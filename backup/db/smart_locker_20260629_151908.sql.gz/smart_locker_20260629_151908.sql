--
-- PostgreSQL database dump
--

\restrict yTixLKRo3ctHdgzMHZqXCMqMoS0Yywyff6BTS0qVSR2eYTbLn9QuYIgI8alVO1V

-- Dumped from database version 14.23 (Ubuntu 14.23-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.23 (Ubuntu 14.23-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'admin'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auth_token text
);


ALTER TABLE public.admin_users OWNER TO locker_admin;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_users_id_seq OWNER TO locker_admin;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: after_sales; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.after_sales (
    id integer NOT NULL,
    ticket_no text,
    cabinet_id integer,
    location_id integer,
    device_id text,
    fault_type text,
    description text,
    status text DEFAULT 'pending'::text,
    handler text,
    handler_note text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.after_sales OWNER TO locker_admin;

--
-- Name: after_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.after_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.after_sales_id_seq OWNER TO locker_admin;

--
-- Name: after_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.after_sales_id_seq OWNED BY public.after_sales.id;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.agents (
    id integer NOT NULL,
    name text NOT NULL,
    contact_name text,
    contact_phone text NOT NULL,
    password_hash text NOT NULL,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    commission_rate double precision DEFAULT 0,
    auth_token text DEFAULT ''::text,
    login_attempts integer DEFAULT 0,
    is_locked integer DEFAULT 0,
    plain_password text DEFAULT ''::text
);


ALTER TABLE public.agents OWNER TO locker_admin;

--
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agents_id_seq OWNER TO locker_admin;

--
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.agents_id_seq OWNED BY public.agents.id;


--
-- Name: alarms; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.alarms (
    id integer NOT NULL,
    type text NOT NULL,
    cabinet_id integer,
    device_id text,
    content text,
    level integer DEFAULT 1,
    status text DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone,
    resolver text
);


ALTER TABLE public.alarms OWNER TO locker_admin;

--
-- Name: alarms_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.alarms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alarms_id_seq OWNER TO locker_admin;

--
-- Name: alarms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.alarms_id_seq OWNED BY public.alarms.id;


--
-- Name: apk_version; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.apk_version (
    id integer NOT NULL,
    version_name text,
    version_code integer,
    download_url text,
    update_desc text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    file_md5 text DEFAULT ''::text
);


ALTER TABLE public.apk_version OWNER TO locker_admin;

--
-- Name: apk_version_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.apk_version_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.apk_version_id_seq OWNER TO locker_admin;

--
-- Name: apk_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.apk_version_id_seq OWNED BY public.apk_version.id;


--
-- Name: blacklist; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.blacklist (
    id integer NOT NULL,
    phone text NOT NULL,
    reason text,
    cabinet_id integer,
    operator text,
    status text DEFAULT 1,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.blacklist OWNER TO locker_admin;

--
-- Name: blacklist_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.blacklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blacklist_id_seq OWNER TO locker_admin;

--
-- Name: blacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.blacklist_id_seq OWNED BY public.blacklist.id;


--
-- Name: cabinet_groups; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cabinet_groups (
    id integer NOT NULL,
    location_id integer,
    group_code text NOT NULL,
    name text,
    screen_url text,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.cabinet_groups OWNER TO locker_admin;

--
-- Name: cabinet_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cabinet_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cabinet_groups_id_seq OWNER TO locker_admin;

--
-- Name: cabinet_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cabinet_groups_id_seq OWNED BY public.cabinet_groups.id;


--
-- Name: cabinet_slots; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cabinet_slots (
    id integer NOT NULL,
    cabinet_id integer NOT NULL,
    slot_number integer NOT NULL,
    slot_size text DEFAULT 'M'::text,
    status integer DEFAULT 1,
    cabinet_code text,
    mainboard_id integer,
    display_number integer,
    board_no integer DEFAULT 1,
    lock_no integer DEFAULT 1,
    slot_label text DEFAULT ''::text,
    updated_at timestamp without time zone
);


ALTER TABLE public.cabinet_slots OWNER TO locker_admin;

--
-- Name: cabinet_slots_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cabinet_slots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cabinet_slots_id_seq OWNER TO locker_admin;

--
-- Name: cabinet_slots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cabinet_slots_id_seq OWNED BY public.cabinet_slots.id;


--
-- Name: cabinets; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cabinets (
    id integer NOT NULL,
    location_id integer,
    cabinet_code text NOT NULL,
    name text,
    total_slots integer DEFAULT 12,
    status integer DEFAULT 1,
    last_heartbeat timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    group_id integer,
    deposit_amount double precision DEFAULT 20,
    mainboard_device_id text DEFAULT ''::text,
    mainboard_source text DEFAULT ''::text,
    charge_mode text DEFAULT 'deposit'::text,
    app_version text DEFAULT ''::text,
    app_version_code integer DEFAULT 0,
    business_status text DEFAULT 1,
    business_hours text,
    customer_phone text,
    updated_at timestamp without time zone,
    usage_rules text,
    per_use_price double precision DEFAULT 0
);


ALTER TABLE public.cabinets OWNER TO locker_admin;

--
-- Name: cabinets_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cabinets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cabinets_id_seq OWNER TO locker_admin;

--
-- Name: cabinets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cabinets_id_seq OWNED BY public.cabinets.id;


--
-- Name: cached_orders; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cached_orders (
    id integer NOT NULL,
    order_id integer NOT NULL,
    order_no text,
    cabinet_id integer,
    slot_id integer,
    slot_number text,
    deposit_amount double precision,
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    synced integer DEFAULT 0
);


ALTER TABLE public.cached_orders OWNER TO locker_admin;

--
-- Name: cached_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cached_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cached_orders_id_seq OWNER TO locker_admin;

--
-- Name: cached_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cached_orders_id_seq OWNED BY public.cached_orders.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name text NOT NULL,
    credit_code text,
    contact_person text,
    contact_phone text,
    address text,
    status text DEFAULT 1,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.companies OWNER TO locker_admin;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_id_seq OWNER TO locker_admin;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: complaints; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.complaints (
    id integer NOT NULL,
    user_phone text NOT NULL,
    type text DEFAULT 'self'::text,
    content text NOT NULL,
    order_no text,
    status text DEFAULT 0,
    reply text,
    reply_time timestamp without time zone,
    wx_complaint_id text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    complaint_type text DEFAULT 'complaint'::text,
    order_id integer
);


ALTER TABLE public.complaints OWNER TO locker_admin;

--
-- Name: complaints_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.complaints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.complaints_id_seq OWNER TO locker_admin;

--
-- Name: complaints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.complaints_id_seq OWNED BY public.complaints.id;


--
-- Name: device_alerts; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.device_alerts (
    id integer NOT NULL,
    device_id text,
    alert_type text,
    detail text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_alerts OWNER TO locker_admin;

--
-- Name: device_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.device_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_alerts_id_seq OWNER TO locker_admin;

--
-- Name: device_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.device_alerts_id_seq OWNED BY public.device_alerts.id;


--
-- Name: device_logs; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.device_logs (
    id integer NOT NULL,
    device_id text,
    logs text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    log_type text DEFAULT 'info'::text,
    content text,
    level text DEFAULT 'info'::text,
    detail text,
    device_name text,
    status text
);


ALTER TABLE public.device_logs OWNER TO locker_admin;

--
-- Name: device_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.device_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_logs_id_seq OWNER TO locker_admin;

--
-- Name: device_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.device_logs_id_seq OWNED BY public.device_logs.id;


--
-- Name: device_update_logs; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.device_update_logs (
    id integer NOT NULL,
    device_id text,
    success integer DEFAULT 0,
    version_name text DEFAULT ''::text,
    version_code integer DEFAULT 0,
    error_msg text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.device_update_logs OWNER TO locker_admin;

--
-- Name: device_update_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.device_update_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_update_logs_id_seq OWNER TO locker_admin;

--
-- Name: device_update_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.device_update_logs_id_seq OWNED BY public.device_update_logs.id;


--
-- Name: devices; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    device_id text,
    device_name text,
    device_type text,
    status text,
    remark text,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.devices OWNER TO locker_admin;

--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.devices_id_seq OWNER TO locker_admin;

--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: door_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.door_records (
    id integer NOT NULL,
    device_id text,
    board_no text,
    lock_no text,
    order_id text,
    open_type text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.door_records OWNER TO locker_admin;

--
-- Name: door_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.door_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.door_records_id_seq OWNER TO locker_admin;

--
-- Name: door_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.door_records_id_seq OWNED BY public.door_records.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    merchant_id integer NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'staff'::text,
    status text DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auth_token text DEFAULT ''::text,
    permissions text DEFAULT '[]'::text,
    login_attempts integer DEFAULT 0,
    is_locked integer DEFAULT 0,
    plain_password text DEFAULT ''::text
);


ALTER TABLE public.employees OWNER TO locker_admin;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employees_id_seq OWNER TO locker_admin;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    merchant_id integer,
    name text NOT NULL,
    address text,
    longitude double precision,
    latitude double precision,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    withdraw_enabled integer DEFAULT 1,
    auto_approve_day integer DEFAULT 1,
    auto_approve_time text DEFAULT '12:00'::text,
    auto_approve_rate double precision DEFAULT 80,
    click_free_count integer DEFAULT 3,
    anti_test_minutes integer DEFAULT 30,
    anti_test_auto_refund integer DEFAULT 1,
    hide_ratio integer DEFAULT 0,
    whitelist_phones text DEFAULT ''::text,
    duplicate_filter_enabled integer DEFAULT 0,
    duplicate_filter_days integer DEFAULT 7,
    duplicate_filter_limit integer DEFAULT 3,
    show_refunding_status text DEFAULT 1,
    refund_approve_rate double precision DEFAULT 80,
    refund_approve_start_min integer DEFAULT 60,
    refund_approve_end_min integer DEFAULT 300,
    contact_phone text DEFAULT ''::text,
    open_time text DEFAULT '08:00'::text,
    close_time text DEFAULT '22:00'::text,
    allow_slot_select integer DEFAULT 0,
    slot_assign_mode text DEFAULT 'auto'::text,
    allow_mid_retrieve integer DEFAULT 1,
    retrieve_mode text DEFAULT 'both'::text,
    allow_h5_to_mp integer DEFAULT 0,
    show_qr_follow integer DEFAULT 0,
    force_follow_mp integer DEFAULT 0,
    h5_url text DEFAULT ''::text,
    show_slot_count integer DEFAULT 1,
    screen_show_title integer DEFAULT 1,
    screen_title text DEFAULT ''::text,
    slot_full_alert integer DEFAULT 0,
    slot_full_text text DEFAULT ''::text,
    end_alert_minutes integer DEFAULT 0,
    enable_clear_box integer DEFAULT 0,
    clear_box_time text DEFAULT '23:00'::text,
    clear_box_cycle integer DEFAULT 1,
    deposit_random integer DEFAULT 0,
    deposit_min double precision DEFAULT 0,
    deposit_max double precision DEFAULT 0,
    contact_name text DEFAULT ''::text,
    refund_mode text DEFAULT 'auto_approve'::text,
    withdraw_mode text DEFAULT 'manual_approve'::text,
    province text DEFAULT ''::text,
    agent_id integer,
    city text DEFAULT ''::text,
    usage_rules text DEFAULT ''::text,
    deposit_amount double precision DEFAULT 20.0,
    mp_appid text DEFAULT ''::text
);


ALTER TABLE public.locations OWNER TO locker_admin;

--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locations_id_seq OWNER TO locker_admin;

--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: mainboards; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.mainboards (
    id integer NOT NULL,
    cabinet_id integer NOT NULL,
    board_index integer NOT NULL,
    slot_count integer DEFAULT 16,
    name text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    serial_port text DEFAULT 'ttyS1'::text,
    baud_rate integer DEFAULT 9600,
    address text DEFAULT ''::text,
    board_type text DEFAULT 'main'::text,
    protocol text DEFAULT 'YBM'::text
);


ALTER TABLE public.mainboards OWNER TO locker_admin;

--
-- Name: mainboards_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.mainboards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mainboards_id_seq OWNER TO locker_admin;

--
-- Name: mainboards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.mainboards_id_seq OWNED BY public.mainboards.id;


--
-- Name: merchants; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.merchants (
    id integer NOT NULL,
    name text NOT NULL,
    contact_name text,
    contact_phone text NOT NULL,
    password_hash text NOT NULL,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    agent_id integer,
    auth_token text,
    permissions text DEFAULT '[]'::text,
    login_attempts integer DEFAULT 0,
    is_locked integer DEFAULT 0,
    plain_password text DEFAULT ''::text,
    commission_per_order numeric(10,2) DEFAULT 0
);


ALTER TABLE public.merchants OWNER TO locker_admin;

--
-- Name: merchants_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.merchants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.merchants_id_seq OWNER TO locker_admin;

--
-- Name: merchants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.merchants_id_seq OWNED BY public.merchants.id;


--
-- Name: offline_retrieve_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.offline_retrieve_records (
    id integer NOT NULL,
    order_no text NOT NULL,
    retrieve_code text,
    cabinet_id integer,
    slot_id integer,
    slot_number text,
    retrieved_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    synced integer DEFAULT 0,
    uploaded integer DEFAULT 0
);


ALTER TABLE public.offline_retrieve_records OWNER TO locker_admin;

--
-- Name: offline_retrieve_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.offline_retrieve_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.offline_retrieve_records_id_seq OWNER TO locker_admin;

--
-- Name: offline_retrieve_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.offline_retrieve_records_id_seq OWNED BY public.offline_retrieve_records.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    order_no text NOT NULL,
    user_phone text NOT NULL,
    slot_id integer,
    cabinet_id integer,
    compartment_number text,
    access_code text,
    deposit_amount double precision DEFAULT 20,
    status integer DEFAULT 1,
    store_time timestamp without time zone,
    retrieve_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    group_id integer,
    cabinet_code text,
    cabinet_name text,
    slot_size text,
    transaction_id text,
    refund_id text,
    pay_time timestamp without time zone,
    refund_time timestamp without time zone,
    payment_channel_id integer,
    refund_mark integer DEFAULT 0,
    refund_status text DEFAULT 'none'::text,
    refund_amount double precision DEFAULT 0,
    logical_mark text DEFAULT 'N'::text,
    logic_mark text,
    logic_hide text,
    note text,
    admin_remark text,
    pickup_time timestamp without time zone,
    updated_at timestamp without time zone,
    openid text
);


ALTER TABLE public.orders OWNER TO locker_admin;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO locker_admin;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: payment_channels; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.payment_channels (
    id integer NOT NULL,
    name text NOT NULL,
    channel_type text DEFAULT 'wechat'::text NOT NULL,
    mch_id text,
    api_key text,
    app_id text,
    app_secret text,
    cert_name text,
    extra_config text,
    is_active integer DEFAULT 1,
    weight integer DEFAULT 1,
    daily_limit double precision DEFAULT 0,
    total_amount double precision DEFAULT 0,
    total_count integer DEFAULT 0,
    last_used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    rotation_index integer DEFAULT 0
);


ALTER TABLE public.payment_channels OWNER TO locker_admin;

--
-- Name: payment_channels_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.payment_channels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_channels_id_seq OWNER TO locker_admin;

--
-- Name: payment_channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.payment_channels_id_seq OWNED BY public.payment_channels.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    order_id integer NOT NULL,
    type integer NOT NULL,
    amount double precision NOT NULL,
    transaction_id text,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    refund_transaction_id text
);


ALTER TABLE public.payments OWNER TO locker_admin;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO locker_admin;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: pending_lock_cmds; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.pending_lock_cmds (
    id integer NOT NULL,
    device_id text,
    board_no text DEFAULT 1,
    lock_no text,
    protocol text DEFAULT 'YBM'::text,
    order_id text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    delivered integer DEFAULT 0,
    cabinet_id text,
    slot_id integer,
    command text,
    status text
);


ALTER TABLE public.pending_lock_cmds OWNER TO locker_admin;

--
-- Name: pending_lock_cmds_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.pending_lock_cmds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pending_lock_cmds_id_seq OWNER TO locker_admin;

--
-- Name: pending_lock_cmds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.pending_lock_cmds_id_seq OWNED BY public.pending_lock_cmds.id;


--
-- Name: phone_openids; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.phone_openids (
    id integer NOT NULL,
    phone character varying(20),
    openid character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.phone_openids OWNER TO locker_admin;

--
-- Name: phone_openids_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.phone_openids_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.phone_openids_id_seq OWNER TO locker_admin;

--
-- Name: phone_openids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.phone_openids_id_seq OWNED BY public.phone_openids.id;


--
-- Name: remote_open_logs; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.remote_open_logs (
    id integer NOT NULL,
    merchant_id integer,
    cabinet_id integer,
    device_id text,
    slot_id integer,
    slot_number text,
    action_type text DEFAULT 'emergency_open'::text,
    operator text,
    result text DEFAULT 'success'::text,
    success integer DEFAULT 1,
    ip_address text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.remote_open_logs OWNER TO locker_admin;

--
-- Name: remote_open_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.remote_open_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.remote_open_logs_id_seq OWNER TO locker_admin;

--
-- Name: remote_open_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.remote_open_logs_id_seq OWNED BY public.remote_open_logs.id;


--
-- Name: sms_codes; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.sms_codes (
    id integer NOT NULL,
    phone text NOT NULL,
    code text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sms_codes OWNER TO locker_admin;

--
-- Name: sms_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.sms_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sms_codes_id_seq OWNER TO locker_admin;

--
-- Name: sms_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.sms_codes_id_seq OWNED BY public.sms_codes.id;


--
-- Name: storage_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.storage_records (
    id integer NOT NULL,
    cabinet_id integer NOT NULL,
    compartment_number text NOT NULL,
    user_phone text,
    access_code text,
    status text DEFAULT 1,
    store_time timestamp without time zone,
    retrieve_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.storage_records OWNER TO locker_admin;

--
-- Name: storage_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.storage_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.storage_records_id_seq OWNER TO locker_admin;

--
-- Name: storage_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.storage_records_id_seq OWNED BY public.storage_records.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    setting_key text NOT NULL,
    setting_value text,
    description text
);


ALTER TABLE public.system_settings OWNER TO locker_admin;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_settings_id_seq OWNER TO locker_admin;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: user_balances; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.user_balances (
    id integer NOT NULL,
    phone text NOT NULL,
    balance double precision DEFAULT 0,
    total_deposited double precision DEFAULT 0,
    total_withdrawn double precision DEFAULT 0,
    first_use_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    wechat_name text DEFAULT ''::text,
    openid text DEFAULT ''::text
);


ALTER TABLE public.user_balances OWNER TO locker_admin;

--
-- Name: user_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.user_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_balances_id_seq OWNER TO locker_admin;

--
-- Name: user_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.user_balances_id_seq OWNED BY public.user_balances.id;


--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.user_profiles (
    openid text NOT NULL,
    wechat_name text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_profiles OWNER TO locker_admin;

--
-- Name: withdrawal_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.withdrawal_records (
    id integer NOT NULL,
    order_id integer,
    user_phone text NOT NULL,
    amount double precision NOT NULL,
    status integer DEFAULT 0,
    apply_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approve_time timestamp without time zone,
    approver text,
    click_count integer DEFAULT 1,
    auto_approve_time text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    openid text,
    error_msg text
);


ALTER TABLE public.withdrawal_records OWNER TO locker_admin;

--
-- Name: withdrawal_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.withdrawal_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.withdrawal_records_id_seq OWNER TO locker_admin;

--
-- Name: withdrawal_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.withdrawal_records_id_seq OWNED BY public.withdrawal_records.id;


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: after_sales id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.after_sales ALTER COLUMN id SET DEFAULT nextval('public.after_sales_id_seq'::regclass);


--
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.agents ALTER COLUMN id SET DEFAULT nextval('public.agents_id_seq'::regclass);


--
-- Name: alarms id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.alarms ALTER COLUMN id SET DEFAULT nextval('public.alarms_id_seq'::regclass);


--
-- Name: apk_version id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.apk_version ALTER COLUMN id SET DEFAULT nextval('public.apk_version_id_seq'::regclass);


--
-- Name: blacklist id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.blacklist ALTER COLUMN id SET DEFAULT nextval('public.blacklist_id_seq'::regclass);


--
-- Name: cabinet_groups id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_groups ALTER COLUMN id SET DEFAULT nextval('public.cabinet_groups_id_seq'::regclass);


--
-- Name: cabinet_slots id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_slots ALTER COLUMN id SET DEFAULT nextval('public.cabinet_slots_id_seq'::regclass);


--
-- Name: cabinets id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinets ALTER COLUMN id SET DEFAULT nextval('public.cabinets_id_seq'::regclass);


--
-- Name: cached_orders id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cached_orders ALTER COLUMN id SET DEFAULT nextval('public.cached_orders_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: complaints id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.complaints ALTER COLUMN id SET DEFAULT nextval('public.complaints_id_seq'::regclass);


--
-- Name: device_alerts id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_alerts ALTER COLUMN id SET DEFAULT nextval('public.device_alerts_id_seq'::regclass);


--
-- Name: device_logs id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_logs ALTER COLUMN id SET DEFAULT nextval('public.device_logs_id_seq'::regclass);


--
-- Name: device_update_logs id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_update_logs ALTER COLUMN id SET DEFAULT nextval('public.device_update_logs_id_seq'::regclass);


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: door_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.door_records ALTER COLUMN id SET DEFAULT nextval('public.door_records_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: mainboards id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.mainboards ALTER COLUMN id SET DEFAULT nextval('public.mainboards_id_seq'::regclass);


--
-- Name: merchants id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.merchants ALTER COLUMN id SET DEFAULT nextval('public.merchants_id_seq'::regclass);


--
-- Name: offline_retrieve_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.offline_retrieve_records ALTER COLUMN id SET DEFAULT nextval('public.offline_retrieve_records_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: payment_channels id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payment_channels ALTER COLUMN id SET DEFAULT nextval('public.payment_channels_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: pending_lock_cmds id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.pending_lock_cmds ALTER COLUMN id SET DEFAULT nextval('public.pending_lock_cmds_id_seq'::regclass);


--
-- Name: phone_openids id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.phone_openids ALTER COLUMN id SET DEFAULT nextval('public.phone_openids_id_seq'::regclass);


--
-- Name: remote_open_logs id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.remote_open_logs ALTER COLUMN id SET DEFAULT nextval('public.remote_open_logs_id_seq'::regclass);


--
-- Name: sms_codes id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.sms_codes ALTER COLUMN id SET DEFAULT nextval('public.sms_codes_id_seq'::regclass);


--
-- Name: storage_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.storage_records ALTER COLUMN id SET DEFAULT nextval('public.storage_records_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: user_balances id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balances ALTER COLUMN id SET DEFAULT nextval('public.user_balances_id_seq'::regclass);


--
-- Name: withdrawal_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.withdrawal_records ALTER COLUMN id SET DEFAULT nextval('public.withdrawal_records_id_seq'::regclass);


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.admin_users (id, username, password_hash, role, created_at, auth_token) FROM stdin;
1	admin	scrypt:32768:8:1$w0GArPx5D5wRGeXw$a11d032f4249144577e2c5a3dd441594dbe591a6621c85cd088c46d49bb7da1db239aed3939a1ab291ac07a25401817854a6dfe51ea758f1bde82b9243c10bbe	super_admin	2026-06-11 05:52:50	ca212cc83c326ab2092a002106230515
\.


--
-- Data for Name: after_sales; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.after_sales (id, ticket_no, cabinet_id, location_id, device_id, fault_type, description, status, handler, handler_note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.agents (id, name, contact_name, contact_phone, password_hash, status, created_at, commission_rate, auth_token, login_attempts, is_locked, plain_password) FROM stdin;
3	自动密码测试	自动密码测试	13900005555	scrypt:32768:8:1$Hm09rGIVdhjXIqk0$f0240605e8fb16383b2d77090bcf8fe20dda54705cb3ec1942803aacddf07937bf1974f96919ebaf19bf84b9215fdca3b844a72a2716c6a8957a7b464bd501f5	1	2026-06-23 08:51:36	0	\N	0	0	
1	王昊	王昊	18996093393	scrypt:32768:8:1$9aiLOaUnk3ViGfvc$80cf59d026967038a92c418efee942e429e9fc5457b2ab38b2a39874437560788847b42d6366bf574dd0f97242d94022bf4e2d29f4df3403b75b4e07459dc3f7	1	2026-06-12 05:09:53	0	dd8e9d43f47be61b0c42e142e2fa245c	0	0	
\.


--
-- Data for Name: alarms; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.alarms (id, type, cabinet_id, device_id, content, level, status, created_at, resolved_at, resolver) FROM stdin;
\.


--
-- Data for Name: apk_version; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.apk_version (id, version_name, version_code, download_url, update_desc, create_time, file_md5) FROM stdin;
1	1.1.2	112	https://cqdyxl.com/static/smart-locker.apk	1. 新增远程升级功能\\n2. 新增版本更新弹窗\\n3. 新增下载进度显示\\n4. 支持WebSocket推送升级通知	2026-06-17 11:06:15	
3	1.2.0	120	https://cqdyxl.com/static/smart-locker.apk	1. 原生WebSocket连接\\n2. 修复socket.io兼容性问题\\n3. 补全Activity注册\\n4. 版本号统一	2026-06-18 07:47:11	
4	1.2.1	121	https://cqdyxl.com/static/smart-locker.apk	修复SSL证书信任问题	2026-06-18 09:26:10	
5	1.2.3	123	https://kelaiwei.top/static/smart-locker.apk	1. 恢复备案域名子域名locker.cqdyxl.com\\n2. 修复YBM拨码板号偏移\\n3. 修复YBM协议对齐竞品\\n4. 修复WebSocket连接\\n5. 新增YBM 0x9B设置指令	2026-06-19 05:56:49	
6	v1.2.8	128	http://locker.cqdyxl.com/static/smart-locker-v1.2.8.apk	1. SSL证书信任修复\\n2. wss://安全连接\\n3. 修复串口通信\\n4. 修复0x8A开锁协议	2026-06-20 11:56:32	
7	v1.2.9	129	http://locker.cqdyxl.com/static/smart-locker-v1.2.9.apk	1. 开机自启动\\n2. 修复二维码功能\\n3. UI优化	2026-06-20 12:28:46	
8	v1.2.10	130	http://locker.cqdyxl.com/static/smart-locker-v1.2.10.apk	修复更新安装卡住问题	2026-06-20 13:38:20	
9	v1.2.11	131	http://locker.cqdyxl.com/static/smart-locker-v1.2.11.apk	修复安装卡住+版本号上报	2026-06-20 14:08:42	
10	v1.2.12	132	http://locker.cqdyxl.com/static/smart-locker-v1.2.12.apk	修复APK解析错误	2026-06-20 14:39:58	
11	v1.2.13	133	http://locker.cqdyxl.com/static/smart-locker-v1.2.13.apk	版本号动态读取，修复更新循环	2026-06-20 14:50:48	
12	v1.2.14	134	https://locker.cqdyxl.com/static/smart-locker-v1.2.14.apk	修复WebSocket连接：强制wss://避免明文ws与SSL配置冲突	2026-06-20 15:51:29	
14	1.2.16	136	https://locker.cqdyxl.com/static/smart-locker.apk	修复YBM开锁协议+远程更新三级安装策略+UI复刻	2026-06-21 02:37:30	
15	1.2.17	137	https://locker.cqdyxl.com/static/smart-locker.apk	H5取包+二维码+缓存	2026-06-21 06:44:24	
16	1.2.18	138	https://locker.cqdyxl.com/static/smart-locker.apk	修复: 版本号+开机自启+退桌面重启+安装后自动重启	2026-06-21 07:15:26	
17	1.2.18	138	https://locker.cqdyxl.com/static/smart-locker.apk	fix: version+autostart	2026-06-21 07:16:45	
18	1.2.22	142	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.22 稳定版	2026-06-22 15:22:55	
19	1.2.24	144	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.24 工业屏规则分行+H5取包流程改造+二维码修复+跳转小程序+缓存修复	2026-06-23 07:25:53	
20	1.2.25	145	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.25 版本号升级	2026-06-24 01:27:22	
21	1.2.25	145	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.25	2026-06-24 01:27:31	
22	1.2.26	146	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.26 改为系统安装界面	2026-06-24 01:31:32	
23	1.2.27	147	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.27 返回按钮+取包成功页面+倒计时	2026-06-24 02:59:01	
24	1.2.28	148	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.28 取包界面优化+远程更新功能	2026-06-24 07:17:28	
25	1.2.29	149	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.29 修复开门成功弹窗不显示的问题	2026-06-24 09:34:37	
26	1.2.30	150	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.30 新增解绑功能，可远程解绑设备并重新绑定网点	2026-06-26 02:41:16	
27	1.2.31	151	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.31 修复远程自动更新	2026-06-26 21:21:41.407472	
28	1.2.32	152	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.32 修复安装后不返回软件的问题	2026-06-27 06:46:00.761888	
39	1.2.42	162	https://locker.cqdyxl.com/static/locker.apk	\N	2026-06-28 10:24:07.832223	66749536a08ab3ff24f98d235e73fe6a
30	1.2.33	153	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782517746	v1.2.33 新增前台保活+修复自动重启	2026-06-27 07:32:54.044919	
31	1.2.34	154	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782518827	修复安装后自动重启bug	2026-06-27 08:07:07.747029	
32	1.2.35	155	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782520891	修复重复FileProvider导致安装失败问题；优化安装流程	2026-06-27 08:41:32.108365	
33	1.2.36	156	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782521688	修复重复调度导致频繁轮询的问题	2026-06-27 08:54:49.012667	
34	1.2.37	157	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782522225	修复前台保活机制导致界面反复重启的问题	2026-06-27 09:03:45.449798	
36	1.2.39	159	https://locker.cqdyxl.com/static/locker.apk	修复onPause导致MainActivity无限重启循环	2026-06-27 09:55:31.928991	
40	1.2.43	163	https://locker.cqdyxl.com/static/locker.apk	\N	2026-06-29 09:41:13.415587	ae15b3afeae83d00eadbda85d0311a24
35	1.2.39	159	https://locker.cqdyxl.com/static/locker.apk	修复keepAlive每15秒startActivity导致断网后界面反复重启	2026-06-27 09:11:34.022058	
37	1.2.40	160	https://locker.cqdyxl.com/static/locker.apk	修复WT协议VioSerial未配置波特率导致开锁失败	2026-06-27 14:50:40.644657	
38	1.2.41	161	https://locker.cqdyxl.com/static/locker.apk	修复update_config支持serial_type/protocol_type切换，新增reinitSerialAndProtocol彻底重初始化串口和协议；新增断网看门狗；修复pending命令默认board_no/lock_no导致误开门	2026-06-28 09:59:05.189506	
\.


--
-- Data for Name: blacklist; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.blacklist (id, phone, reason, cabinet_id, operator, status, created_at) FROM stdin;
\.


--
-- Data for Name: cabinet_groups; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cabinet_groups (id, location_id, group_code, name, screen_url, status, created_at) FROM stdin;
1	4	a123	A	\N	1	2026-06-12 05:28:16
\.


--
-- Data for Name: cabinet_slots; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cabinet_slots (id, cabinet_id, slot_number, slot_size, status, cabinet_code, mainboard_id, display_number, board_no, lock_no, slot_label, updated_at) FROM stdin;
13	2	1	S	1	1	1	\N	1	1	\N	2026-06-26 05:33:44
14	2	2	S	1	1	1	\N	1	2	\N	2026-06-26 05:33:44
15	2	3	S	1	1	1	\N	1	3	\N	2026-06-26 05:33:44
16	2	4	S	1	1	1	\N	1	4	\N	2026-06-26 05:33:44
17	2	5	M	1	1	1	\N	1	5	\N	2026-06-26 05:33:44
18	2	6	M	1	1	1	\N	1	6	\N	2026-06-26 05:33:44
19	2	7	M	1	1	1	\N	1	7	\N	2026-06-26 05:33:44
20	2	8	M	1	1	1	\N	1	8	\N	2026-06-26 05:33:44
21	2	9	L	1	1	1	\N	1	9	\N	2026-06-26 05:33:44
22	2	10	L	1	1	1	\N	1	10	\N	2026-06-26 05:33:44
23	2	11	L	1	1	1	\N	1	11	\N	2026-06-26 05:33:44
24	2	12	L	1	1	1	\N	1	12	\N	2026-06-26 05:33:44
25	2	13	M	1	1	1	1	1	13	\N	2026-06-26 05:33:44
26	2	14	M	1	1	1	2	1	14	\N	2026-06-26 05:33:44
27	2	15	M	1	1	1	3	1	15	\N	2026-06-26 05:33:44
28	2	16	M	1	1	1	4	1	16	\N	2026-06-26 05:33:44
29	2	17	M	1	1	1	5	1	17	\N	2026-06-26 05:33:44
30	2	18	M	1	1	1	6	1	18	\N	2026-06-26 05:33:44
31	2	19	M	1	1	1	7	1	19	\N	2026-06-26 05:33:44
32	2	20	M	1	1	1	8	1	20	\N	2026-06-26 05:33:44
33	2	21	M	1	1	1	9	1	21	\N	2026-06-26 05:33:44
34	2	22	M	1	1	1	10	1	22	\N	2026-06-26 05:33:44
35	2	23	M	1	1	1	11	1	23	\N	2026-06-26 05:33:44
36	2	24	M	1	1	1	12	1	24	\N	2026-06-26 05:33:44
37	2	25	M	1	1	2	13	2	1	\N	2026-06-26 05:33:44
38	2	26	M	1	1	2	14	2	2	\N	2026-06-26 05:33:44
39	2	27	M	1	1	2	15	2	3	\N	2026-06-26 05:33:44
40	2	28	M	1	1	2	16	2	4	\N	2026-06-26 05:33:44
41	2	29	M	1	1	2	17	2	5	\N	2026-06-26 05:33:44
42	2	30	M	1	1	2	18	2	6	\N	2026-06-26 05:33:44
43	2	31	M	1	1	2	19	2	7	\N	2026-06-26 05:33:44
44	2	32	M	1	1	2	20	2	8	\N	2026-06-26 05:33:44
45	2	33	M	1	1	2	21	2	9	\N	2026-06-26 05:33:44
46	2	34	M	1	1	2	22	2	10	\N	2026-06-26 05:33:44
47	2	35	M	1	1	2	23	2	11	\N	2026-06-26 05:33:44
48	2	36	M	1	1	2	24	2	12	\N	2026-06-26 05:33:44
49	2	37	M	1	1	2	25	2	13	\N	2026-06-26 05:33:44
50	2	38	M	1	1	2	26	2	14	\N	2026-06-26 05:33:44
51	2	39	M	1	1	2	27	2	15	\N	2026-06-26 05:33:44
52	2	40	M	1	1	2	28	2	16	\N	2026-06-26 05:33:44
53	2	41	M	1	1	2	29	2	17	\N	2026-06-26 05:33:44
54	2	42	M	1	1	2	30	2	18	\N	2026-06-26 05:33:44
55	2	43	M	1	1	2	31	2	19	\N	2026-06-26 05:33:44
56	2	44	M	1	1	2	32	2	20	\N	2026-06-26 05:33:44
57	3	1	M	1	c001	3	1	1	1	\N	2026-06-26 05:33:44
58	3	2	M	1	c001	3	2	1	2	\N	2026-06-26 05:33:44
59	3	3	M	1	c001	3	3	1	3	\N	2026-06-26 05:33:44
60	3	4	M	1	c001	3	4	1	4	\N	2026-06-26 05:33:44
61	3	5	M	1	c001	3	5	1	5	\N	2026-06-26 05:33:44
62	3	6	M	1	c001	3	6	1	6	\N	2026-06-26 05:33:44
63	3	7	M	1	c001	3	7	1	7	\N	2026-06-26 05:33:44
64	3	8	M	1	c001	3	8	1	8	\N	2026-06-26 05:33:44
65	3	9	M	1	c001	3	9	1	9	\N	2026-06-26 05:33:44
66	3	10	M	1	c001	3	10	1	10	\N	2026-06-26 05:33:44
67	3	11	M	1	c001	3	11	1	11	\N	2026-06-26 05:33:44
68	3	12	M	1	c001	3	12	1	12	\N	2026-06-26 05:33:44
69	5	1	M	1	CAB002	4	1	1	1	\N	2026-06-26 05:33:44
70	5	2	M	1	CAB002	4	2	1	2	\N	2026-06-26 05:33:44
71	5	3	M	1	CAB002	4	3	1	3	\N	2026-06-26 05:33:44
72	5	4	M	1	CAB002	4	4	1	4	\N	2026-06-26 05:33:44
73	5	5	M	1	CAB002	4	5	1	5	\N	2026-06-26 05:33:44
74	5	6	M	1	CAB002	4	6	1	6	\N	2026-06-26 05:33:44
75	5	7	M	1	CAB002	4	7	1	7	\N	2026-06-26 05:33:44
76	5	8	M	1	CAB002	4	8	1	8	\N	2026-06-26 05:33:44
77	5	9	M	1	CAB002	4	9	1	9	\N	2026-06-26 05:33:44
78	5	10	M	1	CAB002	4	10	1	10	\N	2026-06-26 05:33:44
79	5	11	M	1	CAB002	4	11	1	11	\N	2026-06-26 05:33:44
80	5	12	M	1	CAB002	4	12	1	12	\N	2026-06-26 05:33:44
81	5	13	M	1	CAB002	4	13	1	13	\N	2026-06-26 05:33:44
82	5	14	M	1	CAB002	4	14	1	14	\N	2026-06-26 05:33:44
83	5	15	M	1	CAB002	4	15	1	15	\N	2026-06-26 05:33:44
84	5	16	M	1	CAB002	4	16	1	16	\N	2026-06-26 05:33:44
85	5	17	M	1	CAB002	4	17	1	17	\N	2026-06-26 05:33:44
86	5	18	M	1	CAB002	4	18	1	18	\N	2026-06-26 05:33:44
87	5	19	M	1	CAB002	4	19	1	19	\N	2026-06-26 05:33:44
88	5	20	M	1	CAB002	4	20	1	20	\N	2026-06-26 05:33:44
89	5	21	M	1	CAB002	4	21	1	21	\N	2026-06-26 05:33:44
90	5	22	M	1	CAB002	4	22	1	22	\N	2026-06-26 05:33:44
91	5	23	M	1	CAB002	4	23	1	23	\N	2026-06-26 05:33:44
92	5	24	M	1	CAB002	4	24	1	24	\N	2026-06-26 05:33:44
181	9	1	M	1	\N	13	\N	1	1	\N	2026-06-26 05:33:44
182	9	2	M	1	\N	13	\N	1	2	\N	2026-06-26 05:33:44
183	9	3	M	1	\N	13	\N	1	3	\N	2026-06-26 05:33:44
184	9	4	M	1	\N	13	\N	1	4	\N	2026-06-26 05:33:44
185	9	5	M	1	\N	13	\N	1	5	\N	2026-06-26 05:33:44
186	9	6	M	1	\N	13	\N	1	6	\N	2026-06-26 05:33:44
187	9	7	M	1	\N	13	\N	1	7	\N	2026-06-26 05:33:44
188	9	8	M	1	\N	13	\N	1	8	\N	2026-06-26 05:33:44
189	9	9	M	1	\N	13	\N	1	9	\N	2026-06-26 05:33:44
190	9	10	M	1	\N	13	\N	1	10	\N	2026-06-26 05:33:44
191	9	11	M	1	\N	13	\N	1	11	\N	2026-06-26 05:33:44
192	9	12	M	1	\N	13	\N	1	12	\N	2026-06-26 05:33:44
193	10	1	M	1	\N	14	\N	1	1	\N	2026-06-26 05:33:44
194	10	2	M	1	\N	14	\N	1	2	\N	2026-06-26 05:33:44
195	10	3	M	1	\N	14	\N	1	3	\N	2026-06-26 05:33:44
196	10	4	M	1	\N	14	\N	1	4	\N	2026-06-26 05:33:44
197	10	5	M	1	\N	14	\N	1	5	\N	2026-06-26 05:33:44
198	10	6	M	1	\N	14	\N	1	6	\N	2026-06-26 05:33:44
199	10	7	M	1	\N	14	\N	1	7	\N	2026-06-26 05:33:44
200	10	8	M	1	\N	14	\N	1	8	\N	2026-06-26 05:33:44
201	10	9	M	1	\N	14	\N	1	9	\N	2026-06-26 05:33:44
202	10	10	M	1	\N	14	\N	1	10	\N	2026-06-26 05:33:44
203	10	11	M	1	\N	14	\N	1	11	\N	2026-06-26 05:33:44
204	10	12	M	1	\N	14	\N	1	12	\N	2026-06-26 05:33:44
205	11	1	M	1	\N	15	\N	1	1	\N	2026-06-26 05:33:44
206	11	2	M	1	\N	15	\N	1	2	\N	2026-06-26 05:33:44
207	11	3	M	1	\N	15	\N	1	3	\N	2026-06-26 05:33:44
208	11	4	M	1	\N	15	\N	1	4	\N	2026-06-26 05:33:44
209	11	5	M	1	\N	15	\N	1	5	\N	2026-06-26 05:33:44
210	11	6	M	1	\N	15	\N	1	6	\N	2026-06-26 05:33:44
211	11	7	M	1	\N	15	\N	1	7	\N	2026-06-26 05:33:44
212	11	8	M	1	\N	15	\N	1	8	\N	2026-06-26 05:33:44
213	11	9	M	1	\N	15	\N	1	9	\N	2026-06-26 05:33:44
214	11	10	M	1	\N	15	\N	1	10	\N	2026-06-26 05:33:44
215	11	11	M	1	\N	15	\N	1	11	\N	2026-06-26 05:33:44
216	11	12	M	1	\N	15	\N	1	12	\N	2026-06-26 05:33:44
229	13	1	M	1	\N	17	\N	1	1	\N	2026-06-26 05:33:44
230	13	2	M	1	\N	17	\N	1	2	\N	2026-06-26 05:33:44
231	13	3	M	1	\N	17	\N	1	3	\N	2026-06-26 05:33:44
232	13	4	M	1	\N	17	\N	1	4	\N	2026-06-26 05:33:44
233	13	5	M	1	\N	17	\N	1	5	\N	2026-06-26 05:33:44
234	13	6	M	1	\N	17	\N	1	6	\N	2026-06-26 05:33:44
235	13	7	M	1	\N	17	\N	1	7	\N	2026-06-26 05:33:44
236	13	8	M	1	\N	17	\N	1	8	\N	2026-06-26 05:33:44
237	13	9	M	1	\N	17	\N	1	9	\N	2026-06-26 05:33:44
238	13	10	M	1	\N	17	\N	1	10	\N	2026-06-26 05:33:44
239	13	11	M	1	\N	17	\N	1	11	\N	2026-06-26 05:33:44
240	13	12	M	1	\N	17	\N	1	12	\N	2026-06-26 05:33:44
241	14	1	M	1	\N	18	\N	1	1	\N	2026-06-26 05:33:44
242	14	2	M	1	\N	18	\N	1	2	\N	2026-06-26 05:33:44
243	14	3	M	1	\N	18	\N	1	3	\N	2026-06-26 05:33:44
244	14	4	M	1	\N	18	\N	1	4	\N	2026-06-26 05:33:44
245	14	5	M	1	\N	18	\N	1	5	\N	2026-06-26 05:33:44
246	14	6	M	1	\N	18	\N	1	6	\N	2026-06-26 05:33:44
247	14	7	M	1	\N	18	\N	1	7	\N	2026-06-26 05:33:44
248	14	8	M	1	\N	18	\N	1	8	\N	2026-06-26 05:33:44
249	14	9	M	1	\N	18	\N	1	9	\N	2026-06-26 05:33:44
250	14	10	M	1	\N	18	\N	1	10	\N	2026-06-26 05:33:44
251	14	11	M	1	\N	18	\N	1	11	\N	2026-06-26 05:33:44
252	14	12	M	1	\N	18	\N	1	12	\N	2026-06-26 05:33:44
447	8	1	medium	2	\N	\N	\N	1	1	1	2026-06-26 05:33:44
448	8	2	medium	1	\N	\N	\N	1	2	2	2026-06-26 05:33:44
449	8	3	medium	1	\N	\N	\N	1	3	3	2026-06-26 05:33:44
450	8	4	medium	1	\N	\N	\N	1	4	4	2026-06-26 05:33:44
451	8	5	medium	1	\N	\N	\N	1	5	5	2026-06-26 05:33:44
452	8	6	medium	1	\N	\N	\N	1	6	6	2026-06-26 05:33:44
453	8	7	medium	1	\N	\N	\N	1	7	7	2026-06-26 05:33:44
454	8	8	medium	2	\N	\N	\N	1	8	8	2026-06-26 05:33:44
455	8	9	medium	1	\N	\N	\N	1	9	9	2026-06-26 05:33:44
456	8	10	medium	1	\N	\N	\N	1	10	10	2026-06-26 05:33:44
457	8	11	medium	1	\N	\N	\N	1	11	11	2026-06-26 05:33:44
458	8	12	medium	1	\N	\N	\N	1	12	12	2026-06-26 05:33:44
459	8	13	medium	1	\N	\N	\N	1	13	13	2026-06-26 05:33:44
460	8	14	medium	1	\N	\N	\N	1	14	14	2026-06-26 05:33:44
461	8	15	medium	1	\N	\N	\N	1	15	15	2026-06-26 05:33:44
462	8	16	medium	1	\N	\N	\N	1	16	16	2026-06-26 05:33:44
463	15	1	medium	1	\N	\N	\N	1	1	1	\N
468	15	6	medium	1	\N	\N	\N	1	6	6	\N
469	15	7	medium	1	\N	\N	\N	1	7	7	\N
470	15	8	medium	1	\N	\N	\N	1	8	8	\N
471	15	9	medium	1	\N	\N	\N	1	9	9	\N
474	15	12	medium	1	\N	\N	\N	1	12	12	\N
475	15	13	medium	1	\N	\N	\N	1	13	13	\N
476	15	14	medium	1	\N	\N	\N	1	14	14	\N
477	15	15	medium	1	\N	\N	\N	1	15	15	\N
478	15	16	medium	1	\N	\N	\N	1	16	16	\N
479	15	17	medium	1	\N	\N	\N	2	1	17	\N
480	15	18	medium	1	\N	\N	\N	2	2	18	\N
481	15	19	medium	1	\N	\N	\N	2	3	19	\N
482	15	20	medium	1	\N	\N	\N	2	4	20	\N
483	15	21	medium	1	\N	\N	\N	2	5	21	\N
484	15	22	medium	1	\N	\N	\N	2	6	22	\N
485	15	23	medium	1	\N	\N	\N	2	7	23	\N
486	15	24	medium	1	\N	\N	\N	2	8	24	\N
487	15	25	medium	1	\N	\N	\N	2	9	25	\N
488	15	26	medium	1	\N	\N	\N	2	10	26	\N
489	15	27	medium	1	\N	\N	\N	2	11	27	\N
490	15	28	medium	1	\N	\N	\N	2	12	28	\N
491	15	29	medium	1	\N	\N	\N	2	13	29	\N
492	15	30	medium	1	\N	\N	\N	2	14	30	\N
493	15	31	medium	1	\N	\N	\N	2	15	31	\N
494	15	32	medium	1	\N	\N	\N	2	16	32	\N
472	15	10	medium	1	\N	\N	\N	1	10	10	\N
495	16	1	medium	1	\N	\N	\N	1	1	1	\N
497	16	3	medium	1	\N	\N	\N	1	3	3	\N
498	16	4	medium	1	\N	\N	\N	1	4	4	\N
503	16	9	medium	1	\N	\N	\N	1	9	9	\N
505	16	11	medium	1	\N	\N	\N	1	11	11	\N
506	16	12	medium	1	\N	\N	\N	1	12	12	\N
473	15	11	medium	1	\N	\N	\N	1	11	11	\N
500	16	6	medium	2	\N	\N	\N	1	6	6	\N
501	16	7	medium	1	\N	\N	\N	1	7	7	\N
502	16	8	medium	2	\N	\N	\N	1	8	8	\N
504	16	10	medium	2	\N	\N	\N	1	10	10	\N
465	15	3	medium	1	\N	\N	\N	1	3	3	\N
499	16	5	medium	1	\N	\N	\N	1	5	5	\N
464	15	2	medium	1	\N	\N	\N	1	2	2	\N
466	15	4	medium	1	\N	\N	\N	1	4	4	\N
507	16	13	medium	1	\N	\N	\N	1	13	13	\N
509	16	15	medium	1	\N	\N	\N	1	15	15	\N
510	16	16	medium	1	\N	\N	\N	1	16	16	\N
496	16	2	medium	1	\N	\N	\N	1	2	2	\N
511	16	17	medium	1	\N	\N	\N	2	1	17	\N
514	16	20	medium	1	\N	\N	\N	2	4	20	\N
518	16	24	medium	1	\N	\N	\N	2	8	24	\N
520	16	26	medium	1	\N	\N	\N	2	10	26	\N
523	16	29	medium	1	\N	\N	\N	2	13	29	\N
524	16	30	medium	1	\N	\N	\N	2	14	30	\N
525	16	31	medium	1	\N	\N	\N	2	15	31	\N
526	16	32	medium	1	\N	\N	\N	2	16	32	\N
508	16	14	medium	1	\N	\N	\N	1	14	14	\N
467	15	5	medium	2	\N	\N	\N	1	5	5	\N
515	16	21	medium	1	\N	\N	\N	2	5	21	\N
522	16	28	medium	1	\N	\N	\N	2	12	28	\N
519	16	25	medium	1	\N	\N	\N	2	9	25	\N
521	16	27	medium	1	\N	\N	\N	2	11	27	\N
513	16	19	medium	1	\N	\N	\N	2	3	19	\N
512	16	18	medium	1	\N	\N	\N	2	2	18	\N
517	16	23	medium	1	\N	\N	\N	2	7	23	\N
516	16	22	medium	1	\N	\N	\N	2	6	22	\N
\.


--
-- Data for Name: cabinets; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cabinets (id, location_id, cabinet_code, name, total_slots, status, last_heartbeat, created_at, group_id, deposit_amount, mainboard_device_id, mainboard_source, charge_mode, app_version, app_version_code, business_status, business_hours, customer_phone, updated_at, usage_rules, per_use_price) FROM stdin;
8	4	CAB005	智能寄存柜	16	1	2026-06-27 09:29:36.651437	2026-06-14 14:45:50	\N	20	123456	WT	deposit	1.2.30	150	active	8:00~22:00	4006981080	2026-06-27 11:40:45.308331	24小时内取包免费\\n保证金{deposit_amount}元，寄存结束后按规则结算\\n存包后请保管好取件码\\n柜内禁止存放易燃易爆及违禁物品	0
15	6	CAB20260625180817	A柜	32	1	2026-06-29 08:43:12.343451	2026-06-25 10:08:17	\N	1	101001	WT	deposit	1.2.42	162	open	\N	0	2026-06-28 07:19:10.849061	24小时内取包免费\\n保证金{deposit_amount}元，寄存结束后按规则结算\\n存包后请保管好取件码\\n柜内禁止存放易燃易爆及违禁物品	4006981080
16	6	CAB20260625181326	B柜	32	1	2026-06-29 15:19:07.665169	2026-06-25 10:13:26	\N	20	100100	YBM	deposit	1.2.43	163	open	\N	0	2026-06-28 07:43:42.926212	24小时内取包免费\\n保证金{deposit_amount}元，寄存结束后按规则结算\\n存包后请保管好取件码\\n柜内禁止存放易燃易爆及违禁物品	4006981080
\.


--
-- Data for Name: cached_orders; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cached_orders (id, order_id, order_no, cabinet_id, slot_id, slot_number, deposit_amount, status, created_at, synced) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.companies (id, name, credit_code, contact_person, contact_phone, address, status, created_at) FROM stdin;
1	重庆科莱维科技有限公司	91500106MACK2R5P8G	李百棚	4006981080	重庆市沙坪坝区覃家岗街道凤鸣山307号附54号26-22	1	2026-06-18 02:28:25
2	测试公司	TEST001	\N	\N	\N	1	2026-06-18 02:54:02
\.


--
-- Data for Name: complaints; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.complaints (id, user_phone, type, content, order_no, status, reply, reply_time, wx_complaint_id, created_at, complaint_type, order_id) FROM stdin;
\.


--
-- Data for Name: device_alerts; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.device_alerts (id, device_id, alert_type, detail, created_at) FROM stdin;
3	100100	online	设备WebSocket连接建立	2026-06-27 10:55:56.91984
4	100100	online	设备WebSocket连接建立	2026-06-27 10:55:57.461221
5	100100	online	设备WebSocket连接建立	2026-06-27 10:59:31.857423
6	100100	online	设备WebSocket连接建立	2026-06-27 10:59:31.935454
7	100100	online	设备WebSocket连接建立	2026-06-27 11:00:20.381276
8	100100	online	设备WebSocket连接建立	2026-06-27 11:00:20.45294
9	100100	online	设备WebSocket连接建立	2026-06-27 11:07:40.394132
10	100100	online	设备WebSocket连接建立	2026-06-27 11:07:40.63802
11	100100	online	设备WebSocket连接建立	2026-06-27 11:08:49.266356
12	100100	online	设备WebSocket连接建立	2026-06-27 11:08:49.354396
13	100100	online	设备WebSocket连接建立	2026-06-27 11:10:03.377474
14	100100	online	设备WebSocket连接建立	2026-06-27 11:10:03.451777
15	100100	online	设备WebSocket连接建立	2026-06-27 11:12:19.854435
16	100100	online	设备WebSocket连接建立	2026-06-27 11:12:19.923264
17	100100	online	设备WebSocket连接建立	2026-06-27 11:12:47.261434
18	100100	online	设备WebSocket连接建立	2026-06-27 11:12:47.330682
19	100100	online	设备WebSocket连接建立	2026-06-27 11:12:48.555489
20	100100	online	设备WebSocket连接建立	2026-06-27 11:12:48.627375
21	100100	online	设备WebSocket连接建立	2026-06-27 11:12:49.916003
22	100100	online	设备WebSocket连接建立	2026-06-27 11:12:49.991209
23	100100	online	设备WebSocket连接建立	2026-06-27 11:12:51.225431
24	100100	online	设备WebSocket连接建立	2026-06-27 11:12:51.306914
25	100100	online	设备WebSocket连接建立	2026-06-27 11:12:52.580641
26	100100	online	设备WebSocket连接建立	2026-06-27 11:12:52.649964
27	100100	online	设备WebSocket连接建立	2026-06-27 11:12:54.041139
28	100100	online	设备WebSocket连接建立	2026-06-27 11:12:54.127381
29	100100	online	设备WebSocket连接建立	2026-06-27 11:12:55.4078
30	100100	online	设备WebSocket连接建立	2026-06-27 11:12:55.499532
31	100100	online	设备WebSocket连接建立	2026-06-27 11:12:56.837912
32	100100	online	设备WebSocket连接建立	2026-06-27 11:12:56.913271
33	100100	online	设备WebSocket连接建立	2026-06-27 11:12:58.173546
34	100100	online	设备WebSocket连接建立	2026-06-27 11:12:58.244881
35	100100	online	设备WebSocket连接建立	2026-06-27 11:12:59.539079
36	100100	online	设备WebSocket连接建立	2026-06-27 11:12:59.61114
37	100100	online	设备WebSocket连接建立	2026-06-27 11:13:00.877525
38	100100	online	设备WebSocket连接建立	2026-06-27 11:13:00.950467
39	100100	online	设备WebSocket连接建立	2026-06-27 11:13:02.406601
40	100100	online	设备WebSocket连接建立	2026-06-27 11:13:02.481136
41	100100	online	设备WebSocket连接建立	2026-06-27 11:13:03.73445
42	100100	online	设备WebSocket连接建立	2026-06-27 11:13:03.806018
43	100100	online	设备WebSocket连接建立	2026-06-27 11:13:05.050571
44	100100	online	设备WebSocket连接建立	2026-06-27 11:13:05.122727
45	100100	online	设备WebSocket连接建立	2026-06-27 11:13:06.344516
46	100100	online	设备WebSocket连接建立	2026-06-27 11:13:06.418125
47	100100	online	设备WebSocket连接建立	2026-06-27 11:13:07.648217
48	100100	online	设备WebSocket连接建立	2026-06-27 11:13:07.717789
49	100100	online	设备WebSocket连接建立	2026-06-27 11:13:38.589728
50	100100	online	设备WebSocket连接建立	2026-06-27 11:13:38.660644
51	101001	online	设备WebSocket连接建立	2026-06-27 11:16:43.984789
52	101001	online	设备WebSocket连接建立	2026-06-27 11:16:44.057094
53	101001	offline	设备WebSocket断开连接	2026-06-27 11:20:10.390829
54	101001	online	设备WebSocket连接建立	2026-06-27 11:20:10.850521
55	101001	online	设备WebSocket连接建立	2026-06-27 11:20:11.443967
56	100100	online	设备WebSocket连接建立	2026-06-27 11:23:55.912602
57	100100	online	设备WebSocket连接建立	2026-06-27 11:23:55.986191
58	101001	online	设备WebSocket连接建立	2026-06-27 11:23:56.163704
59	101001	online	设备WebSocket连接建立	2026-06-27 11:23:56.242573
60	101001	offline	设备WebSocket断开连接	2026-06-27 11:24:56.33821
61	101001	online	设备WebSocket连接建立	2026-06-27 11:24:57.973628
62	101001	online	设备WebSocket连接建立	2026-06-27 11:24:58.043956
63	100100	online	设备WebSocket连接建立	2026-06-27 11:29:09.559206
64	100100	online	设备WebSocket连接建立	2026-06-27 11:29:09.630231
65	101001	online	设备WebSocket连接建立	2026-06-27 11:29:18.428186
66	101001	online	设备WebSocket连接建立	2026-06-27 11:29:18.514517
67	101001	offline	设备WebSocket断开连接	2026-06-27 11:29:58.492744
68	101001	online	设备WebSocket连接建立	2026-06-27 11:30:00.81245
69	101001	online	设备WebSocket连接建立	2026-06-27 11:30:00.922113
70	101001	offline	设备WebSocket断开连接	2026-06-27 11:30:45.57715
71	101001	online	设备WebSocket连接建立	2026-06-27 11:30:54.254622
72	101001	online	设备WebSocket连接建立	2026-06-27 11:30:54.33895
73	100100	offline	设备WebSocket断开连接	2026-06-27 11:31:42.249812
74	100100	online	设备WebSocket连接建立	2026-06-27 11:31:48.402826
75	100100	online	设备WebSocket连接建立	2026-06-27 11:31:48.500141
76	101001	online	设备WebSocket连接建立	2026-06-27 11:35:41.855068
77	101001	online	设备WebSocket连接建立	2026-06-27 11:35:41.928488
78	100100	online	设备WebSocket连接建立	2026-06-27 11:44:03.720774
79	100100	online	设备WebSocket连接建立	2026-06-27 11:44:03.790999
80	101001	online	设备WebSocket连接建立	2026-06-27 11:44:24.235326
81	101001	online	设备WebSocket连接建立	2026-06-27 11:44:24.554912
82	100100	online	设备WebSocket连接建立	2026-06-27 11:55:16.171009
83	100100	online	设备WebSocket连接建立	2026-06-27 11:55:16.24396
84	100100	online	设备WebSocket连接建立	2026-06-27 11:58:36.821876
85	100100	online	设备WebSocket连接建立	2026-06-27 11:58:36.897543
86	100100	online	设备WebSocket连接建立	2026-06-27 12:11:37.160118
87	100100	online	设备WebSocket连接建立	2026-06-27 12:11:37.230653
88	100100	online	设备WebSocket连接建立	2026-06-27 12:28:29.595707
89	100100	online	设备WebSocket连接建立	2026-06-27 12:28:29.688708
90	100100	online	设备WebSocket连接建立	2026-06-27 12:30:47.394625
91	100100	online	设备WebSocket连接建立	2026-06-27 12:30:47.467509
92	100100	online	设备WebSocket连接建立	2026-06-27 12:35:45.520331
93	100100	online	设备WebSocket连接建立	2026-06-27 12:35:45.595731
94	100100	online	设备WebSocket连接建立	2026-06-27 12:42:26.257185
95	100100	online	设备WebSocket连接建立	2026-06-27 12:42:26.329878
96	100100	online	设备WebSocket连接建立	2026-06-27 12:45:37.822836
97	100100	online	设备WebSocket连接建立	2026-06-27 12:45:37.935435
98	100100	online	设备WebSocket连接建立	2026-06-27 12:50:43.915669
99	100100	online	设备WebSocket连接建立	2026-06-27 12:50:43.987128
100	100100	online	设备WebSocket连接建立	2026-06-27 12:58:19.943683
101	100100	online	设备WebSocket连接建立	2026-06-27 12:58:20.019932
102	100100	online	设备WebSocket连接建立	2026-06-27 12:58:42.944621
103	100100	online	设备WebSocket连接建立	2026-06-27 12:58:43.016519
104	100100	online	设备WebSocket连接建立	2026-06-27 13:16:34.084493
105	100100	online	设备WebSocket连接建立	2026-06-27 13:16:34.154438
106	100100	online	设备WebSocket连接建立	2026-06-27 13:17:48.989725
107	100100	online	设备WebSocket连接建立	2026-06-27 13:17:49.071032
108	100100	online	设备WebSocket连接建立	2026-06-27 13:42:02.442429
109	100100	online	设备WebSocket连接建立	2026-06-27 13:42:02.512096
110	101001	online	设备WebSocket连接建立	2026-06-27 13:58:01.052123
111	101001	online	设备WebSocket连接建立	2026-06-27 13:58:01.124738
112	101001	offline	设备WebSocket断开连接	2026-06-27 13:59:12.339609
113	101001	online	设备WebSocket连接建立	2026-06-27 14:00:14.099787
114	101001	online	设备WebSocket连接建立	2026-06-27 14:00:14.192503
115	100100	online	设备WebSocket连接建立	2026-06-27 14:09:37.808714
116	100100	online	设备WebSocket连接建立	2026-06-27 14:09:37.882159
117	101001	online	设备WebSocket连接建立	2026-06-27 14:09:37.952859
118	101001	online	设备WebSocket连接建立	2026-06-27 14:09:38.026301
119	101001	online	设备WebSocket连接建立	2026-06-27 14:26:36.722879
120	101001	online	设备WebSocket连接建立	2026-06-27 14:26:36.796375
121	100100	online	设备WebSocket连接建立	2026-06-27 14:26:37.075285
122	100100	online	设备WebSocket连接建立	2026-06-27 14:26:37.152586
123	100100	online	设备WebSocket连接建立	2026-06-27 14:30:51.991888
124	100100	online	设备WebSocket连接建立	2026-06-27 14:30:52.06807
125	101001	online	设备WebSocket连接建立	2026-06-27 14:30:52.242664
126	101001	online	设备WebSocket连接建立	2026-06-27 14:30:52.314568
127	101001	online	设备WebSocket连接建立	2026-06-27 14:30:56.99661
128	100100	online	设备WebSocket连接建立	2026-06-27 14:30:57.069126
129	100100	online	设备WebSocket连接建立	2026-06-27 14:30:57.145065
130	101001	online	设备WebSocket连接建立	2026-06-27 14:30:57.221708
131	101001	online	设备WebSocket连接建立	2026-06-27 14:49:41.095679
132	101001	online	设备WebSocket连接建立	2026-06-27 14:49:41.167306
133	100100	online	设备WebSocket连接建立	2026-06-27 14:49:41.353313
134	100100	online	设备WebSocket连接建立	2026-06-27 14:49:41.422462
135	101001	online	设备WebSocket连接建立	2026-06-27 14:52:53.476754
136	101001	online	设备WebSocket连接建立	2026-06-27 14:52:53.5524
137	100100	online	设备WebSocket连接建立	2026-06-27 14:52:53.737981
138	100100	online	设备WebSocket连接建立	2026-06-27 14:52:53.809222
139	100100	online	设备WebSocket连接建立	2026-06-27 14:54:06.200075
140	100100	online	设备WebSocket连接建立	2026-06-27 14:54:06.273558
141	101001	online	设备WebSocket连接建立	2026-06-27 14:54:06.441097
142	101001	online	设备WebSocket连接建立	2026-06-27 14:54:06.536404
143	100100	online	设备WebSocket连接建立	2026-06-27 14:54:57.425766
144	100100	online	设备WebSocket连接建立	2026-06-27 14:54:57.498051
145	101001	online	设备WebSocket连接建立	2026-06-27 14:55:00.345343
146	101001	online	设备WebSocket连接建立	2026-06-27 14:55:00.421623
147	101001	online	设备WebSocket连接建立	2026-06-27 14:56:05.473517
148	101001	online	设备WebSocket连接建立	2026-06-27 14:56:05.710202
149	100100	online	设备WebSocket连接建立	2026-06-27 14:56:05.783358
150	100100	online	设备WebSocket连接建立	2026-06-27 14:56:05.857102
151	100100	online	设备WebSocket连接建立	2026-06-27 14:57:32.001079
152	100100	online	设备WebSocket连接建立	2026-06-27 14:57:32.073553
153	101001	online	设备WebSocket连接建立	2026-06-27 14:57:49.589517
154	101001	online	设备WebSocket连接建立	2026-06-27 14:57:49.662768
155	100100	online	设备WebSocket连接建立	2026-06-27 15:05:50.047388
156	100100	online	设备WebSocket连接建立	2026-06-27 15:05:50.118638
157	101001	online	设备WebSocket连接建立	2026-06-27 15:05:53.355632
158	101001	online	设备WebSocket连接建立	2026-06-27 15:05:54.148915
159	101001	offline	设备WebSocket断开连接	2026-06-27 15:12:32.221135
160	101001	online	设备WebSocket连接建立	2026-06-27 15:12:38.025838
161	101001	online	设备WebSocket连接建立	2026-06-27 15:12:38.098489
162	101001	online	设备WebSocket连接建立	2026-06-27 15:24:38.341851
163	101001	online	设备WebSocket连接建立	2026-06-27 15:24:38.421847
164	100100	online	设备WebSocket连接建立	2026-06-27 15:35:33.355339
165	100100	online	设备WebSocket连接建立	2026-06-27 15:35:33.700155
166	101001	online	设备WebSocket连接建立	2026-06-27 15:36:08.475763
167	101001	online	设备WebSocket连接建立	2026-06-27 15:36:08.554127
168	100100	offline	设备WebSocket断开连接	2026-06-27 15:50:59.540512
169	100100	online	设备WebSocket连接建立	2026-06-27 15:51:05.69696
170	100100	online	设备WebSocket连接建立	2026-06-27 15:51:05.773884
171	100100	online	设备WebSocket连接建立	2026-06-27 15:53:01.32763
172	100100	online	设备WebSocket连接建立	2026-06-27 15:53:01.399322
173	101001	online	设备WebSocket连接建立	2026-06-27 15:53:01.507267
174	101001	online	设备WebSocket连接建立	2026-06-27 15:53:01.585697
175	100100	online	设备WebSocket连接建立	2026-06-27 15:53:06.659286
176	100100	online	设备WebSocket连接建立	2026-06-27 15:53:06.735054
177	101001	online	设备WebSocket连接建立	2026-06-27 15:53:06.810704
178	101001	online	设备WebSocket连接建立	2026-06-27 15:53:06.883891
179	100100	online	设备WebSocket连接建立	2026-06-27 15:59:49.079856
180	100100	online	设备WebSocket连接建立	2026-06-27 15:59:49.221892
181	101001	online	设备WebSocket连接建立	2026-06-27 15:59:49.302743
182	101001	online	设备WebSocket连接建立	2026-06-27 15:59:49.377531
183	101001	online	设备WebSocket连接建立	2026-06-27 16:09:47.331367
184	101001	online	设备WebSocket连接建立	2026-06-27 16:09:47.428036
185	100100	online	设备WebSocket连接建立	2026-06-27 16:09:47.503295
186	100100	online	设备WebSocket连接建立	2026-06-27 16:09:47.95771
187	100100	offline	设备WebSocket断开连接	2026-06-27 16:24:59.778041
188	101001	online	设备WebSocket连接建立	2026-06-27 16:31:53.974559
189	101001	online	设备WebSocket连接建立	2026-06-27 16:31:54.051231
190	100100	online	设备WebSocket连接建立	2026-06-27 16:37:57.075038
191	100100	online	设备WebSocket连接建立	2026-06-27 16:37:57.14883
192	100100	online	设备WebSocket连接建立	2026-06-27 16:52:19.756726
193	100100	online	设备WebSocket连接建立	2026-06-27 16:52:20.011994
194	100100	offline	设备WebSocket断开连接	2026-06-27 16:53:37.760693
195	101001	online	设备WebSocket连接建立	2026-06-27 17:05:21.068977
196	101001	online	设备WebSocket连接建立	2026-06-27 17:05:21.147375
197	101001	online	设备WebSocket连接建立	2026-06-27 17:11:43.009515
198	101001	online	设备WebSocket连接建立	2026-06-27 17:11:43.148494
199	101001	online	设备WebSocket连接建立	2026-06-27 17:12:31.975608
200	101001	online	设备WebSocket连接建立	2026-06-27 17:12:32.108736
201	101001	online	设备WebSocket连接建立	2026-06-27 17:13:14.185902
202	101001	online	设备WebSocket连接建立	2026-06-27 17:13:14.269736
203	101001	offline	设备WebSocket断开连接	2026-06-27 17:13:57.393623
204	101001	online	设备WebSocket连接建立	2026-06-27 17:14:03.232819
205	101001	online	设备WebSocket连接建立	2026-06-27 17:14:03.320362
206	101001	online	设备WebSocket连接建立	2026-06-27 17:14:58.109727
207	101001	online	设备WebSocket连接建立	2026-06-27 17:14:58.188691
208	101001	online	设备WebSocket连接建立	2026-06-27 17:15:50.748542
209	101001	online	设备WebSocket连接建立	2026-06-27 17:15:50.834547
210	101001	online	设备WebSocket连接建立	2026-06-27 17:19:04.074877
211	101001	online	设备WebSocket连接建立	2026-06-27 17:19:04.185739
212	101001	offline	设备WebSocket断开连接	2026-06-27 17:20:44.186843
213	101001	online	设备WebSocket连接建立	2026-06-27 17:20:45.86578
214	101001	online	设备WebSocket连接建立	2026-06-27 17:20:45.946464
215	101001	online	设备WebSocket连接建立	2026-06-27 17:25:32.954773
216	101001	online	设备WebSocket连接建立	2026-06-27 17:25:33.181436
217	101001	online	设备WebSocket连接建立	2026-06-27 17:27:28.346106
218	101001	online	设备WebSocket连接建立	2026-06-27 17:27:28.424993
219	101001	online	设备WebSocket连接建立	2026-06-27 18:04:56.652973
220	101001	online	设备WebSocket连接建立	2026-06-27 18:04:56.740728
221	101001	online	设备WebSocket连接建立	2026-06-27 18:06:52.819787
222	101001	online	设备WebSocket连接建立	2026-06-27 18:06:52.893232
223	101001	online	设备WebSocket连接建立	2026-06-27 22:43:22.88857
224	101001	online	设备WebSocket连接建立	2026-06-27 22:43:22.967632
225	101001	online	设备WebSocket连接建立	2026-06-27 23:15:08.466261
226	101001	online	设备WebSocket连接建立	2026-06-27 23:15:08.545361
227	101001	offline	设备WebSocket断开连接	2026-06-28 02:10:17.700956
228	100100	online	设备WebSocket连接建立	2026-06-28 07:42:07.076801
229	100100	online	设备WebSocket连接建立	2026-06-28 07:42:07.148268
230	100100	online	设备WebSocket连接建立	2026-06-28 07:45:40.294895
231	100100	online	设备WebSocket连接建立	2026-06-28 07:45:40.369461
232	100100	online	设备WebSocket连接建立	2026-06-28 07:46:31.403873
233	100100	online	设备WebSocket连接建立	2026-06-28 07:46:31.478628
234	100100	online	设备WebSocket连接建立	2026-06-28 07:55:19.148113
235	100100	online	设备WebSocket连接建立	2026-06-28 07:55:19.224822
236	100100	online	设备WebSocket连接建立	2026-06-28 08:01:45.333148
237	100100	online	设备WebSocket连接建立	2026-06-28 08:01:45.411546
238	100100	online	设备WebSocket连接建立	2026-06-28 08:06:36.979856
239	100100	online	设备WebSocket连接建立	2026-06-28 08:06:37.053312
240	100100	online	设备WebSocket连接建立	2026-06-28 08:06:47.205464
241	100100	online	设备WebSocket连接建立	2026-06-28 08:06:47.27967
242	101001	online	设备WebSocket连接建立	2026-06-28 08:10:31.696513
243	101001	online	设备WebSocket连接建立	2026-06-28 08:10:31.769677
244	100100	online	设备WebSocket连接建立	2026-06-28 08:18:42.757439
245	100100	online	设备WebSocket连接建立	2026-06-28 08:18:42.828576
246	101001	online	设备WebSocket连接建立	2026-06-28 08:18:44.822992
247	101001	online	设备WebSocket连接建立	2026-06-28 08:18:44.898687
248	100100	online	设备WebSocket连接建立	2026-06-28 08:28:12.025768
249	100100	online	设备WebSocket连接建立	2026-06-28 08:28:12.274313
250	101001	online	设备WebSocket连接建立	2026-06-28 08:28:12.36468
251	101001	online	设备WebSocket连接建立	2026-06-28 08:28:12.4665
252	101001	online	设备WebSocket连接建立	2026-06-28 08:29:37.479541
253	101001	online	设备WebSocket连接建立	2026-06-28 08:29:37.627901
254	100100	online	设备WebSocket连接建立	2026-06-28 08:29:37.968583
255	100100	online	设备WebSocket连接建立	2026-06-28 08:29:38.043873
256	100100	online	设备WebSocket连接建立	2026-06-28 08:39:24.423586
257	100100	online	设备WebSocket连接建立	2026-06-28 08:39:24.509015
258	101001	online	设备WebSocket连接建立	2026-06-28 08:39:24.581357
259	101001	online	设备WebSocket连接建立	2026-06-28 08:39:24.788743
260	101001	online	设备WebSocket连接建立	2026-06-28 08:39:34.683667
261	100100	online	设备WebSocket连接建立	2026-06-28 08:39:34.759718
262	100100	online	设备WebSocket连接建立	2026-06-28 08:39:34.837898
263	101001	online	设备WebSocket连接建立	2026-06-28 08:39:34.912728
264	100100	online	设备WebSocket连接建立	2026-06-28 08:44:39.132275
265	100100	online	设备WebSocket连接建立	2026-06-28 08:44:39.211206
266	101001	online	设备WebSocket连接建立	2026-06-28 08:44:39.296442
267	101001	online	设备WebSocket连接建立	2026-06-28 08:44:39.371087
268	100100	online	设备WebSocket连接建立	2026-06-28 09:07:18.259738
269	100100	online	设备WebSocket连接建立	2026-06-28 09:07:18.332833
270	101001	online	设备WebSocket连接建立	2026-06-28 09:07:18.999034
271	101001	online	设备WebSocket连接建立	2026-06-28 09:07:19.23829
272	100100	online	设备WebSocket连接建立	2026-06-28 09:09:36.171337
273	100100	online	设备WebSocket连接建立	2026-06-28 09:09:36.245943
274	101001	online	设备WebSocket连接建立	2026-06-28 09:09:36.317479
275	101001	online	设备WebSocket连接建立	2026-06-28 09:09:36.391455
276	100100	online	设备WebSocket连接建立	2026-06-28 09:11:17.899334
277	100100	online	设备WebSocket连接建立	2026-06-28 09:11:17.978357
278	101001	online	设备WebSocket连接建立	2026-06-28 09:11:18.054865
279	101001	online	设备WebSocket连接建立	2026-06-28 09:11:18.130049
280	100100	online	设备WebSocket连接建立	2026-06-28 09:14:27.188387
281	100100	online	设备WebSocket连接建立	2026-06-28 09:14:27.265968
282	101001	online	设备WebSocket连接建立	2026-06-28 09:14:27.340346
283	101001	online	设备WebSocket连接建立	2026-06-28 09:14:27.414992
284	100100	online	设备WebSocket连接建立	2026-06-28 09:17:09.622663
285	100100	online	设备WebSocket连接建立	2026-06-28 09:17:09.69706
286	101001	online	设备WebSocket连接建立	2026-06-28 09:17:09.769792
287	101001	online	设备WebSocket连接建立	2026-06-28 09:17:09.966535
288	100100	online	设备WebSocket连接建立	2026-06-28 09:18:40.836115
289	100100	online	设备WebSocket连接建立	2026-06-28 09:18:40.909392
290	101001	online	设备WebSocket连接建立	2026-06-28 09:18:40.982775
291	101001	online	设备WebSocket连接建立	2026-06-28 09:18:41.168139
292	101001	online	设备WebSocket连接建立	2026-06-28 09:19:47.846884
293	100100	online	设备WebSocket连接建立	2026-06-28 09:19:47.985685
294	100100	online	设备WebSocket连接建立	2026-06-28 09:19:48.061107
295	101001	online	设备WebSocket连接建立	2026-06-28 09:19:48.139327
296	100100	online	设备WebSocket连接建立	2026-06-28 09:21:15.732146
297	100100	online	设备WebSocket连接建立	2026-06-28 09:21:15.806794
298	101001	online	设备WebSocket连接建立	2026-06-28 09:21:15.883144
299	101001	online	设备WebSocket连接建立	2026-06-28 09:21:16.027311
300	100100	online	设备WebSocket连接建立	2026-06-28 09:23:26.872149
301	100100	online	设备WebSocket连接建立	2026-06-28 09:23:26.947545
302	101001	online	设备WebSocket连接建立	2026-06-28 09:23:27.22378
303	101001	online	设备WebSocket连接建立	2026-06-28 09:23:27.300395
304	100100	online	设备WebSocket连接建立	2026-06-28 09:32:04.15383
305	100100	online	设备WebSocket连接建立	2026-06-28 09:32:04.230537
306	101001	online	设备WebSocket连接建立	2026-06-28 09:32:07.493136
307	101001	online	设备WebSocket连接建立	2026-06-28 09:32:07.573987
308	100100	online	设备WebSocket连接建立	2026-06-28 09:34:29.642791
309	100100	online	设备WebSocket连接建立	2026-06-28 09:34:29.719868
310	101001	online	设备WebSocket连接建立	2026-06-28 09:34:29.794242
311	101001	online	设备WebSocket连接建立	2026-06-28 09:34:29.948186
312	100100	online	设备WebSocket连接建立	2026-06-28 09:46:38.546075
313	100100	online	设备WebSocket连接建立	2026-06-28 09:46:38.623352
314	101001	online	设备WebSocket连接建立	2026-06-28 09:46:39.873659
315	101001	online	设备WebSocket连接建立	2026-06-28 09:46:39.950643
316	100100	online	设备WebSocket连接建立	2026-06-28 09:46:56.400672
317	101001	online	设备WebSocket连接建立	2026-06-28 09:46:56.813596
318	101001	online	设备WebSocket连接建立	2026-06-28 09:46:58.435754
319	101001	online	设备WebSocket连接建立	2026-06-28 09:46:58.510667
320	100100	online	设备WebSocket连接建立	2026-06-28 09:46:58.59833
321	100100	online	设备WebSocket连接建立	2026-06-28 09:46:58.675923
322	100100	online	设备WebSocket连接建立	2026-06-28 09:54:08.61657
323	100100	online	设备WebSocket连接建立	2026-06-28 09:54:08.691367
324	101001	online	设备WebSocket连接建立	2026-06-28 09:54:08.765725
325	101001	online	设备WebSocket连接建立	2026-06-28 09:54:08.842151
326	100100	online	设备WebSocket连接建立	2026-06-28 09:58:21.045436
327	100100	online	设备WebSocket连接建立	2026-06-28 09:58:21.125017
328	101001	online	设备WebSocket连接建立	2026-06-28 09:58:21.377412
329	101001	online	设备WebSocket连接建立	2026-06-28 09:58:21.448749
330	101001	offline	设备WebSocket断开连接	2026-06-28 09:59:23.536344
331	101001	online	设备WebSocket连接建立	2026-06-28 09:59:29.724462
332	101001	online	设备WebSocket连接建立	2026-06-28 09:59:29.797251
333	101001	online	设备WebSocket连接建立	2026-06-28 10:00:27.243184
334	101001	online	设备WebSocket连接建立	2026-06-28 10:00:27.37371
335	100100	online	设备WebSocket连接建立	2026-06-28 10:00:28.616599
336	100100	online	设备WebSocket连接建立	2026-06-28 10:00:28.690169
337	101001	online	设备WebSocket连接建立	2026-06-28 10:11:55.660741
338	101001	online	设备WebSocket连接建立	2026-06-28 10:11:55.737363
339	100100	online	设备WebSocket连接建立	2026-06-28 10:24:55.659881
340	100100	online	设备WebSocket连接建立	2026-06-28 10:24:55.746867
341	100100	online	设备WebSocket连接建立	2026-06-28 10:25:53.232666
342	100100	online	设备WebSocket连接建立	2026-06-28 10:25:53.31183
343	100100	online	设备WebSocket连接建立	2026-06-28 10:26:13.207212
344	100100	online	设备WebSocket连接建立	2026-06-28 10:26:13.334595
345	100100	online	设备WebSocket连接建立	2026-06-28 10:30:04.918939
346	100100	online	设备WebSocket连接建立	2026-06-28 10:30:04.992961
347	100100	online	设备WebSocket连接建立	2026-06-28 10:31:07.299956
348	100100	online	设备WebSocket连接建立	2026-06-28 10:31:07.379765
349	100100	online	设备WebSocket连接建立	2026-06-28 10:32:11.442108
350	100100	online	设备WebSocket连接建立	2026-06-28 10:32:11.513963
351	100100	online	设备WebSocket连接建立	2026-06-28 10:33:49.906469
352	100100	online	设备WebSocket连接建立	2026-06-28 10:33:49.981176
353	100100	online	设备WebSocket连接建立	2026-06-28 10:36:37.944518
354	100100	online	设备WebSocket连接建立	2026-06-28 10:36:38.023341
355	100100	online	设备WebSocket连接建立	2026-06-28 10:45:36.230657
356	100100	online	设备WebSocket连接建立	2026-06-28 10:45:36.306648
357	101001	online	设备WebSocket连接建立	2026-06-28 10:46:39.387683
358	101001	online	设备WebSocket连接建立	2026-06-28 10:46:39.466899
359	100100	online	设备WebSocket连接建立	2026-06-28 10:46:51.472946
360	100100	online	设备WebSocket连接建立	2026-06-28 10:46:51.551371
361	101001	online	设备WebSocket连接建立	2026-06-28 10:46:57.548618
362	101001	online	设备WebSocket连接建立	2026-06-28 10:46:57.625684
363	101001	online	设备WebSocket连接建立	2026-06-28 10:49:32.423338
364	101001	online	设备WebSocket连接建立	2026-06-28 10:49:32.496951
365	100100	online	设备WebSocket连接建立	2026-06-28 10:49:32.5761
366	100100	online	设备WebSocket连接建立	2026-06-28 10:49:32.649764
367	101001	online	设备WebSocket连接建立	2026-06-28 10:52:47.881645
368	101001	online	设备WebSocket连接建立	2026-06-28 10:52:47.957805
369	100100	online	设备WebSocket连接建立	2026-06-28 10:52:48.032281
370	100100	online	设备WebSocket连接建立	2026-06-28 10:52:48.102681
371	101001	online	设备WebSocket连接建立	2026-06-28 10:57:11.677465
372	101001	online	设备WebSocket连接建立	2026-06-28 10:57:11.75066
373	100100	online	设备WebSocket连接建立	2026-06-28 10:57:11.827057
374	100100	online	设备WebSocket连接建立	2026-06-28 10:57:11.900432
375	101001	online	设备WebSocket连接建立	2026-06-28 11:02:59.621399
376	101001	online	设备WebSocket连接建立	2026-06-28 11:02:59.699243
377	100100	online	设备WebSocket连接建立	2026-06-28 11:02:59.77276
378	100100	online	设备WebSocket连接建立	2026-06-28 11:02:59.847471
379	101001	online	设备WebSocket连接建立	2026-06-28 11:08:09.248403
380	101001	online	设备WebSocket连接建立	2026-06-28 11:08:09.324632
381	100100	online	设备WebSocket连接建立	2026-06-28 11:08:12.646165
382	100100	online	设备WebSocket连接建立	2026-06-28 11:08:12.732252
383	101001	online	设备WebSocket连接建立	2026-06-28 11:11:16.983144
384	101001	online	设备WebSocket连接建立	2026-06-28 11:11:17.057459
385	100100	online	设备WebSocket连接建立	2026-06-28 11:11:17.129305
386	100100	online	设备WebSocket连接建立	2026-06-28 11:11:17.613241
387	101001	online	设备WebSocket连接建立	2026-06-28 11:18:27.391106
388	101001	online	设备WebSocket连接建立	2026-06-28 11:18:27.47106
389	100100	online	设备WebSocket连接建立	2026-06-28 11:18:27.554515
390	100100	online	设备WebSocket连接建立	2026-06-28 11:18:27.636248
391	101001	online	设备WebSocket连接建立	2026-06-28 11:21:17.473515
392	101001	online	设备WebSocket连接建立	2026-06-28 11:21:17.553482
393	100100	online	设备WebSocket连接建立	2026-06-28 11:21:18.079565
394	100100	online	设备WebSocket连接建立	2026-06-28 11:21:18.156376
395	101001	offline	设备WebSocket断开连接	2026-06-28 11:24:05.937565
396	101001	online	设备WebSocket连接建立	2026-06-28 11:24:11.561293
397	101001	online	设备WebSocket连接建立	2026-06-28 11:24:11.636609
398	100100	online	设备WebSocket连接建立	2026-06-28 11:25:29.975978
399	100100	online	设备WebSocket连接建立	2026-06-28 11:25:30.050892
400	101001	online	设备WebSocket连接建立	2026-06-28 11:25:30.126676
401	101001	online	设备WebSocket连接建立	2026-06-28 11:25:30.201957
402	101001	online	设备WebSocket连接建立	2026-06-28 11:29:38.76954
403	101001	online	设备WebSocket连接建立	2026-06-28 11:29:38.849282
404	100100	online	设备WebSocket连接建立	2026-06-28 11:29:38.922173
405	100100	online	设备WebSocket连接建立	2026-06-28 11:29:38.996908
406	101001	offline	设备WebSocket断开连接	2026-06-28 11:30:41.192788
407	101001	online	设备WebSocket连接建立	2026-06-28 11:30:46.800064
408	101001	online	设备WebSocket连接建立	2026-06-28 11:30:46.87462
409	101001	offline	设备WebSocket断开连接	2026-06-28 11:31:08.209473
410	101001	online	设备WebSocket连接建立	2026-06-28 11:31:13.79887
411	101001	online	设备WebSocket连接建立	2026-06-28 11:31:13.88008
412	100100	online	设备WebSocket连接建立	2026-06-28 11:35:12.432911
413	100100	online	设备WebSocket连接建立	2026-06-28 11:35:12.51557
414	101001	online	设备WebSocket连接建立	2026-06-28 11:35:12.595358
415	101001	online	设备WebSocket连接建立	2026-06-28 11:35:12.676136
416	101001	online	设备WebSocket连接建立	2026-06-28 11:56:47.685729
417	101001	online	设备WebSocket连接建立	2026-06-28 11:56:47.76112
418	100100	online	设备WebSocket连接建立	2026-06-28 11:56:47.837351
419	100100	online	设备WebSocket连接建立	2026-06-28 11:56:47.917697
420	101001	online	设备WebSocket连接建立	2026-06-28 14:09:28.14474
421	101001	online	设备WebSocket连接建立	2026-06-28 14:09:28.232844
422	100100	online	设备WebSocket连接建立	2026-06-28 14:09:28.337348
423	100100	online	设备WebSocket连接建立	2026-06-28 14:09:28.415029
424	101001	online	设备WebSocket连接建立	2026-06-28 14:12:48.92152
425	101001	online	设备WebSocket连接建立	2026-06-28 14:12:49.004553
426	100100	online	设备WebSocket连接建立	2026-06-28 14:12:49.07869
427	100100	online	设备WebSocket连接建立	2026-06-28 14:12:49.157814
428	101001	online	设备WebSocket连接建立	2026-06-28 14:15:53.72697
429	101001	online	设备WebSocket连接建立	2026-06-28 14:15:53.803687
430	100100	online	设备WebSocket连接建立	2026-06-28 14:15:53.905672
431	100100	online	设备WebSocket连接建立	2026-06-28 14:15:53.977688
432	101001	online	设备WebSocket连接建立	2026-06-28 14:57:51.847093
433	101001	online	设备WebSocket连接建立	2026-06-28 14:57:51.923417
434	100100	online	设备WebSocket连接建立	2026-06-28 14:57:52.000825
435	100100	online	设备WebSocket连接建立	2026-06-28 14:57:52.077506
436	101001	online	设备WebSocket连接建立	2026-06-28 15:12:04.5064
437	101001	online	设备WebSocket连接建立	2026-06-28 15:12:04.587768
438	100100	online	设备WebSocket连接建立	2026-06-28 15:12:04.661028
439	100100	online	设备WebSocket连接建立	2026-06-28 15:12:04.73306
440	101001	online	设备WebSocket连接建立	2026-06-28 15:17:25.616885
441	101001	online	设备WebSocket连接建立	2026-06-28 15:17:25.688353
442	100100	online	设备WebSocket连接建立	2026-06-28 15:17:25.767363
443	100100	online	设备WebSocket连接建立	2026-06-28 15:17:25.83967
444	101001	online	设备WebSocket连接建立	2026-06-28 15:18:36.589757
445	101001	online	设备WebSocket连接建立	2026-06-28 15:18:36.66229
446	100100	online	设备WebSocket连接建立	2026-06-28 15:18:36.736551
447	100100	online	设备WebSocket连接建立	2026-06-28 15:18:36.808536
448	101001	online	设备WebSocket连接建立	2026-06-28 15:19:41.561538
449	101001	online	设备WebSocket连接建立	2026-06-28 15:19:41.636303
450	100100	online	设备WebSocket连接建立	2026-06-28 15:19:41.711351
451	100100	online	设备WebSocket连接建立	2026-06-28 15:19:41.790171
452	101001	online	设备WebSocket连接建立	2026-06-28 15:32:07.032841
453	101001	online	设备WebSocket连接建立	2026-06-28 15:32:07.105902
454	100100	online	设备WebSocket连接建立	2026-06-28 15:32:07.179018
455	100100	online	设备WebSocket连接建立	2026-06-28 15:32:07.254473
456	100100	online	设备WebSocket连接建立	2026-06-28 15:33:40.624062
457	100100	online	设备WebSocket连接建立	2026-06-28 15:33:40.701234
458	101001	online	设备WebSocket连接建立	2026-06-28 15:33:40.777116
459	101001	online	设备WebSocket连接建立	2026-06-28 15:33:40.860039
460	101001	online	设备WebSocket连接建立	2026-06-28 15:40:48.096653
461	101001	online	设备WebSocket连接建立	2026-06-28 15:40:48.18171
462	100100	online	设备WebSocket连接建立	2026-06-28 15:40:48.258176
463	100100	online	设备WebSocket连接建立	2026-06-28 15:40:48.339034
464	101001	online	设备WebSocket连接建立	2026-06-28 15:47:53.989944
465	101001	online	设备WebSocket连接建立	2026-06-28 15:47:54.064171
466	100100	online	设备WebSocket连接建立	2026-06-28 15:47:54.215415
467	100100	online	设备WebSocket连接建立	2026-06-28 15:47:54.287458
468	101001	online	设备WebSocket连接建立	2026-06-28 15:49:36.077638
469	101001	online	设备WebSocket连接建立	2026-06-28 15:49:36.157515
470	100100	online	设备WebSocket连接建立	2026-06-28 15:49:36.246214
471	100100	online	设备WebSocket连接建立	2026-06-28 15:49:36.321335
472	101001	online	设备WebSocket连接建立	2026-06-28 16:13:56.801122
473	101001	online	设备WebSocket连接建立	2026-06-28 16:13:56.876771
474	100100	online	设备WebSocket连接建立	2026-06-28 16:13:58.873315
475	100100	online	设备WebSocket连接建立	2026-06-28 16:13:58.948305
476	101001	online	设备WebSocket连接建立	2026-06-28 16:17:22.927872
477	101001	online	设备WebSocket连接建立	2026-06-28 16:17:23.005092
478	100100	online	设备WebSocket连接建立	2026-06-28 16:17:23.079771
479	100100	online	设备WebSocket连接建立	2026-06-28 16:17:23.153539
480	101001	online	设备WebSocket连接建立	2026-06-28 16:18:40.242225
481	101001	online	设备WebSocket连接建立	2026-06-28 16:18:40.318412
482	100100	online	设备WebSocket连接建立	2026-06-28 16:18:40.391405
483	100100	online	设备WebSocket连接建立	2026-06-28 16:18:40.465292
484	100100	online	设备WebSocket连接建立	2026-06-28 16:21:14.771243
485	100100	online	设备WebSocket连接建立	2026-06-28 16:21:14.853886
486	101001	online	设备WebSocket连接建立	2026-06-28 16:21:14.943235
487	101001	online	设备WebSocket连接建立	2026-06-28 16:21:15.023747
488	101001	online	设备WebSocket连接建立	2026-06-28 17:33:30.812488
489	101001	online	设备WebSocket连接建立	2026-06-28 17:33:30.890266
490	100100	online	设备WebSocket连接建立	2026-06-28 17:33:30.966689
491	100100	online	设备WebSocket连接建立	2026-06-28 17:33:31.039333
492	101001	online	设备WebSocket连接建立	2026-06-28 17:43:19.194823
493	101001	online	设备WebSocket连接建立	2026-06-28 17:43:19.27045
494	100100	online	设备WebSocket连接建立	2026-06-28 17:43:19.350172
495	100100	online	设备WebSocket连接建立	2026-06-28 17:43:19.42447
496	101001	online	设备WebSocket连接建立	2026-06-28 17:56:22.600341
497	101001	online	设备WebSocket连接建立	2026-06-28 17:56:22.68653
498	100100	online	设备WebSocket连接建立	2026-06-28 17:56:22.761796
499	100100	online	设备WebSocket连接建立	2026-06-28 17:56:22.837774
500	101001	online	设备WebSocket连接建立	2026-06-28 18:33:03.823587
501	101001	online	设备WebSocket连接建立	2026-06-28 18:33:03.898838
502	100100	online	设备WebSocket连接建立	2026-06-28 18:33:04.104593
503	100100	online	设备WebSocket连接建立	2026-06-28 18:33:04.183079
504	100100	offline	设备WebSocket断开连接	2026-06-28 21:31:44.109363
505	101001	online	设备WebSocket连接建立	2026-06-28 22:01:50.274874
506	101001	online	设备WebSocket连接建立	2026-06-28 22:01:50.358863
507	101001	online	设备WebSocket连接建立	2026-06-28 22:02:56.265399
508	101001	online	设备WebSocket连接建立	2026-06-28 22:02:56.344595
509	101001	online	设备WebSocket连接建立	2026-06-28 22:05:55.148062
510	101001	online	设备WebSocket连接建立	2026-06-28 22:05:55.222338
511	101001	online	设备WebSocket连接建立	2026-06-28 22:13:46.421457
512	101001	online	设备WebSocket连接建立	2026-06-28 22:13:46.499118
513	101001	online	设备WebSocket连接建立	2026-06-28 22:16:07.819306
514	101001	online	设备WebSocket连接建立	2026-06-28 22:16:07.9009
515	101001	online	设备WebSocket连接建立	2026-06-28 22:17:01.59514
516	101001	online	设备WebSocket连接建立	2026-06-28 22:17:01.670579
517	101001	online	设备WebSocket连接建立	2026-06-28 22:17:41.454191
518	101001	online	设备WebSocket连接建立	2026-06-28 22:17:41.534251
519	101001	online	设备WebSocket连接建立	2026-06-28 22:19:35.728056
520	101001	online	设备WebSocket连接建立	2026-06-28 22:19:36.04962
521	101001	online	设备WebSocket连接建立	2026-06-28 22:20:58.5266
522	101001	online	设备WebSocket连接建立	2026-06-28 22:20:58.602361
523	101001	online	设备WebSocket连接建立	2026-06-28 22:21:51.006989
524	101001	online	设备WebSocket连接建立	2026-06-28 22:21:51.086445
525	101001	online	设备WebSocket连接建立	2026-06-28 22:30:00.587063
526	101001	online	设备WebSocket连接建立	2026-06-28 22:30:00.665369
527	101001	online	设备WebSocket连接建立	2026-06-28 22:30:58.467217
528	101001	online	设备WebSocket连接建立	2026-06-28 22:30:58.546033
529	101001	online	设备WebSocket连接建立	2026-06-28 22:31:38.649664
530	101001	online	设备WebSocket连接建立	2026-06-28 22:31:38.727012
531	101001	online	设备WebSocket连接建立	2026-06-28 22:35:24.442275
532	101001	online	设备WebSocket连接建立	2026-06-28 22:35:24.521633
533	101001	online	设备WebSocket连接建立	2026-06-28 22:47:46.164989
534	101001	online	设备WebSocket连接建立	2026-06-28 22:47:46.239738
535	101001	online	设备WebSocket连接建立	2026-06-28 23:18:23.283893
536	101001	online	设备WebSocket连接建立	2026-06-28 23:18:23.361629
537	101001	online	设备WebSocket连接建立	2026-06-28 23:28:35.636577
538	101001	online	设备WebSocket连接建立	2026-06-28 23:28:35.715673
539	101001	online	设备WebSocket连接建立	2026-06-29 07:09:24.669252
540	101001	online	设备WebSocket连接建立	2026-06-29 07:09:24.743899
541	101001	online	设备WebSocket连接建立	2026-06-29 07:17:11.608062
542	101001	online	设备WebSocket连接建立	2026-06-29 07:17:11.683907
543	101001	online	设备WebSocket连接建立	2026-06-29 07:24:52.642146
544	101001	online	设备WebSocket连接建立	2026-06-29 07:24:52.722962
545	101001	online	设备WebSocket连接建立	2026-06-29 07:29:21.609725
546	101001	online	设备WebSocket连接建立	2026-06-29 07:29:21.69347
547	101001	online	设备WebSocket连接建立	2026-06-29 07:33:59.920959
548	101001	online	设备WebSocket连接建立	2026-06-29 07:33:59.997623
549	101001	online	设备WebSocket连接建立	2026-06-29 07:46:04.820231
550	101001	online	设备WebSocket连接建立	2026-06-29 07:46:04.898989
551	101001	online	设备WebSocket连接建立	2026-06-29 07:47:56.297615
552	101001	online	设备WebSocket连接建立	2026-06-29 07:47:56.373918
553	101001	online	设备WebSocket连接建立	2026-06-29 07:49:27.002582
554	101001	online	设备WebSocket连接建立	2026-06-29 07:49:27.077585
555	101001	online	设备WebSocket连接建立	2026-06-29 07:52:08.116199
556	101001	online	设备WebSocket连接建立	2026-06-29 07:52:08.191298
557	101001	online	设备WebSocket连接建立	2026-06-29 07:53:54.245536
558	101001	online	设备WebSocket连接建立	2026-06-29 07:53:54.319574
559	101001	online	设备WebSocket连接建立	2026-06-29 07:54:34.512035
560	101001	online	设备WebSocket连接建立	2026-06-29 07:54:34.590814
561	101001	online	设备WebSocket连接建立	2026-06-29 07:56:26.392697
562	101001	online	设备WebSocket连接建立	2026-06-29 07:56:26.464974
563	101001	online	设备WebSocket连接建立	2026-06-29 07:57:35.066428
564	101001	online	设备WebSocket连接建立	2026-06-29 07:57:35.14468
565	100100	online	设备WebSocket连接建立	2026-06-29 12:35:36.79388
566	100100	offline	设备WebSocket断开连接	2026-06-29 14:21:20.597128
567	100100	online	设备WebSocket连接建立	2026-06-29 14:26:16.530661
568	100100	offline	设备WebSocket断开连接	2026-06-29 14:35:48.465815
569	100100	online	设备WebSocket连接建立	2026-06-29 14:35:54.216333
570	100100	offline	设备WebSocket断开连接	2026-06-29 15:03:17.050167
571	100100	online	设备WebSocket连接建立	2026-06-29 15:03:23.176682
\.


--
-- Data for Name: device_logs; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.device_logs (id, device_id, logs, create_time, log_type, content, level, detail, device_name, status) FROM stdin;
1	TEST_DEVICE_001	["heartbeat", "温度正常"]	2026-06-17 08:34:11	heartbeat	["heartbeat", "温度正常"]	info	\N	\N	\N
2	TEST_DEVICE_001	["heartbeat"]	2026-06-17 09:18:20	heartbeat	["heartbeat"]	info	\N	\N	\N
3	TEST_DEVICE_001	["heartbeat"]	2026-06-17 09:19:09	heartbeat	["heartbeat"]	info	\N	\N	\N
4	DEV001	["hb"]	2026-06-17 09:20:53	heartbeat	["hb"]	info	\N	\N	\N
5	123456	["test"]	2026-06-17 20:39:30	info	["test"]	info	\N	智能寄存柜	\N
6	123456	["test"]	2026-06-17 20:41:58	info	["test"]	info	\N	智能寄存柜	\N
7	123456	"test log"	2026-06-17 21:04:11	info	"test log"	info	\N	智能寄存柜	\N
8	123456	"test log"	2026-06-17 21:05:17	info	"test log"	info	\N	智能寄存柜	\N
9	123456	"test"	2026-06-17 21:07:59	info	"test"	info	\N	智能寄存柜	\N
10	123456	\N	2026-06-23 09:05:44	online	设备WebSocket连接建立	info	\N	\N	\N
11	123456	\N	2026-06-23 09:07:55	online	设备WebSocket连接建立	info	\N	\N	\N
12	123456	\N	2026-06-23 09:49:53	online	设备WebSocket连接建立	info	\N	\N	\N
13	123456	\N	2026-06-23 09:50:58	online	设备WebSocket连接建立	info	\N	\N	\N
14	123456	\N	2026-06-23 09:51:06	online	设备WebSocket连接建立	info	\N	\N	\N
15	123456	\N	2026-06-23 09:51:41	online	设备WebSocket连接建立	info	\N	\N	\N
16	123456	\N	2026-06-23 10:03:15	online	设备WebSocket连接建立	info	\N	\N	\N
17	123456	\N	2026-06-23 10:07:12	online	设备WebSocket连接建立	info	\N	\N	\N
18	123456	\N	2026-06-23 10:11:25	online	设备WebSocket连接建立	info	\N	\N	\N
19	123456	\N	2026-06-23 10:51:47	online	设备WebSocket连接建立	info	\N	\N	\N
20	123456	\N	2026-06-23 10:57:05	online	设备WebSocket连接建立	info	\N	\N	\N
21	123456	\N	2026-06-23 11:08:49	online	设备WebSocket连接建立	info	\N	\N	\N
22	123456	\N	2026-06-23 11:29:42	online	设备WebSocket连接建立	info	\N	\N	\N
23	123456	\N	2026-06-23 11:31:32	online	设备WebSocket连接建立	info	\N	\N	\N
24	123456	\N	2026-06-23 11:32:07	online	设备WebSocket连接建立	info	\N	\N	\N
25	123456	\N	2026-06-23 11:35:30	online	设备WebSocket连接建立	info	\N	\N	\N
26	123456	\N	2026-06-23 11:38:20	online	设备WebSocket连接建立	info	\N	\N	\N
27	123456	\N	2026-06-23 11:55:10	online	设备WebSocket连接建立	info	\N	\N	\N
28	123456	\N	2026-06-23 12:03:43	online	设备WebSocket连接建立	info	\N	\N	\N
29	123456	\N	2026-06-23 12:28:04	online	设备WebSocket连接建立	info	\N	\N	\N
30	123456	\N	2026-06-23 12:57:49	online	设备WebSocket连接建立	info	\N	\N	\N
31	123456	\N	2026-06-23 13:41:26	online	设备WebSocket连接建立	info	\N	\N	\N
32	123456	\N	2026-06-23 14:39:40	online	设备WebSocket连接建立	info	\N	\N	\N
33	123456	\N	2026-06-23 15:06:21	online	设备WebSocket连接建立	info	\N	\N	\N
34	123456	\N	2026-06-23 15:16:49	online	设备WebSocket连接建立	info	\N	\N	\N
35	123456	\N	2026-06-23 15:44:35	online	设备WebSocket连接建立	info	\N	\N	\N
36	123456	\N	2026-06-23 15:55:15	online	设备WebSocket连接建立	info	\N	\N	\N
37	123456	\N	2026-06-23 15:55:54	online	设备WebSocket连接建立	info	\N	\N	\N
38	123456	\N	2026-06-23 16:11:29	online	设备WebSocket连接建立	info	\N	\N	\N
39	123456	\N	2026-06-23 16:33:33	online	设备WebSocket连接建立	info	\N	\N	\N
40	123456	\N	2026-06-23 17:12:21	online	设备WebSocket连接建立	info	\N	\N	\N
41	123456	\N	2026-06-23 23:04:59	online	设备WebSocket连接建立	info	\N	\N	\N
42	123456	\N	2026-06-23 23:20:49	online	设备WebSocket连接建立	info	\N	\N	\N
43	123456	\N	2026-06-23 23:22:15	online	设备WebSocket连接建立	info	\N	\N	\N
44	123456	\N	2026-06-23 23:23:27	online	设备WebSocket连接建立	info	\N	\N	\N
45	123456	\N	2026-06-23 23:42:25	online	设备WebSocket连接建立	info	\N	\N	\N
46	123456	\N	2026-06-24 00:26:18	online	设备WebSocket连接建立	info	\N	\N	\N
47	123456	\N	2026-06-24 00:47:20	online	设备WebSocket连接建立	info	\N	\N	\N
48	123456	\N	2026-06-24 00:52:06	online	设备WebSocket连接建立	info	\N	\N	\N
49	123456	\N	2026-06-24 01:13:53	online	设备WebSocket连接建立	info	\N	\N	\N
50	123456	\N	2026-06-24 01:32:09	online	设备WebSocket连接建立	info	\N	\N	\N
51	123456	\N	2026-06-24 01:46:25	online	设备WebSocket连接建立	info	\N	\N	\N
52	123456	\N	2026-06-24 01:49:16	offline	设备WebSocket断开连接	warning	\N	\N	\N
53	123456	\N	2026-06-24 01:49:33	online	设备WebSocket连接建立	info	\N	\N	\N
54	123456	\N	2026-06-24 01:50:28	offline	设备WebSocket断开连接	warning	\N	\N	\N
55	123456	\N	2026-06-24 01:50:31	online	设备WebSocket连接建立	info	\N	\N	\N
56	123456	\N	2026-06-24 01:55:57	online	设备WebSocket连接建立	info	\N	\N	\N
57	123456	\N	2026-06-24 01:58:57	offline	设备WebSocket断开连接	warning	\N	\N	\N
58	123456	\N	2026-06-24 01:59:16	online	设备WebSocket连接建立	info	\N	\N	\N
59	123456	\N	2026-06-24 02:08:47	offline	设备WebSocket断开连接	warning	\N	\N	\N
60	123456	\N	2026-06-24 02:09:17	online	设备WebSocket连接建立	info	\N	\N	\N
61	123456	\N	2026-06-24 02:14:26	online	设备WebSocket连接建立	info	\N	\N	\N
62	123456	\N	2026-06-24 02:19:28	online	设备WebSocket连接建立	info	\N	\N	\N
63	123456	\N	2026-06-24 02:20:35	online	设备WebSocket连接建立	info	\N	\N	\N
64	123456	\N	2026-06-24 02:24:40	online	设备WebSocket连接建立	info	\N	\N	\N
65	123456	\N	2026-06-24 02:26:09	offline	设备WebSocket断开连接	warning	\N	\N	\N
66	123456	\N	2026-06-24 02:26:09	online	设备WebSocket连接建立	info	\N	\N	\N
67	123456	\N	2026-06-24 02:26:09	online	设备WebSocket连接建立	info	\N	\N	\N
68	123456	\N	2026-06-24 02:26:11	online	设备WebSocket连接建立	info	\N	\N	\N
69	123456	\N	2026-06-24 02:26:12	online	设备WebSocket连接建立	info	\N	\N	\N
70	123456	\N	2026-06-24 02:28:18	offline	设备WebSocket断开连接	warning	\N	\N	\N
71	123456	\N	2026-06-24 02:28:20	online	设备WebSocket连接建立	info	\N	\N	\N
72	123456	\N	2026-06-24 02:34:36	online	设备WebSocket连接建立	info	\N	\N	\N
73	123456	\N	2026-06-24 02:49:26	online	设备WebSocket连接建立	info	\N	\N	\N
74	123456	\N	2026-06-24 02:54:05	online	设备WebSocket连接建立	info	\N	\N	\N
75	123456	\N	2026-06-24 03:09:06	online	设备WebSocket连接建立	info	\N	\N	\N
76	123456	\N	2026-06-24 03:12:18	online	设备WebSocket连接建立	info	\N	\N	\N
77	123456	\N	2026-06-24 03:17:40	online	设备WebSocket连接建立	info	\N	\N	\N
78	123456	\N	2026-06-24 03:21:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
79	123456	\N	2026-06-24 03:21:38	online	设备WebSocket连接建立	info	\N	\N	\N
80	123456	\N	2026-06-24 03:22:21	online	设备WebSocket连接建立	info	\N	\N	\N
81	123456	\N	2026-06-24 03:40:41	online	设备WebSocket连接建立	info	\N	\N	\N
82	123456	\N	2026-06-24 03:42:20	offline	设备WebSocket断开连接	warning	\N	\N	\N
83	123456	\N	2026-06-24 03:42:26	online	设备WebSocket连接建立	info	\N	\N	\N
84	123456	\N	2026-06-24 03:45:03	offline	设备WebSocket断开连接	warning	\N	\N	\N
85	123456	\N	2026-06-24 03:45:04	online	设备WebSocket连接建立	info	\N	\N	\N
86	123456	\N	2026-06-24 03:45:04	online	设备WebSocket连接建立	info	\N	\N	\N
87	123456	\N	2026-06-24 03:45:05	online	设备WebSocket连接建立	info	\N	\N	\N
88	123456	\N	2026-06-24 03:45:07	online	设备WebSocket连接建立	info	\N	\N	\N
89	123456	\N	2026-06-24 03:45:08	online	设备WebSocket连接建立	info	\N	\N	\N
90	123456	\N	2026-06-24 03:47:04	offline	设备WebSocket断开连接	warning	\N	\N	\N
91	123456	\N	2026-06-24 03:47:05	online	设备WebSocket连接建立	info	\N	\N	\N
92	123456	\N	2026-06-24 03:51:41	online	设备WebSocket连接建立	info	\N	\N	\N
93	123456	\N	2026-06-24 03:53:32	online	设备WebSocket连接建立	info	\N	\N	\N
94	123456	\N	2026-06-24 03:55:06	online	设备WebSocket连接建立	info	\N	\N	\N
95	123456	\N	2026-06-24 03:55:40	online	设备WebSocket连接建立	info	\N	\N	\N
96	123456	\N	2026-06-24 04:14:03	online	设备WebSocket连接建立	info	\N	\N	\N
97	123456	\N	2026-06-24 04:23:21	offline	设备WebSocket断开连接	warning	\N	\N	\N
98	123456	\N	2026-06-24 04:23:27	online	设备WebSocket连接建立	info	\N	\N	\N
99	123456	\N	2026-06-24 04:24:12	online	设备WebSocket连接建立	info	\N	\N	\N
100	123456	\N	2026-06-24 04:25:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
101	123456	\N	2026-06-24 04:25:30	online	设备WebSocket连接建立	info	\N	\N	\N
102	123456	\N	2026-06-24 04:39:41	online	设备WebSocket连接建立	info	\N	\N	\N
103	123456	\N	2026-06-24 04:51:31	online	设备WebSocket连接建立	info	\N	\N	\N
104	123456	\N	2026-06-24 04:53:00	online	设备WebSocket连接建立	info	\N	\N	\N
105	123456	\N	2026-06-24 04:56:27	offline	设备WebSocket断开连接	warning	\N	\N	\N
106	123456	\N	2026-06-24 04:56:38	online	设备WebSocket连接建立	info	\N	\N	\N
107	123456	\N	2026-06-24 04:56:47	offline	设备WebSocket断开连接	warning	\N	\N	\N
108	123456	\N	2026-06-24 04:56:56	online	设备WebSocket连接建立	info	\N	\N	\N
109	123456	\N	2026-06-24 05:55:58	online	设备WebSocket连接建立	info	\N	\N	\N
110	123456	\N	2026-06-24 05:58:16	online	设备WebSocket连接建立	info	\N	\N	\N
111	123456	\N	2026-06-24 06:10:44	online	设备WebSocket连接建立	info	\N	\N	\N
112	123456	\N	2026-06-24 06:29:38	online	设备WebSocket连接建立	info	\N	\N	\N
113	123456	\N	2026-06-24 06:34:44	offline	设备WebSocket断开连接	warning	\N	\N	\N
114	123456	\N	2026-06-24 06:34:45	online	设备WebSocket连接建立	info	\N	\N	\N
115	123456	\N	2026-06-24 06:34:45	online	设备WebSocket连接建立	info	\N	\N	\N
116	123456	\N	2026-06-24 06:34:57	offline	设备WebSocket断开连接	warning	\N	\N	\N
117	123456	\N	2026-06-24 06:34:58	online	设备WebSocket连接建立	info	\N	\N	\N
118	123456	\N	2026-06-24 06:41:37	online	设备WebSocket连接建立	info	\N	\N	\N
119	123456	\N	2026-06-24 07:14:13	online	设备WebSocket连接建立	info	\N	\N	\N
120	123456	\N	2026-06-24 07:16:27	online	设备WebSocket连接建立	info	\N	\N	\N
121	123456	\N	2026-06-24 07:20:05	online	设备WebSocket连接建立	info	\N	\N	\N
122	123456	\N	2026-06-24 07:30:28	online	设备WebSocket连接建立	info	\N	\N	\N
123	123456	\N	2026-06-24 07:31:14	offline	设备WebSocket断开连接	warning	\N	\N	\N
124	123456	\N	2026-06-24 07:31:20	online	设备WebSocket连接建立	info	\N	\N	\N
125	123456	\N	2026-06-24 07:31:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
126	123456	\N	2026-06-24 07:31:39	online	设备WebSocket连接建立	info	\N	\N	\N
127	123456	\N	2026-06-24 07:36:53	online	设备WebSocket连接建立	info	\N	\N	\N
128	123456	\N	2026-06-24 07:37:08	offline	设备WebSocket断开连接	warning	\N	\N	\N
129	123456	\N	2026-06-24 07:37:17	online	设备WebSocket连接建立	info	\N	\N	\N
130	123456	\N	2026-06-24 07:37:38	offline	设备WebSocket断开连接	warning	\N	\N	\N
131	123456	\N	2026-06-24 08:32:10	online	设备WebSocket连接建立	info	\N	\N	\N
132	123456	\N	2026-06-24 08:55:33	offline	设备WebSocket断开连接	warning	\N	\N	\N
133	123456	\N	2026-06-24 08:56:12	online	设备WebSocket连接建立	info	\N	\N	\N
134	123456	\N	2026-06-24 08:56:23	offline	设备WebSocket断开连接	warning	\N	\N	\N
135	123456	\N	2026-06-24 08:56:23	online	设备WebSocket连接建立	info	\N	\N	\N
136	123456	\N	2026-06-24 08:56:23	online	设备WebSocket连接建立	info	\N	\N	\N
137	123456	\N	2026-06-24 08:56:31	offline	设备WebSocket断开连接	warning	\N	\N	\N
138	123456	\N	2026-06-24 08:56:32	online	设备WebSocket连接建立	info	\N	\N	\N
139	123456	\N	2026-06-24 09:09:45	offline	设备WebSocket断开连接	warning	\N	\N	\N
140	123456	\N	2026-06-24 09:09:46	online	设备WebSocket连接建立	info	\N	\N	\N
141	123456	\N	2026-06-24 09:09:46	online	设备WebSocket连接建立	info	\N	\N	\N
142	123456	\N	2026-06-24 09:09:47	online	设备WebSocket连接建立	info	\N	\N	\N
143	123456	\N	2026-06-24 09:09:49	online	设备WebSocket连接建立	info	\N	\N	\N
144	123456	\N	2026-06-24 09:09:50	online	设备WebSocket连接建立	info	\N	\N	\N
145	123456	\N	2026-06-24 09:09:51	online	设备WebSocket连接建立	info	\N	\N	\N
146	123456	\N	2026-06-24 09:09:53	online	设备WebSocket连接建立	info	\N	\N	\N
147	123456	\N	2026-06-24 09:09:54	online	设备WebSocket连接建立	info	\N	\N	\N
148	123456	\N	2026-06-24 09:29:05	offline	设备WebSocket断开连接	warning	\N	\N	\N
149	123456	\N	2026-06-24 09:29:06	online	设备WebSocket连接建立	info	\N	\N	\N
150	123456	\N	2026-06-24 09:29:17	offline	设备WebSocket断开连接	warning	\N	\N	\N
151	123456	\N	2026-06-24 09:29:18	online	设备WebSocket连接建立	info	\N	\N	\N
152	123456	\N	2026-06-24 09:29:18	online	设备WebSocket连接建立	info	\N	\N	\N
153	123456	\N	2026-06-24 09:29:19	online	设备WebSocket连接建立	info	\N	\N	\N
154	123456	\N	2026-06-24 09:29:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
155	123456	\N	2026-06-24 09:29:26	online	设备WebSocket连接建立	info	\N	\N	\N
156	123456	\N	2026-06-24 09:32:39	offline	设备WebSocket断开连接	warning	\N	\N	\N
157	123456	\N	2026-06-24 09:32:40	online	设备WebSocket连接建立	info	\N	\N	\N
158	123456	\N	2026-06-24 09:32:40	online	设备WebSocket连接建立	info	\N	\N	\N
159	123456	\N	2026-06-24 09:32:41	online	设备WebSocket连接建立	info	\N	\N	\N
160	123456	\N	2026-06-24 09:32:42	online	设备WebSocket连接建立	info	\N	\N	\N
161	123456	\N	2026-06-24 09:32:43	online	设备WebSocket连接建立	info	\N	\N	\N
162	123456	\N	2026-06-24 09:32:58	offline	设备WebSocket断开连接	warning	\N	\N	\N
163	123456	\N	2026-06-24 09:32:59	online	设备WebSocket连接建立	info	\N	\N	\N
164	123456	\N	2026-06-24 09:38:16	online	设备WebSocket连接建立	info	\N	\N	\N
165	123456	\N	2026-06-24 09:38:45	offline	设备WebSocket断开连接	warning	\N	\N	\N
166	123456	\N	2026-06-24 09:38:46	online	设备WebSocket连接建立	info	\N	\N	\N
167	123456	\N	2026-06-24 09:38:46	online	设备WebSocket连接建立	info	\N	\N	\N
168	123456	\N	2026-06-24 09:38:47	online	设备WebSocket连接建立	info	\N	\N	\N
169	123456	\N	2026-06-24 09:38:49	online	设备WebSocket连接建立	info	\N	\N	\N
170	123456	\N	2026-06-24 09:40:13	online	设备WebSocket连接建立	info	\N	\N	\N
171	123456	\N	2026-06-24 09:51:25	online	设备WebSocket连接建立	info	\N	\N	\N
172	123456	\N	2026-06-24 09:51:45	online	设备WebSocket连接建立	info	\N	\N	\N
173	123456	\N	2026-06-24 09:53:51	online	设备WebSocket连接建立	info	\N	\N	\N
174	123456	\N	2026-06-24 09:55:19	online	设备WebSocket连接建立	info	\N	\N	\N
175	123456	\N	2026-06-24 10:01:30	online	设备WebSocket连接建立	info	\N	\N	\N
176	123456	\N	2026-06-24 10:05:54	online	设备WebSocket连接建立	info	\N	\N	\N
177	123456	\N	2026-06-24 10:14:44	online	设备WebSocket连接建立	info	\N	\N	\N
178	123456	\N	2026-06-24 10:28:19	online	设备WebSocket连接建立	info	\N	\N	\N
179	123456	\N	2026-06-24 10:32:26	online	设备WebSocket连接建立	info	\N	\N	\N
180	123456	\N	2026-06-24 10:34:09	online	设备WebSocket连接建立	info	\N	\N	\N
181	123456	\N	2026-06-24 10:35:29	online	设备WebSocket连接建立	info	\N	\N	\N
182	123456	\N	2026-06-24 11:39:13	offline	设备WebSocket断开连接	warning	\N	\N	\N
183	123456	\N	2026-06-24 12:05:23	online	设备WebSocket连接建立	info	\N	\N	\N
184	123456	\N	2026-06-24 12:07:39	online	设备WebSocket连接建立	info	\N	\N	\N
185	123456	\N	2026-06-24 12:15:45	online	设备WebSocket连接建立	info	\N	\N	\N
186	123456	\N	2026-06-24 12:19:37	offline	设备WebSocket断开连接	warning	\N	\N	\N
187	123456	\N	2026-06-24 12:19:39	online	设备WebSocket连接建立	info	\N	\N	\N
188	123456	\N	2026-06-24 14:22:44	online	设备WebSocket连接建立	info	\N	\N	\N
189	123456	\N	2026-06-24 14:30:17	online	设备WebSocket连接建立	info	\N	\N	\N
190	123456	\N	2026-06-24 14:39:13	online	设备WebSocket连接建立	info	\N	\N	\N
191	123456	\N	2026-06-24 14:44:41	online	设备WebSocket连接建立	info	\N	\N	\N
192	123456	\N	2026-06-24 15:04:18	online	设备WebSocket连接建立	info	\N	\N	\N
193	123456	\N	2026-06-24 15:19:32	online	设备WebSocket连接建立	info	\N	\N	\N
194	123456	\N	2026-06-24 15:35:42	online	设备WebSocket连接建立	info	\N	\N	\N
195	123456	\N	2026-06-24 15:52:31	offline	设备WebSocket断开连接	warning	\N	\N	\N
196	123456	\N	2026-06-24 15:52:32	online	设备WebSocket连接建立	info	\N	\N	\N
197	123456	\N	2026-06-24 16:07:28	offline	设备WebSocket断开连接	warning	\N	\N	\N
198	123456	\N	2026-06-24 16:07:30	online	设备WebSocket连接建立	info	\N	\N	\N
199	123456	\N	2026-06-24 16:15:40	offline	设备WebSocket断开连接	warning	\N	\N	\N
200	123456	\N	2026-06-24 16:15:42	online	设备WebSocket连接建立	info	\N	\N	\N
201	123456	\N	2026-06-24 16:17:17	offline	设备WebSocket断开连接	warning	\N	\N	\N
202	123456	\N	2026-06-24 16:17:19	online	设备WebSocket连接建立	info	\N	\N	\N
203	123456	\N	2026-06-24 16:25:50	offline	设备WebSocket断开连接	warning	\N	\N	\N
204	123456	\N	2026-06-24 16:25:52	online	设备WebSocket连接建立	info	\N	\N	\N
205	123456	\N	2026-06-24 16:31:05	online	设备WebSocket连接建立	info	\N	\N	\N
206	123456	\N	2026-06-24 16:31:17	online	设备WebSocket连接建立	info	\N	\N	\N
207	123456	\N	2026-06-24 22:42:17	offline	设备WebSocket断开连接	warning	\N	\N	\N
208	123456	\N	2026-06-24 22:42:18	online	设备WebSocket连接建立	info	\N	\N	\N
209	123456	\N	2026-06-24 23:03:11	offline	设备WebSocket断开连接	warning	\N	\N	\N
210	123456	\N	2026-06-24 23:03:13	online	设备WebSocket连接建立	info	\N	\N	\N
211	123456	\N	2026-06-25 00:22:02	offline	设备WebSocket断开连接	warning	\N	\N	\N
212	123456	\N	2026-06-25 00:22:04	online	设备WebSocket连接建立	info	\N	\N	\N
213	123456	\N	2026-06-25 00:23:21	offline	设备WebSocket断开连接	warning	\N	\N	\N
214	123456	\N	2026-06-25 00:23:22	online	设备WebSocket连接建立	info	\N	\N	\N
215	123456	\N	2026-06-25 00:24:12	offline	设备WebSocket断开连接	warning	\N	\N	\N
216	123456	\N	2026-06-25 00:24:14	online	设备WebSocket连接建立	info	\N	\N	\N
217	123456	\N	2026-06-25 00:32:18	online	设备WebSocket连接建立	info	\N	\N	\N
218	123456	\N	2026-06-25 02:02:24	online	设备WebSocket连接建立	info	\N	\N	\N
219	123456	\N	2026-06-25 02:19:17	online	设备WebSocket连接建立	info	\N	\N	\N
220	123456	\N	2026-06-25 02:33:16	online	设备WebSocket连接建立	info	\N	\N	\N
221	123456	\N	2026-06-25 02:42:13	online	设备WebSocket连接建立	info	\N	\N	\N
222	123456	\N	2026-06-25 02:43:52	online	设备WebSocket连接建立	info	\N	\N	\N
223	123456	\N	2026-06-25 02:51:52	online	设备WebSocket连接建立	info	\N	\N	\N
224	123456	\N	2026-06-25 03:29:48	online	设备WebSocket连接建立	info	\N	\N	\N
225	123456	\N	2026-06-25 03:50:42	online	设备WebSocket连接建立	info	\N	\N	\N
226	123456	\N	2026-06-25 04:00:57	online	设备WebSocket连接建立	info	\N	\N	\N
227	123456	\N	2026-06-25 04:03:05	online	设备WebSocket连接建立	info	\N	\N	\N
228	123456	\N	2026-06-25 04:03:28	online	设备WebSocket连接建立	info	\N	\N	\N
229	123456	\N	2026-06-25 04:04:27	online	设备WebSocket连接建立	info	\N	\N	\N
230	123456	\N	2026-06-25 04:05:56	online	设备WebSocket连接建立	info	\N	\N	\N
231	123456	\N	2026-06-25 04:06:06	online	设备WebSocket连接建立	info	\N	\N	\N
232	123456	\N	2026-06-25 04:11:56	online	设备WebSocket连接建立	info	\N	\N	\N
233	123456	\N	2026-06-25 04:11:59	online	设备WebSocket连接建立	info	\N	\N	\N
234	123456	\N	2026-06-25 04:20:58	online	设备WebSocket连接建立	info	\N	\N	\N
235	123456	\N	2026-06-25 04:21:01	online	设备WebSocket连接建立	info	\N	\N	\N
236	123456	\N	2026-06-25 04:59:08	online	设备WebSocket连接建立	info	\N	\N	\N
237	123456	\N	2026-06-25 04:59:11	online	设备WebSocket连接建立	info	\N	\N	\N
238	123456	\N	2026-06-25 06:24:14	online	设备WebSocket连接建立	info	\N	\N	\N
239	123456	\N	2026-06-25 06:24:16	online	设备WebSocket连接建立	info	\N	\N	\N
240	123456	\N	2026-06-25 06:41:57	online	设备WebSocket连接建立	info	\N	\N	\N
241	123456	\N	2026-06-25 06:42:00	online	设备WebSocket连接建立	info	\N	\N	\N
242	123456	\N	2026-06-25 06:46:26	online	设备WebSocket连接建立	info	\N	\N	\N
243	123456	\N	2026-06-25 06:46:30	online	设备WebSocket连接建立	info	\N	\N	\N
244	123456	\N	2026-06-25 08:13:36	online	设备WebSocket连接建立	info	\N	\N	\N
245	123456	\N	2026-06-25 08:32:12	online	设备WebSocket连接建立	info	\N	\N	\N
246	123456	\N	2026-06-25 08:36:49	online	设备WebSocket连接建立	info	\N	\N	\N
247	123456	\N	2026-06-25 08:39:02	online	设备WebSocket连接建立	info	\N	\N	\N
248	123456	\N	2026-06-25 08:55:23	online	设备WebSocket连接建立	info	\N	\N	\N
249	123456	\N	2026-06-25 09:04:16	online	设备WebSocket连接建立	info	\N	\N	\N
250	123456	\N	2026-06-25 09:05:58	online	设备WebSocket连接建立	info	\N	\N	\N
251	123456	\N	2026-06-25 09:06:01	online	设备WebSocket连接建立	info	\N	\N	\N
252	123456	\N	2026-06-25 09:12:02	online	设备WebSocket连接建立	info	\N	\N	\N
253	123456	\N	2026-06-25 09:12:34	online	设备WebSocket连接建立	info	\N	\N	\N
254	123456	\N	2026-06-25 09:26:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
255	123456	\N	2026-06-25 09:26:29	online	设备WebSocket连接建立	info	\N	\N	\N
256	123456	\N	2026-06-25 09:30:50	online	设备WebSocket连接建立	info	\N	\N	\N
257	123456	\N	2026-06-25 09:34:27	offline	设备WebSocket断开连接	warning	\N	\N	\N
258	123456	\N	2026-06-25 09:34:28	online	设备WebSocket连接建立	info	\N	\N	\N
259	123456	\N	2026-06-25 09:41:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
260	123456	\N	2026-06-25 09:41:30	online	设备WebSocket连接建立	info	\N	\N	\N
261	123456	\N	2026-06-25 09:41:37	online	设备WebSocket连接建立	info	\N	\N	\N
262	123456	\N	2026-06-25 09:44:59	online	设备WebSocket连接建立	info	\N	\N	\N
263	123456	\N	2026-06-25 09:48:42	offline	设备WebSocket断开连接	warning	\N	\N	\N
264	123456	\N	2026-06-25 09:48:42	online	设备WebSocket连接建立	info	\N	\N	\N
265	123456	\N	2026-06-25 09:48:42	online	设备WebSocket连接建立	info	\N	\N	\N
266	123456	\N	2026-06-25 09:49:32	online	设备WebSocket连接建立	info	\N	\N	\N
267	123456	\N	2026-06-25 09:52:50	offline	设备WebSocket断开连接	warning	\N	\N	\N
268	123456	\N	2026-06-25 09:52:50	online	设备WebSocket连接建立	info	\N	\N	\N
269	123456	\N	2026-06-25 09:55:45	online	设备WebSocket连接建立	info	\N	\N	\N
270	123456	\N	2026-06-25 09:58:19	online	设备WebSocket连接建立	info	\N	\N	\N
271	123456	\N	2026-06-25 10:01:44	online	设备WebSocket连接建立	info	\N	\N	\N
272	123456	\N	2026-06-25 10:03:32	online	设备WebSocket连接建立	info	\N	\N	\N
273	123456	\N	2026-06-25 10:03:40	online	设备WebSocket连接建立	info	\N	\N	\N
274	123456	\N	2026-06-25 10:07:34	online	设备WebSocket连接建立	info	\N	\N	\N
275	123456	\N	2026-06-25 10:15:11	online	设备WebSocket连接建立	info	\N	\N	\N
276	123456	\N	2026-06-25 10:37:36	online	设备WebSocket连接建立	info	\N	\N	\N
277	123456	\N	2026-06-25 10:38:27	online	设备WebSocket连接建立	info	\N	\N	\N
278	123456	\N	2026-06-25 10:40:17	online	设备WebSocket连接建立	info	\N	\N	\N
279	123456	\N	2026-06-25 10:41:53	online	设备WebSocket连接建立	info	\N	\N	\N
280	123456	\N	2026-06-25 10:46:41	online	设备WebSocket连接建立	info	\N	\N	\N
281	123456	\N	2026-06-25 10:51:52	online	设备WebSocket连接建立	info	\N	\N	\N
282	123456	\N	2026-06-25 10:56:13	offline	设备WebSocket断开连接	warning	\N	\N	\N
283	123456	\N	2026-06-25 10:56:14	online	设备WebSocket连接建立	info	\N	\N	\N
284	123456	\N	2026-06-25 11:14:23	online	设备WebSocket连接建立	info	\N	\N	\N
285	123456	\N	2026-06-25 11:16:25	online	设备WebSocket连接建立	info	\N	\N	\N
286	123456	\N	2026-06-25 11:18:52	online	设备WebSocket连接建立	info	\N	\N	\N
287	101002	\N	2026-06-25 11:19:38	online	设备WebSocket连接建立	info	\N	\N	\N
288	123456	\N	2026-06-25 11:20:50	online	设备WebSocket连接建立	info	\N	\N	\N
289	101002	\N	2026-06-25 11:20:50	online	设备WebSocket连接建立	info	\N	\N	\N
290	123456	\N	2026-06-25 11:22:57	online	设备WebSocket连接建立	info	\N	\N	\N
291	101002	\N	2026-06-25 11:22:57	online	设备WebSocket连接建立	info	\N	\N	\N
292	123456	\N	2026-06-25 11:23:42	online	设备WebSocket连接建立	info	\N	\N	\N
293	101002	\N	2026-06-25 11:23:42	online	设备WebSocket连接建立	info	\N	\N	\N
294	123456	\N	2026-06-25 11:25:10	online	设备WebSocket连接建立	info	\N	\N	\N
295	101002	\N	2026-06-25 11:25:10	online	设备WebSocket连接建立	info	\N	\N	\N
296	123456	\N	2026-06-25 11:26:22	online	设备WebSocket连接建立	info	\N	\N	\N
297	101002	\N	2026-06-25 11:26:22	online	设备WebSocket连接建立	info	\N	\N	\N
298	123456	\N	2026-06-25 11:42:03	online	设备WebSocket连接建立	info	\N	\N	\N
299	123456	\N	2026-06-25 12:15:58	online	设备WebSocket连接建立	info	\N	\N	\N
300	123456	\N	2026-06-25 12:26:28	online	设备WebSocket连接建立	info	\N	\N	\N
301	123456	\N	2026-06-25 12:27:34	online	设备WebSocket连接建立	info	\N	\N	\N
302	123456	\N	2026-06-25 12:31:58	online	设备WebSocket连接建立	info	\N	\N	\N
303	123456	\N	2026-06-25 12:32:33	online	设备WebSocket连接建立	info	\N	\N	\N
304	123456	\N	2026-06-25 12:38:39	online	设备WebSocket连接建立	info	\N	\N	\N
305	123456	\N	2026-06-25 12:39:43	online	设备WebSocket连接建立	info	\N	\N	\N
306	123456	\N	2026-06-25 13:02:08	offline	设备WebSocket断开连接	warning	\N	\N	\N
307	123456	\N	2026-06-25 13:02:08	online	设备WebSocket连接建立	info	\N	\N	\N
308	123456	\N	2026-06-25 13:18:19	online	设备WebSocket连接建立	info	\N	\N	\N
309	123456	\N	2026-06-25 13:32:10	online	设备WebSocket连接建立	info	\N	\N	\N
310	123456	\N	2026-06-25 13:34:33	online	设备WebSocket连接建立	info	\N	\N	\N
311	123456	\N	2026-06-25 13:38:40	online	设备WebSocket连接建立	info	\N	\N	\N
312	123456	\N	2026-06-25 13:45:39	online	设备WebSocket连接建立	info	\N	\N	\N
313	123456	\N	2026-06-25 13:50:24	online	设备WebSocket连接建立	info	\N	\N	\N
314	101002	\N	2026-06-25 13:51:42	online	设备WebSocket连接建立	info	\N	\N	\N
315	101002	\N	2026-06-25 13:52:59	online	设备WebSocket连接建立	info	\N	\N	\N
316	101002	\N	2026-06-25 13:52:59	online	设备WebSocket连接建立	info	\N	\N	\N
317	101002	\N	2026-06-25 13:53:00	online	设备WebSocket连接建立	info	\N	\N	\N
318	101002	\N	2026-06-25 13:53:02	online	设备WebSocket连接建立	info	\N	\N	\N
319	101002	\N	2026-06-25 13:53:04	online	设备WebSocket连接建立	info	\N	\N	\N
320	101002	\N	2026-06-25 13:53:05	online	设备WebSocket连接建立	info	\N	\N	\N
321	101002	\N	2026-06-25 13:53:07	online	设备WebSocket连接建立	info	\N	\N	\N
322	101002	\N	2026-06-25 13:54:49	online	设备WebSocket连接建立	info	\N	\N	\N
323	123456	\N	2026-06-25 14:01:32	online	设备WebSocket连接建立	info	\N	\N	\N
324	101002	\N	2026-06-25 14:01:33	online	设备WebSocket连接建立	info	\N	\N	\N
325	101002	\N	2026-06-25 14:01:33	online	设备WebSocket连接建立	info	\N	\N	\N
326	101002	\N	2026-06-25 14:01:33	online	设备WebSocket连接建立	info	\N	\N	\N
327	101002	\N	2026-06-25 14:06:24	online	设备WebSocket连接建立	info	\N	\N	\N
328	123456	\N	2026-06-25 14:06:24	online	设备WebSocket连接建立	info	\N	\N	\N
329	101002	\N	2026-06-25 14:14:31	online	设备WebSocket连接建立	info	\N	\N	\N
330	123456	\N	2026-06-25 14:14:31	online	设备WebSocket连接建立	info	\N	\N	\N
331	123456	\N	2026-06-25 14:44:49	online	设备WebSocket连接建立	info	\N	\N	\N
332	123456	\N	2026-06-25 14:49:36	online	设备WebSocket连接建立	info	\N	\N	\N
333	101002	\N	2026-06-25 14:49:37	online	设备WebSocket连接建立	info	\N	\N	\N
334	101002	\N	2026-06-25 14:56:29	online	设备WebSocket连接建立	info	\N	\N	\N
335	123456	\N	2026-06-25 15:22:47	online	设备WebSocket连接建立	info	\N	\N	\N
336	123456	\N	2026-06-25 15:33:27	online	设备WebSocket连接建立	info	\N	\N	\N
337	123456	\N	2026-06-25 15:36:25	online	设备WebSocket连接建立	info	\N	\N	\N
338	123456	\N	2026-06-25 15:38:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
339	123456	\N	2026-06-25 15:38:25	online	设备WebSocket连接建立	info	\N	\N	\N
340	123456	\N	2026-06-25 15:46:24	offline	设备WebSocket断开连接	warning	\N	\N	\N
341	123456	\N	2026-06-25 15:46:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
342	123456	\N	2026-06-25 15:46:25	online	设备WebSocket连接建立	info	\N	\N	\N
343	123456	\N	2026-06-25 15:59:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
344	123456	\N	2026-06-25 15:59:31	online	设备WebSocket连接建立	info	\N	\N	\N
345	123456	\N	2026-06-25 17:00:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
346	123456	\N	2026-06-25 22:22:56	online	设备WebSocket连接建立	info	\N	\N	\N
347	123456	\N	2026-06-25 22:27:31	online	设备WebSocket连接建立	info	\N	\N	\N
348	123456	\N	2026-06-25 22:35:32	online	设备WebSocket连接建立	info	\N	\N	\N
349	123456	\N	2026-06-25 22:37:37	online	设备WebSocket连接建立	info	\N	\N	\N
350	123456	\N	2026-06-25 22:38:17	online	设备WebSocket连接建立	info	\N	\N	\N
351	123456	\N	2026-06-25 22:42:19	online	设备WebSocket连接建立	info	\N	\N	\N
352	123456	\N	2026-06-25 22:44:58	online	设备WebSocket连接建立	info	\N	\N	\N
353	123456	\N	2026-06-25 22:45:32	online	设备WebSocket连接建立	info	\N	\N	\N
354	123456	\N	2026-06-25 22:50:18	online	设备WebSocket连接建立	info	\N	\N	\N
355	123456	\N	2026-06-25 22:56:18	online	设备WebSocket连接建立	info	\N	\N	\N
356	123456	\N	2026-06-25 23:01:17	online	设备WebSocket连接建立	info	\N	\N	\N
357	123456	\N	2026-06-25 23:06:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
358	123456	\N	2026-06-25 23:06:33	online	设备WebSocket连接建立	info	\N	\N	\N
359	123456	\N	2026-06-25 23:06:33	online	设备WebSocket连接建立	info	\N	\N	\N
360	123456	\N	2026-06-25 23:06:34	online	设备WebSocket连接建立	info	\N	\N	\N
361	123456	\N	2026-06-25 23:06:35	online	设备WebSocket连接建立	info	\N	\N	\N
362	123456	\N	2026-06-25 23:06:37	online	设备WebSocket连接建立	info	\N	\N	\N
363	123456	\N	2026-06-25 23:06:38	online	设备WebSocket连接建立	info	\N	\N	\N
364	123456	\N	2026-06-25 23:06:39	online	设备WebSocket连接建立	info	\N	\N	\N
365	123456	\N	2026-06-25 23:06:40	online	设备WebSocket连接建立	info	\N	\N	\N
366	123456	\N	2026-06-25 23:06:42	online	设备WebSocket连接建立	info	\N	\N	\N
367	123456	\N	2026-06-25 23:06:43	online	设备WebSocket连接建立	info	\N	\N	\N
368	123456	\N	2026-06-25 23:06:44	online	设备WebSocket连接建立	info	\N	\N	\N
369	123456	\N	2026-06-25 23:10:42	online	设备WebSocket连接建立	info	\N	\N	\N
370	123456	\N	2026-06-25 23:10:42	online	设备WebSocket连接建立	info	\N	\N	\N
371	123456	\N	2026-06-25 23:10:42	online	设备WebSocket连接建立	info	\N	\N	\N
372	123456	\N	2026-06-25 23:10:44	online	设备WebSocket连接建立	info	\N	\N	\N
373	123456	\N	2026-06-25 23:29:27	online	设备WebSocket连接建立	info	\N	\N	\N
374	123456	\N	2026-06-25 23:32:50	online	设备WebSocket连接建立	info	\N	\N	\N
375	123456	\N	2026-06-25 23:33:24	online	设备WebSocket连接建立	info	\N	\N	\N
376	123456	\N	2026-06-25 23:38:10	offline	设备WebSocket断开连接	warning	\N	\N	\N
377	101002	\N	2026-06-26 00:29:54	online	设备WebSocket连接建立	info	\N	\N	\N
378	101002	\N	2026-06-26 00:31:09	online	设备WebSocket连接建立	info	\N	\N	\N
379	101002	\N	2026-06-26 00:44:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
380	123456	\N	2026-06-26 00:45:03	online	设备WebSocket连接建立	info	\N	\N	\N
381	123456	\N	2026-06-26 01:26:53	offline	设备WebSocket断开连接	warning	\N	\N	\N
382	123456	\N	2026-06-26 01:26:54	online	设备WebSocket连接建立	info	\N	\N	\N
383	123456	\N	2026-06-26 01:29:18	offline	设备WebSocket断开连接	warning	\N	\N	\N
384	123456	\N	2026-06-26 01:29:18	online	设备WebSocket连接建立	info	\N	\N	\N
385	123456	\N	2026-06-26 01:34:58	online	设备WebSocket连接建立	info	\N	\N	\N
386	123456	\N	2026-06-26 01:39:41	online	设备WebSocket连接建立	info	\N	\N	\N
387	123456	\N	2026-06-26 01:41:54	offline	设备WebSocket断开连接	warning	\N	\N	\N
388	123456	\N	2026-06-26 01:41:55	online	设备WebSocket连接建立	info	\N	\N	\N
389	123456	\N	2026-06-26 01:45:19	offline	设备WebSocket断开连接	warning	\N	\N	\N
390	123456	\N	2026-06-26 01:45:21	online	设备WebSocket连接建立	info	\N	\N	\N
391	123456	\N	2026-06-26 01:46:02	offline	设备WebSocket断开连接	warning	\N	\N	\N
392	123456	\N	2026-06-26 01:46:03	online	设备WebSocket连接建立	info	\N	\N	\N
393	123456	\N	2026-06-26 01:48:22	offline	设备WebSocket断开连接	warning	\N	\N	\N
394	123456	\N	2026-06-26 01:48:22	online	设备WebSocket连接建立	info	\N	\N	\N
395	123456	\N	2026-06-26 01:51:09	online	设备WebSocket连接建立	info	\N	\N	\N
396	123456	\N	2026-06-26 01:51:25	online	设备WebSocket连接建立	info	\N	\N	\N
397	123456	\N	2026-06-26 01:51:30	online	设备WebSocket连接建立	info	\N	\N	\N
398	123456	\N	2026-06-26 01:55:34	online	设备WebSocket连接建立	info	\N	\N	\N
399	123456	\N	2026-06-26 01:56:50	offline	设备WebSocket断开连接	warning	\N	\N	\N
400	123456	\N	2026-06-26 01:56:52	online	设备WebSocket连接建立	info	\N	\N	\N
401	123456	\N	2026-06-26 01:58:38	offline	设备WebSocket断开连接	warning	\N	\N	\N
402	123456	\N	2026-06-26 01:58:40	online	设备WebSocket连接建立	info	\N	\N	\N
403	123456	\N	2026-06-26 02:05:41	online	设备WebSocket连接建立	info	\N	\N	\N
404	123456	\N	2026-06-26 02:25:38	online	设备WebSocket连接建立	info	\N	\N	\N
405	123456	\N	2026-06-26 02:30:23	online	设备WebSocket连接建立	info	\N	\N	\N
406	123456	\N	2026-06-26 02:30:46	online	设备WebSocket连接建立	info	\N	\N	\N
407	123456	\N	2026-06-26 02:34:03	online	设备WebSocket连接建立	info	\N	\N	\N
408	123456	\N	2026-06-26 02:51:14	online	设备WebSocket连接建立	info	\N	\N	\N
409	123456	\N	2026-06-26 02:55:39	offline	设备WebSocket断开连接	warning	\N	\N	\N
410	123456	\N	2026-06-26 02:55:39	online	设备WebSocket连接建立	info	\N	\N	\N
411	123456	\N	2026-06-26 03:06:51	offline	设备WebSocket断开连接	warning	\N	\N	\N
412	123456	\N	2026-06-26 03:06:53	online	设备WebSocket连接建立	info	\N	\N	\N
413	123456	\N	2026-06-26 03:13:48	offline	设备WebSocket断开连接	warning	\N	\N	\N
414	123456	\N	2026-06-26 03:13:55	online	设备WebSocket连接建立	info	\N	\N	\N
415	123456	\N	2026-06-26 03:22:12	offline	设备WebSocket断开连接	warning	\N	\N	\N
416	123456	\N	2026-06-26 03:22:14	online	设备WebSocket连接建立	info	\N	\N	\N
417	123456	\N	2026-06-26 03:23:40	offline	设备WebSocket断开连接	warning	\N	\N	\N
418	123456	\N	2026-06-26 03:23:41	online	设备WebSocket连接建立	info	\N	\N	\N
419	123456	\N	2026-06-26 03:36:30	offline	设备WebSocket断开连接	warning	\N	\N	\N
420	123456	\N	2026-06-26 03:36:32	online	设备WebSocket连接建立	info	\N	\N	\N
421	123456	\N	2026-06-26 03:50:19	offline	设备WebSocket断开连接	warning	\N	\N	\N
422	123456	\N	2026-06-26 03:59:10	online	设备WebSocket连接建立	info	\N	\N	\N
423	123456	\N	2026-06-26 03:59:23	offline	设备WebSocket断开连接	warning	\N	\N	\N
424	123456	\N	2026-06-26 03:59:32	online	设备WebSocket连接建立	info	\N	\N	\N
425	123456	\N	2026-06-26 04:01:02	offline	设备WebSocket断开连接	warning	\N	\N	\N
426	123456	\N	2026-06-26 04:01:03	online	设备WebSocket连接建立	info	\N	\N	\N
427	123456	\N	2026-06-26 04:08:19	online	设备WebSocket连接建立	info	\N	\N	\N
428	123456	\N	2026-06-26 04:19:42	online	设备WebSocket连接建立	info	\N	\N	\N
429	123456	\N	2026-06-26 04:26:10	online	设备WebSocket连接建立	info	\N	\N	\N
430	123456	\N	2026-06-26 04:33:08	online	设备WebSocket连接建立	info	\N	\N	\N
431	123456	\N	2026-06-26 04:36:15	offline	设备WebSocket断开连接	warning	\N	\N	\N
432	123456	\N	2026-06-26 04:36:20	online	设备WebSocket连接建立	info	\N	\N	\N
433	123456	\N	2026-06-26 04:38:19	offline	设备WebSocket断开连接	warning	\N	\N	\N
434	123456	\N	2026-06-26 04:40:49	online	设备WebSocket连接建立	info	\N	\N	\N
435	123456	\N	2026-06-26 04:46:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
436	123456	\N	2026-06-26 04:48:01	online	设备WebSocket连接建立	info	\N	\N	\N
437	123456	\N	2026-06-26 04:48:33	offline	设备WebSocket断开连接	warning	\N	\N	\N
438	123456	\N	2026-06-26 04:55:18	online	设备WebSocket连接建立	info	\N	\N	\N
439	123456	\N	2026-06-26 05:07:19	online	设备WebSocket连接建立	info	\N	\N	\N
440	123456	\N	2026-06-26 05:17:17	online	设备WebSocket连接建立	info	\N	\N	\N
441	123456	\N	2026-06-26 05:17:18	online	设备WebSocket连接建立	info	\N	\N	\N
442	123456	\N	2026-06-26 05:17:18	offline	设备WebSocket断开连接	warning	\N	\N	\N
443	123456	\N	2026-06-26 05:17:20	online	设备WebSocket连接建立	info	\N	\N	\N
444	123456	\N	2026-06-26 05:18:10	online	设备WebSocket连接建立	info	\N	\N	\N
445	123456	\N	2026-06-26 05:24:12	online	设备WebSocket连接建立	info	\N	\N	\N
446	123456	\N	2026-06-26 05:26:31	online	设备WebSocket连接建立	info	\N	\N	\N
447	123456	\N	2026-06-26 05:35:19	online	设备WebSocket连接建立	info	\N	\N	\N
448	123456	\N	2026-06-26 05:46:57	online	设备WebSocket连接建立	info	\N	\N	\N
449	123456	\N	2026-06-26 05:51:16	online	设备WebSocket连接建立	info	\N	\N	\N
450	123456	\N	2026-06-26 05:54:34	online	设备WebSocket连接建立	info	\N	\N	\N
451	123456	\N	2026-06-26 05:59:08	online	设备WebSocket连接建立	info	\N	\N	\N
452	123456	\N	2026-06-26 06:24:06	offline	设备WebSocket断开连接	warning	\N	\N	\N
453	100100	\N	2026-06-26 06:41:10	online	设备WebSocket连接建立	info	\N	\N	\N
454	100100	\N	2026-06-26 06:41:12	online	设备WebSocket连接建立	info	\N	\N	\N
455	100100	\N	2026-06-26 06:41:14	online	设备WebSocket连接建立	info	\N	\N	\N
456	100100	\N	2026-06-26 06:41:15	online	设备WebSocket连接建立	info	\N	\N	\N
457	100100	\N	2026-06-26 06:41:58	online	设备WebSocket连接建立	info	\N	\N	\N
458	100100	\N	2026-06-26 06:42:30	online	设备WebSocket连接建立	info	\N	\N	\N
459	100100	\N	2026-06-26 06:43:17	online	设备WebSocket连接建立	info	\N	\N	\N
460	100100	\N	2026-06-26 06:44:06	online	设备WebSocket连接建立	info	\N	\N	\N
461	100100	\N	2026-06-26 06:47:44	online	设备WebSocket连接建立	info	\N	\N	\N
462	100100	\N	2026-06-26 06:51:35	online	设备WebSocket连接建立	info	\N	\N	\N
463	100100	\N	2026-06-26 06:55:46	online	设备WebSocket连接建立	info	\N	\N	\N
464	100100	\N	2026-06-26 06:57:35	online	设备WebSocket连接建立	info	\N	\N	\N
465	100100	\N	2026-06-26 07:02:02	online	设备WebSocket连接建立	info	\N	\N	\N
466	100100	\N	2026-06-26 07:05:15	online	设备WebSocket连接建立	info	\N	\N	\N
467	100100	\N	2026-06-26 07:08:28	online	设备WebSocket连接建立	info	\N	\N	\N
468	100100	\N	2026-06-26 07:15:01	online	设备WebSocket连接建立	info	\N	\N	\N
469	100100	\N	2026-06-26 07:17:59	offline	设备WebSocket断开连接	warning	\N	\N	\N
470	100100	\N	2026-06-26 07:17:59	online	设备WebSocket连接建立	info	\N	\N	\N
471	100100	\N	2026-06-26 07:24:50	online	设备WebSocket连接建立	info	\N	\N	\N
472	100100	\N	2026-06-26 07:25:47	online	设备WebSocket连接建立	info	\N	\N	\N
473	100100	\N	2026-06-26 07:28:33	online	设备WebSocket连接建立	info	\N	\N	\N
474	100100	\N	2026-06-26 07:38:58	online	设备WebSocket连接建立	info	\N	\N	\N
475	100100	\N	2026-06-26 07:42:01	offline	设备WebSocket断开连接	warning	\N	\N	\N
476	100100	\N	2026-06-26 07:42:02	online	设备WebSocket连接建立	info	\N	\N	\N
477	100100	\N	2026-06-26 07:46:05	online	设备WebSocket连接建立	info	\N	\N	\N
478	100100	\N	2026-06-26 07:49:09	offline	设备WebSocket断开连接	warning	\N	\N	\N
479	100100	\N	2026-06-26 07:49:15	online	设备WebSocket连接建立	info	\N	\N	\N
480	100100	\N	2026-06-26 07:52:38	online	设备WebSocket连接建立	info	\N	\N	\N
481	100100	\N	2026-06-26 07:56:20	online	设备WebSocket连接建立	info	\N	\N	\N
482	100100	\N	2026-06-26 08:00:06	online	设备WebSocket连接建立	info	\N	\N	\N
483	100100	\N	2026-06-26 08:01:13	online	设备WebSocket连接建立	info	\N	\N	\N
484	100100	\N	2026-06-26 08:03:46	online	设备WebSocket连接建立	info	\N	\N	\N
485	100100	\N	2026-06-26 08:03:56	online	设备WebSocket连接建立	info	\N	\N	\N
486	100100	\N	2026-06-26 08:06:10	online	设备WebSocket连接建立	info	\N	\N	\N
487	100100	\N	2026-06-26 08:07:59	online	设备WebSocket连接建立	info	\N	\N	\N
488	100100	\N	2026-06-26 08:11:00	online	设备WebSocket连接建立	info	\N	\N	\N
489	100100	\N	2026-06-26 08:11:38	online	设备WebSocket连接建立	info	\N	\N	\N
490	test_main_app	\N	2026-06-27 07:07:00.301678	online	设备WebSocket连接建立	info	\N	\N	\N
491	test_main_app	\N	2026-06-27 07:07:03.253405	offline	设备WebSocket断开连接	warning	\N	\N	\N
492	100100	\N	2026-06-27 07:07:49.920075	online	设备WebSocket连接建立	info	\N	\N	\N
493	100100	\N	2026-06-27 07:07:49.994632	online	设备WebSocket连接建立	info	\N	\N	\N
494	100100	\N	2026-06-27 07:07:59.849589	offline	设备WebSocket断开连接	warning	\N	\N	\N
495	test_direct	\N	2026-06-27 07:08:15.618189	offline	设备WebSocket断开连接	warning	\N	\N	\N
496	test_nginx	\N	2026-06-27 07:08:18.584824	offline	设备WebSocket断开连接	warning	\N	\N	\N
497	test_nohost	\N	2026-06-27 07:08:21.604902	offline	设备WebSocket断开连接	warning	\N	\N	\N
498	test_recheck	\N	2026-06-27 07:08:53.415112	offline	设备WebSocket断开连接	warning	\N	\N	\N
499	test_py_direct	\N	2026-06-27 07:09:09.187288	online	设备WebSocket连接建立	info	\N	\N	\N
500	test_py_direct	\N	2026-06-27 07:09:09.31354	offline	设备WebSocket断开连接	warning	\N	\N	\N
501	test_single_host	\N	2026-06-27 07:09:30.583827	offline	设备WebSocket断开连接	warning	\N	\N	\N
502	test_default_host	\N	2026-06-27 07:09:32.608764	offline	设备WebSocket断开连接	warning	\N	\N	\N
503	100100	\N	2026-06-27 07:11:25.496255	online	设备WebSocket连接建立	info	\N	\N	\N
504	100100	\N	2026-06-27 07:11:30.823681	offline	设备WebSocket断开连接	warning	\N	\N	\N
505	100100	\N	2026-06-27 07:11:32.630952	online	设备WebSocket连接建立	info	\N	\N	\N
506	100100	\N	2026-06-27 07:11:43.019813	offline	设备WebSocket断开连接	warning	\N	\N	\N
507	100100	\N	2026-06-27 07:11:47.552613	online	设备WebSocket连接建立	info	\N	\N	\N
508	100100	\N	2026-06-27 07:11:48.766999	offline	设备WebSocket断开连接	warning	\N	\N	\N
509	100100	\N	2026-06-27 07:13:38.830143	online	设备WebSocket连接建立	info	\N	\N	\N
510	100100	\N	2026-06-27 07:13:49.356182	offline	设备WebSocket断开连接	warning	\N	\N	\N
511	100100	\N	2026-06-27 07:13:49.948043	online	设备WebSocket连接建立	info	\N	\N	\N
512	100100	\N	2026-06-27 07:14:00.59405	offline	设备WebSocket断开连接	warning	\N	\N	\N
513	100100	\N	2026-06-27 07:14:05.351706	online	设备WebSocket连接建立	info	\N	\N	\N
514	100100	\N	2026-06-27 07:14:15.786697	offline	设备WebSocket断开连接	warning	\N	\N	\N
515	100100	\N	2026-06-27 07:14:34.229846	online	设备WebSocket连接建立	info	\N	\N	\N
516	100100	\N	2026-06-27 07:14:42.735172	offline	设备WebSocket断开连接	warning	\N	\N	\N
517	100100	\N	2026-06-27 07:15:02.45812	online	设备WebSocket连接建立	info	\N	\N	\N
518	100100	\N	2026-06-27 07:15:02.532131	online	设备WebSocket连接建立	info	\N	\N	\N
519	100100	\N	2026-06-27 07:15:07.316551	offline	设备WebSocket断开连接	warning	\N	\N	\N
520	100100	\N	2026-06-27 07:16:17.096168	online	设备WebSocket连接建立	info	\N	\N	\N
521	100100	\N	2026-06-27 07:16:27.177086	offline	设备WebSocket断开连接	warning	\N	\N	\N
522	100100	\N	2026-06-27 07:16:28.015272	online	设备WebSocket连接建立	info	\N	\N	\N
523	100100	\N	2026-06-27 07:16:28.089357	online	设备WebSocket连接建立	info	\N	\N	\N
524	100100	\N	2026-06-27 07:16:29.27177	online	设备WebSocket连接建立	info	\N	\N	\N
525	100100	\N	2026-06-27 07:16:38.069109	offline	设备WebSocket断开连接	warning	\N	\N	\N
526	100100	\N	2026-06-27 07:16:42.937619	online	设备WebSocket连接建立	info	\N	\N	\N
527	100100	\N	2026-06-27 07:16:53.29388	offline	设备WebSocket断开连接	warning	\N	\N	\N
528	100100	\N	2026-06-27 07:19:14.059323	online	设备WebSocket连接建立	info	\N	\N	\N
529	100100	\N	2026-06-27 07:19:15.714929	offline	设备WebSocket断开连接	warning	\N	\N	\N
530	100100	\N	2026-06-27 07:19:17.346032	online	设备WebSocket连接建立	info	\N	\N	\N
531	100100	\N	2026-06-27 07:19:27.60143	offline	设备WebSocket断开连接	warning	\N	\N	\N
532	100100	\N	2026-06-27 07:21:01.920009	online	设备WebSocket连接建立	info	\N	\N	\N
533	100100	\N	2026-06-27 07:21:06.695338	offline	设备WebSocket断开连接	warning	\N	\N	\N
534	100100	\N	2026-06-27 07:21:25.655849	online	设备WebSocket连接建立	info	\N	\N	\N
535	100100	\N	2026-06-27 07:21:35.819822	offline	设备WebSocket断开连接	warning	\N	\N	\N
536	100100	\N	2026-06-27 07:21:37.678149	online	设备WebSocket连接建立	info	\N	\N	\N
537	100100	\N	2026-06-27 07:21:38.454401	offline	设备WebSocket断开连接	warning	\N	\N	\N
538	100100	\N	2026-06-27 07:26:32.61367	online	设备WebSocket连接建立	info	\N	\N	\N
539	100100	\N	2026-06-27 07:26:42.936555	offline	设备WebSocket断开连接	warning	\N	\N	\N
540	100100	\N	2026-06-27 07:26:43.482596	online	设备WebSocket连接建立	info	\N	\N	\N
541	100100	\N	2026-06-27 07:26:53.586738	offline	设备WebSocket断开连接	warning	\N	\N	\N
542	100100	\N	2026-06-27 07:27:06.28456	online	设备WebSocket连接建立	info	\N	\N	\N
543	100100	\N	2026-06-27 07:27:16.960721	offline	设备WebSocket断开连接	warning	\N	\N	\N
544	100100	\N	2026-06-27 07:27:17.768058	online	设备WebSocket连接建立	info	\N	\N	\N
545	100100	\N	2026-06-27 07:27:17.848826	online	设备WebSocket连接建立	info	\N	\N	\N
546	100100	\N	2026-06-27 07:27:19.09849	online	设备WebSocket连接建立	info	\N	\N	\N
547	100100	\N	2026-06-27 07:27:20.404738	online	设备WebSocket连接建立	info	\N	\N	\N
548	100100	\N	2026-06-27 07:27:21.689969	online	设备WebSocket连接建立	info	\N	\N	\N
549	100100	\N	2026-06-27 07:27:27.819089	offline	设备WebSocket断开连接	warning	\N	\N	\N
550	100100	\N	2026-06-27 07:27:28.464966	online	设备WebSocket连接建立	info	\N	\N	\N
551	100100	\N	2026-06-27 07:27:38.902357	offline	设备WebSocket断开连接	warning	\N	\N	\N
552	100100	\N	2026-06-27 07:32:13.325294	online	设备WebSocket连接建立	info	\N	\N	\N
553	100100	\N	2026-06-27 07:37:28.570649	online	设备WebSocket连接建立	info	\N	\N	\N
554	100100	\N	2026-06-27 07:38:14.398408	online	设备WebSocket连接建立	info	\N	\N	\N
555	100100	\N	2026-06-27 07:39:48.077537	online	设备WebSocket连接建立	info	\N	\N	\N
556	100100	\N	2026-06-27 07:39:48.14737	online	设备WebSocket连接建立	info	\N	\N	\N
557	100100	\N	2026-06-27 07:39:53.312521	offline	设备WebSocket断开连接	warning	\N	\N	\N
558	100100	\N	2026-06-27 07:39:54.986883	online	设备WebSocket连接建立	info	\N	\N	\N
559	100100	\N	2026-06-27 07:39:55.058792	online	设备WebSocket连接建立	info	\N	\N	\N
560	100100	\N	2026-06-27 07:41:03.477678	offline	设备WebSocket断开连接	warning	\N	\N	\N
561	100100	\N	2026-06-27 07:46:23.52377	online	设备WebSocket连接建立	info	\N	\N	\N
562	100100	\N	2026-06-27 07:46:23.598796	online	设备WebSocket连接建立	info	\N	\N	\N
563	100100	\N	2026-06-27 07:47:59.775198	online	设备WebSocket连接建立	info	\N	\N	\N
564	100100	\N	2026-06-27 07:47:59.847962	online	设备WebSocket连接建立	info	\N	\N	\N
565	100100	\N	2026-06-27 07:48:42.627695	online	设备WebSocket连接建立	info	\N	\N	\N
566	100100	\N	2026-06-27 07:48:42.911862	online	设备WebSocket连接建立	info	\N	\N	\N
567	100100	\N	2026-06-27 07:49:40.670145	online	设备WebSocket连接建立	info	\N	\N	\N
568	100100	\N	2026-06-27 07:49:40.84826	online	设备WebSocket连接建立	info	\N	\N	\N
569	100100	\N	2026-06-27 07:50:23.530853	online	设备WebSocket连接建立	info	\N	\N	\N
570	100100	\N	2026-06-27 07:50:23.602611	online	设备WebSocket连接建立	info	\N	\N	\N
571	100100	\N	2026-06-27 07:51:13.694582	offline	设备WebSocket断开连接	warning	\N	\N	\N
572	100100	\N	2026-06-27 07:51:15.346679	online	设备WebSocket连接建立	info	\N	\N	\N
573	100100	\N	2026-06-27 07:51:15.418615	online	设备WebSocket连接建立	info	\N	\N	\N
574	100100	\N	2026-06-27 08:01:57.496137	online	设备WebSocket连接建立	info	\N	\N	\N
575	100100	\N	2026-06-27 08:01:57.699739	online	设备WebSocket连接建立	info	\N	\N	\N
576	100100	\N	2026-06-27 08:01:57.841181	online	设备WebSocket连接建立	info	\N	\N	\N
577	100100	\N	2026-06-27 08:01:58.0048	online	设备WebSocket连接建立	info	\N	\N	\N
578	100100	\N	2026-06-27 08:01:58.141504	online	设备WebSocket连接建立	info	\N	\N	\N
579	100100	\N	2026-06-27 08:01:58.255142	online	设备WebSocket连接建立	info	\N	\N	\N
580	100100	\N	2026-06-27 08:01:58.365135	online	设备WebSocket连接建立	info	\N	\N	\N
581	100100	\N	2026-06-27 08:01:58.468565	online	设备WebSocket连接建立	info	\N	\N	\N
582	100100	\N	2026-06-27 08:01:58.591619	online	设备WebSocket连接建立	info	\N	\N	\N
583	100100	\N	2026-06-27 08:01:58.694783	online	设备WebSocket连接建立	info	\N	\N	\N
584	100100	\N	2026-06-27 08:01:58.773445	online	设备WebSocket连接建立	info	\N	\N	\N
585	100100	\N	2026-06-27 08:01:58.854365	online	设备WebSocket连接建立	info	\N	\N	\N
586	100100	\N	2026-06-27 08:01:58.936643	online	设备WebSocket连接建立	info	\N	\N	\N
587	100100	\N	2026-06-27 08:01:59.025577	online	设备WebSocket连接建立	info	\N	\N	\N
588	100100	\N	2026-06-27 08:01:59.139865	online	设备WebSocket连接建立	info	\N	\N	\N
589	100100	\N	2026-06-27 08:01:59.267478	online	设备WebSocket连接建立	info	\N	\N	\N
590	100100	\N	2026-06-27 08:01:59.370057	online	设备WebSocket连接建立	info	\N	\N	\N
591	100100	\N	2026-06-27 08:01:59.474922	online	设备WebSocket连接建立	info	\N	\N	\N
592	100100	\N	2026-06-27 08:01:59.600359	online	设备WebSocket连接建立	info	\N	\N	\N
593	100100	\N	2026-06-27 08:01:59.706794	online	设备WebSocket连接建立	info	\N	\N	\N
594	100100	\N	2026-06-27 08:01:59.848186	online	设备WebSocket连接建立	info	\N	\N	\N
595	100100	\N	2026-06-27 08:01:59.984033	online	设备WebSocket连接建立	info	\N	\N	\N
596	100100	\N	2026-06-27 08:02:00.100096	online	设备WebSocket连接建立	info	\N	\N	\N
597	100100	\N	2026-06-27 08:02:00.281605	online	设备WebSocket连接建立	info	\N	\N	\N
598	100100	\N	2026-06-27 08:02:00.404908	online	设备WebSocket连接建立	info	\N	\N	\N
599	100100	\N	2026-06-27 08:02:00.567731	online	设备WebSocket连接建立	info	\N	\N	\N
600	100100	\N	2026-06-27 08:02:00.677776	online	设备WebSocket连接建立	info	\N	\N	\N
601	100100	\N	2026-06-27 08:02:00.785178	online	设备WebSocket连接建立	info	\N	\N	\N
602	100100	\N	2026-06-27 08:02:00.904658	online	设备WebSocket连接建立	info	\N	\N	\N
603	100100	\N	2026-06-27 08:02:01.139699	online	设备WebSocket连接建立	info	\N	\N	\N
604	100100	\N	2026-06-27 08:02:01.268646	online	设备WebSocket连接建立	info	\N	\N	\N
605	100100	\N	2026-06-27 08:02:01.391763	online	设备WebSocket连接建立	info	\N	\N	\N
606	100100	\N	2026-06-27 08:02:01.520832	online	设备WebSocket连接建立	info	\N	\N	\N
607	100100	\N	2026-06-27 08:02:01.713331	online	设备WebSocket连接建立	info	\N	\N	\N
608	100100	\N	2026-06-27 08:02:01.877701	online	设备WebSocket连接建立	info	\N	\N	\N
609	100100	\N	2026-06-27 08:02:01.987966	online	设备WebSocket连接建立	info	\N	\N	\N
610	100100	\N	2026-06-27 08:02:02.099473	online	设备WebSocket连接建立	info	\N	\N	\N
611	100100	\N	2026-06-27 08:02:02.22473	online	设备WebSocket连接建立	info	\N	\N	\N
612	100100	\N	2026-06-27 08:02:02.358641	online	设备WebSocket连接建立	info	\N	\N	\N
613	100100	\N	2026-06-27 08:02:02.505784	online	设备WebSocket连接建立	info	\N	\N	\N
614	100100	\N	2026-06-27 08:02:02.631772	online	设备WebSocket连接建立	info	\N	\N	\N
615	100100	\N	2026-06-27 08:02:02.735229	online	设备WebSocket连接建立	info	\N	\N	\N
616	100100	\N	2026-06-27 08:02:02.909846	online	设备WebSocket连接建立	info	\N	\N	\N
617	100100	\N	2026-06-27 08:02:03.100049	online	设备WebSocket连接建立	info	\N	\N	\N
618	100100	\N	2026-06-27 08:02:03.259716	online	设备WebSocket连接建立	info	\N	\N	\N
619	100100	\N	2026-06-27 08:02:03.371661	online	设备WebSocket连接建立	info	\N	\N	\N
620	100100	\N	2026-06-27 08:02:03.503362	online	设备WebSocket连接建立	info	\N	\N	\N
621	100100	\N	2026-06-27 08:02:03.614068	online	设备WebSocket连接建立	info	\N	\N	\N
622	100100	\N	2026-06-27 08:02:03.742594	online	设备WebSocket连接建立	info	\N	\N	\N
623	100100	\N	2026-06-27 08:02:03.849478	online	设备WebSocket连接建立	info	\N	\N	\N
624	100100	\N	2026-06-27 08:02:03.952519	online	设备WebSocket连接建立	info	\N	\N	\N
625	100100	\N	2026-06-27 08:02:04.067065	online	设备WebSocket连接建立	info	\N	\N	\N
626	100100	\N	2026-06-27 08:02:04.188167	online	设备WebSocket连接建立	info	\N	\N	\N
627	100100	\N	2026-06-27 08:02:04.311739	online	设备WebSocket连接建立	info	\N	\N	\N
628	100100	\N	2026-06-27 08:02:04.444432	online	设备WebSocket连接建立	info	\N	\N	\N
629	100100	\N	2026-06-27 08:02:04.575747	online	设备WebSocket连接建立	info	\N	\N	\N
630	100100	\N	2026-06-27 08:02:04.662168	online	设备WebSocket连接建立	info	\N	\N	\N
631	100100	\N	2026-06-27 08:02:04.773007	online	设备WebSocket连接建立	info	\N	\N	\N
632	100100	\N	2026-06-27 08:02:04.904869	online	设备WebSocket连接建立	info	\N	\N	\N
633	100100	\N	2026-06-27 08:02:05.035603	online	设备WebSocket连接建立	info	\N	\N	\N
634	100100	\N	2026-06-27 08:02:05.151722	online	设备WebSocket连接建立	info	\N	\N	\N
635	100100	\N	2026-06-27 08:02:05.261679	online	设备WebSocket连接建立	info	\N	\N	\N
636	100100	\N	2026-06-27 08:02:05.358955	online	设备WebSocket连接建立	info	\N	\N	\N
637	100100	\N	2026-06-27 08:02:05.456372	online	设备WebSocket连接建立	info	\N	\N	\N
638	100100	\N	2026-06-27 08:02:05.591032	online	设备WebSocket连接建立	info	\N	\N	\N
639	100100	\N	2026-06-27 08:02:05.706154	online	设备WebSocket连接建立	info	\N	\N	\N
640	100100	\N	2026-06-27 08:02:05.828754	online	设备WebSocket连接建立	info	\N	\N	\N
641	100100	\N	2026-06-27 08:02:05.969284	online	设备WebSocket连接建立	info	\N	\N	\N
642	100100	\N	2026-06-27 08:02:06.085176	online	设备WebSocket连接建立	info	\N	\N	\N
643	100100	\N	2026-06-27 08:02:06.203122	online	设备WebSocket连接建立	info	\N	\N	\N
644	100100	\N	2026-06-27 08:02:06.463728	online	设备WebSocket连接建立	info	\N	\N	\N
645	100100	\N	2026-06-27 08:02:06.556779	online	设备WebSocket连接建立	info	\N	\N	\N
646	100100	\N	2026-06-27 08:02:06.694292	online	设备WebSocket连接建立	info	\N	\N	\N
647	100100	\N	2026-06-27 08:02:06.820348	online	设备WebSocket连接建立	info	\N	\N	\N
648	100100	\N	2026-06-27 08:02:07.784928	online	设备WebSocket连接建立	info	\N	\N	\N
649	100100	\N	2026-06-27 08:02:07.863227	online	设备WebSocket连接建立	info	\N	\N	\N
650	100100	\N	2026-06-27 08:07:08.834843	offline	设备WebSocket断开连接	warning	\N	\N	\N
651	100100	\N	2026-06-27 08:09:52.223981	online	设备WebSocket连接建立	info	\N	\N	\N
652	100100	\N	2026-06-27 08:09:52.295145	online	设备WebSocket连接建立	info	\N	\N	\N
653	100100	\N	2026-06-27 08:23:35.30851	offline	设备WebSocket断开连接	warning	\N	\N	\N
654	100100	\N	2026-06-27 08:23:37.990941	online	设备WebSocket连接建立	info	\N	\N	\N
655	100100	\N	2026-06-27 08:23:38.155039	online	设备WebSocket连接建立	info	\N	\N	\N
656	100100	\N	2026-06-27 08:23:38.296156	online	设备WebSocket连接建立	info	\N	\N	\N
657	100100	\N	2026-06-27 08:23:38.454977	online	设备WebSocket连接建立	info	\N	\N	\N
658	100100	\N	2026-06-27 08:23:38.604012	online	设备WebSocket连接建立	info	\N	\N	\N
659	100100	\N	2026-06-27 08:23:38.815946	online	设备WebSocket连接建立	info	\N	\N	\N
660	100100	\N	2026-06-27 08:23:39.000675	online	设备WebSocket连接建立	info	\N	\N	\N
661	100100	\N	2026-06-27 08:23:39.174236	online	设备WebSocket连接建立	info	\N	\N	\N
662	100100	\N	2026-06-27 08:23:39.383758	online	设备WebSocket连接建立	info	\N	\N	\N
663	100100	\N	2026-06-27 08:23:39.489247	online	设备WebSocket连接建立	info	\N	\N	\N
664	100100	\N	2026-06-27 08:23:39.594399	online	设备WebSocket连接建立	info	\N	\N	\N
665	100100	\N	2026-06-27 08:23:39.7237	online	设备WebSocket连接建立	info	\N	\N	\N
666	100100	\N	2026-06-27 08:23:39.854101	online	设备WebSocket连接建立	info	\N	\N	\N
667	100100	\N	2026-06-27 08:23:39.977666	online	设备WebSocket连接建立	info	\N	\N	\N
668	100100	\N	2026-06-27 08:23:40.078705	online	设备WebSocket连接建立	info	\N	\N	\N
669	100100	\N	2026-06-27 08:23:40.331062	online	设备WebSocket连接建立	info	\N	\N	\N
670	100100	\N	2026-06-27 08:23:40.475743	online	设备WebSocket连接建立	info	\N	\N	\N
671	100100	\N	2026-06-27 08:23:40.602833	online	设备WebSocket连接建立	info	\N	\N	\N
672	100100	\N	2026-06-27 08:23:40.741812	online	设备WebSocket连接建立	info	\N	\N	\N
673	100100	\N	2026-06-27 08:23:40.836207	online	设备WebSocket连接建立	info	\N	\N	\N
674	100100	\N	2026-06-27 08:23:40.979722	online	设备WebSocket连接建立	info	\N	\N	\N
675	100100	\N	2026-06-27 08:23:41.095083	online	设备WebSocket连接建立	info	\N	\N	\N
676	100100	\N	2026-06-27 08:23:41.205933	online	设备WebSocket连接建立	info	\N	\N	\N
677	100100	\N	2026-06-27 08:23:41.344735	online	设备WebSocket连接建立	info	\N	\N	\N
678	100100	\N	2026-06-27 08:23:41.443333	online	设备WebSocket连接建立	info	\N	\N	\N
679	100100	\N	2026-06-27 08:23:41.553562	online	设备WebSocket连接建立	info	\N	\N	\N
680	100100	\N	2026-06-27 08:23:41.673768	online	设备WebSocket连接建立	info	\N	\N	\N
681	100100	\N	2026-06-27 08:23:41.77857	online	设备WebSocket连接建立	info	\N	\N	\N
682	100100	\N	2026-06-27 08:23:41.929595	online	设备WebSocket连接建立	info	\N	\N	\N
683	100100	\N	2026-06-27 08:23:42.050001	online	设备WebSocket连接建立	info	\N	\N	\N
684	100100	\N	2026-06-27 08:23:42.23466	online	设备WebSocket连接建立	info	\N	\N	\N
685	100100	\N	2026-06-27 08:23:42.399422	online	设备WebSocket连接建立	info	\N	\N	\N
686	100100	\N	2026-06-27 08:23:42.588765	online	设备WebSocket连接建立	info	\N	\N	\N
687	100100	\N	2026-06-27 08:23:42.723485	online	设备WebSocket连接建立	info	\N	\N	\N
688	100100	\N	2026-06-27 08:23:42.875494	online	设备WebSocket连接建立	info	\N	\N	\N
689	100100	\N	2026-06-27 08:23:42.995333	online	设备WebSocket连接建立	info	\N	\N	\N
690	100100	\N	2026-06-27 08:23:43.165802	online	设备WebSocket连接建立	info	\N	\N	\N
691	100100	\N	2026-06-27 08:23:43.318945	online	设备WebSocket连接建立	info	\N	\N	\N
692	100100	\N	2026-06-27 08:23:43.461646	online	设备WebSocket连接建立	info	\N	\N	\N
693	100100	\N	2026-06-27 08:23:43.594468	online	设备WebSocket连接建立	info	\N	\N	\N
694	100100	\N	2026-06-27 08:23:43.727414	online	设备WebSocket连接建立	info	\N	\N	\N
695	100100	\N	2026-06-27 08:23:43.868522	online	设备WebSocket连接建立	info	\N	\N	\N
696	100100	\N	2026-06-27 08:23:43.986802	online	设备WebSocket连接建立	info	\N	\N	\N
697	100100	\N	2026-06-27 08:23:44.133328	online	设备WebSocket连接建立	info	\N	\N	\N
698	100100	\N	2026-06-27 08:23:44.311219	online	设备WebSocket连接建立	info	\N	\N	\N
699	100100	\N	2026-06-27 08:23:44.395277	online	设备WebSocket连接建立	info	\N	\N	\N
700	100100	\N	2026-06-27 08:23:44.515819	online	设备WebSocket连接建立	info	\N	\N	\N
701	100100	\N	2026-06-27 08:23:44.630371	online	设备WebSocket连接建立	info	\N	\N	\N
702	100100	\N	2026-06-27 08:23:44.747498	online	设备WebSocket连接建立	info	\N	\N	\N
703	100100	\N	2026-06-27 08:23:44.851667	online	设备WebSocket连接建立	info	\N	\N	\N
704	100100	\N	2026-06-27 08:23:44.977214	online	设备WebSocket连接建立	info	\N	\N	\N
705	100100	\N	2026-06-27 08:23:45.11169	online	设备WebSocket连接建立	info	\N	\N	\N
706	100100	\N	2026-06-27 08:23:45.239682	online	设备WebSocket连接建立	info	\N	\N	\N
707	100100	\N	2026-06-27 08:23:45.365178	online	设备WebSocket连接建立	info	\N	\N	\N
708	100100	\N	2026-06-27 08:23:45.599694	online	设备WebSocket连接建立	info	\N	\N	\N
709	100100	\N	2026-06-27 08:23:45.720672	online	设备WebSocket连接建立	info	\N	\N	\N
710	100100	\N	2026-06-27 08:23:45.827951	online	设备WebSocket连接建立	info	\N	\N	\N
711	100100	\N	2026-06-27 08:23:45.943701	online	设备WebSocket连接建立	info	\N	\N	\N
712	100100	\N	2026-06-27 08:23:46.069777	online	设备WebSocket连接建立	info	\N	\N	\N
713	100100	\N	2026-06-27 08:23:46.195741	online	设备WebSocket连接建立	info	\N	\N	\N
714	100100	\N	2026-06-27 08:23:46.314834	online	设备WebSocket连接建立	info	\N	\N	\N
715	100100	\N	2026-06-27 08:23:46.451758	online	设备WebSocket连接建立	info	\N	\N	\N
716	100100	\N	2026-06-27 08:23:46.582143	online	设备WebSocket连接建立	info	\N	\N	\N
717	100100	\N	2026-06-27 08:23:46.723743	online	设备WebSocket连接建立	info	\N	\N	\N
718	100100	\N	2026-06-27 08:23:46.851217	online	设备WebSocket连接建立	info	\N	\N	\N
719	100100	\N	2026-06-27 08:23:46.970207	online	设备WebSocket连接建立	info	\N	\N	\N
720	100100	\N	2026-06-27 08:23:47.09319	online	设备WebSocket连接建立	info	\N	\N	\N
721	100100	\N	2026-06-27 08:23:47.22376	online	设备WebSocket连接建立	info	\N	\N	\N
722	100100	\N	2026-06-27 08:23:47.347102	online	设备WebSocket连接建立	info	\N	\N	\N
723	100100	\N	2026-06-27 08:23:47.475693	online	设备WebSocket连接建立	info	\N	\N	\N
724	100100	\N	2026-06-27 08:23:47.593158	online	设备WebSocket连接建立	info	\N	\N	\N
725	100100	\N	2026-06-27 08:23:47.710336	online	设备WebSocket连接建立	info	\N	\N	\N
726	100100	\N	2026-06-27 08:23:47.813769	online	设备WebSocket连接建立	info	\N	\N	\N
727	100100	\N	2026-06-27 08:23:47.947972	online	设备WebSocket连接建立	info	\N	\N	\N
728	100100	\N	2026-06-27 08:23:48.07837	online	设备WebSocket连接建立	info	\N	\N	\N
729	100100	\N	2026-06-27 08:23:48.182899	online	设备WebSocket连接建立	info	\N	\N	\N
730	100100	\N	2026-06-27 08:23:48.29439	online	设备WebSocket连接建立	info	\N	\N	\N
731	100100	\N	2026-06-27 08:23:48.412279	online	设备WebSocket连接建立	info	\N	\N	\N
732	100100	\N	2026-06-27 08:23:48.523964	online	设备WebSocket连接建立	info	\N	\N	\N
733	100100	\N	2026-06-27 08:23:48.639665	online	设备WebSocket连接建立	info	\N	\N	\N
734	100100	\N	2026-06-27 08:23:48.768833	online	设备WebSocket连接建立	info	\N	\N	\N
735	100100	\N	2026-06-27 08:23:48.883477	online	设备WebSocket连接建立	info	\N	\N	\N
736	100100	\N	2026-06-27 08:23:48.99725	online	设备WebSocket连接建立	info	\N	\N	\N
737	100100	\N	2026-06-27 08:23:49.107058	online	设备WebSocket连接建立	info	\N	\N	\N
738	100100	\N	2026-06-27 08:23:49.242252	online	设备WebSocket连接建立	info	\N	\N	\N
739	100100	\N	2026-06-27 08:23:49.378329	online	设备WebSocket连接建立	info	\N	\N	\N
740	100100	\N	2026-06-27 08:23:49.517968	online	设备WebSocket连接建立	info	\N	\N	\N
741	100100	\N	2026-06-27 08:23:49.640669	online	设备WebSocket连接建立	info	\N	\N	\N
742	100100	\N	2026-06-27 08:23:49.761056	online	设备WebSocket连接建立	info	\N	\N	\N
743	100100	\N	2026-06-27 08:23:49.883683	online	设备WebSocket连接建立	info	\N	\N	\N
744	100100	\N	2026-06-27 08:23:50.030942	online	设备WebSocket连接建立	info	\N	\N	\N
745	100100	\N	2026-06-27 08:23:50.134167	online	设备WebSocket连接建立	info	\N	\N	\N
746	100100	\N	2026-06-27 08:23:50.255726	online	设备WebSocket连接建立	info	\N	\N	\N
747	100100	\N	2026-06-27 08:23:50.383712	online	设备WebSocket连接建立	info	\N	\N	\N
748	100100	\N	2026-06-27 08:23:50.491078	online	设备WebSocket连接建立	info	\N	\N	\N
749	100100	\N	2026-06-27 08:23:50.582219	online	设备WebSocket连接建立	info	\N	\N	\N
750	100100	\N	2026-06-27 08:23:50.698163	online	设备WebSocket连接建立	info	\N	\N	\N
751	100100	\N	2026-06-27 08:23:50.967209	online	设备WebSocket连接建立	info	\N	\N	\N
752	100100	\N	2026-06-27 08:23:51.106618	online	设备WebSocket连接建立	info	\N	\N	\N
753	100100	\N	2026-06-27 08:23:51.271823	online	设备WebSocket连接建立	info	\N	\N	\N
754	100100	\N	2026-06-27 08:23:51.443791	online	设备WebSocket连接建立	info	\N	\N	\N
755	100100	\N	2026-06-27 08:23:51.632587	online	设备WebSocket连接建立	info	\N	\N	\N
756	100100	\N	2026-06-27 08:23:52.196388	online	设备WebSocket连接建立	info	\N	\N	\N
757	100100	\N	2026-06-27 08:23:52.335703	online	设备WebSocket连接建立	info	\N	\N	\N
758	100100	\N	2026-06-27 08:41:57.529524	online	设备WebSocket连接建立	info	\N	\N	\N
759	100100	\N	2026-06-27 08:41:57.610579	online	设备WebSocket连接建立	info	\N	\N	\N
760	100100	\N	2026-06-27 08:46:21.239845	online	设备WebSocket连接建立	info	\N	\N	\N
761	100100	\N	2026-06-27 08:46:21.312773	online	设备WebSocket连接建立	info	\N	\N	\N
762	100100	\N	2026-06-27 08:48:52.389343	online	设备WebSocket连接建立	info	\N	\N	\N
763	100100	\N	2026-06-27 08:48:52.462133	online	设备WebSocket连接建立	info	\N	\N	\N
764	100100	\N	2026-06-27 08:50:49.520522	online	设备WebSocket连接建立	info	\N	\N	\N
765	100100	\N	2026-06-27 08:50:49.698649	online	设备WebSocket连接建立	info	\N	\N	\N
766	100100	\N	2026-06-27 08:51:39.122688	offline	设备WebSocket断开连接	warning	\N	\N	\N
767	100100	\N	2026-06-27 08:52:00.421699	online	设备WebSocket连接建立	info	\N	\N	\N
768	100100	\N	2026-06-27 08:52:00.572863	online	设备WebSocket连接建立	info	\N	\N	\N
769	100100	\N	2026-06-27 08:52:00.738695	online	设备WebSocket连接建立	info	\N	\N	\N
770	100100	\N	2026-06-27 08:52:00.930374	online	设备WebSocket连接建立	info	\N	\N	\N
771	100100	\N	2026-06-27 08:52:01.098709	online	设备WebSocket连接建立	info	\N	\N	\N
772	100100	\N	2026-06-27 08:52:01.259235	online	设备WebSocket连接建立	info	\N	\N	\N
773	100100	\N	2026-06-27 08:52:01.400896	online	设备WebSocket连接建立	info	\N	\N	\N
774	100100	\N	2026-06-27 08:52:01.569248	online	设备WebSocket连接建立	info	\N	\N	\N
775	100100	\N	2026-06-27 08:52:01.702029	online	设备WebSocket连接建立	info	\N	\N	\N
776	100100	\N	2026-06-27 08:52:01.8887	online	设备WebSocket连接建立	info	\N	\N	\N
777	100100	\N	2026-06-27 08:52:02.064501	online	设备WebSocket连接建立	info	\N	\N	\N
778	100100	\N	2026-06-27 08:52:02.218369	online	设备WebSocket连接建立	info	\N	\N	\N
779	100100	\N	2026-06-27 08:52:02.398658	online	设备WebSocket连接建立	info	\N	\N	\N
780	100100	\N	2026-06-27 08:52:02.573291	online	设备WebSocket连接建立	info	\N	\N	\N
781	100100	\N	2026-06-27 08:52:02.718611	online	设备WebSocket连接建立	info	\N	\N	\N
782	100100	\N	2026-06-27 08:52:02.868915	online	设备WebSocket连接建立	info	\N	\N	\N
783	100100	\N	2026-06-27 08:52:03.020824	online	设备WebSocket连接建立	info	\N	\N	\N
784	100100	\N	2026-06-27 08:52:03.214655	online	设备WebSocket连接建立	info	\N	\N	\N
785	100100	\N	2026-06-27 08:52:03.402656	online	设备WebSocket连接建立	info	\N	\N	\N
786	100100	\N	2026-06-27 08:52:03.556352	online	设备WebSocket连接建立	info	\N	\N	\N
787	100100	\N	2026-06-27 08:52:03.722712	online	设备WebSocket连接建立	info	\N	\N	\N
788	100100	\N	2026-06-27 08:52:03.887234	online	设备WebSocket连接建立	info	\N	\N	\N
789	100100	\N	2026-06-27 08:52:04.054655	online	设备WebSocket连接建立	info	\N	\N	\N
790	100100	\N	2026-06-27 08:52:04.222654	online	设备WebSocket连接建立	info	\N	\N	\N
791	100100	\N	2026-06-27 08:52:04.39467	online	设备WebSocket连接建立	info	\N	\N	\N
792	100100	\N	2026-06-27 08:52:04.564901	online	设备WebSocket连接建立	info	\N	\N	\N
793	100100	\N	2026-06-27 08:52:05.664309	online	设备WebSocket连接建立	info	\N	\N	\N
794	100100	\N	2026-06-27 08:52:05.755919	online	设备WebSocket连接建立	info	\N	\N	\N
795	100100	\N	2026-06-27 08:55:00.951488	offline	设备WebSocket断开连接	warning	\N	\N	\N
796	100100	\N	2026-06-27 08:55:02.807762	online	设备WebSocket连接建立	info	\N	\N	\N
797	100100	\N	2026-06-27 08:55:02.87911	online	设备WebSocket连接建立	info	\N	\N	\N
798	100100	\N	2026-06-27 08:55:14.788586	offline	设备WebSocket断开连接	warning	\N	\N	\N
799	100100	\N	2026-06-27 08:55:21.554363	online	设备WebSocket连接建立	info	\N	\N	\N
800	100100	\N	2026-06-27 08:55:21.62645	online	设备WebSocket连接建立	info	\N	\N	\N
801	100100	\N	2026-06-27 09:04:03.863715	offline	设备WebSocket断开连接	warning	\N	\N	\N
802	100100	\N	2026-06-27 09:04:10.566687	online	设备WebSocket连接建立	info	\N	\N	\N
803	100100	\N	2026-06-27 09:04:10.635507	online	设备WebSocket连接建立	info	\N	\N	\N
804	100100	\N	2026-06-27 09:07:05.773296	online	设备WebSocket连接建立	info	\N	\N	\N
805	100100	\N	2026-06-27 09:07:05.842667	online	设备WebSocket连接建立	info	\N	\N	\N
806	100100	\N	2026-06-27 09:07:41.158637	online	设备WebSocket连接建立	info	\N	\N	\N
807	100100	\N	2026-06-27 09:07:41.328407	online	设备WebSocket连接建立	info	\N	\N	\N
808	100100	\N	2026-06-27 09:11:17.032884	online	设备WebSocket连接建立	info	\N	\N	\N
809	100100	\N	2026-06-27 09:11:17.106342	online	设备WebSocket连接建立	info	\N	\N	\N
810	100100	\N	2026-06-27 09:14:03.864547	online	设备WebSocket连接建立	info	\N	\N	\N
811	100100	\N	2026-06-27 09:14:03.977787	online	设备WebSocket连接建立	info	\N	\N	\N
812	100100	\N	2026-06-27 09:14:53.140792	offline	设备WebSocket断开连接	warning	\N	\N	\N
813	100100	\N	2026-06-27 09:14:59.153499	online	设备WebSocket连接建立	info	\N	\N	\N
814	100100	\N	2026-06-27 09:14:59.224784	online	设备WebSocket连接建立	info	\N	\N	\N
815	100100	\N	2026-06-27 09:15:41.822782	online	设备WebSocket连接建立	info	\N	\N	\N
816	100100	\N	2026-06-27 09:15:41.892461	online	设备WebSocket连接建立	info	\N	\N	\N
817	100100	\N	2026-06-27 09:16:17.888262	online	设备WebSocket连接建立	info	\N	\N	\N
818	100100	\N	2026-06-27 09:16:17.957712	online	设备WebSocket连接建立	info	\N	\N	\N
819	100100	\N	2026-06-27 09:16:46.536239	offline	设备WebSocket断开连接	warning	\N	\N	\N
820	100100	\N	2026-06-27 09:16:52.597931	online	设备WebSocket连接建立	info	\N	\N	\N
821	100100	\N	2026-06-27 09:16:52.667865	online	设备WebSocket连接建立	info	\N	\N	\N
822	100100	\N	2026-06-27 09:19:16.410604	online	设备WebSocket连接建立	info	\N	\N	\N
823	100100	\N	2026-06-27 09:19:16.480169	online	设备WebSocket连接建立	info	\N	\N	\N
824	100100	\N	2026-06-27 09:19:41.007387	online	设备WebSocket连接建立	info	\N	\N	\N
825	100100	\N	2026-06-27 09:19:41.077839	online	设备WebSocket连接建立	info	\N	\N	\N
826	100100	\N	2026-06-27 09:20:01.283109	online	设备WebSocket连接建立	info	\N	\N	\N
827	100100	\N	2026-06-27 09:20:01.520093	online	设备WebSocket连接建立	info	\N	\N	\N
828	100100	\N	2026-06-27 09:25:39.500852	offline	设备WebSocket断开连接	warning	\N	\N	\N
829	100100	\N	2026-06-27 09:28:44.856743	online	设备WebSocket连接建立	info	\N	\N	\N
830	100100	\N	2026-06-27 09:28:44.927084	online	设备WebSocket连接建立	info	\N	\N	\N
831	101002	\N	2026-06-27 09:30:03.054066	online	设备WebSocket连接建立	info	\N	\N	\N
832	101002	\N	2026-06-27 09:30:03.44534	online	设备WebSocket连接建立	info	\N	\N	\N
833	100100	\N	2026-06-27 09:30:40.527159	offline	设备WebSocket断开连接	warning	\N	\N	\N
834	101002	\N	2026-06-27 09:32:44.997691	online	设备WebSocket连接建立	info	\N	\N	\N
835	101002	\N	2026-06-27 09:32:45.072307	online	设备WebSocket连接建立	info	\N	\N	\N
836	101002	\N	2026-06-27 09:33:32.203307	offline	设备WebSocket断开连接	warning	\N	\N	\N
837	100100	\N	2026-06-27 09:34:28.374679	online	设备WebSocket连接建立	info	\N	\N	\N
838	100100	\N	2026-06-27 09:34:28.450571	online	设备WebSocket连接建立	info	\N	\N	\N
839	100100	\N	2026-06-27 09:35:08.435515	offline	设备WebSocket断开连接	warning	\N	\N	\N
840	100100	\N	2026-06-27 09:35:10.18376	online	设备WebSocket连接建立	info	\N	\N	\N
841	100100	\N	2026-06-27 09:35:10.254397	online	设备WebSocket连接建立	info	\N	\N	\N
842	100100	\N	2026-06-27 09:44:33.582762	online	设备WebSocket连接建立	info	\N	\N	\N
843	100100	\N	2026-06-27 09:44:33.655708	online	设备WebSocket连接建立	info	\N	\N	\N
844	100100	\N	2026-06-27 09:56:33.481557	online	设备WebSocket连接建立	info	\N	\N	\N
845	100100	\N	2026-06-27 09:56:33.588043	online	设备WebSocket连接建立	info	\N	\N	\N
846	100100	\N	2026-06-27 09:56:44.130368	offline	设备WebSocket断开连接	warning	\N	\N	\N
847	100100	\N	2026-06-27 09:56:50.38847	online	设备WebSocket连接建立	info	\N	\N	\N
848	100100	\N	2026-06-27 09:56:50.457702	online	设备WebSocket连接建立	info	\N	\N	\N
849	100100	\N	2026-06-27 10:00:36.551863	online	设备WebSocket连接建立	info	\N	\N	\N
850	100100	\N	2026-06-27 10:00:36.691174	online	设备WebSocket连接建立	info	\N	\N	\N
851	100100	\N	2026-06-27 10:03:17.237719	online	设备WebSocket连接建立	info	\N	\N	\N
852	100100	\N	2026-06-27 10:03:17.52969	online	设备WebSocket连接建立	info	\N	\N	\N
853	100100	\N	2026-06-27 10:24:58.993539	online	设备WebSocket连接建立	info	\N	\N	\N
854	100100	\N	2026-06-27 10:24:59.248373	online	设备WebSocket连接建立	info	\N	\N	\N
855	100100	\N	2026-06-27 10:43:23.957255	online	设备WebSocket连接建立	info	\N	\N	\N
856	100100	\N	2026-06-27 10:43:24.025221	online	设备WebSocket连接建立	info	\N	\N	\N
\.


--
-- Data for Name: device_update_logs; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.device_update_logs (id, device_id, success, version_name, version_code, error_msg, created_at) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.devices (id, device_id, device_name, device_type, status, remark, update_time) FROM stdin;
\.


--
-- Data for Name: door_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.door_records (id, device_id, board_no, lock_no, order_id, open_type, create_time) FROM stdin;
1	TEST_DEVICE_001	1	1	1	remote	2026-06-17 09:19:40
2	DEV001	1	1	1	remote	2026-06-17 09:21:09
3	123456	1	5	test001	0	2026-06-17 20:35:12
4	123456	1	5	test001	0	2026-06-17 20:41:36
5	123456	0	0	\N	manual	2026-06-17 21:01:45
6	123456	0	0	\N	manual	2026-06-17 21:07:28
7	123456	0	0	\N	manual	2026-06-17 21:07:59
8	123456	0	0	\N	manual	2026-06-17 21:10:44
9	123456	1	10	\N	YBM	2026-06-24 03:44:42
10	123456	1	10	20260624114601985736	YBM	2026-06-24 03:46:09
11	123456	1	11	\N	YBM	2026-06-24 03:58:27
12	123456	1	10	20260624143247226180	YBM	2026-06-24 06:32:58
13	123456	1	10	196	YBM	2026-06-24 09:01:04
14	123456	1	10	196	YBM	2026-06-24 10:06:50
15	123456	1	1	\N	YBM	2026-06-24 10:07:01
16	123456	1	10	196	YBM	2026-06-24 10:07:52
17	123456	1	10	196	YBM	2026-06-24 12:09:09
18	123456	1	7	178	YBM	2026-06-24 12:18:03
19	123456	1	7	178	YBM	2026-06-24 12:20:52
20	123456	1	4	\N	YBM	2026-06-25 08:49:43
21	123456	1	12	269	YBM	2026-06-25 08:56:59
22	123456	2	1	\N	YBM	2026-06-25 09:42:12
23	123456	2	2	\N	YBM	2026-06-25 09:59:45
24	101002	2	17	278	YBM	2026-06-25 11:00:10
25	101002	2	17	278	YBM	2026-06-25 11:00:22
26	101002	2	17	278	YBM	2026-06-25 11:00:28
27	123456	2	18	277	YBM	2026-06-25 11:00:42
28	101002	1	1	\N	YBM	2026-06-25 11:21:09
29	101002	1	2	\N	YBM	2026-06-25 11:21:51
30	123456	2	21	283	YBM	2026-06-25 13:10:46
31	123456	2	22	284	YBM	2026-06-25 13:14:40
32	123456	2	22	284	YBM	2026-06-25 13:15:10
33	123456	2	22	284	YBM	2026-06-25 13:19:35
34	123456	2	22	284	YBM	2026-06-25 13:22:44
35	123456	2	22	284	YBM	2026-06-25 13:28:16
36	123456	2	22	284	YBM	2026-06-25 13:29:52
37	123456	2	21	283	YBM	2026-06-25 13:32:58
38	123456	2	21	283	YBM	2026-06-25 13:35:51
39	123456	1	A24	20260625214644063856	YBM	2026-06-25 13:50:24
40	101002	1	1	\N	YBM	2026-06-25 13:55:20
41	101002	1	1	\N	YBM	2026-06-25 13:57:27
42	101002	1	1	\N	YBM	2026-06-25 14:01:32
43	101002	1	1	\N	YBM	2026-06-25 14:01:33
44	101002	1	1	\N	YBM	2026-06-25 14:01:33
45	101002	1	1	\N	YBM	2026-06-25 14:01:42
46	101002	1	1	\N	YBM	2026-06-25 14:04:53
47	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
48	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
49	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
50	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
51	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
52	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
53	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
54	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
55	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
56	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
57	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
58	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
59	\N	1	1	\N	YBM	2026-06-25 14:14:33
60	123456	1	A29	20260625224205854601	YBM	2026-06-25 14:42:11
61	123456	1	A30	20260625224556086478	YBM	2026-06-25 14:46:02
62	123456	1	A30	20260625224556086478	YBM	2026-06-25 14:49:36
63	101002	1	1	\N	YBM	2026-06-25 14:50:04
64	101002	1	1	\N	YBM	2026-06-25 14:50:15
65	101002	1	1	\N	YBM	2026-06-25 14:50:39
66	101002	1	1	\N	YBM	2026-06-25 14:52:26
67	101002	1	1	\N	YBM	2026-06-25 14:52:32
68	101002	1	1	\N	YBM	2026-06-25 14:54:38
69	101002	1	1	\N	YBM	2026-06-25 14:54:46
70	101002	1	1	\N	YBM	2026-06-25 14:56:57
71	123456	1	A31	20260625230123439689	YBM	2026-06-25 15:01:31
72	123456	2	14	\N	YBM	2026-06-25 15:29:41
73	123456	1	A32	20260625233005853236	YBM	2026-06-25 15:30:11
74	123456	1	A33	20260625233407427886	YBM	2026-06-25 15:36:24
75	123456	1	A34	20260625234133881159	YBM	2026-06-25 15:41:41
76	123456	1	A34	20260625234133881159	YBM	2026-06-25 15:41:50
77	123456	1	A35	20260625234710366176	YBM	2026-06-25 15:47:15
78	123456	1	A35	20260625234710366176	YBM	2026-06-25 15:47:23
79	123456	1	A36	20260625234755209987	YBM	2026-06-25 15:48:02
80	123456	1	A36	20260625234755209987	YBM	2026-06-25 15:48:12
81	123456	1	A37	20260625235027193965	YBM	2026-06-25 15:50:39
82	123456	1	A38	20260625235218620187	YBM	2026-06-25 15:52:25
83	123456	1	A38	20260625235218620187	YBM	2026-06-25 15:52:35
84	123456	3	38	300	YBM	2026-06-25 22:27:51
85	123456	3	37	299	YBM	2026-06-25 22:27:56
86	123456	2	16	\N	YBM	2026-06-25 22:29:01
87	123456	3	1	\N	YBM	2026-06-25 22:29:17
88	123456	3	2	\N	YBM	2026-06-25 22:29:23
89	123456	3	3	\N	YBM	2026-06-25 22:29:27
90	123456	3	38	300	YBM	2026-06-25 22:29:40
91	123456	3	7	\N	YBM	2026-06-25 22:30:46
92	123456	3	6	\N	YBM	2026-06-25 22:30:50
93	123456	3	5	\N	YBM	2026-06-25 22:30:53
94	123456	3	16	\N	YBM	2026-06-25 22:31:51
95	123456	3	15	\N	YBM	2026-06-25 22:31:57
96	123456	3	16	\N	YBM	2026-06-25 22:32:00
97	123456	3	14	\N	YBM	2026-06-25 22:32:04
98	123456	3	7	\N	YBM	2026-06-25 22:39:13
99	123456	3	38	300	YBM	2026-06-25 22:57:09
100	123456	3	8	\N	YBM	2026-06-25 22:57:24
101	123456	3	38	300	YBM	2026-06-25 23:03:17
102	123456	3	8	\N	YBM	2026-06-25 23:11:40
103	123456	3	16	\N	YBM	2026-06-25 23:11:45
104	123456	3	38	300	YBM	2026-06-25 23:28:33
105	123456	3	8	\N	YBM	2026-06-25 23:36:02
106	101002	1	1	\N	YBM	2026-06-26 00:42:23
107	123456	1	1	\N	YBM	2026-06-26 00:47:02
108	123456	1	1	\N	YBM	2026-06-26 00:50:45
109	123456	3	12	20260626091635740650	YBM	2026-06-26 01:17:16
110	123456	3	12	20260626091635740650	YBM	2026-06-26 01:17:42
111	123456	1	1	\N	YBM	2026-06-26 01:34:58
112	123456	1	1	\N	YBM	2026-06-26 01:34:58
113	123456	1	1	\N	YBM	2026-06-26 01:34:58
114	123456	1	1	\N	YBM	2026-06-26 01:35:17
115	123456	1	3	\N	YBM	2026-06-26 01:35:20
116	123456	1	1	311	YBM	2026-06-26 01:35:37
117	123456	1	5	315	YBM	2026-06-26 01:49:04
118	123456	1	1	\N	YBM	2026-06-26 02:38:40
119	123456	1	5	315	YBM	2026-06-26 04:02:45
120	123456	1	6	316	YBM	2026-06-26 04:25:43
121	123456	1	6	316	YBM	2026-06-26 04:44:18
122	100100	1	1	\N	YBM	2026-06-26 06:42:11
123	100100	1	1	\N	YBM	2026-06-26 06:47:18
124	100100	1	1	\N	YBM	2026-06-26 07:02:50
125	100100	1	2	\N	YBM	2026-06-26 07:02:59
126	100100	1	1	\N	YBM	2026-06-26 07:42:26
127	100100	1	1	\N	YBM	2026-06-26 07:42:52
128	100100	1	1	\N	YBM	2026-06-26 07:42:54
129	100100	1	1	\N	YBM	2026-06-26 07:42:56
130	100100	1	1	\N	YBM	2026-06-26 07:42:58
131	100100	1	2	\N	YBM	2026-06-26 07:43:01
132	100100	2	14	\N	YBM	2026-06-26 07:43:04
133	100100	1	1	\N	YBM	2026-06-26 07:58:00
134	100100	1	1	\N	YBM	2026-06-26 07:58:02
135	100100	1	2	\N	YBM	2026-06-26 07:58:04
136	100100	2	6	20260626155413206167	YBM	2026-06-26 17:28:40.710572
137	100100	2	4	20260626152942192997	YBM	2026-06-26 17:34:14.772993
138	100100	2	22	332	YBM	2026-06-26 17:49:02.718622
139	100100	2	1		YBM	2026-06-26 18:00:47.295769
140	100100	2	2		YBM	2026-06-26 18:02:49.467996
141	100100	2	1		YBM	2026-06-26 18:03:04.705283
142	100100	2	1		YBM	2026-06-26 18:09:25.596607
143	100100	1	1		YBM	2026-06-26 19:31:03.002828
144	100100	2	1		YBM	2026-06-26 19:31:07.517309
145	100100	2	3		YBM	2026-06-26 19:47:07.679332
146	100100	2	3		YBM	2026-06-26 19:47:19.025095
147	100100	2	1		YBM	2026-06-26 19:51:55.631717
148	100100	1	13	20260626195241140324	YBM	2026-06-26 19:53:03.057647
149	100100	2	3		YBM	2026-06-26 19:54:39.222165
150	100100	1	15		YBM	2026-06-26 19:54:45.972923
151	100100	2	3		YBM	2026-06-26 19:54:50.09196
152	100100	1	1		YBM	2026-06-26 19:55:26.877275
153	100100	1	14	20260626203440517799	YBM	2026-06-26 20:35:02.323958
154	100100	2	15	20260626203849898493	YBM	2026-06-26 20:39:21.522362
155	100100	1	2	20260626211119806002	YBM	2026-06-26 21:11:38.372213
156	100100	1	3	20260626211337376195	YBM	2026-06-26 21:14:06.708637
157	100100	2	31	353	YBM	2026-06-27 06:34:58.789463
158	100100	1	3	359	YBM	2026-06-27 06:35:15.702873
159	100100	2	31	353	YBM	2026-06-27 06:35:29.634192
160	100100	1	1		YBM	2026-06-27 06:35:47.738114
161	100100	1	1		YBM	2026-06-27 06:36:00.46266
162	100100	1	3	359	YBM	2026-06-27 06:36:14.528238
163	100100	2	31	353	YBM	2026-06-27 06:54:21.404689
164	100100	1	14	352	YBM	2026-06-27 07:02:59.185218
165	100100	1	1		YBM	2026-06-27 07:07:46.902472
166	100100	1	1		YBM	2026-06-27 07:07:57.014345
167	100100	1	16		YBM	2026-06-27 07:08:03.732724
168	100100	1	2		YBM	2026-06-27 09:31:15.556471
169	100100	1	2		YBM	2026-06-27 09:34:43.595835
170	100100	1	1		YBM	2026-06-27 10:03:35.861388
171	100100	1	15		YBM	2026-06-27 10:03:41.127345
172	100100	2	3		YBM	2026-06-27 10:03:58.54928
173	100100	2	16		YBM	2026-06-27 10:04:08.616789
174	100100	3	10	20260627100422451091	YBM	2026-06-27 10:05:21.633816
175	101001	1	2		YBM	2026-06-27 11:17:24.079408
176	101001	1	2		YBM	2026-06-27 11:17:31.899584
177	101001	1	2		YBM	2026-06-27 11:17:51.953095
178	101001	1	2		YBM	2026-06-27 11:18:10.716614
179	101001	1	2		YBM	2026-06-27 11:18:32.624113
180	101001	1	2		YBM	2026-06-27 11:18:56.387405
181	101001	1	2		YBM	2026-06-27 11:20:28.725241
182	101001	1	10	20260627112151757434	YBM	2026-06-27 11:22:27.340018
183	101001	1	1		YBM	2026-06-27 11:24:21.089085
184	101001	1	1		YBM	2026-06-27 11:24:44.748915
185	101001	1	1		YBM	2026-06-27 11:25:12.138513
186	101001	1	2		YBM	2026-06-27 11:25:33.265636
187	101001	1	2		YBM	2026-06-27 11:27:03.102306
188	101001	1	2		YBM	2026-06-27 11:27:19.788709
189	101001	1	2		YBM	2026-06-27 11:34:39.256151
190	101001	1	2		YBM	2026-06-27 11:35:05.458595
191	101001	1	10		YBM	2026-06-27 11:36:49.927683
192	101001	1	1		YBM	2026-06-27 11:40:26.108381
193	101001	1	1		YBM	2026-06-27 11:40:35.477012
194	101001	1	11	20260627114452740267	WT	2026-06-27 11:45:25.258865
195	100100	1	1		YBM	2026-06-27 11:55:37.838345
196	100100	1	1		YBM	2026-06-27 11:55:46.097519
197	100100	1	1		YBM	2026-06-27 11:56:21.1827
198	100100	1	1		YBM	2026-06-27 11:59:35.726011
199	100100	1	1		YBM	2026-06-27 11:59:49.203863
200	100100	1	1		YBM	2026-06-27 11:59:55.794778
201	100100	1	10		YBM	2026-06-27 12:00:00.40752
202	100100	1	10		YBM	2026-06-27 12:00:04.742742
203	100100	1	2	20260627123001901085	YBM	2026-06-27 12:30:16.951011
204	100100	1	2	376	YBM	2026-06-27 12:30:23.812217
205	100100	1	2	376	YBM	2026-06-27 12:30:26.167561
206	100100	1	2	376	YBM	2026-06-27 12:30:27.454293
207	100100	1	2		YBM	2026-06-27 12:32:08.162881
208	101001	1	1		YBM	2026-06-27 14:00:41.503607
209	101001	1	1		YBM	2026-06-27 14:00:49.857725
210	101001	1	1		WT	2026-06-27 14:11:11.919237
211	101001	1	1		WT	2026-06-27 14:12:07.737293
212	101001	1	1		WT	2026-06-27 14:13:03.612532
213	101001	1	1		WT	2026-06-27 14:19:48.883615
214	100100	1	2	376	YBM	2026-06-27 14:27:59.811893
215	100100	1	2	376	YBM	2026-06-27 14:28:06.976602
216	101001	1	1		WT	2026-06-27 14:31:38.577035
217	101001	1	1		WT	2026-06-27 14:42:31.79207
218	101001	1	1		WT	2026-06-27 14:42:43.862746
219	101001	1	1		WT	2026-06-27 15:15:32.363497
220	101001	1	1		WT	2026-06-27 15:17:30.738994
221	101001	1	1		WT	2026-06-27 15:17:47.889182
222	101001	1	1		WT	2026-06-27 15:36:38.798084
223	101001	1	1		WT	2026-06-27 15:36:45.365057
224	101001	1	1		WT	2026-06-27 15:43:06.498132
225	100100	1	5	20260627155423256198	YBM	2026-06-27 15:54:39.124728
226	100100	1	5	379	YBM	2026-06-27 15:54:46.83573
227	100100	1	6	20260627160102439699	YBM	2026-06-27 16:01:17.988511
228	100100	1	6	380	YBM	2026-06-27 16:01:24.254021
229	100100	1	6	380	YBM	2026-06-27 16:01:25.896282
230	100100	1	7	20260627160609859877	YBM	2026-06-27 16:06:33.798075
231	100100	1	8	20260627161116110216	YBM	2026-06-27 16:11:33.424228
232	100100	1	8	382	YBM	2026-06-27 16:11:39.849037
233	100100	1	8	382	YBM	2026-06-27 16:11:42.765564
234	100100	1	10	20260627163808998198	YBM	2026-06-27 16:38:26.541136
235	101001	1	2	20260627180155088478	WT	2026-06-27 18:02:24.794482
236	101001	1	3	20260627180357317523	WT	2026-06-27 18:04:23.777241
237	101001	1	1		WT	2026-06-27 22:44:59.317513
238	100100	1	14	20260628075013324398	YBM	2026-06-28 07:50:38.579811
239	101001	1	4	20260628082951623603	WT	2026-06-28 08:30:08.597418
240	101001	1	5	20260628083429993292	WT	2026-06-28 08:35:13.974034
241	100100	2	2	20260628084105846088	YBM	2026-06-28 08:41:27.75471
242	100100	2	3	20260628084559522187	YBM	2026-06-28 08:46:21.766696
243	101001	1	1		WT	2026-06-28 09:01:48.235463
244	101001	1	1		WT	2026-06-28 09:02:21.852486
245	101001	1	1		WT	2026-06-28 09:07:42.869597
246	100100	2	5	20260628093341461556	YBM	2026-06-28 09:34:39.713336
247	100100	2	6	20260628093722986540	YBM	2026-06-28 09:37:42.669354
248	100100	2	7	20260628094511242522	YBM	2026-06-28 09:45:59.483708
249	101001	1	1		WT	2026-06-28 11:01:38.682996
250	101001	1	1	test_wt_v2_0628	WT	2026-06-28 11:32:52.464013
251	101001	1	1		WT	2026-06-28 11:33:56.440954
252	101001	1	1		WT	2026-06-28 11:35:49.499495
253	100100	2	9	20260628145155650131	YBM	2026-06-28 14:52:23.335601
254	100100	2	9	405	YBM	2026-06-28 14:52:35.242697
255	100100	2	11	20260628152256512875	YBM	2026-06-28 15:23:20.170806
256	100100	2	12	20260628152957019526	YBM	2026-06-28 15:30:18.667362
257	100100	2	1		YBM	2026-06-29 14:10:11.930726
258	100100	2	16		YBM	2026-06-29 14:10:25.993702
259	100100	1	1		YBM	2026-06-29 14:27:08.907076
260	100100	1	16		YBM	2026-06-29 14:27:13.153185
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.employees (id, merchant_id, name, phone, password_hash, role, status, created_at, auth_token, permissions, login_attempts, is_locked, plain_password) FROM stdin;
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.locations (id, merchant_id, name, address, longitude, latitude, status, created_at, withdraw_enabled, auto_approve_day, auto_approve_time, auto_approve_rate, click_free_count, anti_test_minutes, anti_test_auto_refund, hide_ratio, whitelist_phones, duplicate_filter_enabled, duplicate_filter_days, duplicate_filter_limit, show_refunding_status, refund_approve_rate, refund_approve_start_min, refund_approve_end_min, contact_phone, open_time, close_time, allow_slot_select, slot_assign_mode, allow_mid_retrieve, retrieve_mode, allow_h5_to_mp, show_qr_follow, force_follow_mp, h5_url, show_slot_count, screen_show_title, screen_title, slot_full_alert, slot_full_text, end_alert_minutes, enable_clear_box, clear_box_time, clear_box_cycle, deposit_random, deposit_min, deposit_max, contact_name, refund_mode, withdraw_mode, province, agent_id, city, usage_rules, deposit_amount, mp_appid) FROM stdin;
4	1	测试网点_修改测试	新地址	\N	\N	1	2026-06-12 05:12:41	1	1	12:00	80	3	30	1	30	13900139000	0	7	3	1	80	60	300	\N	08:00	22:00	0	auto	1	both	1	0	0	\N	0	1	\N	0	\N	0	0	23:00	1	0	0	0	1895588779	auto_approve	auto_approve	\N	\N	\N	test rules for locker	20	
6	4	淮海考场	河南商丘市	\N	\N	1	2026-06-25 09:24:57	1	1	12:00	80	3	30	1	0	\N	0	7	3	1	80	60	300	139000000000	08:00	22:00	0	auto	1	both	1	0	0	\N	1	1	\N	0	\N	0	0	23:00	1	0	0	0	李	auto_approve	auto_approve	\N	\N	\N	\N	20	
\.


--
-- Data for Name: mainboards; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.mainboards (id, cabinet_id, board_index, slot_count, name, created_at, serial_port, baud_rate, address, board_type, protocol) FROM stdin;
1	2	1	24	主板1	2026-06-13 09:06:31	ttyS1	9600	\N	main	YBM
2	2	2	20	主板2	2026-06-13 09:06:35	ttyS1	9600	\N	main	YBM
3	3	1	12	主板1	2026-06-13 12:39:42	ttyS1	9600	\N	main	YBM
4	5	1	24	主板1	2026-06-14 14:39:36	ttyS1	9600	\N	main	YBM
13	9	1	12	\N	2026-06-16 14:16:02	ttyS1	9600	\N	main	YBM
14	10	1	12	\N	2026-06-16 22:59:14	ttyS4	9600	\N	main	YBM
15	11	1	12	\N	2026-06-16 22:59:42	ttyS3	115200	\N	main	WT
17	13	1	12	\N	2026-06-17 13:59:08	ttyS4	9600	\N	main	YBM
18	14	1	12	\N	2026-06-17 15:08:06	ttyS4	9600	\N	main	YBM
6	8	1	24	主板1	2026-06-15 01:53:20	ttyS4	9600	01	main	WT
10	8	2	24	主板2	2026-06-16 06:38:59	ttyS4	9600	02	main	WT
11	8	3	4	主板3	2026-06-16 07:36:30	ttyS4	9600	03	main	WT
36	15	1	16	\N	2026-06-28 07:19:10.849061	ttyS3	115200		main	WT
33	16	1	24	\N	2026-06-26 02:05:06	ttyS4	9600	\N	main	YBM
34	16	2	24	\N	2026-06-26 02:05:06	ttyS4	9600	\N	main	YBM
35	16	3	24	\N	2026-06-26 02:05:06	ttyS4	9600	\N	main	YBM
\.


--
-- Data for Name: merchants; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.merchants (id, name, contact_name, contact_phone, password_hash, status, created_at, agent_id, auth_token, permissions, login_attempts, is_locked, plain_password, commission_per_order) FROM stdin;
2	自动密码商家	自动密码商家	13900004444	scrypt:32768:8:1$NMu4ywIhvVFRlw56$3967b2c9c47c8888e4f814aee04279e01a12f088f9cd4ac6aaaeb64a640bfd2947c143cf48659eb083f899c8f43d9eef600b6429eef9f318481200fd3b2e7d23	1	2026-06-23 08:51:37	1	\N	[]	0	0		0.00
4	淮海驾校	李	139000000000	scrypt:32768:8:1$2BY3G5zXtvLWzkmw$c81063a1364f950657edc66ca31291ce03865123b8570c5989377531c1b4740d696a5f26ff5dc2b86d8b30f2b1db56eb6a18d5f36f8011cb1341c28b93fab1df	1	2026-06-25 09:23:45	1	\N	[]	0	0		0.00
1	王	\N	13667618419	scrypt:32768:8:1$HvJPuR08ieE00pj5$e3a60c8b4c645b32a19911ae9e06010cbc0df8df1db94bcc8774b27990a10cf4684031c98a3d8291fe874d18886d58fbc6633d1366c5a9902f2b1f11ec7d9165	1	2026-06-11 05:56:47	1	9a7eab8d94c7953efb4838feeff1959b	["dashboard","locations","devices","orders","statistics","withdrawal","alerts","merchant_manage","full_data"]	0	0		0.00
\.


--
-- Data for Name: offline_retrieve_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.offline_retrieve_records (id, order_no, retrieve_code, cabinet_id, slot_id, slot_number, retrieved_at, synced, uploaded) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.orders (id, order_no, user_phone, slot_id, cabinet_id, compartment_number, access_code, deposit_amount, status, store_time, retrieve_time, created_at, group_id, cabinet_code, cabinet_name, slot_size, transaction_id, refund_id, pay_time, refund_time, payment_channel_id, refund_mark, refund_status, refund_amount, logical_mark, logic_mark, logic_hide, note, admin_remark, pickup_time, updated_at, openid) FROM stdin;
1	20260611164651223263	13900001111	1	1	1	1234	20	6	2026-06-11 16:46:51.161898	2026-06-22 11:02:45.653043	2026-06-11 08:46:51	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
2	20260612123114733747	13800138000	1	1	1	1234	20	5	2026-06-12 12:31:14.192499	\N	2026-06-12 04:31:14	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
3	20260612123727077142	13811112222	1	1	1	6666	20	5	2026-06-12 12:37:27.81512	\N	2026-06-12 04:37:27	\N	\N	\N	\N	MOCK20260612123731687721	\N	2026-06-12 12:37:31.594703	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
4	20260612124106814078	13833334444	2	1	2	8888	20	5	2026-06-12 12:41:06.648616	\N	2026-06-12 04:41:06	\N	\N	\N	\N	MOCK20260612124112354956	\N	2026-06-12 12:41:12.466456	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
6	20260612125720101658	13855556666	3	1	3	5555	20	5	2026-06-12 12:57:20.93579	\N	2026-06-12 04:57:20	\N	\N	\N	\N	MOCK20260612125721052779	\N	2026-06-12 12:57:21.097809	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
7	20260612125750915588	13800001111	4	1	4	1111	20	5	2026-06-12 12:57:50.149594	\N	2026-06-12 04:57:50	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
380	20260627160102439699	18888889999	500	16	6	1234	20	2	2026-06-27 16:01:02.420536	\N	2026-06-27 16:01:02.416518	\N	\N	\N	\N	4200003186202606272613703359	\N	2026-06-27 16:01:17.946145	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
10	20260612215047522854	13667618419	4	1	4	1234	20	5	2026-06-12 21:50:47.092037	\N	2026-06-12 13:50:47	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
11	20260612215049196096	13667618419	4	1	4	1234	20	5	2026-06-12 21:50:49.478714	\N	2026-06-12 13:50:49	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
12	20260612215241961752	13667618419	4	1	4	1234	20	5	2026-06-12 21:52:41.378657	\N	2026-06-12 13:52:41	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
13	20260612215243412736	13667618419	4	1	4	1234	20	5	2026-06-12 21:52:43.190793	\N	2026-06-12 13:52:43	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
14	20260612220410413004	13667618419	4	1	4	1234	20	5	2026-06-12 22:04:10.832917	\N	2026-06-12 14:04:10	\N	\N	\N	\N	MOCK20260612220412535185	\N	2026-06-12 22:04:12.482515	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
15	20260612220646836729	13667619418	5	1	5	1234	20	5	2026-06-12 22:06:46.722765	\N	2026-06-12 14:06:46	\N	\N	\N	\N	MOCK20260612220648303668	\N	2026-06-12 22:06:48.35446	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
16	20260612221713749602	13667619418	6	1	6	1234	20	5	2026-06-12 22:17:13.723193	\N	2026-06-12 14:17:13	\N	\N	\N	\N	MOCK20260612221715620901	\N	2026-06-12 22:17:15.374401	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
17	20260613070525557123	13667618419	7	1	7	1234	20	5	2026-06-13 07:05:25.574644	\N	2026-06-12 23:05:25	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
18	20260613071529364557	13667619418	7	1	7	1234	20	5	2026-06-13 07:15:29.564058	\N	2026-06-12 23:15:29	\N	\N	\N	\N	MOCK20260613071531279605	\N	2026-06-13 07:15:31.12188	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
19	20260613084316775983	13667618419	8	1	8	1234	20	5	2026-06-13 08:43:16.360938	\N	2026-06-13 00:43:16	\N	\N	\N	\N	MOCK20260613084317461012	\N	2026-06-13 08:43:17.926972	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
20	20260613084722495070	13667618419	9	1	9	1234	20	5	2026-06-13 08:47:22.984184	\N	2026-06-13 00:47:22	\N	\N	\N	\N	MOCK20260613084724403496	\N	2026-06-13 08:47:24.553551	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
21	20260613084812016560	18996093393	10	1	10	1234	20	5	2026-06-13 08:48:12.982301	\N	2026-06-13 00:48:12	\N	\N	\N	\N	MOCK20260613084814527585	\N	2026-06-13 08:48:14.541599	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
22	20260613084905903310	18996093393	11	1	11	1234	20	5	2026-06-13 08:49:05.895363	\N	2026-06-13 00:49:05	\N	\N	\N	\N	MOCK20260613084907298375	\N	2026-06-13 08:49:07.467623	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
23	20260613085201409181	18996093393	12	1	12	1234	20	5	2026-06-13 08:52:01.526147	\N	2026-06-13 00:52:01	\N	\N	\N	\N	MOCK20260613085203062507	\N	2026-06-13 08:52:03.085261	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
24	20260613092059472982	13667618419	1	1	1	1234	20	5	2026-06-13 09:20:59.159071	\N	2026-06-13 01:20:59	\N	\N	\N	\N	MOCK20260613092100550571	\N	2026-06-13 09:21:00.710869	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
25	20260613103518582221	13667618419	2	1	2	1234	20	4	2026-06-13 10:35:18.188338	2026-06-18 16:24:07.583328	2026-06-13 02:35:18	\N	\N	\N	\N	MOCK20260613103519579330	\N	2026-06-13 10:35:19.76699	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
26	20260613103608102085	13667618419	3	1	3	1234	20	5	2026-06-13 10:36:08.034442	2026-06-20 07:45:34	2026-06-13 02:36:08	\N	\N	\N	\N	MOCK20260613103609423697	\N	2026-06-13 10:36:09.620615	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
27	20260613103836064964	13667618419	4	1	4	1234	20	5	2026-06-13 10:38:36.153748	2026-06-20 07:45:34	2026-06-13 02:38:36	\N	\N	\N	\N	MOCK20260613103837623027	\N	2026-06-13 10:38:37.746003	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
28	20260613103956052882	18996093393	5	1	5	1234	20	3	2026-06-13 10:39:56.434611	2026-06-13 10:40:52.646938	2026-06-13 02:39:56	\N	\N	\N	\N	MOCK20260613103958690879	\N	2026-06-13 10:39:58.025961	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
29	20260613105400223433	13667618419	5	1	5	1234	20	4	2026-06-13 10:54:00.714045	2026-06-20 07:28:37.901891	2026-06-13 02:54:00	\N	\N	\N	\N	MOCK20260613105402524401	\N	2026-06-13 10:54:02.304042	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
30	20260613105455853270	13667618419	6	1	6	1245	20	4	2026-06-13 10:54:55.784146	2026-06-20 07:28:42.627193	2026-06-13 02:54:55	\N	\N	\N	\N	MOCK20260613105457264570	\N	2026-06-13 10:54:57.370452	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
31	20260613110035310163	13667618419	7	1	7	1245	20	5	2026-06-13 11:00:35.50103	2026-06-20 07:45:34	2026-06-13 03:00:35	\N	\N	\N	\N	MOCK20260613110037508854	\N	2026-06-13 11:00:37.0886	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
32	20260613110923352760	13667618491	8	1	8	1234	20	5	2026-06-13 11:09:23.383141	2026-06-20 07:45:34	2026-06-13 03:09:23	\N	\N	\N	\N	MOCK20260613110924025926	\N	2026-06-13 11:09:24.983525	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
33	20260613111339242608	13667618419	9	1	9	1234	20	4	2026-06-13 11:13:39.831526	2026-06-20 07:28:30.680119	2026-06-13 03:13:39	\N	\N	\N	\N	MOCK20260613111341731060	\N	2026-06-13 11:13:41.426004	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
34	20260613111950247604	13667618419	10	1	10	1234	20	4	2026-06-13 11:19:50.101529	2026-06-20 07:28:25.534453	2026-06-13 03:19:50	\N	\N	\N	\N	MOCK20260613111951029532	\N	2026-06-13 11:19:51.705278	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
35	20260613112009044932	13667618419	11	1	11	1234	20	6	2026-06-13 11:20:09.3219	2026-06-13 16:54:54.138127	2026-06-13 03:20:09	\N	\N	\N	\N	MOCK20260613112010821772	\N	2026-06-13 11:20:10.929253	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
36	20260613112745200041	13667618419	12	1	12	1234	20	5	2026-06-13 11:27:45.113944	\N	2026-06-13 03:27:45	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
37	20260613112747117782	13667618419	12	1	12	1234	20	5	2026-06-13 11:27:47.536917	\N	2026-06-13 03:27:47	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
38	20260613121913870418	13667618419	12	1	12	1234	20	5	2026-06-13 12:19:13.615272	\N	2026-06-13 04:19:13	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
39	20260613122824572046	13667618419	12	1	12	1234	20	5	2026-06-13 12:28:24.017606	\N	2026-06-13 04:28:24	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
40	20260613122900360737	13667164843	12	1	12	1234	20	5	2026-06-13 12:29:00.764583	\N	2026-06-13 04:29:00	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
41	20260613130407011443	13667618419	12	1	12	1234	20	5	2026-06-13 13:04:07.511063	\N	2026-06-13 05:04:07	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
42	20260613130820751960	13667618419	12	1	12	1234	20	5	2026-06-13 13:08:20.736987	\N	2026-06-13 05:08:20	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
43	20260613130825632693	13667618419	12	1	12	1234	20	5	2026-06-13 13:08:25.150539	\N	2026-06-13 05:08:25	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
44	20260613131835570416	13667618419	12	1	12	1234	20	5	2026-06-13 13:18:35.510589	\N	2026-06-13 05:18:35	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
384	20260627163808998198	18888889999	504	16	10	1234	20	2	2026-06-27 16:38:08.255333	\N	2026-06-27 16:38:08.251689	\N	\N	\N	\N	4200003137202606271203499467	\N	2026-06-27 16:38:26.498928	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
388	20260628072555783397	18888889999	506	16	12	1234	20	5	2026-06-28 07:25:55.756408	\N	2026-06-28 07:25:55.752303	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
45	20260613131840461338	13667618419	12	1	12	1234	20	5	2026-06-13 13:18:40.783496	\N	2026-06-13 05:18:40	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
46	20260613133703359745	13667618419	12	1	12	1234	20	5	2026-06-13 13:37:03.055746	\N	2026-06-13 05:37:03	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
47	20260613133909419178	13667618419	12	1	12	1234	20	5	2026-06-13 13:39:09.640321	\N	2026-06-13 05:39:09	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
48	20260613133924649812	13667618419	12	1	12	1234	20	5	2026-06-13 13:39:24.861452	\N	2026-06-13 05:39:24	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
49	20260613134749013842	13667618419	12	1	12	1234	20	5	2026-06-13 13:47:49.703254	\N	2026-06-13 05:47:49	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
50	20260613134850334364	13667618419	12	1	12	1234	20	5	2026-06-13 13:48:50.92085	\N	2026-06-13 05:48:50	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
322	20260626143108074975	18888889999	456	8	10	1234	20	5	2026-06-26 14:31:08.770084	\N	2026-06-26 06:31:08	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
303	20260626070425643415	17726689234	\N	8	A41	1234	20	3	2026-06-26 07:04:25.78776	2026-06-26 07:07:47	2026-06-25 23:04:25	\N	\N	\N	\N	4200003184202606262064245079	\N	2026-06-26 07:06:32.966761	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
308	20260626091635740650	13800138099	\N	8	A44	6190	20	5	2026-06-26 09:16:35.183113	\N	2026-06-26 01:16:35	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
310	20260626092711160596	18896963355	\N	8	A45	1234	20	2	2026-06-26 09:27:11.556338	\N	2026-06-26 01:27:11	\N	\N	\N	\N	4200003125202606267155536409	\N	2026-06-26 09:27:18.112181	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
311	20260626093121031571	18896963355	447	8	1	1472	20	2	2026-06-26 09:31:21.065921	\N	2026-06-26 01:31:21	\N	\N	\N	\N	4200003129202606262955618549	\N	2026-06-26 09:34:58.933456	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
320	20260626140617450909	18888889999	455	8	9	1234	20	5	2026-06-26 14:06:17.38877	\N	2026-06-26 06:06:17	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
324	20260626143656327539	18888889999	457	8	11	2222	20	5	2026-06-26 14:36:56.063012	\N	2026-06-26 06:36:56	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
381	20260627160609859877	18888889999	501	16	7	1234	20	2	2026-06-27 16:06:09.568076	\N	2026-06-27 16:06:09.564124	\N	\N	\N	\N	4200003194202606274482878253	\N	2026-06-27 16:06:33.756775	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
398	20260628093340043922	18888889999	514	16	20	1234	20	5	2026-06-28 09:33:40.390696	\N	2026-06-28 09:33:40.386839	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
389	20260628074940785789	18888889999	507	16	13	1234	20	5	2026-06-28 07:49:40.541368	\N	2026-06-28 07:49:40.537811	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
385	20260627180155088478	18996093393	464	15	2	1111	1	3	2026-06-27 18:01:55.789566	2026-06-28 08:30:57.233902	2026-06-27 18:01:55.784048	\N	\N	\N	\N	4200003215202606279493063491	\N	2026-06-27 18:02:24.752173	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
393	20260628083429993292	18983079797	467	15	5	1111	1	2	2026-06-28 08:34:29.816315	\N	2026-06-28 08:34:29.81235	\N	\N	\N	\N	4200003127202606285009377611	\N	2026-06-28 08:35:13.935168	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
395	20260628084040740119	17722332233	511	16	17	2354	20	5	2026-06-28 08:40:40.59985	\N	2026-06-28 08:40:40.596079	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
299	20260625235027193965	17725196748	\N	8	A37	2588	20	4	2026-06-25 23:50:27.826689	2026-06-26 09:25:55	2026-06-25 15:50:27	\N	\N	\N	\N	\N	\N	2026-06-25 23:50:39.600723	\N	1	0	none	0	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N
300	20260625235218620187	17725196748	\N	8	A38	1475	20	4	2026-06-25 23:52:18.95125	2026-06-26 09:25:55	2026-06-25 15:52:18	\N	\N	\N	\N	\N	\N	2026-06-25 23:52:25.211139	\N	1	0	none	0	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N
301	20260626062352442950	17725196748	\N	8	A39	1234	20	4	2026-06-26 06:23:52.388604	2026-06-26 09:25:55	2026-06-25 22:23:52	\N	\N	\N	\N	4200003126202606266486005168	\N	2026-06-26 06:26:00.886014	\N	1	0	none	0	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N
302	20260626065241645773	17725196748	\N	8	A40	1234	20	4	2026-06-26 06:52:41.110615	2026-06-26 09:25:55	2026-06-25 22:52:41	\N	\N	\N	\N	4200003206202606266399413240	\N	2026-06-26 06:56:19.145714	\N	1	0	none	0	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N
306	20260626070704844022	17726689234	\N	8	A42	1234	20	4	2026-06-26 07:07:04.286167	2026-06-26 09:25:55	2026-06-25 23:07:04	\N	\N	\N	\N	4200003222202606267015269936	\N	2026-06-26 07:10:42.381455	\N	1	0	none	0	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N
317	20260626131340677421	18888889999	453	8	7	1234	20	3	2026-06-26 13:13:40.256117	2026-06-26 13:13:40.256117	2026-06-26 05:13:40	\N	\N	\N	\N	4200003204202606269502378651	\N	2026-06-26 13:15:47.744732	\N	1	0	none	0	N	Y	\N	\N	\N	\N	\N	\N
312	20260626093458449115	18888889999	448	8	2	1472	20	4	2026-06-26 09:34:58.429982	2026-06-26 09:35:30	2026-06-26 01:34:58	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	2026-06-26 09:35:30	2026-06-26 09:35:30	\N
318	20260626135530670593	18888889999	454	8	8	2584	20	4	2026-06-26 13:55:30.485465	2026-06-26 06:54:23	2026-06-26 05:55:30	\N	\N	\N	\N	4200003189202606260554928901	50302107622026062666051552700	2026-06-26 13:57:38.738504	2026-06-26 06:54:23	1	0	none	0	N	Y	\N	\N	\N	\N	\N	\N
405	20260628145155650131	18888889999	519	16	25	1234	20	3	2026-06-28 14:51:55.54862	\N	2026-06-28 14:51:55.544538	\N	\N	\N	\N	4200003187202606285994990390	\N	2026-06-28 14:52:23.293635	\N	\N	0	none	20	N	N	\N	\N	\N	\N	\N	
307	20260626073004388401	17726689234	\N	8	A43	1234	20	4	2026-06-26 07:30:04.21892	2026-06-26 09:25:55	2026-06-25 23:30:04	\N	\N	\N	\N	4200003135202606260982950090	\N	2026-06-26 07:31:20.124597	\N	1	0	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N
401	20260628094511242522	18888889999	517	16	23	1234	20	3	2026-06-28 09:45:11.146479	2026-06-28 17:48:14	2026-06-28 09:45:11.142633	\N	\N	\N	\N	4200003205202606284880898631	\N	2026-06-28 09:45:59.44543	\N	\N	0	none	0	N	\N	\N	\N	\N	2026-06-28 17:48:14	2026-06-28 17:48:14	
315	20260626094615190546	18888889999	451	8	5	5555	20	4	2026-06-26 09:46:15.591414	2026-06-26 02:48:20	2026-06-26 01:46:15	\N	\N	\N	\N	4200003184202606264338045728	50300807642026062648651889940	2026-06-26 09:46:21.93903	2026-06-26 02:48:20	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
316	20260626094918519644	18888889999	452	8	6	1234	20	4	2026-06-26 09:49:18.491913	2026-06-26 04:04:47	2026-06-26 01:49:18	\N	\N	\N	\N	4200003183202606260475366817	50301707452026062667399424477	2026-06-26 10:53:39.424639	2026-06-26 04:04:47	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
408	20260628152957019526	17722332233	522	16	28	2584	20	3	2026-06-28 15:29:57.720409	\N	2026-06-28 15:29:57.716683	\N	\N	\N	\N	4200003133202606283862175972	\N	2026-06-28 15:30:18.625375	\N	\N	0	none	20	N	\N	\N	\N	\N	\N	\N	
326	20260626151140780127	18888889999	\N	16	19	1234	20	2	2026-06-26 15:11:40.037844	\N	2026-06-26 07:11:40	\N	\N	\N	\N	4200003196202606264025106289	\N	2026-06-26 15:15:59.100626	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
330	20260626154702233246	18888889999	\N	16	21	1234	20	2	2026-06-26 15:47:02.451091	\N	2026-06-26 07:47:02	\N	\N	\N	\N	4200003208202606261431066067	\N	2026-06-26 15:47:09.175571	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
313	20260626093604565096	18888889999	449	8	3	1234	20	3	2026-06-26 09:36:04.314655	2026-06-26 09:36:04.314655	2026-06-26 01:36:04	\N	\N	\N	\N	4200003188202606261236674981	\N	2026-06-26 09:39:42.377781	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
314	20260626094216584004	18888889999	450	8	4	1234	20	3	2026-06-26 09:42:16.701258	2026-06-26 09:42:16.701258	2026-06-26 01:42:16	\N	\N	\N	\N	4200003186202606263086244068	\N	2026-06-26 09:42:30.426072	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
382	20260627161116110216	18888889999	502	16	8	1234	20	2	2026-06-27 16:11:16.267593	\N	2026-06-27 16:11:16.264003	\N	\N	\N	\N	4200003222202606276645933201	\N	2026-06-27 16:11:33.379517	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
332	20260626155413206167	18888889999	\N	16	22	1234	20	2	2026-06-26 15:54:13.158122	\N	2026-06-26 07:54:13	\N	\N	\N	\N	4200003214202606261349170060	\N	2026-06-26 17:28:40.671384	\N	1	0	none	20	N	\N	\N	\N	\N	\N	\N	\N
386	20260627180357317523	18983079797	465	15	3	1111	1	3	2026-06-27 18:03:57.305456	2026-06-27 18:06:36.345558	2026-06-27 18:03:57.30143	\N	\N	\N	\N	4200003131202606271749527663	\N	2026-06-27 18:04:23.73262	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
406	20260628145244714943	18888889999	520	16	26	1234	20	5	2026-06-28 14:52:44.056848	\N	2026-06-28 14:52:44.05194	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
390	20260628075013324398	18888889999	508	16	14	1234	20	3	2026-06-28 07:50:13.359321	\N	2026-06-28 07:50:13.355498	\N	\N	\N	\N	4200003179202606284370748705	\N	2026-06-28 07:50:38.542911	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
392	20260628083256974078	18888889999	509	16	15	1234	20	5	2026-06-28 08:32:56.971527	\N	2026-06-28 08:32:56.967757	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
402	20260628095005403739	18888889999	518	16	24	1234	20	5	2026-06-28 09:50:05.573443	\N	2026-06-28 09:50:05.569659	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
350	20260626202216294000	17722332233	\N	16	29	1245	20	5	2026-06-26 20:22:16.432857	\N	2026-06-26 20:22:16.429379	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
353	20260626203849898493	18888889999	\N	16	31	1234	20	4	2026-06-26 20:38:49.379353	2026-06-27 12:36:26	2026-06-26 20:38:49.37593	\N	\N	\N	\N	4200003195202606264695707051	\N	2026-06-26 20:39:21.485707	\N	\N	0	none	0	N	\N	\N	\N	\N	2026-06-27 12:36:26	2026-06-27 12:36:26	\N
396	20260628084105846088	17722332233	512	16	18	3698	20	3	2026-06-28 08:41:05.289221	\N	2026-06-28 08:41:05.285541	\N	\N	\N	\N	4200003183202606281049040918	\N	2026-06-28 08:41:27.716368	\N	\N	0	none	20	N	\N	\N	\N	\N	\N	\N	
372	20260627112151525591	18996093393	463	15	1	1111	1	5	2026-06-27 11:21:51.071583	\N	2026-06-27 11:21:51.067519	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
374	20260627114452740267	18996093393	473	15	11	1111	1	4	2026-06-27 11:44:52.795958	2026-06-27 12:40:46	2026-06-27 11:44:52.791747	\N	\N	\N	\N	4200003183202606272953018543	\N	2026-06-27 11:45:25.221999	\N	\N	0	none	0	N	\N	\N	\N	\N	2026-06-27 12:40:46	2026-06-27 12:40:46	\N
399	20260628093341461556	18888889999	515	16	21	1234	20	2	2026-06-28 09:33:41.75497	\N	2026-06-28 09:33:41.751031	\N	\N	\N	\N	4200003177202606285617651946	\N	2026-06-28 09:34:39.676769	\N	\N	0	none	0	N	Y	\N	\N	\N	\N	\N	
352	20260626203440517799	18888889999	\N	16	14	1234	20	4	2026-06-26 20:34:40.996024	2026-06-27 13:01:09	2026-06-26 20:34:40.992904	\N	\N	\N	\N	4200003125202606264648421174	\N	2026-06-26 20:35:02.286861	2026-06-27 13:01:13.283609	\N	1	refunded	20	N	\N	\N	\N	\N	2026-06-27 13:01:09	2026-06-27 13:01:09	\N
347	20260626195241140324	18888889999	\N	16	13	1234	20	4	2026-06-26 19:52:41.308565	2026-06-27 13:08:19	2026-06-26 19:52:41.305257	\N	\N	\N	\N	4200003178202606268143428277	\N	2026-06-26 19:53:03.021625	2026-06-27 13:08:24.915191	\N	1	refunded	20	N	\N	\N	\N	\N	2026-06-27 13:08:19	2026-06-27 13:08:19	\N
373	20260627112151757434	18996093393	472	15	10	1111	1	4	2026-06-27 11:21:51.938666	2026-06-27 13:00:57.157798	2026-06-27 11:21:51.93423	\N	\N	\N	\N	4200003189202606278759826892	\N	2026-06-27 11:22:27.301772	2026-06-27 13:00:57.157798	\N	1	refunded	1	N	\N	\N	\N	\N	\N	\N	\N
328	20260626152942192997	18888889999	\N	16	20	1234	20	2	2026-06-26 15:29:42.720861	\N	2026-06-26 07:29:42	\N	\N	\N	\N	4200003223202606261012234681	\N	2026-06-26 17:34:14.73608	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
336	20260626191339113080	13800138000	\N	16	17	4656	20	5	2026-06-26 19:13:39.495277	\N	2026-06-26 19:13:39.492373	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
338	20260626192430918322	13800138001	\N	16	18	3736	20	5	2026-06-26 19:24:30.878316	\N	2026-06-26 19:24:30.857027	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
339	20260626192804780540	13900001111	\N	16	23	5390	20	5	2026-06-26 19:28:04.597972	\N	2026-06-26 19:28:04.59467	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
340	20260626193319662087	18888889999	\N	16	1	1234	20	5	2026-06-26 19:33:19.501948	\N	2026-06-26 19:33:19.498629	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
341	20260626193410828034	18888889999	\N	16	24	1234	20	5	2026-06-26 19:34:10.658355	\N	2026-06-26 19:34:10.655079	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
342	20260626193558073778	18888889999	\N	16	25	1234	20	5	2026-06-26 19:35:58.396973	\N	2026-06-26 19:35:58.393778	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
343	20260626193718480697	18888889999	\N	16	10	1234	20	5	2026-06-26 19:37:18.787223	\N	2026-06-26 19:37:18.783864	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
344	20260626194126519853	13800138002	\N	16	26	0774	20	5	2026-06-26 19:41:26.945445	\N	2026-06-26 19:41:26.942187	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
345	20260626195113492844	18888889999	\N	16	11	1234	20	5	2026-06-26 19:51:13.399607	\N	2026-06-26 19:51:13.396408	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
346	20260626195223936759	18888889999	\N	16	12	1234	20	5	2026-06-26 19:52:23.95039	\N	2026-06-26 19:52:23.946807	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
348	20260626201308102505	18888889999	\N	16	27	1234	20	5	2026-06-26 20:13:08.194187	\N	2026-06-26 20:13:08.190781	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
349	20260626201940213728	17722332233	\N	16	28	1234	20	5	2026-06-26 20:19:40.70182	\N	2026-06-26 20:19:40.698743	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
351	20260626202221883459	17722332233	\N	16	30	1245	20	5	2026-06-26 20:22:21.872984	\N	2026-06-26 20:22:21.869637	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
371	20260627104626280493	18888889999	\N	16	45	1475	20	5	2026-06-27 10:46:26.963353	\N	2026-06-27 10:46:26.959998	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
354	20260626204829842556	18996093393	\N	16	15	1111	20	5	2026-06-26 20:48:29.40273	\N	2026-06-26 20:48:29.399371	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
355	20260626204928378750	18888889999	\N	16	32	4234	20	5	2026-06-26 20:49:28.016012	\N	2026-06-26 20:49:28.01245	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
356	20260626205722591084	18888889999	\N	16	33	1234	20	5	2026-06-26 20:57:22.848096	\N	2026-06-26 20:57:22.844854	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
358	20260626211119806002	18996093393	\N	16	2	1234	20	3	2026-06-26 21:11:19.719376	2026-06-26 21:11:50.818076	2026-06-26 21:11:19.716109	\N	\N	\N	\N	4200003203202606266721579288	\N	2026-06-26 21:11:38.334743	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
357	20260626211118085006	18996093393	\N	16	16	1234	20	5	2026-06-26 21:11:18.445816	\N	2026-06-26 21:11:18.442622	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
360	20260627081026930792	18888889999	\N	16	34	1234	20	5	2026-06-27 08:10:26.276668	\N	2026-06-27 08:10:26.272233	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
361	20260627090317533234	18888889999	\N	16	35	1234	20	5	2026-06-27 09:03:17.223309	\N	2026-06-27 09:03:17.217013	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
362	20260627090802425253	18888889999	\N	16	36	2582	20	5	2026-06-27 09:08:02.402114	\N	2026-06-27 09:08:02.398762	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
363	20260627090903381736	17722332233	\N	16	37	2582	20	5	2026-06-27 09:09:03.602507	\N	2026-06-27 09:09:03.597066	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
364	20260627091248396985	17722332233	\N	16	38	1234	20	5	2026-06-27 09:12:48.347639	\N	2026-06-27 09:12:48.343982	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
365	20260627091428107422	17722332233	\N	16	39	1234	20	5	2026-06-27 09:14:28.423398	\N	2026-06-27 09:14:28.419986	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
366	20260627091653850850	18888889999	\N	16	40	1231	20	5	2026-06-27 09:16:53.368289	\N	2026-06-27 09:16:53.365101	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
367	20260627091745119158	18888889999	\N	16	41	1234	20	5	2026-06-27 09:17:45.683536	\N	2026-06-27 09:17:45.680578	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
369	20260627100946811350	18888889999	\N	16	43	1234	20	5	2026-06-27 10:09:46.860479	\N	2026-06-27 10:09:46.857228	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
370	20260627102739798588	18888889999	\N	16	44	1234	20	5	2026-06-27 10:27:39.670587	\N	2026-06-27 10:27:39.667024	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
378	20260627155334919055	18888889999	498	16	4	1234	20	5	2026-06-27 15:53:34.571293	\N	2026-06-27 15:53:34.567167	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
375	20260627122904914170	18888889999	495	16	1	1234	20	5	2026-06-27 12:29:04.585367	\N	2026-06-27 12:29:04.572968	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
383	20260627163807021258	18888889999	503	16	9	1234	20	5	2026-06-27 16:38:07.045946	\N	2026-06-27 16:38:07.041968	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
379	20260627155423256198	18888889999	499	16	5	1234	20	3	2026-06-27 15:54:23.610202	2026-06-28 07:21:51	2026-06-27 15:54:23.605346	\N	\N	\N	\N	4200003209202606279977784591	\N	2026-06-27 15:54:39.077132	\N	\N	0	none	0	N	\N	\N	\N	\N	2026-06-28 07:21:51	2026-06-28 07:21:51	
377	20260627130236007300	18888889999	497	16	3	1234	20	5	2026-06-27 13:02:36.062128	\N	2026-06-27 13:02:36.058429	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
359	20260626211337376195	18996093393	\N	16	3	1234	20	4	2026-06-26 21:13:37.547959	2026-06-27 02:01:04	2026-06-26 21:13:37.544542	\N	\N	\N	\N	4200003190202606262178436345	\N	2026-06-26 21:14:06.670619	\N	\N	0	none	0	N	\N	\N	\N	\N	2026-06-27 02:01:04	2026-06-27 02:01:04	\N
368	20260627100422451091	18888889999	\N	16	42	1234	20	4	2026-06-27 10:04:22.568878	2026-06-27 12:41:16	2026-06-27 10:04:22.56541	\N	\N	\N	\N	4200003132202606278136500376	\N	2026-06-27 10:05:21.590954	\N	\N	0	none	0	N	\N	\N	\N	\N	2026-06-27 12:41:16	2026-06-27 12:41:16	\N
5	20260612125238878728	13844445555	3	1	3	1234	20	4	2026-06-12 12:52:38.906724	2026-06-12 12:52:39.19345	2026-06-12 04:52:38	\N	\N	\N	\N	MOCK20260612125239933782	MOCK_R20260612125239053174	2026-06-12 12:52:39.075634	2026-06-12 12:52:39.19345	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
8	20260612125806054979	13800001111	4	1	4	1111	20	4	2026-06-12 12:58:06.520154	2026-06-12 12:58:06.798029	2026-06-12 04:58:06	\N	\N	\N	\N	MOCK20260612125806736595	MOCK_R20260612125806149070	2026-06-12 12:58:06.678324	2026-06-12 12:58:06.798029	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
9	20260612130727372053	13877778888	4	1	4	9999	20	4	2026-06-12 13:07:27.142639	2026-06-12 13:07:27.422495	2026-06-12 05:07:27	\N	\N	\N	\N	MOCK20260612130727077299	MOCK_R20260612130727819069	2026-06-12 13:07:27.300624	2026-06-12 13:07:27.422495	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
376	20260627123001901085	18888889999	496	16	2	1234	20	4	2026-06-27 12:30:01.700717	2026-06-27 12:58:36.902548	2026-06-27 12:30:01.695111	\N	\N	\N	\N	4200003136202606276068779383	\N	2026-06-27 12:30:16.889189	2026-06-27 12:58:36.902548	\N	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N
387	20260628072554852730	18888889999	505	16	11	1234	20	5	2026-06-28 07:25:54.935084	\N	2026-06-28 07:25:54.93125	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
407	20260628152256512875	17722332233	521	16	27	1475	20	3	2026-06-28 15:22:56.856654	\N	2026-06-28 15:22:56.852527	\N	\N	\N	\N	4200003223202606288663233889	\N	2026-06-28 15:23:20.132205	\N	\N	0	none	20	N	\N	\N	\N	\N	\N	\N	
391	20260628082951623603	18996093393	466	15	4	1111	1	3	2026-06-28 08:29:51.401874	2026-06-28 08:31:00.780515	2026-06-28 08:29:51.396946	\N	\N	\N	\N	4200003213202606286027761813	\N	2026-06-28 08:30:08.559875	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
394	20260628084016662738	17722332233	510	16	16	2588	20	5	2026-06-28 08:40:16.371355	\N	2026-06-28 08:40:16.367515	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	
404	TEST_WT_0628	test_wt	463	15	\N	\N	20	2	\N	\N	2026-06-28 11:33:39.969283	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N
400	20260628093722986540	18888889999	516	16	22	1234	20	3	2026-06-28 09:37:22.654169	2026-06-29 08:51:01	2026-06-28 09:37:22.650293	\N	\N	\N	\N	4200003191202606283617596483	\N	2026-06-28 09:37:42.630942	\N	\N	0	none	0	N	\N	\N	\N	\N	2026-06-29 08:51:01	2026-06-29 08:51:01	
397	20260628084559522187	17722332233	513	16	19	1234	20	3	2026-06-28 08:45:59.421579	\N	2026-06-28 08:45:59.417494	\N	\N	\N	\N	4200003133202606282333152255	\N	2026-06-28 08:46:21.724518	\N	\N	0	none	20	N	Y	\N	\N	\N	\N	\N	
\.


--
-- Data for Name: payment_channels; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.payment_channels (id, name, channel_type, mch_id, api_key, app_id, app_secret, cert_name, extra_config, is_active, weight, daily_limit, total_amount, total_count, last_used_at, created_at, rotation_index) FROM stdin;
1	微信支付-主商户	wechat	1113658351	lichengju0904LICHENGJU0904libp98	wxd85204d0ec930d46	e2f27e35864226bf2668643b27f149d9	apiclient	\N	1	1	0	220	22	2026-06-26 17:34:14.790492	2026-06-12 07:00:31	0
2	微信支付-商户2	wechat	1745738973	lichengju0904LICHENGJU0904libp98	wxd85204d0ec930d46	e2f27e35864226bf2668643b27f149d9	1745738973	\N	1	1	0	160	999	2026-06-24 10:25:47.802639	2026-06-12 07:00:31	0
3	微信支付-商户3	wechat	1746577840	lichengju0904LICHENGJU0904libp98	wxd85204d0ec930d46	e2f27e35864226bf2668643b27f149d9	1746577840	\N	1	1	0	160	999	2026-06-24 11:46:09.11485	2026-06-12 07:00:31	0
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.payments (id, order_id, type, amount, transaction_id, status, created_at, refund_transaction_id) FROM stdin;
1	3	1	20	MOCK20260612123731687721	1	2026-06-12 04:37:31	\N
2	4	1	20	MOCK20260612124112354956	1	2026-06-12 04:41:12	\N
3	5	1	20	MOCK20260612125239933782	1	2026-06-12 04:52:39	\N
4	5	2	20	\N	1	2026-06-12 04:52:39	MOCK_R20260612125239053174
5	6	1	20	MOCK20260612125721052779	1	2026-06-12 04:57:21	\N
6	8	1	20	MOCK20260612125806736595	1	2026-06-12 04:58:06	\N
7	8	2	20	\N	1	2026-06-12 04:58:06	MOCK_R20260612125806149070
8	9	1	20	MOCK20260612130727077299	1	2026-06-12 05:07:27	\N
9	9	2	20	\N	1	2026-06-12 05:07:27	MOCK_R20260612130727819069
10	14	1	20	MOCK20260612220412535185	1	2026-06-12 14:04:12	\N
11	15	1	20	MOCK20260612220648303668	1	2026-06-12 14:06:48	\N
12	16	1	20	MOCK20260612221715620901	1	2026-06-12 14:17:15	\N
13	18	1	20	MOCK20260613071531279605	1	2026-06-12 23:15:31	\N
14	19	1	20	MOCK20260613084317461012	1	2026-06-13 00:43:17	\N
15	20	1	20	MOCK20260613084724403496	1	2026-06-13 00:47:24	\N
16	21	1	20	MOCK20260613084814527585	1	2026-06-13 00:48:14	\N
17	22	1	20	MOCK20260613084907298375	1	2026-06-13 00:49:07	\N
18	23	1	20	MOCK20260613085203062507	1	2026-06-13 00:52:03	\N
19	24	1	20	MOCK20260613092100550571	1	2026-06-13 01:21:00	\N
20	25	1	20	MOCK20260613103519579330	1	2026-06-13 02:35:19	\N
21	26	1	20	MOCK20260613103609423697	1	2026-06-13 02:36:09	\N
22	27	1	20	MOCK20260613103837623027	1	2026-06-13 02:38:37	\N
23	28	1	20	MOCK20260613103958690879	1	2026-06-13 02:39:58	\N
25	29	1	20	MOCK20260613105402524401	1	2026-06-13 02:54:02	\N
26	30	1	20	MOCK20260613105457264570	1	2026-06-13 02:54:57	\N
27	31	1	20	MOCK20260613110037508854	1	2026-06-13 03:00:37	\N
28	32	1	20	MOCK20260613110924025926	1	2026-06-13 03:09:24	\N
29	33	1	20	MOCK20260613111341731060	1	2026-06-13 03:13:41	\N
30	34	1	20	MOCK20260613111951029532	1	2026-06-13 03:19:51	\N
31	35	1	20	MOCK20260613112010821772	1	2026-06-13 03:20:10	\N
32	35	2	20	\N	0	2026-06-13 08:54:54	\N
33	74	1	20	MOCK20260615195200058468	1	2026-06-15 11:52:00	\N
34	75	1	20	MOCK20260615212238084163	1	2026-06-15 13:22:38	\N
35	78	1	20	4200003197202606157747962293	1	2026-06-15 14:47:03	\N
36	79	1	20	4200003209202606156654791224	1	2026-06-15 14:51:32	\N
37	81	1	20	4200003196202606163226158236	1	2026-06-16 02:09:38	\N
38	82	1	20	4200003129202606161854087446	1	2026-06-16 02:26:35	\N
39	84	1	20	4200003189202606165694456320	1	2026-06-16 03:26:32	\N
40	87	1	20	4200003131202606165905503583	1	2026-06-16 04:28:08	\N
41	88	1	20	4200003136202606165732011683	1	2026-06-16 04:28:56	\N
42	90	1	20	4200003223202606162762774344	1	2026-06-16 05:10:46	\N
43	92	1	20	4200003125202606166578988744	1	2026-06-16 06:43:56	\N
44	93	1	20	4200003187202606163240242798	1	2026-06-16 06:45:04	\N
45	94	1	20	4200003203202606160572494080	1	2026-06-16 07:47:24	\N
46	95	1	20	4200003201202606160806649078	1	2026-06-16 08:43:11	\N
47	98	1	20	4200003214202606163984242235	1	2026-06-16 08:56:36	\N
48	101	1	20	4200003211202606161176191397	1	2026-06-16 09:21:57	\N
49	103	1	20	4200003197202606160258458376	1	2026-06-16 12:05:03	\N
50	124	1	20	4200003134202606202313414267	1	2026-06-20 06:38:00	\N
51	124	1	20	4200003134202606202313414267	1	2026-06-20 06:38:31	\N
52	125	1	20	4200003130202606207192208715	1	2026-06-20 07:00:09	\N
53	125	1	20	4200003130202606207192208715	1	2026-06-20 07:00:39	\N
54	126	1	20	4200003214202606203948138371	1	2026-06-20 07:49:10	\N
55	127	1	20	4200003197202606204893669758	1	2026-06-20 07:49:45	\N
56	125	2	20	4200003130202606207192208715	1	2026-06-20 15:56:06.615305	RF20260620155606125
57	124	2	20	4200003134202606202313414267	1	2026-06-20 15:56:10.453777	RF20260620155610124
58	98	2	20	4200003214202606163984242235	1	2026-06-20 17:06:24.13429	RF2026062017062498
59	95	2	20	4200003201202606160806649078	1	2026-06-20 17:09:56.176641	RF2026062017095695
60	94	2	20	4200003203202606160572494080	1	2026-06-20 17:13:56.780917	RF2026062017135694
61	126	2	20	4200003214202606203948138371	1	2026-06-20 17:38:22.569721	RF20260620173821126
62	136	1	20	4200003185202606216413763246	1	2026-06-21 02:01:18	\N
63	138	1	20	4200003215202606211382457072	1	2026-06-21 02:02:57	\N
64	136	2	20	\N	1	2026-06-21 05:48:05	MOCK_R202606211348054318
65	160	1	20	4200003112202606227000683871	1	2026-06-21 23:51:10	\N
66	160	2	20	\N	1	2026-06-22 00:08:44	MOCK_R202606220808448368
67	162	1	20	4200003187202606221169857264	1	2026-06-22 00:59:23	\N
68	162	2	20	\N	1	2026-06-22 00:59:51	MOCK_R202606220859510289
69	163	1	20	4200003207202606223015137996	1	2026-06-22 02:45:24	\N
70	1	2	20	\N	0	2026-06-22 02:58:48	\N
71	1	2	20	\N	0	2026-06-22 03:02:45	\N
72	163	2	20	\N	1	2026-06-22 03:13:11	MOCK_R202606221113118916
73	164	1	20	4200003161202606220715893776	1	2026-06-22 03:45:56	\N
74	164	2	20	\N	1	2026-06-22 03:47:39	MOCK_R202606221147394386
75	165	1	20	4200003190202606223203070588	1	2026-06-22 04:29:23	\N
76	127	2	20	4200003197202606204893669758	1	2026-06-22 17:07:00.18928	RF20260622170659127
77	125	2	20	4200003130202606207192208715	1	2026-06-22 17:34:41.632235	RF20260622173440125
78	167	1	20	4200003213202606228028335181	1	2026-06-22 09:40:59	\N
79	169	1	20	4200003161202606224316828891	1	2026-06-22 10:11:29	\N
80	169	2	20	\N	1	2026-06-22 11:00:19	MOCK_R202606221900190931
81	171	1	20	4200003134202606238092863920	1	2026-06-23 13:46:08	\N
82	171	2	20	\N	1	2026-06-23 13:50:43	MOCK_R202606232150434694
83	172	1	20	4200003205202606239399871354	1	2026-06-23 14:42:29	\N
84	173	1	20	4200003167202606239067117617	1	2026-06-23 15:08:26	\N
85	175	1	20	4200003131202606234724155894	1	2026-06-23 15:10:06	\N
86	176	1	20	4200003183202606237930294670	1	2026-06-23 15:10:25	\N
87	177	1	20	4200003111202606235388301444	1	2026-06-23 15:21:41	\N
88	178	1	20	4200003131202606234306287373	1	2026-06-23 15:22:27	\N
89	177	2	20	\N	1	2026-06-23 15:54:23	MOCK_R202606232354236405
90	180	1	20	4200003186202606245075059432	1	2026-06-23 16:10:24	\N
91	184	1	20	4200003156202606240131921142	1	2026-06-23 22:24:17	\N
92	176	2	20	\N	1	2026-06-23 22:27:19	MOCK_R202606240627196147
93	185	1	20	4200003208202606240871033738	1	2026-06-23 22:42:08	\N
94	175	2	20	\N	1	2026-06-23 23:02:58	MOCK_R202606240702589758
95	186	1	20	4200003187202606241549677511	1	2026-06-23 23:03:56	\N
96	187	1	20	4200003211202606245418929050	1	2026-06-23 23:28:08	\N
97	188	1	20	4200003179202606249375880551	1	2026-06-23 23:47:21	\N
98	189	1	20	4200003141202606247314158381	1	2026-06-23 23:48:53	\N
99	190	1	20	4200003202202606247319480008	1	2026-06-24 00:07:55	\N
100	189	2	20	\N	1	2026-06-24 01:20:47	MOCK_R202606240920470170
101	191	1	20	4200003203202606248887967052	1	2026-06-24 02:25:47	\N
102	191	2	20	\N	1	2026-06-24 02:26:08	MOCK_R202606241026080405
103	193	1	20	4200003118202606243319941721	1	2026-06-24 03:44:11	\N
104	193	2	20	\N	1	2026-06-24 03:45:03	MOCK_R202606241145033822
105	194	1	20	4200003148202606249425682380	1	2026-06-24 03:46:09	\N
106	194	2	20	\N	1	2026-06-24 03:47:04	MOCK_R202606241147049804
107	190	2	20	4200003202202606247319480008	1	2026-06-24 11:58:40.028901	RF20260624115839190
108	195	1	20	4200003136202606242171328386	1	2026-06-24 06:32:58	\N
109	195	1	20	4200003136202606242171328386	1	2026-06-24 06:32:58	\N
110	195	2	20	\N	1	2026-06-24 06:34:57	MOCK_R20260624143457962311
111	196	1	20	4200003184202606249304133409	1	2026-06-24 07:37:45	\N
112	194	2	20	4200003148202606249425682380	1	2026-06-24 19:10:58.366656	RF20260624191057194
113	196	2	20	\N	0	2026-06-24 12:08:58	\N
114	198	1	20	4200003188202606240188305829	1	2026-06-24 14:37:50	\N
115	198	2	20	\N	0	2026-06-24 14:39:50	\N
116	275	1	20	4200003196202606259252043903	1	2026-06-25 09:24:58	\N
117	276	1	20	4200003215202606251844643887	1	2026-06-25 09:39:59	\N
118	277	1	20	4200003212202606259109040544	1	2026-06-25 09:47:12	\N
119	277	1	20	4200003212202606259109040544	1	2026-06-25 09:48:42	\N
120	277	2	20	\N	0	2026-06-25 09:49:11	\N
121	277	1	20	4200003212202606259109040544	1	2026-06-25 09:51:20	\N
122	278	1	20	4200003221202606256483320125	1	2026-06-25 10:54:43	\N
123	283	1	20	4200003128202606256100234318	1	2026-06-25 13:00:38	\N
124	284	1	20	4200003188202606258522730680	1	2026-06-25 13:07:45	\N
125	284	1	20	4200003188202606258522730680	1	2026-06-25 13:09:15	\N
126	285	1	20	4200003182202606254736104552	1	2026-06-25 13:44:08	\N
127	286	1	20	4200003217202606258317286550	1	2026-06-25 13:48:53	\N
128	287	1	20	4200003131202606253826643798	1	2026-06-25 14:00:02	\N
129	288	1	20	4200003136202606253757337202	1	2026-06-25 14:04:53	\N
130	289	1	20	4200003206202606258412608378	1	2026-06-25 14:13:01	\N
131	290	1	20	4200003128202606253899404960	1	2026-06-25 14:37:16	\N
132	291	1	20	4200003142202606255874904089	1	2026-06-25 14:43:18	\N
133	292	1	20	4200003111202606255715225042	1	2026-06-25 14:48:06	\N
134	295	1	20	\N	1	2026-06-25 15:34:23	\N
135	293	1	20	4200003185202606254397243023	1	2026-06-25 15:36:25	\N
136	296	1	20	\N	1	2026-06-25 15:41:41	\N
137	294	1	20	4200003191202606257942699219	1	2026-06-25 15:44:24	\N
138	297	1	20	\N	1	2026-06-25 15:47:15	\N
139	298	1	20	\N	1	2026-06-25 15:48:02	\N
140	299	1	20	\N	1	2026-06-25 15:50:39	\N
141	300	1	20	\N	1	2026-06-25 15:52:25	\N
142	301	1	20	4200003126202606266486005168	1	2026-06-25 22:26:00	\N
143	302	1	20	4200003206202606266399413240	1	2026-06-25 22:54:48	\N
144	302	1	20	4200003206202606266399413240	1	2026-06-25 22:56:19	\N
145	303	1	20	4200003184202606262064245079	1	2026-06-25 23:04:32	\N
146	303	1	20	4200003184202606262064245079	1	2026-06-25 23:06:32	\N
147	306	1	20	4200003222202606267015269936	1	2026-06-25 23:09:11	\N
148	306	1	20	4200003222202606267015269936	1	2026-06-25 23:10:42	\N
149	306	1	20	4200003222202606267015269936	1	2026-06-25 23:10:42	\N
150	307	1	20	4200003135202606260982950090	1	2026-06-25 23:31:20	\N
151	310	1	20	4200003125202606267155536409	1	2026-06-26 01:27:18	\N
152	311	1	20	4200003129202606262955618549	1	2026-06-26 01:33:28	\N
153	311	1	20	4200003129202606262955618549	1	2026-06-26 01:34:58	\N
154	313	1	20	4200003188202606261236674981	1	2026-06-26 01:38:11	\N
155	313	1	20	4200003188202606261236674981	1	2026-06-26 01:39:42	\N
156	314	1	20	4200003186202606263086244068	1	2026-06-26 01:42:30	\N
157	315	1	20	4200003184202606264338045728	1	2026-06-26 01:46:21	\N
158	316	1	20	4200003183202606260475366817	1	2026-06-26 02:53:39	\N
159	317	1	20	4200003204202606269502378651	1	2026-06-26 05:15:47	\N
160	318	1	20	4200003189202606260554928901	1	2026-06-26 05:57:38	\N
161	326	1	20	4200003196202606264025106289	1	2026-06-26 07:15:59	\N
162	330	1	20	4200003208202606261431066067	1	2026-06-26 07:47:09	\N
163	332	1	20	4200003214202606261349170060	1	2026-06-26 08:58:37	\N
164	332	1	20	4200003214202606261349170060	1	2026-06-26 17:28:40.670006	\N
165	328	1	20	4200003223202606261012234681	1	2026-06-26 17:34:14.734917	\N
166	347	1	20	4200003178202606268143428277	1	2026-06-26 19:53:03.020549	\N
167	352	1	20	4200003125202606264648421174	1	2026-06-26 20:35:02.285683	\N
168	353	1	20	4200003195202606264695707051	1	2026-06-26 20:39:21.484571	\N
169	358	1	20	4200003203202606266721579288	1	2026-06-26 21:11:38.333582	\N
171	359	1	20	4200003190202606262178436345	1	2026-06-26 21:14:06.669444	\N
175	368	1	20	4200003132202606278136500376	1	2026-06-27 10:05:21.589816	\N
176	373	1	1	4200003189202606278759826892	1	2026-06-27 11:22:27.300618	\N
177	374	1	1	4200003183202606272953018543	1	2026-06-27 11:45:25.220677	\N
178	376	1	20	4200003136202606276068779383	1	2026-06-27 12:30:16.888008	\N
179	376	2	20	4200003136202606276068779383	1	2026-06-27 12:58:36.902548	RF20260627124832376
180	373	2	1	4200003189202606278759826892	1	2026-06-27 13:00:58.079687	RF20260627130057373
181	352	2	20	4200003125202606264648421174	1	2026-06-27 13:01:14.084133	RF20260627130113352
182	347	2	20	4200003178202606268143428277	1	2026-06-27 13:08:25.746961	RF20260627130824347
183	379	1	20	4200003209202606279977784591	1	2026-06-27 15:54:39.07598	\N
184	380	1	20	4200003186202606272613703359	1	2026-06-27 16:01:17.944934	\N
185	381	1	20	4200003194202606274482878253	1	2026-06-27 16:06:33.755489	\N
186	382	1	20	4200003222202606276645933201	1	2026-06-27 16:11:33.378261	\N
187	384	1	20	4200003137202606271203499467	1	2026-06-27 16:38:26.497389	\N
188	385	1	1	4200003215202606279493063491	1	2026-06-27 18:02:24.751033	\N
189	386	1	1	4200003131202606271749527663	1	2026-06-27 18:04:23.731391	\N
190	390	1	20	4200003179202606284370748705	1	2026-06-28 07:50:38.541754	\N
191	391	1	1	4200003213202606286027761813	1	2026-06-28 08:30:08.558633	\N
192	393	1	1	4200003127202606285009377611	1	2026-06-28 08:35:13.934019	\N
193	396	1	20	4200003183202606281049040918	1	2026-06-28 08:41:27.715242	\N
194	397	1	20	4200003133202606282333152255	1	2026-06-28 08:46:21.723308	\N
195	399	1	20	4200003177202606285617651946	1	2026-06-28 09:34:39.675548	\N
196	400	1	20	4200003191202606283617596483	1	2026-06-28 09:37:42.629482	\N
197	401	1	20	4200003205202606284880898631	1	2026-06-28 09:45:59.444138	\N
198	405	1	20	4200003187202606285994990390	1	2026-06-28 14:52:23.292359	\N
199	407	1	20	4200003223202606288663233889	1	2026-06-28 15:23:20.131006	\N
200	408	1	20	4200003133202606283862175972	1	2026-06-28 15:30:18.624103	\N
\.


--
-- Data for Name: pending_lock_cmds; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.pending_lock_cmds (id, device_id, board_no, lock_no, protocol, order_id, created_at, delivered, cabinet_id, slot_id, command, status) FROM stdin;
371	123456	2	21	YBM	283	2026-06-25 13:35:51	1	\N	\N	\N	\N
372	123456	1	A24	YBM	20260625214644063856	2026-06-25 13:50:24	1	\N	\N	\N	\N
373	101002	1	1	YBM	\N	2026-06-25 13:55:20	1	\N	\N	\N	\N
374	101002	1	1	YBM	\N	2026-06-25 13:57:27	1	\N	\N	\N	\N
375	101002	1	1	YBM	\N	2026-06-25 14:01:32	1	\N	\N	\N	\N
376	101002	1	1	YBM	\N	2026-06-25 14:01:33	1	\N	\N	\N	\N
377	101002	1	1	YBM	\N	2026-06-25 14:01:33	1	\N	\N	\N	\N
378	101002	1	1	YBM	\N	2026-06-25 14:01:42	1	\N	\N	\N	\N
379	101002	1	1	YBM	\N	2026-06-25 14:04:53	1	\N	\N	\N	\N
380	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
381	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
382	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
383	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
384	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
385	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
386	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
387	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
388	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
389	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
390	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
391	123456	1	A26	YBM	20260625220242082866	2026-06-25 14:06:24	1	\N	\N	\N	\N
393	123456	1	A29	YBM	20260625224205854601	2026-06-25 14:42:11	1	\N	\N	\N	\N
394	123456	1	A30	YBM	20260625224556086478	2026-06-25 14:46:02	1	\N	\N	\N	\N
395	123456	1	A30	YBM	20260625224556086478	2026-06-25 14:49:36	1	\N	\N	\N	\N
396	101002	1	1	YBM	\N	2026-06-25 14:50:04	1	\N	\N	\N	\N
397	101002	1	1	YBM	\N	2026-06-25 14:50:15	1	\N	\N	\N	\N
398	101002	1	1	YBM	\N	2026-06-25 14:50:39	1	\N	\N	\N	\N
399	101002	1	1	YBM	\N	2026-06-25 14:52:26	1	\N	\N	\N	\N
400	101002	1	1	YBM	\N	2026-06-25 14:52:32	1	\N	\N	\N	\N
401	101002	1	1	YBM	\N	2026-06-25 14:54:38	1	\N	\N	\N	\N
402	101002	1	1	YBM	\N	2026-06-25 14:54:46	1	\N	\N	\N	\N
403	101002	1	1	YBM	\N	2026-06-25 14:56:57	1	\N	\N	\N	\N
404	123456	1	A31	YBM	20260625230123439689	2026-06-25 15:01:31	1	\N	\N	\N	\N
405	123456	2	14	YBM	\N	2026-06-25 15:29:41	1	\N	\N	\N	\N
406	123456	1	A32	YBM	20260625233005853236	2026-06-25 15:30:11	1	\N	\N	\N	\N
407	123456	1	A33	YBM	20260625233407427886	2026-06-25 15:36:24	1	\N	\N	\N	\N
408	123456	1	A34	YBM	20260625234133881159	2026-06-25 15:41:41	1	\N	\N	\N	\N
409	123456	1	A34	YBM	20260625234133881159	2026-06-25 15:41:50	1	\N	\N	\N	\N
410	123456	1	A35	YBM	20260625234710366176	2026-06-25 15:47:15	1	\N	\N	\N	\N
411	123456	1	A35	YBM	20260625234710366176	2026-06-25 15:47:23	1	\N	\N	\N	\N
412	123456	1	A36	YBM	20260625234755209987	2026-06-25 15:48:02	1	\N	\N	\N	\N
413	123456	1	A36	YBM	20260625234755209987	2026-06-25 15:48:12	1	\N	\N	\N	\N
414	123456	1	A37	YBM	20260625235027193965	2026-06-25 15:50:39	1	\N	\N	\N	\N
415	123456	1	A38	YBM	20260625235218620187	2026-06-25 15:52:25	1	\N	\N	\N	\N
416	123456	1	A38	YBM	20260625235218620187	2026-06-25 15:52:35	1	\N	\N	\N	\N
417	123456	3	38	YBM	300	2026-06-25 22:27:51	1	\N	\N	\N	\N
418	123456	3	37	YBM	299	2026-06-25 22:27:56	1	\N	\N	\N	\N
419	123456	2	16	YBM	\N	2026-06-25 22:29:01	1	\N	\N	\N	\N
420	123456	3	1	YBM	\N	2026-06-25 22:29:17	1	\N	\N	\N	\N
421	123456	3	2	YBM	\N	2026-06-25 22:29:23	1	\N	\N	\N	\N
422	123456	3	3	YBM	\N	2026-06-25 22:29:27	1	\N	\N	\N	\N
423	123456	3	38	YBM	300	2026-06-25 22:29:40	1	\N	\N	\N	\N
424	123456	3	7	YBM	\N	2026-06-25 22:30:46	1	\N	\N	\N	\N
425	123456	3	6	YBM	\N	2026-06-25 22:30:50	1	\N	\N	\N	\N
426	123456	3	5	YBM	\N	2026-06-25 22:30:53	1	\N	\N	\N	\N
427	123456	3	16	YBM	\N	2026-06-25 22:31:51	1	\N	\N	\N	\N
428	123456	3	15	YBM	\N	2026-06-25 22:31:57	1	\N	\N	\N	\N
429	123456	3	16	YBM	\N	2026-06-25 22:32:00	1	\N	\N	\N	\N
430	123456	3	14	YBM	\N	2026-06-25 22:32:04	1	\N	\N	\N	\N
431	123456	3	7	YBM	\N	2026-06-25 22:39:13	1	\N	\N	\N	\N
432	123456	3	38	YBM	300	2026-06-25 22:57:09	1	\N	\N	\N	\N
433	123456	3	8	YBM	\N	2026-06-25 22:57:24	1	\N	\N	\N	\N
434	123456	3	38	YBM	300	2026-06-25 23:03:17	1	\N	\N	\N	\N
435	123456	3	8	YBM	\N	2026-06-25 23:11:40	1	\N	\N	\N	\N
436	123456	3	16	YBM	\N	2026-06-25 23:11:45	1	\N	\N	\N	\N
437	123456	3	38	YBM	300	2026-06-25 23:28:33	1	\N	\N	\N	\N
438	123456	3	8	YBM	\N	2026-06-25 23:36:02	1	\N	\N	\N	\N
439	101002	1	1	YBM	\N	2026-06-26 00:42:23	1	\N	\N	\N	\N
440	123456	1	1	YBM	\N	2026-06-26 00:47:02	1	\N	\N	\N	\N
441	123456	1	1	YBM	\N	2026-06-26 00:50:45	1	\N	\N	\N	\N
442	123456	3	12	YBM	20260626091635740650	2026-06-26 01:17:16	1	\N	\N	\N	\N
443	123456	3	12	YBM	20260626091635740650	2026-06-26 01:17:42	1	\N	\N	\N	\N
599	100100	2	5	YBM		2026-06-26 19:50:33.750967	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-26 19:50:00"}	\N
604	100100	2	3	YBM		2026-06-26 19:54:50.073594	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "2", "boardNo": "2", "lock_no": "3", "lockNo": "3", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-26 19:54:50"}	\N
609	100100	1	3	YBM	20260626211337376195	2026-06-26 21:14:06.688977	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "3", "lockNo": "3", "protocol": "YBM", "order_id": "20260626211337376195", "orderId": "20260626211337376195", "timestamp": "2026-06-26 21:14:06"}	\N
392	\N	1	1	YBM	\N	2026-06-25 14:14:33	1	\N	\N	\N	\N
623	100100	1	\N	YBM		2026-06-27 07:40:56.836919	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/smart-locker.apk?v=1782515669", "version_name": "1.2.33", "version_code": 153, "force": true}	pending
659	101001	1	2	YBM		2026-06-27 11:35:05.440695	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:35:05"}	\N
664	100100	1	1	YBM		2026-06-27 11:55:37.81845	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:55:37"}	\N
594	100100	1	99	YBM		2026-06-26 18:11:36.91632	1	\N	\N	\N	\N
651	101001	1	1	YBM		2026-06-27 11:24:21.069424	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:24:21"}	\N
610	100100	2	31	YBM	353	2026-06-27 06:34:58.772463	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "2", "boardNo": "2", "lock_no": "31", "lockNo": "31", "protocol": "YBM", "order_id": "353", "orderId": "353", "timestamp": "2026-06-27 06:34:58"}	\N
665	100100	1	1	YBM		2026-06-27 11:55:46.080703	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:55:46"}	\N
669	100100	1	1	YBM		2026-06-27 11:59:55.777646	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:59:55"}	\N
655	101001	1	2	YBM		2026-06-27 11:27:03.084759	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:27:03"}	\N
673	100100	1	2	YBM	376	2026-06-27 12:30:23.788583	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": 376, "orderId": "376", "timestamp": "2026-06-27 12:30:23"}	\N
624	100100	1	\N	YBM		2026-06-27 07:51:05.010013	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/smart-locker.apk?v=1782517746", "version_name": "1.2.33", "version_code": 153, "force": true}	pending
626	100100	1	\N	YBM		2026-06-27 08:54:49.076079	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/smart-locker.apk?v=1782521688","version_name":"1.2.36","version_code":156,"force":true}	pending
631	100100	1	\N	YBM		2026-06-27 09:33:36.730228	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.38","version_code":158,"md5":"","force":true}	\N
634	100100	1	\N	YBM		2026-06-27 09:41:52.423267	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.38","version_code":158,"force":true}	\N
614	100100	1	1	YBM		2026-06-27 06:36:00.445313	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 06:36:00"}	\N
593	100100	2	1	YBM		2026-06-26 18:09:25.5796	1	\N	\N	\N	\N
638	100100	1	1	YBM		2026-06-27 10:03:35.843769	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 10:03:35"}	\N
600	100100	2	1	YBM		2026-06-26 19:51:55.611511	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "2", "boardNo": "2", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-26 19:51:55"}	\N
605	100100	1	1	YBM		2026-06-26 19:55:26.859639	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-26 19:55:26"}	\N
619	100100	1	1	YBM		2026-06-27 07:07:46.883083	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 07:07:46"}	\N
615	100100	1	3	YBM	359	2026-06-27 06:36:14.502592	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "3", "lockNo": "3", "protocol": "YBM", "order_id": "359", "orderId": "359", "timestamp": "2026-06-27 06:36:14"}	\N
642	100100	3	10	YBM	20260627100422451091	2026-06-27 10:05:21.61364	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "3", "boardNo": "3", "lock_no": "10", "lockNo": "10", "protocol": "YBM", "order_id": "20260627100422451091", "orderId": "20260627100422451091", "timestamp": "2026-06-27 10:05:21"}	\N
646	101001	1	2	YBM		2026-06-27 11:18:10.698759	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:18:10"}	\N
647	101001	1	2	YBM		2026-06-27 11:18:32.605702	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:18:32"}	\N
676	100100	1	2	YBM		2026-06-27 12:32:08.143243	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 12:32:08"}	\N
679	101001	1	1	WT		2026-06-27 14:11:11.898625	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 14:11:11"}	\N
682	101001	1	1	WT		2026-06-27 14:19:48.864925	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 14:19:48"}	\N
660	101001	1	10	YBM		2026-06-27 11:36:49.907778	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "10", "lockNo": "10", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:36:49"}	\N
685	101001	1	1	WT		2026-06-27 14:31:38.556834	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 14:31:38"}	\N
688	101001	1	\N	YBM		2026-06-27 14:52:01.432416	1	15	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.40", "version_code": 160, "force": true}	pending
691	101001	1	1	WT		2026-06-27 15:17:47.868997	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 15:17:47"}	\N
694	101001	1	1	WT		2026-06-27 15:43:06.477873	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 15:43:06"}	\N
697	100100	1	5	YBM	379	2026-06-27 15:54:46.814071	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": 379, "orderId": "379", "timestamp": "2026-06-27 15:54:46"}	\N
639	100100	1	15	YBM		2026-06-27 10:03:41.109183	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "15", "lockNo": "15", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 10:03:41"}	\N
601	100100	1	13	YBM	20260626195241140324	2026-06-26 19:53:03.039848	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "13", "lockNo": "13", "protocol": "YBM", "order_id": "20260626195241140324", "orderId": "20260626195241140324", "timestamp": "2026-06-26 19:53:03"}	\N
606	100100	1	14	YBM	20260626203440517799	2026-06-26 20:35:02.305252	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "14", "lockNo": "14", "protocol": "YBM", "order_id": "20260626203440517799", "orderId": "20260626203440517799", "timestamp": "2026-06-26 20:35:02"}	\N
616	100100	2	31	YBM	353	2026-06-27 06:54:21.38707	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "2", "boardNo": "2", "lock_no": "31", "lockNo": "31", "protocol": "YBM", "order_id": "353", "orderId": "353", "timestamp": "2026-06-27 06:54:21"}	\N
611	100100	1	3	YBM	359	2026-06-27 06:35:15.685407	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "3", "lockNo": "3", "protocol": "YBM", "order_id": "359", "orderId": "359", "timestamp": "2026-06-27 06:35:15"}	\N
652	101001	1	1	YBM		2026-06-27 11:24:44.730659	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:24:44"}	\N
625	100100	1	\N	YBM		2026-06-27 08:07:07.799325	1	\N	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/smart-locker.apk?v=1782518827", "version_name": "1.2.34", "version_code": 154, "force": true}	\N
627	100100	1	\N	YBM		2026-06-27 09:03:45.503667	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/smart-locker.apk?v=1782522225","version_name":"1.2.37","version_code":157,"force":true}	pending
630	100100	1	2	YBM		2026-06-27 09:31:15.540043	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 09:31:15"}	\N
635	100100	1	\N	YBM		2026-06-27 09:55:32.030958	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.39","version_code":159,"force":true}	\N
595	100100	1	1	YBM		2026-06-26 19:31:02.984255	1	\N	\N	\N	\N
620	100100	1	1	YBM		2026-06-27 07:07:56.996378	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 07:07:56"}	\N
661	101001	1	1	YBM		2026-06-27 11:40:26.089901	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:40:26"}	\N
666	100100	1	1	YBM		2026-06-27 11:56:21.165127	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:56:21"}	\N
670	100100	1	10	YBM		2026-06-27 12:00:00.389908	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "10", "lockNo": "10", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 12:00:00"}	\N
643	101001	1	2	YBM		2026-06-27 11:17:24.063022	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:17:24"}	\N
648	101001	1	2	YBM		2026-06-27 11:18:56.370072	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:18:56"}	\N
656	101001	1	2	YBM		2026-06-27 11:27:19.771207	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:27:19"}	\N
674	100100	1	2	YBM	376	2026-06-27 12:30:26.142492	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": 376, "orderId": "376", "timestamp": "2026-06-27 12:30:26"}	\N
677	101001	1	1	YBM		2026-06-27 14:00:41.483216	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 14:00:41"}	\N
680	101001	1	1	WT		2026-06-27 14:12:07.719903	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 14:12:07"}	\N
686	101001	1	1	WT		2026-06-27 14:42:31.772669	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 14:42:31"}	\N
540	123456	1	1	YBM	\N	2026-06-26 01:34:58	1	\N	\N	\N	\N
541	123456	1	1	YBM	\N	2026-06-26 01:34:58	1	\N	\N	\N	\N
542	123456	1	1	YBM	\N	2026-06-26 01:34:58	1	\N	\N	\N	\N
543	123456	1	1	YBM	\N	2026-06-26 01:35:17	1	\N	\N	\N	\N
544	123456	1	3	YBM	\N	2026-06-26 01:35:20	1	\N	\N	\N	\N
545	123456	1	1	YBM	311	2026-06-26 01:35:37	1	\N	\N	\N	\N
546	123456	1	5	YBM	315	2026-06-26 01:49:04	1	\N	\N	\N	\N
547	123456	1	1	YBM	\N	2026-06-26 02:38:40	1	\N	\N	\N	\N
689	101001	1	1	WT		2026-06-27 15:15:32.337672	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 15:15:32"}	\N
454	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	265	{"type": "open_lock", "device_id": "123456", "slot_number": 11, "slot_label": "A11"}	pending
683	100100	1	2	YBM	376	2026-06-27 14:27:59.79189	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "376", "orderId": "376", "timestamp": "2026-06-27 14:27:59"}	\N
692	101001	1	1	WT		2026-06-27 15:36:38.777203	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 15:36:38"}	\N
570	123456	1	6	YBM	316	2026-06-26 04:44:18	1	\N	\N	\N	\N
582	100100	2	14	YBM	\N	2026-06-26 07:43:04	1	\N	\N	\N	\N
586	100100	2	6	YBM	20260626155413206167	2026-06-26 17:28:40.689734	1	\N	\N	\N	\N
612	100100	2	31	YBM	353	2026-06-27 06:35:29.615291	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "2", "boardNo": "2", "lock_no": "31", "lockNo": "31", "protocol": "YBM", "order_id": "353", "orderId": "353", "timestamp": "2026-06-27 06:35:29"}	\N
617	100100	1	14	YBM	352	2026-06-27 07:02:59.165556	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "14", "lockNo": "14", "protocol": "YBM", "order_id": "352", "orderId": "352", "timestamp": "2026-06-27 07:02:59"}	\N
607	100100	2	15	YBM	20260626203849898493	2026-06-26 20:39:21.503853	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "2", "boardNo": "2", "lock_no": "15", "lockNo": "15", "protocol": "YBM", "order_id": "20260626203849898493", "orderId": "20260626203849898493", "timestamp": "2026-06-26 20:39:21"}	\N
587	100100	2	4	YBM	20260626152942192997	2026-06-26 17:34:14.754145	1	\N	\N	\N	\N
588	100100	2	22	YBM	332	2026-06-26 17:49:02.69832	1	\N	\N	\N	\N
628	100100	1	\N	YBM		2026-06-27 09:11:47.578723	1	\N	\N	{"type":"force_update","url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.38","version_code":158,"md5":""}	\N
602	100100	2	3	YBM		2026-06-26 19:54:39.203051	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "2", "boardNo": "2", "lock_no": "3", "lockNo": "3", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-26 19:54:39"}	\N
640	100100	2	3	YBM		2026-06-27 10:03:58.531615	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "2", "boardNo": "2", "lock_no": "3", "lockNo": "3", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 10:03:58"}	\N
444	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	255	{"type": "open_lock", "device_id": "123456", "slot_number": 1, "slot_label": "A1"}	pending
445	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	256	{"type": "open_lock", "device_id": "123456", "slot_number": 2, "slot_label": "A2"}	pending
621	100100	1	16	YBM		2026-06-27 07:08:03.715295	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "16", "lockNo": "16", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 07:08:03"}	\N
446	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	257	{"type": "open_lock", "device_id": "123456", "slot_number": 3, "slot_label": "A3"}	pending
447	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	258	{"type": "open_lock", "device_id": "123456", "slot_number": 4, "slot_label": "A4"}	pending
448	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	259	{"type": "open_lock", "device_id": "123456", "slot_number": 5, "slot_label": "A5"}	pending
449	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	260	{"type": "open_lock", "device_id": "123456", "slot_number": 6, "slot_label": "A6"}	pending
450	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	261	{"type": "open_lock", "device_id": "123456", "slot_number": 7, "slot_label": "A7"}	pending
451	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	262	{"type": "open_lock", "device_id": "123456", "slot_number": 8, "slot_label": "A8"}	pending
452	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	263	{"type": "open_lock", "device_id": "123456", "slot_number": 9, "slot_label": "A9"}	pending
453	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	264	{"type": "open_lock", "device_id": "123456", "slot_number": 10, "slot_label": "A10"}	pending
653	101001	1	1	YBM		2026-06-27 11:25:12.119733	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:25:12"}	\N
657	100100	1	\N	YBM		2026-06-27 11:31:22.156131	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.39", "version_code": 159, "force": true}	pending
644	101001	1	2	YBM		2026-06-27 11:17:31.881331	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:17:31"}	\N
649	101001	1	2	YBM		2026-06-27 11:20:28.707673	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:20:28"}	\N
667	100100	1	1	YBM		2026-06-27 11:59:35.709249	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:59:35"}	\N
575	100100	1	2	YBM	\N	2026-06-26 07:02:59	1	\N	\N	\N	\N
581	100100	1	2	YBM	\N	2026-06-26 07:43:01	1	\N	\N	\N	\N
585	100100	1	2	YBM	\N	2026-06-26 07:58:04	1	\N	\N	\N	\N
632	100100	1	2	YBM		2026-06-27 09:34:43.578561	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 09:34:43"}	\N
636	100100	1	\N	YBM		2026-06-27 09:56:29.691501	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.39","version_code":159,"force":true}	\N
596	100100	2	1	YBM		2026-06-26 19:31:07.497223	1	\N	\N	\N	\N
572	100100	1	1	YBM	\N	2026-06-26 06:42:11	1	\N	\N	\N	\N
573	100100	1	1	YBM	\N	2026-06-26 06:47:18	1	\N	\N	\N	\N
574	100100	1	1	YBM	\N	2026-06-26 07:02:50	1	\N	\N	\N	\N
576	100100	1	1	YBM	\N	2026-06-26 07:42:26	1	\N	\N	\N	\N
577	100100	1	1	YBM	\N	2026-06-26 07:42:52	1	\N	\N	\N	\N
578	100100	1	1	YBM	\N	2026-06-26 07:42:54	1	\N	\N	\N	\N
579	100100	1	1	YBM	\N	2026-06-26 07:42:56	1	\N	\N	\N	\N
580	100100	1	1	YBM	\N	2026-06-26 07:42:58	1	\N	\N	\N	\N
583	100100	1	1	YBM	\N	2026-06-26 07:58:00	1	\N	\N	\N	\N
584	100100	1	1	YBM	\N	2026-06-26 07:58:02	1	\N	\N	\N	\N
589	100100	2	1	YBM		2026-06-26 18:00:47.277914	1	\N	\N	\N	\N
662	101001	1	1	YBM		2026-06-27 11:40:35.459622	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:40:35"}	\N
671	100100	1	10	YBM		2026-06-27 12:00:04.725516	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "10", "lockNo": "10", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 12:00:04"}	\N
695	100100	1	\N	YBM		2026-06-27 15:50:39.584778	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.40", "version_code": 160, "force": true}	pending
455	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	266	{"type": "open_lock", "device_id": "123456", "slot_number": 12, "slot_label": "A12"}	pending
456	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	267	{"type": "open_lock", "device_id": "123456", "slot_number": 13, "slot_label": "A13"}	pending
457	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	268	{"type": "open_lock", "device_id": "123456", "slot_number": 14, "slot_label": "A14"}	pending
458	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	269	{"type": "open_lock", "device_id": "123456", "slot_number": 15, "slot_label": "A15"}	pending
459	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	270	{"type": "open_lock", "device_id": "123456", "slot_number": 16, "slot_label": "A16"}	pending
460	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	271	{"type": "open_lock", "device_id": "123456", "slot_number": 17, "slot_label": "A17"}	pending
461	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	272	{"type": "open_lock", "device_id": "123456", "slot_number": 18, "slot_label": "A18"}	pending
462	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	273	{"type": "open_lock", "device_id": "123456", "slot_number": 19, "slot_label": "A19"}	pending
463	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	274	{"type": "open_lock", "device_id": "123456", "slot_number": 20, "slot_label": "A20"}	pending
464	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	275	{"type": "open_lock", "device_id": "123456", "slot_number": 21, "slot_label": "A21"}	pending
465	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	276	{"type": "open_lock", "device_id": "123456", "slot_number": 22, "slot_label": "A22"}	pending
466	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	277	{"type": "open_lock", "device_id": "123456", "slot_number": 23, "slot_label": "A23"}	pending
467	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	278	{"type": "open_lock", "device_id": "123456", "slot_number": 24, "slot_label": "A24"}	pending
468	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	279	{"type": "open_lock", "device_id": "123456", "slot_number": 25, "slot_label": "A25"}	pending
469	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	280	{"type": "open_lock", "device_id": "123456", "slot_number": 26, "slot_label": "A26"}	pending
470	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	281	{"type": "open_lock", "device_id": "123456", "slot_number": 27, "slot_label": "A27"}	pending
471	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	282	{"type": "open_lock", "device_id": "123456", "slot_number": 28, "slot_label": "A28"}	pending
472	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	283	{"type": "open_lock", "device_id": "123456", "slot_number": 29, "slot_label": "A29"}	pending
473	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	284	{"type": "open_lock", "device_id": "123456", "slot_number": 30, "slot_label": "A30"}	pending
474	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	285	{"type": "open_lock", "device_id": "123456", "slot_number": 31, "slot_label": "A31"}	pending
475	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	286	{"type": "open_lock", "device_id": "123456", "slot_number": 32, "slot_label": "A32"}	pending
476	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	287	{"type": "open_lock", "device_id": "123456", "slot_number": 33, "slot_label": "A33"}	pending
477	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	288	{"type": "open_lock", "device_id": "123456", "slot_number": 34, "slot_label": "A34"}	pending
478	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	289	{"type": "open_lock", "device_id": "123456", "slot_number": 35, "slot_label": "A35"}	pending
479	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	290	{"type": "open_lock", "device_id": "123456", "slot_number": 36, "slot_label": "A36"}	pending
480	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	291	{"type": "open_lock", "device_id": "123456", "slot_number": 37, "slot_label": "A37"}	pending
481	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	292	{"type": "open_lock", "device_id": "123456", "slot_number": 38, "slot_label": "A38"}	pending
482	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	293	{"type": "open_lock", "device_id": "123456", "slot_number": 39, "slot_label": "A39"}	pending
483	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	294	{"type": "open_lock", "device_id": "123456", "slot_number": 40, "slot_label": "A40"}	pending
484	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	295	{"type": "open_lock", "device_id": "123456", "slot_number": 41, "slot_label": "A41"}	pending
485	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	296	{"type": "open_lock", "device_id": "123456", "slot_number": 42, "slot_label": "A42"}	pending
486	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	297	{"type": "open_lock", "device_id": "123456", "slot_number": 43, "slot_label": "A43"}	pending
487	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	298	{"type": "open_lock", "device_id": "123456", "slot_number": 44, "slot_label": "A44"}	pending
488	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	299	{"type": "open_lock", "device_id": "123456", "slot_number": 45, "slot_label": "A45"}	pending
489	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	300	{"type": "open_lock", "device_id": "123456", "slot_number": 46, "slot_label": "A46"}	pending
490	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	301	{"type": "open_lock", "device_id": "123456", "slot_number": 47, "slot_label": "A47"}	pending
491	\N	1	\N	YBM	\N	2026-06-26 01:25:55	1	8	302	{"type": "open_lock", "device_id": "123456", "slot_number": 48, "slot_label": "A48"}	pending
492	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	255	{"type": "open_lock", "device_id": "123456", "slot_number": 1, "slot_label": "A1"}	pending
493	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	256	{"type": "open_lock", "device_id": "123456", "slot_number": 2, "slot_label": "A2"}	pending
494	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	257	{"type": "open_lock", "device_id": "123456", "slot_number": 3, "slot_label": "A3"}	pending
495	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	258	{"type": "open_lock", "device_id": "123456", "slot_number": 4, "slot_label": "A4"}	pending
496	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	259	{"type": "open_lock", "device_id": "123456", "slot_number": 5, "slot_label": "A5"}	pending
497	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	260	{"type": "open_lock", "device_id": "123456", "slot_number": 6, "slot_label": "A6"}	pending
498	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	261	{"type": "open_lock", "device_id": "123456", "slot_number": 7, "slot_label": "A7"}	pending
499	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	262	{"type": "open_lock", "device_id": "123456", "slot_number": 8, "slot_label": "A8"}	pending
500	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	263	{"type": "open_lock", "device_id": "123456", "slot_number": 9, "slot_label": "A9"}	pending
501	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	264	{"type": "open_lock", "device_id": "123456", "slot_number": 10, "slot_label": "A10"}	pending
597	100100	2	3	YBM		2026-06-26 19:47:07.661715	1	\N	\N	\N	\N
502	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	265	{"type": "open_lock", "device_id": "123456", "slot_number": 11, "slot_label": "A11"}	pending
503	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	266	{"type": "open_lock", "device_id": "123456", "slot_number": 12, "slot_label": "A12"}	pending
504	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	267	{"type": "open_lock", "device_id": "123456", "slot_number": 13, "slot_label": "A13"}	pending
505	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	268	{"type": "open_lock", "device_id": "123456", "slot_number": 14, "slot_label": "A14"}	pending
506	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	269	{"type": "open_lock", "device_id": "123456", "slot_number": 15, "slot_label": "A15"}	pending
507	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	270	{"type": "open_lock", "device_id": "123456", "slot_number": 16, "slot_label": "A16"}	pending
508	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	271	{"type": "open_lock", "device_id": "123456", "slot_number": 17, "slot_label": "A17"}	pending
509	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	272	{"type": "open_lock", "device_id": "123456", "slot_number": 18, "slot_label": "A18"}	pending
510	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	273	{"type": "open_lock", "device_id": "123456", "slot_number": 19, "slot_label": "A19"}	pending
511	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	274	{"type": "open_lock", "device_id": "123456", "slot_number": 20, "slot_label": "A20"}	pending
512	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	275	{"type": "open_lock", "device_id": "123456", "slot_number": 21, "slot_label": "A21"}	pending
513	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	276	{"type": "open_lock", "device_id": "123456", "slot_number": 22, "slot_label": "A22"}	pending
514	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	277	{"type": "open_lock", "device_id": "123456", "slot_number": 23, "slot_label": "A23"}	pending
515	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	278	{"type": "open_lock", "device_id": "123456", "slot_number": 24, "slot_label": "A24"}	pending
516	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	279	{"type": "open_lock", "device_id": "123456", "slot_number": 25, "slot_label": "A25"}	pending
517	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	280	{"type": "open_lock", "device_id": "123456", "slot_number": 26, "slot_label": "A26"}	pending
518	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	281	{"type": "open_lock", "device_id": "123456", "slot_number": 27, "slot_label": "A27"}	pending
519	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	282	{"type": "open_lock", "device_id": "123456", "slot_number": 28, "slot_label": "A28"}	pending
520	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	283	{"type": "open_lock", "device_id": "123456", "slot_number": 29, "slot_label": "A29"}	pending
521	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	284	{"type": "open_lock", "device_id": "123456", "slot_number": 30, "slot_label": "A30"}	pending
522	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	285	{"type": "open_lock", "device_id": "123456", "slot_number": 31, "slot_label": "A31"}	pending
523	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	286	{"type": "open_lock", "device_id": "123456", "slot_number": 32, "slot_label": "A32"}	pending
524	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	287	{"type": "open_lock", "device_id": "123456", "slot_number": 33, "slot_label": "A33"}	pending
525	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	288	{"type": "open_lock", "device_id": "123456", "slot_number": 34, "slot_label": "A34"}	pending
526	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	289	{"type": "open_lock", "device_id": "123456", "slot_number": 35, "slot_label": "A35"}	pending
527	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	290	{"type": "open_lock", "device_id": "123456", "slot_number": 36, "slot_label": "A36"}	pending
528	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	291	{"type": "open_lock", "device_id": "123456", "slot_number": 37, "slot_label": "A37"}	pending
529	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	292	{"type": "open_lock", "device_id": "123456", "slot_number": 38, "slot_label": "A38"}	pending
530	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	293	{"type": "open_lock", "device_id": "123456", "slot_number": 39, "slot_label": "A39"}	pending
531	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	294	{"type": "open_lock", "device_id": "123456", "slot_number": 40, "slot_label": "A40"}	pending
532	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	295	{"type": "open_lock", "device_id": "123456", "slot_number": 41, "slot_label": "A41"}	pending
533	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	296	{"type": "open_lock", "device_id": "123456", "slot_number": 42, "slot_label": "A42"}	pending
534	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	297	{"type": "open_lock", "device_id": "123456", "slot_number": 43, "slot_label": "A43"}	pending
535	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	298	{"type": "open_lock", "device_id": "123456", "slot_number": 44, "slot_label": "A44"}	pending
536	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	299	{"type": "open_lock", "device_id": "123456", "slot_number": 45, "slot_label": "A45"}	pending
537	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	300	{"type": "open_lock", "device_id": "123456", "slot_number": 46, "slot_label": "A46"}	pending
538	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	301	{"type": "open_lock", "device_id": "123456", "slot_number": 47, "slot_label": "A47"}	pending
539	\N	1	\N	YBM	\N	2026-06-26 01:26:02	1	8	302	{"type": "open_lock", "device_id": "123456", "slot_number": 48, "slot_label": "A48"}	pending
684	100100	1	2	YBM	376	2026-06-27 14:28:06.957527	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "376", "orderId": "376", "timestamp": "2026-06-27 14:28:06"}	\N
603	100100	1	15	YBM		2026-06-26 19:54:45.955582	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "15", "lockNo": "15", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-26 19:54:45"}	\N
598	100100	2	3	YBM		2026-06-26 19:47:19.008034	1	\N	\N	\N	\N
641	100100	2	16	YBM		2026-06-27 10:04:08.599139	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "2", "boardNo": "2", "lock_no": "16", "lockNo": "16", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 10:04:08"}	\N
687	101001	1	1	WT		2026-06-27 14:42:43.845304	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 14:42:43"}	\N
690	101001	1	1	WT		2026-06-27 15:17:30.720155	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 15:17:30"}	\N
618	100100	1	\N	YBM		2026-06-27 07:06:42.710086	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/smart-locker.apk", "version_name": "1.2.33", "version_code": 153, "force": true}	pending
622	100100	1	\N	YBM		2026-06-27 07:39:51.009737	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/smart-locker.apk?v=1782515669", "version_name": "1.2.33", "version_code": 153, "force": true}	pending
629	100100	1	\N	YBM		2026-06-27 09:14:31.74746	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.38","version_code":158,"md5":"","force":true}	\N
590	100100	2	2	YBM		2026-06-26 18:02:49.449565	1	\N	\N	\N	\N
608	100100	1	2	YBM	20260626211119806002	2026-06-26 21:11:38.353437	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "20260626211119806002", "orderId": "20260626211119806002", "timestamp": "2026-06-26 21:11:38"}	\N
658	101001	1	2	YBM		2026-06-27 11:34:39.238625	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:34:39"}	\N
591	100100	2	1	YBM		2026-06-26 18:03:04.687392	1	\N	\N	\N	\N
592	100100	1	1	YBM		2026-06-26 18:03:11.003203	1	\N	\N	\N	\N
613	100100	1	1	YBM		2026-06-27 06:35:47.719971	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 06:35:47"}	\N
645	101001	1	2	YBM		2026-06-27 11:17:51.935382	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:17:51"}	\N
654	101001	1	2	YBM		2026-06-27 11:25:33.246994	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "2", "lockNo": "2", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:25:33"}	\N
693	101001	1	1	WT		2026-06-27 15:36:45.341849	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 15:36:45"}	\N
650	101001	1	10	YBM	20260627112151757434	2026-06-27 11:22:27.320587	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "10", "lockNo": "10", "protocol": "YBM", "order_id": "20260627112151757434", "orderId": "20260627112151757434", "timestamp": "2026-06-27 11:22:27"}	\N
663	101001	1	11	WT	20260627114452740267	2026-06-27 11:45:25.240816	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": "1", "boardNo": "1", "lock_no": "11", "lockNo": "11", "protocol": "WT", "order_id": "20260627114452740267", "orderId": "20260627114452740267", "timestamp": "2026-06-27 11:45:25"}	\N
668	100100	1	1	YBM		2026-06-27 11:59:49.186763	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": "1", "boardNo": "1", "lock_no": "1", "lockNo": "1", "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 11:59:49"}	\N
672	100100	1	2	YBM	20260627123001901085	2026-06-27 12:30:16.923905	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260627123001901085", "orderId": "20260627123001901085", "timestamp": "2026-06-27 12:30:16"}	\N
696	100100	1	5	YBM	20260627155423256198	2026-06-27 15:54:39.102344	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260627155423256198", "orderId": "20260627155423256198", "timestamp": "2026-06-27 15:54:39"}	\N
698	100100	1	6	YBM	20260627160102439699	2026-06-27 16:01:17.967038	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260627160102439699", "orderId": "20260627160102439699", "timestamp": "2026-06-27 16:01:17"}	\N
675	100100	1	2	YBM	376	2026-06-27 12:30:27.436247	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": 376, "orderId": "376", "timestamp": "2026-06-27 12:30:27"}	\N
678	101001	1	1	YBM		2026-06-27 14:00:49.839138	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-27 14:00:49"}	\N
681	101001	1	1	WT		2026-06-27 14:13:03.594981	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 14:13:03"}	\N
699	100100	1	6	YBM	380	2026-06-27 16:01:24.236995	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": 380, "orderId": "380", "timestamp": "2026-06-27 16:01:24"}	\N
700	100100	1	6	YBM	380	2026-06-27 16:01:25.875382	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": 380, "orderId": "380", "timestamp": "2026-06-27 16:01:25"}	\N
703	100100	1	8	YBM	382	2026-06-27 16:11:39.830498	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": 382, "orderId": "382", "timestamp": "2026-06-27 16:11:39"}	\N
701	100100	1	7	YBM	20260627160609859877	2026-06-27 16:06:33.778693	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260627160609859877", "orderId": "20260627160609859877", "timestamp": "2026-06-27 16:06:33"}	\N
702	100100	1	8	YBM	20260627161116110216	2026-06-27 16:11:33.403516	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260627161116110216", "orderId": "20260627161116110216", "timestamp": "2026-06-27 16:11:33"}	\N
704	100100	1	8	YBM	382	2026-06-27 16:11:42.74643	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": 382, "orderId": "382", "timestamp": "2026-06-27 16:11:42"}	\N
705	100100	1	10	YBM	20260627163808998198	2026-06-27 16:38:26.522808	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260627163808998198", "orderId": "20260627163808998198", "timestamp": "2026-06-27 16:38:26"}	\N
706	101001	1	2	WT	20260627180155088478	2026-06-27 18:02:24.774516	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "WT", "order_id": "20260627180155088478", "orderId": "20260627180155088478", "timestamp": "2026-06-27 18:02:24"}	\N
707	101001	1	3	WT	20260627180357317523	2026-06-27 18:04:23.757409	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "WT", "order_id": "20260627180357317523", "orderId": "20260627180357317523", "timestamp": "2026-06-27 18:04:23"}	\N
708	101001	1	1	WT		2026-06-27 22:44:59.300157	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-27 22:44:59"}	\N
709	100100	1	14	YBM	20260628075013324398	2026-06-28 07:50:38.561333	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260628075013324398", "orderId": "20260628075013324398", "timestamp": "2026-06-28 07:50:38"}	\N
710	101001	1	4	WT	20260628082951623603	2026-06-28 08:30:08.578803	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "WT", "order_id": "20260628082951623603", "orderId": "20260628082951623603", "timestamp": "2026-06-28 08:30:08"}	\N
711	101001	1	5	WT	20260628083429993292	2026-06-28 08:35:13.954846	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "WT", "order_id": "20260628083429993292", "orderId": "20260628083429993292", "timestamp": "2026-06-28 08:35:13"}	\N
712	100100	2	2	YBM	20260628084105846088	2026-06-28 08:41:27.734906	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260628084105846088", "orderId": "20260628084105846088", "timestamp": "2026-06-28 08:41:27"}	\N
713	100100	2	3	YBM	20260628084559522187	2026-06-28 08:46:21.742871	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260628084559522187", "orderId": "20260628084559522187", "timestamp": "2026-06-28 08:46:21"}	\N
714	101001	1	1	WT		2026-06-28 09:01:48.217258	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-28 09:01:48"}	\N
715	101001	1	1	WT		2026-06-28 09:02:21.834605	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-28 09:02:21"}	\N
716	101001	1	\N	YBM		2026-06-28 09:06:20.157848	1	\N	\N	{"type":"update_config","device_id":"101001","deviceId":"101001","serial_port":"/dev/ttyS3","baud_rate":115200,"serial_type":"VioSerial","protocol_type":"WT","timestamp":"2026-06-28 09:05:00"}	\N
717	101001	1	1	WT		2026-06-28 09:07:42.849554	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-28 09:07:42"}	\N
718	100100	2	5	YBM	20260628093341461556	2026-06-28 09:34:39.694704	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260628093341461556", "orderId": "20260628093341461556", "timestamp": "2026-06-28 09:34:39"}	\N
719	101001	1	\N	WT		2026-06-28 09:35:47.703238	1	\N	\N	{"type":"update_config","device_id":"101001","serial_port":"/dev/ttyS3","baud_rate":115200,"serial_type":"VioSerial","protocol_type":"WT","timestamp":"2026-06-28 09:35:00"}	\N
720	101001	1	1	WT		2026-06-28 09:37:14.110154	1	\N	\N	{"type":"open_lock","device_id":"101001","board_no":1,"boardNo":1,"lock_no":1,"lockNo":1,"protocol":"WT","order_id":"","timestamp":"2026-06-28 09:37:00"}	\N
721	100100	2	6	YBM	20260628093722986540	2026-06-28 09:37:42.650351	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260628093722986540", "orderId": "20260628093722986540", "timestamp": "2026-06-28 09:37:42"}	\N
722	101001	1	1	WT		2026-06-28 09:41:45.892581	1	\N	\N	{"type":"update_config","device_id":"101001","serial_port":"/dev/ttyS3","baud_rate":115200,"serial_type":"VioSerial","protocol_type":"WT","timestamp":"2026-06-28 09:35:00"}	\N
723	100100	2	7	YBM	20260628094511242522	2026-06-28 09:45:59.46442	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260628094511242522", "orderId": "20260628094511242522", "timestamp": "2026-06-28 09:45:59"}	\N
724	101001	1	\N	YBM		2026-06-28 10:01:03.209844	1	\N	\N	{"type": "update_config", "device_id": "101001", "serial_port": "/dev/ttyS3", "baud_rate": 115200, "serial_type": "VioSerial", "protocol_type": "WT", "timestamp": "2026-06-28 10:01:00"}	\N
725	101001	1	2	WT	test_wt_001	2026-06-28 10:01:57.738964	1	\N	\N	{"type": "open_lock", "device_id": "101001", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "WT", "order_id": "test_wt_001", "orderId": "test_wt_001", "timestamp": "2026-06-28 10:02:00"}	\N
726	101001	0	0	WT		2026-06-28 10:27:50.414443	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.42","version_code":162,"force":true}	\N
727	101001	0	0	WT		2026-06-28 10:28:04.314309	1	\N	\N	{"type":"update_config","device_id":"101001","serial_port":"/dev/ttyS3","baud_rate":115200,"serial_type":"VioSerial","protocol_type":"WT"}	\N
728	101001	1	2	WT	test_wt_v2	2026-06-28 10:28:12.793888	1	\N	\N	{"type":"open_lock","device_id":"101001","board_no":1,"lock_no":2,"protocol":"WT","order_id":"test_wt_v2"}	\N
729	101001	1	1	WT		2026-06-28 11:01:38.660768	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-28 11:01:38"}	\N
730	101001	1	1	WT	test_wt_v2_0628	2026-06-28 11:32:52.443557	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "test_wt_v2_0628", "orderId": "test_wt_v2_0628", "timestamp": "2026-06-28 11:32:52"}	\N
731	101001	1	1	WT		2026-06-28 11:33:56.419293	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-28 11:33:56"}	\N
732	101001	1	1	WT		2026-06-28 11:35:49.481069	1	\N	\N	{"type": "open_lock", "device_id": "101001", "deviceId": "101001", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "WT", "order_id": "", "orderId": "", "timestamp": "2026-06-28 11:35:49"}	\N
733	100100	2	9	YBM	20260628145155650131	2026-06-28 14:52:23.315268	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260628145155650131", "orderId": "20260628145155650131", "timestamp": "2026-06-28 14:52:23"}	\N
734	100100	2	9	YBM	405	2026-06-28 14:52:35.225001	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": 405, "orderId": "405", "timestamp": "2026-06-28 14:52:35"}	\N
735	100100	2	11	YBM	20260628152256512875	2026-06-28 15:23:20.150875	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260628152256512875", "orderId": "20260628152256512875", "timestamp": "2026-06-28 15:23:20"}	\N
736	100100	2	12	YBM	20260628152957019526	2026-06-28 15:30:18.647157	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260628152957019526", "orderId": "20260628152957019526", "timestamp": "2026-06-28 15:30:18"}	\N
737	101001	1	\N	YBM		2026-06-29 09:41:48.873028	0	15	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.43", "version_code": 163, "force": true, "file_md5": "57c9c3c6e46d2a5e9d6022ea5432dcc7"}	pending
738	100100	1	\N	YBM		2026-06-29 14:01:38.410796	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.43", "version_code": 163, "force": true, "file_md5": ""}	pending
739	100100	2	1	YBM		2026-06-29 14:10:11.907618	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 14:10:11"}	\N
740	100100	2	16	YBM		2026-06-29 14:10:25.975073	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 14:10:25"}	\N
741	100100	1	\N	YBM		2026-06-29 14:22:40.504752	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.43","version_code":163,"force":true}	\N
742	100100	1	1	YBM		2026-06-29 14:27:08.886257	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 14:27:08"}	\N
743	100100	1	16	YBM		2026-06-29 14:27:13.135498	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 14:27:13"}	\N
744	100100	1	\N	YBM		2026-06-29 14:27:56.383333	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.43", "version_code": 163, "force": true, "file_md5": ""}	pending
745	100100	1	\N	YBM		2026-06-29 14:35:30.249256	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.42","version_code":162,"force":true,"file_md5":"66749536a08ab3ff24f98d235e73fe6a"}	pending
746	100100	1	\N	YBM		2026-06-29 14:42:33.630838	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.43","version_code":163,"force":true,"file_md5":"1f6eb2e94393d9ac5f1eb1c6403e8435"}	pending
747	100100	1	\N	YBM		2026-06-29 14:48:47.316517	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.43","version_code":163,"force":true}	pending
748	100100	1	\N	YBM		2026-06-29 14:50:16.386835	1	\N	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.43", "version_code": 163, "force": true, "file_md5": "57c9c3c6e46d2a5e9d6022ea5432dcc7"}	\N
749	100100	1	\N	YBM		2026-06-29 14:50:46.941739	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.43","version_code":163,"force":true,"file_md5":"1f6eb2e94393d9ac5f1eb1c6403e8435"}	pending
750	100100	1	\N	YBM		2026-06-29 14:53:23.941453	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.43","version_code":163,"force":true,"file_md5":"de6f80e8599a83c2c6bb9a39a2b686ac"}	pending
751	100100	1	\N	YBM		2026-06-29 15:02:55.461826	1	\N	\N	{"type":"force_update","download_url":"https://locker.cqdyxl.com/static/locker.apk","version_name":"1.2.43","version_code":163,"force":true,"file_md5":"ae15b3afeae83d00eadbda85d0311a24"}	pending
\.


--
-- Data for Name: phone_openids; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.phone_openids (id, phone, openid, created_at, updated_at) FROM stdin;
2	17722332233	oWrA81xyJP1aI7beoqhd2rxBGPfw	2026-06-28 15:30:04.779791	2026-06-28 15:30:04.779791
\.


--
-- Data for Name: remote_open_logs; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.remote_open_logs (id, merchant_id, cabinet_id, device_id, slot_id, slot_number, action_type, operator, result, success, ip_address, created_at) FROM stdin;
1	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:11
2	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:19
3	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:25
4	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:40
5	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:54
6	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:57:00
7	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:57:06
8	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 08:06:49
9	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 08:07:01
10	\N	\N	\N	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:42:00
11	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:43:59
12	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:48:37
13	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:51:17
14	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:56:00
15	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:36:55
16	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:46:50
17	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:51:45
18	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:53:47
19	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 12:34:41
20	\N	\N	123456	1	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
21	\N	\N	123456	2	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
22	\N	\N	123456	3	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
23	\N	\N	123456	4	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
24	\N	\N	123456	5	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
25	\N	\N	123456	6	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
26	\N	\N	123456	7	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
27	\N	\N	123456	8	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
28	\N	\N	123456	9	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
29	\N	\N	123456	10	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
30	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 15:56:00
31	\N	\N	123456	1	\N	admin_batch_open	admin	success	1	\N	2026-06-19 16:07:22
32	\N	\N	123456	2	\N	admin_batch_open	admin	success	1	\N	2026-06-19 16:07:22
33	\N	\N	123456	3	\N	admin_batch_open	admin	success	1	\N	2026-06-19 16:07:22
34	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 16:07:22
35	\N	\N	test	1	1	emergency_open	\N	success	1	\N	2026-06-19 16:43:59
36	\N	\N	123456	1	1	emergency_open	\N	success	1	\N	2026-06-20 00:50:25
37	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 22:21:48
38	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 22:23:28
39	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 02:50:47
40	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 02:58:54
41	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:01:38
42	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:02:07
43	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:30:31
44	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:32:56
45	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:33:42
46	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:43:31
47	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:13:41
48	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-20 04:13:48
49	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:14:13
50	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:14:21
51	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 04:17:51
52	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:25:38
53	\N	\N	123456	98	\N	admin_open	admin	success	1	\N	2026-06-20 04:25:54
54	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-20 10:36:31
55	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-20 22:34:47
56	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-20 22:35:12
57	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 02:03:43
58	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 02:03:57
59	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 02:04:09
60	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:38:48
61	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:40:07
62	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:51:33
63	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-21 07:54:04
64	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:55:17
65	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:55:34
66	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:00:02
67	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:10:13
68	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:10:40
69	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:22:38
70	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:29:29
71	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 13:04:31
72	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 13:05:22
73	\N	\N	123456	153	\N	admin_open	admin	success	1	\N	2026-06-21 13:06:10
74	\N	\N	123456	177	\N	admin_open	admin	success	1	\N	2026-06-21 13:07:43
75	\N	\N	123456	107	\N	admin_open	admin	success	1	\N	2026-06-21 15:08:05
76	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:25:26
77	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:27:37
78	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:31:56
79	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:49:25
80	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 04:49:29
81	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 05:57:34
82	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 05:57:58
83	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 06:08:20
84	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 09:19:12
85	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:19:16
86	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:14
87	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:19
88	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:23
89	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:28
90	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:34
91	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:40
92	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:45
93	\N	\N	123456	98	\N	admin_open	admin	success	1	\N	2026-06-22 10:52:11
94	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 10:52:17
95	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:22
96	\N	\N	123456	98	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:26
97	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:29
98	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:33
99	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 13:01:15
100	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 23:45:38
101	\N	\N	123456	108	\N	admin_open	admin	success	1	\N	2026-06-22 23:45:43
102	\N	\N	123456	145	\N	admin_open	admin	success	1	\N	2026-06-22 23:45:52
103	\N	\N	123456	145	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:01
104	\N	\N	123456	147	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:04
105	\N	\N	123456	148	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:08
106	\N	\N	123456	149	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:11
107	\N	\N	123456	153	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:16
108	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 23:52:33
109	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 23:52:38
110	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 23:53:21
111	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 23:55:27
112	\N	\N	123456	96	\N	admin_open	admin	success	1	\N	2026-06-22 23:56:23
113	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 23:57:56
114	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:05:31
115	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:07:55
116	\N	\N	123456	153	\N	admin_open	admin	success	1	\N	2026-06-23 00:08:26
117	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:09:11
118	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:09:44
119	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:10:25
120	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:13:08
121	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-23 00:13:40
122	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:14:51
123	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:14:55
124	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:16:36
125	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:17:22
126	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:17:38
127	\N	\N	123456	152	\N	admin_open	admin	success	1	\N	2026-06-23 00:18:39
128	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:21:00
129	\N	\N	123456	152	\N	admin_open	admin	success	1	\N	2026-06-23 00:21:03
130	\N	\N	123456	270	\N	admin_open	admin	success	1	\N	2026-06-23 01:00:16
131	\N	\N	123456	271	\N	admin_open	admin	success	1	\N	2026-06-23 01:00:26
132	\N	\N	123456	287	\N	admin_open	admin	success	1	\N	2026-06-23 01:01:01
133	\N	\N	123456	288	\N	admin_open	admin	success	1	\N	2026-06-23 01:01:06
134	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-23 01:01:10
135	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 04:42:15
136	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 06:00:34
137	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 07:40:55
138	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 07:59:01
139	\N	\N	123456	270	\N	admin_open	admin	success	1	\N	2026-06-23 07:59:05
140	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 11:36:57
141	1	8	\N	261	7	emergency_open	\N	success	1	127.0.0.1	2026-06-24 00:43:00
142	\N	\N	123456	256	\N	admin_open	admin	success	1	\N	2026-06-24 01:37:24
143	\N	\N	123456	256	\N	admin_open	admin	success	1	\N	2026-06-24 03:11:29
144	\N	\N	123456	264	\N	admin_open	admin	success	1	\N	2026-06-24 03:44:42
145	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-24 10:07:01
146	\N	\N	123456	258	\N	admin_open	admin	success	1	\N	2026-06-25 08:49:43
147	1	8	\N	255	1	emergency_open	\N	success	1	127.0.0.1	2026-06-25 09:18:38
148	1	8	\N	255	1	emergency_open	\N	success	1	127.0.0.1	2026-06-25 09:18:41
149	1	8	\N	269	15	emergency_open	\N	success	1	127.0.0.1	2026-06-25 09:18:46
150	\N	\N	123456	271	\N	admin_open	admin	success	1	\N	2026-06-25 09:42:12
151	\N	\N	123456	272	\N	admin_open	admin	success	1	\N	2026-06-25 09:59:45
152	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 11:21:09
153	\N	\N	101002	352	\N	admin_open	admin	success	1	\N	2026-06-25 11:21:51
154	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 13:55:20
155	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 13:57:27
156	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:32
157	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:32
158	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:33
159	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:42
160	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:04:53
161	\N	\N	\N	13	\N	admin_open	admin	success	1	\N	2026-06-25 14:14:33
162	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:50:04
163	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:50:15
164	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:50:39
165	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:52:26
166	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:52:32
167	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:54:38
168	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:54:46
169	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:56:57
170	\N	\N	123456	284	\N	admin_open	admin	success	1	\N	2026-06-25 15:29:41
171	\N	\N	123456	286	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:01
172	\N	\N	123456	287	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:17
173	\N	\N	123456	288	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:23
174	\N	\N	123456	289	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:27
175	\N	\N	123456	293	\N	admin_open	admin	success	1	\N	2026-06-25 22:30:46
176	\N	\N	123456	292	\N	admin_open	admin	success	1	\N	2026-06-25 22:30:50
177	\N	\N	123456	291	\N	admin_open	admin	success	1	\N	2026-06-25 22:30:53
178	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-25 22:31:51
179	\N	\N	123456	301	\N	admin_open	admin	success	1	\N	2026-06-25 22:31:57
180	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-25 22:32:00
181	\N	\N	123456	300	\N	admin_open	admin	success	1	\N	2026-06-25 22:32:04
182	\N	\N	123456	293	\N	admin_open	admin	success	1	\N	2026-06-25 22:39:13
183	\N	\N	123456	294	\N	admin_open	admin	success	1	\N	2026-06-25 22:57:24
184	\N	\N	123456	294	\N	admin_open	admin	success	1	\N	2026-06-25 23:11:40
185	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-25 23:11:45
186	\N	\N	123456	294	\N	admin_open	admin	success	1	\N	2026-06-25 23:36:02
187	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-26 00:42:23
188	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-26 00:47:02
189	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-26 00:50:45
190	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:34:58
191	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:34:58
192	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:34:58
193	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:35:17
194	\N	\N	123456	449	\N	admin_open	admin	success	1	\N	2026-06-26 01:35:20
195	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 02:38:40
196	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 06:42:11
197	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 06:47:18
198	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:02:50
199	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-26 07:02:59
200	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:26
201	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:52
202	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:54
203	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:56
204	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:58
205	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-26 07:43:01
206	\N	\N	100100	380	\N	admin_open	admin	success	1	\N	2026-06-26 07:43:04
207	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:58:00
208	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:58:02
209	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-26 07:58:04
210	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 18:00:47.25663
211	\N	\N	100100	368	\N	admin_open	admin	success	1	\N	2026-06-26 18:02:49.428502
212	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 18:03:04.666112
213	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 18:09:25.559611
214	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 19:31:02.96323
215	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 19:31:07.474492
216	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:47:07.639074
217	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:47:18.988
218	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 19:51:55.59031
219	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:54:39.18208
220	\N	\N	100100	365	\N	admin_open	admin	success	1	\N	2026-06-26 19:54:45.935272
221	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:54:50.053577
222	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 19:55:26.839841
223	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 06:35:47.700775
224	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 06:36:00.425405
225	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 07:07:46.863249
226	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 07:07:56.974742
227	\N	\N	100100	366	\N	admin_open	admin	success	1	\N	2026-06-27 07:08:03.695459
228	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-27 09:31:15.5171
229	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-27 09:34:43.557133
230	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 10:03:35.824128
231	\N	\N	100100	365	\N	admin_open	admin	success	1	\N	2026-06-27 10:03:41.08763
232	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-27 10:03:58.509552
233	\N	\N	100100	382	\N	admin_open	admin	success	1	\N	2026-06-27 10:04:08.579255
234	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:17:24.043736
235	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:17:31.858963
236	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:17:51.915017
237	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:18:10.678942
238	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:18:32.586337
239	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:18:56.349357
240	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:20:28.687406
241	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:24:21.048594
242	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:24:44.709947
243	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:25:12.098877
244	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:25:33.222225
245	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:27:03.063312
246	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:27:19.749983
247	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:34:39.219236
248	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:35:05.419812
249	\N	\N	101001	472	\N	admin_open	admin	success	1	\N	2026-06-27 11:36:49.888779
250	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:40:26.06909
251	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:40:35.438744
252	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 11:55:37.797842
253	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 11:55:46.059861
254	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:56:21.144599
255	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:59:35.689044
256	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:59:49.166442
257	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:59:55.756528
258	\N	\N	100100	504	\N	admin_open	admin	success	1	\N	2026-06-27 12:00:00.363297
259	\N	\N	100100	504	\N	admin_open	admin	success	1	\N	2026-06-27 12:00:04.704309
260	\N	\N	100100	496	\N	admin_open	admin	success	1	\N	2026-06-27 12:32:08.114549
261	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:00:41.46164
262	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:00:49.816395
263	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:11:11.861336
264	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:12:07.682438
265	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:13:03.557823
266	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:19:48.827768
267	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:31:38.510832
268	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:42:31.732545
269	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:42:43.807844
270	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:15:32.294565
271	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:17:30.683167
272	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:17:47.831749
273	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:36:38.738447
274	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:36:45.303563
275	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:43:06.440158
276	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 22:44:59.262628
277	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-28 11:01:38.619476
278	\N	\N	100100	511	\N	admin_open	admin	success	1	\N	2026-06-29 14:10:11.866566
279	\N	\N	100100	526	\N	admin_open	admin	success	1	\N	2026-06-29 14:10:25.937038
280	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 14:27:08.84106
281	\N	\N	100100	510	\N	admin_open	admin	success	1	\N	2026-06-29 14:27:13.095342
\.


--
-- Data for Name: sms_codes; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.sms_codes (id, phone, code, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: storage_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.storage_records (id, cabinet_id, compartment_number, user_phone, access_code, status, store_time, retrieve_time, created_at) FROM stdin;
1	1	3	13844445555	1234	1	2026-06-12 12:52:38.906724	2026-06-12 12:52:39.193363	2026-06-12 04:52:39
2	1	4	13800001111	1111	1	2026-06-12 12:58:06.520154	2026-06-12 12:58:06.797935	2026-06-12 04:58:06
3	1	4	13877778888	9999	1	2026-06-12 13:07:27.142639	2026-06-12 13:07:27.422383	2026-06-12 05:07:27
4	8	10	17725196748	1234	2	2026-06-24 14:32:47.145958	2026-06-24 14:34:44.027213	2026-06-24 06:34:44
5	8	10	17725196748	1234	1	2026-06-24 14:32:47.145958	2026-06-24 14:34:57.748019	2026-06-24 06:34:57
6	8	A10	17725196748	1234	1	2026-06-24 15:33:30.907419	2026-06-24 17:57:15.690936	2026-06-24 09:57:15
7	8	A10	17725196748	1234	1	2026-06-24 15:33:30.907419	2026-06-24 20:08:58.563297	2026-06-24 12:08:58
8	8	A1	13667618419	2584	1	2026-06-24 22:37:34.737997	2026-06-24 22:39:50.475957	2026-06-24 14:39:50
9	8	A15	17725196748	1234	2	2026-06-25 17:24:49.211634	2026-06-25 17:27:38.913835	2026-06-25 09:27:38
10	8	A17	17725196748	1234	2	2026-06-25 17:39:37.186267	2026-06-25 17:42:32.72969	2026-06-25 09:42:32
11	8	A18	17725196748	1234	2	2026-06-25 17:47:03.188676	2026-06-25 17:48:56.614529	2026-06-25 09:48:56
12	8	A18	17725196748	1234	1	2026-06-25 17:47:03.188676	2026-06-25 17:49:10.749128	2026-06-25 09:49:10
13	8	A22	13667618419	1234	2	2026-06-25 21:07:31.636984	2026-06-25 21:36:27.913417	2026-06-25 13:36:27
14	8	A42	17726689234	1234	2	2026-06-26 07:07:04.286167	2026-06-26 07:29:38.957188	2026-06-25 23:29:38
15	8	A43	17726689234	1234	2	2026-06-26 07:30:04.21892	2026-06-26 07:34:24.71674	2026-06-25 23:34:24
16	8	4	18888889999	1234	1	2026-06-26 09:42:16.701258	2026-06-26 09:51:26.378147	2026-06-26 01:51:26
17	8	3	18888889999	1234	1	2026-06-26 09:36:04.314655	2026-06-26 09:51:58.611342	2026-06-26 01:51:58
18	8	6	18888889999	1234	1	2026-06-26 09:49:18.491913	2026-06-26 11:31:45.256536	2026-06-26 03:31:45
19	8	7	18888889999	1234	2	2026-06-26 13:13:40.256117	2026-06-26 13:17:38.140905	2026-06-26 05:17:38
20	8	7	18888889999	1234	1	2026-06-26 13:13:40.256117	2026-06-26 13:17:55.427649	2026-06-26 05:17:55
21	16	13	18888889999	1234	2	2026-06-26 19:52:41.308565	2026-06-26 19:55:06.79708	2026-06-26 19:55:06.794832
22	16	13	18888889999	1234	2	2026-06-26 19:52:41.308565	2026-06-26 19:55:19.183534	2026-06-26 19:55:19.181113
23	16	14	18888889999	1234	2	2026-06-26 20:34:40.996024	2026-06-26 20:38:20.736155	2026-06-26 20:38:20.733726
24	16	42	18888889999	1234	2	2026-06-27 10:04:22.568878	2026-06-27 10:07:53.971529	2026-06-27 10:07:53.969284
25	15	10	18996093393	1111	1	2026-06-27 11:21:51.938666	2026-06-27 11:37:31.395637	2026-06-27 11:37:31.393462
26	16	2	18888889999	1234	1	2026-06-27 12:30:01.700717	2026-06-27 12:37:46.547675	2026-06-27 12:37:46.545524
27	16	14	18888889999	1234	2	2026-06-28 07:50:13.359321	2026-06-28 07:51:05.05579	2026-06-28 07:51:05.053476
28	16	14	18888889999	1234	2	2026-06-28 07:50:13.359321	2026-06-28 07:51:22.960896	2026-06-28 07:51:22.95866
29	16	14	18888889999	1234	1	2026-06-28 07:50:13.359321	2026-06-28 07:51:52.073067	2026-06-28 07:51:52.0707
30	16	28	17722332233	2584	1	2026-06-28 15:29:57.720409	2026-06-28 15:31:16.549595	2026-06-28 15:31:16.547281
31	16	25	18888889999	1234	2	2026-06-28 14:51:55.54862	2026-06-28 15:32:12.795953	2026-06-28 15:32:12.793405
32	16	25	18888889999	1234	1	2026-06-28 14:51:55.54862	2026-06-28 15:32:31.404132	2026-06-28 15:32:31.401547
33	16	27	17722332233	1475	1	2026-06-28 15:22:56.856654	2026-06-28 15:34:04.539229	2026-06-28 15:34:04.537009
34	16	19	17722332233	1234	1	2026-06-28 08:45:59.421579	2026-06-28 15:34:06.147277	2026-06-28 15:34:06.144756
35	16	18	17722332233	3698	1	2026-06-28 08:41:05.289221	2026-06-28 15:34:07.976224	2026-06-28 15:34:07.974022
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.system_settings (id, setting_key, setting_value, description) FROM stdin;
1	deposit_amount	25	保证金金额（元）
2	sms_enabled	false	是否开启短信验证
3	system_name	智能寄存柜系统	系统名称
4	deposit_timeout	24	超时时间（小时）
12	pay_mode	wechat	支付模式：mock=模拟支付，wechat=微信支付
28	order_hide_rate	0	订单隐藏比例(%)
29	order_hide_whitelist	\N	订单隐藏白名单手机号(逗号分隔)
30	duplicate_days	7	重复用户过滤天数
31	duplicate_limit	5	重复用户过滤单数
32	duplicate_filter_enabled	0	是否开启重复用户过滤
3943	channel_rotation_mode	round_robin	支付渠道轮转模式: round_robin=严格轮转, weighted=加权随机
4024	test_key	test_value	\N
11185	allow_h5_to_mp	1	是否允许H5跳转小程序
\.


--
-- Data for Name: user_balances; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.user_balances (id, phone, balance, total_deposited, total_withdrawn, first_use_time, created_at, wechat_name, openid) FROM stdin;
20	17726689234	0	20	20	2026-06-26 07:04:32.799063	2026-06-25 23:04:32	\N	
22	18888889999	40	120	120	2026-06-26 09:38:11.776791	2026-06-26 01:38:11	\N	
1	13667164843	0	0	0	2026-06-13 04:29:00	2026-06-13 04:29:00	\N	
3	13667618491	0	0	0	2026-06-13 03:09:23	2026-06-13 03:09:23	\N	
4	13667618494	0	0	0	2026-06-13 08:45:25	2026-06-13 08:45:25	\N	
5	13667619418	0	0	0	2026-06-12 14:06:46	2026-06-12 14:06:46	\N	
6	13800001111	0	0	0	2026-06-12 04:57:50	2026-06-12 04:57:50	\N	
7	13800138000	-10	0	10	2026-06-12 04:31:14	2026-06-12 04:31:14	\N	
8	13811112222	0	0	0	2026-06-12 04:37:27	2026-06-12 04:37:27	\N	
9	13833334444	0	0	0	2026-06-12 04:41:06	2026-06-12 04:41:06	\N	
10	13844445555	0	0	0	2026-06-12 04:52:38	2026-06-12 04:52:38	\N	
11	13855556666	0	0	0	2026-06-12 04:57:20	2026-06-12 04:57:20	\N	
12	13877778888	0	0	0	2026-06-12 05:07:27	2026-06-12 05:07:27	\N	
13	13900001111	0	0	0	2026-06-11 08:46:51	2026-06-11 08:46:51	\N	
14	13900139000	0	0	0	2026-06-15 04:33:51	2026-06-15 04:33:51	\N	
21	18896963355	0	0	0	2026-06-26 09:27:18.112343	2026-06-26 01:27:18	\N	
15	18996093393	42	42	0	2026-06-13 00:48:12	2026-06-13 00:48:12	\N	
23	18983079797	1	1	0	2026-06-27 18:04:23.736538	2026-06-27 18:04:23.731391		
16	13667618719	0	0	0	2026-06-23 22:42:29.591611	2026-06-23 14:42:29	\N	
24	17722332233	0	80	80	2026-06-28 08:41:27.717903	2026-06-28 08:41:27.715242		
2	13667618419	-20	0	20	2026-06-12 13:50:47	2026-06-12 13:50:47	\N	
17	17725196748	-110	0	110	2026-06-24 10:25:47.775458	2026-06-24 02:25:47	\N	
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.user_profiles (openid, wechat_name, updated_at) FROM stdin;
\.


--
-- Data for Name: withdrawal_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.withdrawal_records (id, order_id, user_phone, amount, status, apply_time, approve_time, approver, click_count, auto_approve_time, created_at, openid, error_msg) FROM stdin;
3	\N	17725196748	20	3	2026-06-24 03:03:43	\N	\N	1	\N	2026-06-24 03:03:43	\N	\N
4	\N	13667618419	20	3	2026-06-24 03:07:02	\N	\N	1	\N	2026-06-24 03:07:02	\N	\N
5	\N	17725196748	20	3	2026-06-24 03:57:10	\N	\N	1	\N	2026-06-24 03:57:10	\N	\N
6	\N	13667618419	10	3	2026-06-24 04:15:03	\N	\N	1	\N	2026-06-24 04:15:03	\N	\N
7	\N	17725196748	20	2	2026-06-24 04:16:56	\N	\N	1	\N	2026-06-24 04:16:56	\N	\N
9	\N	17725196748	20	3	2026-06-24 06:35:26	\N	\N	1	2026-06-24 06:35:26	2026-06-24 06:35:26	\N	\N
10	\N	17725196748	20	3	2026-06-24 09:45:35	2026-06-24 09:47:18	admin	1	\N	2026-06-24 09:45:35	\N	\N
14	196	17725196748	20	2	2026-06-24 12:08:58	2026-06-25 10:06:55	\N	1	2026-06-24 20:08:58	2026-06-24 12:08:58	\N	\N
15	198	13667618419	20	2	2026-06-24 14:39:50	2026-06-25 10:06:56	\N	1	2026-06-24 22:39:50	2026-06-24 14:39:50	\N	\N
17	\N	17725196748	40	3	2026-06-24 15:23:46	\N	\N	1	2026-06-24 15:23:46	2026-06-24 15:23:46	\N	\N
18	129	13800138000	20	3	2026-06-24 16:59:19	\N	\N	1	2026-06-24 16:59:19	2026-06-24 16:59:19	\N	\N
19	129	13800138000	20	3	2026-06-24 17:03:24	\N	\N	1	2026-06-24 17:03:24	2026-06-24 17:03:24	\N	\N
20	277	17725196748	20	3	2026-06-25 09:49:11	\N	\N	1	2026-06-25 17:49:11	2026-06-25 09:49:11	\N	\N
32	277	17725196748	20	2	2026-06-25 10:51:58	\N	system	1	2026-06-25 10:51:58	2026-06-25 10:51:58	\N	\N
33	276	17725196748	10	2	2026-06-25 11:26:30	\N	system	1	2026-06-25 11:26:30	2026-06-25 11:26:30	\N	\N
34	275	17725196748	20	2	2026-06-25 11:38:03	\N	system	1	2026-06-25 11:38:03	2026-06-25 11:38:03	\N	\N
37	315	18888889999	20	2	2026-06-26 02:48:20	\N	system	1	2026-06-26 02:48:20	2026-06-26 02:48:20	\N	\N
39	316	18888889999	20	2	2026-06-26 04:04:47	\N	system	1	2026-06-26 04:04:47	2026-06-26 04:04:47	\N	\N
40	318	18888889999	20	2	2026-06-26 06:54:23	\N	system	1	2026-06-26 06:54:23	2026-06-26 06:54:23	\N	\N
79	390	18888889999	20	2	2026-06-28 08:02:31.470551	\N	\N	1	2026-06-28 08:02:31.470551+08	2026-06-28 08:02:31.470551		\N
94	\N	17722332233	100	5	2026-06-28 15:33:50.52335	\N	system_cleanup	1	\N	2026-06-28 15:33:50.52335	\N	\N
38	315	18888889999	20	2	2026-06-26 02:48:21	\N	system	1	2026-06-26 02:48:21	2026-06-26 02:48:21	\N	订单已全额退款
35	284	13667618419	20	3	2026-06-26 00:04:10	\N	\N	1	2026-06-26 00:04:10	2026-06-26 00:04:10	\N	\N
36	188	13667618719	20	3	2026-06-26 00:06:38	\N	\N	1	2026-06-26 00:06:38	2026-06-26 00:06:38	\N	\N
80	\N	18888889999	20	5	2026-06-28 08:39:07.769374	\N	system_cleanup	1	\N	2026-06-28 08:39:07.769374		\N
44	302	17725196748	20	3	2026-06-26 21:07:22.894042	\N	\N	1	2026-06-26 21:07:22.894042+08	2026-06-26 21:07:22.894042	\N	\N
45	302	17725196748	20	3	2026-06-26 21:11:30.524503	\N	\N	1	2026-06-26 21:11:30.524503+08	2026-06-26 21:11:30.524503	\N	\N
85	\N	18888889999	460	5	2026-06-28 15:18:39.397813	\N	system_cleanup	1	\N	2026-06-28 15:18:39.397813	\N	\N
86	\N	18888889999	460	5	2026-06-28 15:18:43.106437	\N	system_cleanup	1	\N	2026-06-28 15:18:43.106437	\N	\N
87	\N	18888889999	460	5	2026-06-28 15:18:49.610057	\N	system_cleanup	1	\N	2026-06-28 15:18:49.610057	\N	\N
83	\N	13800138000	10	5	2026-06-28 10:49:16.606119	\N	system_cleanup	1	\N	2026-06-28 10:49:16.606119	\N	\N
21	\N	13800138000	5	3	2026-06-25 09:57:30	\N	\N	1	\N	2026-06-25 09:57:30	\N	\N
43	302	17725196748	20	2	2026-06-26 19:56:16.528003	\N	\N	1	2026-06-26 19:56:16.528003+08	2026-06-26 19:56:16.528003	\N	\N
88	\N	18888889999	460	5	2026-06-28 15:20:59.819987	\N	system_cleanup	1	\N	2026-06-28 15:20:59.819987	\N	\N
22	\N	13800138000	5	3	2026-06-25 09:57:54	\N	\N	1	\N	2026-06-25 09:57:54	\N	\N
89	\N	18888889999	460	5	2026-06-28 15:21:02.545764	\N	system_cleanup	1	\N	2026-06-28 15:21:02.545764	\N	\N
23	265	13800138000	20	3	2026-06-25 09:58:35	\N	\N	1	\N	2026-06-25 09:58:35	\N	\N
84	\N	13800138000	10	5	2026-06-28 12:16:47.023477	\N	system_cleanup	1	\N	2026-06-28 12:16:47.023477	\N	\N
81	391	18996093393	47	5	2026-06-28 09:04:09.5201	\N	system_cleanup	1	\N	2026-06-28 09:04:09.5201	oLhbm2LrGNu2Ka_r96cs6wF-Tu0E	\N
82	393	18983079797	3	5	2026-06-28 09:04:20.367748	\N	system_cleanup	1	\N	2026-06-28 09:04:20.367748	oLhbm2F46i0hw0ncI9vJ6QL0p2Y8	\N
90	\N	17722332233	40	5	2026-06-28 15:22:32.563121	\N	system_cleanup	1	\N	2026-06-28 15:22:32.563121	\N	\N
91	\N	13800138000	1	5	2026-06-28 15:24:18.840454	\N	system_cleanup	1	\N	2026-06-28 15:24:18.840454	\N	\N
92	\N	17722332233	60	5	2026-06-28 15:24:30.750934	\N	system_cleanup	1	\N	2026-06-28 15:24:30.750934	\N	\N
93	\N	17722332233	60	5	2026-06-28 15:24:32.700862	\N	system_cleanup	1	\N	2026-06-28 15:24:32.700862	\N	\N
95	\N	17722332233	160	5	2026-06-28 16:07:49.110583	\N	system_cleanup	1	\N	2026-06-28 16:07:49.110583	\N	\N
96	\N	17722332233	160	5	2026-06-28 16:07:50.923614	\N	system_cleanup	1	\N	2026-06-28 16:07:50.923614	\N	\N
97	408	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N
98	407	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N
99	397	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N
100	396	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N
101	307	17726689234	20	2	2026-06-28 16:23:28.184636	\N	\N	1	2026-06-28 16:23:28.184636+08	2026-06-28 16:23:28.184636	\N	\N
77	332	18888889999	20	4	2026-06-27 19:22:32.159527	\N	system	1	2026-06-27 19:22:32.159527+08	2026-06-27 19:22:32.159527	\N	订单已全额退款
78	389	18888889999	20	4	2026-06-28 07:56:51.812019	\N	\N	1	2026-06-28 07:56:51.812019+08	2026-06-28 07:56:51.812019		记录不存在
102	405	18888889999	20	2	2026-06-28 17:25:25.120129	\N	\N	1	2026-06-28 17:25:25.120129+08	2026-06-28 17:25:25.120129	\N	\N
\.


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 1, true);


--
-- Name: after_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.after_sales_id_seq', 1, true);


--
-- Name: agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.agents_id_seq', 3, true);


--
-- Name: alarms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.alarms_id_seq', 1, true);


--
-- Name: apk_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.apk_version_id_seq', 40, true);


--
-- Name: blacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.blacklist_id_seq', 1, true);


--
-- Name: cabinet_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cabinet_groups_id_seq', 1, true);


--
-- Name: cabinet_slots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cabinet_slots_id_seq', 526, true);


--
-- Name: cabinets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cabinets_id_seq', 23, true);


--
-- Name: cached_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cached_orders_id_seq', 1, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.companies_id_seq', 2, true);


--
-- Name: complaints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.complaints_id_seq', 1, true);


--
-- Name: device_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.device_alerts_id_seq', 571, true);


--
-- Name: device_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.device_logs_id_seq', 856, true);


--
-- Name: device_update_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.device_update_logs_id_seq', 1, false);


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.devices_id_seq', 1, true);


--
-- Name: door_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.door_records_id_seq', 260, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.employees_id_seq', 1, true);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.locations_id_seq', 6, true);


--
-- Name: mainboards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.mainboards_id_seq', 36, true);


--
-- Name: merchants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.merchants_id_seq', 4, true);


--
-- Name: offline_retrieve_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.offline_retrieve_records_id_seq', 1, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.orders_id_seq', 408, true);


--
-- Name: payment_channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.payment_channels_id_seq', 3, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.payments_id_seq', 200, true);


--
-- Name: pending_lock_cmds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.pending_lock_cmds_id_seq', 751, true);


--
-- Name: phone_openids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.phone_openids_id_seq', 2, true);


--
-- Name: remote_open_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.remote_open_logs_id_seq', 281, true);


--
-- Name: sms_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.sms_codes_id_seq', 1, true);


--
-- Name: storage_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.storage_records_id_seq', 35, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 11185, true);


--
-- Name: user_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.user_balances_id_seq', 24, true);


--
-- Name: withdrawal_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.withdrawal_records_id_seq', 102, true);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_username_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_username_key UNIQUE (username);


--
-- Name: after_sales after_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.after_sales
    ADD CONSTRAINT after_sales_pkey PRIMARY KEY (id);


--
-- Name: after_sales after_sales_ticket_no_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.after_sales
    ADD CONSTRAINT after_sales_ticket_no_key UNIQUE (ticket_no);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: alarms alarms_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.alarms
    ADD CONSTRAINT alarms_pkey PRIMARY KEY (id);


--
-- Name: apk_version apk_version_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.apk_version
    ADD CONSTRAINT apk_version_pkey PRIMARY KEY (id);


--
-- Name: blacklist blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.blacklist
    ADD CONSTRAINT blacklist_pkey PRIMARY KEY (id);


--
-- Name: cabinet_groups cabinet_groups_group_code_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_groups
    ADD CONSTRAINT cabinet_groups_group_code_key UNIQUE (group_code);


--
-- Name: cabinet_groups cabinet_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_groups
    ADD CONSTRAINT cabinet_groups_pkey PRIMARY KEY (id);


--
-- Name: cabinet_slots cabinet_slots_cabinet_id_slot_number_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_slots
    ADD CONSTRAINT cabinet_slots_cabinet_id_slot_number_key UNIQUE (cabinet_id, slot_number);


--
-- Name: cabinet_slots cabinet_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_slots
    ADD CONSTRAINT cabinet_slots_pkey PRIMARY KEY (id);


--
-- Name: cabinets cabinets_cabinet_code_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinets
    ADD CONSTRAINT cabinets_cabinet_code_key UNIQUE (cabinet_code);


--
-- Name: cabinets cabinets_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinets
    ADD CONSTRAINT cabinets_pkey PRIMARY KEY (id);


--
-- Name: cached_orders cached_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cached_orders
    ADD CONSTRAINT cached_orders_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: complaints complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.complaints
    ADD CONSTRAINT complaints_pkey PRIMARY KEY (id);


--
-- Name: device_alerts device_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_alerts
    ADD CONSTRAINT device_alerts_pkey PRIMARY KEY (id);


--
-- Name: device_logs device_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_logs
    ADD CONSTRAINT device_logs_pkey PRIMARY KEY (id);


--
-- Name: device_update_logs device_update_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_update_logs
    ADD CONSTRAINT device_update_logs_pkey PRIMARY KEY (id);


--
-- Name: devices devices_device_id_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_device_id_key UNIQUE (device_id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: door_records door_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.door_records
    ADD CONSTRAINT door_records_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: mainboards mainboards_cabinet_id_board_index_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.mainboards
    ADD CONSTRAINT mainboards_cabinet_id_board_index_key UNIQUE (cabinet_id, board_index);


--
-- Name: mainboards mainboards_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.mainboards
    ADD CONSTRAINT mainboards_pkey PRIMARY KEY (id);


--
-- Name: merchants merchants_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT merchants_pkey PRIMARY KEY (id);


--
-- Name: offline_retrieve_records offline_retrieve_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.offline_retrieve_records
    ADD CONSTRAINT offline_retrieve_records_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_no_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_no_key UNIQUE (order_no);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payment_channels payment_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payment_channels
    ADD CONSTRAINT payment_channels_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pending_lock_cmds pending_lock_cmds_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.pending_lock_cmds
    ADD CONSTRAINT pending_lock_cmds_pkey PRIMARY KEY (id);


--
-- Name: phone_openids phone_openids_phone_openid_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.phone_openids
    ADD CONSTRAINT phone_openids_phone_openid_key UNIQUE (phone, openid);


--
-- Name: phone_openids phone_openids_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.phone_openids
    ADD CONSTRAINT phone_openids_pkey PRIMARY KEY (id);


--
-- Name: remote_open_logs remote_open_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.remote_open_logs
    ADD CONSTRAINT remote_open_logs_pkey PRIMARY KEY (id);


--
-- Name: sms_codes sms_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.sms_codes
    ADD CONSTRAINT sms_codes_pkey PRIMARY KEY (id);


--
-- Name: storage_records storage_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.storage_records
    ADD CONSTRAINT storage_records_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_key UNIQUE (setting_key);


--
-- Name: user_balances user_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balances
    ADD CONSTRAINT user_balances_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (openid);


--
-- Name: withdrawal_records withdrawal_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.withdrawal_records
    ADD CONSTRAINT withdrawal_records_pkey PRIMARY KEY (id);


--
-- Name: idx_cabinets_heartbeat; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_cabinets_heartbeat ON public.cabinets USING btree (last_heartbeat);


--
-- Name: idx_cabinets_location; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_cabinets_location ON public.cabinets USING btree (location_id);


--
-- Name: idx_cabinets_mainboard; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_cabinets_mainboard ON public.cabinets USING btree (mainboard_device_id);


--
-- Name: idx_complaints_order_id; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_complaints_order_id ON public.complaints USING btree (order_id);


--
-- Name: idx_orders_cabinet; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_orders_cabinet ON public.orders USING btree (cabinet_id);


--
-- Name: idx_orders_phone; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_orders_phone ON public.orders USING btree (user_phone);


--
-- Name: idx_orders_slot; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_orders_slot ON public.orders USING btree (slot_id);


--
-- Name: idx_phone_openids_phone; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE UNIQUE INDEX idx_phone_openids_phone ON public.phone_openids USING btree (phone);


--
-- Name: idx_slots_cabinet; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_slots_cabinet ON public.cabinet_slots USING btree (cabinet_id);


--
-- Name: idx_slots_status; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_slots_status ON public.cabinet_slots USING btree (status);


--
-- Name: user_balances_phone_openid_uk; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE UNIQUE INDEX user_balances_phone_openid_uk ON public.user_balances USING btree (phone, openid);


--
-- PostgreSQL database dump complete
--

\unrestrict yTixLKRo3ctHdgzMHZqXCMqMoS0Yywyff6BTS0qVSR2eYTbLn9QuYIgI8alVO1V

