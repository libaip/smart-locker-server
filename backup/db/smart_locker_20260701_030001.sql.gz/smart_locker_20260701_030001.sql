--
-- PostgreSQL database dump
--

\restrict gG2mEeKMwaI7f87HaaNtCp0fZjmfIvd6yQMHJ5evZJuxm9rzJf2ioQmPtEhyYjS

-- Dumped from database version 14.23 (Ubuntu 14.23-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.23 (Ubuntu 14.23-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'admin'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auth_token text
);


ALTER TABLE public.admin_users OWNER TO locker_admin;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_users_id_seq OWNER TO locker_admin;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: after_sales; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.after_sales (
    id integer NOT NULL,
    ticket_no text,
    cabinet_id integer,
    location_id integer,
    device_id text,
    fault_type text,
    description text,
    status text DEFAULT 'pending'::text,
    handler text,
    handler_note text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.after_sales OWNER TO locker_admin;

--
-- Name: after_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.after_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.after_sales_id_seq OWNER TO locker_admin;

--
-- Name: after_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.after_sales_id_seq OWNED BY public.after_sales.id;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.agents (
    id integer NOT NULL,
    name text NOT NULL,
    contact_name text,
    contact_phone text NOT NULL,
    password_hash text NOT NULL,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    commission_rate double precision DEFAULT 0,
    auth_token text DEFAULT ''::text,
    login_attempts integer DEFAULT 0,
    is_locked integer DEFAULT 0,
    plain_password text DEFAULT ''::text
);


ALTER TABLE public.agents OWNER TO locker_admin;

--
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agents_id_seq OWNER TO locker_admin;

--
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.agents_id_seq OWNED BY public.agents.id;


--
-- Name: alarms; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.alarms (
    id integer NOT NULL,
    type text NOT NULL,
    cabinet_id integer,
    device_id text,
    content text,
    level integer DEFAULT 1,
    status text DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone,
    resolver text
);


ALTER TABLE public.alarms OWNER TO locker_admin;

--
-- Name: alarms_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.alarms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alarms_id_seq OWNER TO locker_admin;

--
-- Name: alarms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.alarms_id_seq OWNED BY public.alarms.id;


--
-- Name: apk_version; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.apk_version (
    id integer NOT NULL,
    version_name text,
    version_code integer,
    download_url text,
    update_desc text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    file_md5 text DEFAULT ''::text
);


ALTER TABLE public.apk_version OWNER TO locker_admin;

--
-- Name: apk_version_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.apk_version_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.apk_version_id_seq OWNER TO locker_admin;

--
-- Name: apk_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.apk_version_id_seq OWNED BY public.apk_version.id;


--
-- Name: blacklist; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.blacklist (
    id integer NOT NULL,
    phone text NOT NULL,
    reason text,
    cabinet_id integer,
    operator text,
    status text DEFAULT 1,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.blacklist OWNER TO locker_admin;

--
-- Name: blacklist_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.blacklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blacklist_id_seq OWNER TO locker_admin;

--
-- Name: blacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.blacklist_id_seq OWNED BY public.blacklist.id;


--
-- Name: cabinet_groups; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cabinet_groups (
    id integer NOT NULL,
    location_id integer,
    group_code text NOT NULL,
    name text,
    screen_url text,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.cabinet_groups OWNER TO locker_admin;

--
-- Name: cabinet_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cabinet_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cabinet_groups_id_seq OWNER TO locker_admin;

--
-- Name: cabinet_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cabinet_groups_id_seq OWNED BY public.cabinet_groups.id;


--
-- Name: cabinet_slots; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cabinet_slots (
    id integer NOT NULL,
    cabinet_id integer NOT NULL,
    slot_number integer NOT NULL,
    slot_size text DEFAULT 'M'::text,
    status integer DEFAULT 1,
    cabinet_code text,
    mainboard_id integer,
    display_number integer,
    board_no integer DEFAULT 1,
    lock_no integer DEFAULT 1,
    slot_label text DEFAULT ''::text,
    updated_at timestamp without time zone
);


ALTER TABLE public.cabinet_slots OWNER TO locker_admin;

--
-- Name: cabinet_slots_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cabinet_slots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cabinet_slots_id_seq OWNER TO locker_admin;

--
-- Name: cabinet_slots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cabinet_slots_id_seq OWNED BY public.cabinet_slots.id;


--
-- Name: cabinets; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cabinets (
    id integer NOT NULL,
    location_id integer,
    cabinet_code text NOT NULL,
    name text,
    total_slots integer DEFAULT 12,
    status integer DEFAULT 1,
    last_heartbeat timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    group_id integer,
    deposit_amount double precision DEFAULT 20,
    mainboard_device_id text DEFAULT ''::text,
    mainboard_source text DEFAULT ''::text,
    charge_mode text DEFAULT 'deposit'::text,
    app_version text DEFAULT ''::text,
    app_version_code integer DEFAULT 0,
    business_status text DEFAULT 1,
    business_hours text,
    customer_phone text,
    updated_at timestamp without time zone,
    usage_rules text,
    per_use_price double precision DEFAULT 0
);


ALTER TABLE public.cabinets OWNER TO locker_admin;

--
-- Name: cabinets_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cabinets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cabinets_id_seq OWNER TO locker_admin;

--
-- Name: cabinets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cabinets_id_seq OWNED BY public.cabinets.id;


--
-- Name: cached_orders; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cached_orders (
    id integer NOT NULL,
    order_id integer NOT NULL,
    order_no text,
    cabinet_id integer,
    slot_id integer,
    slot_number text,
    deposit_amount double precision,
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    synced integer DEFAULT 0
);


ALTER TABLE public.cached_orders OWNER TO locker_admin;

--
-- Name: cached_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cached_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cached_orders_id_seq OWNER TO locker_admin;

--
-- Name: cached_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cached_orders_id_seq OWNED BY public.cached_orders.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name text NOT NULL,
    credit_code text,
    contact_person text,
    contact_phone text,
    address text,
    status text DEFAULT 1,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.companies OWNER TO locker_admin;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_id_seq OWNER TO locker_admin;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: complaints; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.complaints (
    id integer NOT NULL,
    user_phone text NOT NULL,
    type text DEFAULT 'self'::text,
    content text NOT NULL,
    order_no text,
    status text DEFAULT 0,
    reply text,
    reply_time timestamp without time zone,
    wx_complaint_id text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    complaint_type text DEFAULT 'complaint'::text,
    order_id integer
);


ALTER TABLE public.complaints OWNER TO locker_admin;

--
-- Name: complaints_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.complaints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.complaints_id_seq OWNER TO locker_admin;

--
-- Name: complaints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.complaints_id_seq OWNED BY public.complaints.id;


--
-- Name: device_alerts; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.device_alerts (
    id integer NOT NULL,
    device_id text,
    alert_type text,
    detail text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_alerts OWNER TO locker_admin;

--
-- Name: device_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.device_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_alerts_id_seq OWNER TO locker_admin;

--
-- Name: device_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.device_alerts_id_seq OWNED BY public.device_alerts.id;


--
-- Name: device_logs; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.device_logs (
    id integer NOT NULL,
    device_id text,
    logs text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    log_type text DEFAULT 'info'::text,
    content text,
    level text DEFAULT 'info'::text,
    detail text,
    device_name text,
    status text
);


ALTER TABLE public.device_logs OWNER TO locker_admin;

--
-- Name: device_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.device_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_logs_id_seq OWNER TO locker_admin;

--
-- Name: device_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.device_logs_id_seq OWNED BY public.device_logs.id;


--
-- Name: device_update_logs; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.device_update_logs (
    id integer NOT NULL,
    device_id text,
    success integer DEFAULT 0,
    version_name text DEFAULT ''::text,
    version_code integer DEFAULT 0,
    error_msg text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.device_update_logs OWNER TO locker_admin;

--
-- Name: device_update_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.device_update_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_update_logs_id_seq OWNER TO locker_admin;

--
-- Name: device_update_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.device_update_logs_id_seq OWNED BY public.device_update_logs.id;


--
-- Name: devices; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    device_id text,
    device_name text,
    device_type text,
    status text,
    remark text,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.devices OWNER TO locker_admin;

--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.devices_id_seq OWNER TO locker_admin;

--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: door_query_cache; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.door_query_cache (
    request_id text NOT NULL,
    device_id text,
    board_no integer,
    lock_no integer,
    cabinet_id integer,
    is_open boolean,
    door_status text,
    query_success boolean,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.door_query_cache OWNER TO locker_admin;

--
-- Name: door_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.door_records (
    id integer NOT NULL,
    device_id text,
    board_no text,
    lock_no text,
    order_id text,
    open_type text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.door_records OWNER TO locker_admin;

--
-- Name: door_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.door_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.door_records_id_seq OWNER TO locker_admin;

--
-- Name: door_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.door_records_id_seq OWNED BY public.door_records.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    merchant_id integer NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'staff'::text,
    status text DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auth_token text DEFAULT ''::text,
    permissions text DEFAULT '[]'::text,
    login_attempts integer DEFAULT 0,
    is_locked integer DEFAULT 0,
    plain_password text DEFAULT ''::text
);


ALTER TABLE public.employees OWNER TO locker_admin;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employees_id_seq OWNER TO locker_admin;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    merchant_id integer,
    name text NOT NULL,
    address text,
    longitude double precision,
    latitude double precision,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    withdraw_enabled integer DEFAULT 1,
    auto_approve_day integer DEFAULT 1,
    auto_approve_time text DEFAULT '12:00'::text,
    auto_approve_rate double precision DEFAULT 80,
    click_free_count integer DEFAULT 3,
    anti_test_minutes integer DEFAULT 30,
    anti_test_auto_refund integer DEFAULT 1,
    hide_ratio integer DEFAULT 0,
    whitelist_phones text DEFAULT ''::text,
    duplicate_filter_enabled integer DEFAULT 0,
    duplicate_filter_days integer DEFAULT 7,
    duplicate_filter_limit integer DEFAULT 3,
    show_refunding_status text DEFAULT 1,
    refund_approve_rate double precision DEFAULT 80,
    refund_approve_start_min integer DEFAULT 60,
    refund_approve_end_min integer DEFAULT 300,
    contact_phone text DEFAULT ''::text,
    open_time text DEFAULT '08:00'::text,
    close_time text DEFAULT '22:00'::text,
    allow_slot_select integer DEFAULT 0,
    slot_assign_mode text DEFAULT 'auto'::text,
    allow_mid_retrieve integer DEFAULT 1,
    retrieve_mode text DEFAULT 'both'::text,
    allow_h5_to_mp integer DEFAULT 0,
    show_qr_follow integer DEFAULT 0,
    force_follow_mp integer DEFAULT 0,
    h5_url text DEFAULT ''::text,
    show_slot_count integer DEFAULT 1,
    screen_show_title integer DEFAULT 1,
    screen_title text DEFAULT ''::text,
    slot_full_alert integer DEFAULT 0,
    slot_full_text text DEFAULT ''::text,
    end_alert_minutes integer DEFAULT 0,
    enable_clear_box integer DEFAULT 0,
    clear_box_time text DEFAULT '23:00'::text,
    clear_box_cycle integer DEFAULT 1,
    deposit_random integer DEFAULT 0,
    deposit_min double precision DEFAULT 0,
    deposit_max double precision DEFAULT 0,
    contact_name text DEFAULT ''::text,
    refund_mode text DEFAULT 'auto_approve'::text,
    withdraw_mode text DEFAULT 'manual_approve'::text,
    province text DEFAULT ''::text,
    agent_id integer,
    city text DEFAULT ''::text,
    usage_rules text DEFAULT ''::text,
    deposit_amount double precision DEFAULT 20.0,
    mp_appid text DEFAULT ''::text,
    balance_hide_enabled integer DEFAULT 0,
    balance_hide_days integer DEFAULT 30
);


ALTER TABLE public.locations OWNER TO locker_admin;

--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locations_id_seq OWNER TO locker_admin;

--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: mainboards; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.mainboards (
    id integer NOT NULL,
    cabinet_id integer NOT NULL,
    board_index integer NOT NULL,
    slot_count integer DEFAULT 16,
    name text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    serial_port text DEFAULT 'ttyS1'::text,
    baud_rate integer DEFAULT 9600,
    address text DEFAULT ''::text,
    board_type text DEFAULT 'main'::text,
    protocol text DEFAULT 'YBM'::text
);


ALTER TABLE public.mainboards OWNER TO locker_admin;

--
-- Name: mainboards_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.mainboards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mainboards_id_seq OWNER TO locker_admin;

--
-- Name: mainboards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.mainboards_id_seq OWNED BY public.mainboards.id;


--
-- Name: merchants; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.merchants (
    id integer NOT NULL,
    name text NOT NULL,
    contact_name text,
    contact_phone text NOT NULL,
    password_hash text NOT NULL,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    agent_id integer,
    auth_token text,
    permissions text DEFAULT '[]'::text,
    login_attempts integer DEFAULT 0,
    is_locked integer DEFAULT 0,
    plain_password text DEFAULT ''::text,
    commission_per_order numeric(10,2) DEFAULT 0,
    text_labels text DEFAULT '{}'::text,
    merchant_number text DEFAULT ''::text
);


ALTER TABLE public.merchants OWNER TO locker_admin;

--
-- Name: merchants_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.merchants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.merchants_id_seq OWNER TO locker_admin;

--
-- Name: merchants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.merchants_id_seq OWNED BY public.merchants.id;


--
-- Name: offline_retrieve_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.offline_retrieve_records (
    id integer NOT NULL,
    order_no text NOT NULL,
    retrieve_code text,
    cabinet_id integer,
    slot_id integer,
    slot_number text,
    retrieved_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    synced integer DEFAULT 0,
    uploaded integer DEFAULT 0
);


ALTER TABLE public.offline_retrieve_records OWNER TO locker_admin;

--
-- Name: offline_retrieve_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.offline_retrieve_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.offline_retrieve_records_id_seq OWNER TO locker_admin;

--
-- Name: offline_retrieve_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.offline_retrieve_records_id_seq OWNED BY public.offline_retrieve_records.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    order_no text NOT NULL,
    user_phone text NOT NULL,
    slot_id integer,
    cabinet_id integer,
    compartment_number text,
    access_code text,
    deposit_amount double precision DEFAULT 20,
    status integer DEFAULT 1,
    store_time timestamp without time zone,
    retrieve_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    group_id integer,
    cabinet_code text,
    cabinet_name text,
    slot_size text,
    transaction_id text,
    refund_id text,
    pay_time timestamp without time zone,
    refund_time timestamp without time zone,
    payment_channel_id integer,
    refund_mark integer DEFAULT 0,
    refund_status text DEFAULT 'none'::text,
    refund_amount double precision DEFAULT 0,
    logical_mark text DEFAULT 'N'::text,
    logic_mark text,
    logic_hide text,
    note text,
    admin_remark text,
    pickup_time timestamp without time zone,
    updated_at timestamp without time zone,
    openid text,
    unionid character varying(100)
);


ALTER TABLE public.orders OWNER TO locker_admin;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO locker_admin;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: payment_channels; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.payment_channels (
    id integer NOT NULL,
    name text NOT NULL,
    channel_type text DEFAULT 'wechat'::text NOT NULL,
    mch_id text,
    api_key text,
    app_id text,
    app_secret text,
    cert_name text,
    extra_config text,
    is_active integer DEFAULT 1,
    weight integer DEFAULT 1,
    daily_limit double precision DEFAULT 0,
    total_amount double precision DEFAULT 0,
    total_count integer DEFAULT 0,
    last_used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    rotation_index integer DEFAULT 0,
    cert_serial_no text
);


ALTER TABLE public.payment_channels OWNER TO locker_admin;

--
-- Name: payment_channels_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.payment_channels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_channels_id_seq OWNER TO locker_admin;

--
-- Name: payment_channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.payment_channels_id_seq OWNED BY public.payment_channels.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    order_id integer NOT NULL,
    type integer NOT NULL,
    amount double precision NOT NULL,
    transaction_id text,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    refund_transaction_id text
);


ALTER TABLE public.payments OWNER TO locker_admin;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO locker_admin;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: pending_lock_cmds; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.pending_lock_cmds (
    id integer NOT NULL,
    device_id text,
    board_no text DEFAULT 1,
    lock_no text,
    protocol text DEFAULT 'YBM'::text,
    order_id text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    delivered integer DEFAULT 0,
    cabinet_id text,
    slot_id integer,
    command text,
    status text
);


ALTER TABLE public.pending_lock_cmds OWNER TO locker_admin;

--
-- Name: pending_lock_cmds_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.pending_lock_cmds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pending_lock_cmds_id_seq OWNER TO locker_admin;

--
-- Name: pending_lock_cmds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.pending_lock_cmds_id_seq OWNED BY public.pending_lock_cmds.id;


--
-- Name: phone_openids; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.phone_openids (
    id integer NOT NULL,
    phone character varying(20),
    openid character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    wechat_name character varying(100) DEFAULT ''::character varying,
    unionid character varying(100)
);


ALTER TABLE public.phone_openids OWNER TO locker_admin;

--
-- Name: phone_openids_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.phone_openids_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.phone_openids_id_seq OWNER TO locker_admin;

--
-- Name: phone_openids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.phone_openids_id_seq OWNED BY public.phone_openids.id;


--
-- Name: remote_open_logs; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.remote_open_logs (
    id integer NOT NULL,
    merchant_id integer,
    cabinet_id integer,
    device_id text,
    slot_id integer,
    slot_number text,
    action_type text DEFAULT 'emergency_open'::text,
    operator text,
    result text DEFAULT 'success'::text,
    success integer DEFAULT 1,
    ip_address text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.remote_open_logs OWNER TO locker_admin;

--
-- Name: remote_open_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.remote_open_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.remote_open_logs_id_seq OWNER TO locker_admin;

--
-- Name: remote_open_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.remote_open_logs_id_seq OWNED BY public.remote_open_logs.id;


--
-- Name: sms_codes; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.sms_codes (
    id integer NOT NULL,
    phone text NOT NULL,
    code text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sms_codes OWNER TO locker_admin;

--
-- Name: sms_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.sms_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sms_codes_id_seq OWNER TO locker_admin;

--
-- Name: sms_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.sms_codes_id_seq OWNED BY public.sms_codes.id;


--
-- Name: storage_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.storage_records (
    id integer NOT NULL,
    cabinet_id integer NOT NULL,
    compartment_number text NOT NULL,
    user_phone text,
    access_code text,
    status text DEFAULT 1,
    store_time timestamp without time zone,
    retrieve_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.storage_records OWNER TO locker_admin;

--
-- Name: storage_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.storage_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.storage_records_id_seq OWNER TO locker_admin;

--
-- Name: storage_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.storage_records_id_seq OWNED BY public.storage_records.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    setting_key text NOT NULL,
    setting_value text,
    description text
);


ALTER TABLE public.system_settings OWNER TO locker_admin;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_settings_id_seq OWNER TO locker_admin;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: user_balance_details; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.user_balance_details (
    id integer NOT NULL,
    user_phone character varying(20) NOT NULL,
    order_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    source_time timestamp without time zone DEFAULT now(),
    status character varying(20) DEFAULT 'available'::character varying,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_balance_details OWNER TO locker_admin;

--
-- Name: user_balance_details_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.user_balance_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_balance_details_id_seq OWNER TO locker_admin;

--
-- Name: user_balance_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.user_balance_details_id_seq OWNED BY public.user_balance_details.id;


--
-- Name: user_balances; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.user_balances (
    id integer NOT NULL,
    phone text NOT NULL,
    balance double precision DEFAULT 0,
    total_deposited double precision DEFAULT 0,
    total_withdrawn double precision DEFAULT 0,
    first_use_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    wechat_name text DEFAULT ''::text,
    openid text DEFAULT ''::text,
    unionid character varying(100)
);


ALTER TABLE public.user_balances OWNER TO locker_admin;

--
-- Name: user_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.user_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_balances_id_seq OWNER TO locker_admin;

--
-- Name: user_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.user_balances_id_seq OWNED BY public.user_balances.id;


--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.user_profiles (
    openid text NOT NULL,
    wechat_name text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    unionid character varying(100)
);


ALTER TABLE public.user_profiles OWNER TO locker_admin;

--
-- Name: withdrawal_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.withdrawal_records (
    id integer NOT NULL,
    order_id integer,
    user_phone text NOT NULL,
    amount double precision NOT NULL,
    status integer DEFAULT 0,
    apply_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approve_time timestamp without time zone,
    approver text,
    click_count integer DEFAULT 1,
    auto_approve_time text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    openid text,
    error_msg text,
    order_ids text DEFAULT '[]'::text
);


ALTER TABLE public.withdrawal_records OWNER TO locker_admin;

--
-- Name: withdrawal_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.withdrawal_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.withdrawal_records_id_seq OWNER TO locker_admin;

--
-- Name: withdrawal_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.withdrawal_records_id_seq OWNED BY public.withdrawal_records.id;


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: after_sales id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.after_sales ALTER COLUMN id SET DEFAULT nextval('public.after_sales_id_seq'::regclass);


--
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.agents ALTER COLUMN id SET DEFAULT nextval('public.agents_id_seq'::regclass);


--
-- Name: alarms id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.alarms ALTER COLUMN id SET DEFAULT nextval('public.alarms_id_seq'::regclass);


--
-- Name: apk_version id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.apk_version ALTER COLUMN id SET DEFAULT nextval('public.apk_version_id_seq'::regclass);


--
-- Name: blacklist id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.blacklist ALTER COLUMN id SET DEFAULT nextval('public.blacklist_id_seq'::regclass);


--
-- Name: cabinet_groups id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_groups ALTER COLUMN id SET DEFAULT nextval('public.cabinet_groups_id_seq'::regclass);


--
-- Name: cabinet_slots id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_slots ALTER COLUMN id SET DEFAULT nextval('public.cabinet_slots_id_seq'::regclass);


--
-- Name: cabinets id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinets ALTER COLUMN id SET DEFAULT nextval('public.cabinets_id_seq'::regclass);


--
-- Name: cached_orders id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cached_orders ALTER COLUMN id SET DEFAULT nextval('public.cached_orders_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: complaints id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.complaints ALTER COLUMN id SET DEFAULT nextval('public.complaints_id_seq'::regclass);


--
-- Name: device_alerts id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_alerts ALTER COLUMN id SET DEFAULT nextval('public.device_alerts_id_seq'::regclass);


--
-- Name: device_logs id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_logs ALTER COLUMN id SET DEFAULT nextval('public.device_logs_id_seq'::regclass);


--
-- Name: device_update_logs id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_update_logs ALTER COLUMN id SET DEFAULT nextval('public.device_update_logs_id_seq'::regclass);


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: door_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.door_records ALTER COLUMN id SET DEFAULT nextval('public.door_records_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: mainboards id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.mainboards ALTER COLUMN id SET DEFAULT nextval('public.mainboards_id_seq'::regclass);


--
-- Name: merchants id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.merchants ALTER COLUMN id SET DEFAULT nextval('public.merchants_id_seq'::regclass);


--
-- Name: offline_retrieve_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.offline_retrieve_records ALTER COLUMN id SET DEFAULT nextval('public.offline_retrieve_records_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: payment_channels id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payment_channels ALTER COLUMN id SET DEFAULT nextval('public.payment_channels_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: pending_lock_cmds id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.pending_lock_cmds ALTER COLUMN id SET DEFAULT nextval('public.pending_lock_cmds_id_seq'::regclass);


--
-- Name: phone_openids id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.phone_openids ALTER COLUMN id SET DEFAULT nextval('public.phone_openids_id_seq'::regclass);


--
-- Name: remote_open_logs id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.remote_open_logs ALTER COLUMN id SET DEFAULT nextval('public.remote_open_logs_id_seq'::regclass);


--
-- Name: sms_codes id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.sms_codes ALTER COLUMN id SET DEFAULT nextval('public.sms_codes_id_seq'::regclass);


--
-- Name: storage_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.storage_records ALTER COLUMN id SET DEFAULT nextval('public.storage_records_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: user_balance_details id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balance_details ALTER COLUMN id SET DEFAULT nextval('public.user_balance_details_id_seq'::regclass);


--
-- Name: user_balances id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balances ALTER COLUMN id SET DEFAULT nextval('public.user_balances_id_seq'::regclass);


--
-- Name: withdrawal_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.withdrawal_records ALTER COLUMN id SET DEFAULT nextval('public.withdrawal_records_id_seq'::regclass);


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.admin_users (id, username, password_hash, role, created_at, auth_token) FROM stdin;
1	admin	scrypt:32768:8:1$w0GArPx5D5wRGeXw$a11d032f4249144577e2c5a3dd441594dbe591a6621c85cd088c46d49bb7da1db239aed3939a1ab291ac07a25401817854a6dfe51ea758f1bde82b9243c10bbe	super_admin	2026-06-11 05:52:50	52c78ff074d80d14767211b3e3b87b40
\.


--
-- Data for Name: after_sales; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.after_sales (id, ticket_no, cabinet_id, location_id, device_id, fault_type, description, status, handler, handler_note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.agents (id, name, contact_name, contact_phone, password_hash, status, created_at, commission_rate, auth_token, login_attempts, is_locked, plain_password) FROM stdin;
3	自动密码测试	自动密码测试	13900005555	scrypt:32768:8:1$Hm09rGIVdhjXIqk0$f0240605e8fb16383b2d77090bcf8fe20dda54705cb3ec1942803aacddf07937bf1974f96919ebaf19bf84b9215fdca3b844a72a2716c6a8957a7b464bd501f5	1	2026-06-23 08:51:36	0	\N	0	0	
1	王昊	王昊	18996093393	scrypt:32768:8:1$cHcVnE06qBQJ4WJk$06fbf3f8c3193874014777361a2bc3e984c679f88c95bb857d53fdabec3b1fd44eb2ad90a67256aad98ff2dce3a0fa63d930373b39956bb8ec4823a450e4f481	1	2026-06-12 05:09:53	0	4283855cba08f99570e58002da897e74	0	0	123456
\.


--
-- Data for Name: alarms; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.alarms (id, type, cabinet_id, device_id, content, level, status, created_at, resolved_at, resolver) FROM stdin;
\.


--
-- Data for Name: apk_version; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.apk_version (id, version_name, version_code, download_url, update_desc, create_time, file_md5) FROM stdin;
1	1.1.2	112	https://cqdyxl.com/static/smart-locker.apk	1. 新增远程升级功能\\n2. 新增版本更新弹窗\\n3. 新增下载进度显示\\n4. 支持WebSocket推送升级通知	2026-06-17 11:06:15	
3	1.2.0	120	https://cqdyxl.com/static/smart-locker.apk	1. 原生WebSocket连接\\n2. 修复socket.io兼容性问题\\n3. 补全Activity注册\\n4. 版本号统一	2026-06-18 07:47:11	
4	1.2.1	121	https://cqdyxl.com/static/smart-locker.apk	修复SSL证书信任问题	2026-06-18 09:26:10	
5	1.2.3	123	https://kelaiwei.top/static/smart-locker.apk	1. 恢复备案域名子域名locker.cqdyxl.com\\n2. 修复YBM拨码板号偏移\\n3. 修复YBM协议对齐竞品\\n4. 修复WebSocket连接\\n5. 新增YBM 0x9B设置指令	2026-06-19 05:56:49	
6	v1.2.8	128	http://locker.cqdyxl.com/static/smart-locker-v1.2.8.apk	1. SSL证书信任修复\\n2. wss://安全连接\\n3. 修复串口通信\\n4. 修复0x8A开锁协议	2026-06-20 11:56:32	
7	v1.2.9	129	http://locker.cqdyxl.com/static/smart-locker-v1.2.9.apk	1. 开机自启动\\n2. 修复二维码功能\\n3. UI优化	2026-06-20 12:28:46	
8	v1.2.10	130	http://locker.cqdyxl.com/static/smart-locker-v1.2.10.apk	修复更新安装卡住问题	2026-06-20 13:38:20	
9	v1.2.11	131	http://locker.cqdyxl.com/static/smart-locker-v1.2.11.apk	修复安装卡住+版本号上报	2026-06-20 14:08:42	
10	v1.2.12	132	http://locker.cqdyxl.com/static/smart-locker-v1.2.12.apk	修复APK解析错误	2026-06-20 14:39:58	
11	v1.2.13	133	http://locker.cqdyxl.com/static/smart-locker-v1.2.13.apk	版本号动态读取，修复更新循环	2026-06-20 14:50:48	
12	v1.2.14	134	https://locker.cqdyxl.com/static/smart-locker-v1.2.14.apk	修复WebSocket连接：强制wss://避免明文ws与SSL配置冲突	2026-06-20 15:51:29	
14	1.2.16	136	https://locker.cqdyxl.com/static/smart-locker.apk	修复YBM开锁协议+远程更新三级安装策略+UI复刻	2026-06-21 02:37:30	
15	1.2.17	137	https://locker.cqdyxl.com/static/smart-locker.apk	H5取包+二维码+缓存	2026-06-21 06:44:24	
16	1.2.18	138	https://locker.cqdyxl.com/static/smart-locker.apk	修复: 版本号+开机自启+退桌面重启+安装后自动重启	2026-06-21 07:15:26	
17	1.2.18	138	https://locker.cqdyxl.com/static/smart-locker.apk	fix: version+autostart	2026-06-21 07:16:45	
18	1.2.22	142	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.22 稳定版	2026-06-22 15:22:55	
19	1.2.24	144	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.24 工业屏规则分行+H5取包流程改造+二维码修复+跳转小程序+缓存修复	2026-06-23 07:25:53	
20	1.2.25	145	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.25 版本号升级	2026-06-24 01:27:22	
21	1.2.25	145	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.25	2026-06-24 01:27:31	
22	1.2.26	146	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.26 改为系统安装界面	2026-06-24 01:31:32	
23	1.2.27	147	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.27 返回按钮+取包成功页面+倒计时	2026-06-24 02:59:01	
24	1.2.28	148	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.28 取包界面优化+远程更新功能	2026-06-24 07:17:28	
25	1.2.29	149	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.29 修复开门成功弹窗不显示的问题	2026-06-24 09:34:37	
26	1.2.30	150	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.30 新增解绑功能，可远程解绑设备并重新绑定网点	2026-06-26 02:41:16	
27	1.2.31	151	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.31 修复远程自动更新	2026-06-26 21:21:41.407472	
28	1.2.32	152	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.32 修复安装后不返回软件的问题	2026-06-27 06:46:00.761888	
39	1.2.42	162	https://locker.cqdyxl.com/static/locker.apk	\N	2026-06-28 10:24:07.832223	66749536a08ab3ff24f98d235e73fe6a
30	1.2.33	153	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782517746	v1.2.33 新增前台保活+修复自动重启	2026-06-27 07:32:54.044919	
31	1.2.34	154	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782518827	修复安装后自动重启bug	2026-06-27 08:07:07.747029	
32	1.2.35	155	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782520891	修复重复FileProvider导致安装失败问题；优化安装流程	2026-06-27 08:41:32.108365	
33	1.2.36	156	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782521688	修复重复调度导致频繁轮询的问题	2026-06-27 08:54:49.012667	
34	1.2.37	157	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782522225	修复前台保活机制导致界面反复重启的问题	2026-06-27 09:03:45.449798	
45	1.2.49	169	https://locker.cqdyxl.com/static/locker.apk	v1.2.49 混淆+取包显示修复	2026-06-30 07:40:37.308934	996dc013243b5066d87ee61508639839
36	1.2.39	159	https://locker.cqdyxl.com/static/locker.apk	修复onPause导致MainActivity无限重启循环	2026-06-27 09:55:31.928991	
46	1.2.50	170	https://locker.cqdyxl.com/static/locker.apk	???????????	2026-06-30 09:27:15.440268	
40	1.2.43	163	https://locker.cqdyxl.com/static/locker.apk	\N	2026-06-29 09:41:13.415587	ae15b3afeae83d00eadbda85d0311a24
35	1.2.39	159	https://locker.cqdyxl.com/static/locker.apk	修复keepAlive每15秒startActivity导致断网后界面反复重启	2026-06-27 09:11:34.022058	
37	1.2.40	160	https://locker.cqdyxl.com/static/locker.apk	修复WT协议VioSerial未配置波特率导致开锁失败	2026-06-27 14:50:40.644657	
38	1.2.41	161	https://locker.cqdyxl.com/static/locker.apk	修复update_config支持serial_type/protocol_type切换，新增reinitSerialAndProtocol彻底重初始化串口和协议；新增断网看门狗；修复pending命令默认board_no/lock_no导致误开门	2026-06-28 09:59:05.189506	
41	1.2.46	166	https://locker.cqdyxl.com/static/locker.apk	v1.2.46 修复YBM协议板号减1导致开门失败问题	2026-06-29 20:56:59.051845	fd7644f71b186d916a7306caf69c6599
43	1.2.47	167	https://locker.cqdyxl.com/static/locker.apk	v1.2.47 WS超时修复+轮询间隔3s+匹配管道轮转	2026-06-30 07:04:07.686534	a2b5fa08c0138bcca27dfe53680a3a18
44	1.2.48	168	https://locker.cqdyxl.com/static/locker.apk	v1.2.48 取包显示修复+公司号显示修复	2026-06-30 07:23:45.919957	ac800bb5a494189aa0bcada9b9380b03
\.


--
-- Data for Name: blacklist; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.blacklist (id, phone, reason, cabinet_id, operator, status, created_at) FROM stdin;
\.


--
-- Data for Name: cabinet_groups; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cabinet_groups (id, location_id, group_code, name, screen_url, status, created_at) FROM stdin;
1	4	a123	A	\N	1	2026-06-12 05:28:16
\.


--
-- Data for Name: cabinet_slots; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cabinet_slots (id, cabinet_id, slot_number, slot_size, status, cabinet_code, mainboard_id, display_number, board_no, lock_no, slot_label, updated_at) FROM stdin;
13	2	1	S	1	1	1	\N	1	1	\N	2026-06-26 05:33:44
14	2	2	S	1	1	1	\N	1	2	\N	2026-06-26 05:33:44
15	2	3	S	1	1	1	\N	1	3	\N	2026-06-26 05:33:44
16	2	4	S	1	1	1	\N	1	4	\N	2026-06-26 05:33:44
17	2	5	M	1	1	1	\N	1	5	\N	2026-06-26 05:33:44
18	2	6	M	1	1	1	\N	1	6	\N	2026-06-26 05:33:44
19	2	7	M	1	1	1	\N	1	7	\N	2026-06-26 05:33:44
20	2	8	M	1	1	1	\N	1	8	\N	2026-06-26 05:33:44
21	2	9	L	1	1	1	\N	1	9	\N	2026-06-26 05:33:44
22	2	10	L	1	1	1	\N	1	10	\N	2026-06-26 05:33:44
23	2	11	L	1	1	1	\N	1	11	\N	2026-06-26 05:33:44
24	2	12	L	1	1	1	\N	1	12	\N	2026-06-26 05:33:44
25	2	13	M	1	1	1	1	1	13	\N	2026-06-26 05:33:44
26	2	14	M	1	1	1	2	1	14	\N	2026-06-26 05:33:44
27	2	15	M	1	1	1	3	1	15	\N	2026-06-26 05:33:44
28	2	16	M	1	1	1	4	1	16	\N	2026-06-26 05:33:44
29	2	17	M	1	1	1	5	1	17	\N	2026-06-26 05:33:44
30	2	18	M	1	1	1	6	1	18	\N	2026-06-26 05:33:44
31	2	19	M	1	1	1	7	1	19	\N	2026-06-26 05:33:44
32	2	20	M	1	1	1	8	1	20	\N	2026-06-26 05:33:44
33	2	21	M	1	1	1	9	1	21	\N	2026-06-26 05:33:44
34	2	22	M	1	1	1	10	1	22	\N	2026-06-26 05:33:44
35	2	23	M	1	1	1	11	1	23	\N	2026-06-26 05:33:44
36	2	24	M	1	1	1	12	1	24	\N	2026-06-26 05:33:44
37	2	25	M	1	1	2	13	2	1	\N	2026-06-26 05:33:44
38	2	26	M	1	1	2	14	2	2	\N	2026-06-26 05:33:44
39	2	27	M	1	1	2	15	2	3	\N	2026-06-26 05:33:44
40	2	28	M	1	1	2	16	2	4	\N	2026-06-26 05:33:44
41	2	29	M	1	1	2	17	2	5	\N	2026-06-26 05:33:44
42	2	30	M	1	1	2	18	2	6	\N	2026-06-26 05:33:44
43	2	31	M	1	1	2	19	2	7	\N	2026-06-26 05:33:44
44	2	32	M	1	1	2	20	2	8	\N	2026-06-26 05:33:44
45	2	33	M	1	1	2	21	2	9	\N	2026-06-26 05:33:44
46	2	34	M	1	1	2	22	2	10	\N	2026-06-26 05:33:44
47	2	35	M	1	1	2	23	2	11	\N	2026-06-26 05:33:44
48	2	36	M	1	1	2	24	2	12	\N	2026-06-26 05:33:44
49	2	37	M	1	1	2	25	2	13	\N	2026-06-26 05:33:44
50	2	38	M	1	1	2	26	2	14	\N	2026-06-26 05:33:44
51	2	39	M	1	1	2	27	2	15	\N	2026-06-26 05:33:44
52	2	40	M	1	1	2	28	2	16	\N	2026-06-26 05:33:44
53	2	41	M	1	1	2	29	2	17	\N	2026-06-26 05:33:44
54	2	42	M	1	1	2	30	2	18	\N	2026-06-26 05:33:44
55	2	43	M	1	1	2	31	2	19	\N	2026-06-26 05:33:44
56	2	44	M	1	1	2	32	2	20	\N	2026-06-26 05:33:44
57	3	1	M	1	c001	3	1	1	1	\N	2026-06-26 05:33:44
58	3	2	M	1	c001	3	2	1	2	\N	2026-06-26 05:33:44
59	3	3	M	1	c001	3	3	1	3	\N	2026-06-26 05:33:44
60	3	4	M	1	c001	3	4	1	4	\N	2026-06-26 05:33:44
61	3	5	M	1	c001	3	5	1	5	\N	2026-06-26 05:33:44
62	3	6	M	1	c001	3	6	1	6	\N	2026-06-26 05:33:44
63	3	7	M	1	c001	3	7	1	7	\N	2026-06-26 05:33:44
64	3	8	M	1	c001	3	8	1	8	\N	2026-06-26 05:33:44
65	3	9	M	1	c001	3	9	1	9	\N	2026-06-26 05:33:44
66	3	10	M	1	c001	3	10	1	10	\N	2026-06-26 05:33:44
67	3	11	M	1	c001	3	11	1	11	\N	2026-06-26 05:33:44
68	3	12	M	1	c001	3	12	1	12	\N	2026-06-26 05:33:44
69	5	1	M	1	CAB002	4	1	1	1	\N	2026-06-26 05:33:44
70	5	2	M	1	CAB002	4	2	1	2	\N	2026-06-26 05:33:44
71	5	3	M	1	CAB002	4	3	1	3	\N	2026-06-26 05:33:44
72	5	4	M	1	CAB002	4	4	1	4	\N	2026-06-26 05:33:44
73	5	5	M	1	CAB002	4	5	1	5	\N	2026-06-26 05:33:44
74	5	6	M	1	CAB002	4	6	1	6	\N	2026-06-26 05:33:44
75	5	7	M	1	CAB002	4	7	1	7	\N	2026-06-26 05:33:44
76	5	8	M	1	CAB002	4	8	1	8	\N	2026-06-26 05:33:44
77	5	9	M	1	CAB002	4	9	1	9	\N	2026-06-26 05:33:44
78	5	10	M	1	CAB002	4	10	1	10	\N	2026-06-26 05:33:44
79	5	11	M	1	CAB002	4	11	1	11	\N	2026-06-26 05:33:44
80	5	12	M	1	CAB002	4	12	1	12	\N	2026-06-26 05:33:44
81	5	13	M	1	CAB002	4	13	1	13	\N	2026-06-26 05:33:44
82	5	14	M	1	CAB002	4	14	1	14	\N	2026-06-26 05:33:44
83	5	15	M	1	CAB002	4	15	1	15	\N	2026-06-26 05:33:44
84	5	16	M	1	CAB002	4	16	1	16	\N	2026-06-26 05:33:44
85	5	17	M	1	CAB002	4	17	1	17	\N	2026-06-26 05:33:44
86	5	18	M	1	CAB002	4	18	1	18	\N	2026-06-26 05:33:44
87	5	19	M	1	CAB002	4	19	1	19	\N	2026-06-26 05:33:44
88	5	20	M	1	CAB002	4	20	1	20	\N	2026-06-26 05:33:44
89	5	21	M	1	CAB002	4	21	1	21	\N	2026-06-26 05:33:44
90	5	22	M	1	CAB002	4	22	1	22	\N	2026-06-26 05:33:44
91	5	23	M	1	CAB002	4	23	1	23	\N	2026-06-26 05:33:44
92	5	24	M	1	CAB002	4	24	1	24	\N	2026-06-26 05:33:44
181	9	1	M	1	\N	13	\N	1	1	\N	2026-06-26 05:33:44
182	9	2	M	1	\N	13	\N	1	2	\N	2026-06-26 05:33:44
183	9	3	M	1	\N	13	\N	1	3	\N	2026-06-26 05:33:44
184	9	4	M	1	\N	13	\N	1	4	\N	2026-06-26 05:33:44
185	9	5	M	1	\N	13	\N	1	5	\N	2026-06-26 05:33:44
186	9	6	M	1	\N	13	\N	1	6	\N	2026-06-26 05:33:44
187	9	7	M	1	\N	13	\N	1	7	\N	2026-06-26 05:33:44
188	9	8	M	1	\N	13	\N	1	8	\N	2026-06-26 05:33:44
189	9	9	M	1	\N	13	\N	1	9	\N	2026-06-26 05:33:44
190	9	10	M	1	\N	13	\N	1	10	\N	2026-06-26 05:33:44
191	9	11	M	1	\N	13	\N	1	11	\N	2026-06-26 05:33:44
192	9	12	M	1	\N	13	\N	1	12	\N	2026-06-26 05:33:44
193	10	1	M	1	\N	14	\N	1	1	\N	2026-06-26 05:33:44
194	10	2	M	1	\N	14	\N	1	2	\N	2026-06-26 05:33:44
195	10	3	M	1	\N	14	\N	1	3	\N	2026-06-26 05:33:44
196	10	4	M	1	\N	14	\N	1	4	\N	2026-06-26 05:33:44
197	10	5	M	1	\N	14	\N	1	5	\N	2026-06-26 05:33:44
198	10	6	M	1	\N	14	\N	1	6	\N	2026-06-26 05:33:44
199	10	7	M	1	\N	14	\N	1	7	\N	2026-06-26 05:33:44
200	10	8	M	1	\N	14	\N	1	8	\N	2026-06-26 05:33:44
201	10	9	M	1	\N	14	\N	1	9	\N	2026-06-26 05:33:44
202	10	10	M	1	\N	14	\N	1	10	\N	2026-06-26 05:33:44
203	10	11	M	1	\N	14	\N	1	11	\N	2026-06-26 05:33:44
204	10	12	M	1	\N	14	\N	1	12	\N	2026-06-26 05:33:44
205	11	1	M	1	\N	15	\N	1	1	\N	2026-06-26 05:33:44
206	11	2	M	1	\N	15	\N	1	2	\N	2026-06-26 05:33:44
207	11	3	M	1	\N	15	\N	1	3	\N	2026-06-26 05:33:44
208	11	4	M	1	\N	15	\N	1	4	\N	2026-06-26 05:33:44
209	11	5	M	1	\N	15	\N	1	5	\N	2026-06-26 05:33:44
210	11	6	M	1	\N	15	\N	1	6	\N	2026-06-26 05:33:44
211	11	7	M	1	\N	15	\N	1	7	\N	2026-06-26 05:33:44
212	11	8	M	1	\N	15	\N	1	8	\N	2026-06-26 05:33:44
213	11	9	M	1	\N	15	\N	1	9	\N	2026-06-26 05:33:44
214	11	10	M	1	\N	15	\N	1	10	\N	2026-06-26 05:33:44
215	11	11	M	1	\N	15	\N	1	11	\N	2026-06-26 05:33:44
216	11	12	M	1	\N	15	\N	1	12	\N	2026-06-26 05:33:44
229	13	1	M	1	\N	17	\N	1	1	\N	2026-06-26 05:33:44
230	13	2	M	1	\N	17	\N	1	2	\N	2026-06-26 05:33:44
231	13	3	M	1	\N	17	\N	1	3	\N	2026-06-26 05:33:44
232	13	4	M	1	\N	17	\N	1	4	\N	2026-06-26 05:33:44
233	13	5	M	1	\N	17	\N	1	5	\N	2026-06-26 05:33:44
234	13	6	M	1	\N	17	\N	1	6	\N	2026-06-26 05:33:44
235	13	7	M	1	\N	17	\N	1	7	\N	2026-06-26 05:33:44
236	13	8	M	1	\N	17	\N	1	8	\N	2026-06-26 05:33:44
237	13	9	M	1	\N	17	\N	1	9	\N	2026-06-26 05:33:44
238	13	10	M	1	\N	17	\N	1	10	\N	2026-06-26 05:33:44
239	13	11	M	1	\N	17	\N	1	11	\N	2026-06-26 05:33:44
240	13	12	M	1	\N	17	\N	1	12	\N	2026-06-26 05:33:44
241	14	1	M	1	\N	18	\N	1	1	\N	2026-06-26 05:33:44
242	14	2	M	1	\N	18	\N	1	2	\N	2026-06-26 05:33:44
243	14	3	M	1	\N	18	\N	1	3	\N	2026-06-26 05:33:44
244	14	4	M	1	\N	18	\N	1	4	\N	2026-06-26 05:33:44
245	14	5	M	1	\N	18	\N	1	5	\N	2026-06-26 05:33:44
246	14	6	M	1	\N	18	\N	1	6	\N	2026-06-26 05:33:44
247	14	7	M	1	\N	18	\N	1	7	\N	2026-06-26 05:33:44
248	14	8	M	1	\N	18	\N	1	8	\N	2026-06-26 05:33:44
249	14	9	M	1	\N	18	\N	1	9	\N	2026-06-26 05:33:44
250	14	10	M	1	\N	18	\N	1	10	\N	2026-06-26 05:33:44
251	14	11	M	1	\N	18	\N	1	11	\N	2026-06-26 05:33:44
252	14	12	M	1	\N	18	\N	1	12	\N	2026-06-26 05:33:44
448	8	2	medium	1	\N	\N	\N	1	2	2	2026-06-26 05:33:44
449	8	3	medium	1	\N	\N	\N	1	3	3	2026-06-26 05:33:44
450	8	4	medium	1	\N	\N	\N	1	4	4	2026-06-26 05:33:44
451	8	5	medium	1	\N	\N	\N	1	5	5	2026-06-26 05:33:44
452	8	6	medium	1	\N	\N	\N	1	6	6	2026-06-26 05:33:44
453	8	7	medium	1	\N	\N	\N	1	7	7	2026-06-26 05:33:44
454	8	8	medium	2	\N	\N	\N	1	8	8	2026-06-26 05:33:44
455	8	9	medium	1	\N	\N	\N	1	9	9	2026-06-26 05:33:44
456	8	10	medium	1	\N	\N	\N	1	10	10	2026-06-26 05:33:44
457	8	11	medium	1	\N	\N	\N	1	11	11	2026-06-26 05:33:44
458	8	12	medium	1	\N	\N	\N	1	12	12	2026-06-26 05:33:44
459	8	13	medium	1	\N	\N	\N	1	13	13	2026-06-26 05:33:44
460	8	14	medium	1	\N	\N	\N	1	14	14	2026-06-26 05:33:44
461	8	15	medium	1	\N	\N	\N	1	15	15	2026-06-26 05:33:44
462	8	16	medium	1	\N	\N	\N	1	16	16	2026-06-26 05:33:44
463	15	1	medium	1	\N	\N	\N	1	1	1	\N
655	26	1	medium	1	\N	\N	\N	1	1	1	\N
656	26	2	medium	1	\N	\N	\N	1	2	2	\N
657	26	3	medium	1	\N	\N	\N	1	3	3	\N
468	15	6	medium	1	\N	\N	\N	1	6	6	\N
469	15	7	medium	1	\N	\N	\N	1	7	7	\N
470	15	8	medium	1	\N	\N	\N	1	8	8	\N
471	15	9	medium	1	\N	\N	\N	1	9	9	\N
474	15	12	medium	1	\N	\N	\N	1	12	12	\N
475	15	13	medium	1	\N	\N	\N	1	13	13	\N
476	15	14	medium	1	\N	\N	\N	1	14	14	\N
477	15	15	medium	1	\N	\N	\N	1	15	15	\N
478	15	16	medium	1	\N	\N	\N	1	16	16	\N
479	15	17	medium	1	\N	\N	\N	2	1	17	\N
480	15	18	medium	1	\N	\N	\N	2	2	18	\N
481	15	19	medium	1	\N	\N	\N	2	3	19	\N
482	15	20	medium	1	\N	\N	\N	2	4	20	\N
483	15	21	medium	1	\N	\N	\N	2	5	21	\N
484	15	22	medium	1	\N	\N	\N	2	6	22	\N
485	15	23	medium	1	\N	\N	\N	2	7	23	\N
486	15	24	medium	1	\N	\N	\N	2	8	24	\N
487	15	25	medium	1	\N	\N	\N	2	9	25	\N
488	15	26	medium	1	\N	\N	\N	2	10	26	\N
489	15	27	medium	1	\N	\N	\N	2	11	27	\N
490	15	28	medium	1	\N	\N	\N	2	12	28	\N
491	15	29	medium	1	\N	\N	\N	2	13	29	\N
492	15	30	medium	1	\N	\N	\N	2	14	30	\N
493	15	31	medium	1	\N	\N	\N	2	15	31	\N
494	15	32	medium	1	\N	\N	\N	2	16	32	\N
472	15	10	medium	1	\N	\N	\N	1	10	10	\N
495	16	1	medium	1	\N	\N	\N	1	1	B1	\N
473	15	11	medium	1	\N	\N	\N	1	11	11	\N
447	8	1	medium	1	\N	\N	\N	1	1	1	2026-06-26 05:33:44
465	15	3	medium	1	\N	\N	\N	1	3	3	\N
464	15	2	medium	1	\N	\N	\N	1	2	2	\N
466	15	4	medium	1	\N	\N	\N	1	4	4	\N
496	16	2	medium	1	\N	\N	\N	1	2	B2	\N
498	16	4	medium	1	\N	\N	\N	1	4	B4	\N
502	16	8	medium	1	\N	\N	\N	1	8	B8	\N
504	16	10	medium	1	\N	\N	\N	1	10	B10	\N
505	16	11	medium	1	\N	\N	\N	1	11	B11	\N
506	16	12	medium	0	\N	\N	\N	1	12	B12	2026-06-30 15:37:21.900677
507	16	13	medium	1	\N	\N	\N	1	13	B13	\N
508	16	14	medium	1	\N	\N	\N	1	14	B14	\N
509	16	15	medium	1	\N	\N	\N	1	15	B15	\N
595	24	5	medium	1	\N	\N	\N	1	5	E5	\N
644	24	54	medium	1	\N	\N	\N	4	6	E54	\N
602	24	12	medium	1	\N	\N	\N	1	12	E12	\N
599	24	9	medium	1	\N	\N	\N	1	9	E9	\N
601	24	11	medium	1	\N	\N	\N	1	11	E11	\N
643	24	53	medium	1	\N	\N	\N	4	5	E53	\N
641	24	51	medium	1	\N	\N	\N	4	3	E51	\N
598	24	8	medium	1	\N	\N	\N	1	8	E8	\N
467	15	5	medium	1	\N	\N	\N	1	5	5	\N
600	24	10	medium	4	\N	\N	\N	1	10	E10	\N
606	24	16	medium	3	\N	\N	\N	1	16	E16	\N
658	26	4	medium	1	\N	\N	\N	1	4	4	\N
659	26	5	medium	1	\N	\N	\N	1	5	5	\N
660	26	6	medium	1	\N	\N	\N	1	6	6	\N
661	26	7	medium	1	\N	\N	\N	1	7	7	\N
662	26	8	medium	1	\N	\N	\N	1	8	8	\N
663	26	9	medium	1	\N	\N	\N	1	9	9	\N
664	26	10	medium	1	\N	\N	\N	1	10	10	\N
665	26	11	medium	1	\N	\N	\N	1	11	11	\N
666	26	12	medium	1	\N	\N	\N	1	12	12	\N
667	26	13	medium	1	\N	\N	\N	1	13	13	\N
668	26	14	medium	1	\N	\N	\N	1	14	14	\N
669	26	15	medium	1	\N	\N	\N	1	15	15	\N
670	26	16	medium	1	\N	\N	\N	1	16	16	\N
687	26	33	medium	1	\N	\N	\N	3	1	33	\N
688	26	34	medium	1	\N	\N	\N	3	2	34	\N
689	26	35	medium	1	\N	\N	\N	3	3	35	\N
690	26	36	medium	1	\N	\N	\N	3	4	36	\N
691	26	37	medium	1	\N	\N	\N	3	5	37	\N
692	26	38	medium	1	\N	\N	\N	3	6	38	\N
693	26	39	medium	1	\N	\N	\N	3	7	39	\N
694	26	40	medium	1	\N	\N	\N	3	8	40	\N
695	26	41	medium	1	\N	\N	\N	3	9	41	\N
696	26	42	medium	1	\N	\N	\N	3	10	42	\N
697	26	43	medium	1	\N	\N	\N	3	11	43	\N
698	26	44	medium	1	\N	\N	\N	3	12	44	\N
699	26	45	medium	1	\N	\N	\N	3	13	45	\N
700	26	46	medium	1	\N	\N	\N	3	14	46	\N
701	26	47	medium	1	\N	\N	\N	3	15	47	\N
702	26	48	medium	1	\N	\N	\N	3	16	48	\N
626	24	36	medium	1	\N	\N	\N	3	4	E36	\N
501	16	7	medium	1	\N	\N	\N	1	7	B7	\N
503	16	9	medium	1	\N	\N	\N	1	9	B9	\N
605	24	15	medium	1	\N	\N	\N	1	15	E15	\N
597	24	7	medium	1	\N	\N	\N	1	7	E7	\N
500	16	6	medium	1	\N	\N	\N	1	6	B6	\N
594	24	4	medium	1	\N	\N	\N	1	4	E4	\N
497	16	3	medium	1	\N	\N	\N	1	3	B3	\N
596	24	6	medium	1	\N	\N	\N	1	6	E6	\N
603	24	13	medium	1	\N	\N	\N	1	13	E13	\N
604	24	14	medium	1	\N	\N	\N	1	14	E14	\N
624	24	34	medium	1	\N	\N	\N	3	2	E34	\N
628	24	38	medium	1	\N	\N	\N	3	6	E38	\N
630	24	40	medium	1	\N	\N	\N	3	8	E40	\N
633	24	43	medium	1	\N	\N	\N	3	11	E43	\N
635	24	45	medium	1	\N	\N	\N	3	13	E45	\N
637	24	47	medium	1	\N	\N	\N	3	15	E47	\N
638	24	48	medium	1	\N	\N	\N	3	16	E48	\N
640	24	50	medium	1	\N	\N	\N	4	2	E50	\N
623	24	33	medium	1	\N	\N	\N	3	1	E33	\N
642	24	52	medium	1	\N	\N	\N	4	4	E52	\N
625	24	35	medium	2	\N	\N	\N	3	3	E35	\N
627	24	37	medium	2	\N	\N	\N	3	5	E37	\N
631	24	41	medium	2	\N	\N	\N	3	9	E41	\N
629	24	39	medium	1	\N	\N	\N	3	7	E39	\N
632	24	42	medium	1	\N	\N	\N	3	10	E42	\N
636	24	46	medium	1	\N	\N	\N	3	14	E46	\N
634	24	44	medium	1	\N	\N	\N	3	12	E44	\N
639	24	49	medium	1	\N	\N	\N	4	1	E49	\N
621	24	31	medium	3	\N	\N	\N	2	15	E31	\N
671	26	17	medium	1	\N	\N	\N	2	1	17	\N
672	26	18	medium	1	\N	\N	\N	2	2	18	\N
673	26	19	medium	1	\N	\N	\N	2	3	19	\N
674	26	20	medium	1	\N	\N	\N	2	4	20	\N
675	26	21	medium	1	\N	\N	\N	2	5	21	\N
676	26	22	medium	1	\N	\N	\N	2	6	22	\N
677	26	23	medium	1	\N	\N	\N	2	7	23	\N
678	26	24	medium	1	\N	\N	\N	2	8	24	\N
679	26	25	medium	1	\N	\N	\N	2	9	25	\N
680	26	26	medium	1	\N	\N	\N	2	10	26	\N
681	26	27	medium	1	\N	\N	\N	2	11	27	\N
682	26	28	medium	1	\N	\N	\N	2	12	28	\N
683	26	29	medium	1	\N	\N	\N	2	13	29	\N
684	26	30	medium	1	\N	\N	\N	2	14	30	\N
685	26	31	medium	1	\N	\N	\N	2	15	31	\N
686	26	32	medium	1	\N	\N	\N	2	16	32	\N
499	16	5	medium	0	\N	\N	\N	1	5	B5	2026-06-30 15:36:26.717548
510	16	16	medium	1	\N	\N	\N	1	16	B16	\N
511	16	17	medium	1	\N	\N	\N	2	1	B17	\N
613	24	23	medium	1	\N	\N	\N	2	7	E23	\N
512	16	18	medium	0	\N	\N	\N	2	2	B18	2026-06-30 15:36:26.717548
513	16	19	medium	1	\N	\N	\N	2	3	B19	\N
614	24	24	medium	1	\N	\N	\N	2	8	E24	\N
514	16	20	medium	1	\N	\N	\N	2	4	B20	\N
616	24	26	medium	1	\N	\N	\N	2	10	E26	\N
515	16	21	medium	1	\N	\N	\N	2	5	B21	\N
617	24	27	medium	1	\N	\N	\N	2	11	E27	\N
516	16	22	medium	0	\N	\N	\N	2	6	B22	2026-06-30 15:36:26.717548
619	24	29	medium	1	\N	\N	\N	2	13	E29	\N
517	16	23	medium	0	\N	\N	\N	2	7	B23	2026-06-30 15:36:26.717548
518	16	24	medium	1	\N	\N	\N	2	8	B24	\N
519	16	25	medium	1	\N	\N	\N	2	9	B25	\N
651	24	61	medium	2	\N	\N	\N	4	13	E61	\N
520	16	26	medium	1	\N	\N	\N	2	10	B26	\N
521	16	27	medium	0	\N	\N	\N	2	11	B27	2026-06-30 15:36:26.717548
522	16	28	medium	0	\N	\N	\N	2	12	B28	2026-06-30 15:36:26.717548
620	24	30	medium	1	\N	\N	\N	2	14	E30	\N
650	24	60	medium	1	\N	\N	\N	4	12	E60	\N
648	24	58	medium	1	\N	\N	\N	4	10	E58	\N
523	16	29	medium	0	\N	\N	\N	2	13	B29	2026-06-30 15:36:26.717548
524	16	30	medium	1	\N	\N	\N	2	14	B30	\N
525	16	31	medium	0	\N	\N	\N	2	15	B31	2026-06-30 15:36:26.717548
646	24	56	medium	1	\N	\N	\N	4	8	E56	\N
593	24	3	medium	1	\N	\N	\N	1	3	E3	\N
592	24	2	medium	1	\N	\N	\N	1	2	E2	\N
653	24	63	medium	1	\N	\N	\N	4	15	E63	\N
607	24	17	medium	1	\N	\N	\N	2	1	E17	\N
608	24	18	medium	1	\N	\N	\N	2	2	E18	\N
609	24	19	medium	1	\N	\N	\N	2	3	E19	\N
610	24	20	medium	1	\N	\N	\N	2	4	E20	\N
611	24	21	medium	1	\N	\N	\N	2	5	E21	\N
612	24	22	medium	1	\N	\N	\N	2	6	E22	\N
615	24	25	medium	1	\N	\N	\N	2	9	E25	\N
591	24	1	medium	1	\N	\N	\N	1	1	E1	\N
618	24	28	medium	1	\N	\N	\N	2	12	E28	\N
526	16	32	medium	1	\N	\N	\N	2	16	B32	\N
622	24	32	medium	1	\N	\N	\N	2	16	E32	\N
645	24	55	medium	1	\N	\N	\N	4	7	E55	\N
647	24	57	medium	1	\N	\N	\N	4	9	E57	\N
649	24	59	medium	1	\N	\N	\N	4	11	E59	\N
652	24	62	medium	1	\N	\N	\N	4	14	E62	\N
654	24	64	medium	1	\N	\N	\N	4	16	E64	\N
\.


--
-- Data for Name: cabinets; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cabinets (id, location_id, cabinet_code, name, total_slots, status, last_heartbeat, created_at, group_id, deposit_amount, mainboard_device_id, mainboard_source, charge_mode, app_version, app_version_code, business_status, business_hours, customer_phone, updated_at, usage_rules, per_use_price) FROM stdin;
8	4	CAB005	智能寄存柜	16	0	2026-06-30 17:09:57.728225	2026-06-14 14:45:50	\N	20	123456	WT	deposit	1.2.30	150	active	8:00~22:00	4006981080	2026-06-27 11:40:45.308331	24小时内取包免费\\n保证金{deposit_amount}元，寄存结束后按规则结算\\n存包后请保管好取件码\\n柜内禁止存放易燃易爆及违禁物品	0
15	6	CAB20260625180817	A柜	32	1	2026-06-29 17:38:22.430074	2026-06-25 10:08:17	\N	1	101001	WT	deposit	1.2.42	162	inactive	\N	0	2026-06-28 07:19:10.849061	24小时内取包免费\\n保证金{deposit_amount}元，寄存结束后按规则结算\\n存包后请保管好取件码\\n柜内禁止存放易燃易爆及违禁物品	4006981080
24	7	CAB20260629175546	E柜	64	1	2026-07-01 02:59:59.823817	2026-06-29 17:55:46.292334	\N	20	100101	YBM	deposit	1.2.50	170	open	\N		2026-06-30 08:21:43.475429	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
26	7	CAB20260630085211	D柜	48	1	\N	2026-06-30 08:52:11.725233	\N	20	100102	YBM	deposit		0	inactive	\N		2026-06-30 16:53:21.649498	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
16	6	CAB20260625181326	B柜	32	1	2026-07-01 02:13:10.740598	2026-06-25 10:13:26	\N	20	100100	YBM	deposit	1.2.50	170	open	\N	0	2026-06-28 07:43:42.926212	24小时内取包免费\\n保证金{deposit_amount}元，寄存结束后按规则结算\\n存包后请保管好取件码\\n柜内禁止存放易燃易爆及违禁物品	4006981080
\.


--
-- Data for Name: cached_orders; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cached_orders (id, order_id, order_no, cabinet_id, slot_id, slot_number, deposit_amount, status, created_at, synced) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.companies (id, name, credit_code, contact_person, contact_phone, address, status, created_at) FROM stdin;
1	重庆科莱维科技有限公司	91500106MACK2R5P8G	李百棚	4006981080	重庆市沙坪坝区覃家岗街道凤鸣山307号附54号26-22	1	2026-06-18 02:28:25
2	测试公司	TEST001	\N	\N	\N	1	2026-06-18 02:54:02
\.


--
-- Data for Name: complaints; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.complaints (id, user_phone, type, content, order_no, status, reply, reply_time, wx_complaint_id, created_at, complaint_type, order_id) FROM stdin;
3	18265820019	wechat	柜子押金为什么迟迟不到帐？	20260630123806951872	1	您好，我们已收到您的反馈，正在尽快为您处理。如有疑问请联系客服，感谢您的理解与支持！	2026-06-30 21:39:40.847453	200000020260630150476195840	2026-06-30 15:26:14.234833	wechat	501
2	18254067609	wechat	我于今日12点半左右存放物品，交取20元押金，但物品取出后押金并未退回	20260630123939351137	2	您好，您的订单已为您办理全额退款，款项将原路返回至您的微信零钱，请注意查收。如有疑问请联系客服，感谢您的理解与支持！	2026-06-30 21:08:18.022789	200000020260630150476190663	2026-06-30 15:00:14.837249	wechat	506
\.


--
-- Data for Name: device_alerts; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.device_alerts (id, device_id, alert_type, detail, created_at) FROM stdin;
3	100100	online	设备WebSocket连接建立	2026-06-27 10:55:56.91984
4	100100	online	设备WebSocket连接建立	2026-06-27 10:55:57.461221
5	100100	online	设备WebSocket连接建立	2026-06-27 10:59:31.857423
6	100100	online	设备WebSocket连接建立	2026-06-27 10:59:31.935454
7	100100	online	设备WebSocket连接建立	2026-06-27 11:00:20.381276
8	100100	online	设备WebSocket连接建立	2026-06-27 11:00:20.45294
9	100100	online	设备WebSocket连接建立	2026-06-27 11:07:40.394132
10	100100	online	设备WebSocket连接建立	2026-06-27 11:07:40.63802
11	100100	online	设备WebSocket连接建立	2026-06-27 11:08:49.266356
12	100100	online	设备WebSocket连接建立	2026-06-27 11:08:49.354396
13	100100	online	设备WebSocket连接建立	2026-06-27 11:10:03.377474
14	100100	online	设备WebSocket连接建立	2026-06-27 11:10:03.451777
15	100100	online	设备WebSocket连接建立	2026-06-27 11:12:19.854435
16	100100	online	设备WebSocket连接建立	2026-06-27 11:12:19.923264
17	100100	online	设备WebSocket连接建立	2026-06-27 11:12:47.261434
18	100100	online	设备WebSocket连接建立	2026-06-27 11:12:47.330682
19	100100	online	设备WebSocket连接建立	2026-06-27 11:12:48.555489
20	100100	online	设备WebSocket连接建立	2026-06-27 11:12:48.627375
21	100100	online	设备WebSocket连接建立	2026-06-27 11:12:49.916003
22	100100	online	设备WebSocket连接建立	2026-06-27 11:12:49.991209
23	100100	online	设备WebSocket连接建立	2026-06-27 11:12:51.225431
24	100100	online	设备WebSocket连接建立	2026-06-27 11:12:51.306914
25	100100	online	设备WebSocket连接建立	2026-06-27 11:12:52.580641
26	100100	online	设备WebSocket连接建立	2026-06-27 11:12:52.649964
27	100100	online	设备WebSocket连接建立	2026-06-27 11:12:54.041139
28	100100	online	设备WebSocket连接建立	2026-06-27 11:12:54.127381
29	100100	online	设备WebSocket连接建立	2026-06-27 11:12:55.4078
30	100100	online	设备WebSocket连接建立	2026-06-27 11:12:55.499532
31	100100	online	设备WebSocket连接建立	2026-06-27 11:12:56.837912
32	100100	online	设备WebSocket连接建立	2026-06-27 11:12:56.913271
33	100100	online	设备WebSocket连接建立	2026-06-27 11:12:58.173546
34	100100	online	设备WebSocket连接建立	2026-06-27 11:12:58.244881
35	100100	online	设备WebSocket连接建立	2026-06-27 11:12:59.539079
36	100100	online	设备WebSocket连接建立	2026-06-27 11:12:59.61114
37	100100	online	设备WebSocket连接建立	2026-06-27 11:13:00.877525
38	100100	online	设备WebSocket连接建立	2026-06-27 11:13:00.950467
39	100100	online	设备WebSocket连接建立	2026-06-27 11:13:02.406601
40	100100	online	设备WebSocket连接建立	2026-06-27 11:13:02.481136
41	100100	online	设备WebSocket连接建立	2026-06-27 11:13:03.73445
42	100100	online	设备WebSocket连接建立	2026-06-27 11:13:03.806018
43	100100	online	设备WebSocket连接建立	2026-06-27 11:13:05.050571
44	100100	online	设备WebSocket连接建立	2026-06-27 11:13:05.122727
45	100100	online	设备WebSocket连接建立	2026-06-27 11:13:06.344516
46	100100	online	设备WebSocket连接建立	2026-06-27 11:13:06.418125
47	100100	online	设备WebSocket连接建立	2026-06-27 11:13:07.648217
48	100100	online	设备WebSocket连接建立	2026-06-27 11:13:07.717789
49	100100	online	设备WebSocket连接建立	2026-06-27 11:13:38.589728
50	100100	online	设备WebSocket连接建立	2026-06-27 11:13:38.660644
51	101001	online	设备WebSocket连接建立	2026-06-27 11:16:43.984789
52	101001	online	设备WebSocket连接建立	2026-06-27 11:16:44.057094
53	101001	offline	设备WebSocket断开连接	2026-06-27 11:20:10.390829
54	101001	online	设备WebSocket连接建立	2026-06-27 11:20:10.850521
55	101001	online	设备WebSocket连接建立	2026-06-27 11:20:11.443967
56	100100	online	设备WebSocket连接建立	2026-06-27 11:23:55.912602
57	100100	online	设备WebSocket连接建立	2026-06-27 11:23:55.986191
58	101001	online	设备WebSocket连接建立	2026-06-27 11:23:56.163704
59	101001	online	设备WebSocket连接建立	2026-06-27 11:23:56.242573
60	101001	offline	设备WebSocket断开连接	2026-06-27 11:24:56.33821
61	101001	online	设备WebSocket连接建立	2026-06-27 11:24:57.973628
62	101001	online	设备WebSocket连接建立	2026-06-27 11:24:58.043956
63	100100	online	设备WebSocket连接建立	2026-06-27 11:29:09.559206
64	100100	online	设备WebSocket连接建立	2026-06-27 11:29:09.630231
65	101001	online	设备WebSocket连接建立	2026-06-27 11:29:18.428186
66	101001	online	设备WebSocket连接建立	2026-06-27 11:29:18.514517
67	101001	offline	设备WebSocket断开连接	2026-06-27 11:29:58.492744
68	101001	online	设备WebSocket连接建立	2026-06-27 11:30:00.81245
69	101001	online	设备WebSocket连接建立	2026-06-27 11:30:00.922113
70	101001	offline	设备WebSocket断开连接	2026-06-27 11:30:45.57715
71	101001	online	设备WebSocket连接建立	2026-06-27 11:30:54.254622
72	101001	online	设备WebSocket连接建立	2026-06-27 11:30:54.33895
73	100100	offline	设备WebSocket断开连接	2026-06-27 11:31:42.249812
74	100100	online	设备WebSocket连接建立	2026-06-27 11:31:48.402826
75	100100	online	设备WebSocket连接建立	2026-06-27 11:31:48.500141
76	101001	online	设备WebSocket连接建立	2026-06-27 11:35:41.855068
77	101001	online	设备WebSocket连接建立	2026-06-27 11:35:41.928488
78	100100	online	设备WebSocket连接建立	2026-06-27 11:44:03.720774
79	100100	online	设备WebSocket连接建立	2026-06-27 11:44:03.790999
80	101001	online	设备WebSocket连接建立	2026-06-27 11:44:24.235326
81	101001	online	设备WebSocket连接建立	2026-06-27 11:44:24.554912
82	100100	online	设备WebSocket连接建立	2026-06-27 11:55:16.171009
83	100100	online	设备WebSocket连接建立	2026-06-27 11:55:16.24396
84	100100	online	设备WebSocket连接建立	2026-06-27 11:58:36.821876
85	100100	online	设备WebSocket连接建立	2026-06-27 11:58:36.897543
86	100100	online	设备WebSocket连接建立	2026-06-27 12:11:37.160118
87	100100	online	设备WebSocket连接建立	2026-06-27 12:11:37.230653
88	100100	online	设备WebSocket连接建立	2026-06-27 12:28:29.595707
89	100100	online	设备WebSocket连接建立	2026-06-27 12:28:29.688708
90	100100	online	设备WebSocket连接建立	2026-06-27 12:30:47.394625
91	100100	online	设备WebSocket连接建立	2026-06-27 12:30:47.467509
92	100100	online	设备WebSocket连接建立	2026-06-27 12:35:45.520331
93	100100	online	设备WebSocket连接建立	2026-06-27 12:35:45.595731
94	100100	online	设备WebSocket连接建立	2026-06-27 12:42:26.257185
95	100100	online	设备WebSocket连接建立	2026-06-27 12:42:26.329878
96	100100	online	设备WebSocket连接建立	2026-06-27 12:45:37.822836
97	100100	online	设备WebSocket连接建立	2026-06-27 12:45:37.935435
98	100100	online	设备WebSocket连接建立	2026-06-27 12:50:43.915669
99	100100	online	设备WebSocket连接建立	2026-06-27 12:50:43.987128
100	100100	online	设备WebSocket连接建立	2026-06-27 12:58:19.943683
101	100100	online	设备WebSocket连接建立	2026-06-27 12:58:20.019932
102	100100	online	设备WebSocket连接建立	2026-06-27 12:58:42.944621
103	100100	online	设备WebSocket连接建立	2026-06-27 12:58:43.016519
104	100100	online	设备WebSocket连接建立	2026-06-27 13:16:34.084493
105	100100	online	设备WebSocket连接建立	2026-06-27 13:16:34.154438
106	100100	online	设备WebSocket连接建立	2026-06-27 13:17:48.989725
107	100100	online	设备WebSocket连接建立	2026-06-27 13:17:49.071032
108	100100	online	设备WebSocket连接建立	2026-06-27 13:42:02.442429
109	100100	online	设备WebSocket连接建立	2026-06-27 13:42:02.512096
110	101001	online	设备WebSocket连接建立	2026-06-27 13:58:01.052123
111	101001	online	设备WebSocket连接建立	2026-06-27 13:58:01.124738
112	101001	offline	设备WebSocket断开连接	2026-06-27 13:59:12.339609
113	101001	online	设备WebSocket连接建立	2026-06-27 14:00:14.099787
114	101001	online	设备WebSocket连接建立	2026-06-27 14:00:14.192503
115	100100	online	设备WebSocket连接建立	2026-06-27 14:09:37.808714
116	100100	online	设备WebSocket连接建立	2026-06-27 14:09:37.882159
117	101001	online	设备WebSocket连接建立	2026-06-27 14:09:37.952859
118	101001	online	设备WebSocket连接建立	2026-06-27 14:09:38.026301
119	101001	online	设备WebSocket连接建立	2026-06-27 14:26:36.722879
120	101001	online	设备WebSocket连接建立	2026-06-27 14:26:36.796375
121	100100	online	设备WebSocket连接建立	2026-06-27 14:26:37.075285
122	100100	online	设备WebSocket连接建立	2026-06-27 14:26:37.152586
123	100100	online	设备WebSocket连接建立	2026-06-27 14:30:51.991888
124	100100	online	设备WebSocket连接建立	2026-06-27 14:30:52.06807
125	101001	online	设备WebSocket连接建立	2026-06-27 14:30:52.242664
126	101001	online	设备WebSocket连接建立	2026-06-27 14:30:52.314568
127	101001	online	设备WebSocket连接建立	2026-06-27 14:30:56.99661
128	100100	online	设备WebSocket连接建立	2026-06-27 14:30:57.069126
129	100100	online	设备WebSocket连接建立	2026-06-27 14:30:57.145065
130	101001	online	设备WebSocket连接建立	2026-06-27 14:30:57.221708
131	101001	online	设备WebSocket连接建立	2026-06-27 14:49:41.095679
132	101001	online	设备WebSocket连接建立	2026-06-27 14:49:41.167306
133	100100	online	设备WebSocket连接建立	2026-06-27 14:49:41.353313
134	100100	online	设备WebSocket连接建立	2026-06-27 14:49:41.422462
135	101001	online	设备WebSocket连接建立	2026-06-27 14:52:53.476754
136	101001	online	设备WebSocket连接建立	2026-06-27 14:52:53.5524
137	100100	online	设备WebSocket连接建立	2026-06-27 14:52:53.737981
138	100100	online	设备WebSocket连接建立	2026-06-27 14:52:53.809222
139	100100	online	设备WebSocket连接建立	2026-06-27 14:54:06.200075
140	100100	online	设备WebSocket连接建立	2026-06-27 14:54:06.273558
141	101001	online	设备WebSocket连接建立	2026-06-27 14:54:06.441097
142	101001	online	设备WebSocket连接建立	2026-06-27 14:54:06.536404
143	100100	online	设备WebSocket连接建立	2026-06-27 14:54:57.425766
144	100100	online	设备WebSocket连接建立	2026-06-27 14:54:57.498051
145	101001	online	设备WebSocket连接建立	2026-06-27 14:55:00.345343
146	101001	online	设备WebSocket连接建立	2026-06-27 14:55:00.421623
147	101001	online	设备WebSocket连接建立	2026-06-27 14:56:05.473517
148	101001	online	设备WebSocket连接建立	2026-06-27 14:56:05.710202
149	100100	online	设备WebSocket连接建立	2026-06-27 14:56:05.783358
150	100100	online	设备WebSocket连接建立	2026-06-27 14:56:05.857102
151	100100	online	设备WebSocket连接建立	2026-06-27 14:57:32.001079
152	100100	online	设备WebSocket连接建立	2026-06-27 14:57:32.073553
153	101001	online	设备WebSocket连接建立	2026-06-27 14:57:49.589517
154	101001	online	设备WebSocket连接建立	2026-06-27 14:57:49.662768
155	100100	online	设备WebSocket连接建立	2026-06-27 15:05:50.047388
156	100100	online	设备WebSocket连接建立	2026-06-27 15:05:50.118638
157	101001	online	设备WebSocket连接建立	2026-06-27 15:05:53.355632
158	101001	online	设备WebSocket连接建立	2026-06-27 15:05:54.148915
159	101001	offline	设备WebSocket断开连接	2026-06-27 15:12:32.221135
160	101001	online	设备WebSocket连接建立	2026-06-27 15:12:38.025838
161	101001	online	设备WebSocket连接建立	2026-06-27 15:12:38.098489
162	101001	online	设备WebSocket连接建立	2026-06-27 15:24:38.341851
163	101001	online	设备WebSocket连接建立	2026-06-27 15:24:38.421847
164	100100	online	设备WebSocket连接建立	2026-06-27 15:35:33.355339
165	100100	online	设备WebSocket连接建立	2026-06-27 15:35:33.700155
166	101001	online	设备WebSocket连接建立	2026-06-27 15:36:08.475763
167	101001	online	设备WebSocket连接建立	2026-06-27 15:36:08.554127
168	100100	offline	设备WebSocket断开连接	2026-06-27 15:50:59.540512
169	100100	online	设备WebSocket连接建立	2026-06-27 15:51:05.69696
170	100100	online	设备WebSocket连接建立	2026-06-27 15:51:05.773884
171	100100	online	设备WebSocket连接建立	2026-06-27 15:53:01.32763
172	100100	online	设备WebSocket连接建立	2026-06-27 15:53:01.399322
173	101001	online	设备WebSocket连接建立	2026-06-27 15:53:01.507267
174	101001	online	设备WebSocket连接建立	2026-06-27 15:53:01.585697
175	100100	online	设备WebSocket连接建立	2026-06-27 15:53:06.659286
176	100100	online	设备WebSocket连接建立	2026-06-27 15:53:06.735054
177	101001	online	设备WebSocket连接建立	2026-06-27 15:53:06.810704
178	101001	online	设备WebSocket连接建立	2026-06-27 15:53:06.883891
179	100100	online	设备WebSocket连接建立	2026-06-27 15:59:49.079856
180	100100	online	设备WebSocket连接建立	2026-06-27 15:59:49.221892
181	101001	online	设备WebSocket连接建立	2026-06-27 15:59:49.302743
182	101001	online	设备WebSocket连接建立	2026-06-27 15:59:49.377531
183	101001	online	设备WebSocket连接建立	2026-06-27 16:09:47.331367
184	101001	online	设备WebSocket连接建立	2026-06-27 16:09:47.428036
185	100100	online	设备WebSocket连接建立	2026-06-27 16:09:47.503295
186	100100	online	设备WebSocket连接建立	2026-06-27 16:09:47.95771
187	100100	offline	设备WebSocket断开连接	2026-06-27 16:24:59.778041
188	101001	online	设备WebSocket连接建立	2026-06-27 16:31:53.974559
189	101001	online	设备WebSocket连接建立	2026-06-27 16:31:54.051231
190	100100	online	设备WebSocket连接建立	2026-06-27 16:37:57.075038
191	100100	online	设备WebSocket连接建立	2026-06-27 16:37:57.14883
192	100100	online	设备WebSocket连接建立	2026-06-27 16:52:19.756726
193	100100	online	设备WebSocket连接建立	2026-06-27 16:52:20.011994
194	100100	offline	设备WebSocket断开连接	2026-06-27 16:53:37.760693
195	101001	online	设备WebSocket连接建立	2026-06-27 17:05:21.068977
196	101001	online	设备WebSocket连接建立	2026-06-27 17:05:21.147375
197	101001	online	设备WebSocket连接建立	2026-06-27 17:11:43.009515
198	101001	online	设备WebSocket连接建立	2026-06-27 17:11:43.148494
199	101001	online	设备WebSocket连接建立	2026-06-27 17:12:31.975608
200	101001	online	设备WebSocket连接建立	2026-06-27 17:12:32.108736
201	101001	online	设备WebSocket连接建立	2026-06-27 17:13:14.185902
202	101001	online	设备WebSocket连接建立	2026-06-27 17:13:14.269736
203	101001	offline	设备WebSocket断开连接	2026-06-27 17:13:57.393623
204	101001	online	设备WebSocket连接建立	2026-06-27 17:14:03.232819
205	101001	online	设备WebSocket连接建立	2026-06-27 17:14:03.320362
206	101001	online	设备WebSocket连接建立	2026-06-27 17:14:58.109727
207	101001	online	设备WebSocket连接建立	2026-06-27 17:14:58.188691
208	101001	online	设备WebSocket连接建立	2026-06-27 17:15:50.748542
209	101001	online	设备WebSocket连接建立	2026-06-27 17:15:50.834547
210	101001	online	设备WebSocket连接建立	2026-06-27 17:19:04.074877
211	101001	online	设备WebSocket连接建立	2026-06-27 17:19:04.185739
212	101001	offline	设备WebSocket断开连接	2026-06-27 17:20:44.186843
213	101001	online	设备WebSocket连接建立	2026-06-27 17:20:45.86578
214	101001	online	设备WebSocket连接建立	2026-06-27 17:20:45.946464
215	101001	online	设备WebSocket连接建立	2026-06-27 17:25:32.954773
216	101001	online	设备WebSocket连接建立	2026-06-27 17:25:33.181436
217	101001	online	设备WebSocket连接建立	2026-06-27 17:27:28.346106
218	101001	online	设备WebSocket连接建立	2026-06-27 17:27:28.424993
219	101001	online	设备WebSocket连接建立	2026-06-27 18:04:56.652973
220	101001	online	设备WebSocket连接建立	2026-06-27 18:04:56.740728
221	101001	online	设备WebSocket连接建立	2026-06-27 18:06:52.819787
222	101001	online	设备WebSocket连接建立	2026-06-27 18:06:52.893232
223	101001	online	设备WebSocket连接建立	2026-06-27 22:43:22.88857
224	101001	online	设备WebSocket连接建立	2026-06-27 22:43:22.967632
225	101001	online	设备WebSocket连接建立	2026-06-27 23:15:08.466261
226	101001	online	设备WebSocket连接建立	2026-06-27 23:15:08.545361
227	101001	offline	设备WebSocket断开连接	2026-06-28 02:10:17.700956
228	100100	online	设备WebSocket连接建立	2026-06-28 07:42:07.076801
229	100100	online	设备WebSocket连接建立	2026-06-28 07:42:07.148268
230	100100	online	设备WebSocket连接建立	2026-06-28 07:45:40.294895
231	100100	online	设备WebSocket连接建立	2026-06-28 07:45:40.369461
232	100100	online	设备WebSocket连接建立	2026-06-28 07:46:31.403873
233	100100	online	设备WebSocket连接建立	2026-06-28 07:46:31.478628
234	100100	online	设备WebSocket连接建立	2026-06-28 07:55:19.148113
235	100100	online	设备WebSocket连接建立	2026-06-28 07:55:19.224822
236	100100	online	设备WebSocket连接建立	2026-06-28 08:01:45.333148
237	100100	online	设备WebSocket连接建立	2026-06-28 08:01:45.411546
238	100100	online	设备WebSocket连接建立	2026-06-28 08:06:36.979856
239	100100	online	设备WebSocket连接建立	2026-06-28 08:06:37.053312
240	100100	online	设备WebSocket连接建立	2026-06-28 08:06:47.205464
241	100100	online	设备WebSocket连接建立	2026-06-28 08:06:47.27967
242	101001	online	设备WebSocket连接建立	2026-06-28 08:10:31.696513
243	101001	online	设备WebSocket连接建立	2026-06-28 08:10:31.769677
244	100100	online	设备WebSocket连接建立	2026-06-28 08:18:42.757439
245	100100	online	设备WebSocket连接建立	2026-06-28 08:18:42.828576
246	101001	online	设备WebSocket连接建立	2026-06-28 08:18:44.822992
247	101001	online	设备WebSocket连接建立	2026-06-28 08:18:44.898687
248	100100	online	设备WebSocket连接建立	2026-06-28 08:28:12.025768
249	100100	online	设备WebSocket连接建立	2026-06-28 08:28:12.274313
250	101001	online	设备WebSocket连接建立	2026-06-28 08:28:12.36468
251	101001	online	设备WebSocket连接建立	2026-06-28 08:28:12.4665
252	101001	online	设备WebSocket连接建立	2026-06-28 08:29:37.479541
253	101001	online	设备WebSocket连接建立	2026-06-28 08:29:37.627901
254	100100	online	设备WebSocket连接建立	2026-06-28 08:29:37.968583
255	100100	online	设备WebSocket连接建立	2026-06-28 08:29:38.043873
256	100100	online	设备WebSocket连接建立	2026-06-28 08:39:24.423586
257	100100	online	设备WebSocket连接建立	2026-06-28 08:39:24.509015
258	101001	online	设备WebSocket连接建立	2026-06-28 08:39:24.581357
259	101001	online	设备WebSocket连接建立	2026-06-28 08:39:24.788743
260	101001	online	设备WebSocket连接建立	2026-06-28 08:39:34.683667
261	100100	online	设备WebSocket连接建立	2026-06-28 08:39:34.759718
262	100100	online	设备WebSocket连接建立	2026-06-28 08:39:34.837898
263	101001	online	设备WebSocket连接建立	2026-06-28 08:39:34.912728
264	100100	online	设备WebSocket连接建立	2026-06-28 08:44:39.132275
265	100100	online	设备WebSocket连接建立	2026-06-28 08:44:39.211206
266	101001	online	设备WebSocket连接建立	2026-06-28 08:44:39.296442
267	101001	online	设备WebSocket连接建立	2026-06-28 08:44:39.371087
268	100100	online	设备WebSocket连接建立	2026-06-28 09:07:18.259738
269	100100	online	设备WebSocket连接建立	2026-06-28 09:07:18.332833
270	101001	online	设备WebSocket连接建立	2026-06-28 09:07:18.999034
271	101001	online	设备WebSocket连接建立	2026-06-28 09:07:19.23829
272	100100	online	设备WebSocket连接建立	2026-06-28 09:09:36.171337
273	100100	online	设备WebSocket连接建立	2026-06-28 09:09:36.245943
274	101001	online	设备WebSocket连接建立	2026-06-28 09:09:36.317479
275	101001	online	设备WebSocket连接建立	2026-06-28 09:09:36.391455
276	100100	online	设备WebSocket连接建立	2026-06-28 09:11:17.899334
277	100100	online	设备WebSocket连接建立	2026-06-28 09:11:17.978357
278	101001	online	设备WebSocket连接建立	2026-06-28 09:11:18.054865
279	101001	online	设备WebSocket连接建立	2026-06-28 09:11:18.130049
280	100100	online	设备WebSocket连接建立	2026-06-28 09:14:27.188387
281	100100	online	设备WebSocket连接建立	2026-06-28 09:14:27.265968
282	101001	online	设备WebSocket连接建立	2026-06-28 09:14:27.340346
283	101001	online	设备WebSocket连接建立	2026-06-28 09:14:27.414992
284	100100	online	设备WebSocket连接建立	2026-06-28 09:17:09.622663
285	100100	online	设备WebSocket连接建立	2026-06-28 09:17:09.69706
286	101001	online	设备WebSocket连接建立	2026-06-28 09:17:09.769792
287	101001	online	设备WebSocket连接建立	2026-06-28 09:17:09.966535
288	100100	online	设备WebSocket连接建立	2026-06-28 09:18:40.836115
289	100100	online	设备WebSocket连接建立	2026-06-28 09:18:40.909392
290	101001	online	设备WebSocket连接建立	2026-06-28 09:18:40.982775
291	101001	online	设备WebSocket连接建立	2026-06-28 09:18:41.168139
292	101001	online	设备WebSocket连接建立	2026-06-28 09:19:47.846884
293	100100	online	设备WebSocket连接建立	2026-06-28 09:19:47.985685
294	100100	online	设备WebSocket连接建立	2026-06-28 09:19:48.061107
295	101001	online	设备WebSocket连接建立	2026-06-28 09:19:48.139327
296	100100	online	设备WebSocket连接建立	2026-06-28 09:21:15.732146
297	100100	online	设备WebSocket连接建立	2026-06-28 09:21:15.806794
298	101001	online	设备WebSocket连接建立	2026-06-28 09:21:15.883144
299	101001	online	设备WebSocket连接建立	2026-06-28 09:21:16.027311
300	100100	online	设备WebSocket连接建立	2026-06-28 09:23:26.872149
301	100100	online	设备WebSocket连接建立	2026-06-28 09:23:26.947545
302	101001	online	设备WebSocket连接建立	2026-06-28 09:23:27.22378
303	101001	online	设备WebSocket连接建立	2026-06-28 09:23:27.300395
304	100100	online	设备WebSocket连接建立	2026-06-28 09:32:04.15383
305	100100	online	设备WebSocket连接建立	2026-06-28 09:32:04.230537
306	101001	online	设备WebSocket连接建立	2026-06-28 09:32:07.493136
307	101001	online	设备WebSocket连接建立	2026-06-28 09:32:07.573987
308	100100	online	设备WebSocket连接建立	2026-06-28 09:34:29.642791
309	100100	online	设备WebSocket连接建立	2026-06-28 09:34:29.719868
310	101001	online	设备WebSocket连接建立	2026-06-28 09:34:29.794242
311	101001	online	设备WebSocket连接建立	2026-06-28 09:34:29.948186
312	100100	online	设备WebSocket连接建立	2026-06-28 09:46:38.546075
313	100100	online	设备WebSocket连接建立	2026-06-28 09:46:38.623352
314	101001	online	设备WebSocket连接建立	2026-06-28 09:46:39.873659
315	101001	online	设备WebSocket连接建立	2026-06-28 09:46:39.950643
316	100100	online	设备WebSocket连接建立	2026-06-28 09:46:56.400672
317	101001	online	设备WebSocket连接建立	2026-06-28 09:46:56.813596
318	101001	online	设备WebSocket连接建立	2026-06-28 09:46:58.435754
319	101001	online	设备WebSocket连接建立	2026-06-28 09:46:58.510667
320	100100	online	设备WebSocket连接建立	2026-06-28 09:46:58.59833
321	100100	online	设备WebSocket连接建立	2026-06-28 09:46:58.675923
322	100100	online	设备WebSocket连接建立	2026-06-28 09:54:08.61657
323	100100	online	设备WebSocket连接建立	2026-06-28 09:54:08.691367
324	101001	online	设备WebSocket连接建立	2026-06-28 09:54:08.765725
325	101001	online	设备WebSocket连接建立	2026-06-28 09:54:08.842151
326	100100	online	设备WebSocket连接建立	2026-06-28 09:58:21.045436
327	100100	online	设备WebSocket连接建立	2026-06-28 09:58:21.125017
328	101001	online	设备WebSocket连接建立	2026-06-28 09:58:21.377412
329	101001	online	设备WebSocket连接建立	2026-06-28 09:58:21.448749
330	101001	offline	设备WebSocket断开连接	2026-06-28 09:59:23.536344
331	101001	online	设备WebSocket连接建立	2026-06-28 09:59:29.724462
332	101001	online	设备WebSocket连接建立	2026-06-28 09:59:29.797251
333	101001	online	设备WebSocket连接建立	2026-06-28 10:00:27.243184
334	101001	online	设备WebSocket连接建立	2026-06-28 10:00:27.37371
335	100100	online	设备WebSocket连接建立	2026-06-28 10:00:28.616599
336	100100	online	设备WebSocket连接建立	2026-06-28 10:00:28.690169
337	101001	online	设备WebSocket连接建立	2026-06-28 10:11:55.660741
338	101001	online	设备WebSocket连接建立	2026-06-28 10:11:55.737363
339	100100	online	设备WebSocket连接建立	2026-06-28 10:24:55.659881
340	100100	online	设备WebSocket连接建立	2026-06-28 10:24:55.746867
341	100100	online	设备WebSocket连接建立	2026-06-28 10:25:53.232666
342	100100	online	设备WebSocket连接建立	2026-06-28 10:25:53.31183
343	100100	online	设备WebSocket连接建立	2026-06-28 10:26:13.207212
344	100100	online	设备WebSocket连接建立	2026-06-28 10:26:13.334595
345	100100	online	设备WebSocket连接建立	2026-06-28 10:30:04.918939
346	100100	online	设备WebSocket连接建立	2026-06-28 10:30:04.992961
347	100100	online	设备WebSocket连接建立	2026-06-28 10:31:07.299956
348	100100	online	设备WebSocket连接建立	2026-06-28 10:31:07.379765
349	100100	online	设备WebSocket连接建立	2026-06-28 10:32:11.442108
350	100100	online	设备WebSocket连接建立	2026-06-28 10:32:11.513963
351	100100	online	设备WebSocket连接建立	2026-06-28 10:33:49.906469
352	100100	online	设备WebSocket连接建立	2026-06-28 10:33:49.981176
353	100100	online	设备WebSocket连接建立	2026-06-28 10:36:37.944518
354	100100	online	设备WebSocket连接建立	2026-06-28 10:36:38.023341
355	100100	online	设备WebSocket连接建立	2026-06-28 10:45:36.230657
356	100100	online	设备WebSocket连接建立	2026-06-28 10:45:36.306648
357	101001	online	设备WebSocket连接建立	2026-06-28 10:46:39.387683
358	101001	online	设备WebSocket连接建立	2026-06-28 10:46:39.466899
359	100100	online	设备WebSocket连接建立	2026-06-28 10:46:51.472946
360	100100	online	设备WebSocket连接建立	2026-06-28 10:46:51.551371
361	101001	online	设备WebSocket连接建立	2026-06-28 10:46:57.548618
362	101001	online	设备WebSocket连接建立	2026-06-28 10:46:57.625684
363	101001	online	设备WebSocket连接建立	2026-06-28 10:49:32.423338
364	101001	online	设备WebSocket连接建立	2026-06-28 10:49:32.496951
365	100100	online	设备WebSocket连接建立	2026-06-28 10:49:32.5761
366	100100	online	设备WebSocket连接建立	2026-06-28 10:49:32.649764
367	101001	online	设备WebSocket连接建立	2026-06-28 10:52:47.881645
368	101001	online	设备WebSocket连接建立	2026-06-28 10:52:47.957805
369	100100	online	设备WebSocket连接建立	2026-06-28 10:52:48.032281
370	100100	online	设备WebSocket连接建立	2026-06-28 10:52:48.102681
371	101001	online	设备WebSocket连接建立	2026-06-28 10:57:11.677465
372	101001	online	设备WebSocket连接建立	2026-06-28 10:57:11.75066
373	100100	online	设备WebSocket连接建立	2026-06-28 10:57:11.827057
374	100100	online	设备WebSocket连接建立	2026-06-28 10:57:11.900432
375	101001	online	设备WebSocket连接建立	2026-06-28 11:02:59.621399
376	101001	online	设备WebSocket连接建立	2026-06-28 11:02:59.699243
377	100100	online	设备WebSocket连接建立	2026-06-28 11:02:59.77276
378	100100	online	设备WebSocket连接建立	2026-06-28 11:02:59.847471
379	101001	online	设备WebSocket连接建立	2026-06-28 11:08:09.248403
380	101001	online	设备WebSocket连接建立	2026-06-28 11:08:09.324632
381	100100	online	设备WebSocket连接建立	2026-06-28 11:08:12.646165
382	100100	online	设备WebSocket连接建立	2026-06-28 11:08:12.732252
383	101001	online	设备WebSocket连接建立	2026-06-28 11:11:16.983144
384	101001	online	设备WebSocket连接建立	2026-06-28 11:11:17.057459
385	100100	online	设备WebSocket连接建立	2026-06-28 11:11:17.129305
386	100100	online	设备WebSocket连接建立	2026-06-28 11:11:17.613241
387	101001	online	设备WebSocket连接建立	2026-06-28 11:18:27.391106
388	101001	online	设备WebSocket连接建立	2026-06-28 11:18:27.47106
389	100100	online	设备WebSocket连接建立	2026-06-28 11:18:27.554515
390	100100	online	设备WebSocket连接建立	2026-06-28 11:18:27.636248
391	101001	online	设备WebSocket连接建立	2026-06-28 11:21:17.473515
392	101001	online	设备WebSocket连接建立	2026-06-28 11:21:17.553482
393	100100	online	设备WebSocket连接建立	2026-06-28 11:21:18.079565
394	100100	online	设备WebSocket连接建立	2026-06-28 11:21:18.156376
395	101001	offline	设备WebSocket断开连接	2026-06-28 11:24:05.937565
396	101001	online	设备WebSocket连接建立	2026-06-28 11:24:11.561293
397	101001	online	设备WebSocket连接建立	2026-06-28 11:24:11.636609
398	100100	online	设备WebSocket连接建立	2026-06-28 11:25:29.975978
399	100100	online	设备WebSocket连接建立	2026-06-28 11:25:30.050892
400	101001	online	设备WebSocket连接建立	2026-06-28 11:25:30.126676
401	101001	online	设备WebSocket连接建立	2026-06-28 11:25:30.201957
402	101001	online	设备WebSocket连接建立	2026-06-28 11:29:38.76954
403	101001	online	设备WebSocket连接建立	2026-06-28 11:29:38.849282
404	100100	online	设备WebSocket连接建立	2026-06-28 11:29:38.922173
405	100100	online	设备WebSocket连接建立	2026-06-28 11:29:38.996908
406	101001	offline	设备WebSocket断开连接	2026-06-28 11:30:41.192788
407	101001	online	设备WebSocket连接建立	2026-06-28 11:30:46.800064
408	101001	online	设备WebSocket连接建立	2026-06-28 11:30:46.87462
409	101001	offline	设备WebSocket断开连接	2026-06-28 11:31:08.209473
410	101001	online	设备WebSocket连接建立	2026-06-28 11:31:13.79887
411	101001	online	设备WebSocket连接建立	2026-06-28 11:31:13.88008
412	100100	online	设备WebSocket连接建立	2026-06-28 11:35:12.432911
413	100100	online	设备WebSocket连接建立	2026-06-28 11:35:12.51557
414	101001	online	设备WebSocket连接建立	2026-06-28 11:35:12.595358
415	101001	online	设备WebSocket连接建立	2026-06-28 11:35:12.676136
416	101001	online	设备WebSocket连接建立	2026-06-28 11:56:47.685729
417	101001	online	设备WebSocket连接建立	2026-06-28 11:56:47.76112
418	100100	online	设备WebSocket连接建立	2026-06-28 11:56:47.837351
419	100100	online	设备WebSocket连接建立	2026-06-28 11:56:47.917697
420	101001	online	设备WebSocket连接建立	2026-06-28 14:09:28.14474
421	101001	online	设备WebSocket连接建立	2026-06-28 14:09:28.232844
422	100100	online	设备WebSocket连接建立	2026-06-28 14:09:28.337348
423	100100	online	设备WebSocket连接建立	2026-06-28 14:09:28.415029
424	101001	online	设备WebSocket连接建立	2026-06-28 14:12:48.92152
425	101001	online	设备WebSocket连接建立	2026-06-28 14:12:49.004553
426	100100	online	设备WebSocket连接建立	2026-06-28 14:12:49.07869
427	100100	online	设备WebSocket连接建立	2026-06-28 14:12:49.157814
428	101001	online	设备WebSocket连接建立	2026-06-28 14:15:53.72697
429	101001	online	设备WebSocket连接建立	2026-06-28 14:15:53.803687
430	100100	online	设备WebSocket连接建立	2026-06-28 14:15:53.905672
431	100100	online	设备WebSocket连接建立	2026-06-28 14:15:53.977688
432	101001	online	设备WebSocket连接建立	2026-06-28 14:57:51.847093
433	101001	online	设备WebSocket连接建立	2026-06-28 14:57:51.923417
434	100100	online	设备WebSocket连接建立	2026-06-28 14:57:52.000825
435	100100	online	设备WebSocket连接建立	2026-06-28 14:57:52.077506
436	101001	online	设备WebSocket连接建立	2026-06-28 15:12:04.5064
437	101001	online	设备WebSocket连接建立	2026-06-28 15:12:04.587768
438	100100	online	设备WebSocket连接建立	2026-06-28 15:12:04.661028
439	100100	online	设备WebSocket连接建立	2026-06-28 15:12:04.73306
440	101001	online	设备WebSocket连接建立	2026-06-28 15:17:25.616885
441	101001	online	设备WebSocket连接建立	2026-06-28 15:17:25.688353
442	100100	online	设备WebSocket连接建立	2026-06-28 15:17:25.767363
443	100100	online	设备WebSocket连接建立	2026-06-28 15:17:25.83967
444	101001	online	设备WebSocket连接建立	2026-06-28 15:18:36.589757
445	101001	online	设备WebSocket连接建立	2026-06-28 15:18:36.66229
446	100100	online	设备WebSocket连接建立	2026-06-28 15:18:36.736551
447	100100	online	设备WebSocket连接建立	2026-06-28 15:18:36.808536
448	101001	online	设备WebSocket连接建立	2026-06-28 15:19:41.561538
449	101001	online	设备WebSocket连接建立	2026-06-28 15:19:41.636303
450	100100	online	设备WebSocket连接建立	2026-06-28 15:19:41.711351
451	100100	online	设备WebSocket连接建立	2026-06-28 15:19:41.790171
452	101001	online	设备WebSocket连接建立	2026-06-28 15:32:07.032841
453	101001	online	设备WebSocket连接建立	2026-06-28 15:32:07.105902
454	100100	online	设备WebSocket连接建立	2026-06-28 15:32:07.179018
455	100100	online	设备WebSocket连接建立	2026-06-28 15:32:07.254473
456	100100	online	设备WebSocket连接建立	2026-06-28 15:33:40.624062
457	100100	online	设备WebSocket连接建立	2026-06-28 15:33:40.701234
458	101001	online	设备WebSocket连接建立	2026-06-28 15:33:40.777116
459	101001	online	设备WebSocket连接建立	2026-06-28 15:33:40.860039
460	101001	online	设备WebSocket连接建立	2026-06-28 15:40:48.096653
461	101001	online	设备WebSocket连接建立	2026-06-28 15:40:48.18171
462	100100	online	设备WebSocket连接建立	2026-06-28 15:40:48.258176
463	100100	online	设备WebSocket连接建立	2026-06-28 15:40:48.339034
464	101001	online	设备WebSocket连接建立	2026-06-28 15:47:53.989944
465	101001	online	设备WebSocket连接建立	2026-06-28 15:47:54.064171
466	100100	online	设备WebSocket连接建立	2026-06-28 15:47:54.215415
467	100100	online	设备WebSocket连接建立	2026-06-28 15:47:54.287458
468	101001	online	设备WebSocket连接建立	2026-06-28 15:49:36.077638
469	101001	online	设备WebSocket连接建立	2026-06-28 15:49:36.157515
470	100100	online	设备WebSocket连接建立	2026-06-28 15:49:36.246214
471	100100	online	设备WebSocket连接建立	2026-06-28 15:49:36.321335
472	101001	online	设备WebSocket连接建立	2026-06-28 16:13:56.801122
473	101001	online	设备WebSocket连接建立	2026-06-28 16:13:56.876771
474	100100	online	设备WebSocket连接建立	2026-06-28 16:13:58.873315
475	100100	online	设备WebSocket连接建立	2026-06-28 16:13:58.948305
476	101001	online	设备WebSocket连接建立	2026-06-28 16:17:22.927872
477	101001	online	设备WebSocket连接建立	2026-06-28 16:17:23.005092
478	100100	online	设备WebSocket连接建立	2026-06-28 16:17:23.079771
479	100100	online	设备WebSocket连接建立	2026-06-28 16:17:23.153539
480	101001	online	设备WebSocket连接建立	2026-06-28 16:18:40.242225
481	101001	online	设备WebSocket连接建立	2026-06-28 16:18:40.318412
482	100100	online	设备WebSocket连接建立	2026-06-28 16:18:40.391405
483	100100	online	设备WebSocket连接建立	2026-06-28 16:18:40.465292
484	100100	online	设备WebSocket连接建立	2026-06-28 16:21:14.771243
485	100100	online	设备WebSocket连接建立	2026-06-28 16:21:14.853886
486	101001	online	设备WebSocket连接建立	2026-06-28 16:21:14.943235
487	101001	online	设备WebSocket连接建立	2026-06-28 16:21:15.023747
488	101001	online	设备WebSocket连接建立	2026-06-28 17:33:30.812488
489	101001	online	设备WebSocket连接建立	2026-06-28 17:33:30.890266
490	100100	online	设备WebSocket连接建立	2026-06-28 17:33:30.966689
491	100100	online	设备WebSocket连接建立	2026-06-28 17:33:31.039333
492	101001	online	设备WebSocket连接建立	2026-06-28 17:43:19.194823
493	101001	online	设备WebSocket连接建立	2026-06-28 17:43:19.27045
494	100100	online	设备WebSocket连接建立	2026-06-28 17:43:19.350172
495	100100	online	设备WebSocket连接建立	2026-06-28 17:43:19.42447
496	101001	online	设备WebSocket连接建立	2026-06-28 17:56:22.600341
497	101001	online	设备WebSocket连接建立	2026-06-28 17:56:22.68653
498	100100	online	设备WebSocket连接建立	2026-06-28 17:56:22.761796
499	100100	online	设备WebSocket连接建立	2026-06-28 17:56:22.837774
500	101001	online	设备WebSocket连接建立	2026-06-28 18:33:03.823587
501	101001	online	设备WebSocket连接建立	2026-06-28 18:33:03.898838
502	100100	online	设备WebSocket连接建立	2026-06-28 18:33:04.104593
503	100100	online	设备WebSocket连接建立	2026-06-28 18:33:04.183079
504	100100	offline	设备WebSocket断开连接	2026-06-28 21:31:44.109363
505	101001	online	设备WebSocket连接建立	2026-06-28 22:01:50.274874
506	101001	online	设备WebSocket连接建立	2026-06-28 22:01:50.358863
507	101001	online	设备WebSocket连接建立	2026-06-28 22:02:56.265399
508	101001	online	设备WebSocket连接建立	2026-06-28 22:02:56.344595
509	101001	online	设备WebSocket连接建立	2026-06-28 22:05:55.148062
510	101001	online	设备WebSocket连接建立	2026-06-28 22:05:55.222338
511	101001	online	设备WebSocket连接建立	2026-06-28 22:13:46.421457
512	101001	online	设备WebSocket连接建立	2026-06-28 22:13:46.499118
513	101001	online	设备WebSocket连接建立	2026-06-28 22:16:07.819306
514	101001	online	设备WebSocket连接建立	2026-06-28 22:16:07.9009
515	101001	online	设备WebSocket连接建立	2026-06-28 22:17:01.59514
516	101001	online	设备WebSocket连接建立	2026-06-28 22:17:01.670579
517	101001	online	设备WebSocket连接建立	2026-06-28 22:17:41.454191
518	101001	online	设备WebSocket连接建立	2026-06-28 22:17:41.534251
519	101001	online	设备WebSocket连接建立	2026-06-28 22:19:35.728056
520	101001	online	设备WebSocket连接建立	2026-06-28 22:19:36.04962
521	101001	online	设备WebSocket连接建立	2026-06-28 22:20:58.5266
522	101001	online	设备WebSocket连接建立	2026-06-28 22:20:58.602361
523	101001	online	设备WebSocket连接建立	2026-06-28 22:21:51.006989
524	101001	online	设备WebSocket连接建立	2026-06-28 22:21:51.086445
525	101001	online	设备WebSocket连接建立	2026-06-28 22:30:00.587063
526	101001	online	设备WebSocket连接建立	2026-06-28 22:30:00.665369
527	101001	online	设备WebSocket连接建立	2026-06-28 22:30:58.467217
528	101001	online	设备WebSocket连接建立	2026-06-28 22:30:58.546033
529	101001	online	设备WebSocket连接建立	2026-06-28 22:31:38.649664
530	101001	online	设备WebSocket连接建立	2026-06-28 22:31:38.727012
531	101001	online	设备WebSocket连接建立	2026-06-28 22:35:24.442275
532	101001	online	设备WebSocket连接建立	2026-06-28 22:35:24.521633
533	101001	online	设备WebSocket连接建立	2026-06-28 22:47:46.164989
534	101001	online	设备WebSocket连接建立	2026-06-28 22:47:46.239738
535	101001	online	设备WebSocket连接建立	2026-06-28 23:18:23.283893
536	101001	online	设备WebSocket连接建立	2026-06-28 23:18:23.361629
537	101001	online	设备WebSocket连接建立	2026-06-28 23:28:35.636577
538	101001	online	设备WebSocket连接建立	2026-06-28 23:28:35.715673
539	101001	online	设备WebSocket连接建立	2026-06-29 07:09:24.669252
540	101001	online	设备WebSocket连接建立	2026-06-29 07:09:24.743899
541	101001	online	设备WebSocket连接建立	2026-06-29 07:17:11.608062
542	101001	online	设备WebSocket连接建立	2026-06-29 07:17:11.683907
543	101001	online	设备WebSocket连接建立	2026-06-29 07:24:52.642146
544	101001	online	设备WebSocket连接建立	2026-06-29 07:24:52.722962
545	101001	online	设备WebSocket连接建立	2026-06-29 07:29:21.609725
546	101001	online	设备WebSocket连接建立	2026-06-29 07:29:21.69347
547	101001	online	设备WebSocket连接建立	2026-06-29 07:33:59.920959
548	101001	online	设备WebSocket连接建立	2026-06-29 07:33:59.997623
549	101001	online	设备WebSocket连接建立	2026-06-29 07:46:04.820231
550	101001	online	设备WebSocket连接建立	2026-06-29 07:46:04.898989
551	101001	online	设备WebSocket连接建立	2026-06-29 07:47:56.297615
552	101001	online	设备WebSocket连接建立	2026-06-29 07:47:56.373918
553	101001	online	设备WebSocket连接建立	2026-06-29 07:49:27.002582
554	101001	online	设备WebSocket连接建立	2026-06-29 07:49:27.077585
555	101001	online	设备WebSocket连接建立	2026-06-29 07:52:08.116199
556	101001	online	设备WebSocket连接建立	2026-06-29 07:52:08.191298
557	101001	online	设备WebSocket连接建立	2026-06-29 07:53:54.245536
558	101001	online	设备WebSocket连接建立	2026-06-29 07:53:54.319574
559	101001	online	设备WebSocket连接建立	2026-06-29 07:54:34.512035
560	101001	online	设备WebSocket连接建立	2026-06-29 07:54:34.590814
561	101001	online	设备WebSocket连接建立	2026-06-29 07:56:26.392697
562	101001	online	设备WebSocket连接建立	2026-06-29 07:56:26.464974
563	101001	online	设备WebSocket连接建立	2026-06-29 07:57:35.066428
564	101001	online	设备WebSocket连接建立	2026-06-29 07:57:35.14468
565	100100	online	设备WebSocket连接建立	2026-06-29 12:35:36.79388
566	100100	offline	设备WebSocket断开连接	2026-06-29 14:21:20.597128
567	100100	online	设备WebSocket连接建立	2026-06-29 14:26:16.530661
568	100100	offline	设备WebSocket断开连接	2026-06-29 14:35:48.465815
569	100100	online	设备WebSocket连接建立	2026-06-29 14:35:54.216333
570	100100	offline	设备WebSocket断开连接	2026-06-29 15:03:17.050167
571	100100	online	设备WebSocket连接建立	2026-06-29 15:03:23.176682
572	test_ws_check	online	设备WebSocket连接建立	2026-06-29 19:32:19.069427
573	test_ws_check	offline	设备WebSocket断开连接	2026-06-29 19:32:24.063788
574	100100	offline	设备WebSocket断开连接	2026-06-29 20:03:32.05209
575	100100	offline	设备WebSocket断开连接	2026-06-29 21:28:22.916226
576	100101	offline	设备WebSocket断开连接	2026-06-29 21:40:05.397495
577	100100	offline	设备WebSocket断开连接	2026-06-29 21:40:05.499595
578	100101	offline	设备WebSocket断开连接	2026-06-29 21:41:52.400055
579	100101	offline	设备WebSocket断开连接	2026-06-29 21:44:01.811282
580	100101	offline	设备WebSocket断开连接	2026-06-29 21:49:19.987752
581	100101	online	设备WebSocket连接建立	2026-06-29 22:21:47.462048
582	100101	offline	设备WebSocket断开连接	2026-06-29 22:23:28.927929
583	100100	offline	设备WebSocket断开连接	2026-06-29 22:24:57.343471
584	100100	offline	设备WebSocket断开连接	2026-06-29 22:50:09.908441
585	100101	offline	设备WebSocket断开连接	2026-06-29 22:50:09.910918
586	100100	offline	设备WebSocket断开连接	2026-06-29 22:57:55.574996
587	100101	offline	设备WebSocket断开连接	2026-06-29 22:57:55.661164
588	100100	offline	设备WebSocket断开连接	2026-06-29 23:05:50.893795
589	100101	offline	设备WebSocket断开连接	2026-06-29 23:29:16.898768
590	100100	online	设备WebSocket连接建立	2026-06-30 06:31:58.671655
591	100100	offline	设备WebSocket断开连接	2026-06-30 06:49:17.202381
592	100100	offline	设备WebSocket断开连接	2026-06-30 06:59:19.05186
593	100100	offline	设备WebSocket断开连接	2026-06-30 07:01:17.480234
594	100100	offline	设备WebSocket断开连接	2026-06-30 07:01:37.223187
595	100100	online	设备WebSocket连接建立	2026-06-30 07:02:02.977403
596	100100	offline	设备WebSocket断开连接	2026-06-30 07:04:30.297108
597	100100	online	设备WebSocket连接建立	2026-06-30 07:04:40.606388
598	100100	offline	设备WebSocket断开连接	2026-06-30 07:19:17.380956
599	100100	offline	设备WebSocket断开连接	2026-06-30 07:24:09.0583
600	100100	online	设备WebSocket连接建立	2026-06-30 07:24:19.98453
601	100100	offline	设备WebSocket断开连接	2026-06-30 07:41:15.55208
602	100100	offline	设备WebSocket断开连接	2026-06-30 07:49:51.705408
603	100100	offline	设备WebSocket断开连接	2026-06-30 07:54:14.391726
604	100100	offline	设备WebSocket断开连接	2026-06-30 08:08:41.992196
605	100100	offline	设备WebSocket断开连接	2026-06-30 08:09:53.756612
606	100100	offline	设备WebSocket断开连接	2026-06-30 08:27:07.374077
607	100100	offline	设备WebSocket断开连接	2026-06-30 08:31:28.733489
608	100100	offline	设备WebSocket断开连接	2026-06-30 08:34:08.402478
609	100100	offline	设备WebSocket断开连接	2026-06-30 08:38:07.996176
610	100101	online	设备WebSocket连接建立	2026-06-30 08:44:48.895673
611	100101	offline	设备WebSocket断开连接	2026-06-30 08:45:01.97852
612	100101	online	设备WebSocket连接建立	2026-06-30 08:45:08.666692
613	100101	offline	设备WebSocket断开连接	2026-06-30 08:52:33.913621
614	100100	offline	设备WebSocket断开连接	2026-06-30 08:55:36.398215
615	100100	offline	设备WebSocket断开连接	2026-06-30 08:56:16.642797
616	100101	offline	设备WebSocket断开连接	2026-06-30 08:56:16.670622
617	100101	offline	设备WebSocket断开连接	2026-06-30 08:57:26.67134
618	100100	offline	设备WebSocket断开连接	2026-06-30 08:57:26.673931
619	100100	offline	设备WebSocket断开连接	2026-06-30 09:10:00.045233
620	100101	online	设备WebSocket连接建立	2026-06-30 09:10:16.260698
621	100100	offline	设备WebSocket断开连接	2026-06-30 09:17:45.010143
622	100101	offline	设备WebSocket断开连接	2026-06-30 09:17:45.0765
623	100100	offline	设备WebSocket断开连接	2026-06-30 09:27:38.769709
624	100101	offline	设备WebSocket断开连接	2026-06-30 09:27:48.023133
625	100101	offline	设备WebSocket断开连接	2026-06-30 09:34:35.616797
626	100101	online	设备WebSocket连接建立	2026-06-30 09:35:26.509557
627	100101	online	设备WebSocket连接建立	2026-06-30 10:14:19.82012
628	100100	offline	设备WebSocket断开连接	2026-06-30 10:25:49.82593
629	100101	offline	设备WebSocket断开连接	2026-06-30 17:51:34.759247
630	100100	offline	设备WebSocket断开连接	2026-06-30 18:34:21.042295
631	100100	offline	设备WebSocket断开连接	2026-06-30 18:35:22.294041
632	100101	offline	设备WebSocket断开连接	2026-06-30 20:21:29.361977
633	100100	offline	设备WebSocket断开连接	2026-06-30 20:58:09.527219
634	100101	offline	设备WebSocket断开连接	2026-06-30 21:28:16.274963
635	100100	offline	设备WebSocket断开连接	2026-06-30 21:32:44.002076
636	100100	online	设备WebSocket连接建立	2026-06-30 21:33:02.444974
\.


--
-- Data for Name: device_logs; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.device_logs (id, device_id, logs, create_time, log_type, content, level, detail, device_name, status) FROM stdin;
1	TEST_DEVICE_001	["heartbeat", "温度正常"]	2026-06-17 08:34:11	heartbeat	["heartbeat", "温度正常"]	info	\N	\N	\N
2	TEST_DEVICE_001	["heartbeat"]	2026-06-17 09:18:20	heartbeat	["heartbeat"]	info	\N	\N	\N
3	TEST_DEVICE_001	["heartbeat"]	2026-06-17 09:19:09	heartbeat	["heartbeat"]	info	\N	\N	\N
4	DEV001	["hb"]	2026-06-17 09:20:53	heartbeat	["hb"]	info	\N	\N	\N
5	123456	["test"]	2026-06-17 20:39:30	info	["test"]	info	\N	智能寄存柜	\N
6	123456	["test"]	2026-06-17 20:41:58	info	["test"]	info	\N	智能寄存柜	\N
7	123456	"test log"	2026-06-17 21:04:11	info	"test log"	info	\N	智能寄存柜	\N
8	123456	"test log"	2026-06-17 21:05:17	info	"test log"	info	\N	智能寄存柜	\N
9	123456	"test"	2026-06-17 21:07:59	info	"test"	info	\N	智能寄存柜	\N
10	123456	\N	2026-06-23 09:05:44	online	设备WebSocket连接建立	info	\N	\N	\N
11	123456	\N	2026-06-23 09:07:55	online	设备WebSocket连接建立	info	\N	\N	\N
12	123456	\N	2026-06-23 09:49:53	online	设备WebSocket连接建立	info	\N	\N	\N
13	123456	\N	2026-06-23 09:50:58	online	设备WebSocket连接建立	info	\N	\N	\N
14	123456	\N	2026-06-23 09:51:06	online	设备WebSocket连接建立	info	\N	\N	\N
15	123456	\N	2026-06-23 09:51:41	online	设备WebSocket连接建立	info	\N	\N	\N
16	123456	\N	2026-06-23 10:03:15	online	设备WebSocket连接建立	info	\N	\N	\N
17	123456	\N	2026-06-23 10:07:12	online	设备WebSocket连接建立	info	\N	\N	\N
18	123456	\N	2026-06-23 10:11:25	online	设备WebSocket连接建立	info	\N	\N	\N
19	123456	\N	2026-06-23 10:51:47	online	设备WebSocket连接建立	info	\N	\N	\N
20	123456	\N	2026-06-23 10:57:05	online	设备WebSocket连接建立	info	\N	\N	\N
21	123456	\N	2026-06-23 11:08:49	online	设备WebSocket连接建立	info	\N	\N	\N
22	123456	\N	2026-06-23 11:29:42	online	设备WebSocket连接建立	info	\N	\N	\N
23	123456	\N	2026-06-23 11:31:32	online	设备WebSocket连接建立	info	\N	\N	\N
24	123456	\N	2026-06-23 11:32:07	online	设备WebSocket连接建立	info	\N	\N	\N
25	123456	\N	2026-06-23 11:35:30	online	设备WebSocket连接建立	info	\N	\N	\N
26	123456	\N	2026-06-23 11:38:20	online	设备WebSocket连接建立	info	\N	\N	\N
27	123456	\N	2026-06-23 11:55:10	online	设备WebSocket连接建立	info	\N	\N	\N
28	123456	\N	2026-06-23 12:03:43	online	设备WebSocket连接建立	info	\N	\N	\N
29	123456	\N	2026-06-23 12:28:04	online	设备WebSocket连接建立	info	\N	\N	\N
30	123456	\N	2026-06-23 12:57:49	online	设备WebSocket连接建立	info	\N	\N	\N
31	123456	\N	2026-06-23 13:41:26	online	设备WebSocket连接建立	info	\N	\N	\N
32	123456	\N	2026-06-23 14:39:40	online	设备WebSocket连接建立	info	\N	\N	\N
33	123456	\N	2026-06-23 15:06:21	online	设备WebSocket连接建立	info	\N	\N	\N
34	123456	\N	2026-06-23 15:16:49	online	设备WebSocket连接建立	info	\N	\N	\N
35	123456	\N	2026-06-23 15:44:35	online	设备WebSocket连接建立	info	\N	\N	\N
36	123456	\N	2026-06-23 15:55:15	online	设备WebSocket连接建立	info	\N	\N	\N
37	123456	\N	2026-06-23 15:55:54	online	设备WebSocket连接建立	info	\N	\N	\N
38	123456	\N	2026-06-23 16:11:29	online	设备WebSocket连接建立	info	\N	\N	\N
39	123456	\N	2026-06-23 16:33:33	online	设备WebSocket连接建立	info	\N	\N	\N
40	123456	\N	2026-06-23 17:12:21	online	设备WebSocket连接建立	info	\N	\N	\N
41	123456	\N	2026-06-23 23:04:59	online	设备WebSocket连接建立	info	\N	\N	\N
42	123456	\N	2026-06-23 23:20:49	online	设备WebSocket连接建立	info	\N	\N	\N
43	123456	\N	2026-06-23 23:22:15	online	设备WebSocket连接建立	info	\N	\N	\N
44	123456	\N	2026-06-23 23:23:27	online	设备WebSocket连接建立	info	\N	\N	\N
45	123456	\N	2026-06-23 23:42:25	online	设备WebSocket连接建立	info	\N	\N	\N
46	123456	\N	2026-06-24 00:26:18	online	设备WebSocket连接建立	info	\N	\N	\N
47	123456	\N	2026-06-24 00:47:20	online	设备WebSocket连接建立	info	\N	\N	\N
48	123456	\N	2026-06-24 00:52:06	online	设备WebSocket连接建立	info	\N	\N	\N
49	123456	\N	2026-06-24 01:13:53	online	设备WebSocket连接建立	info	\N	\N	\N
50	123456	\N	2026-06-24 01:32:09	online	设备WebSocket连接建立	info	\N	\N	\N
51	123456	\N	2026-06-24 01:46:25	online	设备WebSocket连接建立	info	\N	\N	\N
52	123456	\N	2026-06-24 01:49:16	offline	设备WebSocket断开连接	warning	\N	\N	\N
53	123456	\N	2026-06-24 01:49:33	online	设备WebSocket连接建立	info	\N	\N	\N
54	123456	\N	2026-06-24 01:50:28	offline	设备WebSocket断开连接	warning	\N	\N	\N
55	123456	\N	2026-06-24 01:50:31	online	设备WebSocket连接建立	info	\N	\N	\N
56	123456	\N	2026-06-24 01:55:57	online	设备WebSocket连接建立	info	\N	\N	\N
57	123456	\N	2026-06-24 01:58:57	offline	设备WebSocket断开连接	warning	\N	\N	\N
58	123456	\N	2026-06-24 01:59:16	online	设备WebSocket连接建立	info	\N	\N	\N
59	123456	\N	2026-06-24 02:08:47	offline	设备WebSocket断开连接	warning	\N	\N	\N
60	123456	\N	2026-06-24 02:09:17	online	设备WebSocket连接建立	info	\N	\N	\N
61	123456	\N	2026-06-24 02:14:26	online	设备WebSocket连接建立	info	\N	\N	\N
62	123456	\N	2026-06-24 02:19:28	online	设备WebSocket连接建立	info	\N	\N	\N
63	123456	\N	2026-06-24 02:20:35	online	设备WebSocket连接建立	info	\N	\N	\N
64	123456	\N	2026-06-24 02:24:40	online	设备WebSocket连接建立	info	\N	\N	\N
65	123456	\N	2026-06-24 02:26:09	offline	设备WebSocket断开连接	warning	\N	\N	\N
66	123456	\N	2026-06-24 02:26:09	online	设备WebSocket连接建立	info	\N	\N	\N
67	123456	\N	2026-06-24 02:26:09	online	设备WebSocket连接建立	info	\N	\N	\N
68	123456	\N	2026-06-24 02:26:11	online	设备WebSocket连接建立	info	\N	\N	\N
69	123456	\N	2026-06-24 02:26:12	online	设备WebSocket连接建立	info	\N	\N	\N
70	123456	\N	2026-06-24 02:28:18	offline	设备WebSocket断开连接	warning	\N	\N	\N
71	123456	\N	2026-06-24 02:28:20	online	设备WebSocket连接建立	info	\N	\N	\N
72	123456	\N	2026-06-24 02:34:36	online	设备WebSocket连接建立	info	\N	\N	\N
73	123456	\N	2026-06-24 02:49:26	online	设备WebSocket连接建立	info	\N	\N	\N
74	123456	\N	2026-06-24 02:54:05	online	设备WebSocket连接建立	info	\N	\N	\N
75	123456	\N	2026-06-24 03:09:06	online	设备WebSocket连接建立	info	\N	\N	\N
76	123456	\N	2026-06-24 03:12:18	online	设备WebSocket连接建立	info	\N	\N	\N
77	123456	\N	2026-06-24 03:17:40	online	设备WebSocket连接建立	info	\N	\N	\N
78	123456	\N	2026-06-24 03:21:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
79	123456	\N	2026-06-24 03:21:38	online	设备WebSocket连接建立	info	\N	\N	\N
80	123456	\N	2026-06-24 03:22:21	online	设备WebSocket连接建立	info	\N	\N	\N
81	123456	\N	2026-06-24 03:40:41	online	设备WebSocket连接建立	info	\N	\N	\N
82	123456	\N	2026-06-24 03:42:20	offline	设备WebSocket断开连接	warning	\N	\N	\N
83	123456	\N	2026-06-24 03:42:26	online	设备WebSocket连接建立	info	\N	\N	\N
84	123456	\N	2026-06-24 03:45:03	offline	设备WebSocket断开连接	warning	\N	\N	\N
85	123456	\N	2026-06-24 03:45:04	online	设备WebSocket连接建立	info	\N	\N	\N
86	123456	\N	2026-06-24 03:45:04	online	设备WebSocket连接建立	info	\N	\N	\N
87	123456	\N	2026-06-24 03:45:05	online	设备WebSocket连接建立	info	\N	\N	\N
88	123456	\N	2026-06-24 03:45:07	online	设备WebSocket连接建立	info	\N	\N	\N
89	123456	\N	2026-06-24 03:45:08	online	设备WebSocket连接建立	info	\N	\N	\N
90	123456	\N	2026-06-24 03:47:04	offline	设备WebSocket断开连接	warning	\N	\N	\N
91	123456	\N	2026-06-24 03:47:05	online	设备WebSocket连接建立	info	\N	\N	\N
92	123456	\N	2026-06-24 03:51:41	online	设备WebSocket连接建立	info	\N	\N	\N
93	123456	\N	2026-06-24 03:53:32	online	设备WebSocket连接建立	info	\N	\N	\N
94	123456	\N	2026-06-24 03:55:06	online	设备WebSocket连接建立	info	\N	\N	\N
95	123456	\N	2026-06-24 03:55:40	online	设备WebSocket连接建立	info	\N	\N	\N
96	123456	\N	2026-06-24 04:14:03	online	设备WebSocket连接建立	info	\N	\N	\N
97	123456	\N	2026-06-24 04:23:21	offline	设备WebSocket断开连接	warning	\N	\N	\N
98	123456	\N	2026-06-24 04:23:27	online	设备WebSocket连接建立	info	\N	\N	\N
99	123456	\N	2026-06-24 04:24:12	online	设备WebSocket连接建立	info	\N	\N	\N
100	123456	\N	2026-06-24 04:25:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
101	123456	\N	2026-06-24 04:25:30	online	设备WebSocket连接建立	info	\N	\N	\N
102	123456	\N	2026-06-24 04:39:41	online	设备WebSocket连接建立	info	\N	\N	\N
103	123456	\N	2026-06-24 04:51:31	online	设备WebSocket连接建立	info	\N	\N	\N
104	123456	\N	2026-06-24 04:53:00	online	设备WebSocket连接建立	info	\N	\N	\N
105	123456	\N	2026-06-24 04:56:27	offline	设备WebSocket断开连接	warning	\N	\N	\N
106	123456	\N	2026-06-24 04:56:38	online	设备WebSocket连接建立	info	\N	\N	\N
107	123456	\N	2026-06-24 04:56:47	offline	设备WebSocket断开连接	warning	\N	\N	\N
108	123456	\N	2026-06-24 04:56:56	online	设备WebSocket连接建立	info	\N	\N	\N
109	123456	\N	2026-06-24 05:55:58	online	设备WebSocket连接建立	info	\N	\N	\N
110	123456	\N	2026-06-24 05:58:16	online	设备WebSocket连接建立	info	\N	\N	\N
111	123456	\N	2026-06-24 06:10:44	online	设备WebSocket连接建立	info	\N	\N	\N
112	123456	\N	2026-06-24 06:29:38	online	设备WebSocket连接建立	info	\N	\N	\N
113	123456	\N	2026-06-24 06:34:44	offline	设备WebSocket断开连接	warning	\N	\N	\N
114	123456	\N	2026-06-24 06:34:45	online	设备WebSocket连接建立	info	\N	\N	\N
115	123456	\N	2026-06-24 06:34:45	online	设备WebSocket连接建立	info	\N	\N	\N
116	123456	\N	2026-06-24 06:34:57	offline	设备WebSocket断开连接	warning	\N	\N	\N
117	123456	\N	2026-06-24 06:34:58	online	设备WebSocket连接建立	info	\N	\N	\N
118	123456	\N	2026-06-24 06:41:37	online	设备WebSocket连接建立	info	\N	\N	\N
119	123456	\N	2026-06-24 07:14:13	online	设备WebSocket连接建立	info	\N	\N	\N
120	123456	\N	2026-06-24 07:16:27	online	设备WebSocket连接建立	info	\N	\N	\N
121	123456	\N	2026-06-24 07:20:05	online	设备WebSocket连接建立	info	\N	\N	\N
122	123456	\N	2026-06-24 07:30:28	online	设备WebSocket连接建立	info	\N	\N	\N
123	123456	\N	2026-06-24 07:31:14	offline	设备WebSocket断开连接	warning	\N	\N	\N
124	123456	\N	2026-06-24 07:31:20	online	设备WebSocket连接建立	info	\N	\N	\N
125	123456	\N	2026-06-24 07:31:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
126	123456	\N	2026-06-24 07:31:39	online	设备WebSocket连接建立	info	\N	\N	\N
127	123456	\N	2026-06-24 07:36:53	online	设备WebSocket连接建立	info	\N	\N	\N
128	123456	\N	2026-06-24 07:37:08	offline	设备WebSocket断开连接	warning	\N	\N	\N
129	123456	\N	2026-06-24 07:37:17	online	设备WebSocket连接建立	info	\N	\N	\N
130	123456	\N	2026-06-24 07:37:38	offline	设备WebSocket断开连接	warning	\N	\N	\N
131	123456	\N	2026-06-24 08:32:10	online	设备WebSocket连接建立	info	\N	\N	\N
132	123456	\N	2026-06-24 08:55:33	offline	设备WebSocket断开连接	warning	\N	\N	\N
133	123456	\N	2026-06-24 08:56:12	online	设备WebSocket连接建立	info	\N	\N	\N
134	123456	\N	2026-06-24 08:56:23	offline	设备WebSocket断开连接	warning	\N	\N	\N
135	123456	\N	2026-06-24 08:56:23	online	设备WebSocket连接建立	info	\N	\N	\N
136	123456	\N	2026-06-24 08:56:23	online	设备WebSocket连接建立	info	\N	\N	\N
137	123456	\N	2026-06-24 08:56:31	offline	设备WebSocket断开连接	warning	\N	\N	\N
138	123456	\N	2026-06-24 08:56:32	online	设备WebSocket连接建立	info	\N	\N	\N
139	123456	\N	2026-06-24 09:09:45	offline	设备WebSocket断开连接	warning	\N	\N	\N
140	123456	\N	2026-06-24 09:09:46	online	设备WebSocket连接建立	info	\N	\N	\N
141	123456	\N	2026-06-24 09:09:46	online	设备WebSocket连接建立	info	\N	\N	\N
142	123456	\N	2026-06-24 09:09:47	online	设备WebSocket连接建立	info	\N	\N	\N
143	123456	\N	2026-06-24 09:09:49	online	设备WebSocket连接建立	info	\N	\N	\N
144	123456	\N	2026-06-24 09:09:50	online	设备WebSocket连接建立	info	\N	\N	\N
145	123456	\N	2026-06-24 09:09:51	online	设备WebSocket连接建立	info	\N	\N	\N
146	123456	\N	2026-06-24 09:09:53	online	设备WebSocket连接建立	info	\N	\N	\N
147	123456	\N	2026-06-24 09:09:54	online	设备WebSocket连接建立	info	\N	\N	\N
148	123456	\N	2026-06-24 09:29:05	offline	设备WebSocket断开连接	warning	\N	\N	\N
149	123456	\N	2026-06-24 09:29:06	online	设备WebSocket连接建立	info	\N	\N	\N
150	123456	\N	2026-06-24 09:29:17	offline	设备WebSocket断开连接	warning	\N	\N	\N
151	123456	\N	2026-06-24 09:29:18	online	设备WebSocket连接建立	info	\N	\N	\N
152	123456	\N	2026-06-24 09:29:18	online	设备WebSocket连接建立	info	\N	\N	\N
153	123456	\N	2026-06-24 09:29:19	online	设备WebSocket连接建立	info	\N	\N	\N
154	123456	\N	2026-06-24 09:29:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
155	123456	\N	2026-06-24 09:29:26	online	设备WebSocket连接建立	info	\N	\N	\N
156	123456	\N	2026-06-24 09:32:39	offline	设备WebSocket断开连接	warning	\N	\N	\N
157	123456	\N	2026-06-24 09:32:40	online	设备WebSocket连接建立	info	\N	\N	\N
158	123456	\N	2026-06-24 09:32:40	online	设备WebSocket连接建立	info	\N	\N	\N
159	123456	\N	2026-06-24 09:32:41	online	设备WebSocket连接建立	info	\N	\N	\N
160	123456	\N	2026-06-24 09:32:42	online	设备WebSocket连接建立	info	\N	\N	\N
161	123456	\N	2026-06-24 09:32:43	online	设备WebSocket连接建立	info	\N	\N	\N
162	123456	\N	2026-06-24 09:32:58	offline	设备WebSocket断开连接	warning	\N	\N	\N
163	123456	\N	2026-06-24 09:32:59	online	设备WebSocket连接建立	info	\N	\N	\N
164	123456	\N	2026-06-24 09:38:16	online	设备WebSocket连接建立	info	\N	\N	\N
165	123456	\N	2026-06-24 09:38:45	offline	设备WebSocket断开连接	warning	\N	\N	\N
166	123456	\N	2026-06-24 09:38:46	online	设备WebSocket连接建立	info	\N	\N	\N
167	123456	\N	2026-06-24 09:38:46	online	设备WebSocket连接建立	info	\N	\N	\N
168	123456	\N	2026-06-24 09:38:47	online	设备WebSocket连接建立	info	\N	\N	\N
169	123456	\N	2026-06-24 09:38:49	online	设备WebSocket连接建立	info	\N	\N	\N
170	123456	\N	2026-06-24 09:40:13	online	设备WebSocket连接建立	info	\N	\N	\N
171	123456	\N	2026-06-24 09:51:25	online	设备WebSocket连接建立	info	\N	\N	\N
172	123456	\N	2026-06-24 09:51:45	online	设备WebSocket连接建立	info	\N	\N	\N
173	123456	\N	2026-06-24 09:53:51	online	设备WebSocket连接建立	info	\N	\N	\N
174	123456	\N	2026-06-24 09:55:19	online	设备WebSocket连接建立	info	\N	\N	\N
175	123456	\N	2026-06-24 10:01:30	online	设备WebSocket连接建立	info	\N	\N	\N
176	123456	\N	2026-06-24 10:05:54	online	设备WebSocket连接建立	info	\N	\N	\N
177	123456	\N	2026-06-24 10:14:44	online	设备WebSocket连接建立	info	\N	\N	\N
178	123456	\N	2026-06-24 10:28:19	online	设备WebSocket连接建立	info	\N	\N	\N
179	123456	\N	2026-06-24 10:32:26	online	设备WebSocket连接建立	info	\N	\N	\N
180	123456	\N	2026-06-24 10:34:09	online	设备WebSocket连接建立	info	\N	\N	\N
181	123456	\N	2026-06-24 10:35:29	online	设备WebSocket连接建立	info	\N	\N	\N
182	123456	\N	2026-06-24 11:39:13	offline	设备WebSocket断开连接	warning	\N	\N	\N
183	123456	\N	2026-06-24 12:05:23	online	设备WebSocket连接建立	info	\N	\N	\N
184	123456	\N	2026-06-24 12:07:39	online	设备WebSocket连接建立	info	\N	\N	\N
185	123456	\N	2026-06-24 12:15:45	online	设备WebSocket连接建立	info	\N	\N	\N
186	123456	\N	2026-06-24 12:19:37	offline	设备WebSocket断开连接	warning	\N	\N	\N
187	123456	\N	2026-06-24 12:19:39	online	设备WebSocket连接建立	info	\N	\N	\N
188	123456	\N	2026-06-24 14:22:44	online	设备WebSocket连接建立	info	\N	\N	\N
189	123456	\N	2026-06-24 14:30:17	online	设备WebSocket连接建立	info	\N	\N	\N
190	123456	\N	2026-06-24 14:39:13	online	设备WebSocket连接建立	info	\N	\N	\N
191	123456	\N	2026-06-24 14:44:41	online	设备WebSocket连接建立	info	\N	\N	\N
192	123456	\N	2026-06-24 15:04:18	online	设备WebSocket连接建立	info	\N	\N	\N
193	123456	\N	2026-06-24 15:19:32	online	设备WebSocket连接建立	info	\N	\N	\N
194	123456	\N	2026-06-24 15:35:42	online	设备WebSocket连接建立	info	\N	\N	\N
195	123456	\N	2026-06-24 15:52:31	offline	设备WebSocket断开连接	warning	\N	\N	\N
196	123456	\N	2026-06-24 15:52:32	online	设备WebSocket连接建立	info	\N	\N	\N
197	123456	\N	2026-06-24 16:07:28	offline	设备WebSocket断开连接	warning	\N	\N	\N
198	123456	\N	2026-06-24 16:07:30	online	设备WebSocket连接建立	info	\N	\N	\N
199	123456	\N	2026-06-24 16:15:40	offline	设备WebSocket断开连接	warning	\N	\N	\N
200	123456	\N	2026-06-24 16:15:42	online	设备WebSocket连接建立	info	\N	\N	\N
201	123456	\N	2026-06-24 16:17:17	offline	设备WebSocket断开连接	warning	\N	\N	\N
202	123456	\N	2026-06-24 16:17:19	online	设备WebSocket连接建立	info	\N	\N	\N
203	123456	\N	2026-06-24 16:25:50	offline	设备WebSocket断开连接	warning	\N	\N	\N
204	123456	\N	2026-06-24 16:25:52	online	设备WebSocket连接建立	info	\N	\N	\N
205	123456	\N	2026-06-24 16:31:05	online	设备WebSocket连接建立	info	\N	\N	\N
206	123456	\N	2026-06-24 16:31:17	online	设备WebSocket连接建立	info	\N	\N	\N
207	123456	\N	2026-06-24 22:42:17	offline	设备WebSocket断开连接	warning	\N	\N	\N
208	123456	\N	2026-06-24 22:42:18	online	设备WebSocket连接建立	info	\N	\N	\N
209	123456	\N	2026-06-24 23:03:11	offline	设备WebSocket断开连接	warning	\N	\N	\N
210	123456	\N	2026-06-24 23:03:13	online	设备WebSocket连接建立	info	\N	\N	\N
211	123456	\N	2026-06-25 00:22:02	offline	设备WebSocket断开连接	warning	\N	\N	\N
212	123456	\N	2026-06-25 00:22:04	online	设备WebSocket连接建立	info	\N	\N	\N
213	123456	\N	2026-06-25 00:23:21	offline	设备WebSocket断开连接	warning	\N	\N	\N
214	123456	\N	2026-06-25 00:23:22	online	设备WebSocket连接建立	info	\N	\N	\N
215	123456	\N	2026-06-25 00:24:12	offline	设备WebSocket断开连接	warning	\N	\N	\N
216	123456	\N	2026-06-25 00:24:14	online	设备WebSocket连接建立	info	\N	\N	\N
217	123456	\N	2026-06-25 00:32:18	online	设备WebSocket连接建立	info	\N	\N	\N
218	123456	\N	2026-06-25 02:02:24	online	设备WebSocket连接建立	info	\N	\N	\N
219	123456	\N	2026-06-25 02:19:17	online	设备WebSocket连接建立	info	\N	\N	\N
220	123456	\N	2026-06-25 02:33:16	online	设备WebSocket连接建立	info	\N	\N	\N
221	123456	\N	2026-06-25 02:42:13	online	设备WebSocket连接建立	info	\N	\N	\N
222	123456	\N	2026-06-25 02:43:52	online	设备WebSocket连接建立	info	\N	\N	\N
223	123456	\N	2026-06-25 02:51:52	online	设备WebSocket连接建立	info	\N	\N	\N
224	123456	\N	2026-06-25 03:29:48	online	设备WebSocket连接建立	info	\N	\N	\N
225	123456	\N	2026-06-25 03:50:42	online	设备WebSocket连接建立	info	\N	\N	\N
226	123456	\N	2026-06-25 04:00:57	online	设备WebSocket连接建立	info	\N	\N	\N
227	123456	\N	2026-06-25 04:03:05	online	设备WebSocket连接建立	info	\N	\N	\N
228	123456	\N	2026-06-25 04:03:28	online	设备WebSocket连接建立	info	\N	\N	\N
229	123456	\N	2026-06-25 04:04:27	online	设备WebSocket连接建立	info	\N	\N	\N
230	123456	\N	2026-06-25 04:05:56	online	设备WebSocket连接建立	info	\N	\N	\N
231	123456	\N	2026-06-25 04:06:06	online	设备WebSocket连接建立	info	\N	\N	\N
232	123456	\N	2026-06-25 04:11:56	online	设备WebSocket连接建立	info	\N	\N	\N
233	123456	\N	2026-06-25 04:11:59	online	设备WebSocket连接建立	info	\N	\N	\N
234	123456	\N	2026-06-25 04:20:58	online	设备WebSocket连接建立	info	\N	\N	\N
235	123456	\N	2026-06-25 04:21:01	online	设备WebSocket连接建立	info	\N	\N	\N
236	123456	\N	2026-06-25 04:59:08	online	设备WebSocket连接建立	info	\N	\N	\N
237	123456	\N	2026-06-25 04:59:11	online	设备WebSocket连接建立	info	\N	\N	\N
238	123456	\N	2026-06-25 06:24:14	online	设备WebSocket连接建立	info	\N	\N	\N
239	123456	\N	2026-06-25 06:24:16	online	设备WebSocket连接建立	info	\N	\N	\N
240	123456	\N	2026-06-25 06:41:57	online	设备WebSocket连接建立	info	\N	\N	\N
241	123456	\N	2026-06-25 06:42:00	online	设备WebSocket连接建立	info	\N	\N	\N
242	123456	\N	2026-06-25 06:46:26	online	设备WebSocket连接建立	info	\N	\N	\N
243	123456	\N	2026-06-25 06:46:30	online	设备WebSocket连接建立	info	\N	\N	\N
244	123456	\N	2026-06-25 08:13:36	online	设备WebSocket连接建立	info	\N	\N	\N
245	123456	\N	2026-06-25 08:32:12	online	设备WebSocket连接建立	info	\N	\N	\N
246	123456	\N	2026-06-25 08:36:49	online	设备WebSocket连接建立	info	\N	\N	\N
247	123456	\N	2026-06-25 08:39:02	online	设备WebSocket连接建立	info	\N	\N	\N
248	123456	\N	2026-06-25 08:55:23	online	设备WebSocket连接建立	info	\N	\N	\N
249	123456	\N	2026-06-25 09:04:16	online	设备WebSocket连接建立	info	\N	\N	\N
250	123456	\N	2026-06-25 09:05:58	online	设备WebSocket连接建立	info	\N	\N	\N
251	123456	\N	2026-06-25 09:06:01	online	设备WebSocket连接建立	info	\N	\N	\N
252	123456	\N	2026-06-25 09:12:02	online	设备WebSocket连接建立	info	\N	\N	\N
253	123456	\N	2026-06-25 09:12:34	online	设备WebSocket连接建立	info	\N	\N	\N
254	123456	\N	2026-06-25 09:26:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
255	123456	\N	2026-06-25 09:26:29	online	设备WebSocket连接建立	info	\N	\N	\N
256	123456	\N	2026-06-25 09:30:50	online	设备WebSocket连接建立	info	\N	\N	\N
257	123456	\N	2026-06-25 09:34:27	offline	设备WebSocket断开连接	warning	\N	\N	\N
258	123456	\N	2026-06-25 09:34:28	online	设备WebSocket连接建立	info	\N	\N	\N
259	123456	\N	2026-06-25 09:41:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
260	123456	\N	2026-06-25 09:41:30	online	设备WebSocket连接建立	info	\N	\N	\N
261	123456	\N	2026-06-25 09:41:37	online	设备WebSocket连接建立	info	\N	\N	\N
262	123456	\N	2026-06-25 09:44:59	online	设备WebSocket连接建立	info	\N	\N	\N
263	123456	\N	2026-06-25 09:48:42	offline	设备WebSocket断开连接	warning	\N	\N	\N
264	123456	\N	2026-06-25 09:48:42	online	设备WebSocket连接建立	info	\N	\N	\N
265	123456	\N	2026-06-25 09:48:42	online	设备WebSocket连接建立	info	\N	\N	\N
266	123456	\N	2026-06-25 09:49:32	online	设备WebSocket连接建立	info	\N	\N	\N
267	123456	\N	2026-06-25 09:52:50	offline	设备WebSocket断开连接	warning	\N	\N	\N
268	123456	\N	2026-06-25 09:52:50	online	设备WebSocket连接建立	info	\N	\N	\N
269	123456	\N	2026-06-25 09:55:45	online	设备WebSocket连接建立	info	\N	\N	\N
270	123456	\N	2026-06-25 09:58:19	online	设备WebSocket连接建立	info	\N	\N	\N
271	123456	\N	2026-06-25 10:01:44	online	设备WebSocket连接建立	info	\N	\N	\N
272	123456	\N	2026-06-25 10:03:32	online	设备WebSocket连接建立	info	\N	\N	\N
273	123456	\N	2026-06-25 10:03:40	online	设备WebSocket连接建立	info	\N	\N	\N
274	123456	\N	2026-06-25 10:07:34	online	设备WebSocket连接建立	info	\N	\N	\N
275	123456	\N	2026-06-25 10:15:11	online	设备WebSocket连接建立	info	\N	\N	\N
276	123456	\N	2026-06-25 10:37:36	online	设备WebSocket连接建立	info	\N	\N	\N
277	123456	\N	2026-06-25 10:38:27	online	设备WebSocket连接建立	info	\N	\N	\N
278	123456	\N	2026-06-25 10:40:17	online	设备WebSocket连接建立	info	\N	\N	\N
279	123456	\N	2026-06-25 10:41:53	online	设备WebSocket连接建立	info	\N	\N	\N
280	123456	\N	2026-06-25 10:46:41	online	设备WebSocket连接建立	info	\N	\N	\N
281	123456	\N	2026-06-25 10:51:52	online	设备WebSocket连接建立	info	\N	\N	\N
282	123456	\N	2026-06-25 10:56:13	offline	设备WebSocket断开连接	warning	\N	\N	\N
283	123456	\N	2026-06-25 10:56:14	online	设备WebSocket连接建立	info	\N	\N	\N
284	123456	\N	2026-06-25 11:14:23	online	设备WebSocket连接建立	info	\N	\N	\N
285	123456	\N	2026-06-25 11:16:25	online	设备WebSocket连接建立	info	\N	\N	\N
286	123456	\N	2026-06-25 11:18:52	online	设备WebSocket连接建立	info	\N	\N	\N
287	101002	\N	2026-06-25 11:19:38	online	设备WebSocket连接建立	info	\N	\N	\N
288	123456	\N	2026-06-25 11:20:50	online	设备WebSocket连接建立	info	\N	\N	\N
289	101002	\N	2026-06-25 11:20:50	online	设备WebSocket连接建立	info	\N	\N	\N
290	123456	\N	2026-06-25 11:22:57	online	设备WebSocket连接建立	info	\N	\N	\N
291	101002	\N	2026-06-25 11:22:57	online	设备WebSocket连接建立	info	\N	\N	\N
292	123456	\N	2026-06-25 11:23:42	online	设备WebSocket连接建立	info	\N	\N	\N
293	101002	\N	2026-06-25 11:23:42	online	设备WebSocket连接建立	info	\N	\N	\N
294	123456	\N	2026-06-25 11:25:10	online	设备WebSocket连接建立	info	\N	\N	\N
295	101002	\N	2026-06-25 11:25:10	online	设备WebSocket连接建立	info	\N	\N	\N
296	123456	\N	2026-06-25 11:26:22	online	设备WebSocket连接建立	info	\N	\N	\N
297	101002	\N	2026-06-25 11:26:22	online	设备WebSocket连接建立	info	\N	\N	\N
298	123456	\N	2026-06-25 11:42:03	online	设备WebSocket连接建立	info	\N	\N	\N
299	123456	\N	2026-06-25 12:15:58	online	设备WebSocket连接建立	info	\N	\N	\N
300	123456	\N	2026-06-25 12:26:28	online	设备WebSocket连接建立	info	\N	\N	\N
301	123456	\N	2026-06-25 12:27:34	online	设备WebSocket连接建立	info	\N	\N	\N
302	123456	\N	2026-06-25 12:31:58	online	设备WebSocket连接建立	info	\N	\N	\N
303	123456	\N	2026-06-25 12:32:33	online	设备WebSocket连接建立	info	\N	\N	\N
304	123456	\N	2026-06-25 12:38:39	online	设备WebSocket连接建立	info	\N	\N	\N
305	123456	\N	2026-06-25 12:39:43	online	设备WebSocket连接建立	info	\N	\N	\N
306	123456	\N	2026-06-25 13:02:08	offline	设备WebSocket断开连接	warning	\N	\N	\N
307	123456	\N	2026-06-25 13:02:08	online	设备WebSocket连接建立	info	\N	\N	\N
308	123456	\N	2026-06-25 13:18:19	online	设备WebSocket连接建立	info	\N	\N	\N
309	123456	\N	2026-06-25 13:32:10	online	设备WebSocket连接建立	info	\N	\N	\N
310	123456	\N	2026-06-25 13:34:33	online	设备WebSocket连接建立	info	\N	\N	\N
311	123456	\N	2026-06-25 13:38:40	online	设备WebSocket连接建立	info	\N	\N	\N
312	123456	\N	2026-06-25 13:45:39	online	设备WebSocket连接建立	info	\N	\N	\N
313	123456	\N	2026-06-25 13:50:24	online	设备WebSocket连接建立	info	\N	\N	\N
314	101002	\N	2026-06-25 13:51:42	online	设备WebSocket连接建立	info	\N	\N	\N
315	101002	\N	2026-06-25 13:52:59	online	设备WebSocket连接建立	info	\N	\N	\N
316	101002	\N	2026-06-25 13:52:59	online	设备WebSocket连接建立	info	\N	\N	\N
317	101002	\N	2026-06-25 13:53:00	online	设备WebSocket连接建立	info	\N	\N	\N
318	101002	\N	2026-06-25 13:53:02	online	设备WebSocket连接建立	info	\N	\N	\N
319	101002	\N	2026-06-25 13:53:04	online	设备WebSocket连接建立	info	\N	\N	\N
320	101002	\N	2026-06-25 13:53:05	online	设备WebSocket连接建立	info	\N	\N	\N
321	101002	\N	2026-06-25 13:53:07	online	设备WebSocket连接建立	info	\N	\N	\N
322	101002	\N	2026-06-25 13:54:49	online	设备WebSocket连接建立	info	\N	\N	\N
323	123456	\N	2026-06-25 14:01:32	online	设备WebSocket连接建立	info	\N	\N	\N
324	101002	\N	2026-06-25 14:01:33	online	设备WebSocket连接建立	info	\N	\N	\N
325	101002	\N	2026-06-25 14:01:33	online	设备WebSocket连接建立	info	\N	\N	\N
326	101002	\N	2026-06-25 14:01:33	online	设备WebSocket连接建立	info	\N	\N	\N
327	101002	\N	2026-06-25 14:06:24	online	设备WebSocket连接建立	info	\N	\N	\N
328	123456	\N	2026-06-25 14:06:24	online	设备WebSocket连接建立	info	\N	\N	\N
329	101002	\N	2026-06-25 14:14:31	online	设备WebSocket连接建立	info	\N	\N	\N
330	123456	\N	2026-06-25 14:14:31	online	设备WebSocket连接建立	info	\N	\N	\N
331	123456	\N	2026-06-25 14:44:49	online	设备WebSocket连接建立	info	\N	\N	\N
332	123456	\N	2026-06-25 14:49:36	online	设备WebSocket连接建立	info	\N	\N	\N
333	101002	\N	2026-06-25 14:49:37	online	设备WebSocket连接建立	info	\N	\N	\N
334	101002	\N	2026-06-25 14:56:29	online	设备WebSocket连接建立	info	\N	\N	\N
335	123456	\N	2026-06-25 15:22:47	online	设备WebSocket连接建立	info	\N	\N	\N
336	123456	\N	2026-06-25 15:33:27	online	设备WebSocket连接建立	info	\N	\N	\N
337	123456	\N	2026-06-25 15:36:25	online	设备WebSocket连接建立	info	\N	\N	\N
338	123456	\N	2026-06-25 15:38:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
339	123456	\N	2026-06-25 15:38:25	online	设备WebSocket连接建立	info	\N	\N	\N
340	123456	\N	2026-06-25 15:46:24	offline	设备WebSocket断开连接	warning	\N	\N	\N
341	123456	\N	2026-06-25 15:46:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
342	123456	\N	2026-06-25 15:46:25	online	设备WebSocket连接建立	info	\N	\N	\N
343	123456	\N	2026-06-25 15:59:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
344	123456	\N	2026-06-25 15:59:31	online	设备WebSocket连接建立	info	\N	\N	\N
345	123456	\N	2026-06-25 17:00:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
346	123456	\N	2026-06-25 22:22:56	online	设备WebSocket连接建立	info	\N	\N	\N
347	123456	\N	2026-06-25 22:27:31	online	设备WebSocket连接建立	info	\N	\N	\N
348	123456	\N	2026-06-25 22:35:32	online	设备WebSocket连接建立	info	\N	\N	\N
349	123456	\N	2026-06-25 22:37:37	online	设备WebSocket连接建立	info	\N	\N	\N
350	123456	\N	2026-06-25 22:38:17	online	设备WebSocket连接建立	info	\N	\N	\N
351	123456	\N	2026-06-25 22:42:19	online	设备WebSocket连接建立	info	\N	\N	\N
352	123456	\N	2026-06-25 22:44:58	online	设备WebSocket连接建立	info	\N	\N	\N
353	123456	\N	2026-06-25 22:45:32	online	设备WebSocket连接建立	info	\N	\N	\N
354	123456	\N	2026-06-25 22:50:18	online	设备WebSocket连接建立	info	\N	\N	\N
355	123456	\N	2026-06-25 22:56:18	online	设备WebSocket连接建立	info	\N	\N	\N
356	123456	\N	2026-06-25 23:01:17	online	设备WebSocket连接建立	info	\N	\N	\N
357	123456	\N	2026-06-25 23:06:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
358	123456	\N	2026-06-25 23:06:33	online	设备WebSocket连接建立	info	\N	\N	\N
359	123456	\N	2026-06-25 23:06:33	online	设备WebSocket连接建立	info	\N	\N	\N
360	123456	\N	2026-06-25 23:06:34	online	设备WebSocket连接建立	info	\N	\N	\N
361	123456	\N	2026-06-25 23:06:35	online	设备WebSocket连接建立	info	\N	\N	\N
362	123456	\N	2026-06-25 23:06:37	online	设备WebSocket连接建立	info	\N	\N	\N
363	123456	\N	2026-06-25 23:06:38	online	设备WebSocket连接建立	info	\N	\N	\N
364	123456	\N	2026-06-25 23:06:39	online	设备WebSocket连接建立	info	\N	\N	\N
365	123456	\N	2026-06-25 23:06:40	online	设备WebSocket连接建立	info	\N	\N	\N
366	123456	\N	2026-06-25 23:06:42	online	设备WebSocket连接建立	info	\N	\N	\N
367	123456	\N	2026-06-25 23:06:43	online	设备WebSocket连接建立	info	\N	\N	\N
368	123456	\N	2026-06-25 23:06:44	online	设备WebSocket连接建立	info	\N	\N	\N
369	123456	\N	2026-06-25 23:10:42	online	设备WebSocket连接建立	info	\N	\N	\N
370	123456	\N	2026-06-25 23:10:42	online	设备WebSocket连接建立	info	\N	\N	\N
371	123456	\N	2026-06-25 23:10:42	online	设备WebSocket连接建立	info	\N	\N	\N
372	123456	\N	2026-06-25 23:10:44	online	设备WebSocket连接建立	info	\N	\N	\N
373	123456	\N	2026-06-25 23:29:27	online	设备WebSocket连接建立	info	\N	\N	\N
374	123456	\N	2026-06-25 23:32:50	online	设备WebSocket连接建立	info	\N	\N	\N
375	123456	\N	2026-06-25 23:33:24	online	设备WebSocket连接建立	info	\N	\N	\N
376	123456	\N	2026-06-25 23:38:10	offline	设备WebSocket断开连接	warning	\N	\N	\N
377	101002	\N	2026-06-26 00:29:54	online	设备WebSocket连接建立	info	\N	\N	\N
378	101002	\N	2026-06-26 00:31:09	online	设备WebSocket连接建立	info	\N	\N	\N
379	101002	\N	2026-06-26 00:44:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
380	123456	\N	2026-06-26 00:45:03	online	设备WebSocket连接建立	info	\N	\N	\N
381	123456	\N	2026-06-26 01:26:53	offline	设备WebSocket断开连接	warning	\N	\N	\N
382	123456	\N	2026-06-26 01:26:54	online	设备WebSocket连接建立	info	\N	\N	\N
383	123456	\N	2026-06-26 01:29:18	offline	设备WebSocket断开连接	warning	\N	\N	\N
384	123456	\N	2026-06-26 01:29:18	online	设备WebSocket连接建立	info	\N	\N	\N
385	123456	\N	2026-06-26 01:34:58	online	设备WebSocket连接建立	info	\N	\N	\N
386	123456	\N	2026-06-26 01:39:41	online	设备WebSocket连接建立	info	\N	\N	\N
387	123456	\N	2026-06-26 01:41:54	offline	设备WebSocket断开连接	warning	\N	\N	\N
388	123456	\N	2026-06-26 01:41:55	online	设备WebSocket连接建立	info	\N	\N	\N
389	123456	\N	2026-06-26 01:45:19	offline	设备WebSocket断开连接	warning	\N	\N	\N
390	123456	\N	2026-06-26 01:45:21	online	设备WebSocket连接建立	info	\N	\N	\N
391	123456	\N	2026-06-26 01:46:02	offline	设备WebSocket断开连接	warning	\N	\N	\N
392	123456	\N	2026-06-26 01:46:03	online	设备WebSocket连接建立	info	\N	\N	\N
393	123456	\N	2026-06-26 01:48:22	offline	设备WebSocket断开连接	warning	\N	\N	\N
394	123456	\N	2026-06-26 01:48:22	online	设备WebSocket连接建立	info	\N	\N	\N
395	123456	\N	2026-06-26 01:51:09	online	设备WebSocket连接建立	info	\N	\N	\N
396	123456	\N	2026-06-26 01:51:25	online	设备WebSocket连接建立	info	\N	\N	\N
397	123456	\N	2026-06-26 01:51:30	online	设备WebSocket连接建立	info	\N	\N	\N
398	123456	\N	2026-06-26 01:55:34	online	设备WebSocket连接建立	info	\N	\N	\N
399	123456	\N	2026-06-26 01:56:50	offline	设备WebSocket断开连接	warning	\N	\N	\N
400	123456	\N	2026-06-26 01:56:52	online	设备WebSocket连接建立	info	\N	\N	\N
401	123456	\N	2026-06-26 01:58:38	offline	设备WebSocket断开连接	warning	\N	\N	\N
402	123456	\N	2026-06-26 01:58:40	online	设备WebSocket连接建立	info	\N	\N	\N
403	123456	\N	2026-06-26 02:05:41	online	设备WebSocket连接建立	info	\N	\N	\N
404	123456	\N	2026-06-26 02:25:38	online	设备WebSocket连接建立	info	\N	\N	\N
405	123456	\N	2026-06-26 02:30:23	online	设备WebSocket连接建立	info	\N	\N	\N
406	123456	\N	2026-06-26 02:30:46	online	设备WebSocket连接建立	info	\N	\N	\N
407	123456	\N	2026-06-26 02:34:03	online	设备WebSocket连接建立	info	\N	\N	\N
408	123456	\N	2026-06-26 02:51:14	online	设备WebSocket连接建立	info	\N	\N	\N
409	123456	\N	2026-06-26 02:55:39	offline	设备WebSocket断开连接	warning	\N	\N	\N
410	123456	\N	2026-06-26 02:55:39	online	设备WebSocket连接建立	info	\N	\N	\N
411	123456	\N	2026-06-26 03:06:51	offline	设备WebSocket断开连接	warning	\N	\N	\N
412	123456	\N	2026-06-26 03:06:53	online	设备WebSocket连接建立	info	\N	\N	\N
413	123456	\N	2026-06-26 03:13:48	offline	设备WebSocket断开连接	warning	\N	\N	\N
414	123456	\N	2026-06-26 03:13:55	online	设备WebSocket连接建立	info	\N	\N	\N
415	123456	\N	2026-06-26 03:22:12	offline	设备WebSocket断开连接	warning	\N	\N	\N
416	123456	\N	2026-06-26 03:22:14	online	设备WebSocket连接建立	info	\N	\N	\N
417	123456	\N	2026-06-26 03:23:40	offline	设备WebSocket断开连接	warning	\N	\N	\N
418	123456	\N	2026-06-26 03:23:41	online	设备WebSocket连接建立	info	\N	\N	\N
419	123456	\N	2026-06-26 03:36:30	offline	设备WebSocket断开连接	warning	\N	\N	\N
420	123456	\N	2026-06-26 03:36:32	online	设备WebSocket连接建立	info	\N	\N	\N
421	123456	\N	2026-06-26 03:50:19	offline	设备WebSocket断开连接	warning	\N	\N	\N
422	123456	\N	2026-06-26 03:59:10	online	设备WebSocket连接建立	info	\N	\N	\N
423	123456	\N	2026-06-26 03:59:23	offline	设备WebSocket断开连接	warning	\N	\N	\N
424	123456	\N	2026-06-26 03:59:32	online	设备WebSocket连接建立	info	\N	\N	\N
425	123456	\N	2026-06-26 04:01:02	offline	设备WebSocket断开连接	warning	\N	\N	\N
426	123456	\N	2026-06-26 04:01:03	online	设备WebSocket连接建立	info	\N	\N	\N
427	123456	\N	2026-06-26 04:08:19	online	设备WebSocket连接建立	info	\N	\N	\N
428	123456	\N	2026-06-26 04:19:42	online	设备WebSocket连接建立	info	\N	\N	\N
429	123456	\N	2026-06-26 04:26:10	online	设备WebSocket连接建立	info	\N	\N	\N
430	123456	\N	2026-06-26 04:33:08	online	设备WebSocket连接建立	info	\N	\N	\N
431	123456	\N	2026-06-26 04:36:15	offline	设备WebSocket断开连接	warning	\N	\N	\N
432	123456	\N	2026-06-26 04:36:20	online	设备WebSocket连接建立	info	\N	\N	\N
433	123456	\N	2026-06-26 04:38:19	offline	设备WebSocket断开连接	warning	\N	\N	\N
434	123456	\N	2026-06-26 04:40:49	online	设备WebSocket连接建立	info	\N	\N	\N
435	123456	\N	2026-06-26 04:46:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
436	123456	\N	2026-06-26 04:48:01	online	设备WebSocket连接建立	info	\N	\N	\N
437	123456	\N	2026-06-26 04:48:33	offline	设备WebSocket断开连接	warning	\N	\N	\N
438	123456	\N	2026-06-26 04:55:18	online	设备WebSocket连接建立	info	\N	\N	\N
439	123456	\N	2026-06-26 05:07:19	online	设备WebSocket连接建立	info	\N	\N	\N
440	123456	\N	2026-06-26 05:17:17	online	设备WebSocket连接建立	info	\N	\N	\N
441	123456	\N	2026-06-26 05:17:18	online	设备WebSocket连接建立	info	\N	\N	\N
442	123456	\N	2026-06-26 05:17:18	offline	设备WebSocket断开连接	warning	\N	\N	\N
443	123456	\N	2026-06-26 05:17:20	online	设备WebSocket连接建立	info	\N	\N	\N
444	123456	\N	2026-06-26 05:18:10	online	设备WebSocket连接建立	info	\N	\N	\N
445	123456	\N	2026-06-26 05:24:12	online	设备WebSocket连接建立	info	\N	\N	\N
446	123456	\N	2026-06-26 05:26:31	online	设备WebSocket连接建立	info	\N	\N	\N
447	123456	\N	2026-06-26 05:35:19	online	设备WebSocket连接建立	info	\N	\N	\N
448	123456	\N	2026-06-26 05:46:57	online	设备WebSocket连接建立	info	\N	\N	\N
449	123456	\N	2026-06-26 05:51:16	online	设备WebSocket连接建立	info	\N	\N	\N
450	123456	\N	2026-06-26 05:54:34	online	设备WebSocket连接建立	info	\N	\N	\N
451	123456	\N	2026-06-26 05:59:08	online	设备WebSocket连接建立	info	\N	\N	\N
452	123456	\N	2026-06-26 06:24:06	offline	设备WebSocket断开连接	warning	\N	\N	\N
453	100100	\N	2026-06-26 06:41:10	online	设备WebSocket连接建立	info	\N	\N	\N
454	100100	\N	2026-06-26 06:41:12	online	设备WebSocket连接建立	info	\N	\N	\N
455	100100	\N	2026-06-26 06:41:14	online	设备WebSocket连接建立	info	\N	\N	\N
456	100100	\N	2026-06-26 06:41:15	online	设备WebSocket连接建立	info	\N	\N	\N
457	100100	\N	2026-06-26 06:41:58	online	设备WebSocket连接建立	info	\N	\N	\N
458	100100	\N	2026-06-26 06:42:30	online	设备WebSocket连接建立	info	\N	\N	\N
459	100100	\N	2026-06-26 06:43:17	online	设备WebSocket连接建立	info	\N	\N	\N
460	100100	\N	2026-06-26 06:44:06	online	设备WebSocket连接建立	info	\N	\N	\N
461	100100	\N	2026-06-26 06:47:44	online	设备WebSocket连接建立	info	\N	\N	\N
462	100100	\N	2026-06-26 06:51:35	online	设备WebSocket连接建立	info	\N	\N	\N
463	100100	\N	2026-06-26 06:55:46	online	设备WebSocket连接建立	info	\N	\N	\N
464	100100	\N	2026-06-26 06:57:35	online	设备WebSocket连接建立	info	\N	\N	\N
465	100100	\N	2026-06-26 07:02:02	online	设备WebSocket连接建立	info	\N	\N	\N
466	100100	\N	2026-06-26 07:05:15	online	设备WebSocket连接建立	info	\N	\N	\N
467	100100	\N	2026-06-26 07:08:28	online	设备WebSocket连接建立	info	\N	\N	\N
468	100100	\N	2026-06-26 07:15:01	online	设备WebSocket连接建立	info	\N	\N	\N
469	100100	\N	2026-06-26 07:17:59	offline	设备WebSocket断开连接	warning	\N	\N	\N
470	100100	\N	2026-06-26 07:17:59	online	设备WebSocket连接建立	info	\N	\N	\N
471	100100	\N	2026-06-26 07:24:50	online	设备WebSocket连接建立	info	\N	\N	\N
472	100100	\N	2026-06-26 07:25:47	online	设备WebSocket连接建立	info	\N	\N	\N
473	100100	\N	2026-06-26 07:28:33	online	设备WebSocket连接建立	info	\N	\N	\N
474	100100	\N	2026-06-26 07:38:58	online	设备WebSocket连接建立	info	\N	\N	\N
475	100100	\N	2026-06-26 07:42:01	offline	设备WebSocket断开连接	warning	\N	\N	\N
476	100100	\N	2026-06-26 07:42:02	online	设备WebSocket连接建立	info	\N	\N	\N
477	100100	\N	2026-06-26 07:46:05	online	设备WebSocket连接建立	info	\N	\N	\N
478	100100	\N	2026-06-26 07:49:09	offline	设备WebSocket断开连接	warning	\N	\N	\N
479	100100	\N	2026-06-26 07:49:15	online	设备WebSocket连接建立	info	\N	\N	\N
480	100100	\N	2026-06-26 07:52:38	online	设备WebSocket连接建立	info	\N	\N	\N
481	100100	\N	2026-06-26 07:56:20	online	设备WebSocket连接建立	info	\N	\N	\N
482	100100	\N	2026-06-26 08:00:06	online	设备WebSocket连接建立	info	\N	\N	\N
483	100100	\N	2026-06-26 08:01:13	online	设备WebSocket连接建立	info	\N	\N	\N
484	100100	\N	2026-06-26 08:03:46	online	设备WebSocket连接建立	info	\N	\N	\N
485	100100	\N	2026-06-26 08:03:56	online	设备WebSocket连接建立	info	\N	\N	\N
486	100100	\N	2026-06-26 08:06:10	online	设备WebSocket连接建立	info	\N	\N	\N
487	100100	\N	2026-06-26 08:07:59	online	设备WebSocket连接建立	info	\N	\N	\N
488	100100	\N	2026-06-26 08:11:00	online	设备WebSocket连接建立	info	\N	\N	\N
489	100100	\N	2026-06-26 08:11:38	online	设备WebSocket连接建立	info	\N	\N	\N
490	test_main_app	\N	2026-06-27 07:07:00.301678	online	设备WebSocket连接建立	info	\N	\N	\N
491	test_main_app	\N	2026-06-27 07:07:03.253405	offline	设备WebSocket断开连接	warning	\N	\N	\N
492	100100	\N	2026-06-27 07:07:49.920075	online	设备WebSocket连接建立	info	\N	\N	\N
493	100100	\N	2026-06-27 07:07:49.994632	online	设备WebSocket连接建立	info	\N	\N	\N
494	100100	\N	2026-06-27 07:07:59.849589	offline	设备WebSocket断开连接	warning	\N	\N	\N
495	test_direct	\N	2026-06-27 07:08:15.618189	offline	设备WebSocket断开连接	warning	\N	\N	\N
496	test_nginx	\N	2026-06-27 07:08:18.584824	offline	设备WebSocket断开连接	warning	\N	\N	\N
497	test_nohost	\N	2026-06-27 07:08:21.604902	offline	设备WebSocket断开连接	warning	\N	\N	\N
498	test_recheck	\N	2026-06-27 07:08:53.415112	offline	设备WebSocket断开连接	warning	\N	\N	\N
499	test_py_direct	\N	2026-06-27 07:09:09.187288	online	设备WebSocket连接建立	info	\N	\N	\N
500	test_py_direct	\N	2026-06-27 07:09:09.31354	offline	设备WebSocket断开连接	warning	\N	\N	\N
501	test_single_host	\N	2026-06-27 07:09:30.583827	offline	设备WebSocket断开连接	warning	\N	\N	\N
502	test_default_host	\N	2026-06-27 07:09:32.608764	offline	设备WebSocket断开连接	warning	\N	\N	\N
503	100100	\N	2026-06-27 07:11:25.496255	online	设备WebSocket连接建立	info	\N	\N	\N
504	100100	\N	2026-06-27 07:11:30.823681	offline	设备WebSocket断开连接	warning	\N	\N	\N
505	100100	\N	2026-06-27 07:11:32.630952	online	设备WebSocket连接建立	info	\N	\N	\N
506	100100	\N	2026-06-27 07:11:43.019813	offline	设备WebSocket断开连接	warning	\N	\N	\N
507	100100	\N	2026-06-27 07:11:47.552613	online	设备WebSocket连接建立	info	\N	\N	\N
508	100100	\N	2026-06-27 07:11:48.766999	offline	设备WebSocket断开连接	warning	\N	\N	\N
509	100100	\N	2026-06-27 07:13:38.830143	online	设备WebSocket连接建立	info	\N	\N	\N
510	100100	\N	2026-06-27 07:13:49.356182	offline	设备WebSocket断开连接	warning	\N	\N	\N
511	100100	\N	2026-06-27 07:13:49.948043	online	设备WebSocket连接建立	info	\N	\N	\N
512	100100	\N	2026-06-27 07:14:00.59405	offline	设备WebSocket断开连接	warning	\N	\N	\N
513	100100	\N	2026-06-27 07:14:05.351706	online	设备WebSocket连接建立	info	\N	\N	\N
514	100100	\N	2026-06-27 07:14:15.786697	offline	设备WebSocket断开连接	warning	\N	\N	\N
515	100100	\N	2026-06-27 07:14:34.229846	online	设备WebSocket连接建立	info	\N	\N	\N
516	100100	\N	2026-06-27 07:14:42.735172	offline	设备WebSocket断开连接	warning	\N	\N	\N
517	100100	\N	2026-06-27 07:15:02.45812	online	设备WebSocket连接建立	info	\N	\N	\N
518	100100	\N	2026-06-27 07:15:02.532131	online	设备WebSocket连接建立	info	\N	\N	\N
519	100100	\N	2026-06-27 07:15:07.316551	offline	设备WebSocket断开连接	warning	\N	\N	\N
520	100100	\N	2026-06-27 07:16:17.096168	online	设备WebSocket连接建立	info	\N	\N	\N
521	100100	\N	2026-06-27 07:16:27.177086	offline	设备WebSocket断开连接	warning	\N	\N	\N
522	100100	\N	2026-06-27 07:16:28.015272	online	设备WebSocket连接建立	info	\N	\N	\N
523	100100	\N	2026-06-27 07:16:28.089357	online	设备WebSocket连接建立	info	\N	\N	\N
524	100100	\N	2026-06-27 07:16:29.27177	online	设备WebSocket连接建立	info	\N	\N	\N
525	100100	\N	2026-06-27 07:16:38.069109	offline	设备WebSocket断开连接	warning	\N	\N	\N
526	100100	\N	2026-06-27 07:16:42.937619	online	设备WebSocket连接建立	info	\N	\N	\N
527	100100	\N	2026-06-27 07:16:53.29388	offline	设备WebSocket断开连接	warning	\N	\N	\N
528	100100	\N	2026-06-27 07:19:14.059323	online	设备WebSocket连接建立	info	\N	\N	\N
529	100100	\N	2026-06-27 07:19:15.714929	offline	设备WebSocket断开连接	warning	\N	\N	\N
530	100100	\N	2026-06-27 07:19:17.346032	online	设备WebSocket连接建立	info	\N	\N	\N
531	100100	\N	2026-06-27 07:19:27.60143	offline	设备WebSocket断开连接	warning	\N	\N	\N
532	100100	\N	2026-06-27 07:21:01.920009	online	设备WebSocket连接建立	info	\N	\N	\N
533	100100	\N	2026-06-27 07:21:06.695338	offline	设备WebSocket断开连接	warning	\N	\N	\N
534	100100	\N	2026-06-27 07:21:25.655849	online	设备WebSocket连接建立	info	\N	\N	\N
535	100100	\N	2026-06-27 07:21:35.819822	offline	设备WebSocket断开连接	warning	\N	\N	\N
536	100100	\N	2026-06-27 07:21:37.678149	online	设备WebSocket连接建立	info	\N	\N	\N
537	100100	\N	2026-06-27 07:21:38.454401	offline	设备WebSocket断开连接	warning	\N	\N	\N
538	100100	\N	2026-06-27 07:26:32.61367	online	设备WebSocket连接建立	info	\N	\N	\N
539	100100	\N	2026-06-27 07:26:42.936555	offline	设备WebSocket断开连接	warning	\N	\N	\N
540	100100	\N	2026-06-27 07:26:43.482596	online	设备WebSocket连接建立	info	\N	\N	\N
541	100100	\N	2026-06-27 07:26:53.586738	offline	设备WebSocket断开连接	warning	\N	\N	\N
542	100100	\N	2026-06-27 07:27:06.28456	online	设备WebSocket连接建立	info	\N	\N	\N
543	100100	\N	2026-06-27 07:27:16.960721	offline	设备WebSocket断开连接	warning	\N	\N	\N
544	100100	\N	2026-06-27 07:27:17.768058	online	设备WebSocket连接建立	info	\N	\N	\N
545	100100	\N	2026-06-27 07:27:17.848826	online	设备WebSocket连接建立	info	\N	\N	\N
546	100100	\N	2026-06-27 07:27:19.09849	online	设备WebSocket连接建立	info	\N	\N	\N
547	100100	\N	2026-06-27 07:27:20.404738	online	设备WebSocket连接建立	info	\N	\N	\N
548	100100	\N	2026-06-27 07:27:21.689969	online	设备WebSocket连接建立	info	\N	\N	\N
549	100100	\N	2026-06-27 07:27:27.819089	offline	设备WebSocket断开连接	warning	\N	\N	\N
550	100100	\N	2026-06-27 07:27:28.464966	online	设备WebSocket连接建立	info	\N	\N	\N
551	100100	\N	2026-06-27 07:27:38.902357	offline	设备WebSocket断开连接	warning	\N	\N	\N
552	100100	\N	2026-06-27 07:32:13.325294	online	设备WebSocket连接建立	info	\N	\N	\N
553	100100	\N	2026-06-27 07:37:28.570649	online	设备WebSocket连接建立	info	\N	\N	\N
554	100100	\N	2026-06-27 07:38:14.398408	online	设备WebSocket连接建立	info	\N	\N	\N
555	100100	\N	2026-06-27 07:39:48.077537	online	设备WebSocket连接建立	info	\N	\N	\N
556	100100	\N	2026-06-27 07:39:48.14737	online	设备WebSocket连接建立	info	\N	\N	\N
557	100100	\N	2026-06-27 07:39:53.312521	offline	设备WebSocket断开连接	warning	\N	\N	\N
558	100100	\N	2026-06-27 07:39:54.986883	online	设备WebSocket连接建立	info	\N	\N	\N
559	100100	\N	2026-06-27 07:39:55.058792	online	设备WebSocket连接建立	info	\N	\N	\N
560	100100	\N	2026-06-27 07:41:03.477678	offline	设备WebSocket断开连接	warning	\N	\N	\N
561	100100	\N	2026-06-27 07:46:23.52377	online	设备WebSocket连接建立	info	\N	\N	\N
562	100100	\N	2026-06-27 07:46:23.598796	online	设备WebSocket连接建立	info	\N	\N	\N
563	100100	\N	2026-06-27 07:47:59.775198	online	设备WebSocket连接建立	info	\N	\N	\N
564	100100	\N	2026-06-27 07:47:59.847962	online	设备WebSocket连接建立	info	\N	\N	\N
565	100100	\N	2026-06-27 07:48:42.627695	online	设备WebSocket连接建立	info	\N	\N	\N
566	100100	\N	2026-06-27 07:48:42.911862	online	设备WebSocket连接建立	info	\N	\N	\N
567	100100	\N	2026-06-27 07:49:40.670145	online	设备WebSocket连接建立	info	\N	\N	\N
568	100100	\N	2026-06-27 07:49:40.84826	online	设备WebSocket连接建立	info	\N	\N	\N
569	100100	\N	2026-06-27 07:50:23.530853	online	设备WebSocket连接建立	info	\N	\N	\N
570	100100	\N	2026-06-27 07:50:23.602611	online	设备WebSocket连接建立	info	\N	\N	\N
571	100100	\N	2026-06-27 07:51:13.694582	offline	设备WebSocket断开连接	warning	\N	\N	\N
572	100100	\N	2026-06-27 07:51:15.346679	online	设备WebSocket连接建立	info	\N	\N	\N
573	100100	\N	2026-06-27 07:51:15.418615	online	设备WebSocket连接建立	info	\N	\N	\N
574	100100	\N	2026-06-27 08:01:57.496137	online	设备WebSocket连接建立	info	\N	\N	\N
575	100100	\N	2026-06-27 08:01:57.699739	online	设备WebSocket连接建立	info	\N	\N	\N
576	100100	\N	2026-06-27 08:01:57.841181	online	设备WebSocket连接建立	info	\N	\N	\N
577	100100	\N	2026-06-27 08:01:58.0048	online	设备WebSocket连接建立	info	\N	\N	\N
578	100100	\N	2026-06-27 08:01:58.141504	online	设备WebSocket连接建立	info	\N	\N	\N
579	100100	\N	2026-06-27 08:01:58.255142	online	设备WebSocket连接建立	info	\N	\N	\N
580	100100	\N	2026-06-27 08:01:58.365135	online	设备WebSocket连接建立	info	\N	\N	\N
581	100100	\N	2026-06-27 08:01:58.468565	online	设备WebSocket连接建立	info	\N	\N	\N
582	100100	\N	2026-06-27 08:01:58.591619	online	设备WebSocket连接建立	info	\N	\N	\N
583	100100	\N	2026-06-27 08:01:58.694783	online	设备WebSocket连接建立	info	\N	\N	\N
584	100100	\N	2026-06-27 08:01:58.773445	online	设备WebSocket连接建立	info	\N	\N	\N
585	100100	\N	2026-06-27 08:01:58.854365	online	设备WebSocket连接建立	info	\N	\N	\N
586	100100	\N	2026-06-27 08:01:58.936643	online	设备WebSocket连接建立	info	\N	\N	\N
587	100100	\N	2026-06-27 08:01:59.025577	online	设备WebSocket连接建立	info	\N	\N	\N
588	100100	\N	2026-06-27 08:01:59.139865	online	设备WebSocket连接建立	info	\N	\N	\N
589	100100	\N	2026-06-27 08:01:59.267478	online	设备WebSocket连接建立	info	\N	\N	\N
590	100100	\N	2026-06-27 08:01:59.370057	online	设备WebSocket连接建立	info	\N	\N	\N
591	100100	\N	2026-06-27 08:01:59.474922	online	设备WebSocket连接建立	info	\N	\N	\N
592	100100	\N	2026-06-27 08:01:59.600359	online	设备WebSocket连接建立	info	\N	\N	\N
593	100100	\N	2026-06-27 08:01:59.706794	online	设备WebSocket连接建立	info	\N	\N	\N
594	100100	\N	2026-06-27 08:01:59.848186	online	设备WebSocket连接建立	info	\N	\N	\N
595	100100	\N	2026-06-27 08:01:59.984033	online	设备WebSocket连接建立	info	\N	\N	\N
596	100100	\N	2026-06-27 08:02:00.100096	online	设备WebSocket连接建立	info	\N	\N	\N
597	100100	\N	2026-06-27 08:02:00.281605	online	设备WebSocket连接建立	info	\N	\N	\N
598	100100	\N	2026-06-27 08:02:00.404908	online	设备WebSocket连接建立	info	\N	\N	\N
599	100100	\N	2026-06-27 08:02:00.567731	online	设备WebSocket连接建立	info	\N	\N	\N
600	100100	\N	2026-06-27 08:02:00.677776	online	设备WebSocket连接建立	info	\N	\N	\N
601	100100	\N	2026-06-27 08:02:00.785178	online	设备WebSocket连接建立	info	\N	\N	\N
602	100100	\N	2026-06-27 08:02:00.904658	online	设备WebSocket连接建立	info	\N	\N	\N
603	100100	\N	2026-06-27 08:02:01.139699	online	设备WebSocket连接建立	info	\N	\N	\N
604	100100	\N	2026-06-27 08:02:01.268646	online	设备WebSocket连接建立	info	\N	\N	\N
605	100100	\N	2026-06-27 08:02:01.391763	online	设备WebSocket连接建立	info	\N	\N	\N
606	100100	\N	2026-06-27 08:02:01.520832	online	设备WebSocket连接建立	info	\N	\N	\N
607	100100	\N	2026-06-27 08:02:01.713331	online	设备WebSocket连接建立	info	\N	\N	\N
608	100100	\N	2026-06-27 08:02:01.877701	online	设备WebSocket连接建立	info	\N	\N	\N
609	100100	\N	2026-06-27 08:02:01.987966	online	设备WebSocket连接建立	info	\N	\N	\N
610	100100	\N	2026-06-27 08:02:02.099473	online	设备WebSocket连接建立	info	\N	\N	\N
611	100100	\N	2026-06-27 08:02:02.22473	online	设备WebSocket连接建立	info	\N	\N	\N
612	100100	\N	2026-06-27 08:02:02.358641	online	设备WebSocket连接建立	info	\N	\N	\N
613	100100	\N	2026-06-27 08:02:02.505784	online	设备WebSocket连接建立	info	\N	\N	\N
614	100100	\N	2026-06-27 08:02:02.631772	online	设备WebSocket连接建立	info	\N	\N	\N
615	100100	\N	2026-06-27 08:02:02.735229	online	设备WebSocket连接建立	info	\N	\N	\N
616	100100	\N	2026-06-27 08:02:02.909846	online	设备WebSocket连接建立	info	\N	\N	\N
617	100100	\N	2026-06-27 08:02:03.100049	online	设备WebSocket连接建立	info	\N	\N	\N
618	100100	\N	2026-06-27 08:02:03.259716	online	设备WebSocket连接建立	info	\N	\N	\N
619	100100	\N	2026-06-27 08:02:03.371661	online	设备WebSocket连接建立	info	\N	\N	\N
620	100100	\N	2026-06-27 08:02:03.503362	online	设备WebSocket连接建立	info	\N	\N	\N
621	100100	\N	2026-06-27 08:02:03.614068	online	设备WebSocket连接建立	info	\N	\N	\N
622	100100	\N	2026-06-27 08:02:03.742594	online	设备WebSocket连接建立	info	\N	\N	\N
623	100100	\N	2026-06-27 08:02:03.849478	online	设备WebSocket连接建立	info	\N	\N	\N
624	100100	\N	2026-06-27 08:02:03.952519	online	设备WebSocket连接建立	info	\N	\N	\N
625	100100	\N	2026-06-27 08:02:04.067065	online	设备WebSocket连接建立	info	\N	\N	\N
626	100100	\N	2026-06-27 08:02:04.188167	online	设备WebSocket连接建立	info	\N	\N	\N
627	100100	\N	2026-06-27 08:02:04.311739	online	设备WebSocket连接建立	info	\N	\N	\N
628	100100	\N	2026-06-27 08:02:04.444432	online	设备WebSocket连接建立	info	\N	\N	\N
629	100100	\N	2026-06-27 08:02:04.575747	online	设备WebSocket连接建立	info	\N	\N	\N
630	100100	\N	2026-06-27 08:02:04.662168	online	设备WebSocket连接建立	info	\N	\N	\N
631	100100	\N	2026-06-27 08:02:04.773007	online	设备WebSocket连接建立	info	\N	\N	\N
632	100100	\N	2026-06-27 08:02:04.904869	online	设备WebSocket连接建立	info	\N	\N	\N
633	100100	\N	2026-06-27 08:02:05.035603	online	设备WebSocket连接建立	info	\N	\N	\N
634	100100	\N	2026-06-27 08:02:05.151722	online	设备WebSocket连接建立	info	\N	\N	\N
635	100100	\N	2026-06-27 08:02:05.261679	online	设备WebSocket连接建立	info	\N	\N	\N
636	100100	\N	2026-06-27 08:02:05.358955	online	设备WebSocket连接建立	info	\N	\N	\N
637	100100	\N	2026-06-27 08:02:05.456372	online	设备WebSocket连接建立	info	\N	\N	\N
638	100100	\N	2026-06-27 08:02:05.591032	online	设备WebSocket连接建立	info	\N	\N	\N
639	100100	\N	2026-06-27 08:02:05.706154	online	设备WebSocket连接建立	info	\N	\N	\N
640	100100	\N	2026-06-27 08:02:05.828754	online	设备WebSocket连接建立	info	\N	\N	\N
641	100100	\N	2026-06-27 08:02:05.969284	online	设备WebSocket连接建立	info	\N	\N	\N
642	100100	\N	2026-06-27 08:02:06.085176	online	设备WebSocket连接建立	info	\N	\N	\N
643	100100	\N	2026-06-27 08:02:06.203122	online	设备WebSocket连接建立	info	\N	\N	\N
644	100100	\N	2026-06-27 08:02:06.463728	online	设备WebSocket连接建立	info	\N	\N	\N
645	100100	\N	2026-06-27 08:02:06.556779	online	设备WebSocket连接建立	info	\N	\N	\N
646	100100	\N	2026-06-27 08:02:06.694292	online	设备WebSocket连接建立	info	\N	\N	\N
647	100100	\N	2026-06-27 08:02:06.820348	online	设备WebSocket连接建立	info	\N	\N	\N
648	100100	\N	2026-06-27 08:02:07.784928	online	设备WebSocket连接建立	info	\N	\N	\N
649	100100	\N	2026-06-27 08:02:07.863227	online	设备WebSocket连接建立	info	\N	\N	\N
650	100100	\N	2026-06-27 08:07:08.834843	offline	设备WebSocket断开连接	warning	\N	\N	\N
651	100100	\N	2026-06-27 08:09:52.223981	online	设备WebSocket连接建立	info	\N	\N	\N
652	100100	\N	2026-06-27 08:09:52.295145	online	设备WebSocket连接建立	info	\N	\N	\N
653	100100	\N	2026-06-27 08:23:35.30851	offline	设备WebSocket断开连接	warning	\N	\N	\N
654	100100	\N	2026-06-27 08:23:37.990941	online	设备WebSocket连接建立	info	\N	\N	\N
655	100100	\N	2026-06-27 08:23:38.155039	online	设备WebSocket连接建立	info	\N	\N	\N
656	100100	\N	2026-06-27 08:23:38.296156	online	设备WebSocket连接建立	info	\N	\N	\N
657	100100	\N	2026-06-27 08:23:38.454977	online	设备WebSocket连接建立	info	\N	\N	\N
658	100100	\N	2026-06-27 08:23:38.604012	online	设备WebSocket连接建立	info	\N	\N	\N
659	100100	\N	2026-06-27 08:23:38.815946	online	设备WebSocket连接建立	info	\N	\N	\N
660	100100	\N	2026-06-27 08:23:39.000675	online	设备WebSocket连接建立	info	\N	\N	\N
661	100100	\N	2026-06-27 08:23:39.174236	online	设备WebSocket连接建立	info	\N	\N	\N
662	100100	\N	2026-06-27 08:23:39.383758	online	设备WebSocket连接建立	info	\N	\N	\N
663	100100	\N	2026-06-27 08:23:39.489247	online	设备WebSocket连接建立	info	\N	\N	\N
664	100100	\N	2026-06-27 08:23:39.594399	online	设备WebSocket连接建立	info	\N	\N	\N
665	100100	\N	2026-06-27 08:23:39.7237	online	设备WebSocket连接建立	info	\N	\N	\N
666	100100	\N	2026-06-27 08:23:39.854101	online	设备WebSocket连接建立	info	\N	\N	\N
667	100100	\N	2026-06-27 08:23:39.977666	online	设备WebSocket连接建立	info	\N	\N	\N
668	100100	\N	2026-06-27 08:23:40.078705	online	设备WebSocket连接建立	info	\N	\N	\N
669	100100	\N	2026-06-27 08:23:40.331062	online	设备WebSocket连接建立	info	\N	\N	\N
670	100100	\N	2026-06-27 08:23:40.475743	online	设备WebSocket连接建立	info	\N	\N	\N
671	100100	\N	2026-06-27 08:23:40.602833	online	设备WebSocket连接建立	info	\N	\N	\N
672	100100	\N	2026-06-27 08:23:40.741812	online	设备WebSocket连接建立	info	\N	\N	\N
673	100100	\N	2026-06-27 08:23:40.836207	online	设备WebSocket连接建立	info	\N	\N	\N
674	100100	\N	2026-06-27 08:23:40.979722	online	设备WebSocket连接建立	info	\N	\N	\N
675	100100	\N	2026-06-27 08:23:41.095083	online	设备WebSocket连接建立	info	\N	\N	\N
676	100100	\N	2026-06-27 08:23:41.205933	online	设备WebSocket连接建立	info	\N	\N	\N
677	100100	\N	2026-06-27 08:23:41.344735	online	设备WebSocket连接建立	info	\N	\N	\N
678	100100	\N	2026-06-27 08:23:41.443333	online	设备WebSocket连接建立	info	\N	\N	\N
679	100100	\N	2026-06-27 08:23:41.553562	online	设备WebSocket连接建立	info	\N	\N	\N
680	100100	\N	2026-06-27 08:23:41.673768	online	设备WebSocket连接建立	info	\N	\N	\N
681	100100	\N	2026-06-27 08:23:41.77857	online	设备WebSocket连接建立	info	\N	\N	\N
682	100100	\N	2026-06-27 08:23:41.929595	online	设备WebSocket连接建立	info	\N	\N	\N
683	100100	\N	2026-06-27 08:23:42.050001	online	设备WebSocket连接建立	info	\N	\N	\N
684	100100	\N	2026-06-27 08:23:42.23466	online	设备WebSocket连接建立	info	\N	\N	\N
685	100100	\N	2026-06-27 08:23:42.399422	online	设备WebSocket连接建立	info	\N	\N	\N
686	100100	\N	2026-06-27 08:23:42.588765	online	设备WebSocket连接建立	info	\N	\N	\N
687	100100	\N	2026-06-27 08:23:42.723485	online	设备WebSocket连接建立	info	\N	\N	\N
688	100100	\N	2026-06-27 08:23:42.875494	online	设备WebSocket连接建立	info	\N	\N	\N
689	100100	\N	2026-06-27 08:23:42.995333	online	设备WebSocket连接建立	info	\N	\N	\N
690	100100	\N	2026-06-27 08:23:43.165802	online	设备WebSocket连接建立	info	\N	\N	\N
691	100100	\N	2026-06-27 08:23:43.318945	online	设备WebSocket连接建立	info	\N	\N	\N
692	100100	\N	2026-06-27 08:23:43.461646	online	设备WebSocket连接建立	info	\N	\N	\N
693	100100	\N	2026-06-27 08:23:43.594468	online	设备WebSocket连接建立	info	\N	\N	\N
694	100100	\N	2026-06-27 08:23:43.727414	online	设备WebSocket连接建立	info	\N	\N	\N
695	100100	\N	2026-06-27 08:23:43.868522	online	设备WebSocket连接建立	info	\N	\N	\N
696	100100	\N	2026-06-27 08:23:43.986802	online	设备WebSocket连接建立	info	\N	\N	\N
697	100100	\N	2026-06-27 08:23:44.133328	online	设备WebSocket连接建立	info	\N	\N	\N
698	100100	\N	2026-06-27 08:23:44.311219	online	设备WebSocket连接建立	info	\N	\N	\N
699	100100	\N	2026-06-27 08:23:44.395277	online	设备WebSocket连接建立	info	\N	\N	\N
700	100100	\N	2026-06-27 08:23:44.515819	online	设备WebSocket连接建立	info	\N	\N	\N
701	100100	\N	2026-06-27 08:23:44.630371	online	设备WebSocket连接建立	info	\N	\N	\N
702	100100	\N	2026-06-27 08:23:44.747498	online	设备WebSocket连接建立	info	\N	\N	\N
703	100100	\N	2026-06-27 08:23:44.851667	online	设备WebSocket连接建立	info	\N	\N	\N
704	100100	\N	2026-06-27 08:23:44.977214	online	设备WebSocket连接建立	info	\N	\N	\N
705	100100	\N	2026-06-27 08:23:45.11169	online	设备WebSocket连接建立	info	\N	\N	\N
706	100100	\N	2026-06-27 08:23:45.239682	online	设备WebSocket连接建立	info	\N	\N	\N
707	100100	\N	2026-06-27 08:23:45.365178	online	设备WebSocket连接建立	info	\N	\N	\N
708	100100	\N	2026-06-27 08:23:45.599694	online	设备WebSocket连接建立	info	\N	\N	\N
709	100100	\N	2026-06-27 08:23:45.720672	online	设备WebSocket连接建立	info	\N	\N	\N
710	100100	\N	2026-06-27 08:23:45.827951	online	设备WebSocket连接建立	info	\N	\N	\N
711	100100	\N	2026-06-27 08:23:45.943701	online	设备WebSocket连接建立	info	\N	\N	\N
712	100100	\N	2026-06-27 08:23:46.069777	online	设备WebSocket连接建立	info	\N	\N	\N
713	100100	\N	2026-06-27 08:23:46.195741	online	设备WebSocket连接建立	info	\N	\N	\N
714	100100	\N	2026-06-27 08:23:46.314834	online	设备WebSocket连接建立	info	\N	\N	\N
715	100100	\N	2026-06-27 08:23:46.451758	online	设备WebSocket连接建立	info	\N	\N	\N
716	100100	\N	2026-06-27 08:23:46.582143	online	设备WebSocket连接建立	info	\N	\N	\N
717	100100	\N	2026-06-27 08:23:46.723743	online	设备WebSocket连接建立	info	\N	\N	\N
718	100100	\N	2026-06-27 08:23:46.851217	online	设备WebSocket连接建立	info	\N	\N	\N
719	100100	\N	2026-06-27 08:23:46.970207	online	设备WebSocket连接建立	info	\N	\N	\N
720	100100	\N	2026-06-27 08:23:47.09319	online	设备WebSocket连接建立	info	\N	\N	\N
721	100100	\N	2026-06-27 08:23:47.22376	online	设备WebSocket连接建立	info	\N	\N	\N
722	100100	\N	2026-06-27 08:23:47.347102	online	设备WebSocket连接建立	info	\N	\N	\N
723	100100	\N	2026-06-27 08:23:47.475693	online	设备WebSocket连接建立	info	\N	\N	\N
724	100100	\N	2026-06-27 08:23:47.593158	online	设备WebSocket连接建立	info	\N	\N	\N
725	100100	\N	2026-06-27 08:23:47.710336	online	设备WebSocket连接建立	info	\N	\N	\N
726	100100	\N	2026-06-27 08:23:47.813769	online	设备WebSocket连接建立	info	\N	\N	\N
727	100100	\N	2026-06-27 08:23:47.947972	online	设备WebSocket连接建立	info	\N	\N	\N
728	100100	\N	2026-06-27 08:23:48.07837	online	设备WebSocket连接建立	info	\N	\N	\N
729	100100	\N	2026-06-27 08:23:48.182899	online	设备WebSocket连接建立	info	\N	\N	\N
730	100100	\N	2026-06-27 08:23:48.29439	online	设备WebSocket连接建立	info	\N	\N	\N
731	100100	\N	2026-06-27 08:23:48.412279	online	设备WebSocket连接建立	info	\N	\N	\N
732	100100	\N	2026-06-27 08:23:48.523964	online	设备WebSocket连接建立	info	\N	\N	\N
733	100100	\N	2026-06-27 08:23:48.639665	online	设备WebSocket连接建立	info	\N	\N	\N
734	100100	\N	2026-06-27 08:23:48.768833	online	设备WebSocket连接建立	info	\N	\N	\N
735	100100	\N	2026-06-27 08:23:48.883477	online	设备WebSocket连接建立	info	\N	\N	\N
736	100100	\N	2026-06-27 08:23:48.99725	online	设备WebSocket连接建立	info	\N	\N	\N
737	100100	\N	2026-06-27 08:23:49.107058	online	设备WebSocket连接建立	info	\N	\N	\N
738	100100	\N	2026-06-27 08:23:49.242252	online	设备WebSocket连接建立	info	\N	\N	\N
739	100100	\N	2026-06-27 08:23:49.378329	online	设备WebSocket连接建立	info	\N	\N	\N
740	100100	\N	2026-06-27 08:23:49.517968	online	设备WebSocket连接建立	info	\N	\N	\N
741	100100	\N	2026-06-27 08:23:49.640669	online	设备WebSocket连接建立	info	\N	\N	\N
742	100100	\N	2026-06-27 08:23:49.761056	online	设备WebSocket连接建立	info	\N	\N	\N
743	100100	\N	2026-06-27 08:23:49.883683	online	设备WebSocket连接建立	info	\N	\N	\N
744	100100	\N	2026-06-27 08:23:50.030942	online	设备WebSocket连接建立	info	\N	\N	\N
745	100100	\N	2026-06-27 08:23:50.134167	online	设备WebSocket连接建立	info	\N	\N	\N
746	100100	\N	2026-06-27 08:23:50.255726	online	设备WebSocket连接建立	info	\N	\N	\N
747	100100	\N	2026-06-27 08:23:50.383712	online	设备WebSocket连接建立	info	\N	\N	\N
748	100100	\N	2026-06-27 08:23:50.491078	online	设备WebSocket连接建立	info	\N	\N	\N
749	100100	\N	2026-06-27 08:23:50.582219	online	设备WebSocket连接建立	info	\N	\N	\N
750	100100	\N	2026-06-27 08:23:50.698163	online	设备WebSocket连接建立	info	\N	\N	\N
751	100100	\N	2026-06-27 08:23:50.967209	online	设备WebSocket连接建立	info	\N	\N	\N
752	100100	\N	2026-06-27 08:23:51.106618	online	设备WebSocket连接建立	info	\N	\N	\N
753	100100	\N	2026-06-27 08:23:51.271823	online	设备WebSocket连接建立	info	\N	\N	\N
754	100100	\N	2026-06-27 08:23:51.443791	online	设备WebSocket连接建立	info	\N	\N	\N
755	100100	\N	2026-06-27 08:23:51.632587	online	设备WebSocket连接建立	info	\N	\N	\N
756	100100	\N	2026-06-27 08:23:52.196388	online	设备WebSocket连接建立	info	\N	\N	\N
757	100100	\N	2026-06-27 08:23:52.335703	online	设备WebSocket连接建立	info	\N	\N	\N
758	100100	\N	2026-06-27 08:41:57.529524	online	设备WebSocket连接建立	info	\N	\N	\N
759	100100	\N	2026-06-27 08:41:57.610579	online	设备WebSocket连接建立	info	\N	\N	\N
760	100100	\N	2026-06-27 08:46:21.239845	online	设备WebSocket连接建立	info	\N	\N	\N
761	100100	\N	2026-06-27 08:46:21.312773	online	设备WebSocket连接建立	info	\N	\N	\N
762	100100	\N	2026-06-27 08:48:52.389343	online	设备WebSocket连接建立	info	\N	\N	\N
763	100100	\N	2026-06-27 08:48:52.462133	online	设备WebSocket连接建立	info	\N	\N	\N
764	100100	\N	2026-06-27 08:50:49.520522	online	设备WebSocket连接建立	info	\N	\N	\N
765	100100	\N	2026-06-27 08:50:49.698649	online	设备WebSocket连接建立	info	\N	\N	\N
766	100100	\N	2026-06-27 08:51:39.122688	offline	设备WebSocket断开连接	warning	\N	\N	\N
767	100100	\N	2026-06-27 08:52:00.421699	online	设备WebSocket连接建立	info	\N	\N	\N
768	100100	\N	2026-06-27 08:52:00.572863	online	设备WebSocket连接建立	info	\N	\N	\N
769	100100	\N	2026-06-27 08:52:00.738695	online	设备WebSocket连接建立	info	\N	\N	\N
770	100100	\N	2026-06-27 08:52:00.930374	online	设备WebSocket连接建立	info	\N	\N	\N
771	100100	\N	2026-06-27 08:52:01.098709	online	设备WebSocket连接建立	info	\N	\N	\N
772	100100	\N	2026-06-27 08:52:01.259235	online	设备WebSocket连接建立	info	\N	\N	\N
773	100100	\N	2026-06-27 08:52:01.400896	online	设备WebSocket连接建立	info	\N	\N	\N
774	100100	\N	2026-06-27 08:52:01.569248	online	设备WebSocket连接建立	info	\N	\N	\N
775	100100	\N	2026-06-27 08:52:01.702029	online	设备WebSocket连接建立	info	\N	\N	\N
776	100100	\N	2026-06-27 08:52:01.8887	online	设备WebSocket连接建立	info	\N	\N	\N
777	100100	\N	2026-06-27 08:52:02.064501	online	设备WebSocket连接建立	info	\N	\N	\N
778	100100	\N	2026-06-27 08:52:02.218369	online	设备WebSocket连接建立	info	\N	\N	\N
779	100100	\N	2026-06-27 08:52:02.398658	online	设备WebSocket连接建立	info	\N	\N	\N
780	100100	\N	2026-06-27 08:52:02.573291	online	设备WebSocket连接建立	info	\N	\N	\N
781	100100	\N	2026-06-27 08:52:02.718611	online	设备WebSocket连接建立	info	\N	\N	\N
782	100100	\N	2026-06-27 08:52:02.868915	online	设备WebSocket连接建立	info	\N	\N	\N
783	100100	\N	2026-06-27 08:52:03.020824	online	设备WebSocket连接建立	info	\N	\N	\N
784	100100	\N	2026-06-27 08:52:03.214655	online	设备WebSocket连接建立	info	\N	\N	\N
785	100100	\N	2026-06-27 08:52:03.402656	online	设备WebSocket连接建立	info	\N	\N	\N
786	100100	\N	2026-06-27 08:52:03.556352	online	设备WebSocket连接建立	info	\N	\N	\N
787	100100	\N	2026-06-27 08:52:03.722712	online	设备WebSocket连接建立	info	\N	\N	\N
788	100100	\N	2026-06-27 08:52:03.887234	online	设备WebSocket连接建立	info	\N	\N	\N
789	100100	\N	2026-06-27 08:52:04.054655	online	设备WebSocket连接建立	info	\N	\N	\N
790	100100	\N	2026-06-27 08:52:04.222654	online	设备WebSocket连接建立	info	\N	\N	\N
791	100100	\N	2026-06-27 08:52:04.39467	online	设备WebSocket连接建立	info	\N	\N	\N
792	100100	\N	2026-06-27 08:52:04.564901	online	设备WebSocket连接建立	info	\N	\N	\N
793	100100	\N	2026-06-27 08:52:05.664309	online	设备WebSocket连接建立	info	\N	\N	\N
794	100100	\N	2026-06-27 08:52:05.755919	online	设备WebSocket连接建立	info	\N	\N	\N
795	100100	\N	2026-06-27 08:55:00.951488	offline	设备WebSocket断开连接	warning	\N	\N	\N
796	100100	\N	2026-06-27 08:55:02.807762	online	设备WebSocket连接建立	info	\N	\N	\N
797	100100	\N	2026-06-27 08:55:02.87911	online	设备WebSocket连接建立	info	\N	\N	\N
798	100100	\N	2026-06-27 08:55:14.788586	offline	设备WebSocket断开连接	warning	\N	\N	\N
799	100100	\N	2026-06-27 08:55:21.554363	online	设备WebSocket连接建立	info	\N	\N	\N
800	100100	\N	2026-06-27 08:55:21.62645	online	设备WebSocket连接建立	info	\N	\N	\N
801	100100	\N	2026-06-27 09:04:03.863715	offline	设备WebSocket断开连接	warning	\N	\N	\N
802	100100	\N	2026-06-27 09:04:10.566687	online	设备WebSocket连接建立	info	\N	\N	\N
803	100100	\N	2026-06-27 09:04:10.635507	online	设备WebSocket连接建立	info	\N	\N	\N
804	100100	\N	2026-06-27 09:07:05.773296	online	设备WebSocket连接建立	info	\N	\N	\N
805	100100	\N	2026-06-27 09:07:05.842667	online	设备WebSocket连接建立	info	\N	\N	\N
806	100100	\N	2026-06-27 09:07:41.158637	online	设备WebSocket连接建立	info	\N	\N	\N
807	100100	\N	2026-06-27 09:07:41.328407	online	设备WebSocket连接建立	info	\N	\N	\N
808	100100	\N	2026-06-27 09:11:17.032884	online	设备WebSocket连接建立	info	\N	\N	\N
809	100100	\N	2026-06-27 09:11:17.106342	online	设备WebSocket连接建立	info	\N	\N	\N
810	100100	\N	2026-06-27 09:14:03.864547	online	设备WebSocket连接建立	info	\N	\N	\N
811	100100	\N	2026-06-27 09:14:03.977787	online	设备WebSocket连接建立	info	\N	\N	\N
812	100100	\N	2026-06-27 09:14:53.140792	offline	设备WebSocket断开连接	warning	\N	\N	\N
813	100100	\N	2026-06-27 09:14:59.153499	online	设备WebSocket连接建立	info	\N	\N	\N
814	100100	\N	2026-06-27 09:14:59.224784	online	设备WebSocket连接建立	info	\N	\N	\N
815	100100	\N	2026-06-27 09:15:41.822782	online	设备WebSocket连接建立	info	\N	\N	\N
816	100100	\N	2026-06-27 09:15:41.892461	online	设备WebSocket连接建立	info	\N	\N	\N
817	100100	\N	2026-06-27 09:16:17.888262	online	设备WebSocket连接建立	info	\N	\N	\N
818	100100	\N	2026-06-27 09:16:17.957712	online	设备WebSocket连接建立	info	\N	\N	\N
819	100100	\N	2026-06-27 09:16:46.536239	offline	设备WebSocket断开连接	warning	\N	\N	\N
820	100100	\N	2026-06-27 09:16:52.597931	online	设备WebSocket连接建立	info	\N	\N	\N
821	100100	\N	2026-06-27 09:16:52.667865	online	设备WebSocket连接建立	info	\N	\N	\N
822	100100	\N	2026-06-27 09:19:16.410604	online	设备WebSocket连接建立	info	\N	\N	\N
823	100100	\N	2026-06-27 09:19:16.480169	online	设备WebSocket连接建立	info	\N	\N	\N
824	100100	\N	2026-06-27 09:19:41.007387	online	设备WebSocket连接建立	info	\N	\N	\N
825	100100	\N	2026-06-27 09:19:41.077839	online	设备WebSocket连接建立	info	\N	\N	\N
826	100100	\N	2026-06-27 09:20:01.283109	online	设备WebSocket连接建立	info	\N	\N	\N
827	100100	\N	2026-06-27 09:20:01.520093	online	设备WebSocket连接建立	info	\N	\N	\N
828	100100	\N	2026-06-27 09:25:39.500852	offline	设备WebSocket断开连接	warning	\N	\N	\N
829	100100	\N	2026-06-27 09:28:44.856743	online	设备WebSocket连接建立	info	\N	\N	\N
830	100100	\N	2026-06-27 09:28:44.927084	online	设备WebSocket连接建立	info	\N	\N	\N
831	101002	\N	2026-06-27 09:30:03.054066	online	设备WebSocket连接建立	info	\N	\N	\N
832	101002	\N	2026-06-27 09:30:03.44534	online	设备WebSocket连接建立	info	\N	\N	\N
833	100100	\N	2026-06-27 09:30:40.527159	offline	设备WebSocket断开连接	warning	\N	\N	\N
834	101002	\N	2026-06-27 09:32:44.997691	online	设备WebSocket连接建立	info	\N	\N	\N
835	101002	\N	2026-06-27 09:32:45.072307	online	设备WebSocket连接建立	info	\N	\N	\N
836	101002	\N	2026-06-27 09:33:32.203307	offline	设备WebSocket断开连接	warning	\N	\N	\N
837	100100	\N	2026-06-27 09:34:28.374679	online	设备WebSocket连接建立	info	\N	\N	\N
838	100100	\N	2026-06-27 09:34:28.450571	online	设备WebSocket连接建立	info	\N	\N	\N
839	100100	\N	2026-06-27 09:35:08.435515	offline	设备WebSocket断开连接	warning	\N	\N	\N
840	100100	\N	2026-06-27 09:35:10.18376	online	设备WebSocket连接建立	info	\N	\N	\N
841	100100	\N	2026-06-27 09:35:10.254397	online	设备WebSocket连接建立	info	\N	\N	\N
842	100100	\N	2026-06-27 09:44:33.582762	online	设备WebSocket连接建立	info	\N	\N	\N
843	100100	\N	2026-06-27 09:44:33.655708	online	设备WebSocket连接建立	info	\N	\N	\N
844	100100	\N	2026-06-27 09:56:33.481557	online	设备WebSocket连接建立	info	\N	\N	\N
845	100100	\N	2026-06-27 09:56:33.588043	online	设备WebSocket连接建立	info	\N	\N	\N
846	100100	\N	2026-06-27 09:56:44.130368	offline	设备WebSocket断开连接	warning	\N	\N	\N
847	100100	\N	2026-06-27 09:56:50.38847	online	设备WebSocket连接建立	info	\N	\N	\N
848	100100	\N	2026-06-27 09:56:50.457702	online	设备WebSocket连接建立	info	\N	\N	\N
849	100100	\N	2026-06-27 10:00:36.551863	online	设备WebSocket连接建立	info	\N	\N	\N
850	100100	\N	2026-06-27 10:00:36.691174	online	设备WebSocket连接建立	info	\N	\N	\N
851	100100	\N	2026-06-27 10:03:17.237719	online	设备WebSocket连接建立	info	\N	\N	\N
852	100100	\N	2026-06-27 10:03:17.52969	online	设备WebSocket连接建立	info	\N	\N	\N
853	100100	\N	2026-06-27 10:24:58.993539	online	设备WebSocket连接建立	info	\N	\N	\N
854	100100	\N	2026-06-27 10:24:59.248373	online	设备WebSocket连接建立	info	\N	\N	\N
855	100100	\N	2026-06-27 10:43:23.957255	online	设备WebSocket连接建立	info	\N	\N	\N
856	100100	\N	2026-06-27 10:43:24.025221	online	设备WebSocket连接建立	info	\N	\N	\N
\.


--
-- Data for Name: device_update_logs; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.device_update_logs (id, device_id, success, version_name, version_code, error_msg, created_at) FROM stdin;
1	100101	0	1.2.43	163	download failed after 3 attempts	2026-06-29 17:59:25.384688
2	100101	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:21:43.110741
3	100100	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:21:43.671315
4	100100	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:22:44.324238
5	100101	0	1.2.42	162	download failed after 3 attempts	2026-06-29 18:23:23.750406
6	100100	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:25:05.308861
7	100101	0	1.2.44	164	download failed after 3 attempts	2026-06-29 18:28:23.887634
8	100100	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:28:58.940139
9	100101	1	1.2.44	164		2026-06-29 18:31:29.881512
10	100100	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:31:44.225639
11	100100	1	1.2.44	164		2026-06-29 18:33:30.472128
12	100100	1	1.2.45	165		2026-06-29 19:08:15.95283
13	100100	1	1.2.45	165		2026-06-29 19:12:33.485324
14	100100	1	1.2.45	165		2026-06-29 19:16:11.857288
15	100100	0	1.2.47	167	download failed after 3 attempts	2026-06-30 06:43:35.817405
16	100100	0	1.2.47	167	download failed after 3 attempts	2026-06-30 06:48:35.539134
17	100100	1	1.2.47	167		2026-06-30 06:49:15.911007
18	100100	1	1.2.47	167		2026-06-30 06:59:18.170105
19	100100	1	1.2.47	167		2026-06-30 07:04:29.70872
20	100100	1	1.2.48	168		2026-06-30 07:24:08.785417
21	100100	1	1.2.49	169		2026-06-30 07:41:15.22582
22	100101	1	1.2.49	169		2026-06-30 08:45:01.213992
23	100100	1	1.2.50	170		2026-06-30 09:27:38.310403
24	100101	1	1.2.50	170		2026-06-30 09:27:47.445625
25	100100	1	1.2.50	170		2026-06-30 18:35:21.09168
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.devices (id, device_id, device_name, device_type, status, remark, update_time) FROM stdin;
\.


--
-- Data for Name: door_query_cache; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.door_query_cache (request_id, device_id, board_no, lock_no, cabinet_id, is_open, door_status, query_success, created_at) FROM stdin;
\.


--
-- Data for Name: door_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.door_records (id, device_id, board_no, lock_no, order_id, open_type, create_time) FROM stdin;
1	TEST_DEVICE_001	1	1	1	remote	2026-06-17 09:19:40
2	DEV001	1	1	1	remote	2026-06-17 09:21:09
3	123456	1	5	test001	0	2026-06-17 20:35:12
4	123456	1	5	test001	0	2026-06-17 20:41:36
5	123456	0	0	\N	manual	2026-06-17 21:01:45
6	123456	0	0	\N	manual	2026-06-17 21:07:28
7	123456	0	0	\N	manual	2026-06-17 21:07:59
8	123456	0	0	\N	manual	2026-06-17 21:10:44
9	123456	1	10	\N	YBM	2026-06-24 03:44:42
10	123456	1	10	20260624114601985736	YBM	2026-06-24 03:46:09
11	123456	1	11	\N	YBM	2026-06-24 03:58:27
12	123456	1	10	20260624143247226180	YBM	2026-06-24 06:32:58
13	123456	1	10	196	YBM	2026-06-24 09:01:04
14	123456	1	10	196	YBM	2026-06-24 10:06:50
15	123456	1	1	\N	YBM	2026-06-24 10:07:01
16	123456	1	10	196	YBM	2026-06-24 10:07:52
17	123456	1	10	196	YBM	2026-06-24 12:09:09
18	123456	1	7	178	YBM	2026-06-24 12:18:03
19	123456	1	7	178	YBM	2026-06-24 12:20:52
20	123456	1	4	\N	YBM	2026-06-25 08:49:43
21	123456	1	12	269	YBM	2026-06-25 08:56:59
22	123456	2	1	\N	YBM	2026-06-25 09:42:12
23	123456	2	2	\N	YBM	2026-06-25 09:59:45
24	101002	2	17	278	YBM	2026-06-25 11:00:10
25	101002	2	17	278	YBM	2026-06-25 11:00:22
26	101002	2	17	278	YBM	2026-06-25 11:00:28
27	123456	2	18	277	YBM	2026-06-25 11:00:42
28	101002	1	1	\N	YBM	2026-06-25 11:21:09
29	101002	1	2	\N	YBM	2026-06-25 11:21:51
30	123456	2	21	283	YBM	2026-06-25 13:10:46
31	123456	2	22	284	YBM	2026-06-25 13:14:40
32	123456	2	22	284	YBM	2026-06-25 13:15:10
33	123456	2	22	284	YBM	2026-06-25 13:19:35
34	123456	2	22	284	YBM	2026-06-25 13:22:44
35	123456	2	22	284	YBM	2026-06-25 13:28:16
36	123456	2	22	284	YBM	2026-06-25 13:29:52
37	123456	2	21	283	YBM	2026-06-25 13:32:58
38	123456	2	21	283	YBM	2026-06-25 13:35:51
39	123456	1	A24	20260625214644063856	YBM	2026-06-25 13:50:24
40	101002	1	1	\N	YBM	2026-06-25 13:55:20
41	101002	1	1	\N	YBM	2026-06-25 13:57:27
42	101002	1	1	\N	YBM	2026-06-25 14:01:32
43	101002	1	1	\N	YBM	2026-06-25 14:01:33
44	101002	1	1	\N	YBM	2026-06-25 14:01:33
45	101002	1	1	\N	YBM	2026-06-25 14:01:42
46	101002	1	1	\N	YBM	2026-06-25 14:04:53
47	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
48	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
49	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
50	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
51	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
52	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
53	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
54	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
55	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
56	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
57	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
58	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
59	\N	1	1	\N	YBM	2026-06-25 14:14:33
60	123456	1	A29	20260625224205854601	YBM	2026-06-25 14:42:11
61	123456	1	A30	20260625224556086478	YBM	2026-06-25 14:46:02
62	123456	1	A30	20260625224556086478	YBM	2026-06-25 14:49:36
63	101002	1	1	\N	YBM	2026-06-25 14:50:04
64	101002	1	1	\N	YBM	2026-06-25 14:50:15
65	101002	1	1	\N	YBM	2026-06-25 14:50:39
66	101002	1	1	\N	YBM	2026-06-25 14:52:26
67	101002	1	1	\N	YBM	2026-06-25 14:52:32
68	101002	1	1	\N	YBM	2026-06-25 14:54:38
69	101002	1	1	\N	YBM	2026-06-25 14:54:46
70	101002	1	1	\N	YBM	2026-06-25 14:56:57
71	123456	1	A31	20260625230123439689	YBM	2026-06-25 15:01:31
72	123456	2	14	\N	YBM	2026-06-25 15:29:41
73	123456	1	A32	20260625233005853236	YBM	2026-06-25 15:30:11
74	123456	1	A33	20260625233407427886	YBM	2026-06-25 15:36:24
75	123456	1	A34	20260625234133881159	YBM	2026-06-25 15:41:41
76	123456	1	A34	20260625234133881159	YBM	2026-06-25 15:41:50
77	123456	1	A35	20260625234710366176	YBM	2026-06-25 15:47:15
78	123456	1	A35	20260625234710366176	YBM	2026-06-25 15:47:23
79	123456	1	A36	20260625234755209987	YBM	2026-06-25 15:48:02
80	123456	1	A36	20260625234755209987	YBM	2026-06-25 15:48:12
81	123456	1	A37	20260625235027193965	YBM	2026-06-25 15:50:39
82	123456	1	A38	20260625235218620187	YBM	2026-06-25 15:52:25
83	123456	1	A38	20260625235218620187	YBM	2026-06-25 15:52:35
84	123456	3	38	300	YBM	2026-06-25 22:27:51
85	123456	3	37	299	YBM	2026-06-25 22:27:56
86	123456	2	16	\N	YBM	2026-06-25 22:29:01
87	123456	3	1	\N	YBM	2026-06-25 22:29:17
88	123456	3	2	\N	YBM	2026-06-25 22:29:23
89	123456	3	3	\N	YBM	2026-06-25 22:29:27
90	123456	3	38	300	YBM	2026-06-25 22:29:40
91	123456	3	7	\N	YBM	2026-06-25 22:30:46
92	123456	3	6	\N	YBM	2026-06-25 22:30:50
93	123456	3	5	\N	YBM	2026-06-25 22:30:53
94	123456	3	16	\N	YBM	2026-06-25 22:31:51
95	123456	3	15	\N	YBM	2026-06-25 22:31:57
96	123456	3	16	\N	YBM	2026-06-25 22:32:00
97	123456	3	14	\N	YBM	2026-06-25 22:32:04
98	123456	3	7	\N	YBM	2026-06-25 22:39:13
99	123456	3	38	300	YBM	2026-06-25 22:57:09
100	123456	3	8	\N	YBM	2026-06-25 22:57:24
101	123456	3	38	300	YBM	2026-06-25 23:03:17
102	123456	3	8	\N	YBM	2026-06-25 23:11:40
103	123456	3	16	\N	YBM	2026-06-25 23:11:45
104	123456	3	38	300	YBM	2026-06-25 23:28:33
105	123456	3	8	\N	YBM	2026-06-25 23:36:02
106	101002	1	1	\N	YBM	2026-06-26 00:42:23
107	123456	1	1	\N	YBM	2026-06-26 00:47:02
108	123456	1	1	\N	YBM	2026-06-26 00:50:45
109	123456	3	12	20260626091635740650	YBM	2026-06-26 01:17:16
110	123456	3	12	20260626091635740650	YBM	2026-06-26 01:17:42
111	123456	1	1	\N	YBM	2026-06-26 01:34:58
112	123456	1	1	\N	YBM	2026-06-26 01:34:58
113	123456	1	1	\N	YBM	2026-06-26 01:34:58
114	123456	1	1	\N	YBM	2026-06-26 01:35:17
115	123456	1	3	\N	YBM	2026-06-26 01:35:20
116	123456	1	1	311	YBM	2026-06-26 01:35:37
117	123456	1	5	315	YBM	2026-06-26 01:49:04
118	123456	1	1	\N	YBM	2026-06-26 02:38:40
119	123456	1	5	315	YBM	2026-06-26 04:02:45
120	123456	1	6	316	YBM	2026-06-26 04:25:43
121	123456	1	6	316	YBM	2026-06-26 04:44:18
122	100100	1	1	\N	YBM	2026-06-26 06:42:11
123	100100	1	1	\N	YBM	2026-06-26 06:47:18
124	100100	1	1	\N	YBM	2026-06-26 07:02:50
125	100100	1	2	\N	YBM	2026-06-26 07:02:59
126	100100	1	1	\N	YBM	2026-06-26 07:42:26
127	100100	1	1	\N	YBM	2026-06-26 07:42:52
128	100100	1	1	\N	YBM	2026-06-26 07:42:54
129	100100	1	1	\N	YBM	2026-06-26 07:42:56
130	100100	1	1	\N	YBM	2026-06-26 07:42:58
131	100100	1	2	\N	YBM	2026-06-26 07:43:01
132	100100	2	14	\N	YBM	2026-06-26 07:43:04
133	100100	1	1	\N	YBM	2026-06-26 07:58:00
134	100100	1	1	\N	YBM	2026-06-26 07:58:02
135	100100	1	2	\N	YBM	2026-06-26 07:58:04
136	100100	2	6	20260626155413206167	YBM	2026-06-26 17:28:40.710572
137	100100	2	4	20260626152942192997	YBM	2026-06-26 17:34:14.772993
138	100100	2	22	332	YBM	2026-06-26 17:49:02.718622
139	100100	2	1		YBM	2026-06-26 18:00:47.295769
140	100100	2	2		YBM	2026-06-26 18:02:49.467996
141	100100	2	1		YBM	2026-06-26 18:03:04.705283
142	100100	2	1		YBM	2026-06-26 18:09:25.596607
143	100100	1	1		YBM	2026-06-26 19:31:03.002828
144	100100	2	1		YBM	2026-06-26 19:31:07.517309
145	100100	2	3		YBM	2026-06-26 19:47:07.679332
146	100100	2	3		YBM	2026-06-26 19:47:19.025095
147	100100	2	1		YBM	2026-06-26 19:51:55.631717
148	100100	1	13	20260626195241140324	YBM	2026-06-26 19:53:03.057647
149	100100	2	3		YBM	2026-06-26 19:54:39.222165
150	100100	1	15		YBM	2026-06-26 19:54:45.972923
151	100100	2	3		YBM	2026-06-26 19:54:50.09196
152	100100	1	1		YBM	2026-06-26 19:55:26.877275
153	100100	1	14	20260626203440517799	YBM	2026-06-26 20:35:02.323958
154	100100	2	15	20260626203849898493	YBM	2026-06-26 20:39:21.522362
155	100100	1	2	20260626211119806002	YBM	2026-06-26 21:11:38.372213
156	100100	1	3	20260626211337376195	YBM	2026-06-26 21:14:06.708637
157	100100	2	31	353	YBM	2026-06-27 06:34:58.789463
158	100100	1	3	359	YBM	2026-06-27 06:35:15.702873
159	100100	2	31	353	YBM	2026-06-27 06:35:29.634192
160	100100	1	1		YBM	2026-06-27 06:35:47.738114
161	100100	1	1		YBM	2026-06-27 06:36:00.46266
162	100100	1	3	359	YBM	2026-06-27 06:36:14.528238
163	100100	2	31	353	YBM	2026-06-27 06:54:21.404689
164	100100	1	14	352	YBM	2026-06-27 07:02:59.185218
165	100100	1	1		YBM	2026-06-27 07:07:46.902472
166	100100	1	1		YBM	2026-06-27 07:07:57.014345
167	100100	1	16		YBM	2026-06-27 07:08:03.732724
168	100100	1	2		YBM	2026-06-27 09:31:15.556471
169	100100	1	2		YBM	2026-06-27 09:34:43.595835
170	100100	1	1		YBM	2026-06-27 10:03:35.861388
171	100100	1	15		YBM	2026-06-27 10:03:41.127345
172	100100	2	3		YBM	2026-06-27 10:03:58.54928
173	100100	2	16		YBM	2026-06-27 10:04:08.616789
174	100100	3	10	20260627100422451091	YBM	2026-06-27 10:05:21.633816
175	101001	1	2		YBM	2026-06-27 11:17:24.079408
176	101001	1	2		YBM	2026-06-27 11:17:31.899584
177	101001	1	2		YBM	2026-06-27 11:17:51.953095
178	101001	1	2		YBM	2026-06-27 11:18:10.716614
179	101001	1	2		YBM	2026-06-27 11:18:32.624113
180	101001	1	2		YBM	2026-06-27 11:18:56.387405
181	101001	1	2		YBM	2026-06-27 11:20:28.725241
182	101001	1	10	20260627112151757434	YBM	2026-06-27 11:22:27.340018
183	101001	1	1		YBM	2026-06-27 11:24:21.089085
184	101001	1	1		YBM	2026-06-27 11:24:44.748915
185	101001	1	1		YBM	2026-06-27 11:25:12.138513
186	101001	1	2		YBM	2026-06-27 11:25:33.265636
187	101001	1	2		YBM	2026-06-27 11:27:03.102306
188	101001	1	2		YBM	2026-06-27 11:27:19.788709
189	101001	1	2		YBM	2026-06-27 11:34:39.256151
190	101001	1	2		YBM	2026-06-27 11:35:05.458595
191	101001	1	10		YBM	2026-06-27 11:36:49.927683
192	101001	1	1		YBM	2026-06-27 11:40:26.108381
193	101001	1	1		YBM	2026-06-27 11:40:35.477012
194	101001	1	11	20260627114452740267	WT	2026-06-27 11:45:25.258865
195	100100	1	1		YBM	2026-06-27 11:55:37.838345
196	100100	1	1		YBM	2026-06-27 11:55:46.097519
197	100100	1	1		YBM	2026-06-27 11:56:21.1827
198	100100	1	1		YBM	2026-06-27 11:59:35.726011
199	100100	1	1		YBM	2026-06-27 11:59:49.203863
200	100100	1	1		YBM	2026-06-27 11:59:55.794778
201	100100	1	10		YBM	2026-06-27 12:00:00.40752
202	100100	1	10		YBM	2026-06-27 12:00:04.742742
203	100100	1	2	20260627123001901085	YBM	2026-06-27 12:30:16.951011
204	100100	1	2	376	YBM	2026-06-27 12:30:23.812217
205	100100	1	2	376	YBM	2026-06-27 12:30:26.167561
206	100100	1	2	376	YBM	2026-06-27 12:30:27.454293
207	100100	1	2		YBM	2026-06-27 12:32:08.162881
208	101001	1	1		YBM	2026-06-27 14:00:41.503607
209	101001	1	1		YBM	2026-06-27 14:00:49.857725
210	101001	1	1		WT	2026-06-27 14:11:11.919237
211	101001	1	1		WT	2026-06-27 14:12:07.737293
212	101001	1	1		WT	2026-06-27 14:13:03.612532
213	101001	1	1		WT	2026-06-27 14:19:48.883615
214	100100	1	2	376	YBM	2026-06-27 14:27:59.811893
215	100100	1	2	376	YBM	2026-06-27 14:28:06.976602
216	101001	1	1		WT	2026-06-27 14:31:38.577035
217	101001	1	1		WT	2026-06-27 14:42:31.79207
218	101001	1	1		WT	2026-06-27 14:42:43.862746
219	101001	1	1		WT	2026-06-27 15:15:32.363497
220	101001	1	1		WT	2026-06-27 15:17:30.738994
221	101001	1	1		WT	2026-06-27 15:17:47.889182
222	101001	1	1		WT	2026-06-27 15:36:38.798084
223	101001	1	1		WT	2026-06-27 15:36:45.365057
224	101001	1	1		WT	2026-06-27 15:43:06.498132
225	100100	1	5	20260627155423256198	YBM	2026-06-27 15:54:39.124728
226	100100	1	5	379	YBM	2026-06-27 15:54:46.83573
227	100100	1	6	20260627160102439699	YBM	2026-06-27 16:01:17.988511
228	100100	1	6	380	YBM	2026-06-27 16:01:24.254021
229	100100	1	6	380	YBM	2026-06-27 16:01:25.896282
230	100100	1	7	20260627160609859877	YBM	2026-06-27 16:06:33.798075
231	100100	1	8	20260627161116110216	YBM	2026-06-27 16:11:33.424228
232	100100	1	8	382	YBM	2026-06-27 16:11:39.849037
233	100100	1	8	382	YBM	2026-06-27 16:11:42.765564
234	100100	1	10	20260627163808998198	YBM	2026-06-27 16:38:26.541136
235	101001	1	2	20260627180155088478	WT	2026-06-27 18:02:24.794482
236	101001	1	3	20260627180357317523	WT	2026-06-27 18:04:23.777241
237	101001	1	1		WT	2026-06-27 22:44:59.317513
238	100100	1	14	20260628075013324398	YBM	2026-06-28 07:50:38.579811
239	101001	1	4	20260628082951623603	WT	2026-06-28 08:30:08.597418
240	101001	1	5	20260628083429993292	WT	2026-06-28 08:35:13.974034
241	100100	2	2	20260628084105846088	YBM	2026-06-28 08:41:27.75471
242	100100	2	3	20260628084559522187	YBM	2026-06-28 08:46:21.766696
243	101001	1	1		WT	2026-06-28 09:01:48.235463
244	101001	1	1		WT	2026-06-28 09:02:21.852486
245	101001	1	1		WT	2026-06-28 09:07:42.869597
246	100100	2	5	20260628093341461556	YBM	2026-06-28 09:34:39.713336
247	100100	2	6	20260628093722986540	YBM	2026-06-28 09:37:42.669354
248	100100	2	7	20260628094511242522	YBM	2026-06-28 09:45:59.483708
249	101001	1	1		WT	2026-06-28 11:01:38.682996
250	101001	1	1	test_wt_v2_0628	WT	2026-06-28 11:32:52.464013
251	101001	1	1		WT	2026-06-28 11:33:56.440954
252	101001	1	1		WT	2026-06-28 11:35:49.499495
253	100100	2	9	20260628145155650131	YBM	2026-06-28 14:52:23.335601
254	100100	2	9	405	YBM	2026-06-28 14:52:35.242697
255	100100	2	11	20260628152256512875	YBM	2026-06-28 15:23:20.170806
256	100100	2	12	20260628152957019526	YBM	2026-06-28 15:30:18.667362
257	100100	2	1		YBM	2026-06-29 14:10:11.930726
258	100100	2	16		YBM	2026-06-29 14:10:25.993702
259	100100	1	1		YBM	2026-06-29 14:27:08.907076
260	100100	1	16		YBM	2026-06-29 14:27:13.153185
261	100101	1	1		YBM	2026-06-29 17:58:49.943371
262	100101	1	1		YBM	2026-06-29 17:58:59.429119
263	100101	1	1		YBM	2026-06-29 18:01:47.924831
264	100101	1	1		YBM	2026-06-29 18:02:57.259235
265	100100	1	1		YBM	2026-06-29 18:34:55.139601
266	100100	1	1		YBM	2026-06-29 18:48:00.607375
267	100101	1	1	20260629185752358994	YBM	2026-06-29 18:58:05.338125
268	100100	1	1		YBM	2026-06-29 19:07:16.439413
269	100100	1	1		YBM	2026-06-29 19:13:08.171311
270	100100	1	1		YBM	2026-06-29 19:13:19.932361
271	100100	1	1		YBM	2026-06-29 19:17:15.975671
272	100100	1	1		YBM	2026-06-29 19:49:48.543162
273	100100	1	1		YBM	2026-06-29 20:04:23.834251
274	100100	2	1		YBM	2026-06-29 20:11:47.036434
275	100100	2	2		YBM	2026-06-29 20:11:49.120075
276	100100	1	1		YBM	2026-06-29 21:06:15.876232
277	100100	1	1		YBM	2026-06-29 21:06:35.172079
278	100101	1	1		YBM	2026-06-29 21:17:05.316974
279	100100	2	16	20260629212626345012	YBM	2026-06-29 21:26:52.8618
280	100100	2	16	413	YBM	2026-06-29 21:27:06.075798
281	100101	1	1		YBM	2026-06-29 21:41:33.553255
282	100101	1	1		YBM	2026-06-29 21:42:09.39771
283	100101	1	1		YBM	2026-06-29 21:42:39.144564
284	100101	1	1		YBM	2026-06-29 21:43:24.713408
285	100100	2	2		YBM	2026-06-29 21:44:10.420219
286	100100	2	2		YBM	2026-06-29 21:44:15.149402
287	100100	2	2		YBM	2026-06-29 21:44:23.171959
288	100101	1	1		YBM	2026-06-29 21:45:20.15733
289	100101	1	1		YBM	2026-06-29 21:45:36.332599
290	100101	1	1		YBM	2026-06-29 21:46:10.726343
291	100100	1	10		YBM	2026-06-29 21:46:22.71304
292	100100	2	2		YBM	2026-06-29 21:46:24.696673
293	100101	1	1		YBM	2026-06-29 21:46:50.305969
294	100101	1	1		YBM	2026-06-29 21:47:01.332641
295	100101	1	1		YBM	2026-06-29 21:47:54.093014
296	100101	1	1		YBM	2026-06-29 21:48:14.642625
297	100101	1	1		YBM	2026-06-29 21:49:09.388508
298	100101	1	1		YBM	2026-06-29 21:50:59.655457
299	100100	1	9	20260629225052014226	YBM	2026-06-29 22:51:26.722028
300	100100	1	9	422	YBM	2026-06-29 22:51:38.250472
301	100100	1	11	20260629225224739911	YBM	2026-06-29 22:52:47.252035
302	100100	1	11	424	YBM	2026-06-29 22:53:13.965713
303	100100	1	10	423	YBM	2026-06-29 22:53:18.072603
304	100100	1	9	422	YBM	2026-06-29 22:53:22.651312
305	100100	1	11	424	YBM	2026-06-29 22:53:27.503918
306	100100	1	11		YBM	2026-06-29 22:54:37.307648
307	100100	1	11	424	YBM	2026-06-29 22:58:40.798704
308	100100	1	11	424	YBM	2026-06-29 23:00:00.811437
309	100100	1	9	422	YBM	2026-06-29 23:00:06.665536
310	100100	1	11	424	YBM	2026-06-29 23:01:38.605745
311	100100	1	11		YBM	2026-06-30 06:47:59.307582
312	100100	1	11		YBM	2026-06-30 07:02:42.830258
313	100100	1	1		YBM	2026-06-30 07:02:49.035021
314	100100	1	3		YBM	2026-06-30 07:02:57.266608
315	100100	1	2		YBM	2026-06-30 07:04:22.012273
316	100100	1	3		YBM	2026-06-30 07:04:22.382264
317	100100	1	4		YBM	2026-06-30 07:04:28.978664
318	100100	2	3	20260630070731985915	YBM	2026-06-30 07:08:08.530842
319	100100	2	3	432	YBM	2026-06-30 07:08:14.820521
320	100100	2	3	432	YBM	2026-06-30 07:08:18.467624
321	100100	2	7	20260630071102574249	YBM	2026-06-30 07:11:20.904692
322	100100	2	9	20260630072823856658	YBM	2026-06-30 07:28:54.321585
323	100100	2	9	20260630072823856658	YBM	2026-06-30 07:28:54.444181
324	100100	2	11	20260630075016897517	YBM	2026-06-30 07:50:37.438644
325	100100	2	11	440	YBM	2026-06-30 07:50:43.175227
326	100100	2	12	20260630075135072321	YBM	2026-06-30 07:51:52.955115
327	100101	1	1		YBM	2026-06-30 08:45:45.975405
328	100101	1	8	20260630090354376183	YBM	2026-06-30 09:04:02.328782
329	100101	1	9	20260630091101819765	YBM	2026-06-30 09:11:19.745932
330	100100	1	5	20260630091211403812	YBM	2026-06-30 09:13:28.18941
331	100101	1	11	20260630093015601516	YBM	2026-06-30 09:30:39.780994
332	100101	1	11	20260630093015601516	YBM	2026-06-30 09:30:39.961738
333	100101	1	15	20260630093905337250	YBM	2026-06-30 09:39:23.528154
334	100100	1	12	20260630094022158852	YBM	2026-06-30 09:49:43.268354
335	100100	1	16	478	YBM	2026-06-30 09:52:45.632332
336	100100	1	16	478	YBM	2026-06-30 09:52:48.025159
337	100100	1	12	470	YBM	2026-06-30 09:53:20.666603
338	100100	2	2	20260630095414309240	YBM	2026-06-30 09:54:35.060545
339	100100	2	2	20260630095414309240	YBM	2026-06-30 09:54:35.347354
340	100101	2	7	20260630101459139734	YBM	2026-06-30 10:15:35.271449
341	100100	2	6	20260630101943467907	YBM	2026-06-30 10:20:03.54907
342	100100	2	6	487	YBM	2026-06-30 10:20:08.708711
343	100100	2	6	487	YBM	2026-06-30 10:20:17.608822
344	100100	2	6		YBM	2026-06-30 10:20:34.090533
345	100100	2	6		YBM	2026-06-30 10:20:42.449595
346	100100	2	7	20260630105405124207	YBM	2026-06-30 10:54:40.869212
347	100100	2	7	488	YBM	2026-06-30 10:54:46.261232
348	100100	2	7	488	YBM	2026-06-30 10:54:50.082436
349	100100	2	23	488	YBM	2026-06-30 10:57:08.924072
350	100100	2	23	488	YBM	2026-06-30 10:57:28.792694
351	100100	2	7		YBM	2026-06-30 10:58:00.3729
352	100100	2	7		YBM	2026-06-30 10:58:58.873946
353	100100	2	23	488	YBM	2026-06-30 10:59:54.182377
354	100100	2	23	488	YBM	2026-06-30 11:00:08.172771
355	100100	2	11	20260630110420701345	YBM	2026-06-30 11:04:39.117063
356	100100	2	11	492	YBM	2026-06-30 11:04:44.843203
357	100100	2	10	491	YBM	2026-06-30 11:05:24.837296
358	100100	2	12	20260630111758918131	YBM	2026-06-30 11:18:17.923867
359	100100	2	12	493	YBM	2026-06-30 11:18:25.536618
360	100101	2	8	20260630112639381589	YBM	2026-06-30 11:26:59.020428
361	100101	2	8	494	YBM	2026-06-30 11:27:07.244798
362	100101	2	10	20260630113938731600	YBM	2026-06-30 11:40:00.958974
363	100100	2	13	20260630114500326407	YBM	2026-06-30 11:45:16.989931
364	100100	2	13	497	YBM	2026-06-30 11:49:15.531079
365	100101	2	11	20260630120430300084	YBM	2026-06-30 12:04:52.595139
366	100101	2	13	20260630122321456133	YBM	2026-06-30 12:23:42.559744
367	100101	2	14	20260630123806951872	YBM	2026-06-30 12:38:27.240106
368	100101	3	4	20260630123939351137	YBM	2026-06-30 12:40:01.289122
369	100101	3	1	20260630123932308808	YBM	2026-06-30 12:40:01.38284
370	100101	3	3	20260630123936503848	YBM	2026-06-30 12:40:07.374217
371	100101	3	5	20260630123952112437	YBM	2026-06-30 12:40:15.98035
372	100101	3	9	20260630124010539133	YBM	2026-06-30 12:40:30.921776
373	100101	3	7	20260630123959529209	YBM	2026-06-30 12:40:50.179061
374	100101	3	10	20260630124135737562	YBM	2026-06-30 12:42:00.664721
375	100101	3	12	20260630125108236602	YBM	2026-06-30 12:51:45.842866
376	100101	3	12	20260630125108236602	YBM	2026-06-30 12:51:46.01883
377	100101	3	12	514	YBM	2026-06-30 12:52:21.834812
378	100101	3	14	20260630125130451288	YBM	2026-06-30 12:52:31.111164
379	100101	3	15	20260630130421202757	YBM	2026-06-30 13:04:54.47108
380	100101	4	1	20260630130451524847	YBM	2026-06-30 13:05:24.69847
381	100101	4	3	20260630131251511581	YBM	2026-06-30 13:13:16.358173
382	100101	4	5	20260630132913118022	YBM	2026-06-30 13:29:47.12957
383	100101	4	6	20260630133057596999	YBM	2026-06-30 13:31:26.686877
384	100101	4	8	20260630133404595989	YBM	2026-06-30 13:34:33.287737
385	100100	2	15	20260630134559767386	YBM	2026-06-30 13:46:20.445059
386	100101	4	10	20260630134555889371	YBM	2026-06-30 13:46:23.976211
387	100100	2	15	530	YBM	2026-06-30 13:46:27.683317
388	100100	2	15	530	YBM	2026-06-30 13:46:32.165383
389	100100	2	15	530	YBM	2026-06-30 13:46:51.715518
390	100100	2	15	530	YBM	2026-06-30 13:46:56.585164
391	100101	4	12	20260630134846640888	YBM	2026-06-30 13:49:06.178843
392	100100	2	15	530	YBM	2026-06-30 13:49:07.504898
393	100100	2	15	530	YBM	2026-06-30 13:49:11.792453
394	100101	4	13	20260630140052363155	YBM	2026-06-30 14:01:19.943276
395	100101	4	15	20260630141511676928	YBM	2026-06-30 14:15:36.917777
396	100101	1	1	20260630141613856704	YBM	2026-06-30 14:16:30.094043
397	100101	1	2	20260630141616444325	YBM	2026-06-30 14:16:50.139383
398	100101	1	3	20260630141812626447	YBM	2026-06-30 14:18:37.101546
399	100101	1	5	20260630144750539670	YBM	2026-06-30 14:48:09.04823
400	100101	3	12	514	YBM	2026-06-30 14:51:14.797436
401	100101	1	7	20260630145256257792	YBM	2026-06-30 14:53:12.653362
402	100101	1	7	20260630145256257792	YBM	2026-06-30 14:53:12.798531
403	100101	2	14		YBM	2026-06-30 15:09:22.964234
404	100101	1	9	20260630152451000570	YBM	2026-06-30 15:25:19.23546
405	100101	1	11	20260630152726665334	YBM	2026-06-30 15:27:44.679125
406	100101	1	12	20260630153014147323	YBM	2026-06-30 15:30:47.089534
407	100101	1	13	20260630155114892074	YBM	2026-06-30 15:51:36.246515
408	100101	1	1	537	YBM	2026-06-30 16:56:09.637197
409	100100	2	16	20260630170632583423	YBM	2026-06-30 17:06:55.339107
410	100100	2	16	550	YBM	2026-06-30 17:08:19.489604
411	100100	1	1	20260630171440638549	YBM	2026-06-30 17:15:14.079407
412	100101	1	13	549	YBM	2026-06-30 17:39:29.165414
413	100100	1	3	20260630180308393971	YBM	2026-06-30 18:03:26.085858
414	100100	1	6	20260630180349917874	YBM	2026-06-30 18:04:04.471303
415	100100	1	7	20260630184408267234	YBM	2026-06-30 18:44:45.79894
416	100100	1	7	20260630184408267234	YBM	2026-06-30 18:44:45.942936
417	100100	1	9	20260630185425159147	YBM	2026-06-30 18:55:37.184263
418	100100	1	9	558	YBM	2026-06-30 18:55:42.782919
419	100100	1	9	558	remote_reopen	2026-06-30 18:55:42.784552
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.employees (id, merchant_id, name, phone, password_hash, role, status, created_at, auth_token, permissions, login_attempts, is_locked, plain_password) FROM stdin;
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.locations (id, merchant_id, name, address, longitude, latitude, status, created_at, withdraw_enabled, auto_approve_day, auto_approve_time, auto_approve_rate, click_free_count, anti_test_minutes, anti_test_auto_refund, hide_ratio, whitelist_phones, duplicate_filter_enabled, duplicate_filter_days, duplicate_filter_limit, show_refunding_status, refund_approve_rate, refund_approve_start_min, refund_approve_end_min, contact_phone, open_time, close_time, allow_slot_select, slot_assign_mode, allow_mid_retrieve, retrieve_mode, allow_h5_to_mp, show_qr_follow, force_follow_mp, h5_url, show_slot_count, screen_show_title, screen_title, slot_full_alert, slot_full_text, end_alert_minutes, enable_clear_box, clear_box_time, clear_box_cycle, deposit_random, deposit_min, deposit_max, contact_name, refund_mode, withdraw_mode, province, agent_id, city, usage_rules, deposit_amount, mp_appid, balance_hide_enabled, balance_hide_days) FROM stdin;
4	1	测试网点_修改测试	新地址	\N	\N	1	2026-06-12 05:12:41	1	1	12:00	80	3	30	1	30	13900139000	0	7	3	1	80	60	300	\N	08:00	22:00	0	auto	1	both	1	0	0	\N	0	1	\N	0	\N	0	0	23:00	1	0	0	0	1895588779	auto_approve	auto_approve	\N	\N	\N	test rules for locker	20		0	30
7	1	亿航驾校		\N	\N	1	2026-06-29 17:43:30.813267	1	1	02:00	0	3	30	1	30		0	7	3	1	80	60	300	13549878542	08:00	22:00	0	auto	1	both	1	0	0		1	1		0		0	0	23:00	1	0	0	0	wang	auto_approve	manual_approve		\N			20		0	30
6	4	淮海考场	河南商丘市	\N	\N	1	2026-06-25 09:24:57	1	1	12:00	80	3	30	1	0	\N	0	7	3	1	80	60	300	139000000000	08:00	22:00	0	auto	1	both	1	0	0	\N	1	1	\N	0	\N	0	0	23:00	1	0	0	0	李	auto_approve	manual_approve	\N	\N	\N	\N	20		0	30
\.


--
-- Data for Name: mainboards; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.mainboards (id, cabinet_id, board_index, slot_count, name, created_at, serial_port, baud_rate, address, board_type, protocol) FROM stdin;
1	2	1	24	主板1	2026-06-13 09:06:31	ttyS1	9600	\N	main	YBM
2	2	2	20	主板2	2026-06-13 09:06:35	ttyS1	9600	\N	main	YBM
3	3	1	12	主板1	2026-06-13 12:39:42	ttyS1	9600	\N	main	YBM
4	5	1	24	主板1	2026-06-14 14:39:36	ttyS1	9600	\N	main	YBM
13	9	1	12	\N	2026-06-16 14:16:02	ttyS1	9600	\N	main	YBM
14	10	1	12	\N	2026-06-16 22:59:14	ttyS4	9600	\N	main	YBM
15	11	1	12	\N	2026-06-16 22:59:42	ttyS3	115200	\N	main	WT
17	13	1	12	\N	2026-06-17 13:59:08	ttyS4	9600	\N	main	YBM
18	14	1	12	\N	2026-06-17 15:08:06	ttyS4	9600	\N	main	YBM
6	8	1	24	主板1	2026-06-15 01:53:20	ttyS4	9600	01	main	WT
10	8	2	24	主板2	2026-06-16 06:38:59	ttyS4	9600	02	main	WT
11	8	3	4	主板3	2026-06-16 07:36:30	ttyS4	9600	03	main	WT
36	15	1	16	\N	2026-06-28 07:19:10.849061	ttyS3	115200		main	WT
33	16	1	24	\N	2026-06-26 02:05:06	ttyS4	9600	\N	main	YBM
34	16	2	24	\N	2026-06-26 02:05:06	ttyS4	9600	\N	main	YBM
35	16	3	24	\N	2026-06-26 02:05:06	ttyS4	9600	\N	main	YBM
37	24	1	16	\N	2026-06-30 06:45:40.017764	ttyS4	9600		main	YBM
38	26	1	16	\N	2026-06-30 16:53:09.14436	ttyS4	9600		main	YBM
\.


--
-- Data for Name: merchants; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.merchants (id, name, contact_name, contact_phone, password_hash, status, created_at, agent_id, auth_token, permissions, login_attempts, is_locked, plain_password, commission_per_order, text_labels, merchant_number) FROM stdin;
2	自动密码商家	自动密码商家	13900004444	scrypt:32768:8:1$NMu4ywIhvVFRlw56$3967b2c9c47c8888e4f814aee04279e01a12f088f9cd4ac6aaaeb64a640bfd2947c143cf48659eb083f899c8f43d9eef600b6429eef9f318481200fd3b2e7d23	1	2026-06-23 08:51:37	1	\N	[]	0	0		0.00	{}	自动密码商家
4	淮海驾校	李	13900000000	scrypt:32768:8:1$2BY3G5zXtvLWzkmw$c81063a1364f950657edc66ca31291ce03865123b8570c5989377531c1b4740d696a5f26ff5dc2b86d8b30f2b1db56eb6a18d5f36f8011cb1341c28b93fab1df	1	2026-06-25 09:23:45	1	224972a9a93de6bab94518b12bf93f8e	[]	0	0		0.00	{}	淮海驾校
1	王	\N	13667618419	scrypt:32768:8:1$V6wqR21BBwwmfQIP$9a250f53617478ed62c66750f8e213ddac39919beb8b60c4c0a30b6abc78a2e3ada5367376e0f8095b75d485427ff80e31776715af5f4e78e903db29b4b2f6d2	1	2026-06-11 05:56:47	1	608a53efb4fae02af5f4e2f9030e6d73	["dashboard","locations","devices","orders","statistics","withdrawal","alerts","merchant_manage","full_data"]	0	0		0.00	{}	王
\.


--
-- Data for Name: offline_retrieve_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.offline_retrieve_records (id, order_no, retrieve_code, cabinet_id, slot_id, slot_number, retrieved_at, synced, uploaded) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.orders (id, order_no, user_phone, slot_id, cabinet_id, compartment_number, access_code, deposit_amount, status, store_time, retrieve_time, created_at, group_id, cabinet_code, cabinet_name, slot_size, transaction_id, refund_id, pay_time, refund_time, payment_channel_id, refund_mark, refund_status, refund_amount, logical_mark, logic_mark, logic_hide, note, admin_remark, pickup_time, updated_at, openid, unionid) FROM stdin;
1	20260611164651223263	13900001111	1	1	1	1234	20	6	2026-06-11 16:46:51.161898	2026-06-22 11:02:45.653043	2026-06-11 08:46:51	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
2	20260612123114733747	13800138000	1	1	1	1234	20	6	2026-06-12 12:31:14.192499	\N	2026-06-12 04:31:14	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
559	20260630214806741718	17726689234	504	16	B10	1234	20	5	2026-06-30 21:48:06.593936	\N	2026-06-30 21:48:06.58799	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		
560	20260630214824020439	17726689234	505	16	B11	1234	20	5	2026-06-30 21:48:24.538727	\N	2026-06-30 21:48:24.535435	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		
35	20260613112009044932	13667618419	11	1	11	1234	20	6	2026-06-13 11:20:09.3219	2026-06-13 16:54:54.138127	2026-06-13 03:20:09	\N	\N	\N	\N	MOCK20260613112010821772	\N	2026-06-13 11:20:10.929253	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
3	20260612123727077142	13811112222	1	1	1	6666	20	6	2026-06-12 12:37:27.81512	\N	2026-06-12 04:37:27	\N	\N	\N	\N	MOCK20260612123731687721	\N	2026-06-12 12:37:31.594703	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
29	20260613105400223433	13667618419	5	1	5	1234	20	4	2026-06-13 10:54:00.714045	2026-06-20 07:28:37.901891	2026-06-13 02:54:00	\N	\N	\N	\N	MOCK20260613105402524401	\N	2026-06-13 10:54:02.304042	2026-06-30 18:20:19.706673	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
28	20260613103956052882	18996093393	5	1	5	1234	20	3	2026-06-13 10:39:56.434611	2026-06-13 10:40:52.646938	2026-06-13 02:39:56	\N	\N	\N	\N	MOCK20260613103958690879	\N	2026-06-13 10:39:58.025961	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	\N	\N
25	20260613103518582221	13667618419	2	1	2	1234	20	4	2026-06-13 10:35:18.188338	2026-06-18 16:24:07.583328	2026-06-13 02:35:18	\N	\N	\N	\N	MOCK20260613103519579330	\N	2026-06-13 10:35:19.76699	2026-06-30 18:20:26.014794	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
4	20260612124106814078	13833334444	2	1	2	8888	20	6	2026-06-12 12:41:06.648616	\N	2026-06-12 04:41:06	\N	\N	\N	\N	MOCK20260612124112354956	\N	2026-06-12 12:41:12.466456	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
6	20260612125720101658	13855556666	3	1	3	5555	20	6	2026-06-12 12:57:20.93579	\N	2026-06-12 04:57:20	\N	\N	\N	\N	MOCK20260612125721052779	\N	2026-06-12 12:57:21.097809	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
7	20260612125750915588	13800001111	4	1	4	1111	20	6	2026-06-12 12:57:50.149594	\N	2026-06-12 04:57:50	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
10	20260612215047522854	13667618419	4	1	4	1234	20	6	2026-06-12 21:50:47.092037	\N	2026-06-12 13:50:47	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
561	20260630225621876847	13667618419	604	24	E14	1223	20	5	2026-06-30 22:56:21.267751	\N	2026-06-30 22:56:21.26316	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		
311	20260626093121031571	18896963355	447	8	1	1472	20	6	2026-06-26 09:31:21.065921	\N	2026-06-26 01:31:21	\N	\N	\N	\N	4200003129202606262955618549	\N	2026-06-26 09:34:58.933456	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
405	20260628145155650131	18888889999	519	16	25	1234	20	4	2026-06-28 14:51:55.54862	2026-06-28 14:51:55.544538	2026-06-28 14:51:55.544538	\N	\N	\N	\N	4200003187202606285994990390	\N	2026-06-28 14:52:23.293635	2026-06-30 12:29:58.796656	\N	0	none	20	N	N	\N	\N	\N	\N	\N		\N
408	20260628152957019526	17722332233	522	16	28	2584	20	4	2026-06-28 15:29:57.720409	2026-06-28 15:29:57.716683	2026-06-28 15:29:57.716683	\N	\N	\N	\N	4200003133202606283862175972	\N	2026-06-28 15:30:18.625375	2026-06-30 12:29:58.796656	\N	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
385	20260627180155088478	18996093393	464	15	2	1111	1	3	2026-06-27 18:01:55.789566	2026-06-28 08:30:57.233902	2026-06-27 18:01:55.784048	\N	\N	\N	\N	4200003215202606279493063491	\N	2026-06-27 18:02:24.752173	\N	\N	1	none	1	N	\N	\N	\N	\N	\N	\N		\N
317	20260626131340677421	18888889999	453	8	7	1234	20	3	2026-06-26 13:13:40.256117	2026-06-26 13:13:40.256117	2026-06-26 05:13:40	\N	\N	\N	\N	4200003204202606269502378651	\N	2026-06-26 13:15:47.744732	\N	1	1	none	20	N	Y	\N	\N	\N	\N	\N	\N	\N
299	20260625235027193965	17725196748	\N	8	A37	2588	20	3	2026-06-25 23:50:27.826689	2026-06-26 09:25:55	2026-06-25 15:50:27	\N	\N	\N	\N	\N	\N	2026-06-25 23:50:39.600723	\N	1	1	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N	\N
45	20260613131840461338	13667618419	12	1	12	1234	20	6	2026-06-13 13:18:40.783496	\N	2026-06-13 05:18:40	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
401	20260628094511242522	18888889999	517	16	23	1234	20	3	2026-06-28 09:45:11.146479	2026-06-28 17:48:14	2026-06-28 09:45:11.142633	\N	\N	\N	\N	4200003205202606284880898631	\N	2026-06-28 09:45:59.44543	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-28 17:48:14	2026-06-28 17:48:14		\N
318	20260626135530670593	18888889999	454	8	8	2584	20	4	2026-06-26 13:55:30.485465	2026-06-26 06:54:23	2026-06-26 05:55:30	\N	\N	\N	\N	4200003189202606260554928901	50302107622026062666051552700	2026-06-26 13:57:38.738504	2026-06-26 06:54:23	1	0	none	0	N	Y	\N	\N	\N	\N	\N	\N	\N
46	20260613133703359745	13667618419	12	1	12	1234	20	6	2026-06-13 13:37:03.055746	\N	2026-06-13 05:37:03	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
307	20260626073004388401	17726689234	\N	8	A43	1234	20	4	2026-06-26 07:30:04.21892	2026-06-26 09:25:55	2026-06-25 23:30:04	\N	\N	\N	\N	4200003135202606260982950090	\N	2026-06-26 07:31:20.124597	\N	1	0	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N	\N
47	20260613133909419178	13667618419	12	1	12	1234	20	6	2026-06-13 13:39:09.640321	\N	2026-06-13 05:39:09	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
315	20260626094615190546	18888889999	451	8	5	5555	20	4	2026-06-26 09:46:15.591414	2026-06-26 02:48:20	2026-06-26 01:46:15	\N	\N	\N	\N	4200003184202606264338045728	50300807642026062648651889940	2026-06-26 09:46:21.93903	2026-06-26 02:48:20	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
316	20260626094918519644	18888889999	452	8	6	1234	20	4	2026-06-26 09:49:18.491913	2026-06-26 04:04:47	2026-06-26 01:49:18	\N	\N	\N	\N	4200003183202606260475366817	50301707452026062667399424477	2026-06-26 10:53:39.424639	2026-06-26 04:04:47	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
48	20260613133924649812	13667618419	12	1	12	1234	20	6	2026-06-13 13:39:24.861452	\N	2026-06-13 05:39:24	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
49	20260613134749013842	13667618419	12	1	12	1234	20	6	2026-06-13 13:47:49.703254	\N	2026-06-13 05:47:49	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
50	20260613134850334364	13667618419	12	1	12	1234	20	6	2026-06-13 13:48:50.92085	\N	2026-06-13 05:48:50	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
322	20260626143108074975	18888889999	456	8	10	1234	20	6	2026-06-26 14:31:08.770084	\N	2026-06-26 06:31:08	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
308	20260626091635740650	13800138099	\N	8	A44	6190	20	6	2026-06-26 09:16:35.183113	\N	2026-06-26 01:16:35	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
320	20260626140617450909	18888889999	455	8	9	1234	20	6	2026-06-26 14:06:17.38877	\N	2026-06-26 06:06:17	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
324	20260626143656327539	18888889999	457	8	11	2222	20	6	2026-06-26 14:36:56.063012	\N	2026-06-26 06:36:56	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
310	20260626092711160596	18896963355	\N	8	A45	1234	20	6	2026-06-26 09:27:11.556338	\N	2026-06-26 01:27:11	\N	\N	\N	\N	4200003125202606267155536409	\N	2026-06-26 09:27:18.112181	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
411	20260629170431118734	13667618419	525	16	31	1234	20	6	2026-06-29 17:04:31.852581	\N	2026-06-29 17:04:31.849353	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
386	20260627180357317523	18983079797	465	15	3	1111	1	3	2026-06-27 18:03:57.305456	2026-06-27 18:06:36.345558	2026-06-27 18:03:57.30143	\N	\N	\N	\N	4200003131202606271749527663	\N	2026-06-27 18:04:23.73262	\N	\N	1	none	1	N	\N	\N	\N	\N	\N	\N		\N
422	20260629225052014226	13667618419	503	16	9	1234	20	4	2026-06-29 22:50:52.343292	2026-06-29 22:50:52.341273	2026-06-29 22:50:52.341273	\N	\N	\N	\N	4200003196202606294886056707	50302707742026063072046541887	2026-06-29 22:51:26.69975	2026-06-30 12:30:36.497195	\N	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
406	20260628145244714943	18888889999	520	16	26	1234	20	6	2026-06-28 14:52:44.056848	\N	2026-06-28 14:52:44.05194	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
353	20260626203849898493	18888889999	\N	16	31	1234	20	3	2026-06-26 20:38:49.379353	2026-06-27 12:36:26	2026-06-26 20:38:49.37593	\N	\N	\N	\N	4200003195202606264695707051	\N	2026-06-26 20:39:21.485707	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-27 12:36:26	2026-06-27 12:36:26	\N	\N
352	20260626203440517799	18888889999	\N	16	14	1234	20	4	2026-06-26 20:34:40.996024	2026-06-27 13:01:09	2026-06-26 20:34:40.992904	\N	\N	\N	\N	4200003125202606264648421174	\N	2026-06-26 20:35:02.286861	2026-06-27 13:01:13.283609	\N	1	refunded	20	N	\N	\N	\N	\N	2026-06-27 13:01:09	2026-06-27 13:01:09	\N	\N
347	20260626195241140324	18888889999	\N	16	13	1234	20	4	2026-06-26 19:52:41.308565	2026-06-27 13:08:19	2026-06-26 19:52:41.305257	\N	\N	\N	\N	4200003178202606268143428277	\N	2026-06-26 19:53:03.021625	2026-06-27 13:08:24.915191	\N	1	refunded	20	N	\N	\N	\N	\N	2026-06-27 13:08:19	2026-06-27 13:08:19	\N	\N
373	20260627112151757434	18996093393	472	15	10	1111	1	4	2026-06-27 11:21:51.938666	2026-06-27 13:00:57.157798	2026-06-27 11:21:51.93423	\N	\N	\N	\N	4200003189202606278759826892	\N	2026-06-27 11:22:27.301772	2026-06-27 13:00:57.157798	\N	1	refunded	1	N	\N	\N	\N	\N	\N	\N	\N	\N
392	20260628083256974078	18888889999	509	16	15	1234	20	6	2026-06-28 08:32:56.971527	\N	2026-06-28 08:32:56.967757	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
374	20260627114452740267	18996093393	473	15	11	1111	1	3	2026-06-27 11:44:52.795958	2026-06-27 12:40:46	2026-06-27 11:44:52.791747	\N	\N	\N	\N	4200003183202606272953018543	\N	2026-06-27 11:45:25.221999	\N	\N	1	none	1	N	\N	\N	\N	\N	2026-06-27 12:40:46	2026-06-27 12:40:46	\N	\N
414	20260629220133197272	13667618419	495	16	1	1234	20	6	2026-06-29 22:01:33.586509	\N	2026-06-29 22:01:33.584085	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
357	20260626211118085006	18996093393	\N	16	16	1234	20	6	2026-06-26 21:11:18.445816	\N	2026-06-26 21:11:18.442622	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
360	20260627081026930792	18888889999	\N	16	34	1234	20	6	2026-06-27 08:10:26.276668	\N	2026-06-27 08:10:26.272233	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
407	20260628152256512875	17722332233	521	16	27	1475	20	4	2026-06-28 15:22:56.856654	2026-06-28 15:22:56.852527	2026-06-28 15:22:56.852527	\N	\N	\N	\N	4200003223202606288663233889	\N	2026-06-28 15:23:20.132205	2026-06-30 12:29:58.796656	\N	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
5	20260612125238878728	13844445555	3	1	3	1234	20	4	2026-06-12 12:52:38.906724	2026-06-12 12:52:39.19345	2026-06-12 04:52:38	\N	\N	\N	\N	MOCK20260612125239933782	MOCK_R20260612125239053174	2026-06-12 12:52:39.075634	2026-06-12 12:52:39.19345	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
8	20260612125806054979	13800001111	4	1	4	1111	20	4	2026-06-12 12:58:06.520154	2026-06-12 12:58:06.798029	2026-06-12 04:58:06	\N	\N	\N	\N	MOCK20260612125806736595	MOCK_R20260612125806149070	2026-06-12 12:58:06.678324	2026-06-12 12:58:06.798029	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
9	20260612130727372053	13877778888	4	1	4	9999	20	4	2026-06-12 13:07:27.142639	2026-06-12 13:07:27.422495	2026-06-12 05:07:27	\N	\N	\N	\N	MOCK20260612130727077299	MOCK_R20260612130727819069	2026-06-12 13:07:27.300624	2026-06-12 13:07:27.422495	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
376	20260627123001901085	18888889999	496	16	2	1234	20	4	2026-06-27 12:30:01.700717	2026-06-27 12:58:36.902548	2026-06-27 12:30:01.695111	\N	\N	\N	\N	4200003136202606276068779383	\N	2026-06-27 12:30:16.889189	2026-06-27 12:58:36.902548	\N	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
361	20260627090317533234	18888889999	\N	16	35	1234	20	6	2026-06-27 09:03:17.223309	\N	2026-06-27 09:03:17.217013	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
362	20260627090802425253	18888889999	\N	16	36	2582	20	6	2026-06-27 09:08:02.402114	\N	2026-06-27 09:08:02.398762	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
363	20260627090903381736	17722332233	\N	16	37	2582	20	6	2026-06-27 09:09:03.602507	\N	2026-06-27 09:09:03.597066	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
364	20260627091248396985	17722332233	\N	16	38	1234	20	6	2026-06-27 09:12:48.347639	\N	2026-06-27 09:12:48.343982	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
358	20260626211119806002	18996093393	\N	16	2	1234	20	3	2026-06-26 21:11:19.719376	2026-06-26 21:11:50.818076	2026-06-26 21:11:19.716109	\N	\N	\N	\N	4200003203202606266721579288	\N	2026-06-26 21:11:38.334743	\N	\N	1	none	20	N	\N	\N	\N	\N	\N	\N	\N	\N
379	20260627155423256198	18888889999	499	16	5	1234	20	3	2026-06-27 15:54:23.610202	2026-06-28 07:21:51	2026-06-27 15:54:23.605346	\N	\N	\N	\N	4200003209202606279977784591	\N	2026-06-27 15:54:39.077132	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-28 07:21:51	2026-06-28 07:21:51		\N
412	20260629185752358994	18996093393	591	24	E1	1111	20	3	2026-06-29 18:57:52.050962	2026-06-29 18:57:52.048506	2026-06-29 18:57:52.048506	\N	\N	\N	\N	4200003198202606291966260716	\N	2026-06-29 18:58:05.315628	\N	\N	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
359	20260626211337376195	18996093393	\N	16	3	1234	20	3	2026-06-26 21:13:37.547959	2026-06-27 02:01:04	2026-06-26 21:13:37.544542	\N	\N	\N	\N	4200003190202606262178436345	\N	2026-06-26 21:14:06.670619	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-27 02:01:04	2026-06-27 02:01:04	\N	\N
391	20260628082951623603	18996093393	466	15	4	1111	1	3	2026-06-28 08:29:51.401874	2026-06-28 08:31:00.780515	2026-06-28 08:29:51.396946	\N	\N	\N	\N	4200003213202606286027761813	\N	2026-06-28 08:30:08.559875	\N	\N	1	none	1	N	\N	\N	\N	\N	\N	\N		\N
365	20260627091428107422	17722332233	\N	16	39	1234	20	6	2026-06-27 09:14:28.423398	\N	2026-06-27 09:14:28.419986	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
366	20260627091653850850	18888889999	\N	16	40	1231	20	6	2026-06-27 09:16:53.368289	\N	2026-06-27 09:16:53.365101	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
367	20260627091745119158	18888889999	\N	16	41	1234	20	6	2026-06-27 09:17:45.683536	\N	2026-06-27 09:17:45.680578	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
457	20260630091101819765	18996093393	599	24	E9	1234	20	3	2026-06-30 09:11:01.276431	2026-06-30 09:11:01.254235	2026-06-30 09:11:01.254235	\N	\N	\N	\N	4200003186202606300691410477	\N	2026-06-30 09:11:19.737264	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
470	20260630094022158852	17726689234	506	16	12	4265	20	6	2026-06-30 09:40:22.786174	2026-06-30 09:40:22.764245	2026-06-30 09:40:22.764245	\N	\N	\N	\N	4200003173202606305670319510	\N	2026-06-30 09:49:43.241028	2026-06-30 12:29:58.796656	3	0	none	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548		\N
454	20260630090354376183	18996093393	598	24	E8	1234	20	3	2026-06-30 09:03:54.10188	2026-06-30 09:03:54.081831	2026-06-30 09:03:54.081831	\N	\N	\N	\N	4200003183202606303659442815	\N	2026-06-30 09:04:02.318368	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
456	20260630091032906795	13667618419	498	16	4	1234	20	6	2026-06-30 09:10:32.954141	\N	2026-06-30 09:10:32.933236	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
461	20260630093015601516	18983079797	601	24	E11	1234	20	3	2026-06-30 09:30:15.203007	2026-06-30 09:30:15.181189	2026-06-30 09:30:15.181189	\N	\N	\N	\N	4200003185202606305579509474	\N	2026-06-30 09:30:39.947353	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
469	20260630093905337250	18996093393	605	24	E15	1234	20	3	2026-06-30 09:39:05.780707	2026-06-30 09:39:05.759763	2026-06-30 09:39:05.759763	\N	\N	\N	\N	4200003213202606301295336829	\N	2026-06-30 09:39:23.520017	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
453	20260630090350206285	18996093393	597	24	E7	1234	20	6	2026-06-30 09:03:50.484419	\N	2026-06-30 09:03:50.463616	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
440	20260630075016897517	17726689234	521	16	27	1234	20	4	2026-06-30 07:50:16.303948	2026-06-30 07:54:56.206145	2026-06-30 07:50:16.28316	\N	\N	\N	\N	4200003126202606304942694629	\N	2026-06-30 07:50:37.421189	2026-06-30 12:29:58.796656	1	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
439	20260630074932550621	17726689234	520	16	26	1234	20	6	2026-06-30 07:49:32.402611	\N	2026-06-30 07:49:32.370677	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
442	20260630085716452182	18996093393	592	24	E2	1234	20	6	2026-06-30 08:57:16.03203	\N	2026-06-30 08:57:16.011934	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
443	20260630085725701713	13667618419	523	16	29	1234	20	6	2026-06-30 08:57:25.623578	\N	2026-06-30 08:57:25.603562	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
444	20260630085728030940	13667618419	524	16	30	1234	20	6	2026-06-30 08:57:28.664439	\N	2026-06-30 08:57:28.644046	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
306	20260626070704844022	17726689234	\N	8	A42	1234	20	4	2026-06-26 07:07:04.286167	2026-06-26 09:25:55	2026-06-25 23:07:04	\N	\N	\N	\N	4200003222202606267015269936	\N	2026-06-26 07:10:42.381455	\N	1	0	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N	\N
506	20260630123939351137	18254067609	626	24	E36	2007	20	3	2026-06-30 12:39:39.072378	2026-06-30 18:27:44.766091	2026-06-30 12:39:39.051439	\N	\N	\N	\N	4200003190202606306991859861	50302107702026063010864677966	2026-06-30 12:40:01.282903	2026-06-30 21:24:15.600965	2	1	success	20	N	\N	\N	\N	\N	\N	2026-06-30 18:27:44.766091		\N
484	20260630101459139734	19905939796	613	24	E23	8106	20	3	2026-06-30 10:14:59.088933	2026-06-30 10:14:59.067319	2026-06-30 10:14:59.067319	\N	\N	\N	\N	4200003224202606309624402648	\N	2026-06-30 10:15:35.26215	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
501	20260630123806951872	18265820019	620	24	E30	0099	20	3	2026-06-30 12:38:06.906077	2026-06-30 15:09:03.911412	2026-06-30 12:38:06.884662	\N	\N	\N	\N	4200003115202606303234817522	50300207922026063016371921591	2026-06-30 12:38:27.2341	2026-06-30 21:24:15.600965	3	1	success	20	N	\N	\N	\N	\N	\N	\N		\N
303	20260626070425643415	17726689234	\N	8	A41	1234	20	4	2026-06-26 07:04:25.78776	2026-06-26 07:07:47	2026-06-25 23:04:25	\N	\N	\N	\N	4200003184202606262064245079	\N	2026-06-26 07:06:32.966761	2026-06-30 12:29:58.796656	1	0	none	20	N	\N	\N	\N	\N	\N	\N	\N	\N
509	20260630123959529209	15806753783	629	24	E39	0420	20	4	2026-06-30 12:39:59.297656	2026-06-30 14:46:23	2026-06-30 12:39:59.276555	\N	\N	\N	\N	4200003189202606303949941723	\N	2026-06-30 12:40:50.158171	2026-06-30 14:46:27.352347	1	1	refunded	20	N	\N	\N	\N	\N	2026-06-30 14:46:23	2026-06-30 14:46:23		\N
480	20260630095359595591	17726689234	511	16	17	1234	20	6	2026-06-30 09:53:59.073087	\N	2026-06-30 09:53:59.052692	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
482	20260630095930123100	18996093393	612	24	E22	1234	20	6	2026-06-30 09:59:30.323158	\N	2026-06-30 09:59:30.302188	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
483	20260630101421138126	17726689234	513	16	19	1234	20	6	2026-06-30 10:14:21.505509	\N	2026-06-30 10:14:21.484707	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
485	20260630101850398655	17726689234	514	16	20	1234	20	6	2026-06-30 10:18:50.781139	\N	2026-06-30 10:18:50.757213	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
486	20260630101941925927	17726689234	515	16	21	1234	20	6	2026-06-30 10:19:41.637977	\N	2026-06-30 10:19:41.61828	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
495	20260630113935687094	13667618419	615	24	E25	1234	20	6	2026-06-30 11:39:35.828456	\N	2026-06-30 11:39:35.806639	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
505	20260630123936503848	15617060696	625	24	E35	5656	20	2	2026-06-30 12:39:36.449014	\N	2026-06-30 12:39:36.428076	\N	\N	\N	\N	4200003204202606306642224931	\N	2026-06-30 12:40:07.351985	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
507	20260630123952112437	18865018110	627	24	E37	1886	20	2	2026-06-30 12:39:52.568609	\N	2026-06-30 12:39:52.545299	\N	\N	\N	\N	4200003223202606301431470228	\N	2026-06-30 12:40:15.974605	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
511	20260630124010539133	13207075405	631	24	E41	1314	20	2	2026-06-30 12:40:10.410691	\N	2026-06-30 12:40:10.389848	\N	\N	\N	\N	4200003197202606302682250482	\N	2026-06-30 12:40:30.91608	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
489	20260630110213222350	17726689234	518	16	24	1234	20	6	2026-06-30 11:02:13.677224	\N	2026-06-30 11:02:13.657002	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
413	20260629212626345012	13667618419	526	16	32	1234	20	4	2026-06-29 21:26:26.194231	2026-06-29 21:26:26.191915	2026-06-29 21:26:26.191915	\N	\N	\N	\N	4200003134202606295998962135	\N	2026-06-29 21:26:52.835011	2026-06-30 12:29:58.796656	\N	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
490	20260630110215141276	17726689234	519	16	25	1234	20	6	2026-06-30 11:02:15.710138	\N	2026-06-30 11:02:15.688124	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
491	20260630110418100035	17726689234	520	16	26	1234	20	6	2026-06-30 11:04:18.071282	\N	2026-06-30 11:04:18.051079	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
493	20260630111758918131	17726689234	522	16	28	1234	20	6	2026-06-30 11:17:58.486108	2026-06-30 11:17:58.465235	2026-06-30 11:17:58.465235	\N	\N	\N	\N	4200003174202606308573605856	\N	2026-06-30 11:18:17.916737	2026-06-30 11:24:41.832148	3	1	refunded	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548		\N
499	20260630122320700932	13667618419	618	24	E28	1234	20	6	2026-06-30 12:23:20.911204	\N	2026-06-30 12:23:20.890707	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
502	20260630123931350123	15550752925	622	24	E32	2925	20	6	2026-06-30 12:39:31.490052	\N	2026-06-30 12:39:31.469421	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
512	20260630124135737562	15098366660	632	24	E42	1013	20	4	2026-06-30 12:41:35.535429	2026-06-30 15:08:55	2026-06-30 12:41:35.51477	\N	\N	\N	\N	4200003149202606301063935560	\N	2026-06-30 12:42:00.659396	2026-06-30 15:09:00.253175	3	1	refunded	20	N	\N	\N	\N	\N	2026-06-30 15:08:55	2026-06-30 15:08:55		\N
532	20260630134846640888	13791463202	650	24	E60	1234	20	3	2026-06-30 13:48:46.550553	2026-06-30 15:17:35.702619	2026-06-30 13:48:46.52923	\N	\N	\N	\N	4200003223202606307199431243	\N	2026-06-30 13:49:06.172062	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
514	20260630125108236602	18265005796	634	24	E44	7878	20	3	2026-06-30 12:51:08.816958	2026-06-30 15:16:02.742288	2026-06-30 12:51:08.796771	\N	\N	\N	\N	4200003224202606306671084085	\N	2026-06-30 12:51:46.013373	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
528	20260630134555889371	18953074181	648	24	E58	1234	20	3	2026-06-30 13:45:55.349822	2026-06-30 15:29:00.865583	2026-06-30 13:45:55.32821	\N	\N	\N	\N	4200003180202606305224957902	\N	2026-06-30 13:46:23.954501	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
519	20260630130451524847	19286022436	639	24	E49	6666	20	4	2026-06-30 13:04:51.133104	2026-06-30 15:18:21.865765	2026-06-30 13:04:51.109839	\N	\N	\N	\N	4200003138202606302528916179	\N	2026-06-30 13:05:24.693386	2026-06-30 16:50:51.910392	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N		\N
504	20260630123934536157	15617060696	624	24	E34	5656	20	6	2026-06-30 12:39:34.546798	\N	2026-06-30 12:39:34.526664	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
526	20260630133404595989	15138943614	646	24	E56	5219	20	3	2026-06-30 13:34:04.912326	2026-06-30 16:04:17.890288	2026-06-30 13:34:04.892193	\N	\N	\N	\N	4200003147202606302705451991	\N	2026-06-30 13:34:33.280437	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
523	20260630132913118022	15275043796	643	24	E53	8011	20	3	2026-06-30 13:29:13.617642	2026-06-30 16:12:23.934446	2026-06-30 13:29:13.59594	\N	\N	\N	\N	4200003128202606309427246633	\N	2026-06-30 13:29:47.108379	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
516	20260630125130451288	18326741968	636	24	E46	9999	20	3	2026-06-30 12:51:30.444471	2026-06-30 15:12:49.55469	2026-06-30 12:51:30.424234	\N	\N	\N	\N	4200003151202606305421787597	\N	2026-06-30 12:52:31.090413	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
524	20260630133057596999	18438398466	644	24	E54	8466	20	3	2026-06-30 13:30:57.276719	2026-06-30 15:54:09.750178	2026-06-30 13:30:57.256674	\N	\N	\N	\N	4200003135202606306343380379	\N	2026-06-30 13:31:26.664935	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
521	20260630131251511581	18637010208	641	24	E51	1111	20	4	2026-06-30 13:12:51.853737	2026-06-30 16:31:24.751435	2026-06-30 13:12:51.832105	\N	\N	\N	\N	4200003097202606302709695392	\N	2026-06-30 13:13:16.351852	2026-06-30 17:12:18.658536	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N		\N
517	20260630130421202757	15657821278	637	24	E47	1314	20	3	2026-06-30 13:04:21.911241	2026-06-30 13:04:21.890156	2026-06-30 13:04:21.890156	\N	\N	\N	\N	4200003218202606304060814654	\N	2026-06-30 13:04:54.464287	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
424	20260629225224739911	13667618419	505	16	11	1234	20	4	2026-06-29 22:52:24.82795	2026-06-29 22:52:24.825913	2026-06-29 22:52:24.825913	\N	\N	\N	\N	4200003199202606299595869587	50302707822026063078239768103	2026-06-29 22:52:47.231275	2026-06-30 12:29:33.041215	\N	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
432	20260630070731985915	13667618419	513	16	19	1234	20	4	2026-06-30 07:07:31.383625	2026-06-30 07:07:31.36396	2026-06-30 07:07:31.36396	\N	\N	\N	\N	4200003185202606302618664886	50300607922026063003185761556	2026-06-30 07:08:08.499015	2026-06-30 12:29:28.501642	2	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
441	20260630075135072321	17726689234	522	16	28	1234	20	4	2026-06-30 07:51:35.654789	2026-06-30 07:51:35.63506	2026-06-30 07:51:35.63506	\N	\N	\N	\N	4200003102202606301301964997	\N	2026-06-30 07:51:52.930912	2026-06-30 12:29:58.796656	3	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
494	20260630112639381589	13667618419	614	24	E24	1234	20	4	2026-06-30 11:26:39.555022	2026-06-30 11:26:39.522294	2026-06-30 11:26:39.522294	\N	\N	\N	\N	4200003131202606308786195009	\N	2026-06-30 11:26:59.012298	2026-06-30 11:38:11.28106	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N		\N
396	20260628084105846088	17722332233	512	16	18	3698	20	4	2026-06-28 08:41:05.289221	2026-06-28 08:41:05.285541	2026-06-28 08:41:05.285541	\N	\N	\N	\N	4200003183202606281049040918	\N	2026-06-28 08:41:27.716368	2026-06-30 12:29:58.796656	\N	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
332	20260626155413206167	18888889999	\N	16	22	1234	20	4	2026-06-26 15:54:13.158122	2026-06-26 07:54:13	2026-06-26 07:54:13	\N	\N	\N	\N	4200003214202606261349170060	\N	2026-06-26 17:28:40.671384	2026-06-30 12:29:58.796656	1	0	none	20	N	\N	\N	\N	\N	\N	\N	\N	\N
397	20260628084559522187	17722332233	513	16	19	1234	20	4	2026-06-28 08:45:59.421579	2026-06-28 08:45:59.417494	2026-06-28 08:45:59.417494	\N	\N	\N	\N	4200003133202606282333152255	\N	2026-06-28 08:46:21.724518	2026-06-30 12:29:58.796656	\N	0	none	20	N	Y	\N	\N	\N	\N	\N		\N
436	20260630071102574249	17726689234	517	16	23	1234	20	4	2026-06-30 07:11:02.520772	2026-06-30 07:11:02.498729	2026-06-30 07:11:02.498729	\N	\N	\N	\N	4200003119202606306901998225	\N	2026-06-30 07:11:20.883796	2026-06-30 12:29:58.796656	3	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
438	20260630072823856658	17726689234	519	16	25	1234	20	4	2026-06-30 07:28:23.32169	2026-06-30 07:28:23.300015	2026-06-30 07:28:23.300015	\N	\N	\N	\N	4200003196202606302480741718	\N	2026-06-30 07:28:54.438649	2026-06-30 12:29:58.796656	2	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
30	20260613105455853270	13667618419	6	1	6	1245	20	4	2026-06-13 10:54:55.784146	2026-06-20 07:28:42.627193	2026-06-13 02:54:55	\N	\N	\N	\N	MOCK20260613105457264570	\N	2026-06-13 10:54:57.370452	2026-06-30 18:20:16.692277	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
33	20260613111339242608	13667618419	9	1	9	1234	20	4	2026-06-13 11:13:39.831526	2026-06-20 07:28:30.680119	2026-06-13 03:13:39	\N	\N	\N	\N	MOCK20260613111341731060	\N	2026-06-13 11:13:41.426004	2026-06-30 18:20:30.370586	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
34	20260613111950247604	13667618419	10	1	10	1234	20	4	2026-06-13 11:19:50.101529	2026-06-20 07:28:25.534453	2026-06-13 03:19:50	\N	\N	\N	\N	MOCK20260613111951029532	\N	2026-06-13 11:19:51.705278	2026-06-30 18:20:23.259416	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
508	20260630123958282904	17852883970	628	24	E38	0102	20	6	2026-06-30 12:39:58.922741	\N	2026-06-30 12:39:58.901368	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
510	20260630124008746787	13207075405	630	24	E40	1314	20	6	2026-06-30 12:40:08.657323	\N	2026-06-30 12:40:08.635806	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
529	20260630134558804935	17726689234	524	16	30	1234	20	6	2026-06-30 13:45:58.44308	\N	2026-06-30 13:45:58.421459	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
500	20260630122321456133	13667618419	619	24	E29	1234	20	4	2026-06-30 12:23:21.850439	2026-06-30 12:23:21.83036	2026-06-30 12:23:21.83036	\N	\N	\N	\N	4200003190202606303089652659	50301907852026063066869054592	2026-06-30 12:23:42.549796	2026-06-30 12:29:22.440017	1	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
496	20260630113938731600	13667618419	616	24	E26	1234	20	4	2026-06-30 11:39:38.085987	2026-06-30 11:39:38.065986	2026-06-30 11:39:38.065986	\N	\N	\N	\N	4200003210202606300113915182	50302207982026063021246271353	2026-06-30 11:40:00.921905	2026-06-30 12:29:23.388248	1	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
498	20260630120430300084	13667618419	617	24	E27	1234	20	4	2026-06-30 12:04:30.058494	2026-06-30 12:04:30.037885	2026-06-30 12:04:30.037885	\N	\N	\N	\N	4200003130202606309674975458	\N	2026-06-30 12:04:52.582013	2026-06-30 12:29:58.796656	2	0	none	20	N	\N	\N	\N	\N	\N	\N		\N
533	20260630140052363155	19693594027	651	24	E61	4027	20	2	2026-06-30 14:00:52.422918	\N	2026-06-30 14:00:52.4012	\N	\N	\N	\N	4200003107202606306060143584	\N	2026-06-30 14:01:19.933992	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
300	20260625235218620187	17725196748	\N	8	A38	1475	20	3	2026-06-25 23:52:18.95125	2026-06-26 09:25:55	2026-06-25 15:52:18	\N	\N	\N	\N	\N	\N	2026-06-25 23:52:25.211139	\N	1	1	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N	\N
313	20260626093604565096	18888889999	449	8	3	1234	20	3	2026-06-26 09:36:04.314655	2026-06-26 09:36:04.314655	2026-06-26 01:36:04	\N	\N	\N	\N	4200003188202606261236674981	\N	2026-06-26 09:39:42.377781	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	\N	\N
314	20260626094216584004	18888889999	450	8	4	1234	20	3	2026-06-26 09:42:16.701258	2026-06-26 09:42:16.701258	2026-06-26 01:42:16	\N	\N	\N	\N	4200003186202606263086244068	\N	2026-06-26 09:42:30.426072	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	\N	\N
301	20260626062352442950	17725196748	\N	8	A39	1234	20	3	2026-06-26 06:23:52.388604	2026-06-26 09:25:55	2026-06-25 22:23:52	\N	\N	\N	\N	4200003126202606266486005168	\N	2026-06-26 06:26:00.886014	\N	1	1	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N	\N
312	20260626093458449115	18888889999	448	8	2	1472	20	3	2026-06-26 09:34:58.429982	2026-06-26 09:35:30	2026-06-26 01:34:58	\N	\N	\N	\N	\N	\N	\N	\N	1	1	none	20	N	\N	\N	\N	\N	2026-06-26 09:35:30	2026-06-26 09:35:30	\N	\N
400	20260628093722986540	18888889999	516	16	22	1234	20	3	2026-06-28 09:37:22.654169	2026-06-29 08:51:01	2026-06-28 09:37:22.650293	\N	\N	\N	\N	4200003191202606283617596483	\N	2026-06-28 09:37:42.630942	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-29 08:51:01	2026-06-29 08:51:01		\N
368	20260627100422451091	18888889999	\N	16	42	1234	20	3	2026-06-27 10:04:22.568878	2026-06-27 12:41:16	2026-06-27 10:04:22.56541	\N	\N	\N	\N	4200003132202606278136500376	\N	2026-06-27 10:05:21.590954	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-27 12:41:16	2026-06-27 12:41:16	\N	\N
302	20260626065241645773	17725196748	\N	8	A40	1234	20	3	2026-06-26 06:52:41.110615	2026-06-26 09:25:55	2026-06-25 22:52:41	\N	\N	\N	\N	4200003206202606266399413240	\N	2026-06-26 06:56:19.145714	\N	1	1	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N	\N
390	20260628075013324398	18888889999	508	16	14	1234	20	3	2026-06-28 07:50:13.359321	2026-06-28 07:50:13.355498	2026-06-28 07:50:13.355498	\N	\N	\N	\N	4200003179202606284370748705	\N	2026-06-28 07:50:38.542911	2026-06-30 12:29:58.796656	\N	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
503	20260630123932308808	15550752925	623	24	E33	2925	20	3	2026-06-30 12:39:32.545394	2026-06-30 12:39:32.523626	2026-06-30 12:39:32.523626	\N	\N	\N	\N	4200003197202606308771166775	\N	2026-06-30 12:40:01.370608	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
537	20260630141613856704	15254409526	591	24	E1	9526	20	4	2026-06-30 14:16:13.618081	2026-06-30 17:09:24	2026-06-30 14:16:13.598124	\N	\N	\N	\N	4200003211202606304706104835	\N	2026-06-30 14:16:30.087308	2026-06-30 17:09:32.775869	1	1	refunded	20	N	\N	\N	\N	\N	2026-06-30 17:09:24	2026-06-30 17:09:24		\N
535	20260630141511676928	15225299085	653	24	E63	1479	20	3	2026-06-30 14:15:11.916386	2026-06-30 16:18:10.688146	2026-06-30 14:15:11.894956	\N	\N	\N	\N	4200003178202606309902143709	\N	2026-06-30 14:15:36.906924	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
538	20260630141616444325	19137096192	592	24	E2	1223	20	3	2026-06-30 14:16:16.447977	2026-06-30 16:17:34.490627	2026-06-30 14:16:16.427624	\N	\N	\N	\N	4200003131202606303988984290	\N	2026-06-30 14:16:50.133427	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
547	20260630153014147323	15238586310	602	24	E12	2014	20	3	2026-06-30 15:30:14.440812	2026-06-30 16:04:59.130736	2026-06-30 15:30:14.417352	\N	\N	\N	\N	4200003195202606308924862181	\N	2026-06-30 15:30:47.064928	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
543	20260630145256257792	19254304011	597	24	E7	4011	20	2	2026-06-30 14:52:56.59766	\N	2026-06-30 14:52:56.578078	\N	\N	\N	\N	4200003178202606304648003361	\N	2026-06-30 14:53:12.791167	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
546	20260630152726665334	15324821187	601	24	E11	1013	20	3	2026-06-30 15:27:26.746166	2026-06-30 16:10:06.63983	2026-06-30 15:27:26.724031	\N	\N	\N	\N	4200003183202606304945740720	\N	2026-06-30 15:27:44.656396	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
539	20260630141812626447	19544562686	593	24	E3	1234	20	3	2026-06-30 14:18:12.222058	2026-06-30 16:10:29.361524	2026-06-30 14:18:12.201694	\N	\N	\N	\N	4200003115202606301960636307	\N	2026-06-30 14:18:37.078692	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
550	20260630170632583423	13667618419	526	16	B32	1234	20	4	2026-06-30 17:06:32.680209	2026-06-30 18:01:54.880741	2026-06-30 17:06:32.658578	\N	\N	\N	\N	4200003222202606308558391939	50301907932026063088068532403	2026-06-30 17:06:55.328244	2026-06-30 18:20:03.547609	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
548	TEST20260630153711	17726689234	506	16	12	TEST123	20	4	2026-06-30 15:37:11.452908	2026-06-30 15:37:21.900677	2026-06-30 15:37:11.452908	\N	CAB20260625181326	\N	M	\N	\N	2026-06-30 15:37:11.452908	2026-06-30 15:39:03.427119	1	1	1	20	N	\N	\N	\N	\N	\N	2026-06-30 15:39:03.427119	\N	\N
534	20260630141509083244	15225299085	652	24	E62	1479	20	6	2026-06-30 14:15:09.834706	\N	2026-06-30 14:15:09.814559	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
541	20260630144750539670	17837383155	595	24	E5	1111	20	3	2026-06-30 14:47:50.589861	2026-06-30 15:53:14.208293	2026-06-30 14:47:50.569696	\N	\N	\N	\N	4200003222202606307073662743	\N	2026-06-30 14:48:09.042125	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
549	20260630155114892074	15656087879	603	24	E13	0808	20	3	2026-06-30 15:51:14.350607	2026-06-30 18:23:09.845366	2026-06-30 15:51:14.330299	\N	\N	\N	\N	4200003165202606304574377209	\N	2026-06-30 15:51:36.239475	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
545	20260630152451000570	15836435632	599	24	E9	1128	20	4	2026-06-30 15:24:51.048001	2026-06-30 16:09:27.308745	2026-06-30 15:24:51.027615	\N	\N	\N	\N	4200003117202606305680864882	\N	2026-06-30 15:25:19.229084	2026-06-30 17:26:27.645257	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N		\N
536	20260630141515902584	15254409526	654	24	E64	9526	20	6	2026-06-30 14:15:15.98513	\N	2026-06-30 14:15:15.964006	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
552	20260630180307403175	17726689234	496	16	B2	1234	20	6	2026-06-30 18:03:07.187152	\N	2026-06-30 18:03:07.180765	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
557	20260630185423888477	17726689234	502	16	B8	1234	20	6	2026-06-30 18:54:23.86502	\N	2026-06-30 18:54:23.860118	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
556	20260630184408267234	17726689234	501	16	B7	1234	20	4	2026-06-30 18:44:08.337573	2026-06-30 18:45:23.614578	2026-06-30 18:44:08.333052	\N	\N	\N	\N	4200003127202606301108384981	50302107702026063045282922691	2026-06-30 18:44:45.936285	2026-06-30 19:50:31.358649	1	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
551	20260630171440638549	17726689234	495	16	B1	1234	20	4	2026-06-30 17:14:40.953679	2026-06-30 18:01:14.416481	2026-06-30 17:14:40.926802	\N	\N	\N	\N	4200003194202606303961998936	50301607892026063088905827155	2026-06-30 17:15:14.066993	2026-06-30 18:18:41.678075	1	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
553	20260630180308393971	17726689234	497	16	B3	1234	20	4	2026-06-30 18:03:08.846984	2026-06-30 18:04:49.5678	2026-06-30 18:03:08.84262	\N	\N	\N	\N	4200003166202606301245248017	50301707692026063008618973650	2026-06-30 18:03:26.071888	2026-06-30 18:18:45.677994	3	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
555	20260630180349917874	17726689234	500	16	B6	1234	20	4	2026-06-30 18:03:49.221853	2026-06-30 18:04:46.043121	2026-06-30 18:03:49.216679	\N	\N	\N	\N	4200003195202606307167196149	50302907982026063000954853964	2026-06-30 18:04:04.46539	2026-06-30 18:18:50.742941	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
558	20260630185425159147	17726689234	503	16	B9	1234	20	4	2026-06-30 18:54:25.129048	2026-06-30 18:56:02.171276	2026-06-30 18:54:25.125252	\N	\N	\N	\N	4200003110202606309731825407	50300707802026063096662335272	2026-06-30 18:55:37.177167	2026-06-30 19:50:35.233245	3	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
11	20260612215049196096	13667618419	4	1	4	1234	20	6	2026-06-12 21:50:49.478714	\N	2026-06-12 13:50:49	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
12	20260612215241961752	13667618419	4	1	4	1234	20	6	2026-06-12 21:52:41.378657	\N	2026-06-12 13:52:41	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
13	20260612215243412736	13667618419	4	1	4	1234	20	6	2026-06-12 21:52:43.190793	\N	2026-06-12 13:52:43	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
14	20260612220410413004	13667618419	4	1	4	1234	20	6	2026-06-12 22:04:10.832917	\N	2026-06-12 14:04:10	\N	\N	\N	\N	MOCK20260612220412535185	\N	2026-06-12 22:04:12.482515	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
15	20260612220646836729	13667619418	5	1	5	1234	20	6	2026-06-12 22:06:46.722765	\N	2026-06-12 14:06:46	\N	\N	\N	\N	MOCK20260612220648303668	\N	2026-06-12 22:06:48.35446	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
16	20260612221713749602	13667619418	6	1	6	1234	20	6	2026-06-12 22:17:13.723193	\N	2026-06-12 14:17:13	\N	\N	\N	\N	MOCK20260612221715620901	\N	2026-06-12 22:17:15.374401	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
17	20260613070525557123	13667618419	7	1	7	1234	20	6	2026-06-13 07:05:25.574644	\N	2026-06-12 23:05:25	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
18	20260613071529364557	13667619418	7	1	7	1234	20	6	2026-06-13 07:15:29.564058	\N	2026-06-12 23:15:29	\N	\N	\N	\N	MOCK20260613071531279605	\N	2026-06-13 07:15:31.12188	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
19	20260613084316775983	13667618419	8	1	8	1234	20	6	2026-06-13 08:43:16.360938	\N	2026-06-13 00:43:16	\N	\N	\N	\N	MOCK20260613084317461012	\N	2026-06-13 08:43:17.926972	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
20	20260613084722495070	13667618419	9	1	9	1234	20	6	2026-06-13 08:47:22.984184	\N	2026-06-13 00:47:22	\N	\N	\N	\N	MOCK20260613084724403496	\N	2026-06-13 08:47:24.553551	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
21	20260613084812016560	18996093393	10	1	10	1234	20	6	2026-06-13 08:48:12.982301	\N	2026-06-13 00:48:12	\N	\N	\N	\N	MOCK20260613084814527585	\N	2026-06-13 08:48:14.541599	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
22	20260613084905903310	18996093393	11	1	11	1234	20	6	2026-06-13 08:49:05.895363	\N	2026-06-13 00:49:05	\N	\N	\N	\N	MOCK20260613084907298375	\N	2026-06-13 08:49:07.467623	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
23	20260613085201409181	18996093393	12	1	12	1234	20	6	2026-06-13 08:52:01.526147	\N	2026-06-13 00:52:01	\N	\N	\N	\N	MOCK20260613085203062507	\N	2026-06-13 08:52:03.085261	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
24	20260613092059472982	13667618419	1	1	1	1234	20	6	2026-06-13 09:20:59.159071	\N	2026-06-13 01:20:59	\N	\N	\N	\N	MOCK20260613092100550571	\N	2026-06-13 09:21:00.710869	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
26	20260613103608102085	13667618419	3	1	3	1234	20	6	2026-06-13 10:36:08.034442	2026-06-20 07:45:34	2026-06-13 02:36:08	\N	\N	\N	\N	MOCK20260613103609423697	\N	2026-06-13 10:36:09.620615	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
27	20260613103836064964	13667618419	4	1	4	1234	20	6	2026-06-13 10:38:36.153748	2026-06-20 07:45:34	2026-06-13 02:38:36	\N	\N	\N	\N	MOCK20260613103837623027	\N	2026-06-13 10:38:37.746003	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
31	20260613110035310163	13667618419	7	1	7	1245	20	6	2026-06-13 11:00:35.50103	2026-06-20 07:45:34	2026-06-13 03:00:35	\N	\N	\N	\N	MOCK20260613110037508854	\N	2026-06-13 11:00:37.0886	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
32	20260613110923352760	13667618491	8	1	8	1234	20	6	2026-06-13 11:09:23.383141	2026-06-20 07:45:34	2026-06-13 03:09:23	\N	\N	\N	\N	MOCK20260613110924025926	\N	2026-06-13 11:09:24.983525	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
36	20260613112745200041	13667618419	12	1	12	1234	20	6	2026-06-13 11:27:45.113944	\N	2026-06-13 03:27:45	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
37	20260613112747117782	13667618419	12	1	12	1234	20	6	2026-06-13 11:27:47.536917	\N	2026-06-13 03:27:47	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
38	20260613121913870418	13667618419	12	1	12	1234	20	6	2026-06-13 12:19:13.615272	\N	2026-06-13 04:19:13	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
39	20260613122824572046	13667618419	12	1	12	1234	20	6	2026-06-13 12:28:24.017606	\N	2026-06-13 04:28:24	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
40	20260613122900360737	13667164843	12	1	12	1234	20	6	2026-06-13 12:29:00.764583	\N	2026-06-13 04:29:00	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
41	20260613130407011443	13667618419	12	1	12	1234	20	6	2026-06-13 13:04:07.511063	\N	2026-06-13 05:04:07	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
42	20260613130820751960	13667618419	12	1	12	1234	20	6	2026-06-13 13:08:20.736987	\N	2026-06-13 05:08:20	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
43	20260613130825632693	13667618419	12	1	12	1234	20	6	2026-06-13 13:08:25.150539	\N	2026-06-13 05:08:25	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
44	20260613131835570416	13667618419	12	1	12	1234	20	6	2026-06-13 13:18:35.510589	\N	2026-06-13 05:18:35	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
388	20260628072555783397	18888889999	506	16	12	1234	20	6	2026-06-28 07:25:55.756408	\N	2026-06-28 07:25:55.752303	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
398	20260628093340043922	18888889999	514	16	20	1234	20	6	2026-06-28 09:33:40.390696	\N	2026-06-28 09:33:40.386839	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
389	20260628074940785789	18888889999	507	16	13	1234	20	6	2026-06-28 07:49:40.541368	\N	2026-06-28 07:49:40.537811	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
395	20260628084040740119	17722332233	511	16	17	2354	20	6	2026-06-28 08:40:40.59985	\N	2026-06-28 08:40:40.596079	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
381	20260627160609859877	18888889999	501	16	7	1234	20	6	2026-06-27 16:06:09.568076	\N	2026-06-27 16:06:09.564124	\N	\N	\N	\N	4200003194202606274482878253	\N	2026-06-27 16:06:33.756775	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
393	20260628083429993292	18983079797	467	15	5	1111	1	6	2026-06-28 08:34:29.816315	\N	2026-06-28 08:34:29.81235	\N	\N	\N	\N	4200003127202606285009377611	\N	2026-06-28 08:35:13.935168	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
326	20260626151140780127	18888889999	\N	16	19	1234	20	6	2026-06-26 15:11:40.037844	\N	2026-06-26 07:11:40	\N	\N	\N	\N	4200003196202606264025106289	\N	2026-06-26 15:15:59.100626	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
330	20260626154702233246	18888889999	\N	16	21	1234	20	6	2026-06-26 15:47:02.451091	\N	2026-06-26 07:47:02	\N	\N	\N	\N	4200003208202606261431066067	\N	2026-06-26 15:47:09.175571	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
410	20260629170404632021	13667618419	524	16	30	1234	20	6	2026-06-29 17:04:04.210828	\N	2026-06-29 17:04:04.208379	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
416	20260629222655028517	13667618419	497	16	3	1234	20	6	2026-06-29 22:26:55.000734	\N	2026-06-29 22:26:54.998073	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
420	20260629224617311163	13667618419	501	16	7	1234	20	6	2026-06-29 22:46:17.542997	\N	2026-06-29 22:46:17.540594	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
425	20260629230205606790	13667618419	506	16	12	1234	20	6	2026-06-29 23:02:05.710518	\N	2026-06-29 23:02:05.708504	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
402	20260628095005403739	18888889999	518	16	24	1234	20	6	2026-06-28 09:50:05.573443	\N	2026-06-28 09:50:05.569659	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
350	20260626202216294000	17722332233	\N	16	29	1245	20	6	2026-06-26 20:22:16.432857	\N	2026-06-26 20:22:16.429379	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
372	20260627112151525591	18996093393	463	15	1	1111	1	6	2026-06-27 11:21:51.071583	\N	2026-06-27 11:21:51.067519	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
380	20260627160102439699	18888889999	500	16	6	1234	20	6	2026-06-27 16:01:02.420536	\N	2026-06-27 16:01:02.416518	\N	\N	\N	\N	4200003186202606272613703359	\N	2026-06-27 16:01:17.946145	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
384	20260627163808998198	18888889999	504	16	10	1234	20	6	2026-06-27 16:38:08.255333	\N	2026-06-27 16:38:08.251689	\N	\N	\N	\N	4200003137202606271203499467	\N	2026-06-27 16:38:26.498928	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
382	20260627161116110216	18888889999	502	16	8	1234	20	6	2026-06-27 16:11:16.267593	\N	2026-06-27 16:11:16.264003	\N	\N	\N	\N	4200003222202606276645933201	\N	2026-06-27 16:11:33.379517	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
399	20260628093341461556	18888889999	515	16	21	1234	20	6	2026-06-28 09:33:41.75497	\N	2026-06-28 09:33:41.751031	\N	\N	\N	\N	4200003177202606285617651946	\N	2026-06-28 09:34:39.676769	\N	\N	0	none	0	N	Y	\N	\N	\N	\N	\N		\N
328	20260626152942192997	18888889999	\N	16	20	1234	20	6	2026-06-26 15:29:42.720861	\N	2026-06-26 07:29:42	\N	\N	\N	\N	4200003223202606261012234681	\N	2026-06-26 17:34:14.73608	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
417	20260629223533749920	13667618419	498	16	4	1234	20	6	2026-06-29 22:35:33.077402	\N	2026-06-29 22:35:33.075122	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
421	20260629225047821789	13667618419	502	16	8	1234	20	6	2026-06-29 22:50:47.767002	\N	2026-06-29 22:50:47.764728	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
428	20260630065051608708	13667618419	509	16	15	1234	20	6	2026-06-30 06:50:51.28454	\N	2026-06-30 06:50:51.281642	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
430	20260630070643047439	13667618419	511	16	17	1234	20	6	2026-06-30 07:06:43.327658	\N	2026-06-30 07:06:43.306865	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
426	20260630063933061814	13667618419	507	16	13	1234	20	6	2026-06-30 06:39:33.587101	\N	2026-06-30 06:39:33.577984	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
431	20260630070730730437	13667618419	512	16	18	1234	20	6	2026-06-30 07:07:30.254063	\N	2026-06-30 07:07:30.233976	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
434	20260630071035123288	13667618419	515	16	21	1234	20	6	2026-06-30 07:10:35.056985	\N	2026-06-30 07:10:35.034903	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
336	20260626191339113080	13800138000	\N	16	17	4656	20	6	2026-06-26 19:13:39.495277	\N	2026-06-26 19:13:39.492373	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
338	20260626192430918322	13800138001	\N	16	18	3736	20	6	2026-06-26 19:24:30.878316	\N	2026-06-26 19:24:30.857027	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
339	20260626192804780540	13900001111	\N	16	23	5390	20	6	2026-06-26 19:28:04.597972	\N	2026-06-26 19:28:04.59467	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
340	20260626193319662087	18888889999	\N	16	1	1234	20	6	2026-06-26 19:33:19.501948	\N	2026-06-26 19:33:19.498629	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
341	20260626193410828034	18888889999	\N	16	24	1234	20	6	2026-06-26 19:34:10.658355	\N	2026-06-26 19:34:10.655079	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
342	20260626193558073778	18888889999	\N	16	25	1234	20	6	2026-06-26 19:35:58.396973	\N	2026-06-26 19:35:58.393778	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
343	20260626193718480697	18888889999	\N	16	10	1234	20	6	2026-06-26 19:37:18.787223	\N	2026-06-26 19:37:18.783864	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
344	20260626194126519853	13800138002	\N	16	26	0774	20	6	2026-06-26 19:41:26.945445	\N	2026-06-26 19:41:26.942187	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
345	20260626195113492844	18888889999	\N	16	11	1234	20	6	2026-06-26 19:51:13.399607	\N	2026-06-26 19:51:13.396408	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
346	20260626195223936759	18888889999	\N	16	12	1234	20	6	2026-06-26 19:52:23.95039	\N	2026-06-26 19:52:23.946807	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
348	20260626201308102505	18888889999	\N	16	27	1234	20	6	2026-06-26 20:13:08.194187	\N	2026-06-26 20:13:08.190781	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
349	20260626201940213728	17722332233	\N	16	28	1234	20	6	2026-06-26 20:19:40.70182	\N	2026-06-26 20:19:40.698743	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
351	20260626202221883459	17722332233	\N	16	30	1245	20	6	2026-06-26 20:22:21.872984	\N	2026-06-26 20:22:21.869637	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
371	20260627104626280493	18888889999	\N	16	45	1475	20	6	2026-06-27 10:46:26.963353	\N	2026-06-27 10:46:26.959998	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
354	20260626204829842556	18996093393	\N	16	15	1111	20	6	2026-06-26 20:48:29.40273	\N	2026-06-26 20:48:29.399371	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
355	20260626204928378750	18888889999	\N	16	32	4234	20	6	2026-06-26 20:49:28.016012	\N	2026-06-26 20:49:28.01245	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
356	20260626205722591084	18888889999	\N	16	33	1234	20	6	2026-06-26 20:57:22.848096	\N	2026-06-26 20:57:22.844854	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
369	20260627100946811350	18888889999	\N	16	43	1234	20	6	2026-06-27 10:09:46.860479	\N	2026-06-27 10:09:46.857228	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
370	20260627102739798588	18888889999	\N	16	44	1234	20	6	2026-06-27 10:27:39.670587	\N	2026-06-27 10:27:39.667024	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
378	20260627155334919055	18888889999	498	16	4	1234	20	6	2026-06-27 15:53:34.571293	\N	2026-06-27 15:53:34.567167	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
375	20260627122904914170	18888889999	495	16	1	1234	20	6	2026-06-27 12:29:04.585367	\N	2026-06-27 12:29:04.572968	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
383	20260627163807021258	18888889999	503	16	9	1234	20	6	2026-06-27 16:38:07.045946	\N	2026-06-27 16:38:07.041968	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
377	20260627130236007300	18888889999	497	16	3	1234	20	6	2026-06-27 13:02:36.062128	\N	2026-06-27 13:02:36.058429	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
387	20260628072554852730	18888889999	505	16	11	1234	20	6	2026-06-28 07:25:54.935084	\N	2026-06-28 07:25:54.93125	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
419	20260629223559729793	13667618419	500	16	6	1234	20	6	2026-06-29 22:35:59.036901	\N	2026-06-29 22:35:59.035049	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
394	20260628084016662738	17722332233	510	16	16	2588	20	6	2026-06-28 08:40:16.371355	\N	2026-06-28 08:40:16.367515	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
415	20260629222652794945	13667618419	496	16	2	1234	20	6	2026-06-29 22:26:52.299234	\N	2026-06-29 22:26:52.296863	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
404	TEST_WT_0628	test_wt	463	15	\N	\N	20	6	\N	\N	2026-06-28 11:33:39.969283	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
409	20260629170342553990	13667618419	523	16	29	1234	20	6	2026-06-29 17:03:42.260507	\N	2026-06-29 17:03:42.258189	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
418	20260629223538515574	13667618419	499	16	5	1234	20	6	2026-06-29 22:35:38.413539	\N	2026-06-29 22:35:38.411252	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
423	20260629225222984163	13667618419	504	16	10	1234	20	6	2026-06-29 22:52:22.086876	\N	2026-06-29 22:52:22.084483	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
427	20260630063935281541	13667618419	508	16	14	1234	20	6	2026-06-30 06:39:35.989953	\N	2026-06-30 06:39:35.986773	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
429	20260630070642908855	13667618419	510	16	16	1234	20	6	2026-06-30 07:06:42.091909	\N	2026-06-30 07:06:42.07008	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
433	20260630071033696613	13667618419	514	16	20	1234	20	6	2026-06-30 07:10:33.099814	\N	2026-06-30 07:10:33.079226	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
435	20260630071058356302	17726689234	516	16	22	1234	20	6	2026-06-30 07:10:58.610157	\N	2026-06-30 07:10:58.588917	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
437	20260630071507553700	17726689234	518	16	24	1234	20	6	2026-06-30 07:15:07.363449	\N	2026-06-30 07:15:07.341874	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
445	20260630085756017086	17726689234	525	16	31	1234	20	6	2026-06-30 08:57:56.901991	\N	2026-06-30 08:57:56.881607	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
446	20260630085801813148	18996093393	593	24	E3	1234	20	6	2026-06-30 08:58:01.881999	\N	2026-06-30 08:58:01.861605	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
447	20260630085805885573	18996093393	594	24	E4	1234	20	6	2026-06-30 08:58:05.915437	\N	2026-06-30 08:58:05.894841	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
448	20260630085950797365	18996093393	595	24	E5	1234	20	6	2026-06-30 08:59:50.382002	\N	2026-06-30 08:59:50.361668	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
449	20260630085953428673	18996093393	596	24	E6	1234	20	6	2026-06-30 08:59:53.41698	\N	2026-06-30 08:59:53.39626	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
450	20260630090224509718	17726689234	526	16	32	1234	20	6	2026-06-30 09:02:24.402191	\N	2026-06-30 09:02:24.38221	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
451	20260630090226033013	17726689234	495	16	1	1234	20	6	2026-06-30 09:02:26.442095	\N	2026-06-30 09:02:26.422221	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
452	20260630090227228838	17726689234	496	16	2	1234	20	6	2026-06-30 09:02:28.008314	\N	2026-06-30 09:02:27.987509	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
455	20260630090820660394	13667618419	497	16	3	1234	20	6	2026-06-30 09:08:20.677812	\N	2026-06-30 09:08:20.657041	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
465	20260630093503962080	17726689234	505	16	11	4265	20	6	2026-06-30 09:35:03.118492	\N	2026-06-30 09:35:03.098415	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
466	20260630093601674282	18996093393	602	24	E12	1234	20	6	2026-06-30 09:36:01.802147	\N	2026-06-30 09:36:01.781713	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
467	20260630093634430615	18996093393	603	24	E13	1234	20	6	2026-06-30 09:36:34.401984	\N	2026-06-30 09:36:34.376817	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
459	20260630091347299770	17726689234	500	16	6	1334	20	6	2026-06-30 09:13:47.322265	\N	2026-06-30 09:13:47.301857	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
460	20260630091349221251	17726689234	501	16	7	1334	20	6	2026-06-30 09:13:49.446351	\N	2026-06-30 09:13:49.426301	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
468	20260630093738137985	18996093393	604	24	E14	1234	20	6	2026-06-30 09:37:38.799379	\N	2026-06-30 09:37:38.778209	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
462	20260630093241372386	17726689234	502	16	8	1234	20	6	2026-06-30 09:32:41.576066	\N	2026-06-30 09:32:41.555195	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
463	20260630093243011302	17726689234	503	16	9	1234	20	6	2026-06-30 09:32:43.809665	\N	2026-06-30 09:32:43.788982	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
464	20260630093501068353	17726689234	504	16	10	4265	20	6	2026-06-30 09:35:01.831719	\N	2026-06-30 09:35:01.809229	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
458	20260630091211403812	17726689234	499	16	5	4234	20	6	2026-06-30 09:12:11.240047	2026-06-30 11:22:12.951859	2026-06-30 09:12:11.22009	\N	\N	\N	\N	4200003097202606307976765838	\N	2026-06-30 09:13:28.184024	2026-06-30 12:29:58.796656	3	0	none	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548		\N
473	20260630094822889245	18996093393	609	24	E19	2222	20	6	2026-06-30 09:48:22.940715	\N	2026-06-30 09:48:22.919125	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
471	20260630094749862309	18996093393	607	24	E17	1234	20	6	2026-06-30 09:47:49.247963	\N	2026-06-30 09:47:49.228188	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
472	20260630094821708547	18996093393	608	24	E18	2222	20	6	2026-06-30 09:48:21.204475	\N	2026-06-30 09:48:21.184368	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
475	20260630094953123883	17726689234	508	16	14	4265	20	6	2026-06-30 09:49:53.177996	\N	2026-06-30 09:49:53.157435	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
476	20260630095007916175	17726689234	509	16	15	1234	20	6	2026-06-30 09:50:07.257393	\N	2026-06-30 09:50:07.236978	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
477	20260630095008663365	18983079797	610	24	E20	1111	20	6	2026-06-30 09:50:08.241495	\N	2026-06-30 09:50:08.221215	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
478	20260630095010300087	17726689234	510	16	16	1234	20	6	2026-06-30 09:50:10.031311	\N	2026-06-30 09:50:10.010596	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
474	20260630094951047760	17726689234	507	16	13	4265	20	6	2026-06-30 09:49:51.489911	\N	2026-06-30 09:49:51.469002	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
479	20260630095010433885	18983079797	611	24	E21	1111	20	6	2026-06-30 09:50:10.096902	\N	2026-06-30 09:50:10.07607	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
513	20260630125030564040	18996093393	633	24	E43	1234	20	6	2026-06-30 12:50:30.321853	\N	2026-06-30 12:50:30.3021	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
515	20260630125114471293	18265005796	635	24	E45	7878	20	6	2026-06-30 12:51:14.139372	\N	2026-06-30 12:51:14.11901	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
518	20260630130448073613	19286022436	638	24	E48	6666	20	6	2026-06-30 13:04:48.737368	\N	2026-06-30 13:04:48.715871	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
520	20260630131250831176	18637010208	640	24	E50	1111	20	6	2026-06-30 13:12:51.00117	\N	2026-06-30 13:12:50.980951	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
522	20260630132911138554	15275043796	642	24	E52	8011	20	6	2026-06-30 13:29:11.384382	\N	2026-06-30 13:29:11.363537	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
525	20260630133402865557	15138943614	645	24	E55	5219	20	6	2026-06-30 13:34:02.357993	\N	2026-06-30 13:34:02.338278	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
530	20260630134559767386	17726689234	525	16	31	1234	20	6	2026-06-30 13:45:59.983915	2026-06-30 13:45:59.962796	2026-06-30 13:45:59.962796	\N	\N	\N	\N	4200003194202606305055023900	50302007902026063036986140386	2026-06-30 13:46:20.422718	2026-06-30 14:27:50.370046	2	1	none	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548		\N
527	20260630134553969464	18953074181	647	24	E57	1234	20	6	2026-06-30 13:45:53.406087	\N	2026-06-30 13:45:53.38596	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
531	20260630134843793039	13791463202	649	24	E59	1234	20	6	2026-06-30 13:48:43.364036	\N	2026-06-30 13:48:43.342725	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
540	20260630144746251413	17837383155	594	24	E4	1111	20	6	2026-06-30 14:47:47.005982	\N	2026-06-30 14:47:46.985008	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
542	20260630145254758641	19254304011	596	24	E6	4011	20	6	2026-06-30 14:52:54.495493	\N	2026-06-30 14:52:54.474679	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
544	20260630151521429160	15836435632	598	24	E8	1128	20	6	2026-06-30 15:15:22.008901	\N	2026-06-30 15:15:21.987843	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
481	20260630095414309240	17726689234	512	16	18	1234	20	6	2026-06-30 09:54:14.221902	2026-06-30 09:54:14.202174	2026-06-30 09:54:14.202174	\N	\N	\N	\N	4200003188202606309691633192	\N	2026-06-30 09:54:35.340731	2026-06-30 12:29:58.796656	2	0	none	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548		\N
488	20260630105405124207	17726689234	517	16	23	1234	20	6	2026-06-30 10:54:05.502862	2026-06-30 10:54:05.48182	2026-06-30 10:54:05.48182	\N	\N	\N	\N	4200003186202606300773799142	\N	2026-06-30 10:54:40.858662	2026-06-30 12:29:58.796656	2	0	none	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548		\N
487	20260630101943467907	17726689234	516	16	22	1234	20	6	2026-06-30 10:19:43.691053	2026-06-30 10:19:43.670884	2026-06-30 10:19:43.670884	\N	\N	\N	\N	4200003106202606308927643382	\N	2026-06-30 10:20:03.524516	2026-06-30 12:29:58.796656	3	0	none	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548		\N
492	20260630110420701345	17726689234	521	16	27	1234	20	6	2026-06-30 11:04:20.348808	2026-06-30 11:04:20.327317	2026-06-30 11:04:20.327317	\N	\N	\N	\N	4200003130202606306918520781	\N	2026-06-30 11:04:39.110419	2026-06-30 12:29:58.796656	1	0	none	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548		\N
497	20260630114500326407	17726689234	523	16	29	1234	20	6	2026-06-30 11:45:00.055863	2026-06-30 11:45:00.034393	2026-06-30 11:45:00.034393	\N	\N	\N	\N	4200003121202606303979181027	\N	2026-06-30 11:45:16.979316	2026-06-30 12:29:58.796656	3	0	none	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548		\N
554	20260630180347696805	17726689234	498	16	B4	1234	20	6	2026-06-30 18:03:47.296934	\N	2026-06-30 18:03:47.293611	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
\.


--
-- Data for Name: payment_channels; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.payment_channels (id, name, channel_type, mch_id, api_key, app_id, app_secret, cert_name, extra_config, is_active, weight, daily_limit, total_amount, total_count, last_used_at, created_at, rotation_index, cert_serial_no) FROM stdin;
1	微信支付-主商户	wechat	1113658351	lichengju0904LICHENGJU0904libp98	wxd85204d0ec930d46	e2f27e35864226bf2668643b27f149d9	apiclient	\N	1	1	0	1020	51	2026-06-30 18:44:45.944054	2026-06-12 07:00:31	0	39B1456463F2857B9B1F762C2D10D7B104E008FD
3	微信支付-商户3	wechat	1746577840	lichengju0904LICHENGJU0904libp98	wxd85204d0ec930d46	e2f27e35864226bf2668643b27f149d9	1746577840	\N	1	1	0	820	41	2026-06-30 18:55:37.186096	2026-06-12 07:00:31	0	21623753D8FD8C3B4112CC04409397ADA7F1B15A
5	微信支付-商户4	wechat	1747572495	lichengju0904LICHENGJU0904libaip	wxd85204d0ec930d46	552e27fa9a260a6640bf6983bd3470f5	1747572495	\N	1	1	0	20	9	2026-06-30 21:48:30.927902	2026-06-30 08:15:38.051917	0	62E70B19EA3A009D9293DF05CCDDECD516170DDF
2	微信支付-商户2	wechat	1745738973	lichengju0904LICHENGJU0904libp98	wxd85204d0ec930d46	e2f27e35864226bf2668643b27f149d9	1745738973	\N	1	1	0	1060	53	2026-06-30 22:56:43.748197	2026-06-12 07:00:31	0	280C9268D8D09D8ECAF32D552CF5B7BA72D2F737
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.payments (id, order_id, type, amount, transaction_id, status, created_at, refund_transaction_id) FROM stdin;
1	3	1	20	MOCK20260612123731687721	1	2026-06-12 04:37:31	\N
2	4	1	20	MOCK20260612124112354956	1	2026-06-12 04:41:12	\N
3	5	1	20	MOCK20260612125239933782	1	2026-06-12 04:52:39	\N
4	5	2	20	\N	1	2026-06-12 04:52:39	MOCK_R20260612125239053174
5	6	1	20	MOCK20260612125721052779	1	2026-06-12 04:57:21	\N
6	8	1	20	MOCK20260612125806736595	1	2026-06-12 04:58:06	\N
7	8	2	20	\N	1	2026-06-12 04:58:06	MOCK_R20260612125806149070
8	9	1	20	MOCK20260612130727077299	1	2026-06-12 05:07:27	\N
9	9	2	20	\N	1	2026-06-12 05:07:27	MOCK_R20260612130727819069
10	14	1	20	MOCK20260612220412535185	1	2026-06-12 14:04:12	\N
11	15	1	20	MOCK20260612220648303668	1	2026-06-12 14:06:48	\N
12	16	1	20	MOCK20260612221715620901	1	2026-06-12 14:17:15	\N
13	18	1	20	MOCK20260613071531279605	1	2026-06-12 23:15:31	\N
14	19	1	20	MOCK20260613084317461012	1	2026-06-13 00:43:17	\N
15	20	1	20	MOCK20260613084724403496	1	2026-06-13 00:47:24	\N
16	21	1	20	MOCK20260613084814527585	1	2026-06-13 00:48:14	\N
17	22	1	20	MOCK20260613084907298375	1	2026-06-13 00:49:07	\N
18	23	1	20	MOCK20260613085203062507	1	2026-06-13 00:52:03	\N
19	24	1	20	MOCK20260613092100550571	1	2026-06-13 01:21:00	\N
20	25	1	20	MOCK20260613103519579330	1	2026-06-13 02:35:19	\N
21	26	1	20	MOCK20260613103609423697	1	2026-06-13 02:36:09	\N
22	27	1	20	MOCK20260613103837623027	1	2026-06-13 02:38:37	\N
23	28	1	20	MOCK20260613103958690879	1	2026-06-13 02:39:58	\N
25	29	1	20	MOCK20260613105402524401	1	2026-06-13 02:54:02	\N
26	30	1	20	MOCK20260613105457264570	1	2026-06-13 02:54:57	\N
27	31	1	20	MOCK20260613110037508854	1	2026-06-13 03:00:37	\N
28	32	1	20	MOCK20260613110924025926	1	2026-06-13 03:09:24	\N
29	33	1	20	MOCK20260613111341731060	1	2026-06-13 03:13:41	\N
30	34	1	20	MOCK20260613111951029532	1	2026-06-13 03:19:51	\N
31	35	1	20	MOCK20260613112010821772	1	2026-06-13 03:20:10	\N
32	35	2	20	\N	0	2026-06-13 08:54:54	\N
33	74	1	20	MOCK20260615195200058468	1	2026-06-15 11:52:00	\N
34	75	1	20	MOCK20260615212238084163	1	2026-06-15 13:22:38	\N
35	78	1	20	4200003197202606157747962293	1	2026-06-15 14:47:03	\N
36	79	1	20	4200003209202606156654791224	1	2026-06-15 14:51:32	\N
37	81	1	20	4200003196202606163226158236	1	2026-06-16 02:09:38	\N
38	82	1	20	4200003129202606161854087446	1	2026-06-16 02:26:35	\N
39	84	1	20	4200003189202606165694456320	1	2026-06-16 03:26:32	\N
40	87	1	20	4200003131202606165905503583	1	2026-06-16 04:28:08	\N
41	88	1	20	4200003136202606165732011683	1	2026-06-16 04:28:56	\N
42	90	1	20	4200003223202606162762774344	1	2026-06-16 05:10:46	\N
43	92	1	20	4200003125202606166578988744	1	2026-06-16 06:43:56	\N
44	93	1	20	4200003187202606163240242798	1	2026-06-16 06:45:04	\N
45	94	1	20	4200003203202606160572494080	1	2026-06-16 07:47:24	\N
46	95	1	20	4200003201202606160806649078	1	2026-06-16 08:43:11	\N
47	98	1	20	4200003214202606163984242235	1	2026-06-16 08:56:36	\N
48	101	1	20	4200003211202606161176191397	1	2026-06-16 09:21:57	\N
49	103	1	20	4200003197202606160258458376	1	2026-06-16 12:05:03	\N
50	124	1	20	4200003134202606202313414267	1	2026-06-20 06:38:00	\N
51	124	1	20	4200003134202606202313414267	1	2026-06-20 06:38:31	\N
52	125	1	20	4200003130202606207192208715	1	2026-06-20 07:00:09	\N
53	125	1	20	4200003130202606207192208715	1	2026-06-20 07:00:39	\N
54	126	1	20	4200003214202606203948138371	1	2026-06-20 07:49:10	\N
55	127	1	20	4200003197202606204893669758	1	2026-06-20 07:49:45	\N
56	125	2	20	4200003130202606207192208715	1	2026-06-20 15:56:06.615305	RF20260620155606125
57	124	2	20	4200003134202606202313414267	1	2026-06-20 15:56:10.453777	RF20260620155610124
58	98	2	20	4200003214202606163984242235	1	2026-06-20 17:06:24.13429	RF2026062017062498
59	95	2	20	4200003201202606160806649078	1	2026-06-20 17:09:56.176641	RF2026062017095695
60	94	2	20	4200003203202606160572494080	1	2026-06-20 17:13:56.780917	RF2026062017135694
61	126	2	20	4200003214202606203948138371	1	2026-06-20 17:38:22.569721	RF20260620173821126
62	136	1	20	4200003185202606216413763246	1	2026-06-21 02:01:18	\N
63	138	1	20	4200003215202606211382457072	1	2026-06-21 02:02:57	\N
64	136	2	20	\N	1	2026-06-21 05:48:05	MOCK_R202606211348054318
65	160	1	20	4200003112202606227000683871	1	2026-06-21 23:51:10	\N
66	160	2	20	\N	1	2026-06-22 00:08:44	MOCK_R202606220808448368
67	162	1	20	4200003187202606221169857264	1	2026-06-22 00:59:23	\N
68	162	2	20	\N	1	2026-06-22 00:59:51	MOCK_R202606220859510289
69	163	1	20	4200003207202606223015137996	1	2026-06-22 02:45:24	\N
70	1	2	20	\N	0	2026-06-22 02:58:48	\N
71	1	2	20	\N	0	2026-06-22 03:02:45	\N
72	163	2	20	\N	1	2026-06-22 03:13:11	MOCK_R202606221113118916
73	164	1	20	4200003161202606220715893776	1	2026-06-22 03:45:56	\N
74	164	2	20	\N	1	2026-06-22 03:47:39	MOCK_R202606221147394386
75	165	1	20	4200003190202606223203070588	1	2026-06-22 04:29:23	\N
76	127	2	20	4200003197202606204893669758	1	2026-06-22 17:07:00.18928	RF20260622170659127
77	125	2	20	4200003130202606207192208715	1	2026-06-22 17:34:41.632235	RF20260622173440125
78	167	1	20	4200003213202606228028335181	1	2026-06-22 09:40:59	\N
79	169	1	20	4200003161202606224316828891	1	2026-06-22 10:11:29	\N
80	169	2	20	\N	1	2026-06-22 11:00:19	MOCK_R202606221900190931
81	171	1	20	4200003134202606238092863920	1	2026-06-23 13:46:08	\N
82	171	2	20	\N	1	2026-06-23 13:50:43	MOCK_R202606232150434694
83	172	1	20	4200003205202606239399871354	1	2026-06-23 14:42:29	\N
84	173	1	20	4200003167202606239067117617	1	2026-06-23 15:08:26	\N
85	175	1	20	4200003131202606234724155894	1	2026-06-23 15:10:06	\N
86	176	1	20	4200003183202606237930294670	1	2026-06-23 15:10:25	\N
87	177	1	20	4200003111202606235388301444	1	2026-06-23 15:21:41	\N
88	178	1	20	4200003131202606234306287373	1	2026-06-23 15:22:27	\N
89	177	2	20	\N	1	2026-06-23 15:54:23	MOCK_R202606232354236405
90	180	1	20	4200003186202606245075059432	1	2026-06-23 16:10:24	\N
91	184	1	20	4200003156202606240131921142	1	2026-06-23 22:24:17	\N
92	176	2	20	\N	1	2026-06-23 22:27:19	MOCK_R202606240627196147
93	185	1	20	4200003208202606240871033738	1	2026-06-23 22:42:08	\N
94	175	2	20	\N	1	2026-06-23 23:02:58	MOCK_R202606240702589758
95	186	1	20	4200003187202606241549677511	1	2026-06-23 23:03:56	\N
96	187	1	20	4200003211202606245418929050	1	2026-06-23 23:28:08	\N
97	188	1	20	4200003179202606249375880551	1	2026-06-23 23:47:21	\N
98	189	1	20	4200003141202606247314158381	1	2026-06-23 23:48:53	\N
99	190	1	20	4200003202202606247319480008	1	2026-06-24 00:07:55	\N
100	189	2	20	\N	1	2026-06-24 01:20:47	MOCK_R202606240920470170
101	191	1	20	4200003203202606248887967052	1	2026-06-24 02:25:47	\N
102	191	2	20	\N	1	2026-06-24 02:26:08	MOCK_R202606241026080405
103	193	1	20	4200003118202606243319941721	1	2026-06-24 03:44:11	\N
104	193	2	20	\N	1	2026-06-24 03:45:03	MOCK_R202606241145033822
105	194	1	20	4200003148202606249425682380	1	2026-06-24 03:46:09	\N
106	194	2	20	\N	1	2026-06-24 03:47:04	MOCK_R202606241147049804
107	190	2	20	4200003202202606247319480008	1	2026-06-24 11:58:40.028901	RF20260624115839190
108	195	1	20	4200003136202606242171328386	1	2026-06-24 06:32:58	\N
109	195	1	20	4200003136202606242171328386	1	2026-06-24 06:32:58	\N
110	195	2	20	\N	1	2026-06-24 06:34:57	MOCK_R20260624143457962311
111	196	1	20	4200003184202606249304133409	1	2026-06-24 07:37:45	\N
112	194	2	20	4200003148202606249425682380	1	2026-06-24 19:10:58.366656	RF20260624191057194
113	196	2	20	\N	0	2026-06-24 12:08:58	\N
114	198	1	20	4200003188202606240188305829	1	2026-06-24 14:37:50	\N
115	198	2	20	\N	0	2026-06-24 14:39:50	\N
116	275	1	20	4200003196202606259252043903	1	2026-06-25 09:24:58	\N
117	276	1	20	4200003215202606251844643887	1	2026-06-25 09:39:59	\N
118	277	1	20	4200003212202606259109040544	1	2026-06-25 09:47:12	\N
119	277	1	20	4200003212202606259109040544	1	2026-06-25 09:48:42	\N
120	277	2	20	\N	0	2026-06-25 09:49:11	\N
121	277	1	20	4200003212202606259109040544	1	2026-06-25 09:51:20	\N
122	278	1	20	4200003221202606256483320125	1	2026-06-25 10:54:43	\N
123	283	1	20	4200003128202606256100234318	1	2026-06-25 13:00:38	\N
124	284	1	20	4200003188202606258522730680	1	2026-06-25 13:07:45	\N
125	284	1	20	4200003188202606258522730680	1	2026-06-25 13:09:15	\N
126	285	1	20	4200003182202606254736104552	1	2026-06-25 13:44:08	\N
127	286	1	20	4200003217202606258317286550	1	2026-06-25 13:48:53	\N
128	287	1	20	4200003131202606253826643798	1	2026-06-25 14:00:02	\N
129	288	1	20	4200003136202606253757337202	1	2026-06-25 14:04:53	\N
130	289	1	20	4200003206202606258412608378	1	2026-06-25 14:13:01	\N
131	290	1	20	4200003128202606253899404960	1	2026-06-25 14:37:16	\N
132	291	1	20	4200003142202606255874904089	1	2026-06-25 14:43:18	\N
133	292	1	20	4200003111202606255715225042	1	2026-06-25 14:48:06	\N
134	295	1	20	\N	1	2026-06-25 15:34:23	\N
135	293	1	20	4200003185202606254397243023	1	2026-06-25 15:36:25	\N
136	296	1	20	\N	1	2026-06-25 15:41:41	\N
137	294	1	20	4200003191202606257942699219	1	2026-06-25 15:44:24	\N
138	297	1	20	\N	1	2026-06-25 15:47:15	\N
139	298	1	20	\N	1	2026-06-25 15:48:02	\N
140	299	1	20	\N	1	2026-06-25 15:50:39	\N
141	300	1	20	\N	1	2026-06-25 15:52:25	\N
142	301	1	20	4200003126202606266486005168	1	2026-06-25 22:26:00	\N
143	302	1	20	4200003206202606266399413240	1	2026-06-25 22:54:48	\N
144	302	1	20	4200003206202606266399413240	1	2026-06-25 22:56:19	\N
145	303	1	20	4200003184202606262064245079	1	2026-06-25 23:04:32	\N
146	303	1	20	4200003184202606262064245079	1	2026-06-25 23:06:32	\N
147	306	1	20	4200003222202606267015269936	1	2026-06-25 23:09:11	\N
148	306	1	20	4200003222202606267015269936	1	2026-06-25 23:10:42	\N
149	306	1	20	4200003222202606267015269936	1	2026-06-25 23:10:42	\N
150	307	1	20	4200003135202606260982950090	1	2026-06-25 23:31:20	\N
151	310	1	20	4200003125202606267155536409	1	2026-06-26 01:27:18	\N
152	311	1	20	4200003129202606262955618549	1	2026-06-26 01:33:28	\N
153	311	1	20	4200003129202606262955618549	1	2026-06-26 01:34:58	\N
154	313	1	20	4200003188202606261236674981	1	2026-06-26 01:38:11	\N
155	313	1	20	4200003188202606261236674981	1	2026-06-26 01:39:42	\N
156	314	1	20	4200003186202606263086244068	1	2026-06-26 01:42:30	\N
157	315	1	20	4200003184202606264338045728	1	2026-06-26 01:46:21	\N
158	316	1	20	4200003183202606260475366817	1	2026-06-26 02:53:39	\N
159	317	1	20	4200003204202606269502378651	1	2026-06-26 05:15:47	\N
160	318	1	20	4200003189202606260554928901	1	2026-06-26 05:57:38	\N
161	326	1	20	4200003196202606264025106289	1	2026-06-26 07:15:59	\N
162	330	1	20	4200003208202606261431066067	1	2026-06-26 07:47:09	\N
163	332	1	20	4200003214202606261349170060	1	2026-06-26 08:58:37	\N
164	332	1	20	4200003214202606261349170060	1	2026-06-26 17:28:40.670006	\N
165	328	1	20	4200003223202606261012234681	1	2026-06-26 17:34:14.734917	\N
166	347	1	20	4200003178202606268143428277	1	2026-06-26 19:53:03.020549	\N
167	352	1	20	4200003125202606264648421174	1	2026-06-26 20:35:02.285683	\N
168	353	1	20	4200003195202606264695707051	1	2026-06-26 20:39:21.484571	\N
169	358	1	20	4200003203202606266721579288	1	2026-06-26 21:11:38.333582	\N
171	359	1	20	4200003190202606262178436345	1	2026-06-26 21:14:06.669444	\N
175	368	1	20	4200003132202606278136500376	1	2026-06-27 10:05:21.589816	\N
176	373	1	1	4200003189202606278759826892	1	2026-06-27 11:22:27.300618	\N
177	374	1	1	4200003183202606272953018543	1	2026-06-27 11:45:25.220677	\N
178	376	1	20	4200003136202606276068779383	1	2026-06-27 12:30:16.888008	\N
179	376	2	20	4200003136202606276068779383	1	2026-06-27 12:58:36.902548	RF20260627124832376
180	373	2	1	4200003189202606278759826892	1	2026-06-27 13:00:58.079687	RF20260627130057373
181	352	2	20	4200003125202606264648421174	1	2026-06-27 13:01:14.084133	RF20260627130113352
182	347	2	20	4200003178202606268143428277	1	2026-06-27 13:08:25.746961	RF20260627130824347
183	379	1	20	4200003209202606279977784591	1	2026-06-27 15:54:39.07598	\N
184	380	1	20	4200003186202606272613703359	1	2026-06-27 16:01:17.944934	\N
185	381	1	20	4200003194202606274482878253	1	2026-06-27 16:06:33.755489	\N
186	382	1	20	4200003222202606276645933201	1	2026-06-27 16:11:33.378261	\N
187	384	1	20	4200003137202606271203499467	1	2026-06-27 16:38:26.497389	\N
188	385	1	1	4200003215202606279493063491	1	2026-06-27 18:02:24.751033	\N
189	386	1	1	4200003131202606271749527663	1	2026-06-27 18:04:23.731391	\N
190	390	1	20	4200003179202606284370748705	1	2026-06-28 07:50:38.541754	\N
191	391	1	1	4200003213202606286027761813	1	2026-06-28 08:30:08.558633	\N
192	393	1	1	4200003127202606285009377611	1	2026-06-28 08:35:13.934019	\N
193	396	1	20	4200003183202606281049040918	1	2026-06-28 08:41:27.715242	\N
194	397	1	20	4200003133202606282333152255	1	2026-06-28 08:46:21.723308	\N
195	399	1	20	4200003177202606285617651946	1	2026-06-28 09:34:39.675548	\N
196	400	1	20	4200003191202606283617596483	1	2026-06-28 09:37:42.629482	\N
197	401	1	20	4200003205202606284880898631	1	2026-06-28 09:45:59.444138	\N
198	405	1	20	4200003187202606285994990390	1	2026-06-28 14:52:23.292359	\N
199	407	1	20	4200003223202606288663233889	1	2026-06-28 15:23:20.131006	\N
200	408	1	20	4200003133202606283862175972	1	2026-06-28 15:30:18.624103	\N
225	493	2	20	4200003174202606308573605856	1	2026-06-30 11:24:42.160669	RF20260630112441493
227	494	2	20	4200003131202606308786195009	1	2026-06-30 11:38:12.111092	RF20260630113811494
201	412	2	20	4200003198202606291966260716	1	2026-06-29 18:58:05.315308	\N
202	413	2	20	4200003134202606295998962135	1	2026-06-29 21:26:52.834635	\N
203	422	2	20	4200003196202606294886056707	1	2026-06-29 22:51:26.699427	\N
204	424	2	20	4200003199202606299595869587	1	2026-06-29 22:52:47.230947	\N
257	509	2	20	4200003189202606303949941723	1	2026-06-30 14:46:28.27256	RF20260630144627509
261	512	2	20	4200003149202606301063935560	1	2026-06-30 15:09:01.125273	RF20260630150900512
205	432	2	20	4200003185202606302618664886	1	2026-06-30 07:08:08.498714	\N
206	436	2	20	4200003119202606306901998225	1	2026-06-30 07:11:20.883493	\N
207	438	2	20	4200003196202606302480741718	1	2026-06-30 07:28:54.288154	\N
208	438	2	20	4200003196202606302480741718	1	2026-06-30 07:28:54.438848	\N
209	440	2	20	4200003126202606304942694629	1	2026-06-30 07:50:37.421378	\N
210	441	2	20	4200003102202606301301964997	1	2026-06-30 07:51:52.930567	\N
211	454	2	20	4200003183202606303659442815	1	2026-06-30 09:04:02.318598	\N
212	457	2	20	4200003186202606300691410477	1	2026-06-30 09:11:19.737468	\N
213	458	2	20	4200003097202606307976765838	1	2026-06-30 09:13:28.184242	\N
214	461	2	20	4200003185202606305579509474	1	2026-06-30 09:30:39.755877	\N
215	461	2	20	4200003185202606305579509474	1	2026-06-30 09:30:39.947542	\N
216	469	2	20	4200003213202606301295336829	1	2026-06-30 09:39:23.520247	\N
217	470	2	20	4200003173202606305670319510	1	2026-06-30 09:49:43.240687	\N
218	481	2	20	4200003188202606309691633192	1	2026-06-30 09:54:35.033376	\N
219	481	2	20	4200003188202606309691633192	1	2026-06-30 09:54:35.340922	\N
220	484	2	20	4200003224202606309624402648	1	2026-06-30 10:15:35.262354	\N
221	487	2	20	4200003106202606308927643382	1	2026-06-30 10:20:03.524165	\N
222	488	2	20	4200003186202606300773799142	1	2026-06-30 10:54:40.858873	\N
223	492	2	20	4200003130202606306918520781	1	2026-06-30 11:04:39.110611	\N
224	493	2	20	4200003174202606308573605856	1	2026-06-30 11:18:17.91693	\N
226	494	2	20	4200003131202606308786195009	1	2026-06-30 11:26:59.0125	\N
228	496	2	20	4200003210202606300113915182	1	2026-06-30 11:40:00.921451	\N
229	497	2	20	4200003121202606303979181027	1	2026-06-30 11:45:16.979502	\N
230	498	2	20	4200003130202606309674975458	1	2026-06-30 12:04:52.582203	\N
231	500	2	20	4200003190202606303089652659	1	2026-06-30 12:23:42.549994	\N
232	501	2	20	4200003115202606303234817522	1	2026-06-30 12:38:27.234265	\N
233	506	2	20	4200003190202606306991859861	1	2026-06-30 12:40:01.283078	\N
234	503	2	20	4200003197202606308771166775	1	2026-06-30 12:40:01.370824	\N
235	505	2	20	4200003204202606306642224931	1	2026-06-30 12:40:07.351634	\N
236	507	2	20	4200003223202606301431470228	1	2026-06-30 12:40:15.974819	\N
237	511	2	20	4200003197202606302682250482	1	2026-06-30 12:40:30.916278	\N
238	509	2	20	4200003189202606303949941723	1	2026-06-30 12:40:50.157881	\N
239	512	2	20	4200003149202606301063935560	1	2026-06-30 12:42:00.6596	\N
240	514	2	20	4200003224202606306671084085	1	2026-06-30 12:51:45.820534	\N
241	514	2	20	4200003224202606306671084085	1	2026-06-30 12:51:46.013587	\N
242	516	2	20	4200003151202606305421787597	1	2026-06-30 12:52:31.08996	\N
243	517	2	20	4200003218202606304060814654	1	2026-06-30 13:04:54.464525	\N
244	519	2	20	4200003138202606302528916179	1	2026-06-30 13:05:24.693581	\N
245	521	2	20	4200003097202606302709695392	1	2026-06-30 13:13:16.352066	\N
246	523	2	20	4200003128202606309427246633	1	2026-06-30 13:29:47.107098	\N
247	524	2	20	4200003135202606306343380379	1	2026-06-30 13:31:26.664399	\N
248	526	2	20	4200003147202606302705451991	1	2026-06-30 13:34:33.280636	\N
249	530	2	20	4200003194202606305055023900	1	2026-06-30 13:46:20.422411	\N
250	528	2	20	4200003180202606305224957902	1	2026-06-30 13:46:23.954144	\N
251	532	2	20	4200003223202606307199431243	1	2026-06-30 13:49:06.172293	\N
252	533	2	20	4200003107202606306060143584	1	2026-06-30 14:01:19.934189	\N
253	535	2	20	4200003178202606309902143709	1	2026-06-30 14:15:36.907132	\N
254	537	2	20	4200003211202606304706104835	1	2026-06-30 14:16:30.087529	\N
255	538	2	20	4200003131202606303988984290	1	2026-06-30 14:16:50.133669	\N
256	539	2	20	4200003115202606301960636307	1	2026-06-30 14:18:37.078243	\N
258	541	2	20	4200003222202606307073662743	1	2026-06-30 14:48:09.042358	\N
259	543	2	20	4200003178202606304648003361	1	2026-06-30 14:53:12.629742	\N
260	543	2	20	4200003178202606304648003361	1	2026-06-30 14:53:12.79136	\N
262	545	2	20	4200003117202606305680864882	1	2026-06-30 15:25:19.229295	\N
263	546	2	20	4200003183202606304945740720	1	2026-06-30 15:27:44.656072	\N
264	547	2	20	4200003195202606308924862181	1	2026-06-30 15:30:47.06444	\N
265	549	2	20	4200003165202606304574377209	1	2026-06-30 15:51:36.239668	\N
266	519	2	20	4200003138202606302528916179	1	2026-06-30 16:50:52.842004	RF20260630165051519
267	550	1	20	4200003222202606308558391939	1	2026-06-30 17:06:55.328442	\N
268	537	2	20	4200003211202606304706104835	1	2026-06-30 17:09:33.58124	RF20260630170932537
269	521	2	20	4200003097202606302709695392	1	2026-06-30 17:12:19.662631	RF20260630171218521
270	551	1	20	4200003194202606303961998936	1	2026-06-30 17:15:14.067188	\N
271	545	2	20	4200003117202606305680864882	1	2026-06-30 17:26:28.528735	RF20260630172627545
272	553	1	20	4200003166202606301245248017	1	2026-06-30 18:03:26.072108	\N
273	555	1	20	4200003195202606307167196149	1	2026-06-30 18:04:04.46551	\N
274	556	2	20	4200003127202606301108384981	1	2026-06-30 18:44:45.78393	\N
275	556	1	20	4200003127202606301108384981	1	2026-06-30 18:44:45.93648	\N
276	558	2	20	4200003110202606309731825407	1	2026-06-30 18:55:37.176824	\N
\.


--
-- Data for Name: pending_lock_cmds; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.pending_lock_cmds (id, device_id, board_no, lock_no, protocol, order_id, created_at, delivered, cabinet_id, slot_id, command, status) FROM stdin;
752	100101	1	1	YBM		2026-06-29 17:58:49.9421	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 17:58:49"}	\N
753	100101	1	1	YBM		2026-06-29 17:58:59.427278	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 17:58:59"}	\N
755	100101	1	1	YBM		2026-06-29 18:01:47.922967	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 18:01:47"}	\N
756	100101	1	1	YBM		2026-06-29 18:02:57.255984	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 18:02:57"}	\N
765	100101	1	4	YBM		2026-06-29 18:32:47.1652	1	\N	\N	{"type": "open_lock", "device_id": "100101", "board_no": 1, "lock_no": 4, "protocol": "YBM"}	\N
767	100100	1	1	YBM		2026-06-29 18:34:55.136809	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 18:34:55"}	\N
768	100100	1	1	YBM		2026-06-29 18:48:00.605753	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 18:48:00"}	\N
769	100101	1	1	YBM	20260629185752358994	2026-06-29 18:58:05.33557	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260629185752358994", "orderId": "20260629185752358994", "timestamp": "2026-06-29 18:58:05"}	\N
771	100100	1	1	YBM		2026-06-29 19:07:16.438059	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 19:07:16"}	\N
774	100100	1	1	YBM		2026-06-29 19:13:08.168097	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 19:13:08"}	\N
775	100100	1	1	YBM		2026-06-29 19:13:19.930529	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 19:13:19"}	\N
777	100100	1	1	YBM		2026-06-29 19:17:15.974371	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 19:17:15"}	\N
779	100100	1	1	YBM		2026-06-29 19:49:48.539559	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 19:49:48"}	\N
780	100100	1	1	YBM		2026-06-29 20:04:23.833055	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 20:04:23"}	\N
781	100100	2	1	YBM		2026-06-29 20:11:47.034832	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 20:11:47"}	\N
782	100100	2	2	YBM		2026-06-29 20:11:49.117073	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 20:11:49"}	\N
786	100100	1	1	YBM		2026-06-29 21:06:15.874013	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:06:15"}	\N
787	100100	1	1	YBM		2026-06-29 21:06:35.170836	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:06:35"}	\N
788	100101	1	1	YBM		2026-06-29 21:17:05.31348	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:17:05"}	\N
789	100100	2	16	YBM	20260629212626345012	2026-06-29 21:26:52.857814	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "20260629212626345012", "orderId": "20260629212626345012", "timestamp": "2026-06-29 21:26:52"}	\N
790	100100	2	16	YBM	413	2026-06-29 21:27:06.073925	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": 413, "orderId": "413", "timestamp": "2026-06-29 21:27:06"}	\N
791	100101	1	1	YBM		2026-06-29 21:41:33.551369	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:41:33"}	\N
795	100100	2	2	YBM		2026-06-29 21:44:10.418469	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:44:10"}	\N
796	100100	2	2	YBM		2026-06-29 21:44:15.147683	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:44:15"}	\N
792	100101	1	1	YBM		2026-06-29 21:42:09.396463	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:42:09"}	\N
793	100101	1	1	YBM		2026-06-29 21:42:39.142927	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:42:39"}	\N
794	100101	1	1	YBM		2026-06-29 21:43:24.712002	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:43:24"}	\N
797	100100	2	2	YBM		2026-06-29 21:44:23.169926	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:44:23"}	\N
798	100101	1	1	YBM		2026-06-29 21:45:20.155706	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:45:20"}	\N
799	100101	1	1	YBM		2026-06-29 21:45:36.33112	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:45:36"}	\N
800	100101	1	1	YBM		2026-06-29 21:46:10.72505	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:46:10"}	\N
802	100100	2	2	YBM		2026-06-29 21:46:24.69516	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:46:24"}	\N
801	100100	1	10	YBM		2026-06-29 21:46:22.708857	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:46:22"}	\N
803	100101	1	1	YBM		2026-06-29 21:46:50.304061	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:46:50"}	\N
804	100101	1	1	YBM		2026-06-29 21:47:01.328915	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:47:01"}	\N
805	100101	1	1	YBM		2026-06-29 21:47:54.091569	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:47:54"}	\N
806	100101	1	1	YBM		2026-06-29 21:48:14.641273	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:48:14"}	\N
807	100101	1	1	YBM		2026-06-29 21:49:09.386899	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:49:09"}	\N
808	100101	1	1	YBM		2026-06-29 21:50:59.653998	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:50:59"}	\N
809	100100	1	9	YBM	20260629225052014226	2026-06-29 22:51:26.719145	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260629225052014226", "orderId": "20260629225052014226", "timestamp": "2026-06-29 22:51:26"}	\N
810	100100	1	9	YBM	422	2026-06-29 22:51:38.248415	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": 422, "orderId": "422", "timestamp": "2026-06-29 22:51:38"}	\N
811	100100	1	11	YBM	20260629225224739911	2026-06-29 22:52:47.249755	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260629225224739911", "orderId": "20260629225224739911", "timestamp": "2026-06-29 22:52:47"}	\N
812	100100	1	11	YBM	424	2026-06-29 22:53:13.964346	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 424, "orderId": "424", "timestamp": "2026-06-29 22:53:13"}	\N
813	100100	1	10	YBM	423	2026-06-29 22:53:18.071095	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": 423, "orderId": "423", "timestamp": "2026-06-29 22:53:18"}	\N
814	100100	1	9	YBM	422	2026-06-29 22:53:22.649846	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": 422, "orderId": "422", "timestamp": "2026-06-29 22:53:22"}	\N
815	100100	1	11	YBM	424	2026-06-29 22:53:27.502555	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 424, "orderId": "424", "timestamp": "2026-06-29 22:53:27"}	\N
816	100100	1	11	YBM		2026-06-29 22:54:37.306212	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 22:54:37"}	\N
817	100100	1	11	YBM	424	2026-06-29 22:58:40.796864	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 424, "orderId": "424", "timestamp": "2026-06-29 22:58:40"}	\N
818	100100	1	11	YBM	424	2026-06-29 23:00:00.810008	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 424, "orderId": "424", "timestamp": "2026-06-29 23:00:00"}	\N
819	100100	1	9	YBM	422	2026-06-29 23:00:06.66189	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": 422, "orderId": "422", "timestamp": "2026-06-29 23:00:06"}	\N
820	100100	1	11	YBM	424	2026-06-29 23:01:38.604056	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 424, "orderId": "424", "timestamp": "2026-06-29 23:01:38"}	\N
825	100100	1	11	YBM		2026-06-30 06:47:59.306262	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 06:47:59"}	\N
835	100100	1	11	YBM		2026-06-30 07:02:42.829024	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:02:42"}	\N
836	100100	1	1	YBM		2026-06-30 07:02:49.033764	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:02:49"}	\N
837	100100	1	3	YBM		2026-06-30 07:02:57.265125	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:02:57"}	\N
859	100100	2	9	YBM	20260630072823856658	2026-06-30 07:28:54.442782	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630072823856658", "orderId": "20260630072823856658", "timestamp": "2026-06-30 07:28:54"}	\N
842	100100	1	2	YBM		2026-06-30 07:04:22.011135	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:04:22"}	\N
843	100100	1	3	YBM		2026-06-30 07:04:22.380583	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:04:22"}	\N
844	100100	1	4	YBM		2026-06-30 07:04:28.977258	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:04:28"}	\N
845	100100	1	4	YBM	test_070635_4	2026-06-30 07:06:35.122525	1	\N	\N	{"type": "open_lock", "device_id": "100100", "board_no": 1, "lock_no": 4, "protocol": "YBM", "order_id": "test_070635_4"}	\N
846	100100	1	1	YBM	test_070635_1	2026-06-30 07:06:35.125698	1	\N	\N	{"type": "open_lock", "device_id": "100100", "board_no": 1, "lock_no": 1, "protocol": "YBM", "order_id": "test_070635_1"}	\N
847	100100	1	3	YBM	test_070635_3	2026-06-30 07:06:35.129172	1	\N	\N	{"type": "open_lock", "device_id": "100100", "board_no": 1, "lock_no": 3, "protocol": "YBM", "order_id": "test_070635_3"}	\N
848	100100	1	5	YBM	test_070635_5	2026-06-30 07:06:35.137562	1	\N	\N	{"type": "open_lock", "device_id": "100100", "board_no": 1, "lock_no": 5, "protocol": "YBM", "order_id": "test_070635_5"}	\N
849	100100	1	2	YBM	test_070635_2	2026-06-30 07:06:35.136148	1	\N	\N	{"type": "open_lock", "device_id": "100100", "board_no": 1, "lock_no": 2, "protocol": "YBM", "order_id": "test_070635_2"}	\N
850	100100	2	3	YBM	20260630070731985915	2026-06-30 07:08:08.528208	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260630070731985915", "orderId": "20260630070731985915", "timestamp": "2026-06-30 07:08:08"}	\N
851	100100	2	3	YBM	432	2026-06-30 07:08:14.819079	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": 432, "orderId": "432", "timestamp": "2026-06-30 07:08:14"}	\N
852	100100	2	3	YBM	432	2026-06-30 07:08:18.466375	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": 432, "orderId": "432", "timestamp": "2026-06-30 07:08:18"}	\N
853	100100	2	7	YBM	20260630071102574249	2026-06-30 07:11:20.901474	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630071102574249", "orderId": "20260630071102574249", "timestamp": "2026-06-30 07:11:20"}	\N
858	100100	2	9	YBM	20260630072823856658	2026-06-30 07:28:54.317847	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630072823856658", "orderId": "20260630072823856658", "timestamp": "2026-06-30 07:28:54"}	\N
862	101001	1	\N	YBM		2026-06-30 07:40:37.386314	0	15	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.49", "version_code": 169, "force": true, "file_md5": "996dc013243b5066d87ee61508639839"}	pending
863	123456	1	\N	YBM		2026-06-30 07:40:37.409165	0	8	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.49", "version_code": 169, "force": true, "file_md5": "996dc013243b5066d87ee61508639839"}	pending
860	100100	1	\N	YBM		2026-06-30 07:40:37.34113	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.49", "version_code": 169, "force": true, "file_md5": "996dc013243b5066d87ee61508639839"}	pending
864	100100	2	11	YBM	20260630075016897517	2026-06-30 07:50:37.435786	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630075016897517", "orderId": "20260630075016897517", "timestamp": "2026-06-30 07:50:37"}	\N
865	100100	2	11	YBM	440	2026-06-30 07:50:43.17386	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 440, "orderId": "440", "timestamp": "2026-06-30 07:50:43"}	\N
866	100100	2	12	YBM	20260630075135072321	2026-06-30 07:51:52.952597	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630075135072321", "orderId": "20260630075135072321", "timestamp": "2026-06-30 07:51:52"}	\N
861	100101	1	\N	YBM		2026-06-30 07:40:37.359481	1	24	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.49", "version_code": 169, "force": true, "file_md5": "996dc013243b5066d87ee61508639839"}	pending
867	100101	1	1	YBM		2026-06-30 08:45:45.971947	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 08:45:45"}	\N
868	100101	1	8	YBM	20260630090354376183	2026-06-30 09:04:02.326195	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260630090354376183", "orderId": "20260630090354376183", "timestamp": "2026-06-30 09:04:02"}	\N
869	100101	1	9	YBM	20260630091101819765	2026-06-30 09:11:19.743701	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630091101819765", "orderId": "20260630091101819765", "timestamp": "2026-06-30 09:11:19"}	\N
870	100100	1	5	YBM	20260630091211403812	2026-06-30 09:13:28.187945	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260630091211403812", "orderId": "20260630091211403812", "timestamp": "2026-06-30 09:13:28"}	\N
871	123456	1	\N	YBM		2026-06-30 09:27:15.44261	0	8	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
872	101001	1	\N	YBM		2026-06-30 09:27:15.44261	0	15	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
875	1001002	1	\N	YBM		2026-06-30 09:27:15.44261	0	26	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
874	100101	1	\N	YBM		2026-06-30 09:27:15.44261	1	24	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
873	100100	1	\N	YBM		2026-06-30 09:27:15.44261	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
876	100101	1	11	YBM	20260630093015601516	2026-06-30 09:30:39.777412	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630093015601516", "orderId": "20260630093015601516", "timestamp": "2026-06-30 09:30:39"}	\N
877	100101	1	11	YBM	20260630093015601516	2026-06-30 09:30:39.954142	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630093015601516", "orderId": "20260630093015601516", "timestamp": "2026-06-30 09:30:39"}	\N
878	100101	1	15	YBM	20260630093905337250	2026-06-30 09:39:23.526127	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260630093905337250", "orderId": "20260630093905337250", "timestamp": "2026-06-30 09:39:23"}	\N
879	100100	1	12	YBM	20260630094022158852	2026-06-30 09:49:43.264043	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630094022158852", "orderId": "20260630094022158852", "timestamp": "2026-06-30 09:49:43"}	\N
880	100100	1	16	YBM	478	2026-06-30 09:52:45.629938	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": 478, "orderId": "478", "timestamp": "2026-06-30 09:52:45"}	\N
881	100100	1	16	YBM	478	2026-06-30 09:52:48.023677	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": 478, "orderId": "478", "timestamp": "2026-06-30 09:52:48"}	\N
882	100100	1	12	YBM	470	2026-06-30 09:53:20.665141	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": 470, "orderId": "470", "timestamp": "2026-06-30 09:53:20"}	\N
883	100100	2	2	YBM	20260630095414309240	2026-06-30 09:54:35.056502	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260630095414309240", "orderId": "20260630095414309240", "timestamp": "2026-06-30 09:54:35"}	\N
884	100100	2	2	YBM	20260630095414309240	2026-06-30 09:54:35.34468	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260630095414309240", "orderId": "20260630095414309240", "timestamp": "2026-06-30 09:54:35"}	\N
885	100101	2	7	YBM	20260630101459139734	2026-06-30 10:15:35.270155	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630101459139734", "orderId": "20260630101459139734", "timestamp": "2026-06-30 10:15:35"}	\N
886	100100	2	6	YBM	20260630101943467907	2026-06-30 10:20:03.546293	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260630101943467907", "orderId": "20260630101943467907", "timestamp": "2026-06-30 10:20:03"}	\N
887	100100	2	6	YBM	487	2026-06-30 10:20:08.706746	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": 487, "orderId": "487", "timestamp": "2026-06-30 10:20:08"}	\N
888	100100	2	6	YBM	487	2026-06-30 10:20:17.607213	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": 487, "orderId": "487", "timestamp": "2026-06-30 10:20:17"}	\N
889	100100	2	6	YBM		2026-06-30 10:20:34.089165	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 10:20:34"}	\N
890	100100	2	6	YBM		2026-06-30 10:20:42.448156	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 10:20:42"}	\N
891	100100	2	7	YBM	20260630105405124207	2026-06-30 10:54:40.865163	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630105405124207", "orderId": "20260630105405124207", "timestamp": "2026-06-30 10:54:40"}	\N
892	100100	2	7	YBM	488	2026-06-30 10:54:46.257909	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": 488, "orderId": "488", "timestamp": "2026-06-30 10:54:46"}	\N
893	100100	2	7	YBM	488	2026-06-30 10:54:50.079813	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": 488, "orderId": "488", "timestamp": "2026-06-30 10:54:50"}	\N
894	100100	2	23	YBM	488	2026-06-30 10:57:08.922761	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 23, "lockNo": 23, "protocol": "YBM", "order_id": "488", "orderId": "488", "timestamp": "2026-06-30 10:57:08"}	\N
895	100100	2	23	YBM	488	2026-06-30 10:57:28.788881	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 23, "lockNo": 23, "protocol": "YBM", "order_id": "488", "orderId": "488", "timestamp": "2026-06-30 10:57:28"}	\N
896	100100	2	7	YBM		2026-06-30 10:58:00.371201	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 10:58:00"}	\N
897	100100	2	7	YBM		2026-06-30 10:58:58.872311	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 10:58:58"}	\N
898	100100	2	23	YBM	488	2026-06-30 10:59:54.180046	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 23, "lockNo": 23, "protocol": "YBM", "order_id": "488", "orderId": "488", "timestamp": "2026-06-30 10:59:54"}	\N
899	100100	2	23	YBM	488	2026-06-30 11:00:08.171111	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 23, "lockNo": 23, "protocol": "YBM", "order_id": "488", "orderId": "488", "timestamp": "2026-06-30 11:00:08"}	\N
900	100100	2	11	YBM	20260630110420701345	2026-06-30 11:04:39.115718	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630110420701345", "orderId": "20260630110420701345", "timestamp": "2026-06-30 11:04:39"}	\N
901	100100	2	11	YBM	492	2026-06-30 11:04:44.841468	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 492, "orderId": "492", "timestamp": "2026-06-30 11:04:44"}	\N
902	100100	2	10	YBM	491	2026-06-30 11:05:24.835614	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": 491, "orderId": "491", "timestamp": "2026-06-30 11:05:24"}	\N
903	100100	2	12	YBM	20260630111758918131	2026-06-30 11:18:17.921932	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630111758918131", "orderId": "20260630111758918131", "timestamp": "2026-06-30 11:18:17"}	\N
904	100100	2	12	YBM	493	2026-06-30 11:18:25.535304	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": 493, "orderId": "493", "timestamp": "2026-06-30 11:18:25"}	\N
905	100101	2	8	YBM	20260630112639381589	2026-06-30 11:26:59.01898	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260630112639381589", "orderId": "20260630112639381589", "timestamp": "2026-06-30 11:26:59"}	\N
906	100101	2	8	YBM	494	2026-06-30 11:27:07.242982	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": 494, "orderId": "494", "timestamp": "2026-06-30 11:27:07"}	\N
907	100101	2	10	YBM	20260630113938731600	2026-06-30 11:40:00.952082	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260630113938731600", "orderId": "20260630113938731600", "timestamp": "2026-06-30 11:40:00"}	\N
908	100100	2	13	YBM	20260630114500326407	2026-06-30 11:45:16.987841	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260630114500326407", "orderId": "20260630114500326407", "timestamp": "2026-06-30 11:45:16"}	\N
909	100100	2	13	YBM	497	2026-06-30 11:49:15.527334	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "497", "orderId": "497", "timestamp": "2026-06-30 11:49:15"}	\N
910	100101	2	11	YBM	20260630120430300084	2026-06-30 12:04:52.593056	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630120430300084", "orderId": "20260630120430300084", "timestamp": "2026-06-30 12:04:52"}	\N
911	100101	2	13	YBM	20260630122321456133	2026-06-30 12:23:42.55809	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260630122321456133", "orderId": "20260630122321456133", "timestamp": "2026-06-30 12:23:42"}	\N
912	100101	2	14	YBM	20260630123806951872	2026-06-30 12:38:27.238237	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260630123806951872", "orderId": "20260630123806951872", "timestamp": "2026-06-30 12:38:27"}	\N
913	100101	3	4	YBM	20260630123939351137	2026-06-30 12:40:01.287511	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260630123939351137", "orderId": "20260630123939351137", "timestamp": "2026-06-30 12:40:01"}	\N
914	100101	3	1	YBM	20260630123932308808	2026-06-30 12:40:01.381319	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260630123932308808", "orderId": "20260630123932308808", "timestamp": "2026-06-30 12:40:01"}	\N
915	100101	3	3	YBM	20260630123936503848	2026-06-30 12:40:07.370917	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260630123936503848", "orderId": "20260630123936503848", "timestamp": "2026-06-30 12:40:07"}	\N
916	100101	3	5	YBM	20260630123952112437	2026-06-30 12:40:15.978863	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260630123952112437", "orderId": "20260630123952112437", "timestamp": "2026-06-30 12:40:15"}	\N
917	100101	3	9	YBM	20260630124010539133	2026-06-30 12:40:30.920291	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630124010539133", "orderId": "20260630124010539133", "timestamp": "2026-06-30 12:40:30"}	\N
918	100101	3	7	YBM	20260630123959529209	2026-06-30 12:40:50.176599	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630123959529209", "orderId": "20260630123959529209", "timestamp": "2026-06-30 12:40:50"}	\N
919	100101	3	10	YBM	20260630124135737562	2026-06-30 12:42:00.663047	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260630124135737562", "orderId": "20260630124135737562", "timestamp": "2026-06-30 12:42:00"}	\N
920	100101	3	12	YBM	20260630125108236602	2026-06-30 12:51:45.839335	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630125108236602", "orderId": "20260630125108236602", "timestamp": "2026-06-30 12:51:45"}	\N
921	100101	3	12	YBM	20260630125108236602	2026-06-30 12:51:46.017535	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630125108236602", "orderId": "20260630125108236602", "timestamp": "2026-06-30 12:51:46"}	\N
922	100101	3	12	YBM	514	2026-06-30 12:52:21.832861	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": 514, "orderId": "514", "timestamp": "2026-06-30 12:52:21"}	\N
923	100101	3	14	YBM	20260630125130451288	2026-06-30 12:52:31.108721	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260630125130451288", "orderId": "20260630125130451288", "timestamp": "2026-06-30 12:52:31"}	\N
924	100101	3	15	YBM	20260630130421202757	2026-06-30 13:04:54.46945	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260630130421202757", "orderId": "20260630130421202757", "timestamp": "2026-06-30 13:04:54"}	\N
925	100101	4	1	YBM	20260630130451524847	2026-06-30 13:05:24.697041	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260630130451524847", "orderId": "20260630130451524847", "timestamp": "2026-06-30 13:05:24"}	\N
926	100101	4	3	YBM	20260630131251511581	2026-06-30 13:13:16.356508	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260630131251511581", "orderId": "20260630131251511581", "timestamp": "2026-06-30 13:13:16"}	\N
927	100101	4	5	YBM	20260630132913118022	2026-06-30 13:29:47.127515	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260630132913118022", "orderId": "20260630132913118022", "timestamp": "2026-06-30 13:29:47"}	\N
928	100101	4	6	YBM	20260630133057596999	2026-06-30 13:31:26.684711	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260630133057596999", "orderId": "20260630133057596999", "timestamp": "2026-06-30 13:31:26"}	\N
929	100101	4	8	YBM	20260630133404595989	2026-06-30 13:34:33.285874	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260630133404595989", "orderId": "20260630133404595989", "timestamp": "2026-06-30 13:34:33"}	\N
930	100100	2	15	YBM	20260630134559767386	2026-06-30 13:46:20.441528	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260630134559767386", "orderId": "20260630134559767386", "timestamp": "2026-06-30 13:46:20"}	\N
931	100101	4	10	YBM	20260630134555889371	2026-06-30 13:46:23.973575	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260630134555889371", "orderId": "20260630134555889371", "timestamp": "2026-06-30 13:46:23"}	\N
932	100100	2	15	YBM	530	2026-06-30 13:46:27.681865	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:46:27"}	\N
933	100100	2	15	YBM	530	2026-06-30 13:46:32.163341	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:46:32"}	\N
934	100100	2	15	YBM	530	2026-06-30 13:46:51.713416	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:46:51"}	\N
935	100100	2	15	YBM	530	2026-06-30 13:46:56.582472	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:46:56"}	\N
936	100101	4	12	YBM	20260630134846640888	2026-06-30 13:49:06.176774	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630134846640888", "orderId": "20260630134846640888", "timestamp": "2026-06-30 13:49:06"}	\N
937	100100	2	15	YBM	530	2026-06-30 13:49:07.503647	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:49:07"}	\N
938	100100	2	15	YBM	530	2026-06-30 13:49:11.791087	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:49:11"}	\N
939	100101	4	13	YBM	20260630140052363155	2026-06-30 14:01:19.938952	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260630140052363155", "orderId": "20260630140052363155", "timestamp": "2026-06-30 14:01:19"}	\N
940	100101	4	15	YBM	20260630141511676928	2026-06-30 14:15:36.912609	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260630141511676928", "orderId": "20260630141511676928", "timestamp": "2026-06-30 14:15:36"}	\N
941	100101	1	1	YBM	20260630141613856704	2026-06-30 14:16:30.091552	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260630141613856704", "orderId": "20260630141613856704", "timestamp": "2026-06-30 14:16:30"}	\N
942	100101	1	2	YBM	20260630141616444325	2026-06-30 14:16:50.137825	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260630141616444325", "orderId": "20260630141616444325", "timestamp": "2026-06-30 14:16:50"}	\N
943	100101	1	3	YBM	20260630141812626447	2026-06-30 14:18:37.098645	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260630141812626447", "orderId": "20260630141812626447", "timestamp": "2026-06-30 14:18:37"}	\N
944	100101	1	5	YBM	20260630144750539670	2026-06-30 14:48:09.046948	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260630144750539670", "orderId": "20260630144750539670", "timestamp": "2026-06-30 14:48:09"}	\N
945	100101	3	12	YBM	514	2026-06-30 14:51:14.795709	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": 514, "orderId": "514", "timestamp": "2026-06-30 14:51:14"}	\N
946	100101	1	7	YBM	20260630145256257792	2026-06-30 14:53:12.649568	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630145256257792", "orderId": "20260630145256257792", "timestamp": "2026-06-30 14:53:12"}	\N
947	100101	1	7	YBM	20260630145256257792	2026-06-30 14:53:12.796791	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630145256257792", "orderId": "20260630145256257792", "timestamp": "2026-06-30 14:53:12"}	\N
948	100101	2	14	YBM		2026-06-30 15:09:22.959856	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 15:09:22"}	\N
949	100101	1	9	YBM	20260630152451000570	2026-06-30 15:25:19.233486	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630152451000570", "orderId": "20260630152451000570", "timestamp": "2026-06-30 15:25:19"}	\N
950	100101	1	11	YBM	20260630152726665334	2026-06-30 15:27:44.675261	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630152726665334", "orderId": "20260630152726665334", "timestamp": "2026-06-30 15:27:44"}	\N
951	100101	1	12	YBM	20260630153014147323	2026-06-30 15:30:47.083831	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630153014147323", "orderId": "20260630153014147323", "timestamp": "2026-06-30 15:30:47"}	\N
952	100101	1	13	YBM	20260630155114892074	2026-06-30 15:51:36.244949	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260630155114892074", "orderId": "20260630155114892074", "timestamp": "2026-06-30 15:51:36"}	\N
953	100101	1	1	YBM	537	2026-06-30 16:56:09.634971	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": 537, "orderId": "537", "timestamp": "2026-06-30 16:56:09"}	\N
954	100100	2	16	YBM	20260630170632583423	2026-06-30 17:06:55.336605	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "20260630170632583423", "orderId": "20260630170632583423", "timestamp": "2026-06-30 17:06:55"}	\N
955	100100	2	16	YBM	550	2026-06-30 17:08:19.488077	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": 550, "orderId": "550", "timestamp": "2026-06-30 17:08:19"}	\N
956	100100	1	1	YBM	20260630171440638549	2026-06-30 17:15:14.077437	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260630171440638549", "orderId": "20260630171440638549", "timestamp": "2026-06-30 17:15:14"}	\N
957	100101	1	13	YBM	549	2026-06-30 17:39:29.157936	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": 549, "orderId": "549", "timestamp": "2026-06-30 17:39:29"}	\N
958	100100	1	3	YBM	20260630180308393971	2026-06-30 18:03:26.08157	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260630180308393971", "orderId": "20260630180308393971", "timestamp": "2026-06-30 18:03:26"}	\N
959	100100	1	6	YBM	20260630180349917874	2026-06-30 18:04:04.46966	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260630180349917874", "orderId": "20260630180349917874", "timestamp": "2026-06-30 18:04:04"}	\N
960	100100	1	\N	YBM		2026-06-30 18:35:05.352038	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
961	100100	1	7	YBM	20260630184408267234	2026-06-30 18:44:45.793995	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630184408267234", "orderId": "20260630184408267234", "timestamp": "2026-06-30 18:44:45"}	\N
962	100100	1	7	YBM	20260630184408267234	2026-06-30 18:44:45.941694	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630184408267234", "orderId": "20260630184408267234", "timestamp": "2026-06-30 18:44:45"}	\N
963	100100	1	9	YBM	20260630185425159147	2026-06-30 18:55:37.180175	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630185425159147", "orderId": "20260630185425159147", "timestamp": "2026-06-30 18:55:37"}	\N
964	100100	1	9	YBM	558	2026-06-30 18:55:42.77916	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": 558, "orderId": "558", "timestamp": "2026-06-30 18:55:42"}	\N
\.


--
-- Data for Name: phone_openids; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.phone_openids (id, phone, openid, created_at, updated_at, wechat_name, unionid) FROM stdin;
2	17722332233	oWrA81xyJP1aI7beoqhd2rxBGPfw	2026-06-28 15:30:04.779791	2026-06-28 15:30:04.779791		\N
16	17726689234	oLhbm2CegcLUOudngMNwdzBhHA7U	2026-06-30 07:11:10.210251	2026-06-30 21:48:24.600671	666智能寄存柜	
3	13667618419	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	2026-06-29 17:03:50.202911	2026-06-30 22:56:20.852838	？？？	
25	18983079797	oWrA81-sAdleVupXM1QWH2jwpywk	2026-06-30 09:30:24.412491	2026-06-30 09:50:22.169829		\N
39	19905939796	oWrA81x-B7qKpyyzunCQ79w_44Uo	2026-06-30 10:15:22.039783	2026-06-30 10:15:22.039783		\N
48	15550752925	oWrA8105UJTohMvSF-xYM6nVUWOA	2026-06-30 12:39:43.421461	2026-06-30 12:39:43.421461		\N
49	18254067609	oWrA81yIpUhQohO1TptlV1HLGlGU	2026-06-30 12:39:52.176612	2026-06-30 12:39:52.176612		\N
50	15617060696	oWrA81w-5cgkKNolzfRIie4yxyu0	2026-06-30 12:39:55.144986	2026-06-30 12:39:55.144986		\N
51	18865018110	oWrA816FjsBSQwPthTIM5WXpjYVI	2026-06-30 12:40:04.701644	2026-06-30 12:40:04.701644		\N
52	15098366660	oWrA814SNv6vojll-l7fnoshhlRk	2026-06-30 12:41:50.269223	2026-06-30 12:41:50.269223		\N
23	18996093393	oWrA819aVj0AQxk0XRwFiuGi9W5k	2026-06-30 09:11:11.151822	2026-06-30 12:50:37.80925		\N
54	18265005796	oWrA81-ItgTPxpuU_KnmJnRQIZc8	2026-06-30 12:51:27.043021	2026-06-30 12:51:39.340206		\N
56	18326741968	oWrA81xM1eyqfXkFpnjHU05ps_LU	2026-06-30 12:52:07.490643	2026-06-30 12:52:07.490643		\N
57	15657821278	oWrA8119oPBjRQBBnEdipGqRawa8	2026-06-30 13:04:37.433039	2026-06-30 13:04:37.433039		\N
58	19286022436	oWrA81yNEVUEKWc7GIPodzG2yGXE	2026-06-30 13:05:08.587031	2026-06-30 13:05:14.984333		\N
60	18637010208	oWrA8123pVky5DBpbOF-0YgfVVOA	2026-06-30 13:13:07.638923	2026-06-30 13:13:07.638923		\N
61	15275043796	oWrA817RU4v8eQ-ItnK1Sjcj3d7Q	2026-06-30 13:29:26.693839	2026-06-30 13:29:34.918138		\N
63	18438398466	oWrA812I_KJbezJSGRt8wnBfzK4s	2026-06-30 13:31:13.990218	2026-06-30 13:31:13.990218		\N
64	18953074181	oWrA811vea15wVBi1JfZ3bWsqaQU	2026-06-30 13:46:06.806399	2026-06-30 13:46:14.300522		\N
67	13791463202	oWrA819H2B8_mgblRP2ZpM42vNUY	2026-06-30 13:48:57.834205	2026-06-30 13:48:57.834205		\N
68	19693594027	oWrA81xxlAxojDpUE3Q5nxIdLaSA	2026-06-30 14:01:07.382151	2026-06-30 14:01:07.382151		\N
69	15225299085	oWrA81_esql0oaMLcsIiLopvL1Ro	2026-06-30 14:15:27.970106	2026-06-30 14:15:27.970106		\N
70	19137096192	oWrA81wqfJhuq3HGJQDiZ2Ak3Tfs	2026-06-30 14:16:41.440176	2026-06-30 14:16:41.440176		\N
71	19544562686	oWrA814ZbDx9Sa3EUrwREReSYPhY	2026-06-30 14:18:26.599021	2026-06-30 14:18:26.599021		\N
72	17837383155	oWrA819WcGgl_cqgsG8_eviSMIC4	2026-06-30 14:48:03.229392	2026-06-30 14:48:03.229392		\N
73	15836435632	oWrA817pPlLyzrGVF3-hC7nUqcmM	2026-06-30 15:25:08.618728	2026-06-30 15:25:08.618728		\N
74	15238586310	oWrA816bz5qUV3jcjZcEuRMHFH44	2026-06-30 15:30:36.37806	2026-06-30 15:30:36.37806		\N
\.


--
-- Data for Name: remote_open_logs; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.remote_open_logs (id, merchant_id, cabinet_id, device_id, slot_id, slot_number, action_type, operator, result, success, ip_address, created_at) FROM stdin;
1	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:11
2	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:19
3	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:25
4	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:40
5	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:54
6	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:57:00
7	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:57:06
8	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 08:06:49
9	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 08:07:01
10	\N	\N	\N	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:42:00
11	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:43:59
12	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:48:37
13	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:51:17
14	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:56:00
15	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:36:55
16	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:46:50
17	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:51:45
18	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:53:47
19	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 12:34:41
20	\N	\N	123456	1	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
21	\N	\N	123456	2	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
22	\N	\N	123456	3	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
23	\N	\N	123456	4	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
24	\N	\N	123456	5	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
25	\N	\N	123456	6	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
26	\N	\N	123456	7	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
27	\N	\N	123456	8	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
28	\N	\N	123456	9	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
29	\N	\N	123456	10	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
30	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 15:56:00
31	\N	\N	123456	1	\N	admin_batch_open	admin	success	1	\N	2026-06-19 16:07:22
32	\N	\N	123456	2	\N	admin_batch_open	admin	success	1	\N	2026-06-19 16:07:22
33	\N	\N	123456	3	\N	admin_batch_open	admin	success	1	\N	2026-06-19 16:07:22
34	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 16:07:22
35	\N	\N	test	1	1	emergency_open	\N	success	1	\N	2026-06-19 16:43:59
36	\N	\N	123456	1	1	emergency_open	\N	success	1	\N	2026-06-20 00:50:25
37	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 22:21:48
38	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 22:23:28
39	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 02:50:47
40	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 02:58:54
41	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:01:38
42	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:02:07
43	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:30:31
44	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:32:56
45	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:33:42
46	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:43:31
47	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:13:41
48	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-20 04:13:48
49	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:14:13
50	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:14:21
51	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 04:17:51
52	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:25:38
53	\N	\N	123456	98	\N	admin_open	admin	success	1	\N	2026-06-20 04:25:54
54	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-20 10:36:31
55	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-20 22:34:47
56	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-20 22:35:12
57	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 02:03:43
58	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 02:03:57
59	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 02:04:09
60	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:38:48
61	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:40:07
62	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:51:33
63	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-21 07:54:04
64	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:55:17
65	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:55:34
66	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:00:02
67	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:10:13
68	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:10:40
69	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:22:38
70	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:29:29
71	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 13:04:31
72	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 13:05:22
73	\N	\N	123456	153	\N	admin_open	admin	success	1	\N	2026-06-21 13:06:10
74	\N	\N	123456	177	\N	admin_open	admin	success	1	\N	2026-06-21 13:07:43
75	\N	\N	123456	107	\N	admin_open	admin	success	1	\N	2026-06-21 15:08:05
76	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:25:26
77	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:27:37
78	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:31:56
79	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:49:25
80	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 04:49:29
81	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 05:57:34
82	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 05:57:58
83	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 06:08:20
84	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 09:19:12
85	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:19:16
86	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:14
87	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:19
88	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:23
89	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:28
90	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:34
91	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:40
92	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:45
93	\N	\N	123456	98	\N	admin_open	admin	success	1	\N	2026-06-22 10:52:11
94	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 10:52:17
95	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:22
96	\N	\N	123456	98	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:26
97	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:29
98	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:33
99	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 13:01:15
100	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 23:45:38
101	\N	\N	123456	108	\N	admin_open	admin	success	1	\N	2026-06-22 23:45:43
102	\N	\N	123456	145	\N	admin_open	admin	success	1	\N	2026-06-22 23:45:52
103	\N	\N	123456	145	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:01
104	\N	\N	123456	147	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:04
105	\N	\N	123456	148	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:08
106	\N	\N	123456	149	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:11
107	\N	\N	123456	153	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:16
108	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 23:52:33
109	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 23:52:38
110	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 23:53:21
111	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 23:55:27
112	\N	\N	123456	96	\N	admin_open	admin	success	1	\N	2026-06-22 23:56:23
113	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 23:57:56
114	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:05:31
115	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:07:55
116	\N	\N	123456	153	\N	admin_open	admin	success	1	\N	2026-06-23 00:08:26
117	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:09:11
118	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:09:44
119	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:10:25
120	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:13:08
121	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-23 00:13:40
122	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:14:51
123	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:14:55
124	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:16:36
125	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:17:22
126	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:17:38
127	\N	\N	123456	152	\N	admin_open	admin	success	1	\N	2026-06-23 00:18:39
128	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:21:00
129	\N	\N	123456	152	\N	admin_open	admin	success	1	\N	2026-06-23 00:21:03
130	\N	\N	123456	270	\N	admin_open	admin	success	1	\N	2026-06-23 01:00:16
131	\N	\N	123456	271	\N	admin_open	admin	success	1	\N	2026-06-23 01:00:26
132	\N	\N	123456	287	\N	admin_open	admin	success	1	\N	2026-06-23 01:01:01
133	\N	\N	123456	288	\N	admin_open	admin	success	1	\N	2026-06-23 01:01:06
134	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-23 01:01:10
135	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 04:42:15
136	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 06:00:34
137	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 07:40:55
138	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 07:59:01
139	\N	\N	123456	270	\N	admin_open	admin	success	1	\N	2026-06-23 07:59:05
140	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 11:36:57
141	1	8	\N	261	7	emergency_open	\N	success	1	127.0.0.1	2026-06-24 00:43:00
142	\N	\N	123456	256	\N	admin_open	admin	success	1	\N	2026-06-24 01:37:24
143	\N	\N	123456	256	\N	admin_open	admin	success	1	\N	2026-06-24 03:11:29
144	\N	\N	123456	264	\N	admin_open	admin	success	1	\N	2026-06-24 03:44:42
145	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-24 10:07:01
146	\N	\N	123456	258	\N	admin_open	admin	success	1	\N	2026-06-25 08:49:43
147	1	8	\N	255	1	emergency_open	\N	success	1	127.0.0.1	2026-06-25 09:18:38
148	1	8	\N	255	1	emergency_open	\N	success	1	127.0.0.1	2026-06-25 09:18:41
149	1	8	\N	269	15	emergency_open	\N	success	1	127.0.0.1	2026-06-25 09:18:46
150	\N	\N	123456	271	\N	admin_open	admin	success	1	\N	2026-06-25 09:42:12
151	\N	\N	123456	272	\N	admin_open	admin	success	1	\N	2026-06-25 09:59:45
152	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 11:21:09
153	\N	\N	101002	352	\N	admin_open	admin	success	1	\N	2026-06-25 11:21:51
154	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 13:55:20
155	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 13:57:27
156	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:32
157	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:32
158	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:33
159	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:42
160	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:04:53
161	\N	\N	\N	13	\N	admin_open	admin	success	1	\N	2026-06-25 14:14:33
162	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:50:04
163	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:50:15
164	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:50:39
165	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:52:26
166	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:52:32
167	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:54:38
168	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:54:46
169	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:56:57
170	\N	\N	123456	284	\N	admin_open	admin	success	1	\N	2026-06-25 15:29:41
171	\N	\N	123456	286	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:01
172	\N	\N	123456	287	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:17
173	\N	\N	123456	288	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:23
174	\N	\N	123456	289	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:27
175	\N	\N	123456	293	\N	admin_open	admin	success	1	\N	2026-06-25 22:30:46
176	\N	\N	123456	292	\N	admin_open	admin	success	1	\N	2026-06-25 22:30:50
177	\N	\N	123456	291	\N	admin_open	admin	success	1	\N	2026-06-25 22:30:53
178	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-25 22:31:51
179	\N	\N	123456	301	\N	admin_open	admin	success	1	\N	2026-06-25 22:31:57
180	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-25 22:32:00
181	\N	\N	123456	300	\N	admin_open	admin	success	1	\N	2026-06-25 22:32:04
182	\N	\N	123456	293	\N	admin_open	admin	success	1	\N	2026-06-25 22:39:13
183	\N	\N	123456	294	\N	admin_open	admin	success	1	\N	2026-06-25 22:57:24
184	\N	\N	123456	294	\N	admin_open	admin	success	1	\N	2026-06-25 23:11:40
185	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-25 23:11:45
186	\N	\N	123456	294	\N	admin_open	admin	success	1	\N	2026-06-25 23:36:02
187	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-26 00:42:23
188	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-26 00:47:02
189	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-26 00:50:45
190	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:34:58
191	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:34:58
192	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:34:58
193	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:35:17
194	\N	\N	123456	449	\N	admin_open	admin	success	1	\N	2026-06-26 01:35:20
195	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 02:38:40
196	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 06:42:11
197	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 06:47:18
198	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:02:50
199	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-26 07:02:59
200	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:26
201	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:52
202	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:54
203	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:56
204	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:58
205	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-26 07:43:01
206	\N	\N	100100	380	\N	admin_open	admin	success	1	\N	2026-06-26 07:43:04
207	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:58:00
208	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:58:02
209	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-26 07:58:04
210	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 18:00:47.25663
211	\N	\N	100100	368	\N	admin_open	admin	success	1	\N	2026-06-26 18:02:49.428502
212	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 18:03:04.666112
213	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 18:09:25.559611
214	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 19:31:02.96323
215	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 19:31:07.474492
216	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:47:07.639074
217	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:47:18.988
218	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 19:51:55.59031
219	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:54:39.18208
220	\N	\N	100100	365	\N	admin_open	admin	success	1	\N	2026-06-26 19:54:45.935272
221	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:54:50.053577
222	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 19:55:26.839841
223	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 06:35:47.700775
224	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 06:36:00.425405
225	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 07:07:46.863249
226	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 07:07:56.974742
227	\N	\N	100100	366	\N	admin_open	admin	success	1	\N	2026-06-27 07:08:03.695459
228	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-27 09:31:15.5171
229	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-27 09:34:43.557133
230	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 10:03:35.824128
231	\N	\N	100100	365	\N	admin_open	admin	success	1	\N	2026-06-27 10:03:41.08763
232	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-27 10:03:58.509552
233	\N	\N	100100	382	\N	admin_open	admin	success	1	\N	2026-06-27 10:04:08.579255
234	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:17:24.043736
235	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:17:31.858963
236	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:17:51.915017
237	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:18:10.678942
238	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:18:32.586337
239	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:18:56.349357
240	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:20:28.687406
241	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:24:21.048594
242	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:24:44.709947
243	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:25:12.098877
244	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:25:33.222225
245	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:27:03.063312
246	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:27:19.749983
247	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:34:39.219236
248	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:35:05.419812
249	\N	\N	101001	472	\N	admin_open	admin	success	1	\N	2026-06-27 11:36:49.888779
250	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:40:26.06909
251	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:40:35.438744
252	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 11:55:37.797842
253	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 11:55:46.059861
254	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:56:21.144599
255	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:59:35.689044
256	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:59:49.166442
257	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:59:55.756528
258	\N	\N	100100	504	\N	admin_open	admin	success	1	\N	2026-06-27 12:00:00.363297
259	\N	\N	100100	504	\N	admin_open	admin	success	1	\N	2026-06-27 12:00:04.704309
260	\N	\N	100100	496	\N	admin_open	admin	success	1	\N	2026-06-27 12:32:08.114549
261	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:00:41.46164
262	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:00:49.816395
263	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:11:11.861336
264	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:12:07.682438
265	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:13:03.557823
266	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:19:48.827768
267	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:31:38.510832
268	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:42:31.732545
269	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:42:43.807844
270	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:15:32.294565
271	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:17:30.683167
272	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:17:47.831749
273	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:36:38.738447
274	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:36:45.303563
275	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:43:06.440158
276	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 22:44:59.262628
277	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-28 11:01:38.619476
278	\N	\N	100100	511	\N	admin_open	admin	success	1	\N	2026-06-29 14:10:11.866566
279	\N	\N	100100	526	\N	admin_open	admin	success	1	\N	2026-06-29 14:10:25.937038
280	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 14:27:08.84106
281	\N	\N	100100	510	\N	admin_open	admin	success	1	\N	2026-06-29 14:27:13.095342
282	\N	\N	100101	527	\N	admin_open	admin	success	1	\N	2026-06-29 17:58:49.935854
283	\N	\N	100101	527	\N	admin_open	admin	success	1	\N	2026-06-29 17:58:59.422955
284	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 18:01:47.919895
285	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 18:02:57.25271
286	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 18:34:55.13289
287	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 18:48:00.600876
288	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 19:07:16.434661
289	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 19:13:08.164342
290	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 19:13:19.927212
291	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 19:17:15.96919
292	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 19:49:48.533904
293	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 20:04:23.829393
294	\N	\N	100100	511	\N	admin_open	admin	success	1	\N	2026-06-29 20:11:47.030582
295	\N	\N	100100	512	\N	admin_open	admin	success	1	\N	2026-06-29 20:11:49.113197
296	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 21:06:15.866017
297	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 21:06:35.167651
298	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:17:05.307546
299	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:41:33.546361
300	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:42:09.393018
301	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:42:39.13946
302	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:43:24.708841
303	\N	\N	100100	512	\N	admin_open	admin	success	1	\N	2026-06-29 21:44:10.414823
304	\N	\N	100100	512	\N	admin_open	admin	success	1	\N	2026-06-29 21:44:15.14457
305	\N	\N	100100	512	\N	admin_open	admin	success	1	\N	2026-06-29 21:44:23.166384
306	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:45:20.151645
307	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:45:36.32817
308	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:46:10.721647
309	\N	\N	100100	504	\N	admin_open	admin	success	1	\N	2026-06-29 21:46:22.70543
310	\N	\N	100100	512	\N	admin_open	admin	success	1	\N	2026-06-29 21:46:24.689492
311	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:46:50.298239
312	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:47:01.325612
313	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:47:54.088397
314	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:48:14.637
315	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:49:09.383058
316	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:50:59.648433
317	\N	\N	100100	505	\N	admin_open	admin	success	1	\N	2026-06-29 22:54:37.302943
318	\N	\N	100100	505	\N	admin_open	admin	success	1	\N	2026-06-30 06:47:59.299396
319	\N	\N	100100	505	\N	admin_open	admin	success	1	\N	2026-06-30 07:02:42.822988
320	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-30 07:02:49.030649
321	\N	\N	100100	497	\N	admin_open	admin	success	1	\N	2026-06-30 07:02:57.262244
322	\N	\N	100100	496	\N	admin_open	admin	success	1	\N	2026-06-30 07:04:22.006839
323	\N	\N	100100	497	\N	admin_open	admin	success	1	\N	2026-06-30 07:04:22.376033
324	\N	\N	100100	498	\N	admin_open	admin	success	1	\N	2026-06-30 07:04:28.974208
325	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-30 08:45:45.965665
326	\N	\N	100100	516	\N	admin_open	admin	success	1	\N	2026-06-30 10:20:34.08443
327	\N	\N	100100	516	\N	admin_open	admin	success	1	\N	2026-06-30 10:20:42.44505
328	\N	\N	100100	517	\N	admin_open	admin	success	1	\N	2026-06-30 10:58:00.366525
329	\N	\N	100100	517	\N	admin_open	admin	success	1	\N	2026-06-30 10:58:58.868537
330	\N	\N	100101	620	\N	admin_open	admin	success	1	\N	2026-06-30 15:09:22.954176
\.


--
-- Data for Name: sms_codes; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.sms_codes (id, phone, code, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: storage_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.storage_records (id, cabinet_id, compartment_number, user_phone, access_code, status, store_time, retrieve_time, created_at) FROM stdin;
1	1	3	13844445555	1234	1	2026-06-12 12:52:38.906724	2026-06-12 12:52:39.193363	2026-06-12 04:52:39
2	1	4	13800001111	1111	1	2026-06-12 12:58:06.520154	2026-06-12 12:58:06.797935	2026-06-12 04:58:06
3	1	4	13877778888	9999	1	2026-06-12 13:07:27.142639	2026-06-12 13:07:27.422383	2026-06-12 05:07:27
4	8	10	17725196748	1234	2	2026-06-24 14:32:47.145958	2026-06-24 14:34:44.027213	2026-06-24 06:34:44
5	8	10	17725196748	1234	1	2026-06-24 14:32:47.145958	2026-06-24 14:34:57.748019	2026-06-24 06:34:57
6	8	A10	17725196748	1234	1	2026-06-24 15:33:30.907419	2026-06-24 17:57:15.690936	2026-06-24 09:57:15
7	8	A10	17725196748	1234	1	2026-06-24 15:33:30.907419	2026-06-24 20:08:58.563297	2026-06-24 12:08:58
8	8	A1	13667618419	2584	1	2026-06-24 22:37:34.737997	2026-06-24 22:39:50.475957	2026-06-24 14:39:50
9	8	A15	17725196748	1234	2	2026-06-25 17:24:49.211634	2026-06-25 17:27:38.913835	2026-06-25 09:27:38
10	8	A17	17725196748	1234	2	2026-06-25 17:39:37.186267	2026-06-25 17:42:32.72969	2026-06-25 09:42:32
11	8	A18	17725196748	1234	2	2026-06-25 17:47:03.188676	2026-06-25 17:48:56.614529	2026-06-25 09:48:56
12	8	A18	17725196748	1234	1	2026-06-25 17:47:03.188676	2026-06-25 17:49:10.749128	2026-06-25 09:49:10
13	8	A22	13667618419	1234	2	2026-06-25 21:07:31.636984	2026-06-25 21:36:27.913417	2026-06-25 13:36:27
14	8	A42	17726689234	1234	2	2026-06-26 07:07:04.286167	2026-06-26 07:29:38.957188	2026-06-25 23:29:38
15	8	A43	17726689234	1234	2	2026-06-26 07:30:04.21892	2026-06-26 07:34:24.71674	2026-06-25 23:34:24
16	8	4	18888889999	1234	1	2026-06-26 09:42:16.701258	2026-06-26 09:51:26.378147	2026-06-26 01:51:26
17	8	3	18888889999	1234	1	2026-06-26 09:36:04.314655	2026-06-26 09:51:58.611342	2026-06-26 01:51:58
18	8	6	18888889999	1234	1	2026-06-26 09:49:18.491913	2026-06-26 11:31:45.256536	2026-06-26 03:31:45
19	8	7	18888889999	1234	2	2026-06-26 13:13:40.256117	2026-06-26 13:17:38.140905	2026-06-26 05:17:38
20	8	7	18888889999	1234	1	2026-06-26 13:13:40.256117	2026-06-26 13:17:55.427649	2026-06-26 05:17:55
21	16	13	18888889999	1234	2	2026-06-26 19:52:41.308565	2026-06-26 19:55:06.79708	2026-06-26 19:55:06.794832
22	16	13	18888889999	1234	2	2026-06-26 19:52:41.308565	2026-06-26 19:55:19.183534	2026-06-26 19:55:19.181113
23	16	14	18888889999	1234	2	2026-06-26 20:34:40.996024	2026-06-26 20:38:20.736155	2026-06-26 20:38:20.733726
24	16	42	18888889999	1234	2	2026-06-27 10:04:22.568878	2026-06-27 10:07:53.971529	2026-06-27 10:07:53.969284
25	15	10	18996093393	1111	1	2026-06-27 11:21:51.938666	2026-06-27 11:37:31.395637	2026-06-27 11:37:31.393462
26	16	2	18888889999	1234	1	2026-06-27 12:30:01.700717	2026-06-27 12:37:46.547675	2026-06-27 12:37:46.545524
27	16	14	18888889999	1234	2	2026-06-28 07:50:13.359321	2026-06-28 07:51:05.05579	2026-06-28 07:51:05.053476
28	16	14	18888889999	1234	2	2026-06-28 07:50:13.359321	2026-06-28 07:51:22.960896	2026-06-28 07:51:22.95866
29	16	14	18888889999	1234	1	2026-06-28 07:50:13.359321	2026-06-28 07:51:52.073067	2026-06-28 07:51:52.0707
30	16	28	17722332233	2584	1	2026-06-28 15:29:57.720409	2026-06-28 15:31:16.549595	2026-06-28 15:31:16.547281
31	16	25	18888889999	1234	2	2026-06-28 14:51:55.54862	2026-06-28 15:32:12.795953	2026-06-28 15:32:12.793405
32	16	25	18888889999	1234	1	2026-06-28 14:51:55.54862	2026-06-28 15:32:31.404132	2026-06-28 15:32:31.401547
33	16	27	17722332233	1475	1	2026-06-28 15:22:56.856654	2026-06-28 15:34:04.539229	2026-06-28 15:34:04.537009
34	16	19	17722332233	1234	1	2026-06-28 08:45:59.421579	2026-06-28 15:34:06.147277	2026-06-28 15:34:06.144756
35	16	18	17722332233	3698	1	2026-06-28 08:41:05.289221	2026-06-28 15:34:07.976224	2026-06-28 15:34:07.974022
36	24	E1	18996093393	1111	1	2026-06-29 18:57:52.050962	2026-06-29 18:59:17.247001	2026-06-29 18:59:17.245909
37	16	32	13667618419	1234	2	2026-06-29 21:26:26.194231	2026-06-29 21:42:04.194226	2026-06-29 21:42:04.193277
38	16	32	13667618419	1234	1	2026-06-29 21:26:26.194231	2026-06-29 21:42:19.775018	2026-06-29 21:42:19.774136
39	16	19	13667618419	1234	1	2026-06-30 07:07:31.383625	2026-06-30 07:09:41.240801	2026-06-30 07:09:41.239736
40	16	11	13667618419	1234	1	2026-06-29 22:52:24.82795	2026-06-30 07:09:56.648032	2026-06-30 07:09:56.647077
41	16	9	13667618419	1234	1	2026-06-29 22:50:52.343292	2026-06-30 07:10:07.987463	2026-06-30 07:10:07.986451
42	16	23	17726689234	1234	1	2026-06-30 07:11:02.520772	2026-06-30 07:11:50.615626	2026-06-30 07:11:50.614245
43	16	25	17726689234	1234	1	2026-06-30 07:28:23.32169	2026-06-30 07:29:11.513319	2026-06-30 07:29:11.512131
44	16	28	17726689234	1234	1	2026-06-30 07:51:35.654789	2026-06-30 07:52:53.508899	2026-06-30 07:52:53.507574
45	24	E8	18996093393	1234	1	2026-06-30 09:03:54.10188	2026-06-30 09:05:10.563743	2026-06-30 09:05:10.56276
46	24	E9	18996093393	1234	1	2026-06-30 09:11:01.276431	2026-06-30 09:12:48.681011	2026-06-30 09:12:48.679925
47	24	E11	18983079797	1234	1	2026-06-30 09:30:15.203007	2026-06-30 09:31:20.677737	2026-06-30 09:31:20.676985
48	24	E15	18996093393	1234	1	2026-06-30 09:39:05.780707	2026-06-30 09:39:55.003171	2026-06-30 09:39:55.001795
49	16	12	17726689234	4265	1	2026-06-30 09:40:22.786174	2026-06-30 09:53:29.098988	2026-06-30 09:53:29.098118
50	16	18	17726689234	1234	1	2026-06-30 09:54:14.221902	2026-06-30 10:00:30.462017	2026-06-30 10:00:30.461167
51	16	22	17726689234	1234	2	2026-06-30 10:19:43.691053	2026-06-30 10:21:31.732258	2026-06-30 10:21:31.730278
52	16	22	17726689234	1234	2	2026-06-30 10:19:43.691053	2026-06-30 10:21:45.245931	2026-06-30 10:21:45.244904
53	16	22	17726689234	1234	1	2026-06-30 10:19:43.691053	2026-06-30 10:21:59.283675	2026-06-30 10:21:59.282638
54	24	E23	19905939796	8106	2	2026-06-30 10:14:59.088933	2026-06-30 10:53:37.799461	2026-06-30 10:53:37.798423
55	24	E23	19905939796	8106	1	2026-06-30 10:14:59.088933	2026-06-30 10:53:43.919655	2026-06-30 10:53:43.918668
56	16	23	17726689234	1234	1	2026-06-30 10:54:05.502862	2026-06-30 10:55:11.600232	2026-06-30 10:55:11.599401
57	16	27	17726689234	1234	1	2026-06-30 11:04:20.348808	2026-06-30 11:08:12.565185	2026-06-30 11:08:12.563787
58	16	28	17726689234	1234	1	2026-06-30 11:17:58.486108	2026-06-30 11:18:51.346839	2026-06-30 11:18:51.345815
59	24	E24	13667618419	1234	1	2026-06-30 11:26:39.555022	2026-06-30 11:30:18.842996	2026-06-30 11:30:18.840971
60	24	E26	13667618419	1234	1	2026-06-30 11:39:38.085987	2026-06-30 11:42:29.910952	2026-06-30 11:42:29.909578
61	16	29	17726689234	1234	1	2026-06-30 11:45:00.055863	2026-06-30 11:45:41.205097	2026-06-30 11:45:41.203741
62	24	E27	13667618419	1234	1	2026-06-30 12:04:30.058494	2026-06-30 12:05:19.907884	2026-06-30 12:05:19.90699
63	24	E29	13667618419	1234	1	2026-06-30 12:23:21.850439	2026-06-30 12:25:20.681237	2026-06-30 12:25:20.679456
64	24	E30	18265820019	0099	2	2026-06-30 12:38:06.906077	2026-06-30 12:42:03.16104	2026-06-30 12:42:03.160198
65	24	E44	18265005796	7878	2	2026-06-30 12:51:08.816958	2026-06-30 12:52:50.258867	2026-06-30 12:52:50.257887
66	24	E49	19286022436	6666	2	2026-06-30 13:04:51.133104	2026-06-30 13:06:22.755616	2026-06-30 13:06:22.754722
67	24	E47	15657821278	1314	2	2026-06-30 13:04:21.911241	2026-06-30 13:11:11.289929	2026-06-30 13:11:11.288889
68	24	E51	18637010208	1111	2	2026-06-30 13:12:51.853737	2026-06-30 13:14:16.476945	2026-06-30 13:14:16.475925
69	24	E51	18637010208	1111	2	2026-06-30 13:12:51.853737	2026-06-30 13:14:26.397012	2026-06-30 13:14:26.396095
70	24	E51	18637010208	1111	2	2026-06-30 13:12:51.853737	2026-06-30 13:20:02.004368	2026-06-30 13:20:02.003436
71	24	E47	15657821278	1314	1	2026-06-30 13:04:21.911241	2026-06-30 13:41:31.474064	2026-06-30 13:41:31.473033
72	24	E54	18438398466	8466	2	2026-06-30 13:30:57.276719	2026-06-30 13:46:04.435709	2026-06-30 13:46:04.434483
73	24	E53	15275043796	8011	2	2026-06-30 13:29:13.617642	2026-06-30 13:46:30.039567	2026-06-30 13:46:30.037521
74	16	31	17726689234	1234	2	2026-06-30 13:45:59.983915	2026-06-30 13:49:34.851634	2026-06-30 13:49:34.850596
75	16	31	17726689234	1234	1	2026-06-30 13:45:59.983915	2026-06-30 13:49:46.176206	2026-06-30 13:49:46.175068
76	24	E33	15550752925	2925	1	2026-06-30 12:39:32.545394	2026-06-30 13:51:57.650656	2026-06-30 13:51:57.649631
77	24	E53	15275043796	8011	2	2026-06-30 13:29:13.617642	2026-06-30 13:58:33.086826	2026-06-30 13:58:33.085831
78	24	E54	18438398466	8466	2	2026-06-30 13:30:57.276719	2026-06-30 14:02:34.429618	2026-06-30 14:02:34.428599
79	24	E54	18438398466	8466	2	2026-06-30 13:30:57.276719	2026-06-30 14:06:57.955625	2026-06-30 14:06:57.954273
80	24	E51	18637010208	1111	2	2026-06-30 13:12:51.853737	2026-06-30 14:10:57.383062	2026-06-30 14:10:57.382136
84	24	E51	18637010208	1111	2	2026-06-30 13:12:51.853737	2026-06-30 14:14:24.674435	2026-06-30 14:14:24.673478
85	24	E54	18438398466	8466	2	2026-06-30 13:30:57.276719	2026-06-30 14:15:06.129598	2026-06-30 14:15:06.128607
188	24	E13	15656087879	0808	2	2026-06-30 15:51:14.350607	2026-06-30 17:39:18.896291	2026-06-30 17:39:18.895683
87	24	E3	19544562686	1234	2	2026-06-30 14:18:12.222058	2026-06-30 14:19:22.053902	2026-06-30 14:19:22.052904
89	24	E53	15275043796	8011	2	2026-06-30 13:29:13.617642	2026-06-30 14:27:17.732956	2026-06-30 14:27:17.731543
90	24	E49	19286022436	6666	2	2026-06-30 13:04:51.133104	2026-06-30 14:31:28.783358	2026-06-30 14:31:28.782465
92	24	E30	18265820019	0099	2	2026-06-30 12:38:06.906077	2026-06-30 14:39:48.174274	2026-06-30 14:39:48.173322
94	24	E49	19286022436	6666	2	2026-06-30 13:04:51.133104	2026-06-30 14:41:39.478497	2026-06-30 14:41:39.477393
199	16	B32	13667618419	1234	1	2026-06-30 17:06:32.680209	2026-06-30 18:01:54.881842	2026-06-30 18:01:54.880741
198	16	B1	17726689234	1234	1	2026-06-30 17:14:40.953679	2026-06-30 18:01:14.41759	2026-06-30 18:01:14.416481
200	16	B6	17726689234	1234	1	2026-06-30 18:03:49.221853	2026-06-30 18:04:46.044111	2026-06-30 18:04:46.043121
201	16	B3	17726689234	1234	1	2026-06-30 18:03:08.846984	2026-06-30 18:04:49.568652	2026-06-30 18:04:49.5678
202	24	E13	15656087879	0808	1	2026-06-30 15:51:14.350607	2026-06-30 18:23:09.846589	2026-06-30 18:23:09.845366
203	16	B7	17726689234	1234	1	2026-06-30 18:44:08.337573	2026-06-30 18:45:23.615489	2026-06-30 18:45:23.614578
204	16	B9	17726689234	1234	1	2026-06-30 18:54:25.129048	2026-06-30 18:56:02.172187	2026-06-30 18:56:02.171276
111	24	E30	18265820019	0099	2	2026-06-30 12:38:06.906077	2026-06-30 15:02:53.876683	2026-06-30 15:02:53.875753
119	24	E30	18265820019	0099	1	2026-06-30 12:38:06.906077	2026-06-30 15:09:03.912283	2026-06-30 15:09:03.911412
120	24	E46	18326741968	9999	1	2026-06-30 12:51:30.444471	2026-06-30 15:12:49.555653	2026-06-30 15:12:49.55469
121	24	E7	19254304011	4011	2	2026-06-30 14:52:56.59766	2026-06-30 15:14:19.02911	2026-06-30 15:14:19.027825
122	24	E44	18265005796	7878	1	2026-06-30 12:51:08.816958	2026-06-30 15:16:02.743389	2026-06-30 15:16:02.742288
123	24	E60	13791463202	1234	1	2026-06-30 13:48:46.550553	2026-06-30 15:17:35.703566	2026-06-30 15:17:35.702619
124	24	E49	19286022436	6666	1	2026-06-30 13:04:51.133104	2026-06-30 15:18:21.867044	2026-06-30 15:18:21.865765
125	24	E58	18953074181	1234	1	2026-06-30 13:45:55.349822	2026-06-30 15:29:00.86689	2026-06-30 15:29:00.865583
126	24	E5	17837383155	1111	1	2026-06-30 14:47:50.589861	2026-06-30 15:53:14.209131	2026-06-30 15:53:14.208293
127	24	E54	18438398466	8466	1	2026-06-30 13:30:57.276719	2026-06-30 15:54:09.751122	2026-06-30 15:54:09.750178
128	24	E56	15138943614	5219	1	2026-06-30 13:34:04.912326	2026-06-30 16:04:17.891388	2026-06-30 16:04:17.890288
129	24	E12	15238586310	2014	1	2026-06-30 15:30:14.440812	2026-06-30 16:04:59.131753	2026-06-30 16:04:59.130736
130	24	E9	15836435632	1128	1	2026-06-30 15:24:51.048001	2026-06-30 16:09:27.309733	2026-06-30 16:09:27.308745
131	24	E11	15324821187	1013	1	2026-06-30 15:27:26.746166	2026-06-30 16:10:06.640691	2026-06-30 16:10:06.63983
132	24	E3	19544562686	1234	1	2026-06-30 14:18:12.222058	2026-06-30 16:10:29.362563	2026-06-30 16:10:29.361524
133	24	E53	15275043796	8011	1	2026-06-30 13:29:13.617642	2026-06-30 16:12:23.935274	2026-06-30 16:12:23.934446
134	24	E2	19137096192	1223	1	2026-06-30 14:16:16.447977	2026-06-30 16:17:34.491611	2026-06-30 16:17:34.490627
135	24	E63	15225299085	1479	1	2026-06-30 14:15:11.916386	2026-06-30 16:18:10.689029	2026-06-30 16:18:10.688146
136	24	E51	18637010208	1111	1	2026-06-30 13:12:51.853737	2026-06-30 16:31:24.752387	2026-06-30 16:31:24.751435
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.system_settings (id, setting_key, setting_value, description) FROM stdin;
1	deposit_amount	25	保证金金额（元）
2	sms_enabled	false	是否开启短信验证
3	system_name	智能寄存柜系统	系统名称
4	deposit_timeout	24	超时时间（小时）
12	pay_mode	wechat	支付模式：mock=模拟支付，wechat=微信支付
28	order_hide_rate	0	订单隐藏比例(%)
29	order_hide_whitelist	\N	订单隐藏白名单手机号(逗号分隔)
30	duplicate_days	7	重复用户过滤天数
31	duplicate_limit	5	重复用户过滤单数
32	duplicate_filter_enabled	0	是否开启重复用户过滤
3943	channel_rotation_mode	round_robin	支付渠道轮转模式: round_robin=严格轮转, weighted=加权随机
4024	test_key	test_value	\N
11185	allow_h5_to_mp	1	是否允许H5跳转小程序
\.


--
-- Data for Name: user_balance_details; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.user_balance_details (id, user_phone, order_id, amount, source_time, status, created_at) FROM stdin;
2	18996093393	28	20.00	2026-06-13 10:40:52.646938	available	2026-06-30 15:03:06.443668
7	17725196748	299	20.00	2026-06-26 09:25:55	available	2026-06-30 15:03:06.443668
8	17725196748	300	20.00	2026-06-26 09:25:55	available	2026-06-30 15:03:06.443668
9	17725196748	301	20.00	2026-06-26 09:25:55	available	2026-06-30 15:03:06.443668
10	17725196748	302	20.00	2026-06-26 09:25:55	available	2026-06-30 15:03:06.443668
11	18888889999	312	20.00	2026-06-26 09:35:30	available	2026-06-30 15:03:06.443668
12	18888889999	313	20.00	2026-06-26 09:36:04.314655	available	2026-06-30 15:03:06.443668
13	18888889999	314	20.00	2026-06-26 09:42:16.701258	available	2026-06-30 15:03:06.443668
14	18888889999	317	20.00	2026-06-26 13:13:40.256117	available	2026-06-30 15:03:06.443668
15	18888889999	353	20.00	2026-06-27 12:36:26	available	2026-06-30 15:03:06.443668
16	18996093393	358	20.00	2026-06-26 21:11:50.818076	available	2026-06-30 15:03:06.443668
17	18996093393	359	20.00	2026-06-27 02:01:04	available	2026-06-30 15:03:06.443668
18	18888889999	368	20.00	2026-06-27 12:41:16	available	2026-06-30 15:03:06.443668
19	18996093393	374	1.00	2026-06-27 12:40:46	available	2026-06-30 15:03:06.443668
20	18888889999	379	20.00	2026-06-28 07:21:51	available	2026-06-30 15:03:06.443668
21	18996093393	385	1.00	2026-06-28 08:30:57.233902	available	2026-06-30 15:03:06.443668
22	18983079797	386	1.00	2026-06-27 18:06:36.345558	available	2026-06-30 15:03:06.443668
23	18888889999	390	20.00	2026-06-28 07:50:13.355498	available	2026-06-30 15:03:06.443668
24	18996093393	391	1.00	2026-06-28 08:31:00.780515	available	2026-06-30 15:03:06.443668
25	18888889999	400	20.00	2026-06-29 08:51:01	available	2026-06-30 15:03:06.443668
26	18888889999	401	20.00	2026-06-28 17:48:14	available	2026-06-30 15:03:06.443668
27	18996093393	412	20.00	2026-06-29 18:57:52.048506	available	2026-06-30 15:03:06.443668
28	18996093393	454	20.00	2026-06-30 09:03:54.081831	available	2026-06-30 15:03:06.443668
29	18996093393	457	20.00	2026-06-30 09:11:01.254235	available	2026-06-30 15:03:06.443668
30	18983079797	461	20.00	2026-06-30 09:30:15.181189	available	2026-06-30 15:03:06.443668
31	18996093393	469	20.00	2026-06-30 09:39:05.759763	available	2026-06-30 15:03:06.443668
32	19905939796	484	20.00	2026-06-30 10:14:59.067319	available	2026-06-30 15:03:06.443668
33	15550752925	503	20.00	2026-06-30 12:39:32.523626	available	2026-06-30 15:03:06.443668
34	15657821278	517	20.00	2026-06-30 13:04:21.890156	available	2026-06-30 15:03:06.443668
35	18265820019	501	20.00	2026-06-30 15:09:03.911412	pending	2026-06-30 15:09:03.911412
36	18326741968	516	20.00	2026-06-30 15:12:49.55469	available	2026-06-30 15:12:49.55469
37	18265005796	514	20.00	2026-06-30 15:16:02.742288	pending	2026-06-30 15:16:02.742288
38	13791463202	532	20.00	2026-06-30 15:17:35.702619	available	2026-06-30 15:17:35.702619
39	19286022436	519	20.00	2026-06-30 15:18:21.865765	available	2026-06-30 15:18:21.865765
40	18953074181	528	20.00	2026-06-30 15:29:00.865583	available	2026-06-30 15:29:00.865583
41	17726689234	548	20.00	2026-06-30 15:37:21.900677	withdrawn	2026-06-30 15:37:21.900677
42	17837383155	541	20.00	2026-06-30 15:53:14.208293	available	2026-06-30 15:53:14.208293
43	18438398466	524	20.00	2026-06-30 15:54:09.750178	available	2026-06-30 15:54:09.750178
44	15138943614	526	20.00	2026-06-30 16:04:17.890288	available	2026-06-30 16:04:17.890288
45	15238586310	547	20.00	2026-06-30 16:04:59.130736	available	2026-06-30 16:04:59.130736
46	15836435632	545	20.00	2026-06-30 16:09:27.308745	available	2026-06-30 16:09:27.308745
48	19544562686	539	20.00	2026-06-30 16:10:29.361524	pending	2026-06-30 16:10:29.361524
49	15275043796	523	20.00	2026-06-30 16:12:23.934446	pending	2026-06-30 16:12:23.934446
51	15225299085	535	20.00	2026-06-30 16:18:10.688146	available	2026-06-30 16:18:10.688146
52	18637010208	521	20.00	2026-06-30 16:31:24.751435	pending	2026-06-30 16:31:24.751435
50	19137096192	538	20.00	2026-06-30 16:17:34.490627	pending	2026-06-30 16:17:34.490627
53	17726689234	551	20.00	2026-06-30 18:01:14.416481	withdrawn	2026-06-30 18:01:14.416481
56	17726689234	553	20.00	2026-06-30 18:04:49.5678	withdrawn	2026-06-30 18:04:49.5678
55	17726689234	555	20.00	2026-06-30 18:04:46.043121	withdrawn	2026-06-30 18:04:46.043121
6	13667618419	34	20.00	2026-06-20 07:28:25.534453	pending	2026-06-30 15:03:06.443668
5	13667618419	33	20.00	2026-06-20 07:28:30.680119	pending	2026-06-30 15:03:06.443668
4	13667618419	30	20.00	2026-06-20 07:28:42.627193	pending	2026-06-30 15:03:06.443668
3	13667618419	29	20.00	2026-06-20 07:28:37.901891	pending	2026-06-30 15:03:06.443668
1	13667618419	25	20.00	2026-06-18 16:24:07.583328	pending	2026-06-30 15:03:06.443668
54	13667618419	550	20.00	2026-06-30 18:01:54.880741	withdrawn	2026-06-30 18:01:54.880741
58	18254067609	506	20.00	2026-06-30 18:27:44.766091	available	2026-06-30 18:27:44.766091
59	17726689234	556	20.00	2026-06-30 18:45:23.614578	withdrawn	2026-06-30 18:45:23.614578
60	17726689234	558	20.00	2026-06-30 18:56:02.171276	withdrawn	2026-06-30 18:56:02.171276
57	15656087879	549	20.00	2026-06-30 18:23:09.845366	pending	2026-06-30 18:23:09.845366
47	15324821187	546	20.00	2026-06-30 16:10:06.63983	pending	2026-06-30 16:10:06.63983
\.


--
-- Data for Name: user_balances; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.user_balances (id, phone, balance, total_deposited, total_withdrawn, first_use_time, created_at, wechat_name, openid, unionid) FROM stdin;
31	18438398466	40	40	0	2026-06-30 13:31:26.666245	2026-06-30 13:31:26.664399			\N
43	15138943614	20	20	0	2026-06-30 16:04:17.893278	2026-06-30 16:04:17.890288			\N
41	15238586310	40	40	0	2026-06-30 15:30:47.066451	2026-06-30 15:30:47.06444			\N
35	19544562686	0	40	20	2026-06-30 14:18:37.079977	2026-06-30 14:18:37.078243			\N
25	19905939796	20	20	0	2026-06-30 10:53:43.923934	2026-06-30 10:53:43.918668			\N
45	19137096192	0	20	20	2026-06-30 16:17:34.493401	2026-06-30 16:17:34.490627			\N
39	19286022436	0	20	0	2026-06-30 15:18:21.868913	2026-06-30 15:18:21.865765			\N
47	18637010208	-20	20	20	2026-06-30 16:31:24.754185	2026-06-30 16:31:24.751435			\N
2	13667618419	160	340	180	2026-06-12 13:50:47	2026-06-12 13:50:47	\N		\N
49	18254067609	20	20	0	2026-06-30 18:28:15.649222	2026-06-30 18:28:15.649222			\N
20	17726689234	0	240	140	2026-06-26 07:04:32.799063	2026-06-25 23:04:32	\N		\N
7	13800138000	0	0	0	2026-06-12 04:31:14	2026-06-12 04:31:14	\N		\N
22	18888889999	0	120	120	2026-06-26 09:38:11.776791	2026-06-26 01:38:11	\N		\N
23	18983079797	41	41	0	2026-06-27 18:04:23.736538	2026-06-27 18:04:23.731391			\N
15	18996093393	142	142	0	2026-06-13 00:48:12	2026-06-13 00:48:12	\N		\N
1	13667164843	0	0	0	2026-06-13 04:29:00	2026-06-13 04:29:00	\N		\N
27	15806753783	20	20	0	2026-06-30 12:40:50.15943	2026-06-30 12:40:50.157881			\N
4	13667618494	0	0	0	2026-06-13 08:45:25	2026-06-13 08:45:25	\N		\N
5	13667619418	0	0	0	2026-06-12 14:06:46	2026-06-12 14:06:46	\N		\N
6	13800001111	0	0	0	2026-06-12 04:57:50	2026-06-12 04:57:50	\N		\N
8	13811112222	0	0	0	2026-06-12 04:37:27	2026-06-12 04:37:27	\N		\N
9	13833334444	0	0	0	2026-06-12 04:41:06	2026-06-12 04:41:06	\N		\N
10	13844445555	0	0	0	2026-06-12 04:52:38	2026-06-12 04:52:38	\N		\N
11	13855556666	0	0	0	2026-06-12 04:57:20	2026-06-12 04:57:20	\N		\N
12	13877778888	0	0	0	2026-06-12 05:07:27	2026-06-12 05:07:27	\N		\N
13	13900001111	0	0	0	2026-06-11 08:46:51	2026-06-11 08:46:51	\N		\N
37	18265820019	0	20	20	2026-06-30 15:09:03.914187	2026-06-30 15:09:03.911412			\N
14	13900139000	0	0	0	2026-06-15 04:33:51	2026-06-15 04:33:51	\N		\N
21	18896963355	0	0	0	2026-06-26 09:27:18.112343	2026-06-26 01:27:18	\N		\N
29	18326741968	40	40	0	2026-06-30 12:52:31.091806	2026-06-30 12:52:31.08996			\N
33	18953074181	40	40	0	2026-06-30 13:46:23.955858	2026-06-30 13:46:23.954144			\N
16	13667618719	0	0	0	2026-06-23 22:42:29.591611	2026-06-23 14:42:29	\N		\N
24	17722332233	0	80	80	2026-06-28 08:41:27.717903	2026-06-28 08:41:27.715242			\N
26	15617060696	20	20	0	2026-06-30 12:40:07.35341	2026-06-30 12:40:07.351634			\N
32	15657821278	20	20	0	2026-06-30 13:41:31.475858	2026-06-30 13:41:31.473033			\N
34	15550752925	20	20	0	2026-06-30 13:51:57.652261	2026-06-30 13:51:57.649631			\N
17	17725196748	0	0	0	2026-06-24 10:25:47.775458	2026-06-24 02:25:47	\N		\N
36	19254304011	20	20	0	2026-06-30 14:53:12.631388	2026-06-30 14:53:12.629742			\N
28	18265005796	0	40	20	2026-06-30 12:51:45.822212	2026-06-30 12:51:45.820534			\N
38	13791463202	20	20	0	2026-06-30 15:17:35.705352	2026-06-30 15:17:35.702619			\N
42	17837383155	20	20	0	2026-06-30 15:53:14.210799	2026-06-30 15:53:14.208293			\N
30	15275043796	0	40	20	2026-06-30 13:29:47.109922	2026-06-30 13:29:47.107098			\N
46	15225299085	20	20	0	2026-06-30 16:18:10.690747	2026-06-30 16:18:10.688146			\N
44	15836435632	0	20	0	2026-06-30 16:09:27.311529	2026-06-30 16:09:27.308745			\N
48	15656087879	0	20	0	2026-06-30 18:23:09.849548	2026-06-30 18:23:09.845366			\N
40	15324821187	20	40	0	2026-06-30 15:27:44.657406	2026-06-30 15:27:44.656072			\N
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.user_profiles (openid, wechat_name, updated_at, unionid) FROM stdin;
oLhbm2EIT023DkRuiPqj6APR4ihs	智空	2026-06-30 14:42:08.867673	\N
oLhbm2OIiOVK8BGCSaFS6o-Y1FXI	微信用户	2026-06-30 14:47:22.443827	\N
oLhbm2CXJc6pavQnuCs6MckJCwas	乐观的悲观者	2026-06-30 14:47:29.733244	\N
oLhbm2OvV35n-SHDJjFh0s28rBhw	微信用户	2026-06-30 14:52:30.384804	\N
oLhbm2AvvUOwVozZZfm5HcFIqo2M	力	2026-06-30 14:52:38.141819	\N
oLhbm2ABYy3nt1CKFaBxbpHBdXcc	微信用户	2026-06-30 14:52:41.121321	\N
oLhbm2EsutFALRZhVWPATION6_Ng	.	2026-06-30 14:52:50.267843	\N
oLhbm2H09XtplEUhVW46VY-c1Xf4	微信用户	2026-06-30 15:15:02.601331	\N
oLhbm2DjPAgvVpBQdWbtZv0pn4WM	易小名	2026-06-30 15:24:34.606998	\N
oLhbm2PBws2XUF7Sol5n-zB4y-iw	微信用户	2026-06-30 15:24:41.471846	\N
oLhbm2OgNeOSiAfcoTRzC12cPJMw	沐泽.	2026-06-30 15:24:54.36629	\N
oLhbm2AZnD3s6cyNda3cnHyPQYyM	微信用户	2026-06-30 15:27:05.954123	\N
oLhbm2I0XFboukiKwYeoAhtiD-Rw	不考一本不改名	2026-06-30 15:27:14.809806	\N
oLhbm2EAwGhxbH1ky5KZDqCH4Aw4	微信用户	2026-06-30 12:37:36.228497	\N
oLhbm2H6Cfq3ycUGbXyF_PdQhJAk	-	2026-06-30 12:37:48.740227	\N
oLhbm2N5EDl6FFtWeHD3cOPuH1ns	Lucas	2026-06-30 12:38:04.599553	\N
oLhbm2HcW7tlAex7RZXoFI0kuvw4	微信用户	2026-06-30 12:39:01.103008	\N
oLhbm2Dl7uLa70dVcAb9F27u-HWk	微信用户	2026-06-30 12:39:04.096454	\N
oLhbm2LLh7ggG9qQlPIYvGCzFgTQ	闲游一生	2026-06-30 12:39:08.336324	\N
oLhbm2Ca0aITNBPd86WtJmeRDK8o	微信用户	2026-06-30 12:39:11.400789	\N
oLhbm2FDANhiUAWBXIAONn214dqI	微信用户	2026-06-30 12:39:12.06236	\N
oLhbm2B51PnUhE7xLwREJUvZ6EEI	微信用户	2026-06-30 12:39:18.062911	\N
oLhbm2KvyCUTFmrM3cKFpKTNOJAg	王语诺	2026-06-30 12:39:19.818554	\N
oLhbm2EhTRGAcmO8GqNc97KHagLw	R	2026-06-30 12:39:21.704179	\N
oLhbm2NCQcJbu27amdxV0CAIJQNM	微信用户	2026-06-30 12:39:23.520131	\N
oLhbm2MjWCP87tHOgcoOh1lBQjoo	云雾	2026-06-30 12:39:35.140439	\N
oLhbm2Oiyq0fdl-stXmjrMU3JiGg	.	2026-06-30 12:39:39.262795	\N
oLhbm2NPmTXytEfJHCQe8A0TPKyE	微信用户	2026-06-30 09:29:57.226934	\N
oLhbm2HnWSjZrQUXeSOA4N449J0E	单思豪	2026-06-30 12:39:54.343009	\N
oLhbm2E9D3EVMJSh1Y1TM7tvYg4A	微信用户	2026-06-30 12:40:50.239157	\N
oLhbm2JuYEboN4SxLUlNKpfSfT24	阿啵	2026-06-30 12:40:59.611252	\N
oLhbm2A6JtOJDpTlfI_IMhKZwr9Y	微信用户	2026-06-30 12:49:55.638167	\N
oLhbm2MNeHErtSinzW5UZduIFMRE	十二.	2026-06-30 12:50:10.564032	\N
oLhbm2LrGNu2Ka_r96cs6wF-Tu0E	小王	2026-06-30 12:50:23.075585	\N
oLhbm2F46i0hw0ncI9vJ6QL0p2Y8	智能寄存柜	2026-06-30 09:50:01.910301	\N
oLhbm2HsJGTwT1dgbemrapthwWS0	微信用户	2026-06-30 12:50:27.616279	\N
oLhbm2DEq7Wqmw5hMe-5kDGnHqPk	微信用户	2026-06-30 15:29:37.644653	\N
oLhbm2EoF3zqez6Iu7dbSwFcCdCA	微信用户	2026-06-30 10:14:21.492037	\N
oLhbm2DpiO4RBSoDGSY5fG7qbRSk	熊页翔	2026-06-30 10:14:36.191432	\N
oLhbm2L37l3xIo9NfOo1XoQXCq54	吴彦祖	2026-06-30 12:50:41.87017	\N
oLhbm2FLRJGUPAfzViiQHKngpXqU	微信用户	2026-06-30 12:50:43.073925	\N
oLhbm2Llm6eRKQfe2xuISqK2gOkQ	王长军	2026-06-30 12:50:53.07693	\N
oLhbm2Owiw63J-xSNSs89hgdtvuc	花园吴洋	2026-06-30 15:29:51.059919	\N
oLhbm2PIllEdcv-LGy1MALDhyuQY	微信用户	2026-06-30 10:42:02.689322	\N
oLhbm2E8bLv1WOodh6RQta1A_fDU	明月人静夜	2026-06-30 10:42:10.889456	\N
oLhbm2IDJeTxYyadP8lnXcbVbXaw	瑾儿	2026-06-30 10:42:34.330377	\N
oLhbm2KI-nFeB8GquYu3BRHKG4Ho	微信用户	2026-06-30 15:50:53.414424	\N
oLhbm2KV03rQh9xd6xQ8Gj42cA2I	烟雨	2026-06-30 15:51:02.799344	\N
oLhbm2J6Kzl6-UFdSrodo05bkES4	微信用户	2026-06-30 13:03:55.15686	\N
oLhbm2LPScxGqKQwih_qAzbspcac	初心	2026-06-30 13:04:04.444317	\N
oLhbm2HEFZP-hSYr5ZGwGQDEArNw	小星	2026-06-30 13:04:33.735222	\N
oLhbm2OXtnYOix_zmbmo57vCQuyA	微信用户	2026-06-30 13:12:31.648195	\N
oLhbm2Ox2Z7oerbXhmM7Cb3Qv3mQ	 	2026-06-30 13:12:37.299486	\N
oLhbm2O6OboL0tQL7Kl6V1XC8iPg	微信用户	2026-06-30 13:28:44.737746	\N
oLhbm2BclnrQy_uaR6Mgf9V0vsWQ	卖鸡的卖鸡的卖鸡的收摊！！！	2026-06-30 13:28:52.901929	\N
oLhbm2OM7IdiwSgi40RfJo27jvTc	微信用户	2026-06-30 13:30:35.433104	\N
oLhbm2ITc8YCUR8upK8PIRRy6xqc	诸葛匹夫子	2026-06-30 13:30:45.855339	\N
oLhbm2HxZeKl4csdD5gkM7bmurj0	微信用户	2026-06-30 13:33:36.40807	\N
oLhbm2FX0qKKA9juI_bTL7i_bdeg	骑猪看夕阳	2026-06-30 13:33:45.443291	\N
oLhbm2BaKKHhX9pfBL-K7Jj7lTR4	微信用户	2026-06-30 13:45:34.052405	\N
oLhbm2H3hzWZ79Aku76YUHNt7OHw	望眠屿	2026-06-30 13:45:41.442991	\N
oLhbm2CegcLUOudngMNwdzBhHA7U	666智能寄存柜	2026-06-30 21:48:15.73384	\N
oLhbm2BX88UBKYrByTPrvBS6hCKA	微信用户	2026-06-30 13:47:58.643716	\N
oLhbm2L5idqDPVz28EQ4Ir6HIvCU	逸逸的奇妙冒险	2026-06-30 13:48:24.336655	\N
oLhbm2DHcugL3Ez0gSfl4vlKPIUw	？？？	2026-06-30 22:56:08.465618	\N
oLhbm2GvwSDsBQ8sQpGBSI7Mn54U	微信用户	2026-06-30 13:55:01.997929	\N
oLhbm2IWu4x8r-U9ZFh4E7Tw55ZE	五万五	2026-06-30 13:55:08.123387	\N
oLhbm2Ks4WcpQdMtm6cri6aJ9MN0	Shhshiii_	2026-06-30 14:00:36.769047	\N
oLhbm2EToXyVevCGUzDTqLV8gSuc	微信用户	2026-06-30 14:14:40.616727	\N
oLhbm2KrlZvBmZAyjLvWIz84Y9Ys	....King	2026-06-30 14:14:48.395104	\N
oLhbm2EqedLPca2_VAPNwPSg919U	微信用户	2026-06-30 14:14:52.478552	\N
oLhbm2E8WSNST7xidFWa1K6w-eq4	雪芙🍰	2026-06-30 14:15:00.523837	\N
oLhbm2DLwLhKx1sJJ9nFrDzPuoWI	乐游	2026-06-30 14:15:25.692415	\N
oLhbm2KhBL_EwHD5hvwekgdwC8TQ	微信用户	2026-06-30 14:15:48.485369	\N
oLhbm2Nyj6xFLVYq5lMRnukqNRQw	Kovy.🍀	2026-06-30 14:15:57.078296	\N
oLhbm2Fo3JFprUsWfsfSS5mmF8WA	微信用户	2026-06-30 14:17:45.36862	\N
oLhbm2KSXafPUmo7PMKg3qp8fqHQ	X	2026-06-30 14:17:57.927567	\N
\.


--
-- Data for Name: withdrawal_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.withdrawal_records (id, order_id, user_phone, amount, status, apply_time, approve_time, approver, click_count, auto_approve_time, created_at, openid, error_msg, order_ids) FROM stdin;
3	\N	17725196748	20	3	2026-06-24 03:03:43	\N	\N	1	\N	2026-06-24 03:03:43	\N	\N	[]
4	\N	13667618419	20	3	2026-06-24 03:07:02	\N	\N	1	\N	2026-06-24 03:07:02	\N	\N	[]
5	\N	17725196748	20	3	2026-06-24 03:57:10	\N	\N	1	\N	2026-06-24 03:57:10	\N	\N	[]
6	\N	13667618419	10	3	2026-06-24 04:15:03	\N	\N	1	\N	2026-06-24 04:15:03	\N	\N	[]
7	\N	17725196748	20	2	2026-06-24 04:16:56	\N	\N	1	\N	2026-06-24 04:16:56	\N	\N	[]
9	\N	17725196748	20	3	2026-06-24 06:35:26	\N	\N	1	2026-06-24 06:35:26	2026-06-24 06:35:26	\N	\N	[]
10	\N	17725196748	20	3	2026-06-24 09:45:35	2026-06-24 09:47:18	admin	1	\N	2026-06-24 09:45:35	\N	\N	[]
14	196	17725196748	20	2	2026-06-24 12:08:58	2026-06-25 10:06:55	\N	1	2026-06-24 20:08:58	2026-06-24 12:08:58	\N	\N	[]
15	198	13667618419	20	2	2026-06-24 14:39:50	2026-06-25 10:06:56	\N	1	2026-06-24 22:39:50	2026-06-24 14:39:50	\N	\N	[]
17	\N	17725196748	40	3	2026-06-24 15:23:46	\N	\N	1	2026-06-24 15:23:46	2026-06-24 15:23:46	\N	\N	[]
18	129	13800138000	20	3	2026-06-24 16:59:19	\N	\N	1	2026-06-24 16:59:19	2026-06-24 16:59:19	\N	\N	[]
19	129	13800138000	20	3	2026-06-24 17:03:24	\N	\N	1	2026-06-24 17:03:24	2026-06-24 17:03:24	\N	\N	[]
20	277	17725196748	20	3	2026-06-25 09:49:11	\N	\N	1	2026-06-25 17:49:11	2026-06-25 09:49:11	\N	\N	[]
32	277	17725196748	20	2	2026-06-25 10:51:58	\N	system	1	2026-06-25 10:51:58	2026-06-25 10:51:58	\N	\N	[]
33	276	17725196748	10	2	2026-06-25 11:26:30	\N	system	1	2026-06-25 11:26:30	2026-06-25 11:26:30	\N	\N	[]
34	275	17725196748	20	2	2026-06-25 11:38:03	\N	system	1	2026-06-25 11:38:03	2026-06-25 11:38:03	\N	\N	[]
39	316	18888889999	20	2	2026-06-26 04:04:47	\N	system	1	2026-06-26 04:04:47	2026-06-26 04:04:47	\N	\N	[]
40	318	18888889999	20	2	2026-06-26 06:54:23	\N	system	1	2026-06-26 06:54:23	2026-06-26 06:54:23	\N	\N	[]
79	390	18888889999	20	2	2026-06-28 08:02:31.470551	\N	\N	1	2026-06-28 08:02:31.470551+08	2026-06-28 08:02:31.470551		\N	[]
94	\N	17722332233	100	5	2026-06-28 15:33:50.52335	\N	system_cleanup	1	\N	2026-06-28 15:33:50.52335	\N	\N	[]
38	315	18888889999	20	2	2026-06-26 02:48:21	\N	system	1	2026-06-26 02:48:21	2026-06-26 02:48:21	\N	订单已全额退款	[]
35	284	13667618419	20	3	2026-06-26 00:04:10	\N	\N	1	2026-06-26 00:04:10	2026-06-26 00:04:10	\N	\N	[]
36	188	13667618719	20	3	2026-06-26 00:06:38	\N	\N	1	2026-06-26 00:06:38	2026-06-26 00:06:38	\N	\N	[]
80	\N	18888889999	20	5	2026-06-28 08:39:07.769374	\N	system_cleanup	1	\N	2026-06-28 08:39:07.769374		\N	[]
44	302	17725196748	20	3	2026-06-26 21:07:22.894042	\N	\N	1	2026-06-26 21:07:22.894042+08	2026-06-26 21:07:22.894042	\N	\N	[]
45	302	17725196748	20	3	2026-06-26 21:11:30.524503	\N	\N	1	2026-06-26 21:11:30.524503+08	2026-06-26 21:11:30.524503	\N	\N	[]
85	\N	18888889999	460	5	2026-06-28 15:18:39.397813	\N	system_cleanup	1	\N	2026-06-28 15:18:39.397813	\N	\N	[]
86	\N	18888889999	460	5	2026-06-28 15:18:43.106437	\N	system_cleanup	1	\N	2026-06-28 15:18:43.106437	\N	\N	[]
87	\N	18888889999	460	5	2026-06-28 15:18:49.610057	\N	system_cleanup	1	\N	2026-06-28 15:18:49.610057	\N	\N	[]
83	\N	13800138000	10	5	2026-06-28 10:49:16.606119	\N	system_cleanup	1	\N	2026-06-28 10:49:16.606119	\N	\N	[]
21	\N	13800138000	5	3	2026-06-25 09:57:30	\N	\N	1	\N	2026-06-25 09:57:30	\N	\N	[]
43	302	17725196748	20	2	2026-06-26 19:56:16.528003	\N	\N	1	2026-06-26 19:56:16.528003+08	2026-06-26 19:56:16.528003	\N	\N	[]
88	\N	18888889999	460	5	2026-06-28 15:20:59.819987	\N	system_cleanup	1	\N	2026-06-28 15:20:59.819987	\N	\N	[]
22	\N	13800138000	5	3	2026-06-25 09:57:54	\N	\N	1	\N	2026-06-25 09:57:54	\N	\N	[]
89	\N	18888889999	460	5	2026-06-28 15:21:02.545764	\N	system_cleanup	1	\N	2026-06-28 15:21:02.545764	\N	\N	[]
23	265	13800138000	20	3	2026-06-25 09:58:35	\N	\N	1	\N	2026-06-25 09:58:35	\N	\N	[]
84	\N	13800138000	10	5	2026-06-28 12:16:47.023477	\N	system_cleanup	1	\N	2026-06-28 12:16:47.023477	\N	\N	[]
81	391	18996093393	47	5	2026-06-28 09:04:09.5201	\N	system_cleanup	1	\N	2026-06-28 09:04:09.5201	oLhbm2LrGNu2Ka_r96cs6wF-Tu0E	\N	[]
82	393	18983079797	3	5	2026-06-28 09:04:20.367748	\N	system_cleanup	1	\N	2026-06-28 09:04:20.367748	oLhbm2F46i0hw0ncI9vJ6QL0p2Y8	\N	[]
90	\N	17722332233	40	5	2026-06-28 15:22:32.563121	\N	system_cleanup	1	\N	2026-06-28 15:22:32.563121	\N	\N	[]
78	389	18888889999	20	4	2026-06-28 07:56:51.812019	\N	\N	1	2026-06-28 07:56:51.812019+08	2026-06-28 07:56:51.812019		记录不存在	[]
91	\N	13800138000	1	5	2026-06-28 15:24:18.840454	\N	system_cleanup	1	\N	2026-06-28 15:24:18.840454	\N	\N	[]
92	\N	17722332233	60	5	2026-06-28 15:24:30.750934	\N	system_cleanup	1	\N	2026-06-28 15:24:30.750934	\N	\N	[]
93	\N	17722332233	60	5	2026-06-28 15:24:32.700862	\N	system_cleanup	1	\N	2026-06-28 15:24:32.700862	\N	\N	[]
95	\N	17722332233	160	5	2026-06-28 16:07:49.110583	\N	system_cleanup	1	\N	2026-06-28 16:07:49.110583	\N	\N	[]
96	\N	17722332233	160	5	2026-06-28 16:07:50.923614	\N	system_cleanup	1	\N	2026-06-28 16:07:50.923614	\N	\N	[]
97	408	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N	[]
98	407	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N	[]
99	397	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N	[]
100	396	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N	[]
101	307	17726689234	20	2	2026-06-28 16:23:28.184636	\N	\N	1	2026-06-28 16:23:28.184636+08	2026-06-28 16:23:28.184636	\N	\N	[]
102	405	18888889999	20	2	2026-06-28 17:25:25.120129	\N	\N	1	2026-06-28 17:25:25.120129+08	2026-06-28 17:25:25.120129	\N	\N	[]
123	497	17726689234	20	2	2026-06-30 11:45:56.681978	\N	\N	1	2026-06-30 11:45:56.681978+08	2026-06-30 11:45:56.681978	\N	\N	[]
122	\N	13667618419	20	2	2026-06-30 11:42:48.554701	2026-06-30 11:50:07.656641	admin	1	\N	2026-06-30 11:42:48.554701		\N	[]
142	553	17726689234	20	2	2026-06-30 18:13:57.300004	2026-06-30 18:18:44.811429	admin	1	\N	2026-06-30 18:13:57.300004	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N	[]
151	556	17726689234	20	2	2026-06-30 18:53:55.270986	2026-06-30 19:50:30.618775	admin	1	\N	2026-06-30 18:53:55.270986	oLhbm2CegcLUOudngMNwdzBhHA7U	\N	[]
104	413	13667618419	20	2	2026-06-29 22:15:00.717779	\N	\N	1	2026-06-29 22:15:00.717779+08	2026-06-29 22:15:00.717779	\N	\N	[]
105	\N	18996093393	40	2	2026-06-30 09:13:17.248572	2026-06-30 09:51:24.294182	admin	1	\N	2026-06-30 09:13:17.248572	\N	\N	[]
106	\N	18983079797	41	2	2026-06-30 09:32:29.817975	2026-06-30 09:51:27.695488	admin	1	\N	2026-06-30 09:32:29.817975	\N	\N	[]
107	470	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
108	458	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
109	441	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
110	440	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
111	438	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
112	436	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
113	306	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
114	303	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
115	481	17726689234	20	2	2026-06-30 10:00:36.24959	\N	\N	1	2026-06-30 10:00:36.24959+08	2026-06-30 10:00:36.24959	\N	\N	[]
116	488	17726689234	20	2	2026-06-30 11:00:44.841762	\N	\N	1	2026-06-30 11:00:44.841762+08	2026-06-30 11:00:44.841762	\N	\N	[]
117	487	17726689234	20	2	2026-06-30 11:00:44.841762	\N	\N	1	2026-06-30 11:00:44.841762+08	2026-06-30 11:00:44.841762	\N	\N	[]
118	492	17726689234	20	2	2026-06-30 11:05:07.460834	\N	\N	1	2026-06-30 11:05:07.460834+08	2026-06-30 11:05:07.460834	\N	\N	[]
136	\N	18265005796	20	0	2026-06-30 15:16:16.196909	\N	\N	1	\N	2026-06-30 15:16:16.196909		\N	[514]
77	332	18888889999	20	2	2026-06-27 19:22:32.159527	\N	system	1	2026-06-27 19:22:32.159527+08	2026-06-27 19:22:32.159527	\N	订单已全额退款	[]
125	498	13667618419	20	2	2026-06-30 12:06:15.143365	\N	\N	1	2026-06-30 12:06:15.143365+08	2026-06-30 12:06:15.143365	\N	\N	[]
152	558	17726689234	20	2	2026-06-30 19:24:29.929941	2026-06-30 19:50:34.406098	admin	1	\N	2026-06-30 19:24:29.929941		\N	[]
126	500	13667618419	20	2	2026-06-30 12:29:22.440017	\N	\N	1	2026-06-30 12:29:22.440017+08	2026-06-30 12:29:22.440017	\N	\N	[]
127	496	13667618419	20	2	2026-06-30 12:29:23.388248	\N	\N	1	2026-06-30 12:29:23.388248+08	2026-06-30 12:29:23.388248	\N	\N	[]
128	432	13667618419	20	2	2026-06-30 12:29:28.501642	\N	\N	1	2026-06-30 12:29:28.501642+08	2026-06-30 12:29:28.501642	\N	\N	[]
119	493	17726689234	20	2	2026-06-30 11:19:26.804	\N	\N	1	2026-06-30 11:19:26.804+08	2026-06-30 11:19:26.804	\N	\N	[]
129	424	13667618419	20	2	2026-06-30 12:29:33.041215	\N	\N	1	2026-06-30 12:29:33.041215+08	2026-06-30 12:29:33.041215	\N	\N	[]
103	\N	18996093393	82	2	2026-06-29 18:59:48.984255	2026-06-30 10:24:31.009584	admin	1	\N	2026-06-29 18:59:48.984255	\N	\N	[]
130	422	13667618419	20	2	2026-06-30 12:30:36.497195	\N	\N	1	2026-06-30 12:30:36.497195+08	2026-06-30 12:30:36.497195	\N	\N	[]
143	555	17726689234	20	2	2026-06-30 18:13:57.300004	2026-06-30 18:18:49.841431	admin	1	\N	2026-06-30 18:13:57.300004	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N	[]
121	\N	13667618419	20	2	2026-06-30 11:30:24.574198	2026-06-30 11:31:07.901284	admin	1	\N	2026-06-30 11:30:24.574198		\N	[]
153	549	15656087879	20	0	2026-06-30 20:37:10.794774	\N	\N	1	\N	2026-06-30 20:37:10.794774		\N	[]
120	\N	13667618419	120	2	2026-06-30 11:30:09.856373	2026-06-30 11:37:05.425108	admin	1	\N	2026-06-30 11:30:09.856373		\N	[]
145	550	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:02.788767	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
140	\N	18637010208	20	0	2026-06-30 16:32:25.505544	\N	\N	1	\N	2026-06-30 16:32:25.505544		\N	[521]
141	\N	19137096192	20	0	2026-06-30 16:41:56.094547	\N	\N	1	\N	2026-06-30 16:41:56.094547		\N	[538]
134	530	17726689234	20	2	2026-06-30 14:06:06.176592	2026-06-30 14:27:49.528093	admin	1	\N	2026-06-30 14:06:06.176592		\N	[]
135	\N	18265820019	20	0	2026-06-30 15:09:15.541254	\N	\N	1	\N	2026-06-30 15:09:15.541254		\N	[501]
148	30	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:16.691669	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
137	\N	17726689234	20	2	2026-06-30 15:37:59.548873	2026-06-30 15:39:03.424493	admin_test	1	\N	2026-06-30 15:37:59.548873	\N	\N	[548]
149	29	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:19.706076	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
138	\N	19544562686	20	0	2026-06-30 16:11:35.598208	\N	\N	1	\N	2026-06-30 16:11:35.598208		\N	[539]
133	\N	17726689234	40	5	2026-06-30 13:50:05.009292	\N	\N	1	\N	2026-06-30 13:50:05.009292	oLhbm2CegcLUOudngMNwdzBhHA7U	系统修复：取消旧版无订单关联的提现记录	[]
139	\N	15275043796	20	0	2026-06-30 16:12:58.540861	\N	\N	1	\N	2026-06-30 16:12:58.540861		\N	[523]
144	551	17726689234	20	2	2026-06-30 18:13:57.300004	2026-06-30 18:18:40.862269	admin	1	\N	2026-06-30 18:13:57.300004	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N	[]
146	34	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:23.258836	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
150	25	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:26.014054	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
147	33	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:30.369821	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
154	546	15324821187	20	0	2026-07-01 01:12:24.436217	\N	\N	1	\N	2026-07-01 01:12:24.436217		\N	[]
131	422	13667618419	20	4	2026-06-30 12:30:36.685084	\N	\N	1	2026-06-30 12:30:36.685084+08	2026-06-30 12:30:36.685084	\N	订单已全额退款	[]
132	35	13667618419	20	4	2026-06-30 12:30:37.467936	\N	\N	1	2026-06-30 12:30:37.467936+08	2026-06-30 12:30:37.467936	\N	记录不存在	[]
\.


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 1, true);


--
-- Name: after_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.after_sales_id_seq', 1, true);


--
-- Name: agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.agents_id_seq', 3, true);


--
-- Name: alarms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.alarms_id_seq', 1, true);


--
-- Name: apk_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.apk_version_id_seq', 46, true);


--
-- Name: blacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.blacklist_id_seq', 1, true);


--
-- Name: cabinet_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cabinet_groups_id_seq', 1, true);


--
-- Name: cabinet_slots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cabinet_slots_id_seq', 702, true);


--
-- Name: cabinets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cabinets_id_seq', 26, true);


--
-- Name: cached_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cached_orders_id_seq', 1, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.companies_id_seq', 2, true);


--
-- Name: complaints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.complaints_id_seq', 3, true);


--
-- Name: device_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.device_alerts_id_seq', 636, true);


--
-- Name: device_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.device_logs_id_seq', 856, true);


--
-- Name: device_update_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.device_update_logs_id_seq', 25, true);


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.devices_id_seq', 1, true);


--
-- Name: door_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.door_records_id_seq', 419, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.employees_id_seq', 1, true);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.locations_id_seq', 7, true);


--
-- Name: mainboards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.mainboards_id_seq', 38, true);


--
-- Name: merchants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.merchants_id_seq', 4, true);


--
-- Name: offline_retrieve_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.offline_retrieve_records_id_seq', 1, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.orders_id_seq', 561, true);


--
-- Name: payment_channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.payment_channels_id_seq', 6, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.payments_id_seq', 276, true);


--
-- Name: pending_lock_cmds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.pending_lock_cmds_id_seq', 964, true);


--
-- Name: phone_openids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.phone_openids_id_seq', 92, true);


--
-- Name: remote_open_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.remote_open_logs_id_seq', 330, true);


--
-- Name: sms_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.sms_codes_id_seq', 1, true);


--
-- Name: storage_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.storage_records_id_seq', 204, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 11185, true);


--
-- Name: user_balance_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.user_balance_details_id_seq', 60, true);


--
-- Name: user_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.user_balances_id_seq', 49, true);


--
-- Name: withdrawal_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.withdrawal_records_id_seq', 154, true);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_username_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_username_key UNIQUE (username);


--
-- Name: after_sales after_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.after_sales
    ADD CONSTRAINT after_sales_pkey PRIMARY KEY (id);


--
-- Name: after_sales after_sales_ticket_no_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.after_sales
    ADD CONSTRAINT after_sales_ticket_no_key UNIQUE (ticket_no);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: alarms alarms_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.alarms
    ADD CONSTRAINT alarms_pkey PRIMARY KEY (id);


--
-- Name: apk_version apk_version_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.apk_version
    ADD CONSTRAINT apk_version_pkey PRIMARY KEY (id);


--
-- Name: blacklist blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.blacklist
    ADD CONSTRAINT blacklist_pkey PRIMARY KEY (id);


--
-- Name: cabinet_groups cabinet_groups_group_code_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_groups
    ADD CONSTRAINT cabinet_groups_group_code_key UNIQUE (group_code);


--
-- Name: cabinet_groups cabinet_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_groups
    ADD CONSTRAINT cabinet_groups_pkey PRIMARY KEY (id);


--
-- Name: cabinet_slots cabinet_slots_cabinet_id_slot_number_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_slots
    ADD CONSTRAINT cabinet_slots_cabinet_id_slot_number_key UNIQUE (cabinet_id, slot_number);


--
-- Name: cabinet_slots cabinet_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_slots
    ADD CONSTRAINT cabinet_slots_pkey PRIMARY KEY (id);


--
-- Name: cabinets cabinets_cabinet_code_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinets
    ADD CONSTRAINT cabinets_cabinet_code_key UNIQUE (cabinet_code);


--
-- Name: cabinets cabinets_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinets
    ADD CONSTRAINT cabinets_pkey PRIMARY KEY (id);


--
-- Name: cached_orders cached_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cached_orders
    ADD CONSTRAINT cached_orders_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: complaints complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.complaints
    ADD CONSTRAINT complaints_pkey PRIMARY KEY (id);


--
-- Name: device_alerts device_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_alerts
    ADD CONSTRAINT device_alerts_pkey PRIMARY KEY (id);


--
-- Name: device_logs device_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_logs
    ADD CONSTRAINT device_logs_pkey PRIMARY KEY (id);


--
-- Name: device_update_logs device_update_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_update_logs
    ADD CONSTRAINT device_update_logs_pkey PRIMARY KEY (id);


--
-- Name: devices devices_device_id_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_device_id_key UNIQUE (device_id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: door_query_cache door_query_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.door_query_cache
    ADD CONSTRAINT door_query_cache_pkey PRIMARY KEY (request_id);


--
-- Name: door_records door_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.door_records
    ADD CONSTRAINT door_records_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: mainboards mainboards_cabinet_id_board_index_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.mainboards
    ADD CONSTRAINT mainboards_cabinet_id_board_index_key UNIQUE (cabinet_id, board_index);


--
-- Name: mainboards mainboards_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.mainboards
    ADD CONSTRAINT mainboards_pkey PRIMARY KEY (id);


--
-- Name: merchants merchants_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT merchants_pkey PRIMARY KEY (id);


--
-- Name: offline_retrieve_records offline_retrieve_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.offline_retrieve_records
    ADD CONSTRAINT offline_retrieve_records_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_no_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_no_key UNIQUE (order_no);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payment_channels payment_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payment_channels
    ADD CONSTRAINT payment_channels_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pending_lock_cmds pending_lock_cmds_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.pending_lock_cmds
    ADD CONSTRAINT pending_lock_cmds_pkey PRIMARY KEY (id);


--
-- Name: phone_openids phone_openids_phone_openid_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.phone_openids
    ADD CONSTRAINT phone_openids_phone_openid_key UNIQUE (phone, openid);


--
-- Name: phone_openids phone_openids_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.phone_openids
    ADD CONSTRAINT phone_openids_pkey PRIMARY KEY (id);


--
-- Name: remote_open_logs remote_open_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.remote_open_logs
    ADD CONSTRAINT remote_open_logs_pkey PRIMARY KEY (id);


--
-- Name: sms_codes sms_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.sms_codes
    ADD CONSTRAINT sms_codes_pkey PRIMARY KEY (id);


--
-- Name: storage_records storage_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.storage_records
    ADD CONSTRAINT storage_records_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_key UNIQUE (setting_key);


--
-- Name: user_balance_details user_balance_details_order_id_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balance_details
    ADD CONSTRAINT user_balance_details_order_id_key UNIQUE (order_id);


--
-- Name: user_balance_details user_balance_details_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balance_details
    ADD CONSTRAINT user_balance_details_pkey PRIMARY KEY (id);


--
-- Name: user_balances user_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balances
    ADD CONSTRAINT user_balances_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (openid);


--
-- Name: withdrawal_records withdrawal_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.withdrawal_records
    ADD CONSTRAINT withdrawal_records_pkey PRIMARY KEY (id);


--
-- Name: idx_balance_details_order; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_balance_details_order ON public.user_balance_details USING btree (order_id);


--
-- Name: idx_balance_details_phone_status; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_balance_details_phone_status ON public.user_balance_details USING btree (user_phone, status);


--
-- Name: idx_cabinets_heartbeat; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_cabinets_heartbeat ON public.cabinets USING btree (last_heartbeat);


--
-- Name: idx_cabinets_location; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_cabinets_location ON public.cabinets USING btree (location_id);


--
-- Name: idx_cabinets_mainboard; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_cabinets_mainboard ON public.cabinets USING btree (mainboard_device_id);


--
-- Name: idx_complaints_order_id; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_complaints_order_id ON public.complaints USING btree (order_id);


--
-- Name: idx_orders_cabinet; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_orders_cabinet ON public.orders USING btree (cabinet_id);


--
-- Name: idx_orders_phone; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_orders_phone ON public.orders USING btree (user_phone);


--
-- Name: idx_orders_slot; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_orders_slot ON public.orders USING btree (slot_id);


--
-- Name: idx_phone_openids_phone; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE UNIQUE INDEX idx_phone_openids_phone ON public.phone_openids USING btree (phone);


--
-- Name: idx_phone_openids_unionid; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_phone_openids_unionid ON public.phone_openids USING btree (unionid);


--
-- Name: idx_slots_cabinet; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_slots_cabinet ON public.cabinet_slots USING btree (cabinet_id);


--
-- Name: idx_slots_status; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_slots_status ON public.cabinet_slots USING btree (status);


--
-- Name: idx_user_balances_unionid; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_user_balances_unionid ON public.user_balances USING btree (unionid);


--
-- Name: user_balances_phone_openid_uk; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE UNIQUE INDEX user_balances_phone_openid_uk ON public.user_balances USING btree (phone, openid);


--
-- PostgreSQL database dump complete
--

\unrestrict gG2mEeKMwaI7f87HaaNtCp0fZjmfIvd6yQMHJ5evZJuxm9rzJf2ioQmPtEhyYjS

