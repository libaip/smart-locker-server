--
-- PostgreSQL database dump
--

\restrict rIE7xzRrbHDMa7jpj7BMggWRqQByuA1ky3houiM1t5qJ88cnxiIcOfS7yuZvcfw

-- Dumped from database version 14.23 (Ubuntu 14.23-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.23 (Ubuntu 14.23-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'admin'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auth_token text
);


ALTER TABLE public.admin_users OWNER TO locker_admin;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_users_id_seq OWNER TO locker_admin;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: after_sales; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.after_sales (
    id integer NOT NULL,
    ticket_no text,
    cabinet_id integer,
    location_id integer,
    device_id text,
    fault_type text,
    description text,
    status text DEFAULT 'pending'::text,
    handler text,
    handler_note text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.after_sales OWNER TO locker_admin;

--
-- Name: after_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.after_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.after_sales_id_seq OWNER TO locker_admin;

--
-- Name: after_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.after_sales_id_seq OWNED BY public.after_sales.id;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.agents (
    id integer NOT NULL,
    name text NOT NULL,
    contact_name text,
    contact_phone text NOT NULL,
    password_hash text NOT NULL,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    commission_rate double precision DEFAULT 0,
    auth_token text DEFAULT ''::text,
    login_attempts integer DEFAULT 0,
    is_locked integer DEFAULT 0,
    plain_password text DEFAULT ''::text
);


ALTER TABLE public.agents OWNER TO locker_admin;

--
-- Name: agents_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.agents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agents_id_seq OWNER TO locker_admin;

--
-- Name: agents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.agents_id_seq OWNED BY public.agents.id;


--
-- Name: alarms; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.alarms (
    id integer NOT NULL,
    type text NOT NULL,
    cabinet_id integer,
    device_id text,
    content text,
    level integer DEFAULT 1,
    status text DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone,
    resolver text
);


ALTER TABLE public.alarms OWNER TO locker_admin;

--
-- Name: alarms_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.alarms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alarms_id_seq OWNER TO locker_admin;

--
-- Name: alarms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.alarms_id_seq OWNED BY public.alarms.id;


--
-- Name: apk_version; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.apk_version (
    id integer NOT NULL,
    version_name text,
    version_code integer,
    download_url text,
    update_desc text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    file_md5 text DEFAULT ''::text
);


ALTER TABLE public.apk_version OWNER TO locker_admin;

--
-- Name: apk_version_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.apk_version_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.apk_version_id_seq OWNER TO locker_admin;

--
-- Name: apk_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.apk_version_id_seq OWNED BY public.apk_version.id;


--
-- Name: blacklist; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.blacklist (
    id integer NOT NULL,
    phone text NOT NULL,
    reason text,
    cabinet_id integer,
    operator text,
    status text DEFAULT 1,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.blacklist OWNER TO locker_admin;

--
-- Name: blacklist_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.blacklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blacklist_id_seq OWNER TO locker_admin;

--
-- Name: blacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.blacklist_id_seq OWNED BY public.blacklist.id;


--
-- Name: cabinet_groups; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cabinet_groups (
    id integer NOT NULL,
    location_id integer,
    group_code text NOT NULL,
    name text,
    screen_url text,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.cabinet_groups OWNER TO locker_admin;

--
-- Name: cabinet_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cabinet_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cabinet_groups_id_seq OWNER TO locker_admin;

--
-- Name: cabinet_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cabinet_groups_id_seq OWNED BY public.cabinet_groups.id;


--
-- Name: cabinet_slots; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cabinet_slots (
    id integer NOT NULL,
    cabinet_id integer NOT NULL,
    slot_number integer NOT NULL,
    slot_size text DEFAULT 'M'::text,
    status integer DEFAULT 1,
    cabinet_code text,
    mainboard_id integer,
    display_number integer,
    board_no integer DEFAULT 1,
    lock_no integer DEFAULT 1,
    slot_label text DEFAULT ''::text,
    updated_at timestamp without time zone
);


ALTER TABLE public.cabinet_slots OWNER TO locker_admin;

--
-- Name: cabinet_slots_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cabinet_slots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cabinet_slots_id_seq OWNER TO locker_admin;

--
-- Name: cabinet_slots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cabinet_slots_id_seq OWNED BY public.cabinet_slots.id;


--
-- Name: cabinets; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cabinets (
    id integer NOT NULL,
    location_id integer,
    cabinet_code text NOT NULL,
    name text,
    total_slots integer DEFAULT 12,
    status integer DEFAULT 1,
    last_heartbeat timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    group_id integer,
    deposit_amount double precision DEFAULT 20,
    mainboard_device_id text DEFAULT ''::text,
    mainboard_source text DEFAULT ''::text,
    charge_mode text DEFAULT 'deposit'::text,
    app_version text DEFAULT ''::text,
    app_version_code integer DEFAULT 0,
    business_status text DEFAULT 1,
    business_hours text,
    customer_phone text,
    updated_at timestamp without time zone,
    usage_rules text,
    per_use_price double precision DEFAULT 0
);


ALTER TABLE public.cabinets OWNER TO locker_admin;

--
-- Name: cabinets_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cabinets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cabinets_id_seq OWNER TO locker_admin;

--
-- Name: cabinets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cabinets_id_seq OWNED BY public.cabinets.id;


--
-- Name: cached_orders; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.cached_orders (
    id integer NOT NULL,
    order_id integer NOT NULL,
    order_no text,
    cabinet_id integer,
    slot_id integer,
    slot_number text,
    deposit_amount double precision,
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    synced integer DEFAULT 0
);


ALTER TABLE public.cached_orders OWNER TO locker_admin;

--
-- Name: cached_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.cached_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cached_orders_id_seq OWNER TO locker_admin;

--
-- Name: cached_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.cached_orders_id_seq OWNED BY public.cached_orders.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name text NOT NULL,
    credit_code text,
    contact_person text,
    contact_phone text,
    address text,
    status text DEFAULT 1,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.companies OWNER TO locker_admin;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_id_seq OWNER TO locker_admin;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: complaints; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.complaints (
    id integer NOT NULL,
    user_phone text NOT NULL,
    type text DEFAULT 'self'::text,
    content text NOT NULL,
    order_no text,
    status text DEFAULT 0,
    reply text,
    reply_time timestamp without time zone,
    wx_complaint_id text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    complaint_type text DEFAULT 'complaint'::text,
    order_id integer,
    openid text
);


ALTER TABLE public.complaints OWNER TO locker_admin;

--
-- Name: complaints_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.complaints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.complaints_id_seq OWNER TO locker_admin;

--
-- Name: complaints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.complaints_id_seq OWNED BY public.complaints.id;


--
-- Name: device_alerts; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.device_alerts (
    id integer NOT NULL,
    device_id text,
    alert_type text,
    detail text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.device_alerts OWNER TO locker_admin;

--
-- Name: device_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.device_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_alerts_id_seq OWNER TO locker_admin;

--
-- Name: device_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.device_alerts_id_seq OWNED BY public.device_alerts.id;


--
-- Name: device_logs; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.device_logs (
    id integer NOT NULL,
    device_id text,
    logs text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    log_type text DEFAULT 'info'::text,
    content text,
    level text DEFAULT 'info'::text,
    detail text,
    device_name text,
    status text
);


ALTER TABLE public.device_logs OWNER TO locker_admin;

--
-- Name: device_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.device_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_logs_id_seq OWNER TO locker_admin;

--
-- Name: device_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.device_logs_id_seq OWNED BY public.device_logs.id;


--
-- Name: device_update_logs; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.device_update_logs (
    id integer NOT NULL,
    device_id text,
    success integer DEFAULT 0,
    version_name text DEFAULT ''::text,
    version_code integer DEFAULT 0,
    error_msg text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.device_update_logs OWNER TO locker_admin;

--
-- Name: device_update_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.device_update_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_update_logs_id_seq OWNER TO locker_admin;

--
-- Name: device_update_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.device_update_logs_id_seq OWNED BY public.device_update_logs.id;


--
-- Name: devices; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    device_id text,
    device_name text,
    device_type text,
    status text,
    remark text,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.devices OWNER TO locker_admin;

--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.devices_id_seq OWNER TO locker_admin;

--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: door_query_cache; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.door_query_cache (
    request_id text NOT NULL,
    device_id text,
    board_no integer,
    lock_no integer,
    cabinet_id integer,
    is_open boolean,
    door_status text,
    query_success boolean,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.door_query_cache OWNER TO locker_admin;

--
-- Name: door_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.door_records (
    id integer NOT NULL,
    device_id text,
    board_no text,
    lock_no text,
    order_id text,
    open_type text,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.door_records OWNER TO locker_admin;

--
-- Name: door_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.door_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.door_records_id_seq OWNER TO locker_admin;

--
-- Name: door_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.door_records_id_seq OWNED BY public.door_records.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    merchant_id integer,
    name text NOT NULL,
    phone text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'staff'::text,
    status text DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auth_token text DEFAULT ''::text,
    permissions text DEFAULT '[]'::text,
    login_attempts integer DEFAULT 0,
    is_locked integer DEFAULT 0,
    plain_password text DEFAULT ''::text
);


ALTER TABLE public.employees OWNER TO locker_admin;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employees_id_seq OWNER TO locker_admin;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    merchant_id integer,
    name text NOT NULL,
    address text,
    longitude double precision,
    latitude double precision,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    withdraw_enabled integer DEFAULT 1,
    auto_approve_day integer DEFAULT 1,
    auto_approve_time text DEFAULT '12:00'::text,
    auto_approve_rate double precision DEFAULT 80,
    click_free_count integer DEFAULT 3,
    anti_test_minutes integer DEFAULT 30,
    anti_test_auto_refund integer DEFAULT 1,
    hide_ratio integer DEFAULT 0,
    whitelist_phones text DEFAULT ''::text,
    duplicate_filter_enabled integer DEFAULT 0,
    duplicate_filter_days integer DEFAULT 7,
    duplicate_filter_limit integer DEFAULT 3,
    show_refunding_status text DEFAULT 1,
    refund_approve_rate double precision DEFAULT 80,
    refund_approve_start_min integer DEFAULT 60,
    refund_approve_end_min integer DEFAULT 300,
    contact_phone text DEFAULT ''::text,
    open_time text DEFAULT '08:00'::text,
    close_time text DEFAULT '22:00'::text,
    allow_slot_select integer DEFAULT 0,
    slot_assign_mode text DEFAULT 'auto'::text,
    allow_mid_retrieve integer DEFAULT 1,
    retrieve_mode text DEFAULT 'both'::text,
    allow_h5_to_mp integer DEFAULT 0,
    show_qr_follow integer DEFAULT 0,
    force_follow_mp integer DEFAULT 0,
    h5_url text DEFAULT ''::text,
    show_slot_count integer DEFAULT 1,
    screen_show_title integer DEFAULT 1,
    screen_title text DEFAULT ''::text,
    slot_full_alert integer DEFAULT 0,
    slot_full_text text DEFAULT ''::text,
    end_alert_minutes integer DEFAULT 0,
    enable_clear_box integer DEFAULT 0,
    clear_box_time text DEFAULT '23:00'::text,
    clear_box_cycle integer DEFAULT 1,
    deposit_random integer DEFAULT 0,
    deposit_min double precision DEFAULT 0,
    deposit_max double precision DEFAULT 0,
    contact_name text DEFAULT ''::text,
    refund_mode text DEFAULT 'auto_approve'::text,
    withdraw_mode text DEFAULT 'manual_approve'::text,
    province text DEFAULT ''::text,
    agent_id integer,
    city text DEFAULT ''::text,
    usage_rules text DEFAULT ''::text,
    deposit_amount double precision DEFAULT 20.0,
    mp_appid text DEFAULT ''::text,
    balance_hide_enabled integer DEFAULT 0,
    balance_hide_days integer DEFAULT 30
);


ALTER TABLE public.locations OWNER TO locker_admin;

--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.locations_id_seq OWNER TO locker_admin;

--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: mainboards; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.mainboards (
    id integer NOT NULL,
    cabinet_id integer NOT NULL,
    board_index integer NOT NULL,
    slot_count integer DEFAULT 16,
    name text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    serial_port text DEFAULT 'ttyS1'::text,
    baud_rate integer DEFAULT 9600,
    address text DEFAULT ''::text,
    board_type text DEFAULT 'main'::text,
    protocol text DEFAULT 'YBM'::text
);


ALTER TABLE public.mainboards OWNER TO locker_admin;

--
-- Name: mainboards_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.mainboards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mainboards_id_seq OWNER TO locker_admin;

--
-- Name: mainboards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.mainboards_id_seq OWNED BY public.mainboards.id;


--
-- Name: merchants; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.merchants (
    id integer NOT NULL,
    name text NOT NULL,
    contact_name text,
    contact_phone text NOT NULL,
    password_hash text NOT NULL,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    agent_id integer,
    auth_token text,
    permissions text DEFAULT '[]'::text,
    login_attempts integer DEFAULT 0,
    is_locked integer DEFAULT 0,
    plain_password text DEFAULT ''::text,
    commission_per_order numeric(10,2) DEFAULT 0,
    text_labels text DEFAULT '{}'::text,
    merchant_number text DEFAULT ''::text,
    dashboard_config text,
    last_login_at timestamp without time zone
);


ALTER TABLE public.merchants OWNER TO locker_admin;

--
-- Name: merchants_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.merchants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.merchants_id_seq OWNER TO locker_admin;

--
-- Name: merchants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.merchants_id_seq OWNED BY public.merchants.id;


--
-- Name: offline_retrieve_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.offline_retrieve_records (
    id integer NOT NULL,
    order_no text NOT NULL,
    retrieve_code text,
    cabinet_id integer,
    slot_id integer,
    slot_number text,
    retrieved_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    synced integer DEFAULT 0,
    uploaded integer DEFAULT 0
);


ALTER TABLE public.offline_retrieve_records OWNER TO locker_admin;

--
-- Name: offline_retrieve_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.offline_retrieve_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.offline_retrieve_records_id_seq OWNER TO locker_admin;

--
-- Name: offline_retrieve_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.offline_retrieve_records_id_seq OWNED BY public.offline_retrieve_records.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    order_no text NOT NULL,
    user_phone text NOT NULL,
    slot_id integer,
    cabinet_id integer,
    compartment_number text,
    access_code text,
    deposit_amount double precision DEFAULT 20,
    status integer DEFAULT 1,
    store_time timestamp without time zone,
    retrieve_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    group_id integer,
    cabinet_code text,
    cabinet_name text,
    slot_size text,
    transaction_id text,
    refund_id text,
    pay_time timestamp without time zone,
    refund_time timestamp without time zone,
    payment_channel_id integer,
    refund_mark integer DEFAULT 0,
    refund_status text DEFAULT 'none'::text,
    refund_amount double precision DEFAULT 0,
    logical_mark text DEFAULT 'N'::text,
    logic_mark text,
    logic_hide text,
    note text,
    admin_remark text,
    pickup_time timestamp without time zone,
    updated_at timestamp without time zone,
    openid text,
    unionid character varying(100)
);


ALTER TABLE public.orders OWNER TO locker_admin;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO locker_admin;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: payment_channels; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.payment_channels (
    id integer NOT NULL,
    name text NOT NULL,
    channel_type text DEFAULT 'wechat'::text NOT NULL,
    mch_id text,
    api_key text,
    app_id text,
    app_secret text,
    cert_name text,
    extra_config text,
    is_active integer DEFAULT 1,
    weight integer DEFAULT 1,
    daily_limit double precision DEFAULT 0,
    total_amount double precision DEFAULT 0,
    total_count integer DEFAULT 0,
    last_used_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    rotation_index integer DEFAULT 0,
    cert_serial_no text
);


ALTER TABLE public.payment_channels OWNER TO locker_admin;

--
-- Name: payment_channels_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.payment_channels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_channels_id_seq OWNER TO locker_admin;

--
-- Name: payment_channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.payment_channels_id_seq OWNED BY public.payment_channels.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    order_id integer NOT NULL,
    type integer NOT NULL,
    amount double precision NOT NULL,
    transaction_id text,
    status integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    refund_transaction_id text
);


ALTER TABLE public.payments OWNER TO locker_admin;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO locker_admin;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: pending_lock_cmds; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.pending_lock_cmds (
    id integer NOT NULL,
    device_id text,
    board_no text DEFAULT 1,
    lock_no text,
    protocol text DEFAULT 'YBM'::text,
    order_id text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    delivered integer DEFAULT 0,
    cabinet_id text,
    slot_id integer,
    command text,
    status text
);


ALTER TABLE public.pending_lock_cmds OWNER TO locker_admin;

--
-- Name: pending_lock_cmds_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.pending_lock_cmds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pending_lock_cmds_id_seq OWNER TO locker_admin;

--
-- Name: pending_lock_cmds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.pending_lock_cmds_id_seq OWNED BY public.pending_lock_cmds.id;


--
-- Name: phone_openids; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.phone_openids (
    id integer NOT NULL,
    phone character varying(20),
    openid character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    wechat_name character varying(100) DEFAULT ''::character varying,
    unionid character varying(100)
);


ALTER TABLE public.phone_openids OWNER TO locker_admin;

--
-- Name: phone_openids_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.phone_openids_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.phone_openids_id_seq OWNER TO locker_admin;

--
-- Name: phone_openids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.phone_openids_id_seq OWNED BY public.phone_openids.id;


--
-- Name: remote_open_logs; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.remote_open_logs (
    id integer NOT NULL,
    merchant_id integer,
    cabinet_id integer,
    device_id text,
    slot_id integer,
    slot_number text,
    action_type text DEFAULT 'emergency_open'::text,
    operator text,
    result text DEFAULT 'success'::text,
    success integer DEFAULT 1,
    ip_address text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.remote_open_logs OWNER TO locker_admin;

--
-- Name: remote_open_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.remote_open_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.remote_open_logs_id_seq OWNER TO locker_admin;

--
-- Name: remote_open_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.remote_open_logs_id_seq OWNED BY public.remote_open_logs.id;


--
-- Name: sms_codes; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.sms_codes (
    id integer NOT NULL,
    phone text NOT NULL,
    code text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sms_codes OWNER TO locker_admin;

--
-- Name: sms_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.sms_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sms_codes_id_seq OWNER TO locker_admin;

--
-- Name: sms_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.sms_codes_id_seq OWNED BY public.sms_codes.id;


--
-- Name: storage_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.storage_records (
    id integer NOT NULL,
    cabinet_id integer NOT NULL,
    compartment_number text NOT NULL,
    user_phone text,
    access_code text,
    status text DEFAULT 1,
    store_time timestamp without time zone,
    retrieve_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.storage_records OWNER TO locker_admin;

--
-- Name: storage_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.storage_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.storage_records_id_seq OWNER TO locker_admin;

--
-- Name: storage_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.storage_records_id_seq OWNED BY public.storage_records.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    setting_key text NOT NULL,
    setting_value text,
    description text
);


ALTER TABLE public.system_settings OWNER TO locker_admin;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_settings_id_seq OWNER TO locker_admin;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: user_balance_details; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.user_balance_details (
    id integer NOT NULL,
    user_phone character varying(20) NOT NULL,
    order_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    source_time timestamp without time zone DEFAULT now(),
    status character varying(20) DEFAULT 'available'::character varying,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_balance_details OWNER TO locker_admin;

--
-- Name: user_balance_details_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.user_balance_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_balance_details_id_seq OWNER TO locker_admin;

--
-- Name: user_balance_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.user_balance_details_id_seq OWNED BY public.user_balance_details.id;


--
-- Name: user_balances; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.user_balances (
    id integer NOT NULL,
    phone text NOT NULL,
    balance double precision DEFAULT 0,
    total_deposited double precision DEFAULT 0,
    total_withdrawn double precision DEFAULT 0,
    first_use_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    wechat_name text DEFAULT ''::text,
    openid text DEFAULT ''::text,
    unionid character varying(100)
);


ALTER TABLE public.user_balances OWNER TO locker_admin;

--
-- Name: user_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.user_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_balances_id_seq OWNER TO locker_admin;

--
-- Name: user_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.user_balances_id_seq OWNED BY public.user_balances.id;


--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.user_profiles (
    openid text NOT NULL,
    wechat_name text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    unionid character varying(100)
);


ALTER TABLE public.user_profiles OWNER TO locker_admin;

--
-- Name: user_tokens; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.user_tokens (
    id integer NOT NULL,
    user_type text NOT NULL,
    user_id integer NOT NULL,
    token text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_tokens OWNER TO locker_admin;

--
-- Name: user_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.user_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_tokens_id_seq OWNER TO locker_admin;

--
-- Name: user_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.user_tokens_id_seq OWNED BY public.user_tokens.id;


--
-- Name: withdrawal_records; Type: TABLE; Schema: public; Owner: locker_admin
--

CREATE TABLE public.withdrawal_records (
    id integer NOT NULL,
    order_id integer,
    user_phone text NOT NULL,
    amount double precision NOT NULL,
    status integer DEFAULT 0,
    apply_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approve_time timestamp without time zone,
    approver text,
    click_count integer DEFAULT 1,
    auto_approve_time text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    openid text,
    error_msg text,
    order_ids text DEFAULT '[]'::text
);


ALTER TABLE public.withdrawal_records OWNER TO locker_admin;

--
-- Name: withdrawal_records_id_seq; Type: SEQUENCE; Schema: public; Owner: locker_admin
--

CREATE SEQUENCE public.withdrawal_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.withdrawal_records_id_seq OWNER TO locker_admin;

--
-- Name: withdrawal_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: locker_admin
--

ALTER SEQUENCE public.withdrawal_records_id_seq OWNED BY public.withdrawal_records.id;


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: after_sales id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.after_sales ALTER COLUMN id SET DEFAULT nextval('public.after_sales_id_seq'::regclass);


--
-- Name: agents id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.agents ALTER COLUMN id SET DEFAULT nextval('public.agents_id_seq'::regclass);


--
-- Name: alarms id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.alarms ALTER COLUMN id SET DEFAULT nextval('public.alarms_id_seq'::regclass);


--
-- Name: apk_version id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.apk_version ALTER COLUMN id SET DEFAULT nextval('public.apk_version_id_seq'::regclass);


--
-- Name: blacklist id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.blacklist ALTER COLUMN id SET DEFAULT nextval('public.blacklist_id_seq'::regclass);


--
-- Name: cabinet_groups id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_groups ALTER COLUMN id SET DEFAULT nextval('public.cabinet_groups_id_seq'::regclass);


--
-- Name: cabinet_slots id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_slots ALTER COLUMN id SET DEFAULT nextval('public.cabinet_slots_id_seq'::regclass);


--
-- Name: cabinets id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinets ALTER COLUMN id SET DEFAULT nextval('public.cabinets_id_seq'::regclass);


--
-- Name: cached_orders id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cached_orders ALTER COLUMN id SET DEFAULT nextval('public.cached_orders_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: complaints id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.complaints ALTER COLUMN id SET DEFAULT nextval('public.complaints_id_seq'::regclass);


--
-- Name: device_alerts id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_alerts ALTER COLUMN id SET DEFAULT nextval('public.device_alerts_id_seq'::regclass);


--
-- Name: device_logs id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_logs ALTER COLUMN id SET DEFAULT nextval('public.device_logs_id_seq'::regclass);


--
-- Name: device_update_logs id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_update_logs ALTER COLUMN id SET DEFAULT nextval('public.device_update_logs_id_seq'::regclass);


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: door_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.door_records ALTER COLUMN id SET DEFAULT nextval('public.door_records_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: mainboards id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.mainboards ALTER COLUMN id SET DEFAULT nextval('public.mainboards_id_seq'::regclass);


--
-- Name: merchants id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.merchants ALTER COLUMN id SET DEFAULT nextval('public.merchants_id_seq'::regclass);


--
-- Name: offline_retrieve_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.offline_retrieve_records ALTER COLUMN id SET DEFAULT nextval('public.offline_retrieve_records_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: payment_channels id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payment_channels ALTER COLUMN id SET DEFAULT nextval('public.payment_channels_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: pending_lock_cmds id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.pending_lock_cmds ALTER COLUMN id SET DEFAULT nextval('public.pending_lock_cmds_id_seq'::regclass);


--
-- Name: phone_openids id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.phone_openids ALTER COLUMN id SET DEFAULT nextval('public.phone_openids_id_seq'::regclass);


--
-- Name: remote_open_logs id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.remote_open_logs ALTER COLUMN id SET DEFAULT nextval('public.remote_open_logs_id_seq'::regclass);


--
-- Name: sms_codes id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.sms_codes ALTER COLUMN id SET DEFAULT nextval('public.sms_codes_id_seq'::regclass);


--
-- Name: storage_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.storage_records ALTER COLUMN id SET DEFAULT nextval('public.storage_records_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: user_balance_details id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balance_details ALTER COLUMN id SET DEFAULT nextval('public.user_balance_details_id_seq'::regclass);


--
-- Name: user_balances id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balances ALTER COLUMN id SET DEFAULT nextval('public.user_balances_id_seq'::regclass);


--
-- Name: user_tokens id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_tokens ALTER COLUMN id SET DEFAULT nextval('public.user_tokens_id_seq'::regclass);


--
-- Name: withdrawal_records id; Type: DEFAULT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.withdrawal_records ALTER COLUMN id SET DEFAULT nextval('public.withdrawal_records_id_seq'::regclass);


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.admin_users (id, username, password_hash, role, created_at, auth_token) FROM stdin;
1	admin	scrypt:32768:8:1$w0GArPx5D5wRGeXw$a11d032f4249144577e2c5a3dd441594dbe591a6621c85cd088c46d49bb7da1db239aed3939a1ab291ac07a25401817854a6dfe51ea758f1bde82b9243c10bbe	super_admin	2026-06-11 05:52:50	40499264-8944-4328-b1dc-8c73c5dd7009
\.


--
-- Data for Name: after_sales; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.after_sales (id, ticket_no, cabinet_id, location_id, device_id, fault_type, description, status, handler, handler_note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.agents (id, name, contact_name, contact_phone, password_hash, status, created_at, commission_rate, auth_token, login_attempts, is_locked, plain_password) FROM stdin;
3	自动密码测试	自动密码测试	13900005555	scrypt:32768:8:1$Hm09rGIVdhjXIqk0$f0240605e8fb16383b2d77090bcf8fe20dda54705cb3ec1942803aacddf07937bf1974f96919ebaf19bf84b9215fdca3b844a72a2716c6a8957a7b464bd501f5	1	2026-06-23 08:51:36	0	\N	0	0	
1	王昊	王昊	18996093393	scrypt:32768:8:1$cHcVnE06qBQJ4WJk$06fbf3f8c3193874014777361a2bc3e984c679f88c95bb857d53fdabec3b1fd44eb2ad90a67256aad98ff2dce3a0fa63d930373b39956bb8ec4823a450e4f481	1	2026-06-12 05:09:53	0	46f2ddb8c0ecd7e62a1f1946b1747558	0	0	123456
\.


--
-- Data for Name: alarms; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.alarms (id, type, cabinet_id, device_id, content, level, status, created_at, resolved_at, resolver) FROM stdin;
\.


--
-- Data for Name: apk_version; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.apk_version (id, version_name, version_code, download_url, update_desc, create_time, file_md5) FROM stdin;
1	1.1.2	112	https://cqdyxl.com/static/smart-locker.apk	1. 新增远程升级功能\\n2. 新增版本更新弹窗\\n3. 新增下载进度显示\\n4. 支持WebSocket推送升级通知	2026-06-17 11:06:15	
3	1.2.0	120	https://cqdyxl.com/static/smart-locker.apk	1. 原生WebSocket连接\\n2. 修复socket.io兼容性问题\\n3. 补全Activity注册\\n4. 版本号统一	2026-06-18 07:47:11	
4	1.2.1	121	https://cqdyxl.com/static/smart-locker.apk	修复SSL证书信任问题	2026-06-18 09:26:10	
5	1.2.3	123	https://kelaiwei.top/static/smart-locker.apk	1. 恢复备案域名子域名locker.cqdyxl.com\\n2. 修复YBM拨码板号偏移\\n3. 修复YBM协议对齐竞品\\n4. 修复WebSocket连接\\n5. 新增YBM 0x9B设置指令	2026-06-19 05:56:49	
6	v1.2.8	128	http://locker.cqdyxl.com/static/smart-locker-v1.2.8.apk	1. SSL证书信任修复\\n2. wss://安全连接\\n3. 修复串口通信\\n4. 修复0x8A开锁协议	2026-06-20 11:56:32	
7	v1.2.9	129	http://locker.cqdyxl.com/static/smart-locker-v1.2.9.apk	1. 开机自启动\\n2. 修复二维码功能\\n3. UI优化	2026-06-20 12:28:46	
8	v1.2.10	130	http://locker.cqdyxl.com/static/smart-locker-v1.2.10.apk	修复更新安装卡住问题	2026-06-20 13:38:20	
9	v1.2.11	131	http://locker.cqdyxl.com/static/smart-locker-v1.2.11.apk	修复安装卡住+版本号上报	2026-06-20 14:08:42	
10	v1.2.12	132	http://locker.cqdyxl.com/static/smart-locker-v1.2.12.apk	修复APK解析错误	2026-06-20 14:39:58	
11	v1.2.13	133	http://locker.cqdyxl.com/static/smart-locker-v1.2.13.apk	版本号动态读取，修复更新循环	2026-06-20 14:50:48	
12	v1.2.14	134	https://locker.cqdyxl.com/static/smart-locker-v1.2.14.apk	修复WebSocket连接：强制wss://避免明文ws与SSL配置冲突	2026-06-20 15:51:29	
14	1.2.16	136	https://locker.cqdyxl.com/static/smart-locker.apk	修复YBM开锁协议+远程更新三级安装策略+UI复刻	2026-06-21 02:37:30	
15	1.2.17	137	https://locker.cqdyxl.com/static/smart-locker.apk	H5取包+二维码+缓存	2026-06-21 06:44:24	
16	1.2.18	138	https://locker.cqdyxl.com/static/smart-locker.apk	修复: 版本号+开机自启+退桌面重启+安装后自动重启	2026-06-21 07:15:26	
17	1.2.18	138	https://locker.cqdyxl.com/static/smart-locker.apk	fix: version+autostart	2026-06-21 07:16:45	
18	1.2.22	142	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.22 稳定版	2026-06-22 15:22:55	
19	1.2.24	144	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.24 工业屏规则分行+H5取包流程改造+二维码修复+跳转小程序+缓存修复	2026-06-23 07:25:53	
20	1.2.25	145	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.25 版本号升级	2026-06-24 01:27:22	
21	1.2.25	145	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.25	2026-06-24 01:27:31	
22	1.2.26	146	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.26 改为系统安装界面	2026-06-24 01:31:32	
23	1.2.27	147	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.27 返回按钮+取包成功页面+倒计时	2026-06-24 02:59:01	
24	1.2.28	148	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.28 取包界面优化+远程更新功能	2026-06-24 07:17:28	
25	1.2.29	149	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.29 修复开门成功弹窗不显示的问题	2026-06-24 09:34:37	
26	1.2.30	150	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.30 新增解绑功能，可远程解绑设备并重新绑定网点	2026-06-26 02:41:16	
27	1.2.31	151	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.31 修复远程自动更新	2026-06-26 21:21:41.407472	
28	1.2.32	152	https://locker.cqdyxl.com/static/smart-locker.apk	v1.2.32 修复安装后不返回软件的问题	2026-06-27 06:46:00.761888	
39	1.2.42	162	https://locker.cqdyxl.com/static/locker.apk	\N	2026-06-28 10:24:07.832223	66749536a08ab3ff24f98d235e73fe6a
30	1.2.33	153	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782517746	v1.2.33 新增前台保活+修复自动重启	2026-06-27 07:32:54.044919	
31	1.2.34	154	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782518827	修复安装后自动重启bug	2026-06-27 08:07:07.747029	
32	1.2.35	155	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782520891	修复重复FileProvider导致安装失败问题；优化安装流程	2026-06-27 08:41:32.108365	
33	1.2.36	156	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782521688	修复重复调度导致频繁轮询的问题	2026-06-27 08:54:49.012667	
34	1.2.37	157	https://locker.cqdyxl.com/static/smart-locker.apk?v=1782522225	修复前台保活机制导致界面反复重启的问题	2026-06-27 09:03:45.449798	
45	1.2.49	169	https://locker.cqdyxl.com/static/locker.apk	v1.2.49 混淆+取包显示修复	2026-06-30 07:40:37.308934	996dc013243b5066d87ee61508639839
36	1.2.39	159	https://locker.cqdyxl.com/static/locker.apk	修复onPause导致MainActivity无限重启循环	2026-06-27 09:55:31.928991	
46	1.2.50	170	https://locker.cqdyxl.com/static/locker.apk	???????????	2026-06-30 09:27:15.440268	
40	1.2.43	163	https://locker.cqdyxl.com/static/locker.apk	\N	2026-06-29 09:41:13.415587	ae15b3afeae83d00eadbda85d0311a24
35	1.2.39	159	https://locker.cqdyxl.com/static/locker.apk	修复keepAlive每15秒startActivity导致断网后界面反复重启	2026-06-27 09:11:34.022058	
37	1.2.40	160	https://locker.cqdyxl.com/static/locker.apk	修复WT协议VioSerial未配置波特率导致开锁失败	2026-06-27 14:50:40.644657	
38	1.2.41	161	https://locker.cqdyxl.com/static/locker.apk	修复update_config支持serial_type/protocol_type切换，新增reinitSerialAndProtocol彻底重初始化串口和协议；新增断网看门狗；修复pending命令默认board_no/lock_no导致误开门	2026-06-28 09:59:05.189506	
41	1.2.46	166	https://locker.cqdyxl.com/static/locker.apk	v1.2.46 修复YBM协议板号减1导致开门失败问题	2026-06-29 20:56:59.051845	fd7644f71b186d916a7306caf69c6599
43	1.2.47	167	https://locker.cqdyxl.com/static/locker.apk	v1.2.47 WS超时修复+轮询间隔3s+匹配管道轮转	2026-06-30 07:04:07.686534	a2b5fa08c0138bcca27dfe53680a3a18
44	1.2.48	168	https://locker.cqdyxl.com/static/locker.apk	v1.2.48 取包显示修复+公司号显示修复	2026-06-30 07:23:45.919957	ac800bb5a494189aa0bcada9b9380b03
\.


--
-- Data for Name: blacklist; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.blacklist (id, phone, reason, cabinet_id, operator, status, created_at) FROM stdin;
\.


--
-- Data for Name: cabinet_groups; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cabinet_groups (id, location_id, group_code, name, screen_url, status, created_at) FROM stdin;
1	4	a123	A	\N	1	2026-06-12 05:28:16
\.


--
-- Data for Name: cabinet_slots; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cabinet_slots (id, cabinet_id, slot_number, slot_size, status, cabinet_code, mainboard_id, display_number, board_no, lock_no, slot_label, updated_at) FROM stdin;
14	2	2	S	1	1	1	\N	1	2	\N	2026-06-26 05:33:44
15	2	3	S	1	1	1	\N	1	3	\N	2026-06-26 05:33:44
16	2	4	S	1	1	1	\N	1	4	\N	2026-06-26 05:33:44
17	2	5	M	1	1	1	\N	1	5	\N	2026-06-26 05:33:44
18	2	6	M	1	1	1	\N	1	6	\N	2026-06-26 05:33:44
19	2	7	M	1	1	1	\N	1	7	\N	2026-06-26 05:33:44
20	2	8	M	1	1	1	\N	1	8	\N	2026-06-26 05:33:44
21	2	9	L	1	1	1	\N	1	9	\N	2026-06-26 05:33:44
22	2	10	L	1	1	1	\N	1	10	\N	2026-06-26 05:33:44
23	2	11	L	1	1	1	\N	1	11	\N	2026-06-26 05:33:44
24	2	12	L	1	1	1	\N	1	12	\N	2026-06-26 05:33:44
25	2	13	M	1	1	1	1	1	13	\N	2026-06-26 05:33:44
26	2	14	M	1	1	1	2	1	14	\N	2026-06-26 05:33:44
27	2	15	M	1	1	1	3	1	15	\N	2026-06-26 05:33:44
28	2	16	M	1	1	1	4	1	16	\N	2026-06-26 05:33:44
57	3	1	M	1	c001	3	1	1	1	\N	2026-06-26 05:33:44
58	3	2	M	1	c001	3	2	1	2	\N	2026-06-26 05:33:44
59	3	3	M	1	c001	3	3	1	3	\N	2026-06-26 05:33:44
60	3	4	M	1	c001	3	4	1	4	\N	2026-06-26 05:33:44
61	3	5	M	1	c001	3	5	1	5	\N	2026-06-26 05:33:44
62	3	6	M	1	c001	3	6	1	6	\N	2026-06-26 05:33:44
63	3	7	M	1	c001	3	7	1	7	\N	2026-06-26 05:33:44
64	3	8	M	1	c001	3	8	1	8	\N	2026-06-26 05:33:44
65	3	9	M	1	c001	3	9	1	9	\N	2026-06-26 05:33:44
66	3	10	M	1	c001	3	10	1	10	\N	2026-06-26 05:33:44
67	3	11	M	1	c001	3	11	1	11	\N	2026-06-26 05:33:44
68	3	12	M	1	c001	3	12	1	12	\N	2026-06-26 05:33:44
69	5	1	M	1	CAB002	4	1	1	1	\N	2026-06-26 05:33:44
70	5	2	M	1	CAB002	4	2	1	2	\N	2026-06-26 05:33:44
71	5	3	M	1	CAB002	4	3	1	3	\N	2026-06-26 05:33:44
72	5	4	M	1	CAB002	4	4	1	4	\N	2026-06-26 05:33:44
73	5	5	M	1	CAB002	4	5	1	5	\N	2026-06-26 05:33:44
74	5	6	M	1	CAB002	4	6	1	6	\N	2026-06-26 05:33:44
75	5	7	M	1	CAB002	4	7	1	7	\N	2026-06-26 05:33:44
76	5	8	M	1	CAB002	4	8	1	8	\N	2026-06-26 05:33:44
77	5	9	M	1	CAB002	4	9	1	9	\N	2026-06-26 05:33:44
78	5	10	M	1	CAB002	4	10	1	10	\N	2026-06-26 05:33:44
79	5	11	M	1	CAB002	4	11	1	11	\N	2026-06-26 05:33:44
80	5	12	M	1	CAB002	4	12	1	12	\N	2026-06-26 05:33:44
81	5	13	M	1	CAB002	4	13	1	13	\N	2026-06-26 05:33:44
82	5	14	M	1	CAB002	4	14	1	14	\N	2026-06-26 05:33:44
83	5	15	M	1	CAB002	4	15	1	15	\N	2026-06-26 05:33:44
84	5	16	M	1	CAB002	4	16	1	16	\N	2026-06-26 05:33:44
181	9	1	M	1	\N	13	\N	1	1	\N	2026-06-26 05:33:44
182	9	2	M	1	\N	13	\N	1	2	\N	2026-06-26 05:33:44
183	9	3	M	1	\N	13	\N	1	3	\N	2026-06-26 05:33:44
184	9	4	M	1	\N	13	\N	1	4	\N	2026-06-26 05:33:44
185	9	5	M	1	\N	13	\N	1	5	\N	2026-06-26 05:33:44
186	9	6	M	1	\N	13	\N	1	6	\N	2026-06-26 05:33:44
187	9	7	M	1	\N	13	\N	1	7	\N	2026-06-26 05:33:44
188	9	8	M	1	\N	13	\N	1	8	\N	2026-06-26 05:33:44
189	9	9	M	1	\N	13	\N	1	9	\N	2026-06-26 05:33:44
190	9	10	M	1	\N	13	\N	1	10	\N	2026-06-26 05:33:44
191	9	11	M	1	\N	13	\N	1	11	\N	2026-06-26 05:33:44
192	9	12	M	1	\N	13	\N	1	12	\N	2026-06-26 05:33:44
193	10	1	M	1	\N	14	\N	1	1	\N	2026-06-26 05:33:44
194	10	2	M	1	\N	14	\N	1	2	\N	2026-06-26 05:33:44
195	10	3	M	1	\N	14	\N	1	3	\N	2026-06-26 05:33:44
37	2	25	M	1	1	2	13	2	9	\N	2026-06-26 05:33:44
38	2	26	M	1	1	2	14	2	10	\N	2026-06-26 05:33:44
39	2	27	M	1	1	2	15	2	11	\N	2026-06-26 05:33:44
40	2	28	M	1	1	2	16	2	12	\N	2026-06-26 05:33:44
41	2	29	M	1	1	2	17	2	13	\N	2026-06-26 05:33:44
42	2	30	M	1	1	2	18	2	14	\N	2026-06-26 05:33:44
43	2	31	M	1	1	2	19	2	15	\N	2026-06-26 05:33:44
44	2	32	M	1	1	2	20	2	16	\N	2026-06-26 05:33:44
45	2	33	M	1	1	2	21	3	1	\N	2026-06-26 05:33:44
46	2	34	M	1	1	2	22	3	2	\N	2026-06-26 05:33:44
47	2	35	M	1	1	2	23	3	3	\N	2026-06-26 05:33:44
48	2	36	M	1	1	2	24	3	4	\N	2026-06-26 05:33:44
49	2	37	M	1	1	2	25	3	5	\N	2026-06-26 05:33:44
50	2	38	M	1	1	2	26	3	6	\N	2026-06-26 05:33:44
51	2	39	M	1	1	2	27	3	7	\N	2026-06-26 05:33:44
52	2	40	M	1	1	2	28	3	8	\N	2026-06-26 05:33:44
13	2	1	S	1	1	1	\N	1	1	\N	2026-06-26 05:33:44
196	10	4	M	1	\N	14	\N	1	4	\N	2026-06-26 05:33:44
197	10	5	M	1	\N	14	\N	1	5	\N	2026-06-26 05:33:44
198	10	6	M	1	\N	14	\N	1	6	\N	2026-06-26 05:33:44
199	10	7	M	1	\N	14	\N	1	7	\N	2026-06-26 05:33:44
200	10	8	M	1	\N	14	\N	1	8	\N	2026-06-26 05:33:44
201	10	9	M	1	\N	14	\N	1	9	\N	2026-06-26 05:33:44
202	10	10	M	1	\N	14	\N	1	10	\N	2026-06-26 05:33:44
203	10	11	M	1	\N	14	\N	1	11	\N	2026-06-26 05:33:44
204	10	12	M	1	\N	14	\N	1	12	\N	2026-06-26 05:33:44
205	11	1	M	1	\N	15	\N	1	1	\N	2026-06-26 05:33:44
206	11	2	M	1	\N	15	\N	1	2	\N	2026-06-26 05:33:44
207	11	3	M	1	\N	15	\N	1	3	\N	2026-06-26 05:33:44
208	11	4	M	1	\N	15	\N	1	4	\N	2026-06-26 05:33:44
209	11	5	M	1	\N	15	\N	1	5	\N	2026-06-26 05:33:44
210	11	6	M	1	\N	15	\N	1	6	\N	2026-06-26 05:33:44
211	11	7	M	1	\N	15	\N	1	7	\N	2026-06-26 05:33:44
212	11	8	M	1	\N	15	\N	1	8	\N	2026-06-26 05:33:44
213	11	9	M	1	\N	15	\N	1	9	\N	2026-06-26 05:33:44
214	11	10	M	1	\N	15	\N	1	10	\N	2026-06-26 05:33:44
215	11	11	M	1	\N	15	\N	1	11	\N	2026-06-26 05:33:44
216	11	12	M	1	\N	15	\N	1	12	\N	2026-06-26 05:33:44
229	13	1	M	1	\N	17	\N	1	1	\N	2026-06-26 05:33:44
230	13	2	M	1	\N	17	\N	1	2	\N	2026-06-26 05:33:44
231	13	3	M	1	\N	17	\N	1	3	\N	2026-06-26 05:33:44
232	13	4	M	1	\N	17	\N	1	4	\N	2026-06-26 05:33:44
233	13	5	M	1	\N	17	\N	1	5	\N	2026-06-26 05:33:44
234	13	6	M	1	\N	17	\N	1	6	\N	2026-06-26 05:33:44
235	13	7	M	1	\N	17	\N	1	7	\N	2026-06-26 05:33:44
236	13	8	M	1	\N	17	\N	1	8	\N	2026-06-26 05:33:44
237	13	9	M	1	\N	17	\N	1	9	\N	2026-06-26 05:33:44
238	13	10	M	1	\N	17	\N	1	10	\N	2026-06-26 05:33:44
239	13	11	M	1	\N	17	\N	1	11	\N	2026-06-26 05:33:44
240	13	12	M	1	\N	17	\N	1	12	\N	2026-06-26 05:33:44
241	14	1	M	1	\N	18	\N	1	1	\N	2026-06-26 05:33:44
242	14	2	M	1	\N	18	\N	1	2	\N	2026-06-26 05:33:44
243	14	3	M	1	\N	18	\N	1	3	\N	2026-06-26 05:33:44
244	14	4	M	1	\N	18	\N	1	4	\N	2026-06-26 05:33:44
245	14	5	M	1	\N	18	\N	1	5	\N	2026-06-26 05:33:44
246	14	6	M	1	\N	18	\N	1	6	\N	2026-06-26 05:33:44
247	14	7	M	1	\N	18	\N	1	7	\N	2026-06-26 05:33:44
248	14	8	M	1	\N	18	\N	1	8	\N	2026-06-26 05:33:44
249	14	9	M	1	\N	18	\N	1	9	\N	2026-06-26 05:33:44
250	14	10	M	1	\N	18	\N	1	10	\N	2026-06-26 05:33:44
251	14	11	M	1	\N	18	\N	1	11	\N	2026-06-26 05:33:44
252	14	12	M	1	\N	18	\N	1	12	\N	2026-06-26 05:33:44
448	8	2	medium	1	\N	\N	\N	1	2	2	2026-06-26 05:33:44
449	8	3	medium	1	\N	\N	\N	1	3	3	2026-06-26 05:33:44
450	8	4	medium	1	\N	\N	\N	1	4	4	2026-06-26 05:33:44
451	8	5	medium	1	\N	\N	\N	1	5	5	2026-06-26 05:33:44
452	8	6	medium	1	\N	\N	\N	1	6	6	2026-06-26 05:33:44
453	8	7	medium	1	\N	\N	\N	1	7	7	2026-06-26 05:33:44
1184	34	2	medium	1	\N	\N	\N	1	2	2	\N
456	8	10	medium	1	\N	\N	\N	1	10	10	2026-06-26 05:33:44
457	8	11	medium	1	\N	\N	\N	1	11	11	2026-06-26 05:33:44
458	8	12	medium	1	\N	\N	\N	1	12	12	2026-06-26 05:33:44
459	8	13	medium	1	\N	\N	\N	1	13	13	2026-06-26 05:33:44
460	8	14	medium	1	\N	\N	\N	1	14	14	2026-06-26 05:33:44
461	8	15	medium	1	\N	\N	\N	1	15	15	2026-06-26 05:33:44
462	8	16	medium	1	\N	\N	\N	1	16	16	2026-06-26 05:33:44
655	26	1	medium	1	\N	\N	\N	1	1	1	\N
656	26	2	medium	1	\N	\N	\N	1	2	2	\N
657	26	3	medium	1	\N	\N	\N	1	3	3	\N
715	27	13	medium	1	\N	\N	\N	1	13	D13	\N
1185	34	3	medium	1	\N	\N	\N	1	3	3	\N
1186	34	4	medium	1	\N	\N	\N	1	4	4	\N
1187	34	5	medium	1	\N	\N	\N	1	5	5	\N
1188	34	6	medium	1	\N	\N	\N	1	6	6	\N
1189	34	7	medium	1	\N	\N	\N	1	7	7	\N
1190	34	8	medium	1	\N	\N	\N	1	8	8	\N
1191	34	9	medium	1	\N	\N	\N	1	9	9	\N
1192	34	10	medium	1	\N	\N	\N	1	10	10	\N
1193	34	11	medium	1	\N	\N	\N	1	11	11	\N
1194	34	12	medium	1	\N	\N	\N	1	12	12	\N
1195	34	13	medium	1	\N	\N	\N	1	13	13	\N
1196	34	14	medium	1	\N	\N	\N	1	14	14	\N
1197	34	15	medium	1	\N	\N	\N	1	15	15	\N
1198	34	16	medium	1	\N	\N	\N	1	16	16	\N
1199	34	17	medium	1	\N	\N	\N	2	1	17	\N
1200	34	18	medium	1	\N	\N	\N	2	2	18	\N
1201	34	19	medium	1	\N	\N	\N	2	3	19	\N
1202	34	20	medium	1	\N	\N	\N	2	4	20	\N
1203	34	21	medium	1	\N	\N	\N	2	5	21	\N
1204	34	22	medium	1	\N	\N	\N	2	6	22	\N
1205	34	23	medium	1	\N	\N	\N	2	7	23	\N
1206	34	24	medium	1	\N	\N	\N	2	8	24	\N
1207	34	25	medium	1	\N	\N	\N	2	9	25	\N
1208	34	26	medium	1	\N	\N	\N	2	10	26	\N
1209	34	27	medium	1	\N	\N	\N	2	11	27	\N
1210	34	28	medium	1	\N	\N	\N	2	12	28	\N
717	27	15	medium	1	\N	\N	\N	1	15	D15	\N
718	27	16	medium	1	\N	\N	\N	1	16	D16	\N
719	27	17	medium	4	\N	\N	\N	2	1	D17	\N
720	27	18	medium	1	\N	\N	\N	2	2	D18	\N
1211	34	29	medium	1	\N	\N	\N	2	13	29	\N
1212	34	30	medium	1	\N	\N	\N	2	14	30	\N
716	27	14	medium	1	\N	\N	\N	1	14	D14	\N
721	27	19	medium	2	\N	\N	\N	2	3	D19	\N
722	27	20	medium	1	\N	\N	\N	2	4	D20	\N
1213	34	31	medium	1	\N	\N	\N	2	15	31	\N
1214	34	32	medium	1	\N	\N	\N	2	16	32	\N
455	8	9	medium	1	\N	\N	\N	1	9	9	2026-06-26 05:33:44
447	8	1	medium	1	\N	\N	\N	1	1	1	2026-06-26 05:33:44
463	15	1	medium	1	\N	\N	\N	1	1	A1	\N
495	16	1	medium	1	\N	\N	\N	1	1	B1	\N
602	24	12	medium	1	\N	\N	\N	1	12	E12	\N
731	27	29	medium	1	\N	\N	\N	2	13	D29	\N
723	27	21	medium	1	\N	\N	\N	2	5	D21	\N
625	24	35	medium	1	\N	\N	\N	3	3	E35	\N
603	24	13	medium	1	\N	\N	\N	1	13	E13	\N
641	24	51	medium	1	\N	\N	\N	4	3	E51	\N
633	24	43	medium	1	\N	\N	\N	3	11	E43	\N
726	27	24	medium	4	\N	\N	\N	2	8	D24	\N
727	27	25	medium	4	\N	\N	\N	2	9	D25	\N
728	27	26	medium	4	\N	\N	\N	2	10	D26	\N
729	27	27	medium	1	\N	\N	\N	2	11	D27	\N
601	24	11	medium	1	\N	\N	\N	1	11	E11	\N
639	24	49	medium	1	\N	\N	\N	4	1	E49	\N
604	24	14	medium	1	\N	\N	\N	1	14	E14	\N
599	24	9	medium	1	\N	\N	\N	1	9	E9	\N
597	24	7	medium	1	\N	\N	\N	1	7	E7	\N
724	27	22	medium	1	\N	\N	\N	2	6	D22	\N
605	24	15	medium	1	\N	\N	\N	1	15	E15	\N
629	24	39	medium	1	\N	\N	\N	3	7	E39	\N
630	24	40	medium	1	\N	\N	\N	3	8	E40	\N
1231	34	49	medium	1	\N	\N	\N	4	1	49	\N
1215	34	33	medium	1	\N	\N	\N	3	1	33	\N
506	16	12	medium	1	\N	\N	\N	1	12	B12	2026-06-30 15:37:21.900677
642	24	52	medium	1	\N	\N	\N	4	4	E52	\N
730	27	28	medium	1	\N	\N	\N	2	12	D28	\N
623	24	33	medium	1	\N	\N	\N	3	1	E33	\N
598	24	8	medium	1	\N	\N	\N	1	8	E8	\N
600	24	10	medium	4	\N	\N	\N	1	10	E10	\N
606	24	16	medium	3	\N	\N	\N	1	16	E16	\N
658	26	4	medium	1	\N	\N	\N	1	4	4	\N
659	26	5	medium	1	\N	\N	\N	1	5	5	\N
660	26	6	medium	1	\N	\N	\N	1	6	6	\N
661	26	7	medium	1	\N	\N	\N	1	7	7	\N
662	26	8	medium	1	\N	\N	\N	1	8	8	\N
663	26	9	medium	1	\N	\N	\N	1	9	9	\N
664	26	10	medium	1	\N	\N	\N	1	10	10	\N
665	26	11	medium	1	\N	\N	\N	1	11	11	\N
666	26	12	medium	1	\N	\N	\N	1	12	12	\N
667	26	13	medium	1	\N	\N	\N	1	13	13	\N
668	26	14	medium	1	\N	\N	\N	1	14	14	\N
669	26	15	medium	1	\N	\N	\N	1	15	15	\N
670	26	16	medium	1	\N	\N	\N	1	16	16	\N
687	26	33	medium	1	\N	\N	\N	3	1	33	\N
688	26	34	medium	1	\N	\N	\N	3	2	34	\N
689	26	35	medium	1	\N	\N	\N	3	3	35	\N
690	26	36	medium	1	\N	\N	\N	3	4	36	\N
691	26	37	medium	1	\N	\N	\N	3	5	37	\N
692	26	38	medium	1	\N	\N	\N	3	6	38	\N
693	26	39	medium	1	\N	\N	\N	3	7	39	\N
694	26	40	medium	1	\N	\N	\N	3	8	40	\N
695	26	41	medium	1	\N	\N	\N	3	9	41	\N
696	26	42	medium	1	\N	\N	\N	3	10	42	\N
697	26	43	medium	1	\N	\N	\N	3	11	43	\N
698	26	44	medium	1	\N	\N	\N	3	12	44	\N
699	26	45	medium	1	\N	\N	\N	3	13	45	\N
700	26	46	medium	1	\N	\N	\N	3	14	46	\N
701	26	47	medium	1	\N	\N	\N	3	15	47	\N
702	26	48	medium	1	\N	\N	\N	3	16	48	\N
467	15	5	medium	1	\N	\N	\N	1	5	A5	\N
496	16	2	medium	1	\N	\N	\N	1	2	B2	\N
497	16	3	medium	1	\N	\N	\N	1	3	B3	\N
498	16	4	medium	1	\N	\N	\N	1	4	B4	\N
500	16	6	medium	1	\N	\N	\N	1	6	B6	\N
501	16	7	medium	1	\N	\N	\N	1	7	B7	\N
502	16	8	medium	1	\N	\N	\N	1	8	B8	\N
503	16	9	medium	1	\N	\N	\N	1	9	B9	\N
504	16	10	medium	1	\N	\N	\N	1	10	B10	\N
594	24	4	medium	1	\N	\N	\N	1	4	E4	\N
505	16	11	medium	1	\N	\N	\N	1	11	B11	\N
626	24	36	medium	1	\N	\N	\N	3	4	E36	\N
507	16	13	medium	1	\N	\N	\N	1	13	B13	\N
635	24	45	medium	1	\N	\N	\N	3	13	E45	\N
508	16	14	medium	1	\N	\N	\N	1	14	B14	\N
725	27	23	medium	1	\N	\N	\N	2	7	D23	\N
636	24	46	medium	1	\N	\N	\N	3	14	E46	\N
624	24	34	medium	1	\N	\N	\N	3	2	E34	\N
638	24	48	medium	1	\N	\N	\N	3	16	E48	\N
596	24	6	medium	1	\N	\N	\N	1	6	E6	\N
640	24	50	medium	1	\N	\N	\N	4	2	E50	\N
628	24	38	medium	1	\N	\N	\N	3	6	E38	\N
632	24	42	medium	1	\N	\N	\N	3	10	E42	\N
637	24	47	medium	1	\N	\N	\N	3	15	E47	\N
595	24	5	medium	1	\N	\N	\N	1	5	E5	\N
634	24	44	medium	1	\N	\N	\N	3	12	E44	\N
627	24	37	medium	2	\N	\N	\N	3	5	E37	\N
643	24	53	medium	1	\N	\N	\N	4	5	E53	\N
631	24	41	medium	2	\N	\N	\N	3	9	E41	\N
644	24	54	medium	1	\N	\N	\N	4	6	E54	\N
621	24	31	medium	3	\N	\N	\N	2	15	E31	\N
671	26	17	medium	1	\N	\N	\N	2	1	17	\N
672	26	18	medium	1	\N	\N	\N	2	2	18	\N
673	26	19	medium	1	\N	\N	\N	2	3	19	\N
674	26	20	medium	1	\N	\N	\N	2	4	20	\N
675	26	21	medium	1	\N	\N	\N	2	5	21	\N
676	26	22	medium	1	\N	\N	\N	2	6	22	\N
677	26	23	medium	1	\N	\N	\N	2	7	23	\N
678	26	24	medium	1	\N	\N	\N	2	8	24	\N
679	26	25	medium	1	\N	\N	\N	2	9	25	\N
680	26	26	medium	1	\N	\N	\N	2	10	26	\N
681	26	27	medium	1	\N	\N	\N	2	11	27	\N
682	26	28	medium	1	\N	\N	\N	2	12	28	\N
683	26	29	medium	1	\N	\N	\N	2	13	29	\N
684	26	30	medium	1	\N	\N	\N	2	14	30	\N
685	26	31	medium	1	\N	\N	\N	2	15	31	\N
686	26	32	medium	1	\N	\N	\N	2	16	32	\N
1232	34	50	medium	1	\N	\N	\N	4	2	50	\N
591	24	1	medium	1	\N	\N	\N	1	1	E1	\N
713	27	11	medium	1	\N	\N	\N	1	11	D11	\N
1233	34	51	medium	1	\N	\N	\N	4	3	51	\N
650	24	60	medium	1	\N	\N	\N	4	12	E60	\N
652	24	62	medium	1	\N	\N	\N	4	14	E62	\N
646	24	56	medium	1	\N	\N	\N	4	8	E56	\N
593	24	3	medium	1	\N	\N	\N	1	3	E3	\N
651	24	61	medium	2	\N	\N	\N	4	13	E61	\N
1234	34	52	medium	1	\N	\N	\N	4	4	52	\N
620	24	30	medium	1	\N	\N	\N	2	14	E30	\N
1235	34	53	medium	1	\N	\N	\N	4	5	53	\N
1236	34	54	medium	1	\N	\N	\N	4	6	54	\N
770	15	52	medium	1	\N	\N	\N	4	4	A52	\N
653	24	63	medium	1	\N	\N	\N	4	15	E63	\N
771	15	53	medium	1	\N	\N	\N	4	5	A53	\N
1237	34	55	medium	1	\N	\N	\N	4	7	55	\N
1238	34	56	medium	1	\N	\N	\N	4	8	56	\N
1239	34	57	medium	1	\N	\N	\N	4	9	57	\N
1240	34	58	medium	1	\N	\N	\N	4	10	58	\N
611	24	21	medium	1	\N	\N	\N	2	5	E21	\N
609	24	19	medium	1	\N	\N	\N	2	3	E19	\N
708	27	6	medium	1	\N	\N	\N	1	6	D6	\N
615	24	25	medium	1	\N	\N	\N	2	9	E25	\N
614	24	24	medium	1	\N	\N	\N	2	8	E24	\N
618	24	28	medium	1	\N	\N	\N	2	12	E28	\N
645	24	55	medium	1	\N	\N	\N	4	7	E55	\N
1241	34	59	medium	1	\N	\N	\N	4	11	59	\N
1242	34	60	medium	1	\N	\N	\N	4	12	60	\N
1243	34	61	medium	1	\N	\N	\N	4	13	61	\N
710	27	8	medium	1	\N	\N	\N	1	8	D8	\N
454	8	8	medium	1	\N	\N	\N	1	8	8	2026-06-26 05:33:44
705	27	3	medium	1	\N	\N	\N	1	3	D3	\N
772	15	54	medium	1	\N	\N	\N	4	6	A54	\N
773	15	55	medium	1	\N	\N	\N	4	7	A55	\N
1244	34	62	medium	1	\N	\N	\N	4	14	62	\N
774	15	56	medium	1	\N	\N	\N	4	8	A56	\N
775	15	57	medium	1	\N	\N	\N	4	9	A57	\N
776	15	58	medium	1	\N	\N	\N	4	10	A58	\N
777	15	59	medium	1	\N	\N	\N	4	11	A59	\N
613	24	23	medium	1	\N	\N	\N	2	7	E23	\N
778	15	60	medium	1	\N	\N	\N	4	12	A60	\N
608	24	18	medium	1	\N	\N	\N	2	2	E18	\N
779	15	61	medium	3	\N	\N	\N	4	13	A61	\N
592	24	2	medium	1	\N	\N	\N	1	2	E2	\N
780	15	62	medium	1	\N	\N	\N	4	14	A62	\N
781	15	63	medium	1	\N	\N	\N	4	15	A63	\N
709	27	7	medium	1	\N	\N	\N	1	7	D7	\N
782	15	64	medium	1	\N	\N	\N	4	16	A64	\N
788	15	70	medium	1	\N	\N	\N	5	6	A70	\N
1245	34	63	medium	1	\N	\N	\N	4	15	63	\N
789	15	71	medium	1	\N	\N	\N	5	7	A71	\N
607	24	17	medium	1	\N	\N	\N	2	1	E17	\N
704	27	2	medium	1	\N	\N	\N	1	2	D2	\N
510	16	16	medium	1	\N	\N	\N	1	16	B16	\N
511	16	17	medium	1	\N	\N	\N	2	1	B17	\N
612	24	22	medium	1	\N	\N	\N	2	6	E22	\N
703	27	1	medium	1	\N	\N	\N	1	1	D1	\N
616	24	26	medium	1	\N	\N	\N	2	10	E26	\N
617	24	27	medium	1	\N	\N	\N	2	11	E27	\N
610	24	20	medium	1	\N	\N	\N	2	4	E20	\N
706	27	4	medium	1	\N	\N	\N	1	4	D4	\N
513	16	19	medium	1	\N	\N	\N	2	3	B19	\N
514	16	20	medium	1	\N	\N	\N	2	4	B20	\N
648	24	58	medium	1	\N	\N	\N	4	10	E58	\N
515	16	21	medium	1	\N	\N	\N	2	5	B21	\N
518	16	24	medium	1	\N	\N	\N	2	8	B24	\N
519	16	25	medium	1	\N	\N	\N	2	9	B25	\N
512	16	18	medium	1	\N	\N	\N	2	2	B18	2026-06-30 15:36:26.717548
1246	34	64	medium	1	\N	\N	\N	4	16	64	\N
943	30	1	medium	1	\N	\N	\N	1	1	A1	\N
707	27	5	medium	1	\N	\N	\N	1	5	D5	\N
944	30	2	medium	1	\N	\N	\N	1	2	A2	\N
711	27	9	medium	1	\N	\N	\N	1	9	D9	\N
945	30	3	medium	1	\N	\N	\N	1	3	A3	\N
946	30	4	medium	1	\N	\N	\N	1	4	A4	\N
647	24	57	medium	1	\N	\N	\N	4	9	E57	\N
712	27	10	medium	1	\N	\N	\N	1	10	D10	\N
714	27	12	medium	1	\N	\N	\N	1	12	D12	\N
654	24	64	medium	1	\N	\N	\N	4	16	E64	\N
649	24	59	medium	1	\N	\N	\N	4	11	E59	\N
622	24	32	medium	1	\N	\N	\N	2	16	E32	\N
619	24	29	medium	1	\N	\N	\N	2	13	E29	\N
736	27	34	medium	1	\N	\N	\N	3	2	D34	\N
738	27	36	medium	1	\N	\N	\N	3	4	D36	\N
732	27	30	medium	1	\N	\N	\N	2	14	D30	\N
743	27	41	medium	1	\N	\N	\N	3	9	D41	\N
741	27	39	medium	1	\N	\N	\N	3	7	D39	\N
749	27	47	medium	1	\N	\N	\N	3	15	D47	\N
750	27	48	medium	1	\N	\N	\N	3	16	D48	\N
748	27	46	medium	1	\N	\N	\N	3	14	D46	\N
746	27	44	medium	1	\N	\N	\N	3	12	D44	\N
734	27	32	medium	1	\N	\N	\N	2	16	D32	\N
947	30	5	medium	1	\N	\N	\N	1	5	A5	\N
948	30	6	medium	1	\N	\N	\N	1	6	A6	\N
949	30	7	medium	1	\N	\N	\N	1	7	A7	\N
950	30	8	medium	1	\N	\N	\N	1	8	A8	\N
951	30	9	medium	1	\N	\N	\N	1	9	A9	\N
739	27	37	medium	4	\N	\N	\N	3	5	D37	\N
740	27	38	medium	1	\N	\N	\N	3	6	D38	\N
952	30	10	medium	1	\N	\N	\N	1	10	A10	\N
742	27	40	medium	4	\N	\N	\N	3	8	D40	\N
953	30	11	medium	1	\N	\N	\N	1	11	A11	\N
744	27	42	medium	4	\N	\N	\N	3	10	D42	\N
954	30	12	medium	1	\N	\N	\N	1	12	A12	\N
955	30	13	medium	1	\N	\N	\N	1	13	A13	\N
747	27	45	medium	1	\N	\N	\N	3	13	D45	\N
956	30	14	medium	1	\N	\N	\N	1	14	A14	\N
957	30	15	medium	1	\N	\N	\N	1	15	A15	\N
735	27	33	medium	1	\N	\N	\N	3	1	D33	\N
745	27	43	medium	1	\N	\N	\N	3	11	D43	\N
733	27	31	medium	1	\N	\N	\N	2	15	D31	\N
737	27	35	medium	1	\N	\N	\N	3	3	D35	\N
464	15	2	medium	1	\N	\N	\N	1	2	A2	\N
465	15	3	medium	1	\N	\N	\N	1	3	A3	\N
466	15	4	medium	3	\N	\N	\N	1	4	A4	\N
468	15	6	medium	1	\N	\N	\N	1	6	A6	\N
469	15	7	medium	1	\N	\N	\N	1	7	A7	\N
470	15	8	medium	1	\N	\N	\N	1	8	A8	\N
471	15	9	medium	1	\N	\N	\N	1	9	A9	\N
472	15	10	medium	1	\N	\N	\N	1	10	A10	\N
473	15	11	medium	1	\N	\N	\N	1	11	A11	\N
474	15	12	medium	3	\N	\N	\N	1	12	A12	\N
475	15	13	medium	1	\N	\N	\N	1	13	A13	\N
476	15	14	medium	1	\N	\N	\N	1	14	A14	\N
477	15	15	medium	1	\N	\N	\N	1	15	A15	\N
478	15	16	medium	1	\N	\N	\N	1	16	A16	\N
479	15	17	medium	1	\N	\N	\N	2	1	A17	\N
480	15	18	medium	1	\N	\N	\N	2	2	A18	\N
481	15	19	medium	1	\N	\N	\N	2	3	A19	\N
482	15	20	medium	1	\N	\N	\N	2	4	A20	\N
483	15	21	medium	3	\N	\N	\N	2	5	A21	\N
484	15	22	medium	1	\N	\N	\N	2	6	A22	\N
485	15	23	medium	1	\N	\N	\N	2	7	A23	\N
486	15	24	medium	1	\N	\N	\N	2	8	A24	\N
487	15	25	medium	1	\N	\N	\N	2	9	A25	\N
488	15	26	medium	3	\N	\N	\N	2	10	A26	\N
489	15	27	medium	1	\N	\N	\N	2	11	A27	\N
490	15	28	medium	1	\N	\N	\N	2	12	A28	\N
491	15	29	medium	1	\N	\N	\N	2	13	A29	\N
492	15	30	medium	1	\N	\N	\N	2	14	A30	\N
493	15	31	medium	1	\N	\N	\N	2	15	A31	\N
494	15	32	medium	1	\N	\N	\N	2	16	A32	\N
751	15	33	medium	1	\N	\N	\N	3	1	A33	\N
752	15	34	medium	1	\N	\N	\N	3	2	A34	\N
753	15	35	medium	1	\N	\N	\N	3	3	A35	\N
754	15	36	medium	1	\N	\N	\N	3	4	A36	\N
755	15	37	medium	1	\N	\N	\N	3	5	A37	\N
756	15	38	medium	1	\N	\N	\N	3	6	A38	\N
757	15	39	medium	1	\N	\N	\N	3	7	A39	\N
758	15	40	medium	1	\N	\N	\N	3	8	A40	\N
759	15	41	medium	1	\N	\N	\N	3	9	A41	\N
760	15	42	medium	1	\N	\N	\N	3	10	A42	\N
761	15	43	medium	3	\N	\N	\N	3	11	A43	\N
762	15	44	medium	3	\N	\N	\N	3	12	A44	\N
763	15	45	medium	1	\N	\N	\N	3	13	A45	\N
764	15	46	medium	1	\N	\N	\N	3	14	A46	\N
765	15	47	medium	1	\N	\N	\N	3	15	A47	\N
766	15	48	medium	1	\N	\N	\N	3	16	A48	\N
767	15	49	medium	1	\N	\N	\N	4	1	A49	\N
768	15	50	medium	1	\N	\N	\N	4	2	A50	\N
769	15	51	medium	1	\N	\N	\N	4	3	A51	\N
783	15	65	medium	1	\N	\N	\N	5	1	A65	\N
784	15	66	medium	1	\N	\N	\N	5	2	A66	\N
785	15	67	medium	1	\N	\N	\N	5	3	A67	\N
786	15	68	medium	1	\N	\N	\N	5	4	A68	\N
787	15	69	medium	1	\N	\N	\N	5	5	A69	\N
800	16	34	medium	1	\N	\N	\N	3	2	B34	\N
801	16	35	medium	1	\N	\N	\N	3	3	B35	\N
802	16	36	medium	1	\N	\N	\N	3	4	B36	\N
803	16	37	medium	1	\N	\N	\N	3	5	B37	\N
804	16	38	medium	1	\N	\N	\N	3	6	B38	\N
805	16	39	medium	1	\N	\N	\N	3	7	B39	\N
806	16	40	medium	1	\N	\N	\N	3	8	B40	\N
807	16	41	medium	1	\N	\N	\N	3	9	B41	\N
808	16	42	medium	1	\N	\N	\N	3	10	B42	\N
809	16	43	medium	1	\N	\N	\N	3	11	B43	\N
810	16	44	medium	1	\N	\N	\N	3	12	B44	\N
811	16	45	medium	1	\N	\N	\N	3	13	B45	\N
812	16	46	medium	1	\N	\N	\N	3	14	B46	\N
813	16	47	medium	1	\N	\N	\N	3	15	B47	\N
814	16	48	medium	1	\N	\N	\N	3	16	B48	\N
958	30	16	medium	1	\N	\N	\N	1	16	A16	\N
959	30	17	medium	1	\N	\N	\N	2	1	A17	\N
960	30	18	medium	1	\N	\N	\N	2	2	A18	\N
961	30	19	medium	1	\N	\N	\N	2	3	A19	\N
962	30	20	medium	1	\N	\N	\N	2	4	A20	\N
790	15	72	medium	1	\N	\N	\N	5	8	A72	\N
791	15	73	medium	1	\N	\N	\N	5	9	A73	\N
792	15	74	medium	1	\N	\N	\N	5	10	A74	\N
793	15	75	medium	1	\N	\N	\N	5	11	A75	\N
794	15	76	medium	1	\N	\N	\N	5	12	A76	\N
795	15	77	medium	1	\N	\N	\N	5	13	A77	\N
796	15	78	medium	1	\N	\N	\N	5	14	A78	\N
797	15	79	medium	1	\N	\N	\N	5	15	A79	\N
798	15	80	medium	1	\N	\N	\N	5	16	A80	\N
524	16	30	medium	1	\N	\N	\N	2	14	B30	\N
526	16	32	medium	1	\N	\N	\N	2	16	B32	\N
815	16	49	medium	1	\N	\N	\N	4	1	B49	\N
816	16	50	medium	1	\N	\N	\N	4	2	B50	\N
817	16	51	medium	1	\N	\N	\N	4	3	B51	\N
818	16	52	medium	1	\N	\N	\N	4	4	B52	\N
819	16	53	medium	1	\N	\N	\N	4	5	B53	\N
820	16	54	medium	1	\N	\N	\N	4	6	B54	\N
821	16	55	medium	1	\N	\N	\N	4	7	B55	\N
822	16	56	medium	1	\N	\N	\N	4	8	B56	\N
823	16	57	medium	1	\N	\N	\N	4	9	B57	\N
824	16	58	medium	1	\N	\N	\N	4	10	B58	\N
825	16	59	medium	1	\N	\N	\N	4	11	B59	\N
826	16	60	medium	1	\N	\N	\N	4	12	B60	\N
827	16	61	medium	1	\N	\N	\N	4	13	B61	\N
828	16	62	medium	1	\N	\N	\N	4	14	B62	\N
829	16	63	medium	1	\N	\N	\N	4	15	B63	\N
830	16	64	medium	1	\N	\N	\N	4	16	B64	\N
1247	34	65	medium	1	\N	\N	\N	5	1	65	\N
831	28	1	medium	1	\N	\N	\N	1	1	C1	\N
832	28	2	medium	1	\N	\N	\N	1	2	C2	\N
833	28	3	medium	1	\N	\N	\N	1	3	C3	\N
834	28	4	medium	1	\N	\N	\N	1	4	C4	\N
835	28	5	medium	1	\N	\N	\N	1	5	C5	\N
836	28	6	medium	1	\N	\N	\N	1	6	C6	\N
837	28	7	medium	1	\N	\N	\N	1	7	C7	\N
839	28	9	medium	1	\N	\N	\N	1	9	C9	\N
841	28	11	medium	1	\N	\N	\N	1	11	C11	\N
842	28	12	medium	1	\N	\N	\N	1	12	C12	\N
843	28	13	medium	1	\N	\N	\N	1	13	C13	\N
844	28	14	medium	1	\N	\N	\N	1	14	C14	\N
845	28	15	medium	1	\N	\N	\N	1	15	C15	\N
846	28	16	medium	1	\N	\N	\N	1	16	C16	\N
847	28	17	medium	1	\N	\N	\N	2	1	C17	\N
848	28	18	medium	1	\N	\N	\N	2	2	C18	\N
849	28	19	medium	1	\N	\N	\N	2	3	C19	\N
850	28	20	medium	1	\N	\N	\N	2	4	C20	\N
851	28	21	medium	1	\N	\N	\N	2	5	C21	\N
852	28	22	medium	1	\N	\N	\N	2	6	C22	\N
853	28	23	medium	1	\N	\N	\N	2	7	C23	\N
854	28	24	medium	1	\N	\N	\N	2	8	C24	\N
855	28	25	medium	1	\N	\N	\N	2	9	C25	\N
856	28	26	medium	1	\N	\N	\N	2	10	C26	\N
857	28	27	medium	1	\N	\N	\N	2	11	C27	\N
858	28	28	medium	1	\N	\N	\N	2	12	C28	\N
859	28	29	medium	1	\N	\N	\N	2	13	C29	\N
860	28	30	medium	1	\N	\N	\N	2	14	C30	\N
861	28	31	medium	1	\N	\N	\N	2	15	C31	\N
862	28	32	medium	1	\N	\N	\N	2	16	C32	\N
963	30	21	medium	1	\N	\N	\N	2	5	A21	\N
964	30	22	medium	1	\N	\N	\N	2	6	A22	\N
965	30	23	medium	1	\N	\N	\N	2	7	A23	\N
966	30	24	medium	1	\N	\N	\N	2	8	A24	\N
970	30	28	medium	1	\N	\N	\N	2	12	A28	\N
971	30	29	medium	1	\N	\N	\N	2	13	A29	\N
972	30	30	medium	1	\N	\N	\N	2	14	A30	\N
973	30	31	medium	1	\N	\N	\N	2	15	A31	\N
974	30	32	medium	1	\N	\N	\N	2	16	A32	\N
975	30	33	medium	1	\N	\N	\N	3	1	A33	\N
976	30	34	medium	1	\N	\N	\N	3	2	A34	\N
977	30	35	medium	1	\N	\N	\N	3	3	A35	\N
978	30	36	medium	1	\N	\N	\N	3	4	A36	\N
979	30	37	medium	1	\N	\N	\N	3	5	A37	\N
980	30	38	medium	1	\N	\N	\N	3	6	A38	\N
981	30	39	medium	1	\N	\N	\N	3	7	A39	\N
983	30	41	medium	1	\N	\N	\N	3	9	A41	\N
984	30	42	medium	1	\N	\N	\N	3	10	A42	\N
985	30	43	medium	1	\N	\N	\N	3	11	A43	\N
986	30	44	medium	1	\N	\N	\N	3	12	A44	\N
987	30	45	medium	1	\N	\N	\N	3	13	A45	\N
988	30	46	medium	1	\N	\N	\N	3	14	A46	\N
990	30	48	medium	1	\N	\N	\N	3	16	A48	\N
991	30	49	medium	1	\N	\N	\N	4	1	A49	\N
992	30	50	medium	1	\N	\N	\N	4	2	A50	\N
993	30	51	medium	1	\N	\N	\N	4	3	A51	\N
994	30	52	medium	1	\N	\N	\N	4	4	A52	\N
995	30	53	medium	1	\N	\N	\N	4	5	A53	\N
996	30	54	medium	1	\N	\N	\N	4	6	A54	\N
997	30	55	medium	1	\N	\N	\N	4	7	A55	\N
998	30	56	medium	1	\N	\N	\N	4	8	A56	\N
968	30	26	medium	3	\N	\N	\N	2	10	A26	\N
969	30	27	medium	3	\N	\N	\N	2	11	A27	\N
982	30	40	medium	3	\N	\N	\N	3	8	A40	\N
989	30	47	medium	3	\N	\N	\N	3	15	A47	\N
999	30	57	medium	3	\N	\N	\N	4	9	A57	\N
1000	30	58	medium	3	\N	\N	\N	4	10	A58	\N
1001	30	59	medium	3	\N	\N	\N	4	11	A59	\N
1002	30	60	medium	3	\N	\N	\N	4	12	A60	\N
1003	30	61	medium	3	\N	\N	\N	4	13	A61	\N
838	28	8	medium	3	\N	\N	\N	1	8	C8	\N
1248	34	66	medium	1	\N	\N	\N	5	2	66	\N
1249	34	67	medium	1	\N	\N	\N	5	3	67	\N
1250	34	68	medium	1	\N	\N	\N	5	4	68	\N
1251	34	69	medium	1	\N	\N	\N	5	5	69	\N
1252	34	70	medium	1	\N	\N	\N	5	6	70	\N
1253	34	71	medium	1	\N	\N	\N	5	7	71	\N
1254	34	72	medium	1	\N	\N	\N	5	8	72	\N
1255	34	73	medium	1	\N	\N	\N	5	9	73	\N
1256	34	74	medium	1	\N	\N	\N	5	10	74	\N
1257	34	75	medium	1	\N	\N	\N	5	11	75	\N
1258	34	76	medium	1	\N	\N	\N	5	12	76	\N
1259	34	77	medium	1	\N	\N	\N	5	13	77	\N
1260	34	78	medium	1	\N	\N	\N	5	14	78	\N
1261	34	79	medium	1	\N	\N	\N	5	15	79	\N
1262	34	80	medium	1	\N	\N	\N	5	16	80	\N
863	29	1	medium	1	\N	\N	\N	1	1	B1	\N
864	29	2	medium	1	\N	\N	\N	1	2	B2	\N
865	29	3	medium	1	\N	\N	\N	1	3	B3	\N
866	29	4	medium	1	\N	\N	\N	1	4	B4	\N
867	29	5	medium	1	\N	\N	\N	1	5	B5	\N
868	29	6	medium	1	\N	\N	\N	1	6	B6	\N
869	29	7	medium	1	\N	\N	\N	1	7	B7	\N
870	29	8	medium	1	\N	\N	\N	1	8	B8	\N
871	29	9	medium	1	\N	\N	\N	1	9	B9	\N
872	29	10	medium	1	\N	\N	\N	1	10	B10	\N
1263	34	81	medium	1	\N	\N	\N	6	1	81	\N
874	29	12	medium	1	\N	\N	\N	1	12	B12	\N
875	29	13	medium	1	\N	\N	\N	1	13	B13	\N
876	29	14	medium	1	\N	\N	\N	1	14	B14	\N
877	29	15	medium	1	\N	\N	\N	1	15	B15	\N
878	29	16	medium	1	\N	\N	\N	1	16	B16	\N
879	29	17	medium	1	\N	\N	\N	2	1	B17	\N
880	29	18	medium	1	\N	\N	\N	2	2	B18	\N
881	29	19	medium	1	\N	\N	\N	2	3	B19	\N
882	29	20	medium	1	\N	\N	\N	2	4	B20	\N
883	29	21	medium	1	\N	\N	\N	2	5	B21	\N
1264	34	82	medium	1	\N	\N	\N	6	2	82	\N
885	29	23	medium	1	\N	\N	\N	2	7	B23	\N
886	29	24	medium	1	\N	\N	\N	2	8	B24	\N
887	29	25	medium	1	\N	\N	\N	2	9	B25	\N
1265	34	83	medium	1	\N	\N	\N	6	3	83	\N
889	29	27	medium	1	\N	\N	\N	2	11	B27	\N
890	29	28	medium	1	\N	\N	\N	2	12	B28	\N
891	29	29	medium	1	\N	\N	\N	2	13	B29	\N
892	29	30	medium	1	\N	\N	\N	2	14	B30	\N
1266	34	84	medium	1	\N	\N	\N	6	4	84	\N
894	29	32	medium	1	\N	\N	\N	2	16	B32	\N
895	29	33	medium	1	\N	\N	\N	3	1	B33	\N
896	29	34	medium	1	\N	\N	\N	3	2	B34	\N
897	29	35	medium	1	\N	\N	\N	3	3	B35	\N
898	29	36	medium	1	\N	\N	\N	3	4	B36	\N
899	29	37	medium	1	\N	\N	\N	3	5	B37	\N
900	29	38	medium	1	\N	\N	\N	3	6	B38	\N
901	29	39	medium	1	\N	\N	\N	3	7	B39	\N
902	29	40	medium	1	\N	\N	\N	3	8	B40	\N
903	29	41	medium	1	\N	\N	\N	3	9	B41	\N
1267	34	85	medium	1	\N	\N	\N	6	5	85	\N
905	29	43	medium	1	\N	\N	\N	3	11	B43	\N
906	29	44	medium	1	\N	\N	\N	3	12	B44	\N
907	29	45	medium	1	\N	\N	\N	3	13	B45	\N
908	29	46	medium	1	\N	\N	\N	3	14	B46	\N
909	29	47	medium	1	\N	\N	\N	3	15	B47	\N
910	29	48	medium	1	\N	\N	\N	3	16	B48	\N
911	29	49	medium	1	\N	\N	\N	4	1	B49	\N
912	29	50	medium	1	\N	\N	\N	4	2	B50	\N
913	29	51	medium	1	\N	\N	\N	4	3	B51	\N
914	29	52	medium	1	\N	\N	\N	4	4	B52	\N
915	29	53	medium	1	\N	\N	\N	4	5	B53	\N
916	29	54	medium	1	\N	\N	\N	4	6	B54	\N
917	29	55	medium	1	\N	\N	\N	4	7	B55	\N
918	29	56	medium	1	\N	\N	\N	4	8	B56	\N
919	29	57	medium	1	\N	\N	\N	4	9	B57	\N
920	29	58	medium	1	\N	\N	\N	4	10	B58	\N
921	29	59	medium	1	\N	\N	\N	4	11	B59	\N
922	29	60	medium	1	\N	\N	\N	4	12	B60	\N
923	29	61	medium	1	\N	\N	\N	4	13	B61	\N
924	29	62	medium	1	\N	\N	\N	4	14	B62	\N
925	29	63	medium	1	\N	\N	\N	4	15	B63	\N
926	29	64	medium	1	\N	\N	\N	4	16	B64	\N
927	29	65	medium	1	\N	\N	\N	5	1	B65	\N
1268	34	86	medium	1	\N	\N	\N	6	6	86	\N
929	29	67	medium	1	\N	\N	\N	5	3	B67	\N
1269	34	87	medium	1	\N	\N	\N	6	7	87	\N
1270	34	88	medium	1	\N	\N	\N	6	8	88	\N
1271	34	89	medium	1	\N	\N	\N	6	9	89	\N
1272	34	90	medium	1	\N	\N	\N	6	10	90	\N
1273	34	91	medium	1	\N	\N	\N	6	11	91	\N
1274	34	92	medium	1	\N	\N	\N	6	12	92	\N
1275	34	93	medium	1	\N	\N	\N	6	13	93	\N
1276	34	94	medium	1	\N	\N	\N	6	14	94	\N
1277	34	95	medium	1	\N	\N	\N	6	15	95	\N
1278	34	96	medium	1	\N	\N	\N	6	16	96	\N
1336	35	58	medium	1	\N	\N	\N	4	10	A58	\N
1337	35	59	medium	1	\N	\N	\N	4	11	A59	\N
1338	35	60	medium	1	\N	\N	\N	4	12	A60	\N
1004	30	62	medium	3	\N	\N	\N	4	14	A62	\N
1005	30	63	medium	3	\N	\N	\N	4	15	A63	\N
1006	30	64	medium	3	\N	\N	\N	4	16	A64	\N
873	29	11	medium	3	\N	\N	\N	1	11	B11	\N
884	29	22	medium	3	\N	\N	\N	2	6	B22	\N
888	29	26	medium	3	\N	\N	\N	2	10	B26	\N
893	29	31	medium	3	\N	\N	\N	2	15	B31	\N
904	29	42	medium	3	\N	\N	\N	3	10	B42	\N
928	29	66	medium	3	\N	\N	\N	5	2	B66	\N
930	29	68	medium	3	\N	\N	\N	5	4	B68	\N
931	29	69	medium	1	\N	\N	\N	5	5	B69	\N
932	29	70	medium	1	\N	\N	\N	5	6	B70	\N
933	29	71	medium	1	\N	\N	\N	5	7	B71	\N
935	29	73	medium	1	\N	\N	\N	5	9	B73	\N
936	29	74	medium	1	\N	\N	\N	5	10	B74	\N
937	29	75	medium	1	\N	\N	\N	5	11	B75	\N
939	29	77	medium	1	\N	\N	\N	5	13	B77	\N
940	29	78	medium	1	\N	\N	\N	5	14	B78	\N
942	29	80	medium	1	\N	\N	\N	5	16	B80	\N
1007	31	1	medium	1	\N	\N	\N	1	1	F1	\N
1008	31	2	medium	1	\N	\N	\N	1	2	F2	\N
1009	31	3	medium	1	\N	\N	\N	1	3	F3	\N
1010	31	4	medium	1	\N	\N	\N	1	4	F4	\N
1011	31	5	medium	1	\N	\N	\N	1	5	F5	\N
1012	31	6	medium	1	\N	\N	\N	1	6	F6	\N
1013	31	7	medium	1	\N	\N	\N	1	7	F7	\N
1014	31	8	medium	1	\N	\N	\N	1	8	F8	\N
1015	31	9	medium	1	\N	\N	\N	1	9	F9	\N
1016	31	10	medium	1	\N	\N	\N	1	10	F10	\N
1017	31	11	medium	1	\N	\N	\N	1	11	F11	\N
1018	31	12	medium	1	\N	\N	\N	1	12	F12	\N
1019	31	13	medium	1	\N	\N	\N	1	13	F13	\N
1020	31	14	medium	1	\N	\N	\N	1	14	F14	\N
1021	31	15	medium	1	\N	\N	\N	1	15	F15	\N
1022	31	16	medium	1	\N	\N	\N	1	16	F16	\N
1023	31	17	medium	1	\N	\N	\N	2	1	F17	\N
1024	31	18	medium	1	\N	\N	\N	2	2	F18	\N
1025	31	19	medium	1	\N	\N	\N	2	3	F19	\N
1026	31	20	medium	1	\N	\N	\N	2	4	F20	\N
1027	31	21	medium	1	\N	\N	\N	2	5	F21	\N
1028	31	22	medium	1	\N	\N	\N	2	6	F22	\N
1029	31	23	medium	1	\N	\N	\N	2	7	F23	\N
1030	31	24	medium	1	\N	\N	\N	2	8	F24	\N
1031	31	25	medium	1	\N	\N	\N	2	9	F25	\N
1032	31	26	medium	1	\N	\N	\N	2	10	F26	\N
1033	31	27	medium	1	\N	\N	\N	2	11	F27	\N
1034	31	28	medium	1	\N	\N	\N	2	12	F28	\N
1035	31	29	medium	1	\N	\N	\N	2	13	F29	\N
1036	31	30	medium	1	\N	\N	\N	2	14	F30	\N
1037	31	31	medium	1	\N	\N	\N	2	15	F31	\N
1038	31	32	medium	1	\N	\N	\N	2	16	F32	\N
1039	31	33	medium	1	\N	\N	\N	3	1	F33	\N
1040	31	34	medium	1	\N	\N	\N	3	2	F34	\N
1041	31	35	medium	1	\N	\N	\N	3	3	F35	\N
1042	31	36	medium	1	\N	\N	\N	3	4	F36	\N
1043	31	37	medium	1	\N	\N	\N	3	5	F37	\N
1044	31	38	medium	1	\N	\N	\N	3	6	F38	\N
1045	31	39	medium	1	\N	\N	\N	3	7	F39	\N
1046	31	40	medium	1	\N	\N	\N	3	8	F40	\N
1047	31	41	medium	1	\N	\N	\N	3	9	F41	\N
1048	31	42	medium	1	\N	\N	\N	3	10	F42	\N
1049	31	43	medium	1	\N	\N	\N	3	11	F43	\N
1050	31	44	medium	1	\N	\N	\N	3	12	F44	\N
1051	31	45	medium	1	\N	\N	\N	3	13	F45	\N
1052	31	46	medium	1	\N	\N	\N	3	14	F46	\N
1053	31	47	medium	1	\N	\N	\N	3	15	F47	\N
1054	31	48	medium	1	\N	\N	\N	3	16	F48	\N
967	30	25	medium	3	\N	\N	\N	2	9	A25	\N
934	29	72	medium	3	\N	\N	\N	5	8	B72	\N
938	29	76	medium	3	\N	\N	\N	5	12	B76	\N
941	29	79	medium	3	\N	\N	\N	5	15	B79	\N
840	28	10	medium	3	\N	\N	\N	1	10	C10	\N
1055	32	1	medium	1	\N	\N	\N	1	1	A1	\N
1056	32	2	medium	1	\N	\N	\N	1	2	A2	\N
1057	32	3	medium	1	\N	\N	\N	1	3	A3	\N
1058	32	4	medium	1	\N	\N	\N	1	4	A4	\N
1059	32	5	medium	1	\N	\N	\N	1	5	A5	\N
1060	32	6	medium	1	\N	\N	\N	1	6	A6	\N
1061	32	7	medium	1	\N	\N	\N	1	7	A7	\N
1062	32	8	medium	1	\N	\N	\N	1	8	A8	\N
1063	32	9	medium	1	\N	\N	\N	1	9	A9	\N
1065	32	11	medium	1	\N	\N	\N	1	11	A11	\N
1066	32	12	medium	1	\N	\N	\N	1	12	A12	\N
1067	32	13	medium	1	\N	\N	\N	1	13	A13	\N
1068	32	14	medium	1	\N	\N	\N	1	14	A14	\N
1069	32	15	medium	1	\N	\N	\N	1	15	A15	\N
1070	32	16	medium	1	\N	\N	\N	1	16	A16	\N
1071	32	17	medium	1	\N	\N	\N	2	1	A17	\N
1072	32	18	medium	1	\N	\N	\N	2	2	A18	\N
1073	32	19	medium	1	\N	\N	\N	2	3	A19	\N
1074	32	20	medium	1	\N	\N	\N	2	4	A20	\N
1075	32	21	medium	1	\N	\N	\N	2	5	A21	\N
1076	32	22	medium	1	\N	\N	\N	2	6	A22	\N
1077	32	23	medium	1	\N	\N	\N	2	7	A23	\N
1078	32	24	medium	1	\N	\N	\N	2	8	A24	\N
1079	32	25	medium	1	\N	\N	\N	2	9	A25	\N
1080	32	26	medium	1	\N	\N	\N	2	10	A26	\N
1081	32	27	medium	1	\N	\N	\N	2	11	A27	\N
1082	32	28	medium	1	\N	\N	\N	2	12	A28	\N
1083	32	29	medium	1	\N	\N	\N	2	13	A29	\N
1084	32	30	medium	1	\N	\N	\N	2	14	A30	\N
1085	32	31	medium	1	\N	\N	\N	2	15	A31	\N
1086	32	32	medium	1	\N	\N	\N	2	16	A32	\N
1087	32	33	medium	1	\N	\N	\N	3	1	A33	\N
1088	32	34	medium	1	\N	\N	\N	3	2	A34	\N
1089	32	35	medium	1	\N	\N	\N	3	3	A35	\N
1090	32	36	medium	1	\N	\N	\N	3	4	A36	\N
1091	32	37	medium	1	\N	\N	\N	3	5	A37	\N
1092	32	38	medium	1	\N	\N	\N	3	6	A38	\N
1093	32	39	medium	1	\N	\N	\N	3	7	A39	\N
1094	32	40	medium	1	\N	\N	\N	3	8	A40	\N
1095	32	41	medium	1	\N	\N	\N	3	9	A41	\N
1096	32	42	medium	1	\N	\N	\N	3	10	A42	\N
1097	32	43	medium	1	\N	\N	\N	3	11	A43	\N
1098	32	44	medium	1	\N	\N	\N	3	12	A44	\N
1099	32	45	medium	1	\N	\N	\N	3	13	A45	\N
1100	32	46	medium	1	\N	\N	\N	3	14	A46	\N
1101	32	47	medium	1	\N	\N	\N	3	15	A47	\N
1102	32	48	medium	1	\N	\N	\N	3	16	A48	\N
1103	32	49	medium	1	\N	\N	\N	4	1	A49	\N
1104	32	50	medium	1	\N	\N	\N	4	2	A50	\N
1105	32	51	medium	1	\N	\N	\N	4	3	A51	\N
1106	32	52	medium	1	\N	\N	\N	4	4	A52	\N
1107	32	53	medium	1	\N	\N	\N	4	5	A53	\N
1108	32	54	medium	1	\N	\N	\N	4	6	A54	\N
1109	32	55	medium	1	\N	\N	\N	4	7	A55	\N
1110	32	56	medium	1	\N	\N	\N	4	8	A56	\N
1111	32	57	medium	1	\N	\N	\N	4	9	A57	\N
1112	32	58	medium	1	\N	\N	\N	4	10	A58	\N
1113	32	59	medium	1	\N	\N	\N	4	11	A59	\N
1323	35	45	medium	1	\N	\N	\N	3	13	A45	\N
1115	32	61	medium	1	\N	\N	\N	4	13	A61	\N
1116	32	62	medium	1	\N	\N	\N	4	14	A62	\N
1117	32	63	medium	1	\N	\N	\N	4	15	A63	\N
1118	32	64	medium	1	\N	\N	\N	4	16	A64	\N
1064	32	10	medium	3	\N	\N	\N	1	10	A10	\N
1114	32	60	medium	3	\N	\N	\N	4	12	A60	\N
1279	35	1	medium	1	\N	\N	\N	1	1	A1	\N
1280	35	2	medium	1	\N	\N	\N	1	2	A2	\N
1281	35	3	medium	1	\N	\N	\N	1	3	A3	\N
1282	35	4	medium	1	\N	\N	\N	1	4	A4	\N
1283	35	5	medium	1	\N	\N	\N	1	5	A5	\N
1284	35	6	medium	1	\N	\N	\N	1	6	A6	\N
1285	35	7	medium	1	\N	\N	\N	1	7	A7	\N
1286	35	8	medium	1	\N	\N	\N	1	8	A8	\N
1287	35	9	medium	1	\N	\N	\N	1	9	A9	\N
1288	35	10	medium	1	\N	\N	\N	1	10	A10	\N
1289	35	11	medium	1	\N	\N	\N	1	11	A11	\N
1290	35	12	medium	1	\N	\N	\N	1	12	A12	\N
1291	35	13	medium	1	\N	\N	\N	1	13	A13	\N
1292	35	14	medium	1	\N	\N	\N	1	14	A14	\N
1293	35	15	medium	1	\N	\N	\N	1	15	A15	\N
1294	35	16	medium	1	\N	\N	\N	1	16	A16	\N
1295	35	17	medium	1	\N	\N	\N	2	1	A17	\N
1296	35	18	medium	1	\N	\N	\N	2	2	A18	\N
1297	35	19	medium	1	\N	\N	\N	2	3	A19	\N
1298	35	20	medium	1	\N	\N	\N	2	4	A20	\N
1324	35	46	medium	1	\N	\N	\N	3	14	A46	\N
1119	33	1	medium	1	\N	\N	\N	1	1	B1	\N
1120	33	2	medium	1	\N	\N	\N	1	2	B2	\N
1121	33	3	medium	1	\N	\N	\N	1	3	B3	\N
1123	33	5	medium	1	\N	\N	\N	1	5	B5	\N
1124	33	6	medium	1	\N	\N	\N	1	6	B6	\N
1125	33	7	medium	1	\N	\N	\N	1	7	B7	\N
1127	33	9	medium	1	\N	\N	\N	1	9	B9	\N
1128	33	10	medium	1	\N	\N	\N	1	10	B10	\N
1129	33	11	medium	1	\N	\N	\N	1	11	B11	\N
1130	33	12	medium	1	\N	\N	\N	1	12	B12	\N
1131	33	13	medium	1	\N	\N	\N	1	13	B13	\N
1132	33	14	medium	1	\N	\N	\N	1	14	B14	\N
1133	33	15	medium	1	\N	\N	\N	1	15	B15	\N
1134	33	16	medium	1	\N	\N	\N	1	16	B16	\N
1135	33	17	medium	1	\N	\N	\N	2	1	B17	\N
1136	33	18	medium	1	\N	\N	\N	2	2	B18	\N
1137	33	19	medium	1	\N	\N	\N	2	3	B19	\N
1138	33	20	medium	1	\N	\N	\N	2	4	B20	\N
1139	33	21	medium	1	\N	\N	\N	2	5	B21	\N
1140	33	22	medium	1	\N	\N	\N	2	6	B22	\N
1141	33	23	medium	1	\N	\N	\N	2	7	B23	\N
1143	33	25	medium	1	\N	\N	\N	2	9	B25	\N
1145	33	27	medium	1	\N	\N	\N	2	11	B27	\N
1146	33	28	medium	1	\N	\N	\N	2	12	B28	\N
1147	33	29	medium	1	\N	\N	\N	2	13	B29	\N
1148	33	30	medium	1	\N	\N	\N	2	14	B30	\N
1149	33	31	medium	1	\N	\N	\N	2	15	B31	\N
1150	33	32	medium	1	\N	\N	\N	2	16	B32	\N
1151	33	33	medium	1	\N	\N	\N	3	1	B33	\N
1152	33	34	medium	1	\N	\N	\N	3	2	B34	\N
1153	33	35	medium	1	\N	\N	\N	3	3	B35	\N
1154	33	36	medium	1	\N	\N	\N	3	4	B36	\N
1156	33	38	medium	1	\N	\N	\N	3	6	B38	\N
1157	33	39	medium	1	\N	\N	\N	3	7	B39	\N
1158	33	40	medium	1	\N	\N	\N	3	8	B40	\N
1159	33	41	medium	1	\N	\N	\N	3	9	B41	\N
1160	33	42	medium	1	\N	\N	\N	3	10	B42	\N
1161	33	43	medium	1	\N	\N	\N	3	11	B43	\N
1162	33	44	medium	1	\N	\N	\N	3	12	B44	\N
1164	33	46	medium	1	\N	\N	\N	3	14	B46	\N
1165	33	47	medium	1	\N	\N	\N	3	15	B47	\N
1166	33	48	medium	1	\N	\N	\N	3	16	B48	\N
1167	33	49	medium	1	\N	\N	\N	4	1	B49	\N
1168	33	50	medium	1	\N	\N	\N	4	2	B50	\N
1169	33	51	medium	1	\N	\N	\N	4	3	B51	\N
1170	33	52	medium	1	\N	\N	\N	4	4	B52	\N
1171	33	53	medium	1	\N	\N	\N	4	5	B53	\N
1172	33	54	medium	1	\N	\N	\N	4	6	B54	\N
1173	33	55	medium	1	\N	\N	\N	4	7	B55	\N
1174	33	56	medium	1	\N	\N	\N	4	8	B56	\N
1175	33	57	medium	1	\N	\N	\N	4	9	B57	\N
1177	33	59	medium	1	\N	\N	\N	4	11	B59	\N
1178	33	60	medium	1	\N	\N	\N	4	12	B60	\N
1179	33	61	medium	1	\N	\N	\N	4	13	B61	\N
1180	33	62	medium	1	\N	\N	\N	4	14	B62	\N
1181	33	63	medium	1	\N	\N	\N	4	15	B63	\N
1182	33	64	medium	1	\N	\N	\N	4	16	B64	\N
1122	33	4	medium	3	\N	\N	\N	1	4	B4	\N
1126	33	8	medium	3	\N	\N	\N	1	8	B8	\N
1142	33	24	medium	3	\N	\N	\N	2	8	B24	\N
1144	33	26	medium	3	\N	\N	\N	2	10	B26	\N
1155	33	37	medium	3	\N	\N	\N	3	5	B37	\N
1163	33	45	medium	3	\N	\N	\N	3	13	B45	\N
1176	33	58	medium	3	\N	\N	\N	4	10	B58	\N
1299	35	21	medium	1	\N	\N	\N	2	5	A21	\N
1300	35	22	medium	1	\N	\N	\N	2	6	A22	\N
1301	35	23	medium	1	\N	\N	\N	2	7	A23	\N
1302	35	24	medium	1	\N	\N	\N	2	8	A24	\N
1303	35	25	medium	1	\N	\N	\N	2	9	A25	\N
1304	35	26	medium	1	\N	\N	\N	2	10	A26	\N
1305	35	27	medium	1	\N	\N	\N	2	11	A27	\N
1306	35	28	medium	1	\N	\N	\N	2	12	A28	\N
1307	35	29	medium	1	\N	\N	\N	2	13	A29	\N
1308	35	30	medium	1	\N	\N	\N	2	14	A30	\N
1309	35	31	medium	1	\N	\N	\N	2	15	A31	\N
1310	35	32	medium	1	\N	\N	\N	2	16	A32	\N
1311	35	33	medium	1	\N	\N	\N	3	1	A33	\N
1312	35	34	medium	1	\N	\N	\N	3	2	A34	\N
1313	35	35	medium	1	\N	\N	\N	3	3	A35	\N
1314	35	36	medium	1	\N	\N	\N	3	4	A36	\N
1315	35	37	medium	1	\N	\N	\N	3	5	A37	\N
1316	35	38	medium	1	\N	\N	\N	3	6	A38	\N
1317	35	39	medium	1	\N	\N	\N	3	7	A39	\N
1318	35	40	medium	1	\N	\N	\N	3	8	A40	\N
1319	35	41	medium	1	\N	\N	\N	3	9	A41	\N
1320	35	42	medium	1	\N	\N	\N	3	10	A42	\N
1321	35	43	medium	1	\N	\N	\N	3	11	A43	\N
1322	35	44	medium	1	\N	\N	\N	3	12	A44	\N
1325	35	47	medium	1	\N	\N	\N	3	15	A47	\N
1326	35	48	medium	1	\N	\N	\N	3	16	A48	\N
1327	35	49	medium	1	\N	\N	\N	4	1	A49	\N
1328	35	50	medium	1	\N	\N	\N	4	2	A50	\N
1329	35	51	medium	1	\N	\N	\N	4	3	A51	\N
1330	35	52	medium	1	\N	\N	\N	4	4	A52	\N
1331	35	53	medium	1	\N	\N	\N	4	5	A53	\N
1332	35	54	medium	1	\N	\N	\N	4	6	A54	\N
1333	35	55	medium	1	\N	\N	\N	4	7	A55	\N
1334	35	56	medium	1	\N	\N	\N	4	8	A56	\N
1335	35	57	medium	1	\N	\N	\N	4	9	A57	\N
1339	35	61	medium	1	\N	\N	\N	4	13	A61	\N
1340	35	62	medium	1	\N	\N	\N	4	14	A62	\N
1341	35	63	medium	1	\N	\N	\N	4	15	A63	\N
1342	35	64	medium	1	\N	\N	\N	4	16	A64	\N
1343	36	1	medium	1	\N	\N	\N	1	1	B1	\N
1344	36	2	medium	1	\N	\N	\N	1	2	B2	\N
1345	36	3	medium	1	\N	\N	\N	1	3	B3	\N
1346	36	4	medium	1	\N	\N	\N	1	4	B4	\N
1347	36	5	medium	1	\N	\N	\N	1	5	B5	\N
1348	36	6	medium	1	\N	\N	\N	1	6	B6	\N
1349	36	7	medium	1	\N	\N	\N	1	7	B7	\N
1350	36	8	medium	1	\N	\N	\N	1	8	B8	\N
1351	36	9	medium	1	\N	\N	\N	1	9	B9	\N
1352	36	10	medium	1	\N	\N	\N	1	10	B10	\N
1353	36	11	medium	1	\N	\N	\N	1	11	B11	\N
1354	36	12	medium	1	\N	\N	\N	1	12	B12	\N
1355	36	13	medium	1	\N	\N	\N	1	13	B13	\N
1356	36	14	medium	1	\N	\N	\N	1	14	B14	\N
1357	36	15	medium	1	\N	\N	\N	1	15	B15	\N
1358	36	16	medium	1	\N	\N	\N	1	16	B16	\N
1359	36	17	medium	1	\N	\N	\N	2	1	B17	\N
1360	36	18	medium	1	\N	\N	\N	2	2	B18	\N
1361	36	19	medium	1	\N	\N	\N	2	3	B19	\N
1362	36	20	medium	1	\N	\N	\N	2	4	B20	\N
1363	36	21	medium	1	\N	\N	\N	2	5	B21	\N
1364	36	22	medium	1	\N	\N	\N	2	6	B22	\N
1365	36	23	medium	1	\N	\N	\N	2	7	B23	\N
1366	36	24	medium	1	\N	\N	\N	2	8	B24	\N
1367	36	25	medium	1	\N	\N	\N	2	9	B25	\N
1368	36	26	medium	1	\N	\N	\N	2	10	B26	\N
1369	36	27	medium	1	\N	\N	\N	2	11	B27	\N
1370	36	28	medium	1	\N	\N	\N	2	12	B28	\N
1371	36	29	medium	1	\N	\N	\N	2	13	B29	\N
1372	36	30	medium	1	\N	\N	\N	2	14	B30	\N
1373	36	31	medium	1	\N	\N	\N	2	15	B31	\N
1374	36	32	medium	1	\N	\N	\N	2	16	B32	\N
1375	36	33	medium	1	\N	\N	\N	3	1	B33	\N
1376	36	34	medium	1	\N	\N	\N	3	2	B34	\N
1377	36	35	medium	1	\N	\N	\N	3	3	B35	\N
1378	36	36	medium	1	\N	\N	\N	3	4	B36	\N
1379	36	37	medium	1	\N	\N	\N	3	5	B37	\N
1380	36	38	medium	1	\N	\N	\N	3	6	B38	\N
1381	36	39	medium	1	\N	\N	\N	3	7	B39	\N
1382	36	40	medium	1	\N	\N	\N	3	8	B40	\N
1383	36	41	medium	1	\N	\N	\N	3	9	B41	\N
1384	36	42	medium	1	\N	\N	\N	3	10	B42	\N
1385	36	43	medium	1	\N	\N	\N	3	11	B43	\N
1386	36	44	medium	1	\N	\N	\N	3	12	B44	\N
1387	36	45	medium	1	\N	\N	\N	3	13	B45	\N
1388	36	46	medium	1	\N	\N	\N	3	14	B46	\N
1389	36	47	medium	1	\N	\N	\N	3	15	B47	\N
1390	36	48	medium	1	\N	\N	\N	3	16	B48	\N
1391	36	49	medium	1	\N	\N	\N	4	1	B49	\N
1392	36	50	medium	1	\N	\N	\N	4	2	B50	\N
1393	36	51	medium	1	\N	\N	\N	4	3	B51	\N
1394	36	52	medium	1	\N	\N	\N	4	4	B52	\N
1395	36	53	medium	1	\N	\N	\N	4	5	B53	\N
1396	36	54	medium	1	\N	\N	\N	4	6	B54	\N
1397	36	55	medium	1	\N	\N	\N	4	7	B55	\N
1398	36	56	medium	1	\N	\N	\N	4	8	B56	\N
1399	36	57	medium	1	\N	\N	\N	4	9	B57	\N
1400	36	58	medium	1	\N	\N	\N	4	10	B58	\N
1401	36	59	medium	1	\N	\N	\N	4	11	B59	\N
1402	36	60	medium	1	\N	\N	\N	4	12	B60	\N
1403	36	61	medium	1	\N	\N	\N	4	13	B61	\N
1404	36	62	medium	1	\N	\N	\N	4	14	B62	\N
1405	36	63	medium	1	\N	\N	\N	4	15	B63	\N
1406	36	64	medium	1	\N	\N	\N	4	16	B64	\N
1407	37	1	medium	1	\N	\N	\N	1	1	1	\N
1408	37	2	medium	1	\N	\N	\N	1	2	2	\N
1409	37	3	medium	1	\N	\N	\N	1	3	3	\N
1410	37	4	medium	1	\N	\N	\N	1	4	4	\N
1411	37	5	medium	1	\N	\N	\N	1	5	5	\N
1412	37	6	medium	1	\N	\N	\N	1	6	6	\N
1413	37	7	medium	1	\N	\N	\N	1	7	7	\N
1414	37	8	medium	1	\N	\N	\N	1	8	8	\N
1415	37	9	medium	1	\N	\N	\N	1	9	9	\N
1416	37	10	medium	1	\N	\N	\N	1	10	10	\N
1417	37	11	medium	1	\N	\N	\N	1	11	11	\N
1418	37	12	medium	1	\N	\N	\N	1	12	12	\N
1419	37	13	medium	1	\N	\N	\N	1	13	13	\N
1420	37	14	medium	1	\N	\N	\N	1	14	14	\N
1421	37	15	medium	1	\N	\N	\N	1	15	15	\N
1422	37	16	medium	1	\N	\N	\N	1	16	16	\N
1423	37	17	medium	1	\N	\N	\N	2	1	17	\N
1424	37	18	medium	1	\N	\N	\N	2	2	18	\N
1425	37	19	medium	1	\N	\N	\N	2	3	19	\N
1426	37	20	medium	1	\N	\N	\N	2	4	20	\N
1427	37	21	medium	1	\N	\N	\N	2	5	21	\N
1428	37	22	medium	1	\N	\N	\N	2	6	22	\N
1429	37	23	medium	1	\N	\N	\N	2	7	23	\N
1430	37	24	medium	1	\N	\N	\N	2	8	24	\N
1431	37	25	medium	1	\N	\N	\N	2	9	25	\N
1432	37	26	medium	1	\N	\N	\N	2	10	26	\N
1433	37	27	medium	1	\N	\N	\N	2	11	27	\N
1434	37	28	medium	1	\N	\N	\N	2	12	28	\N
1435	37	29	medium	1	\N	\N	\N	2	13	29	\N
1436	37	30	medium	1	\N	\N	\N	2	14	30	\N
1437	37	31	medium	1	\N	\N	\N	2	15	31	\N
1438	37	32	medium	1	\N	\N	\N	2	16	32	\N
1439	37	33	medium	1	\N	\N	\N	3	1	33	\N
1440	37	34	medium	1	\N	\N	\N	3	2	34	\N
1441	37	35	medium	1	\N	\N	\N	3	3	35	\N
1442	37	36	medium	1	\N	\N	\N	3	4	36	\N
1443	37	37	medium	1	\N	\N	\N	3	5	37	\N
1444	37	38	medium	1	\N	\N	\N	3	6	38	\N
1445	37	39	medium	1	\N	\N	\N	3	7	39	\N
1446	37	40	medium	1	\N	\N	\N	3	8	40	\N
1447	37	41	medium	1	\N	\N	\N	3	9	41	\N
1448	37	42	medium	1	\N	\N	\N	3	10	42	\N
1449	37	43	medium	1	\N	\N	\N	3	11	43	\N
1450	37	44	medium	1	\N	\N	\N	3	12	44	\N
1451	37	45	medium	1	\N	\N	\N	3	13	45	\N
1452	37	46	medium	1	\N	\N	\N	3	14	46	\N
1453	37	47	medium	1	\N	\N	\N	3	15	47	\N
1454	37	48	medium	1	\N	\N	\N	3	16	48	\N
1455	37	49	medium	1	\N	\N	\N	4	1	49	\N
1456	37	50	medium	1	\N	\N	\N	4	2	50	\N
1457	37	51	medium	1	\N	\N	\N	4	3	51	\N
1458	37	52	medium	1	\N	\N	\N	4	4	52	\N
1459	37	53	medium	1	\N	\N	\N	4	5	53	\N
1460	37	54	medium	1	\N	\N	\N	4	6	54	\N
1461	37	55	medium	1	\N	\N	\N	4	7	55	\N
1462	37	56	medium	1	\N	\N	\N	4	8	56	\N
1463	37	57	medium	1	\N	\N	\N	4	9	57	\N
1464	37	58	medium	1	\N	\N	\N	4	10	58	\N
1465	37	59	medium	1	\N	\N	\N	4	11	59	\N
1466	37	60	medium	1	\N	\N	\N	4	12	60	\N
1467	37	61	medium	1	\N	\N	\N	4	13	61	\N
1468	37	62	medium	1	\N	\N	\N	4	14	62	\N
1469	37	63	medium	1	\N	\N	\N	4	15	63	\N
1470	37	64	medium	1	\N	\N	\N	4	16	64	\N
1471	38	1	medium	1	\N	\N	\N	1	1	1	\N
1472	38	2	medium	1	\N	\N	\N	1	2	2	\N
1473	38	3	medium	1	\N	\N	\N	1	3	3	\N
1474	38	4	medium	1	\N	\N	\N	1	4	4	\N
1475	38	5	medium	1	\N	\N	\N	1	5	5	\N
1476	38	6	medium	1	\N	\N	\N	1	6	6	\N
1477	38	7	medium	1	\N	\N	\N	1	7	7	\N
1478	38	8	medium	1	\N	\N	\N	1	8	8	\N
1479	38	9	medium	1	\N	\N	\N	1	9	9	\N
1480	38	10	medium	1	\N	\N	\N	1	10	10	\N
1481	38	11	medium	1	\N	\N	\N	1	11	11	\N
1482	38	12	medium	1	\N	\N	\N	1	12	12	\N
1483	38	13	medium	1	\N	\N	\N	1	13	13	\N
1484	38	14	medium	1	\N	\N	\N	1	14	14	\N
1485	38	15	medium	1	\N	\N	\N	1	15	15	\N
1486	38	16	medium	1	\N	\N	\N	1	16	16	\N
1487	38	17	medium	1	\N	\N	\N	2	1	17	\N
1488	38	18	medium	1	\N	\N	\N	2	2	18	\N
1489	38	19	medium	1	\N	\N	\N	2	3	19	\N
1490	38	20	medium	1	\N	\N	\N	2	4	20	\N
1491	38	21	medium	1	\N	\N	\N	2	5	21	\N
1492	38	22	medium	1	\N	\N	\N	2	6	22	\N
1493	38	23	medium	1	\N	\N	\N	2	7	23	\N
1494	38	24	medium	1	\N	\N	\N	2	8	24	\N
1495	38	25	medium	1	\N	\N	\N	2	9	25	\N
1496	38	26	medium	1	\N	\N	\N	2	10	26	\N
1497	38	27	medium	1	\N	\N	\N	2	11	27	\N
1498	38	28	medium	1	\N	\N	\N	2	12	28	\N
1499	38	29	medium	1	\N	\N	\N	2	13	29	\N
1500	38	30	medium	1	\N	\N	\N	2	14	30	\N
1501	38	31	medium	1	\N	\N	\N	2	15	31	\N
1502	38	32	medium	1	\N	\N	\N	2	16	32	\N
1503	38	33	medium	1	\N	\N	\N	3	1	33	\N
1504	38	34	medium	1	\N	\N	\N	3	2	34	\N
1505	38	35	medium	1	\N	\N	\N	3	3	35	\N
1506	38	36	medium	1	\N	\N	\N	3	4	36	\N
1507	38	37	medium	1	\N	\N	\N	3	5	37	\N
1508	38	38	medium	1	\N	\N	\N	3	6	38	\N
1509	38	39	medium	1	\N	\N	\N	3	7	39	\N
1510	38	40	medium	1	\N	\N	\N	3	8	40	\N
1511	38	41	medium	1	\N	\N	\N	3	9	41	\N
1512	38	42	medium	1	\N	\N	\N	3	10	42	\N
1513	38	43	medium	1	\N	\N	\N	3	11	43	\N
1514	38	44	medium	1	\N	\N	\N	3	12	44	\N
1515	38	45	medium	1	\N	\N	\N	3	13	45	\N
1516	38	46	medium	1	\N	\N	\N	3	14	46	\N
1517	38	47	medium	1	\N	\N	\N	3	15	47	\N
1518	38	48	medium	1	\N	\N	\N	3	16	48	\N
1519	38	49	medium	1	\N	\N	\N	4	1	49	\N
1520	38	50	medium	1	\N	\N	\N	4	2	50	\N
1521	38	51	medium	1	\N	\N	\N	4	3	51	\N
1522	38	52	medium	1	\N	\N	\N	4	4	52	\N
1523	38	53	medium	1	\N	\N	\N	4	5	53	\N
1524	38	54	medium	1	\N	\N	\N	4	6	54	\N
1525	38	55	medium	1	\N	\N	\N	4	7	55	\N
1526	38	56	medium	1	\N	\N	\N	4	8	56	\N
1527	38	57	medium	1	\N	\N	\N	4	9	57	\N
1528	38	58	medium	1	\N	\N	\N	4	10	58	\N
1529	38	59	medium	1	\N	\N	\N	4	11	59	\N
1530	38	60	medium	1	\N	\N	\N	4	12	60	\N
1531	38	61	medium	1	\N	\N	\N	4	13	61	\N
1532	38	62	medium	1	\N	\N	\N	4	14	62	\N
1533	38	63	medium	1	\N	\N	\N	4	15	63	\N
1534	38	64	medium	1	\N	\N	\N	4	16	64	\N
1535	38	65	medium	1	\N	\N	\N	5	1	65	\N
1536	38	66	medium	1	\N	\N	\N	5	2	66	\N
1537	38	67	medium	1	\N	\N	\N	5	3	67	\N
1538	38	68	medium	1	\N	\N	\N	5	4	68	\N
1539	38	69	medium	1	\N	\N	\N	5	5	69	\N
1540	38	70	medium	1	\N	\N	\N	5	6	70	\N
1541	38	71	medium	1	\N	\N	\N	5	7	71	\N
1542	38	72	medium	1	\N	\N	\N	5	8	72	\N
1543	38	73	medium	1	\N	\N	\N	5	9	73	\N
1544	38	74	medium	1	\N	\N	\N	5	10	74	\N
1545	38	75	medium	1	\N	\N	\N	5	11	75	\N
1546	38	76	medium	1	\N	\N	\N	5	12	76	\N
1547	38	77	medium	1	\N	\N	\N	5	13	77	\N
1548	38	78	medium	1	\N	\N	\N	5	14	78	\N
1549	38	79	medium	1	\N	\N	\N	5	15	79	\N
1550	38	80	medium	1	\N	\N	\N	5	16	80	\N
509	16	15	medium	1	\N	\N	\N	1	15	B15	\N
520	16	26	medium	1	\N	\N	\N	2	10	B26	\N
1551	39	1	medium	1	\N	\N	\N	1	1	B1	\N
1552	39	2	medium	1	\N	\N	\N	1	2	B2	\N
1553	39	3	medium	1	\N	\N	\N	1	3	B3	\N
1554	39	4	medium	1	\N	\N	\N	1	4	B4	\N
1555	39	5	medium	1	\N	\N	\N	1	5	B5	\N
1556	39	6	medium	1	\N	\N	\N	1	6	B6	\N
1557	39	7	medium	1	\N	\N	\N	1	7	B7	\N
1558	39	8	medium	1	\N	\N	\N	1	8	B8	\N
1559	39	9	medium	1	\N	\N	\N	1	9	B9	\N
1560	39	10	medium	1	\N	\N	\N	1	10	B10	\N
1561	39	11	medium	1	\N	\N	\N	1	11	B11	\N
1562	39	12	medium	1	\N	\N	\N	1	12	B12	\N
1563	39	13	medium	1	\N	\N	\N	1	13	B13	\N
1564	39	14	medium	1	\N	\N	\N	1	14	B14	\N
1565	39	15	medium	1	\N	\N	\N	1	15	B15	\N
1566	39	16	medium	1	\N	\N	\N	1	16	B16	\N
1567	39	17	medium	1	\N	\N	\N	2	1	B17	\N
1568	39	18	medium	1	\N	\N	\N	2	2	B18	\N
1569	39	19	medium	1	\N	\N	\N	2	3	B19	\N
1570	39	20	medium	1	\N	\N	\N	2	4	B20	\N
1571	39	21	medium	1	\N	\N	\N	2	5	B21	\N
1572	39	22	medium	1	\N	\N	\N	2	6	B22	\N
1573	39	23	medium	1	\N	\N	\N	2	7	B23	\N
1574	39	24	medium	1	\N	\N	\N	2	8	B24	\N
1575	39	25	medium	1	\N	\N	\N	2	9	B25	\N
1576	39	26	medium	1	\N	\N	\N	2	10	B26	\N
1577	39	27	medium	1	\N	\N	\N	2	11	B27	\N
1578	39	28	medium	1	\N	\N	\N	2	12	B28	\N
1579	39	29	medium	1	\N	\N	\N	2	13	B29	\N
1580	39	30	medium	1	\N	\N	\N	2	14	B30	\N
1581	39	31	medium	1	\N	\N	\N	2	15	B31	\N
1582	39	32	medium	1	\N	\N	\N	2	16	B32	\N
1583	39	33	medium	1	\N	\N	\N	3	1	B33	\N
1584	39	34	medium	1	\N	\N	\N	3	2	B34	\N
1585	39	35	medium	1	\N	\N	\N	3	3	B35	\N
1586	39	36	medium	1	\N	\N	\N	3	4	B36	\N
1587	39	37	medium	1	\N	\N	\N	3	5	B37	\N
1588	39	38	medium	1	\N	\N	\N	3	6	B38	\N
1589	39	39	medium	1	\N	\N	\N	3	7	B39	\N
1590	39	40	medium	1	\N	\N	\N	3	8	B40	\N
1591	39	41	medium	1	\N	\N	\N	3	9	B41	\N
1592	39	42	medium	1	\N	\N	\N	3	10	B42	\N
1593	39	43	medium	1	\N	\N	\N	3	11	B43	\N
1594	39	44	medium	1	\N	\N	\N	3	12	B44	\N
1595	39	45	medium	1	\N	\N	\N	3	13	B45	\N
1596	39	46	medium	1	\N	\N	\N	3	14	B46	\N
1597	39	47	medium	1	\N	\N	\N	3	15	B47	\N
1598	39	48	medium	1	\N	\N	\N	3	16	B48	\N
1599	39	49	medium	1	\N	\N	\N	4	1	B49	\N
1600	39	50	medium	1	\N	\N	\N	4	2	B50	\N
1601	39	51	medium	1	\N	\N	\N	4	3	B51	\N
1602	39	52	medium	1	\N	\N	\N	4	4	B52	\N
1603	39	53	medium	1	\N	\N	\N	4	5	B53	\N
1604	39	54	medium	1	\N	\N	\N	4	6	B54	\N
1605	39	55	medium	1	\N	\N	\N	4	7	B55	\N
1606	39	56	medium	1	\N	\N	\N	4	8	B56	\N
1607	39	57	medium	1	\N	\N	\N	4	9	B57	\N
1608	39	58	medium	1	\N	\N	\N	4	10	B58	\N
1609	39	59	medium	1	\N	\N	\N	4	11	B59	\N
1610	39	60	medium	1	\N	\N	\N	4	12	B60	\N
1611	39	61	medium	1	\N	\N	\N	4	13	B61	\N
1612	39	62	medium	1	\N	\N	\N	4	14	B62	\N
1613	39	63	medium	1	\N	\N	\N	4	15	B63	\N
1614	39	64	medium	1	\N	\N	\N	4	16	B64	\N
799	16	33	medium	1	\N	\N	\N	3	1	B33	\N
29	2	17	M	1	1	1	5	2	1	\N	2026-06-26 05:33:44
30	2	18	M	1	1	1	6	2	2	\N	2026-06-26 05:33:44
31	2	19	M	1	1	1	7	2	3	\N	2026-06-26 05:33:44
32	2	20	M	1	1	1	8	2	4	\N	2026-06-26 05:33:44
33	2	21	M	1	1	1	9	2	5	\N	2026-06-26 05:33:44
34	2	22	M	1	1	1	10	2	6	\N	2026-06-26 05:33:44
35	2	23	M	1	1	1	11	2	7	\N	2026-06-26 05:33:44
36	2	24	M	1	1	1	12	2	8	\N	2026-06-26 05:33:44
85	5	17	M	1	CAB002	4	17	2	1	\N	2026-06-26 05:33:44
86	5	18	M	1	CAB002	4	18	2	2	\N	2026-06-26 05:33:44
87	5	19	M	1	CAB002	4	19	2	3	\N	2026-06-26 05:33:44
88	5	20	M	1	CAB002	4	20	2	4	\N	2026-06-26 05:33:44
89	5	21	M	1	CAB002	4	21	2	5	\N	2026-06-26 05:33:44
90	5	22	M	1	CAB002	4	22	2	6	\N	2026-06-26 05:33:44
91	5	23	M	1	CAB002	4	23	2	7	\N	2026-06-26 05:33:44
92	5	24	M	1	CAB002	4	24	2	8	\N	2026-06-26 05:33:44
53	2	41	M	1	1	2	29	3	9	\N	2026-06-26 05:33:44
54	2	42	M	1	1	2	30	3	10	\N	2026-06-26 05:33:44
55	2	43	M	1	1	2	31	3	11	\N	2026-06-26 05:33:44
56	2	44	M	1	1	2	32	3	12	\N	2026-06-26 05:33:44
1216	34	34	medium	1	\N	\N	\N	3	2	34	\N
1217	34	35	medium	1	\N	\N	\N	3	3	35	\N
1218	34	36	medium	1	\N	\N	\N	3	4	36	\N
1219	34	37	medium	1	\N	\N	\N	3	5	37	\N
1220	34	38	medium	1	\N	\N	\N	3	6	38	\N
1221	34	39	medium	1	\N	\N	\N	3	7	39	\N
1222	34	40	medium	1	\N	\N	\N	3	8	40	\N
1223	34	41	medium	1	\N	\N	\N	3	9	41	\N
1224	34	42	medium	1	\N	\N	\N	3	10	42	\N
1225	34	43	medium	1	\N	\N	\N	3	11	43	\N
1226	34	44	medium	1	\N	\N	\N	3	12	44	\N
1227	34	45	medium	1	\N	\N	\N	3	13	45	\N
1228	34	46	medium	1	\N	\N	\N	3	14	46	\N
1229	34	47	medium	1	\N	\N	\N	3	15	47	\N
1230	34	48	medium	1	\N	\N	\N	3	16	48	\N
1183	34	1	medium	1	\N	\N	\N	1	1	1	\N
516	16	22	medium	1	\N	\N	\N	2	6	B22	2026-06-30 15:36:26.717548
517	16	23	medium	1	\N	\N	\N	2	7	B23	2026-06-30 15:36:26.717548
499	16	5	medium	1	\N	\N	\N	1	5	B5	2026-06-30 15:36:26.717548
521	16	27	medium	1	\N	\N	\N	2	11	B27	2026-06-30 15:36:26.717548
522	16	28	medium	1	\N	\N	\N	2	12	B28	2026-06-30 15:36:26.717548
523	16	29	medium	1	\N	\N	\N	2	13	B29	2026-06-30 15:36:26.717548
525	16	31	medium	1	\N	\N	\N	2	15	B31	2026-06-30 15:36:26.717548
\.


--
-- Data for Name: cabinets; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cabinets (id, location_id, cabinet_code, name, total_slots, status, last_heartbeat, created_at, group_id, deposit_amount, mainboard_device_id, mainboard_source, charge_mode, app_version, app_version_code, business_status, business_hours, customer_phone, updated_at, usage_rules, per_use_price) FROM stdin;
8	4	CAB005	智能寄存柜	16	0	2026-06-30 17:09:57.728225	2026-06-14 14:45:50	\N	20	123456	WT	deposit	1.2.30	150	active	8:00~22:00	4006981080	2026-06-27 11:40:45.308331	24小时内取包免费\\n保证金{deposit_amount}元，寄存结束后按规则结算\\n存包后请保管好取件码\\n柜内禁止存放易燃易爆及违禁物品	0
29	7	CAB20260702210439	B柜	80	1	\N	2026-07-02 21:04:39.120929	\N	20	101005	YBM	deposit		0	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
32	8	CAB20260702212525	A柜	64	1	\N	2026-07-02 21:25:25.724103	\N	20	101008	YBM	deposit		0	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
35	9	CAB20260702213507	A柜	64	1	\N	2026-07-02 21:35:07.232111	\N	20	101011	YBM	deposit		0	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
28	7	CAB20260702210253	C柜	32	1	\N	2026-07-02 21:02:53.377924	\N	20	100104	YBM	deposit		0	open	\N		2026-07-02 21:03:11.011864	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
31	7	CAB20260702210721	F柜	48	1	\N	2026-07-02 21:07:21.253398	\N	20	101007	YBM	deposit		0	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
30	7	CAB20260702210609	A柜	64	1	\N	2026-07-02 21:06:09.416976	\N	20	101006	YBM	deposit		0	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
33	8	CAB20260702212622	B柜	64	1	\N	2026-07-02 21:26:22.874464	\N	20	101009	YBM	deposit		0	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
15	6	CAB20260625180817	A柜	80	1	2026-07-02 21:53:43.780572	2026-06-25 10:08:17	\N	20	101002	YBM	deposit	1.2.42	162	open	\N	0	2026-07-02 21:50:04.564987	24小时内取包免费\\n保证金{deposit_amount}元，寄存结束后按规则结算\\n存包后请保管好取件码\\n柜内禁止存放易燃易爆及违禁物品	4006981080
37	6	CAB20260702213832	商祖科目二	64	1	\N	2026-07-02 21:38:32.53814	\N	20	101013	YBM	deposit		0	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
39	6	CAB20260702220344	B柜	64	1	\N	2026-07-02 22:03:44.867367	\N	20	100115	YBM	deposit		0	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
34	8	CAB20260702212720		96	1	\N	2026-07-02 21:27:20.893565	\N	20	101010	YBM	deposit		0	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
36	9	CAB20260702213603	B柜	64	1	\N	2026-07-02 21:36:03.123539	\N	20	101012	YBM	deposit		0	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
38	10	CAB20260702214542		80	1	\N	2026-07-02 21:45:42.84847	\N	20	101014	YBM	deposit		0	open	\N		2026-07-02 21:45:50.444829	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
27	7	CAB20260701090903	D柜	48	1	2026-07-03 03:00:00.392053	2026-07-01 09:09:03.714031	\N	20	100103	YBM	deposit	1.2.50	170	open	\N		\N	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
24	7	CAB20260629175546	E柜	64	1	2026-07-03 03:00:00.894928	2026-06-29 17:55:46.292334	\N	20	100101	YBM	deposit	1.2.50	170	open	\N		2026-07-02 07:42:15.581105	24小时内取包免费\n保证金{deposit_amount}元，寄存结束后按规则结算\n存包后请保管好取件码\n柜内禁止存放易燃易爆及违禁物品	0
16	4	CAB20260625181326	B柜	64	1	2026-07-02 23:04:52.368031	2026-06-25 10:13:26	\N	20	100100	YBM	deposit	1.2.50	170	open	\N	0	2026-07-02 21:59:20.283301	24小时内取包免费\\n保证金{deposit_amount}元，寄存结束后按规则结算\\n存包后请保管好取件码\\n柜内禁止存放易燃易爆及违禁物品	4006981080
\.


--
-- Data for Name: cached_orders; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.cached_orders (id, order_id, order_no, cabinet_id, slot_id, slot_number, deposit_amount, status, created_at, synced) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.companies (id, name, credit_code, contact_person, contact_phone, address, status, created_at) FROM stdin;
1	重庆科莱维科技有限公司	91500106MACK2R5P8G	李百棚	4006981080	重庆市沙坪坝区覃家岗街道凤鸣山307号附54号26-22	1	2026-06-18 02:28:25
2	测试公司	TEST001	\N	\N	\N	1	2026-06-18 02:54:02
\.


--
-- Data for Name: complaints; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.complaints (id, user_phone, type, content, order_no, status, reply, reply_time, wx_complaint_id, created_at, complaint_type, order_id, openid) FROM stdin;
4	19544562686	wechat	申请退款多日，钱款迟迟未原路返还，多次咨询无明确到账时间，要求尽快处理退款并告知准确到账节点。	20260630141812626447	2	您好，您的订单已为您办理全额退款，款项将原路返回至您的微信零钱，请注意查收。如有疑问请联系客服，感谢您的理解与支持！	2026-07-01 10:17:22.557803	200000020260701090476547358	2026-07-01 09:35:05.815916	wechat	539	\N
10	15726029001	wechat	没有退押金，快快快退给我	20260702100050634764	1	您好，我们已收到您的反馈，正在尽快为您处理。如有疑问请联系客服，感谢您的理解与支持！	2026-07-02 22:01:14.573544	200000020260702150477213900	2026-07-02 21:58:36.658866	wechat	1465	\N
3	18265820019	wechat	柜子押金为什么迟迟不到帐？	20260630123806951872	replied	您好，经核查该订单（20260630123806951872）已于6月30日完成退款（¥20.00），款项已原路返回。如有其他问题请联系客服4006981080。	2026-07-01 15:59:29.660519	200000020260630150476195840	2026-06-30 15:26:14.234833	wechat	501	\N
7	15186672778	wechat	押金没退，商家没有退还押金	20260701130626543594	1	您好，我们已收到您的反馈，正在尽快为您处理。如有疑问请联系客服，感谢您的理解与支持！	2026-07-01 18:09:42.372387	200000020260701180476782717	2026-07-01 18:04:41.821272	wechat	599	\N
2	18254067609	wechat	我于今日12点半左右存放物品，交取20元押金，但物品取出后押金并未退回	20260630123939351137	2	您好，您的订单已为您办理全额退款，款项将原路返回至您的微信零钱，请注意查收。如有疑问请联系客服，感谢您的理解与支持！	2026-06-30 21:08:18.022789	200000020260630150476190663	2026-06-30 15:00:14.837249	wechat	506	\N
8	18738065631	wechat	结束寄存之后不退钱，	20260702082339209075	1	您好，我们已收到您的反馈，正在尽快为您处理。如有疑问请联系客服，感谢您的理解与支持！	2026-07-02 09:42:21.974061	200000020260702090477071024	2026-07-02 09:37:21.41125	wechat	1432	\N
11	19139362917	wechat	押金未退回，押金未退回	20260702081651889788	1	您好，我们已收到您的反馈，正在尽快为您处理。如有疑问请联系客服，感谢您的理解与支持！	2026-07-02 22:01:15.645533	200000020260702090477076035	2026-07-02 21:58:36.658866	wechat	1429	\N
9	15136011309	wechat	存包已经退了但是钱还没有退回	20260702134104573220	1	您好，我们已收到您的反馈，正在尽快为您处理。如有疑问请联系客服，感谢您的理解与支持！	2026-07-02 15:25:19.822704	200000020260702150477220923	2026-07-02 15:20:19.255589	wechat	1498	\N
12	13655676086	wechat	没有退款111111\n	20260701080252681224	1	您好，我们已收到您的反馈，正在尽快为您处理。如有疑问请联系客服，感谢您的理解与支持！	2026-07-02 22:01:16.679671	200000020260701140476699225	2026-07-02 21:58:36.658866	wechat	565	\N
13	19139066893	wechat	他上边显示退还成功 但是我没有收到啊	20260702081807013160	1	您好，我们已收到您的反馈，正在尽快为您处理。如有疑问请联系客服，感谢您的理解与支持！	2026-07-02 23:38:57.32992	200000020260702230477463601	2026-07-02 23:33:56.767999	wechat	1431	\N
\.


--
-- Data for Name: device_alerts; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.device_alerts (id, device_id, alert_type, detail, created_at) FROM stdin;
3	100100	online	设备WebSocket连接建立	2026-06-27 10:55:56.91984
4	100100	online	设备WebSocket连接建立	2026-06-27 10:55:57.461221
5	100100	online	设备WebSocket连接建立	2026-06-27 10:59:31.857423
6	100100	online	设备WebSocket连接建立	2026-06-27 10:59:31.935454
7	100100	online	设备WebSocket连接建立	2026-06-27 11:00:20.381276
8	100100	online	设备WebSocket连接建立	2026-06-27 11:00:20.45294
9	100100	online	设备WebSocket连接建立	2026-06-27 11:07:40.394132
10	100100	online	设备WebSocket连接建立	2026-06-27 11:07:40.63802
11	100100	online	设备WebSocket连接建立	2026-06-27 11:08:49.266356
12	100100	online	设备WebSocket连接建立	2026-06-27 11:08:49.354396
13	100100	online	设备WebSocket连接建立	2026-06-27 11:10:03.377474
14	100100	online	设备WebSocket连接建立	2026-06-27 11:10:03.451777
15	100100	online	设备WebSocket连接建立	2026-06-27 11:12:19.854435
16	100100	online	设备WebSocket连接建立	2026-06-27 11:12:19.923264
17	100100	online	设备WebSocket连接建立	2026-06-27 11:12:47.261434
18	100100	online	设备WebSocket连接建立	2026-06-27 11:12:47.330682
19	100100	online	设备WebSocket连接建立	2026-06-27 11:12:48.555489
20	100100	online	设备WebSocket连接建立	2026-06-27 11:12:48.627375
21	100100	online	设备WebSocket连接建立	2026-06-27 11:12:49.916003
22	100100	online	设备WebSocket连接建立	2026-06-27 11:12:49.991209
23	100100	online	设备WebSocket连接建立	2026-06-27 11:12:51.225431
24	100100	online	设备WebSocket连接建立	2026-06-27 11:12:51.306914
25	100100	online	设备WebSocket连接建立	2026-06-27 11:12:52.580641
26	100100	online	设备WebSocket连接建立	2026-06-27 11:12:52.649964
27	100100	online	设备WebSocket连接建立	2026-06-27 11:12:54.041139
28	100100	online	设备WebSocket连接建立	2026-06-27 11:12:54.127381
29	100100	online	设备WebSocket连接建立	2026-06-27 11:12:55.4078
30	100100	online	设备WebSocket连接建立	2026-06-27 11:12:55.499532
31	100100	online	设备WebSocket连接建立	2026-06-27 11:12:56.837912
32	100100	online	设备WebSocket连接建立	2026-06-27 11:12:56.913271
33	100100	online	设备WebSocket连接建立	2026-06-27 11:12:58.173546
34	100100	online	设备WebSocket连接建立	2026-06-27 11:12:58.244881
35	100100	online	设备WebSocket连接建立	2026-06-27 11:12:59.539079
36	100100	online	设备WebSocket连接建立	2026-06-27 11:12:59.61114
37	100100	online	设备WebSocket连接建立	2026-06-27 11:13:00.877525
38	100100	online	设备WebSocket连接建立	2026-06-27 11:13:00.950467
39	100100	online	设备WebSocket连接建立	2026-06-27 11:13:02.406601
40	100100	online	设备WebSocket连接建立	2026-06-27 11:13:02.481136
41	100100	online	设备WebSocket连接建立	2026-06-27 11:13:03.73445
42	100100	online	设备WebSocket连接建立	2026-06-27 11:13:03.806018
43	100100	online	设备WebSocket连接建立	2026-06-27 11:13:05.050571
44	100100	online	设备WebSocket连接建立	2026-06-27 11:13:05.122727
45	100100	online	设备WebSocket连接建立	2026-06-27 11:13:06.344516
46	100100	online	设备WebSocket连接建立	2026-06-27 11:13:06.418125
47	100100	online	设备WebSocket连接建立	2026-06-27 11:13:07.648217
48	100100	online	设备WebSocket连接建立	2026-06-27 11:13:07.717789
49	100100	online	设备WebSocket连接建立	2026-06-27 11:13:38.589728
50	100100	online	设备WebSocket连接建立	2026-06-27 11:13:38.660644
51	101001	online	设备WebSocket连接建立	2026-06-27 11:16:43.984789
52	101001	online	设备WebSocket连接建立	2026-06-27 11:16:44.057094
53	101001	offline	设备WebSocket断开连接	2026-06-27 11:20:10.390829
54	101001	online	设备WebSocket连接建立	2026-06-27 11:20:10.850521
55	101001	online	设备WebSocket连接建立	2026-06-27 11:20:11.443967
56	100100	online	设备WebSocket连接建立	2026-06-27 11:23:55.912602
57	100100	online	设备WebSocket连接建立	2026-06-27 11:23:55.986191
58	101001	online	设备WebSocket连接建立	2026-06-27 11:23:56.163704
59	101001	online	设备WebSocket连接建立	2026-06-27 11:23:56.242573
60	101001	offline	设备WebSocket断开连接	2026-06-27 11:24:56.33821
61	101001	online	设备WebSocket连接建立	2026-06-27 11:24:57.973628
62	101001	online	设备WebSocket连接建立	2026-06-27 11:24:58.043956
63	100100	online	设备WebSocket连接建立	2026-06-27 11:29:09.559206
64	100100	online	设备WebSocket连接建立	2026-06-27 11:29:09.630231
65	101001	online	设备WebSocket连接建立	2026-06-27 11:29:18.428186
66	101001	online	设备WebSocket连接建立	2026-06-27 11:29:18.514517
67	101001	offline	设备WebSocket断开连接	2026-06-27 11:29:58.492744
68	101001	online	设备WebSocket连接建立	2026-06-27 11:30:00.81245
69	101001	online	设备WebSocket连接建立	2026-06-27 11:30:00.922113
70	101001	offline	设备WebSocket断开连接	2026-06-27 11:30:45.57715
71	101001	online	设备WebSocket连接建立	2026-06-27 11:30:54.254622
72	101001	online	设备WebSocket连接建立	2026-06-27 11:30:54.33895
73	100100	offline	设备WebSocket断开连接	2026-06-27 11:31:42.249812
74	100100	online	设备WebSocket连接建立	2026-06-27 11:31:48.402826
75	100100	online	设备WebSocket连接建立	2026-06-27 11:31:48.500141
76	101001	online	设备WebSocket连接建立	2026-06-27 11:35:41.855068
77	101001	online	设备WebSocket连接建立	2026-06-27 11:35:41.928488
78	100100	online	设备WebSocket连接建立	2026-06-27 11:44:03.720774
79	100100	online	设备WebSocket连接建立	2026-06-27 11:44:03.790999
80	101001	online	设备WebSocket连接建立	2026-06-27 11:44:24.235326
81	101001	online	设备WebSocket连接建立	2026-06-27 11:44:24.554912
82	100100	online	设备WebSocket连接建立	2026-06-27 11:55:16.171009
83	100100	online	设备WebSocket连接建立	2026-06-27 11:55:16.24396
84	100100	online	设备WebSocket连接建立	2026-06-27 11:58:36.821876
85	100100	online	设备WebSocket连接建立	2026-06-27 11:58:36.897543
86	100100	online	设备WebSocket连接建立	2026-06-27 12:11:37.160118
87	100100	online	设备WebSocket连接建立	2026-06-27 12:11:37.230653
88	100100	online	设备WebSocket连接建立	2026-06-27 12:28:29.595707
89	100100	online	设备WebSocket连接建立	2026-06-27 12:28:29.688708
90	100100	online	设备WebSocket连接建立	2026-06-27 12:30:47.394625
91	100100	online	设备WebSocket连接建立	2026-06-27 12:30:47.467509
92	100100	online	设备WebSocket连接建立	2026-06-27 12:35:45.520331
93	100100	online	设备WebSocket连接建立	2026-06-27 12:35:45.595731
94	100100	online	设备WebSocket连接建立	2026-06-27 12:42:26.257185
95	100100	online	设备WebSocket连接建立	2026-06-27 12:42:26.329878
96	100100	online	设备WebSocket连接建立	2026-06-27 12:45:37.822836
97	100100	online	设备WebSocket连接建立	2026-06-27 12:45:37.935435
98	100100	online	设备WebSocket连接建立	2026-06-27 12:50:43.915669
99	100100	online	设备WebSocket连接建立	2026-06-27 12:50:43.987128
100	100100	online	设备WebSocket连接建立	2026-06-27 12:58:19.943683
101	100100	online	设备WebSocket连接建立	2026-06-27 12:58:20.019932
102	100100	online	设备WebSocket连接建立	2026-06-27 12:58:42.944621
103	100100	online	设备WebSocket连接建立	2026-06-27 12:58:43.016519
104	100100	online	设备WebSocket连接建立	2026-06-27 13:16:34.084493
105	100100	online	设备WebSocket连接建立	2026-06-27 13:16:34.154438
106	100100	online	设备WebSocket连接建立	2026-06-27 13:17:48.989725
107	100100	online	设备WebSocket连接建立	2026-06-27 13:17:49.071032
108	100100	online	设备WebSocket连接建立	2026-06-27 13:42:02.442429
109	100100	online	设备WebSocket连接建立	2026-06-27 13:42:02.512096
110	101001	online	设备WebSocket连接建立	2026-06-27 13:58:01.052123
111	101001	online	设备WebSocket连接建立	2026-06-27 13:58:01.124738
112	101001	offline	设备WebSocket断开连接	2026-06-27 13:59:12.339609
113	101001	online	设备WebSocket连接建立	2026-06-27 14:00:14.099787
114	101001	online	设备WebSocket连接建立	2026-06-27 14:00:14.192503
115	100100	online	设备WebSocket连接建立	2026-06-27 14:09:37.808714
116	100100	online	设备WebSocket连接建立	2026-06-27 14:09:37.882159
117	101001	online	设备WebSocket连接建立	2026-06-27 14:09:37.952859
118	101001	online	设备WebSocket连接建立	2026-06-27 14:09:38.026301
119	101001	online	设备WebSocket连接建立	2026-06-27 14:26:36.722879
120	101001	online	设备WebSocket连接建立	2026-06-27 14:26:36.796375
121	100100	online	设备WebSocket连接建立	2026-06-27 14:26:37.075285
122	100100	online	设备WebSocket连接建立	2026-06-27 14:26:37.152586
123	100100	online	设备WebSocket连接建立	2026-06-27 14:30:51.991888
124	100100	online	设备WebSocket连接建立	2026-06-27 14:30:52.06807
125	101001	online	设备WebSocket连接建立	2026-06-27 14:30:52.242664
126	101001	online	设备WebSocket连接建立	2026-06-27 14:30:52.314568
127	101001	online	设备WebSocket连接建立	2026-06-27 14:30:56.99661
128	100100	online	设备WebSocket连接建立	2026-06-27 14:30:57.069126
129	100100	online	设备WebSocket连接建立	2026-06-27 14:30:57.145065
130	101001	online	设备WebSocket连接建立	2026-06-27 14:30:57.221708
131	101001	online	设备WebSocket连接建立	2026-06-27 14:49:41.095679
132	101001	online	设备WebSocket连接建立	2026-06-27 14:49:41.167306
133	100100	online	设备WebSocket连接建立	2026-06-27 14:49:41.353313
134	100100	online	设备WebSocket连接建立	2026-06-27 14:49:41.422462
135	101001	online	设备WebSocket连接建立	2026-06-27 14:52:53.476754
136	101001	online	设备WebSocket连接建立	2026-06-27 14:52:53.5524
137	100100	online	设备WebSocket连接建立	2026-06-27 14:52:53.737981
138	100100	online	设备WebSocket连接建立	2026-06-27 14:52:53.809222
139	100100	online	设备WebSocket连接建立	2026-06-27 14:54:06.200075
140	100100	online	设备WebSocket连接建立	2026-06-27 14:54:06.273558
141	101001	online	设备WebSocket连接建立	2026-06-27 14:54:06.441097
142	101001	online	设备WebSocket连接建立	2026-06-27 14:54:06.536404
143	100100	online	设备WebSocket连接建立	2026-06-27 14:54:57.425766
144	100100	online	设备WebSocket连接建立	2026-06-27 14:54:57.498051
145	101001	online	设备WebSocket连接建立	2026-06-27 14:55:00.345343
146	101001	online	设备WebSocket连接建立	2026-06-27 14:55:00.421623
147	101001	online	设备WebSocket连接建立	2026-06-27 14:56:05.473517
148	101001	online	设备WebSocket连接建立	2026-06-27 14:56:05.710202
149	100100	online	设备WebSocket连接建立	2026-06-27 14:56:05.783358
150	100100	online	设备WebSocket连接建立	2026-06-27 14:56:05.857102
151	100100	online	设备WebSocket连接建立	2026-06-27 14:57:32.001079
152	100100	online	设备WebSocket连接建立	2026-06-27 14:57:32.073553
153	101001	online	设备WebSocket连接建立	2026-06-27 14:57:49.589517
154	101001	online	设备WebSocket连接建立	2026-06-27 14:57:49.662768
155	100100	online	设备WebSocket连接建立	2026-06-27 15:05:50.047388
156	100100	online	设备WebSocket连接建立	2026-06-27 15:05:50.118638
157	101001	online	设备WebSocket连接建立	2026-06-27 15:05:53.355632
158	101001	online	设备WebSocket连接建立	2026-06-27 15:05:54.148915
159	101001	offline	设备WebSocket断开连接	2026-06-27 15:12:32.221135
160	101001	online	设备WebSocket连接建立	2026-06-27 15:12:38.025838
161	101001	online	设备WebSocket连接建立	2026-06-27 15:12:38.098489
162	101001	online	设备WebSocket连接建立	2026-06-27 15:24:38.341851
163	101001	online	设备WebSocket连接建立	2026-06-27 15:24:38.421847
164	100100	online	设备WebSocket连接建立	2026-06-27 15:35:33.355339
165	100100	online	设备WebSocket连接建立	2026-06-27 15:35:33.700155
166	101001	online	设备WebSocket连接建立	2026-06-27 15:36:08.475763
167	101001	online	设备WebSocket连接建立	2026-06-27 15:36:08.554127
168	100100	offline	设备WebSocket断开连接	2026-06-27 15:50:59.540512
169	100100	online	设备WebSocket连接建立	2026-06-27 15:51:05.69696
170	100100	online	设备WebSocket连接建立	2026-06-27 15:51:05.773884
171	100100	online	设备WebSocket连接建立	2026-06-27 15:53:01.32763
172	100100	online	设备WebSocket连接建立	2026-06-27 15:53:01.399322
173	101001	online	设备WebSocket连接建立	2026-06-27 15:53:01.507267
174	101001	online	设备WebSocket连接建立	2026-06-27 15:53:01.585697
175	100100	online	设备WebSocket连接建立	2026-06-27 15:53:06.659286
176	100100	online	设备WebSocket连接建立	2026-06-27 15:53:06.735054
177	101001	online	设备WebSocket连接建立	2026-06-27 15:53:06.810704
178	101001	online	设备WebSocket连接建立	2026-06-27 15:53:06.883891
179	100100	online	设备WebSocket连接建立	2026-06-27 15:59:49.079856
180	100100	online	设备WebSocket连接建立	2026-06-27 15:59:49.221892
181	101001	online	设备WebSocket连接建立	2026-06-27 15:59:49.302743
182	101001	online	设备WebSocket连接建立	2026-06-27 15:59:49.377531
183	101001	online	设备WebSocket连接建立	2026-06-27 16:09:47.331367
184	101001	online	设备WebSocket连接建立	2026-06-27 16:09:47.428036
185	100100	online	设备WebSocket连接建立	2026-06-27 16:09:47.503295
186	100100	online	设备WebSocket连接建立	2026-06-27 16:09:47.95771
187	100100	offline	设备WebSocket断开连接	2026-06-27 16:24:59.778041
188	101001	online	设备WebSocket连接建立	2026-06-27 16:31:53.974559
189	101001	online	设备WebSocket连接建立	2026-06-27 16:31:54.051231
190	100100	online	设备WebSocket连接建立	2026-06-27 16:37:57.075038
191	100100	online	设备WebSocket连接建立	2026-06-27 16:37:57.14883
192	100100	online	设备WebSocket连接建立	2026-06-27 16:52:19.756726
193	100100	online	设备WebSocket连接建立	2026-06-27 16:52:20.011994
194	100100	offline	设备WebSocket断开连接	2026-06-27 16:53:37.760693
195	101001	online	设备WebSocket连接建立	2026-06-27 17:05:21.068977
196	101001	online	设备WebSocket连接建立	2026-06-27 17:05:21.147375
197	101001	online	设备WebSocket连接建立	2026-06-27 17:11:43.009515
198	101001	online	设备WebSocket连接建立	2026-06-27 17:11:43.148494
199	101001	online	设备WebSocket连接建立	2026-06-27 17:12:31.975608
200	101001	online	设备WebSocket连接建立	2026-06-27 17:12:32.108736
201	101001	online	设备WebSocket连接建立	2026-06-27 17:13:14.185902
202	101001	online	设备WebSocket连接建立	2026-06-27 17:13:14.269736
203	101001	offline	设备WebSocket断开连接	2026-06-27 17:13:57.393623
204	101001	online	设备WebSocket连接建立	2026-06-27 17:14:03.232819
205	101001	online	设备WebSocket连接建立	2026-06-27 17:14:03.320362
206	101001	online	设备WebSocket连接建立	2026-06-27 17:14:58.109727
207	101001	online	设备WebSocket连接建立	2026-06-27 17:14:58.188691
208	101001	online	设备WebSocket连接建立	2026-06-27 17:15:50.748542
209	101001	online	设备WebSocket连接建立	2026-06-27 17:15:50.834547
210	101001	online	设备WebSocket连接建立	2026-06-27 17:19:04.074877
211	101001	online	设备WebSocket连接建立	2026-06-27 17:19:04.185739
212	101001	offline	设备WebSocket断开连接	2026-06-27 17:20:44.186843
213	101001	online	设备WebSocket连接建立	2026-06-27 17:20:45.86578
214	101001	online	设备WebSocket连接建立	2026-06-27 17:20:45.946464
215	101001	online	设备WebSocket连接建立	2026-06-27 17:25:32.954773
216	101001	online	设备WebSocket连接建立	2026-06-27 17:25:33.181436
217	101001	online	设备WebSocket连接建立	2026-06-27 17:27:28.346106
218	101001	online	设备WebSocket连接建立	2026-06-27 17:27:28.424993
219	101001	online	设备WebSocket连接建立	2026-06-27 18:04:56.652973
220	101001	online	设备WebSocket连接建立	2026-06-27 18:04:56.740728
221	101001	online	设备WebSocket连接建立	2026-06-27 18:06:52.819787
222	101001	online	设备WebSocket连接建立	2026-06-27 18:06:52.893232
223	101001	online	设备WebSocket连接建立	2026-06-27 22:43:22.88857
224	101001	online	设备WebSocket连接建立	2026-06-27 22:43:22.967632
225	101001	online	设备WebSocket连接建立	2026-06-27 23:15:08.466261
226	101001	online	设备WebSocket连接建立	2026-06-27 23:15:08.545361
227	101001	offline	设备WebSocket断开连接	2026-06-28 02:10:17.700956
228	100100	online	设备WebSocket连接建立	2026-06-28 07:42:07.076801
229	100100	online	设备WebSocket连接建立	2026-06-28 07:42:07.148268
230	100100	online	设备WebSocket连接建立	2026-06-28 07:45:40.294895
231	100100	online	设备WebSocket连接建立	2026-06-28 07:45:40.369461
232	100100	online	设备WebSocket连接建立	2026-06-28 07:46:31.403873
233	100100	online	设备WebSocket连接建立	2026-06-28 07:46:31.478628
234	100100	online	设备WebSocket连接建立	2026-06-28 07:55:19.148113
235	100100	online	设备WebSocket连接建立	2026-06-28 07:55:19.224822
236	100100	online	设备WebSocket连接建立	2026-06-28 08:01:45.333148
237	100100	online	设备WebSocket连接建立	2026-06-28 08:01:45.411546
238	100100	online	设备WebSocket连接建立	2026-06-28 08:06:36.979856
239	100100	online	设备WebSocket连接建立	2026-06-28 08:06:37.053312
240	100100	online	设备WebSocket连接建立	2026-06-28 08:06:47.205464
241	100100	online	设备WebSocket连接建立	2026-06-28 08:06:47.27967
242	101001	online	设备WebSocket连接建立	2026-06-28 08:10:31.696513
243	101001	online	设备WebSocket连接建立	2026-06-28 08:10:31.769677
244	100100	online	设备WebSocket连接建立	2026-06-28 08:18:42.757439
245	100100	online	设备WebSocket连接建立	2026-06-28 08:18:42.828576
246	101001	online	设备WebSocket连接建立	2026-06-28 08:18:44.822992
247	101001	online	设备WebSocket连接建立	2026-06-28 08:18:44.898687
248	100100	online	设备WebSocket连接建立	2026-06-28 08:28:12.025768
249	100100	online	设备WebSocket连接建立	2026-06-28 08:28:12.274313
250	101001	online	设备WebSocket连接建立	2026-06-28 08:28:12.36468
251	101001	online	设备WebSocket连接建立	2026-06-28 08:28:12.4665
252	101001	online	设备WebSocket连接建立	2026-06-28 08:29:37.479541
253	101001	online	设备WebSocket连接建立	2026-06-28 08:29:37.627901
254	100100	online	设备WebSocket连接建立	2026-06-28 08:29:37.968583
255	100100	online	设备WebSocket连接建立	2026-06-28 08:29:38.043873
256	100100	online	设备WebSocket连接建立	2026-06-28 08:39:24.423586
257	100100	online	设备WebSocket连接建立	2026-06-28 08:39:24.509015
258	101001	online	设备WebSocket连接建立	2026-06-28 08:39:24.581357
259	101001	online	设备WebSocket连接建立	2026-06-28 08:39:24.788743
260	101001	online	设备WebSocket连接建立	2026-06-28 08:39:34.683667
261	100100	online	设备WebSocket连接建立	2026-06-28 08:39:34.759718
262	100100	online	设备WebSocket连接建立	2026-06-28 08:39:34.837898
263	101001	online	设备WebSocket连接建立	2026-06-28 08:39:34.912728
264	100100	online	设备WebSocket连接建立	2026-06-28 08:44:39.132275
265	100100	online	设备WebSocket连接建立	2026-06-28 08:44:39.211206
266	101001	online	设备WebSocket连接建立	2026-06-28 08:44:39.296442
267	101001	online	设备WebSocket连接建立	2026-06-28 08:44:39.371087
268	100100	online	设备WebSocket连接建立	2026-06-28 09:07:18.259738
269	100100	online	设备WebSocket连接建立	2026-06-28 09:07:18.332833
270	101001	online	设备WebSocket连接建立	2026-06-28 09:07:18.999034
271	101001	online	设备WebSocket连接建立	2026-06-28 09:07:19.23829
272	100100	online	设备WebSocket连接建立	2026-06-28 09:09:36.171337
273	100100	online	设备WebSocket连接建立	2026-06-28 09:09:36.245943
274	101001	online	设备WebSocket连接建立	2026-06-28 09:09:36.317479
275	101001	online	设备WebSocket连接建立	2026-06-28 09:09:36.391455
276	100100	online	设备WebSocket连接建立	2026-06-28 09:11:17.899334
277	100100	online	设备WebSocket连接建立	2026-06-28 09:11:17.978357
278	101001	online	设备WebSocket连接建立	2026-06-28 09:11:18.054865
279	101001	online	设备WebSocket连接建立	2026-06-28 09:11:18.130049
280	100100	online	设备WebSocket连接建立	2026-06-28 09:14:27.188387
281	100100	online	设备WebSocket连接建立	2026-06-28 09:14:27.265968
282	101001	online	设备WebSocket连接建立	2026-06-28 09:14:27.340346
283	101001	online	设备WebSocket连接建立	2026-06-28 09:14:27.414992
284	100100	online	设备WebSocket连接建立	2026-06-28 09:17:09.622663
285	100100	online	设备WebSocket连接建立	2026-06-28 09:17:09.69706
286	101001	online	设备WebSocket连接建立	2026-06-28 09:17:09.769792
287	101001	online	设备WebSocket连接建立	2026-06-28 09:17:09.966535
288	100100	online	设备WebSocket连接建立	2026-06-28 09:18:40.836115
289	100100	online	设备WebSocket连接建立	2026-06-28 09:18:40.909392
290	101001	online	设备WebSocket连接建立	2026-06-28 09:18:40.982775
291	101001	online	设备WebSocket连接建立	2026-06-28 09:18:41.168139
292	101001	online	设备WebSocket连接建立	2026-06-28 09:19:47.846884
293	100100	online	设备WebSocket连接建立	2026-06-28 09:19:47.985685
294	100100	online	设备WebSocket连接建立	2026-06-28 09:19:48.061107
295	101001	online	设备WebSocket连接建立	2026-06-28 09:19:48.139327
296	100100	online	设备WebSocket连接建立	2026-06-28 09:21:15.732146
297	100100	online	设备WebSocket连接建立	2026-06-28 09:21:15.806794
298	101001	online	设备WebSocket连接建立	2026-06-28 09:21:15.883144
299	101001	online	设备WebSocket连接建立	2026-06-28 09:21:16.027311
300	100100	online	设备WebSocket连接建立	2026-06-28 09:23:26.872149
301	100100	online	设备WebSocket连接建立	2026-06-28 09:23:26.947545
302	101001	online	设备WebSocket连接建立	2026-06-28 09:23:27.22378
303	101001	online	设备WebSocket连接建立	2026-06-28 09:23:27.300395
304	100100	online	设备WebSocket连接建立	2026-06-28 09:32:04.15383
305	100100	online	设备WebSocket连接建立	2026-06-28 09:32:04.230537
306	101001	online	设备WebSocket连接建立	2026-06-28 09:32:07.493136
307	101001	online	设备WebSocket连接建立	2026-06-28 09:32:07.573987
308	100100	online	设备WebSocket连接建立	2026-06-28 09:34:29.642791
309	100100	online	设备WebSocket连接建立	2026-06-28 09:34:29.719868
310	101001	online	设备WebSocket连接建立	2026-06-28 09:34:29.794242
311	101001	online	设备WebSocket连接建立	2026-06-28 09:34:29.948186
312	100100	online	设备WebSocket连接建立	2026-06-28 09:46:38.546075
313	100100	online	设备WebSocket连接建立	2026-06-28 09:46:38.623352
314	101001	online	设备WebSocket连接建立	2026-06-28 09:46:39.873659
315	101001	online	设备WebSocket连接建立	2026-06-28 09:46:39.950643
316	100100	online	设备WebSocket连接建立	2026-06-28 09:46:56.400672
317	101001	online	设备WebSocket连接建立	2026-06-28 09:46:56.813596
318	101001	online	设备WebSocket连接建立	2026-06-28 09:46:58.435754
319	101001	online	设备WebSocket连接建立	2026-06-28 09:46:58.510667
320	100100	online	设备WebSocket连接建立	2026-06-28 09:46:58.59833
321	100100	online	设备WebSocket连接建立	2026-06-28 09:46:58.675923
322	100100	online	设备WebSocket连接建立	2026-06-28 09:54:08.61657
323	100100	online	设备WebSocket连接建立	2026-06-28 09:54:08.691367
324	101001	online	设备WebSocket连接建立	2026-06-28 09:54:08.765725
325	101001	online	设备WebSocket连接建立	2026-06-28 09:54:08.842151
326	100100	online	设备WebSocket连接建立	2026-06-28 09:58:21.045436
327	100100	online	设备WebSocket连接建立	2026-06-28 09:58:21.125017
328	101001	online	设备WebSocket连接建立	2026-06-28 09:58:21.377412
329	101001	online	设备WebSocket连接建立	2026-06-28 09:58:21.448749
330	101001	offline	设备WebSocket断开连接	2026-06-28 09:59:23.536344
331	101001	online	设备WebSocket连接建立	2026-06-28 09:59:29.724462
332	101001	online	设备WebSocket连接建立	2026-06-28 09:59:29.797251
333	101001	online	设备WebSocket连接建立	2026-06-28 10:00:27.243184
334	101001	online	设备WebSocket连接建立	2026-06-28 10:00:27.37371
335	100100	online	设备WebSocket连接建立	2026-06-28 10:00:28.616599
336	100100	online	设备WebSocket连接建立	2026-06-28 10:00:28.690169
337	101001	online	设备WebSocket连接建立	2026-06-28 10:11:55.660741
338	101001	online	设备WebSocket连接建立	2026-06-28 10:11:55.737363
339	100100	online	设备WebSocket连接建立	2026-06-28 10:24:55.659881
340	100100	online	设备WebSocket连接建立	2026-06-28 10:24:55.746867
341	100100	online	设备WebSocket连接建立	2026-06-28 10:25:53.232666
342	100100	online	设备WebSocket连接建立	2026-06-28 10:25:53.31183
343	100100	online	设备WebSocket连接建立	2026-06-28 10:26:13.207212
344	100100	online	设备WebSocket连接建立	2026-06-28 10:26:13.334595
345	100100	online	设备WebSocket连接建立	2026-06-28 10:30:04.918939
346	100100	online	设备WebSocket连接建立	2026-06-28 10:30:04.992961
347	100100	online	设备WebSocket连接建立	2026-06-28 10:31:07.299956
348	100100	online	设备WebSocket连接建立	2026-06-28 10:31:07.379765
349	100100	online	设备WebSocket连接建立	2026-06-28 10:32:11.442108
350	100100	online	设备WebSocket连接建立	2026-06-28 10:32:11.513963
351	100100	online	设备WebSocket连接建立	2026-06-28 10:33:49.906469
352	100100	online	设备WebSocket连接建立	2026-06-28 10:33:49.981176
353	100100	online	设备WebSocket连接建立	2026-06-28 10:36:37.944518
354	100100	online	设备WebSocket连接建立	2026-06-28 10:36:38.023341
355	100100	online	设备WebSocket连接建立	2026-06-28 10:45:36.230657
356	100100	online	设备WebSocket连接建立	2026-06-28 10:45:36.306648
357	101001	online	设备WebSocket连接建立	2026-06-28 10:46:39.387683
358	101001	online	设备WebSocket连接建立	2026-06-28 10:46:39.466899
359	100100	online	设备WebSocket连接建立	2026-06-28 10:46:51.472946
360	100100	online	设备WebSocket连接建立	2026-06-28 10:46:51.551371
361	101001	online	设备WebSocket连接建立	2026-06-28 10:46:57.548618
362	101001	online	设备WebSocket连接建立	2026-06-28 10:46:57.625684
363	101001	online	设备WebSocket连接建立	2026-06-28 10:49:32.423338
364	101001	online	设备WebSocket连接建立	2026-06-28 10:49:32.496951
365	100100	online	设备WebSocket连接建立	2026-06-28 10:49:32.5761
366	100100	online	设备WebSocket连接建立	2026-06-28 10:49:32.649764
367	101001	online	设备WebSocket连接建立	2026-06-28 10:52:47.881645
368	101001	online	设备WebSocket连接建立	2026-06-28 10:52:47.957805
369	100100	online	设备WebSocket连接建立	2026-06-28 10:52:48.032281
370	100100	online	设备WebSocket连接建立	2026-06-28 10:52:48.102681
371	101001	online	设备WebSocket连接建立	2026-06-28 10:57:11.677465
372	101001	online	设备WebSocket连接建立	2026-06-28 10:57:11.75066
373	100100	online	设备WebSocket连接建立	2026-06-28 10:57:11.827057
374	100100	online	设备WebSocket连接建立	2026-06-28 10:57:11.900432
375	101001	online	设备WebSocket连接建立	2026-06-28 11:02:59.621399
376	101001	online	设备WebSocket连接建立	2026-06-28 11:02:59.699243
377	100100	online	设备WebSocket连接建立	2026-06-28 11:02:59.77276
378	100100	online	设备WebSocket连接建立	2026-06-28 11:02:59.847471
379	101001	online	设备WebSocket连接建立	2026-06-28 11:08:09.248403
380	101001	online	设备WebSocket连接建立	2026-06-28 11:08:09.324632
381	100100	online	设备WebSocket连接建立	2026-06-28 11:08:12.646165
382	100100	online	设备WebSocket连接建立	2026-06-28 11:08:12.732252
383	101001	online	设备WebSocket连接建立	2026-06-28 11:11:16.983144
384	101001	online	设备WebSocket连接建立	2026-06-28 11:11:17.057459
385	100100	online	设备WebSocket连接建立	2026-06-28 11:11:17.129305
386	100100	online	设备WebSocket连接建立	2026-06-28 11:11:17.613241
387	101001	online	设备WebSocket连接建立	2026-06-28 11:18:27.391106
388	101001	online	设备WebSocket连接建立	2026-06-28 11:18:27.47106
389	100100	online	设备WebSocket连接建立	2026-06-28 11:18:27.554515
390	100100	online	设备WebSocket连接建立	2026-06-28 11:18:27.636248
391	101001	online	设备WebSocket连接建立	2026-06-28 11:21:17.473515
392	101001	online	设备WebSocket连接建立	2026-06-28 11:21:17.553482
393	100100	online	设备WebSocket连接建立	2026-06-28 11:21:18.079565
394	100100	online	设备WebSocket连接建立	2026-06-28 11:21:18.156376
395	101001	offline	设备WebSocket断开连接	2026-06-28 11:24:05.937565
396	101001	online	设备WebSocket连接建立	2026-06-28 11:24:11.561293
397	101001	online	设备WebSocket连接建立	2026-06-28 11:24:11.636609
398	100100	online	设备WebSocket连接建立	2026-06-28 11:25:29.975978
399	100100	online	设备WebSocket连接建立	2026-06-28 11:25:30.050892
400	101001	online	设备WebSocket连接建立	2026-06-28 11:25:30.126676
401	101001	online	设备WebSocket连接建立	2026-06-28 11:25:30.201957
402	101001	online	设备WebSocket连接建立	2026-06-28 11:29:38.76954
403	101001	online	设备WebSocket连接建立	2026-06-28 11:29:38.849282
404	100100	online	设备WebSocket连接建立	2026-06-28 11:29:38.922173
405	100100	online	设备WebSocket连接建立	2026-06-28 11:29:38.996908
406	101001	offline	设备WebSocket断开连接	2026-06-28 11:30:41.192788
407	101001	online	设备WebSocket连接建立	2026-06-28 11:30:46.800064
408	101001	online	设备WebSocket连接建立	2026-06-28 11:30:46.87462
409	101001	offline	设备WebSocket断开连接	2026-06-28 11:31:08.209473
410	101001	online	设备WebSocket连接建立	2026-06-28 11:31:13.79887
411	101001	online	设备WebSocket连接建立	2026-06-28 11:31:13.88008
412	100100	online	设备WebSocket连接建立	2026-06-28 11:35:12.432911
413	100100	online	设备WebSocket连接建立	2026-06-28 11:35:12.51557
414	101001	online	设备WebSocket连接建立	2026-06-28 11:35:12.595358
415	101001	online	设备WebSocket连接建立	2026-06-28 11:35:12.676136
416	101001	online	设备WebSocket连接建立	2026-06-28 11:56:47.685729
417	101001	online	设备WebSocket连接建立	2026-06-28 11:56:47.76112
418	100100	online	设备WebSocket连接建立	2026-06-28 11:56:47.837351
419	100100	online	设备WebSocket连接建立	2026-06-28 11:56:47.917697
420	101001	online	设备WebSocket连接建立	2026-06-28 14:09:28.14474
421	101001	online	设备WebSocket连接建立	2026-06-28 14:09:28.232844
422	100100	online	设备WebSocket连接建立	2026-06-28 14:09:28.337348
423	100100	online	设备WebSocket连接建立	2026-06-28 14:09:28.415029
424	101001	online	设备WebSocket连接建立	2026-06-28 14:12:48.92152
425	101001	online	设备WebSocket连接建立	2026-06-28 14:12:49.004553
426	100100	online	设备WebSocket连接建立	2026-06-28 14:12:49.07869
427	100100	online	设备WebSocket连接建立	2026-06-28 14:12:49.157814
428	101001	online	设备WebSocket连接建立	2026-06-28 14:15:53.72697
429	101001	online	设备WebSocket连接建立	2026-06-28 14:15:53.803687
430	100100	online	设备WebSocket连接建立	2026-06-28 14:15:53.905672
431	100100	online	设备WebSocket连接建立	2026-06-28 14:15:53.977688
432	101001	online	设备WebSocket连接建立	2026-06-28 14:57:51.847093
433	101001	online	设备WebSocket连接建立	2026-06-28 14:57:51.923417
434	100100	online	设备WebSocket连接建立	2026-06-28 14:57:52.000825
435	100100	online	设备WebSocket连接建立	2026-06-28 14:57:52.077506
436	101001	online	设备WebSocket连接建立	2026-06-28 15:12:04.5064
437	101001	online	设备WebSocket连接建立	2026-06-28 15:12:04.587768
438	100100	online	设备WebSocket连接建立	2026-06-28 15:12:04.661028
439	100100	online	设备WebSocket连接建立	2026-06-28 15:12:04.73306
440	101001	online	设备WebSocket连接建立	2026-06-28 15:17:25.616885
441	101001	online	设备WebSocket连接建立	2026-06-28 15:17:25.688353
442	100100	online	设备WebSocket连接建立	2026-06-28 15:17:25.767363
443	100100	online	设备WebSocket连接建立	2026-06-28 15:17:25.83967
444	101001	online	设备WebSocket连接建立	2026-06-28 15:18:36.589757
445	101001	online	设备WebSocket连接建立	2026-06-28 15:18:36.66229
446	100100	online	设备WebSocket连接建立	2026-06-28 15:18:36.736551
447	100100	online	设备WebSocket连接建立	2026-06-28 15:18:36.808536
448	101001	online	设备WebSocket连接建立	2026-06-28 15:19:41.561538
449	101001	online	设备WebSocket连接建立	2026-06-28 15:19:41.636303
450	100100	online	设备WebSocket连接建立	2026-06-28 15:19:41.711351
451	100100	online	设备WebSocket连接建立	2026-06-28 15:19:41.790171
452	101001	online	设备WebSocket连接建立	2026-06-28 15:32:07.032841
453	101001	online	设备WebSocket连接建立	2026-06-28 15:32:07.105902
454	100100	online	设备WebSocket连接建立	2026-06-28 15:32:07.179018
455	100100	online	设备WebSocket连接建立	2026-06-28 15:32:07.254473
456	100100	online	设备WebSocket连接建立	2026-06-28 15:33:40.624062
457	100100	online	设备WebSocket连接建立	2026-06-28 15:33:40.701234
458	101001	online	设备WebSocket连接建立	2026-06-28 15:33:40.777116
459	101001	online	设备WebSocket连接建立	2026-06-28 15:33:40.860039
460	101001	online	设备WebSocket连接建立	2026-06-28 15:40:48.096653
461	101001	online	设备WebSocket连接建立	2026-06-28 15:40:48.18171
462	100100	online	设备WebSocket连接建立	2026-06-28 15:40:48.258176
463	100100	online	设备WebSocket连接建立	2026-06-28 15:40:48.339034
464	101001	online	设备WebSocket连接建立	2026-06-28 15:47:53.989944
465	101001	online	设备WebSocket连接建立	2026-06-28 15:47:54.064171
466	100100	online	设备WebSocket连接建立	2026-06-28 15:47:54.215415
467	100100	online	设备WebSocket连接建立	2026-06-28 15:47:54.287458
468	101001	online	设备WebSocket连接建立	2026-06-28 15:49:36.077638
469	101001	online	设备WebSocket连接建立	2026-06-28 15:49:36.157515
470	100100	online	设备WebSocket连接建立	2026-06-28 15:49:36.246214
471	100100	online	设备WebSocket连接建立	2026-06-28 15:49:36.321335
472	101001	online	设备WebSocket连接建立	2026-06-28 16:13:56.801122
473	101001	online	设备WebSocket连接建立	2026-06-28 16:13:56.876771
474	100100	online	设备WebSocket连接建立	2026-06-28 16:13:58.873315
475	100100	online	设备WebSocket连接建立	2026-06-28 16:13:58.948305
476	101001	online	设备WebSocket连接建立	2026-06-28 16:17:22.927872
477	101001	online	设备WebSocket连接建立	2026-06-28 16:17:23.005092
478	100100	online	设备WebSocket连接建立	2026-06-28 16:17:23.079771
479	100100	online	设备WebSocket连接建立	2026-06-28 16:17:23.153539
480	101001	online	设备WebSocket连接建立	2026-06-28 16:18:40.242225
481	101001	online	设备WebSocket连接建立	2026-06-28 16:18:40.318412
482	100100	online	设备WebSocket连接建立	2026-06-28 16:18:40.391405
483	100100	online	设备WebSocket连接建立	2026-06-28 16:18:40.465292
484	100100	online	设备WebSocket连接建立	2026-06-28 16:21:14.771243
485	100100	online	设备WebSocket连接建立	2026-06-28 16:21:14.853886
486	101001	online	设备WebSocket连接建立	2026-06-28 16:21:14.943235
487	101001	online	设备WebSocket连接建立	2026-06-28 16:21:15.023747
488	101001	online	设备WebSocket连接建立	2026-06-28 17:33:30.812488
489	101001	online	设备WebSocket连接建立	2026-06-28 17:33:30.890266
490	100100	online	设备WebSocket连接建立	2026-06-28 17:33:30.966689
491	100100	online	设备WebSocket连接建立	2026-06-28 17:33:31.039333
492	101001	online	设备WebSocket连接建立	2026-06-28 17:43:19.194823
493	101001	online	设备WebSocket连接建立	2026-06-28 17:43:19.27045
494	100100	online	设备WebSocket连接建立	2026-06-28 17:43:19.350172
495	100100	online	设备WebSocket连接建立	2026-06-28 17:43:19.42447
496	101001	online	设备WebSocket连接建立	2026-06-28 17:56:22.600341
497	101001	online	设备WebSocket连接建立	2026-06-28 17:56:22.68653
498	100100	online	设备WebSocket连接建立	2026-06-28 17:56:22.761796
499	100100	online	设备WebSocket连接建立	2026-06-28 17:56:22.837774
500	101001	online	设备WebSocket连接建立	2026-06-28 18:33:03.823587
501	101001	online	设备WebSocket连接建立	2026-06-28 18:33:03.898838
502	100100	online	设备WebSocket连接建立	2026-06-28 18:33:04.104593
503	100100	online	设备WebSocket连接建立	2026-06-28 18:33:04.183079
504	100100	offline	设备WebSocket断开连接	2026-06-28 21:31:44.109363
505	101001	online	设备WebSocket连接建立	2026-06-28 22:01:50.274874
506	101001	online	设备WebSocket连接建立	2026-06-28 22:01:50.358863
507	101001	online	设备WebSocket连接建立	2026-06-28 22:02:56.265399
508	101001	online	设备WebSocket连接建立	2026-06-28 22:02:56.344595
509	101001	online	设备WebSocket连接建立	2026-06-28 22:05:55.148062
510	101001	online	设备WebSocket连接建立	2026-06-28 22:05:55.222338
511	101001	online	设备WebSocket连接建立	2026-06-28 22:13:46.421457
512	101001	online	设备WebSocket连接建立	2026-06-28 22:13:46.499118
513	101001	online	设备WebSocket连接建立	2026-06-28 22:16:07.819306
514	101001	online	设备WebSocket连接建立	2026-06-28 22:16:07.9009
515	101001	online	设备WebSocket连接建立	2026-06-28 22:17:01.59514
516	101001	online	设备WebSocket连接建立	2026-06-28 22:17:01.670579
517	101001	online	设备WebSocket连接建立	2026-06-28 22:17:41.454191
518	101001	online	设备WebSocket连接建立	2026-06-28 22:17:41.534251
519	101001	online	设备WebSocket连接建立	2026-06-28 22:19:35.728056
520	101001	online	设备WebSocket连接建立	2026-06-28 22:19:36.04962
521	101001	online	设备WebSocket连接建立	2026-06-28 22:20:58.5266
522	101001	online	设备WebSocket连接建立	2026-06-28 22:20:58.602361
523	101001	online	设备WebSocket连接建立	2026-06-28 22:21:51.006989
524	101001	online	设备WebSocket连接建立	2026-06-28 22:21:51.086445
525	101001	online	设备WebSocket连接建立	2026-06-28 22:30:00.587063
526	101001	online	设备WebSocket连接建立	2026-06-28 22:30:00.665369
527	101001	online	设备WebSocket连接建立	2026-06-28 22:30:58.467217
528	101001	online	设备WebSocket连接建立	2026-06-28 22:30:58.546033
529	101001	online	设备WebSocket连接建立	2026-06-28 22:31:38.649664
530	101001	online	设备WebSocket连接建立	2026-06-28 22:31:38.727012
531	101001	online	设备WebSocket连接建立	2026-06-28 22:35:24.442275
532	101001	online	设备WebSocket连接建立	2026-06-28 22:35:24.521633
533	101001	online	设备WebSocket连接建立	2026-06-28 22:47:46.164989
534	101001	online	设备WebSocket连接建立	2026-06-28 22:47:46.239738
535	101001	online	设备WebSocket连接建立	2026-06-28 23:18:23.283893
536	101001	online	设备WebSocket连接建立	2026-06-28 23:18:23.361629
537	101001	online	设备WebSocket连接建立	2026-06-28 23:28:35.636577
538	101001	online	设备WebSocket连接建立	2026-06-28 23:28:35.715673
539	101001	online	设备WebSocket连接建立	2026-06-29 07:09:24.669252
540	101001	online	设备WebSocket连接建立	2026-06-29 07:09:24.743899
541	101001	online	设备WebSocket连接建立	2026-06-29 07:17:11.608062
542	101001	online	设备WebSocket连接建立	2026-06-29 07:17:11.683907
543	101001	online	设备WebSocket连接建立	2026-06-29 07:24:52.642146
544	101001	online	设备WebSocket连接建立	2026-06-29 07:24:52.722962
545	101001	online	设备WebSocket连接建立	2026-06-29 07:29:21.609725
546	101001	online	设备WebSocket连接建立	2026-06-29 07:29:21.69347
547	101001	online	设备WebSocket连接建立	2026-06-29 07:33:59.920959
548	101001	online	设备WebSocket连接建立	2026-06-29 07:33:59.997623
549	101001	online	设备WebSocket连接建立	2026-06-29 07:46:04.820231
550	101001	online	设备WebSocket连接建立	2026-06-29 07:46:04.898989
551	101001	online	设备WebSocket连接建立	2026-06-29 07:47:56.297615
552	101001	online	设备WebSocket连接建立	2026-06-29 07:47:56.373918
553	101001	online	设备WebSocket连接建立	2026-06-29 07:49:27.002582
554	101001	online	设备WebSocket连接建立	2026-06-29 07:49:27.077585
555	101001	online	设备WebSocket连接建立	2026-06-29 07:52:08.116199
556	101001	online	设备WebSocket连接建立	2026-06-29 07:52:08.191298
557	101001	online	设备WebSocket连接建立	2026-06-29 07:53:54.245536
558	101001	online	设备WebSocket连接建立	2026-06-29 07:53:54.319574
559	101001	online	设备WebSocket连接建立	2026-06-29 07:54:34.512035
560	101001	online	设备WebSocket连接建立	2026-06-29 07:54:34.590814
561	101001	online	设备WebSocket连接建立	2026-06-29 07:56:26.392697
562	101001	online	设备WebSocket连接建立	2026-06-29 07:56:26.464974
563	101001	online	设备WebSocket连接建立	2026-06-29 07:57:35.066428
564	101001	online	设备WebSocket连接建立	2026-06-29 07:57:35.14468
565	100100	online	设备WebSocket连接建立	2026-06-29 12:35:36.79388
566	100100	offline	设备WebSocket断开连接	2026-06-29 14:21:20.597128
567	100100	online	设备WebSocket连接建立	2026-06-29 14:26:16.530661
568	100100	offline	设备WebSocket断开连接	2026-06-29 14:35:48.465815
569	100100	online	设备WebSocket连接建立	2026-06-29 14:35:54.216333
570	100100	offline	设备WebSocket断开连接	2026-06-29 15:03:17.050167
571	100100	online	设备WebSocket连接建立	2026-06-29 15:03:23.176682
572	test_ws_check	online	设备WebSocket连接建立	2026-06-29 19:32:19.069427
573	test_ws_check	offline	设备WebSocket断开连接	2026-06-29 19:32:24.063788
574	100100	offline	设备WebSocket断开连接	2026-06-29 20:03:32.05209
575	100100	offline	设备WebSocket断开连接	2026-06-29 21:28:22.916226
576	100101	offline	设备WebSocket断开连接	2026-06-29 21:40:05.397495
577	100100	offline	设备WebSocket断开连接	2026-06-29 21:40:05.499595
578	100101	offline	设备WebSocket断开连接	2026-06-29 21:41:52.400055
579	100101	offline	设备WebSocket断开连接	2026-06-29 21:44:01.811282
580	100101	offline	设备WebSocket断开连接	2026-06-29 21:49:19.987752
581	100101	online	设备WebSocket连接建立	2026-06-29 22:21:47.462048
582	100101	offline	设备WebSocket断开连接	2026-06-29 22:23:28.927929
583	100100	offline	设备WebSocket断开连接	2026-06-29 22:24:57.343471
584	100100	offline	设备WebSocket断开连接	2026-06-29 22:50:09.908441
585	100101	offline	设备WebSocket断开连接	2026-06-29 22:50:09.910918
586	100100	offline	设备WebSocket断开连接	2026-06-29 22:57:55.574996
587	100101	offline	设备WebSocket断开连接	2026-06-29 22:57:55.661164
588	100100	offline	设备WebSocket断开连接	2026-06-29 23:05:50.893795
589	100101	offline	设备WebSocket断开连接	2026-06-29 23:29:16.898768
590	100100	online	设备WebSocket连接建立	2026-06-30 06:31:58.671655
591	100100	offline	设备WebSocket断开连接	2026-06-30 06:49:17.202381
592	100100	offline	设备WebSocket断开连接	2026-06-30 06:59:19.05186
593	100100	offline	设备WebSocket断开连接	2026-06-30 07:01:17.480234
594	100100	offline	设备WebSocket断开连接	2026-06-30 07:01:37.223187
595	100100	online	设备WebSocket连接建立	2026-06-30 07:02:02.977403
596	100100	offline	设备WebSocket断开连接	2026-06-30 07:04:30.297108
597	100100	online	设备WebSocket连接建立	2026-06-30 07:04:40.606388
598	100100	offline	设备WebSocket断开连接	2026-06-30 07:19:17.380956
599	100100	offline	设备WebSocket断开连接	2026-06-30 07:24:09.0583
600	100100	online	设备WebSocket连接建立	2026-06-30 07:24:19.98453
601	100100	offline	设备WebSocket断开连接	2026-06-30 07:41:15.55208
602	100100	offline	设备WebSocket断开连接	2026-06-30 07:49:51.705408
603	100100	offline	设备WebSocket断开连接	2026-06-30 07:54:14.391726
604	100100	offline	设备WebSocket断开连接	2026-06-30 08:08:41.992196
605	100100	offline	设备WebSocket断开连接	2026-06-30 08:09:53.756612
606	100100	offline	设备WebSocket断开连接	2026-06-30 08:27:07.374077
607	100100	offline	设备WebSocket断开连接	2026-06-30 08:31:28.733489
608	100100	offline	设备WebSocket断开连接	2026-06-30 08:34:08.402478
609	100100	offline	设备WebSocket断开连接	2026-06-30 08:38:07.996176
610	100101	online	设备WebSocket连接建立	2026-06-30 08:44:48.895673
611	100101	offline	设备WebSocket断开连接	2026-06-30 08:45:01.97852
612	100101	online	设备WebSocket连接建立	2026-06-30 08:45:08.666692
613	100101	offline	设备WebSocket断开连接	2026-06-30 08:52:33.913621
614	100100	offline	设备WebSocket断开连接	2026-06-30 08:55:36.398215
615	100100	offline	设备WebSocket断开连接	2026-06-30 08:56:16.642797
616	100101	offline	设备WebSocket断开连接	2026-06-30 08:56:16.670622
617	100101	offline	设备WebSocket断开连接	2026-06-30 08:57:26.67134
618	100100	offline	设备WebSocket断开连接	2026-06-30 08:57:26.673931
619	100100	offline	设备WebSocket断开连接	2026-06-30 09:10:00.045233
620	100101	online	设备WebSocket连接建立	2026-06-30 09:10:16.260698
621	100100	offline	设备WebSocket断开连接	2026-06-30 09:17:45.010143
622	100101	offline	设备WebSocket断开连接	2026-06-30 09:17:45.0765
623	100100	offline	设备WebSocket断开连接	2026-06-30 09:27:38.769709
624	100101	offline	设备WebSocket断开连接	2026-06-30 09:27:48.023133
625	100101	offline	设备WebSocket断开连接	2026-06-30 09:34:35.616797
626	100101	online	设备WebSocket连接建立	2026-06-30 09:35:26.509557
627	100101	online	设备WebSocket连接建立	2026-06-30 10:14:19.82012
628	100100	offline	设备WebSocket断开连接	2026-06-30 10:25:49.82593
629	100101	offline	设备WebSocket断开连接	2026-06-30 17:51:34.759247
630	100100	offline	设备WebSocket断开连接	2026-06-30 18:34:21.042295
631	100100	offline	设备WebSocket断开连接	2026-06-30 18:35:22.294041
632	100101	offline	设备WebSocket断开连接	2026-06-30 20:21:29.361977
633	100100	offline	设备WebSocket断开连接	2026-06-30 20:58:09.527219
634	100101	offline	设备WebSocket断开连接	2026-06-30 21:28:16.274963
635	100100	offline	设备WebSocket断开连接	2026-06-30 21:32:44.002076
636	100100	online	设备WebSocket连接建立	2026-06-30 21:33:02.444974
637	100100	online	设备WebSocket连接建立	2026-07-01 07:57:40.227482
638	100100	offline	设备WebSocket断开连接	2026-07-01 09:07:21.328298
639	100100	offline	设备WebSocket断开连接	2026-07-01 09:13:29.490944
640	100103	online	设备WebSocket连接建立	2026-07-01 09:16:56.921533
641	100103	offline	设备WebSocket断开连接	2026-07-01 09:17:48.84099
642	100103	online	设备WebSocket连接建立	2026-07-01 09:17:55.129797
643	100100	online	设备WebSocket连接建立	2026-07-01 12:13:35.289739
644	100101	online	设备WebSocket连接建立	2026-07-01 12:13:50.62572
645	100103	online	设备WebSocket连接建立	2026-07-01 12:13:53.702109
646	100100	offline	设备WebSocket断开连接	2026-07-01 16:53:51.097564
647	100100	online	设备WebSocket连接建立	2026-07-01 17:04:10.065991
648	100103	online	设备WebSocket连接建立	2026-07-01 17:31:59.193722
649	100101	online	设备WebSocket连接建立	2026-07-01 17:32:26.219811
650	100103	online	设备WebSocket连接建立	2026-07-01 17:43:29.212026
651	100101	online	设备WebSocket连接建立	2026-07-01 17:43:54.04698
652	100100	offline	设备WebSocket断开连接	2026-07-01 18:15:41.120669
653	100100	online	设备WebSocket连接建立	2026-07-01 18:16:04.438103
654	100100	offline	设备WebSocket断开连接	2026-07-01 18:17:28.815282
655	100100	online	设备WebSocket连接建立	2026-07-01 18:38:42.270008
656	100100	offline	设备WebSocket断开连接	2026-07-01 18:44:31.280659
657	100100	online	设备WebSocket连接建立	2026-07-01 18:44:40.799486
658	100100	offline	设备WebSocket断开连接	2026-07-01 18:53:19.8004
659	100100	online	设备WebSocket连接建立	2026-07-01 18:53:29.262038
660	100100	offline	设备WebSocket断开连接	2026-07-01 19:08:31.04398
661	100100	online	设备WebSocket连接建立	2026-07-01 19:08:40.268276
662	100100	offline	设备WebSocket断开连接	2026-07-01 19:19:51.306075
663	100100	online	设备WebSocket连接建立	2026-07-01 19:20:00.692582
664	100100	offline	设备WebSocket断开连接	2026-07-01 19:47:36.225951
665	100100	online	设备WebSocket连接建立	2026-07-01 19:47:45.722528
666	100100	offline	设备WebSocket断开连接	2026-07-01 20:12:50.152082
667	100100	online	设备WebSocket连接建立	2026-07-01 20:12:59.276272
668	100100	offline	设备WebSocket断开连接	2026-07-01 20:42:11.836229
669	100100	online	设备WebSocket连接建立	2026-07-01 20:42:21.116629
670	100100	offline	设备WebSocket断开连接	2026-07-01 20:47:02.743882
671	100100	online	设备WebSocket连接建立	2026-07-01 20:47:12.057377
672	100100	offline	设备WebSocket断开连接	2026-07-01 20:50:16.460774
673	100100	online	设备WebSocket连接建立	2026-07-01 20:50:38.714118
674	100100	offline	设备WebSocket断开连接	2026-07-01 21:51:53.766372
675	100101	online	设备WebSocket连接建立	2026-07-02 09:52:59.686098
676	100103	online	设备WebSocket连接建立	2026-07-02 09:53:01.097443
677	100100	online	设备WebSocket连接建立	2026-07-02 15:32:46.677438
678	100100	online	设备WebSocket连接建立	2026-07-02 21:47:10.548724
679	100100	offline	设备WebSocket断开连接	2026-07-02 22:00:24.744669
680	100100	online	设备WebSocket连接建立	2026-07-02 22:00:24.749037
681	100100	offline	设备WebSocket断开连接	2026-07-02 22:04:16.30132
682	100100	online	设备WebSocket连接建立	2026-07-02 22:04:22.495849
\.


--
-- Data for Name: device_logs; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.device_logs (id, device_id, logs, create_time, log_type, content, level, detail, device_name, status) FROM stdin;
1	TEST_DEVICE_001	["heartbeat", "温度正常"]	2026-06-17 08:34:11	heartbeat	["heartbeat", "温度正常"]	info	\N	\N	\N
2	TEST_DEVICE_001	["heartbeat"]	2026-06-17 09:18:20	heartbeat	["heartbeat"]	info	\N	\N	\N
3	TEST_DEVICE_001	["heartbeat"]	2026-06-17 09:19:09	heartbeat	["heartbeat"]	info	\N	\N	\N
4	DEV001	["hb"]	2026-06-17 09:20:53	heartbeat	["hb"]	info	\N	\N	\N
5	123456	["test"]	2026-06-17 20:39:30	info	["test"]	info	\N	智能寄存柜	\N
6	123456	["test"]	2026-06-17 20:41:58	info	["test"]	info	\N	智能寄存柜	\N
7	123456	"test log"	2026-06-17 21:04:11	info	"test log"	info	\N	智能寄存柜	\N
8	123456	"test log"	2026-06-17 21:05:17	info	"test log"	info	\N	智能寄存柜	\N
9	123456	"test"	2026-06-17 21:07:59	info	"test"	info	\N	智能寄存柜	\N
10	123456	\N	2026-06-23 09:05:44	online	设备WebSocket连接建立	info	\N	\N	\N
11	123456	\N	2026-06-23 09:07:55	online	设备WebSocket连接建立	info	\N	\N	\N
12	123456	\N	2026-06-23 09:49:53	online	设备WebSocket连接建立	info	\N	\N	\N
13	123456	\N	2026-06-23 09:50:58	online	设备WebSocket连接建立	info	\N	\N	\N
14	123456	\N	2026-06-23 09:51:06	online	设备WebSocket连接建立	info	\N	\N	\N
15	123456	\N	2026-06-23 09:51:41	online	设备WebSocket连接建立	info	\N	\N	\N
16	123456	\N	2026-06-23 10:03:15	online	设备WebSocket连接建立	info	\N	\N	\N
17	123456	\N	2026-06-23 10:07:12	online	设备WebSocket连接建立	info	\N	\N	\N
18	123456	\N	2026-06-23 10:11:25	online	设备WebSocket连接建立	info	\N	\N	\N
19	123456	\N	2026-06-23 10:51:47	online	设备WebSocket连接建立	info	\N	\N	\N
20	123456	\N	2026-06-23 10:57:05	online	设备WebSocket连接建立	info	\N	\N	\N
21	123456	\N	2026-06-23 11:08:49	online	设备WebSocket连接建立	info	\N	\N	\N
22	123456	\N	2026-06-23 11:29:42	online	设备WebSocket连接建立	info	\N	\N	\N
23	123456	\N	2026-06-23 11:31:32	online	设备WebSocket连接建立	info	\N	\N	\N
24	123456	\N	2026-06-23 11:32:07	online	设备WebSocket连接建立	info	\N	\N	\N
25	123456	\N	2026-06-23 11:35:30	online	设备WebSocket连接建立	info	\N	\N	\N
26	123456	\N	2026-06-23 11:38:20	online	设备WebSocket连接建立	info	\N	\N	\N
27	123456	\N	2026-06-23 11:55:10	online	设备WebSocket连接建立	info	\N	\N	\N
28	123456	\N	2026-06-23 12:03:43	online	设备WebSocket连接建立	info	\N	\N	\N
29	123456	\N	2026-06-23 12:28:04	online	设备WebSocket连接建立	info	\N	\N	\N
30	123456	\N	2026-06-23 12:57:49	online	设备WebSocket连接建立	info	\N	\N	\N
31	123456	\N	2026-06-23 13:41:26	online	设备WebSocket连接建立	info	\N	\N	\N
32	123456	\N	2026-06-23 14:39:40	online	设备WebSocket连接建立	info	\N	\N	\N
33	123456	\N	2026-06-23 15:06:21	online	设备WebSocket连接建立	info	\N	\N	\N
34	123456	\N	2026-06-23 15:16:49	online	设备WebSocket连接建立	info	\N	\N	\N
35	123456	\N	2026-06-23 15:44:35	online	设备WebSocket连接建立	info	\N	\N	\N
36	123456	\N	2026-06-23 15:55:15	online	设备WebSocket连接建立	info	\N	\N	\N
37	123456	\N	2026-06-23 15:55:54	online	设备WebSocket连接建立	info	\N	\N	\N
38	123456	\N	2026-06-23 16:11:29	online	设备WebSocket连接建立	info	\N	\N	\N
39	123456	\N	2026-06-23 16:33:33	online	设备WebSocket连接建立	info	\N	\N	\N
40	123456	\N	2026-06-23 17:12:21	online	设备WebSocket连接建立	info	\N	\N	\N
41	123456	\N	2026-06-23 23:04:59	online	设备WebSocket连接建立	info	\N	\N	\N
42	123456	\N	2026-06-23 23:20:49	online	设备WebSocket连接建立	info	\N	\N	\N
43	123456	\N	2026-06-23 23:22:15	online	设备WebSocket连接建立	info	\N	\N	\N
44	123456	\N	2026-06-23 23:23:27	online	设备WebSocket连接建立	info	\N	\N	\N
45	123456	\N	2026-06-23 23:42:25	online	设备WebSocket连接建立	info	\N	\N	\N
46	123456	\N	2026-06-24 00:26:18	online	设备WebSocket连接建立	info	\N	\N	\N
47	123456	\N	2026-06-24 00:47:20	online	设备WebSocket连接建立	info	\N	\N	\N
48	123456	\N	2026-06-24 00:52:06	online	设备WebSocket连接建立	info	\N	\N	\N
49	123456	\N	2026-06-24 01:13:53	online	设备WebSocket连接建立	info	\N	\N	\N
50	123456	\N	2026-06-24 01:32:09	online	设备WebSocket连接建立	info	\N	\N	\N
51	123456	\N	2026-06-24 01:46:25	online	设备WebSocket连接建立	info	\N	\N	\N
52	123456	\N	2026-06-24 01:49:16	offline	设备WebSocket断开连接	warning	\N	\N	\N
53	123456	\N	2026-06-24 01:49:33	online	设备WebSocket连接建立	info	\N	\N	\N
54	123456	\N	2026-06-24 01:50:28	offline	设备WebSocket断开连接	warning	\N	\N	\N
55	123456	\N	2026-06-24 01:50:31	online	设备WebSocket连接建立	info	\N	\N	\N
56	123456	\N	2026-06-24 01:55:57	online	设备WebSocket连接建立	info	\N	\N	\N
57	123456	\N	2026-06-24 01:58:57	offline	设备WebSocket断开连接	warning	\N	\N	\N
58	123456	\N	2026-06-24 01:59:16	online	设备WebSocket连接建立	info	\N	\N	\N
59	123456	\N	2026-06-24 02:08:47	offline	设备WebSocket断开连接	warning	\N	\N	\N
60	123456	\N	2026-06-24 02:09:17	online	设备WebSocket连接建立	info	\N	\N	\N
61	123456	\N	2026-06-24 02:14:26	online	设备WebSocket连接建立	info	\N	\N	\N
62	123456	\N	2026-06-24 02:19:28	online	设备WebSocket连接建立	info	\N	\N	\N
63	123456	\N	2026-06-24 02:20:35	online	设备WebSocket连接建立	info	\N	\N	\N
64	123456	\N	2026-06-24 02:24:40	online	设备WebSocket连接建立	info	\N	\N	\N
65	123456	\N	2026-06-24 02:26:09	offline	设备WebSocket断开连接	warning	\N	\N	\N
66	123456	\N	2026-06-24 02:26:09	online	设备WebSocket连接建立	info	\N	\N	\N
67	123456	\N	2026-06-24 02:26:09	online	设备WebSocket连接建立	info	\N	\N	\N
68	123456	\N	2026-06-24 02:26:11	online	设备WebSocket连接建立	info	\N	\N	\N
69	123456	\N	2026-06-24 02:26:12	online	设备WebSocket连接建立	info	\N	\N	\N
70	123456	\N	2026-06-24 02:28:18	offline	设备WebSocket断开连接	warning	\N	\N	\N
71	123456	\N	2026-06-24 02:28:20	online	设备WebSocket连接建立	info	\N	\N	\N
72	123456	\N	2026-06-24 02:34:36	online	设备WebSocket连接建立	info	\N	\N	\N
73	123456	\N	2026-06-24 02:49:26	online	设备WebSocket连接建立	info	\N	\N	\N
74	123456	\N	2026-06-24 02:54:05	online	设备WebSocket连接建立	info	\N	\N	\N
75	123456	\N	2026-06-24 03:09:06	online	设备WebSocket连接建立	info	\N	\N	\N
76	123456	\N	2026-06-24 03:12:18	online	设备WebSocket连接建立	info	\N	\N	\N
77	123456	\N	2026-06-24 03:17:40	online	设备WebSocket连接建立	info	\N	\N	\N
78	123456	\N	2026-06-24 03:21:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
79	123456	\N	2026-06-24 03:21:38	online	设备WebSocket连接建立	info	\N	\N	\N
80	123456	\N	2026-06-24 03:22:21	online	设备WebSocket连接建立	info	\N	\N	\N
81	123456	\N	2026-06-24 03:40:41	online	设备WebSocket连接建立	info	\N	\N	\N
82	123456	\N	2026-06-24 03:42:20	offline	设备WebSocket断开连接	warning	\N	\N	\N
83	123456	\N	2026-06-24 03:42:26	online	设备WebSocket连接建立	info	\N	\N	\N
84	123456	\N	2026-06-24 03:45:03	offline	设备WebSocket断开连接	warning	\N	\N	\N
85	123456	\N	2026-06-24 03:45:04	online	设备WebSocket连接建立	info	\N	\N	\N
86	123456	\N	2026-06-24 03:45:04	online	设备WebSocket连接建立	info	\N	\N	\N
87	123456	\N	2026-06-24 03:45:05	online	设备WebSocket连接建立	info	\N	\N	\N
88	123456	\N	2026-06-24 03:45:07	online	设备WebSocket连接建立	info	\N	\N	\N
89	123456	\N	2026-06-24 03:45:08	online	设备WebSocket连接建立	info	\N	\N	\N
90	123456	\N	2026-06-24 03:47:04	offline	设备WebSocket断开连接	warning	\N	\N	\N
91	123456	\N	2026-06-24 03:47:05	online	设备WebSocket连接建立	info	\N	\N	\N
92	123456	\N	2026-06-24 03:51:41	online	设备WebSocket连接建立	info	\N	\N	\N
93	123456	\N	2026-06-24 03:53:32	online	设备WebSocket连接建立	info	\N	\N	\N
94	123456	\N	2026-06-24 03:55:06	online	设备WebSocket连接建立	info	\N	\N	\N
95	123456	\N	2026-06-24 03:55:40	online	设备WebSocket连接建立	info	\N	\N	\N
96	123456	\N	2026-06-24 04:14:03	online	设备WebSocket连接建立	info	\N	\N	\N
97	123456	\N	2026-06-24 04:23:21	offline	设备WebSocket断开连接	warning	\N	\N	\N
98	123456	\N	2026-06-24 04:23:27	online	设备WebSocket连接建立	info	\N	\N	\N
99	123456	\N	2026-06-24 04:24:12	online	设备WebSocket连接建立	info	\N	\N	\N
100	123456	\N	2026-06-24 04:25:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
101	123456	\N	2026-06-24 04:25:30	online	设备WebSocket连接建立	info	\N	\N	\N
102	123456	\N	2026-06-24 04:39:41	online	设备WebSocket连接建立	info	\N	\N	\N
103	123456	\N	2026-06-24 04:51:31	online	设备WebSocket连接建立	info	\N	\N	\N
104	123456	\N	2026-06-24 04:53:00	online	设备WebSocket连接建立	info	\N	\N	\N
105	123456	\N	2026-06-24 04:56:27	offline	设备WebSocket断开连接	warning	\N	\N	\N
106	123456	\N	2026-06-24 04:56:38	online	设备WebSocket连接建立	info	\N	\N	\N
107	123456	\N	2026-06-24 04:56:47	offline	设备WebSocket断开连接	warning	\N	\N	\N
108	123456	\N	2026-06-24 04:56:56	online	设备WebSocket连接建立	info	\N	\N	\N
109	123456	\N	2026-06-24 05:55:58	online	设备WebSocket连接建立	info	\N	\N	\N
110	123456	\N	2026-06-24 05:58:16	online	设备WebSocket连接建立	info	\N	\N	\N
111	123456	\N	2026-06-24 06:10:44	online	设备WebSocket连接建立	info	\N	\N	\N
112	123456	\N	2026-06-24 06:29:38	online	设备WebSocket连接建立	info	\N	\N	\N
113	123456	\N	2026-06-24 06:34:44	offline	设备WebSocket断开连接	warning	\N	\N	\N
114	123456	\N	2026-06-24 06:34:45	online	设备WebSocket连接建立	info	\N	\N	\N
115	123456	\N	2026-06-24 06:34:45	online	设备WebSocket连接建立	info	\N	\N	\N
116	123456	\N	2026-06-24 06:34:57	offline	设备WebSocket断开连接	warning	\N	\N	\N
117	123456	\N	2026-06-24 06:34:58	online	设备WebSocket连接建立	info	\N	\N	\N
118	123456	\N	2026-06-24 06:41:37	online	设备WebSocket连接建立	info	\N	\N	\N
119	123456	\N	2026-06-24 07:14:13	online	设备WebSocket连接建立	info	\N	\N	\N
120	123456	\N	2026-06-24 07:16:27	online	设备WebSocket连接建立	info	\N	\N	\N
121	123456	\N	2026-06-24 07:20:05	online	设备WebSocket连接建立	info	\N	\N	\N
122	123456	\N	2026-06-24 07:30:28	online	设备WebSocket连接建立	info	\N	\N	\N
123	123456	\N	2026-06-24 07:31:14	offline	设备WebSocket断开连接	warning	\N	\N	\N
124	123456	\N	2026-06-24 07:31:20	online	设备WebSocket连接建立	info	\N	\N	\N
125	123456	\N	2026-06-24 07:31:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
126	123456	\N	2026-06-24 07:31:39	online	设备WebSocket连接建立	info	\N	\N	\N
127	123456	\N	2026-06-24 07:36:53	online	设备WebSocket连接建立	info	\N	\N	\N
128	123456	\N	2026-06-24 07:37:08	offline	设备WebSocket断开连接	warning	\N	\N	\N
129	123456	\N	2026-06-24 07:37:17	online	设备WebSocket连接建立	info	\N	\N	\N
130	123456	\N	2026-06-24 07:37:38	offline	设备WebSocket断开连接	warning	\N	\N	\N
131	123456	\N	2026-06-24 08:32:10	online	设备WebSocket连接建立	info	\N	\N	\N
132	123456	\N	2026-06-24 08:55:33	offline	设备WebSocket断开连接	warning	\N	\N	\N
133	123456	\N	2026-06-24 08:56:12	online	设备WebSocket连接建立	info	\N	\N	\N
134	123456	\N	2026-06-24 08:56:23	offline	设备WebSocket断开连接	warning	\N	\N	\N
135	123456	\N	2026-06-24 08:56:23	online	设备WebSocket连接建立	info	\N	\N	\N
136	123456	\N	2026-06-24 08:56:23	online	设备WebSocket连接建立	info	\N	\N	\N
137	123456	\N	2026-06-24 08:56:31	offline	设备WebSocket断开连接	warning	\N	\N	\N
138	123456	\N	2026-06-24 08:56:32	online	设备WebSocket连接建立	info	\N	\N	\N
139	123456	\N	2026-06-24 09:09:45	offline	设备WebSocket断开连接	warning	\N	\N	\N
140	123456	\N	2026-06-24 09:09:46	online	设备WebSocket连接建立	info	\N	\N	\N
141	123456	\N	2026-06-24 09:09:46	online	设备WebSocket连接建立	info	\N	\N	\N
142	123456	\N	2026-06-24 09:09:47	online	设备WebSocket连接建立	info	\N	\N	\N
143	123456	\N	2026-06-24 09:09:49	online	设备WebSocket连接建立	info	\N	\N	\N
144	123456	\N	2026-06-24 09:09:50	online	设备WebSocket连接建立	info	\N	\N	\N
145	123456	\N	2026-06-24 09:09:51	online	设备WebSocket连接建立	info	\N	\N	\N
146	123456	\N	2026-06-24 09:09:53	online	设备WebSocket连接建立	info	\N	\N	\N
147	123456	\N	2026-06-24 09:09:54	online	设备WebSocket连接建立	info	\N	\N	\N
148	123456	\N	2026-06-24 09:29:05	offline	设备WebSocket断开连接	warning	\N	\N	\N
149	123456	\N	2026-06-24 09:29:06	online	设备WebSocket连接建立	info	\N	\N	\N
150	123456	\N	2026-06-24 09:29:17	offline	设备WebSocket断开连接	warning	\N	\N	\N
151	123456	\N	2026-06-24 09:29:18	online	设备WebSocket连接建立	info	\N	\N	\N
152	123456	\N	2026-06-24 09:29:18	online	设备WebSocket连接建立	info	\N	\N	\N
153	123456	\N	2026-06-24 09:29:19	online	设备WebSocket连接建立	info	\N	\N	\N
154	123456	\N	2026-06-24 09:29:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
155	123456	\N	2026-06-24 09:29:26	online	设备WebSocket连接建立	info	\N	\N	\N
156	123456	\N	2026-06-24 09:32:39	offline	设备WebSocket断开连接	warning	\N	\N	\N
157	123456	\N	2026-06-24 09:32:40	online	设备WebSocket连接建立	info	\N	\N	\N
158	123456	\N	2026-06-24 09:32:40	online	设备WebSocket连接建立	info	\N	\N	\N
159	123456	\N	2026-06-24 09:32:41	online	设备WebSocket连接建立	info	\N	\N	\N
160	123456	\N	2026-06-24 09:32:42	online	设备WebSocket连接建立	info	\N	\N	\N
161	123456	\N	2026-06-24 09:32:43	online	设备WebSocket连接建立	info	\N	\N	\N
162	123456	\N	2026-06-24 09:32:58	offline	设备WebSocket断开连接	warning	\N	\N	\N
163	123456	\N	2026-06-24 09:32:59	online	设备WebSocket连接建立	info	\N	\N	\N
164	123456	\N	2026-06-24 09:38:16	online	设备WebSocket连接建立	info	\N	\N	\N
165	123456	\N	2026-06-24 09:38:45	offline	设备WebSocket断开连接	warning	\N	\N	\N
166	123456	\N	2026-06-24 09:38:46	online	设备WebSocket连接建立	info	\N	\N	\N
167	123456	\N	2026-06-24 09:38:46	online	设备WebSocket连接建立	info	\N	\N	\N
168	123456	\N	2026-06-24 09:38:47	online	设备WebSocket连接建立	info	\N	\N	\N
169	123456	\N	2026-06-24 09:38:49	online	设备WebSocket连接建立	info	\N	\N	\N
170	123456	\N	2026-06-24 09:40:13	online	设备WebSocket连接建立	info	\N	\N	\N
171	123456	\N	2026-06-24 09:51:25	online	设备WebSocket连接建立	info	\N	\N	\N
172	123456	\N	2026-06-24 09:51:45	online	设备WebSocket连接建立	info	\N	\N	\N
173	123456	\N	2026-06-24 09:53:51	online	设备WebSocket连接建立	info	\N	\N	\N
174	123456	\N	2026-06-24 09:55:19	online	设备WebSocket连接建立	info	\N	\N	\N
175	123456	\N	2026-06-24 10:01:30	online	设备WebSocket连接建立	info	\N	\N	\N
176	123456	\N	2026-06-24 10:05:54	online	设备WebSocket连接建立	info	\N	\N	\N
177	123456	\N	2026-06-24 10:14:44	online	设备WebSocket连接建立	info	\N	\N	\N
178	123456	\N	2026-06-24 10:28:19	online	设备WebSocket连接建立	info	\N	\N	\N
179	123456	\N	2026-06-24 10:32:26	online	设备WebSocket连接建立	info	\N	\N	\N
180	123456	\N	2026-06-24 10:34:09	online	设备WebSocket连接建立	info	\N	\N	\N
181	123456	\N	2026-06-24 10:35:29	online	设备WebSocket连接建立	info	\N	\N	\N
182	123456	\N	2026-06-24 11:39:13	offline	设备WebSocket断开连接	warning	\N	\N	\N
183	123456	\N	2026-06-24 12:05:23	online	设备WebSocket连接建立	info	\N	\N	\N
184	123456	\N	2026-06-24 12:07:39	online	设备WebSocket连接建立	info	\N	\N	\N
185	123456	\N	2026-06-24 12:15:45	online	设备WebSocket连接建立	info	\N	\N	\N
186	123456	\N	2026-06-24 12:19:37	offline	设备WebSocket断开连接	warning	\N	\N	\N
187	123456	\N	2026-06-24 12:19:39	online	设备WebSocket连接建立	info	\N	\N	\N
188	123456	\N	2026-06-24 14:22:44	online	设备WebSocket连接建立	info	\N	\N	\N
189	123456	\N	2026-06-24 14:30:17	online	设备WebSocket连接建立	info	\N	\N	\N
190	123456	\N	2026-06-24 14:39:13	online	设备WebSocket连接建立	info	\N	\N	\N
191	123456	\N	2026-06-24 14:44:41	online	设备WebSocket连接建立	info	\N	\N	\N
192	123456	\N	2026-06-24 15:04:18	online	设备WebSocket连接建立	info	\N	\N	\N
193	123456	\N	2026-06-24 15:19:32	online	设备WebSocket连接建立	info	\N	\N	\N
194	123456	\N	2026-06-24 15:35:42	online	设备WebSocket连接建立	info	\N	\N	\N
195	123456	\N	2026-06-24 15:52:31	offline	设备WebSocket断开连接	warning	\N	\N	\N
196	123456	\N	2026-06-24 15:52:32	online	设备WebSocket连接建立	info	\N	\N	\N
197	123456	\N	2026-06-24 16:07:28	offline	设备WebSocket断开连接	warning	\N	\N	\N
198	123456	\N	2026-06-24 16:07:30	online	设备WebSocket连接建立	info	\N	\N	\N
199	123456	\N	2026-06-24 16:15:40	offline	设备WebSocket断开连接	warning	\N	\N	\N
200	123456	\N	2026-06-24 16:15:42	online	设备WebSocket连接建立	info	\N	\N	\N
201	123456	\N	2026-06-24 16:17:17	offline	设备WebSocket断开连接	warning	\N	\N	\N
202	123456	\N	2026-06-24 16:17:19	online	设备WebSocket连接建立	info	\N	\N	\N
203	123456	\N	2026-06-24 16:25:50	offline	设备WebSocket断开连接	warning	\N	\N	\N
204	123456	\N	2026-06-24 16:25:52	online	设备WebSocket连接建立	info	\N	\N	\N
205	123456	\N	2026-06-24 16:31:05	online	设备WebSocket连接建立	info	\N	\N	\N
206	123456	\N	2026-06-24 16:31:17	online	设备WebSocket连接建立	info	\N	\N	\N
207	123456	\N	2026-06-24 22:42:17	offline	设备WebSocket断开连接	warning	\N	\N	\N
208	123456	\N	2026-06-24 22:42:18	online	设备WebSocket连接建立	info	\N	\N	\N
209	123456	\N	2026-06-24 23:03:11	offline	设备WebSocket断开连接	warning	\N	\N	\N
210	123456	\N	2026-06-24 23:03:13	online	设备WebSocket连接建立	info	\N	\N	\N
211	123456	\N	2026-06-25 00:22:02	offline	设备WebSocket断开连接	warning	\N	\N	\N
212	123456	\N	2026-06-25 00:22:04	online	设备WebSocket连接建立	info	\N	\N	\N
213	123456	\N	2026-06-25 00:23:21	offline	设备WebSocket断开连接	warning	\N	\N	\N
214	123456	\N	2026-06-25 00:23:22	online	设备WebSocket连接建立	info	\N	\N	\N
215	123456	\N	2026-06-25 00:24:12	offline	设备WebSocket断开连接	warning	\N	\N	\N
216	123456	\N	2026-06-25 00:24:14	online	设备WebSocket连接建立	info	\N	\N	\N
217	123456	\N	2026-06-25 00:32:18	online	设备WebSocket连接建立	info	\N	\N	\N
218	123456	\N	2026-06-25 02:02:24	online	设备WebSocket连接建立	info	\N	\N	\N
219	123456	\N	2026-06-25 02:19:17	online	设备WebSocket连接建立	info	\N	\N	\N
220	123456	\N	2026-06-25 02:33:16	online	设备WebSocket连接建立	info	\N	\N	\N
221	123456	\N	2026-06-25 02:42:13	online	设备WebSocket连接建立	info	\N	\N	\N
222	123456	\N	2026-06-25 02:43:52	online	设备WebSocket连接建立	info	\N	\N	\N
223	123456	\N	2026-06-25 02:51:52	online	设备WebSocket连接建立	info	\N	\N	\N
224	123456	\N	2026-06-25 03:29:48	online	设备WebSocket连接建立	info	\N	\N	\N
225	123456	\N	2026-06-25 03:50:42	online	设备WebSocket连接建立	info	\N	\N	\N
226	123456	\N	2026-06-25 04:00:57	online	设备WebSocket连接建立	info	\N	\N	\N
227	123456	\N	2026-06-25 04:03:05	online	设备WebSocket连接建立	info	\N	\N	\N
228	123456	\N	2026-06-25 04:03:28	online	设备WebSocket连接建立	info	\N	\N	\N
229	123456	\N	2026-06-25 04:04:27	online	设备WebSocket连接建立	info	\N	\N	\N
230	123456	\N	2026-06-25 04:05:56	online	设备WebSocket连接建立	info	\N	\N	\N
231	123456	\N	2026-06-25 04:06:06	online	设备WebSocket连接建立	info	\N	\N	\N
232	123456	\N	2026-06-25 04:11:56	online	设备WebSocket连接建立	info	\N	\N	\N
233	123456	\N	2026-06-25 04:11:59	online	设备WebSocket连接建立	info	\N	\N	\N
234	123456	\N	2026-06-25 04:20:58	online	设备WebSocket连接建立	info	\N	\N	\N
235	123456	\N	2026-06-25 04:21:01	online	设备WebSocket连接建立	info	\N	\N	\N
236	123456	\N	2026-06-25 04:59:08	online	设备WebSocket连接建立	info	\N	\N	\N
237	123456	\N	2026-06-25 04:59:11	online	设备WebSocket连接建立	info	\N	\N	\N
238	123456	\N	2026-06-25 06:24:14	online	设备WebSocket连接建立	info	\N	\N	\N
239	123456	\N	2026-06-25 06:24:16	online	设备WebSocket连接建立	info	\N	\N	\N
240	123456	\N	2026-06-25 06:41:57	online	设备WebSocket连接建立	info	\N	\N	\N
241	123456	\N	2026-06-25 06:42:00	online	设备WebSocket连接建立	info	\N	\N	\N
242	123456	\N	2026-06-25 06:46:26	online	设备WebSocket连接建立	info	\N	\N	\N
243	123456	\N	2026-06-25 06:46:30	online	设备WebSocket连接建立	info	\N	\N	\N
244	123456	\N	2026-06-25 08:13:36	online	设备WebSocket连接建立	info	\N	\N	\N
245	123456	\N	2026-06-25 08:32:12	online	设备WebSocket连接建立	info	\N	\N	\N
246	123456	\N	2026-06-25 08:36:49	online	设备WebSocket连接建立	info	\N	\N	\N
247	123456	\N	2026-06-25 08:39:02	online	设备WebSocket连接建立	info	\N	\N	\N
248	123456	\N	2026-06-25 08:55:23	online	设备WebSocket连接建立	info	\N	\N	\N
249	123456	\N	2026-06-25 09:04:16	online	设备WebSocket连接建立	info	\N	\N	\N
250	123456	\N	2026-06-25 09:05:58	online	设备WebSocket连接建立	info	\N	\N	\N
251	123456	\N	2026-06-25 09:06:01	online	设备WebSocket连接建立	info	\N	\N	\N
252	123456	\N	2026-06-25 09:12:02	online	设备WebSocket连接建立	info	\N	\N	\N
253	123456	\N	2026-06-25 09:12:34	online	设备WebSocket连接建立	info	\N	\N	\N
254	123456	\N	2026-06-25 09:26:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
255	123456	\N	2026-06-25 09:26:29	online	设备WebSocket连接建立	info	\N	\N	\N
256	123456	\N	2026-06-25 09:30:50	online	设备WebSocket连接建立	info	\N	\N	\N
257	123456	\N	2026-06-25 09:34:27	offline	设备WebSocket断开连接	warning	\N	\N	\N
258	123456	\N	2026-06-25 09:34:28	online	设备WebSocket连接建立	info	\N	\N	\N
259	123456	\N	2026-06-25 09:41:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
260	123456	\N	2026-06-25 09:41:30	online	设备WebSocket连接建立	info	\N	\N	\N
261	123456	\N	2026-06-25 09:41:37	online	设备WebSocket连接建立	info	\N	\N	\N
262	123456	\N	2026-06-25 09:44:59	online	设备WebSocket连接建立	info	\N	\N	\N
263	123456	\N	2026-06-25 09:48:42	offline	设备WebSocket断开连接	warning	\N	\N	\N
264	123456	\N	2026-06-25 09:48:42	online	设备WebSocket连接建立	info	\N	\N	\N
265	123456	\N	2026-06-25 09:48:42	online	设备WebSocket连接建立	info	\N	\N	\N
266	123456	\N	2026-06-25 09:49:32	online	设备WebSocket连接建立	info	\N	\N	\N
267	123456	\N	2026-06-25 09:52:50	offline	设备WebSocket断开连接	warning	\N	\N	\N
268	123456	\N	2026-06-25 09:52:50	online	设备WebSocket连接建立	info	\N	\N	\N
269	123456	\N	2026-06-25 09:55:45	online	设备WebSocket连接建立	info	\N	\N	\N
270	123456	\N	2026-06-25 09:58:19	online	设备WebSocket连接建立	info	\N	\N	\N
271	123456	\N	2026-06-25 10:01:44	online	设备WebSocket连接建立	info	\N	\N	\N
272	123456	\N	2026-06-25 10:03:32	online	设备WebSocket连接建立	info	\N	\N	\N
273	123456	\N	2026-06-25 10:03:40	online	设备WebSocket连接建立	info	\N	\N	\N
274	123456	\N	2026-06-25 10:07:34	online	设备WebSocket连接建立	info	\N	\N	\N
275	123456	\N	2026-06-25 10:15:11	online	设备WebSocket连接建立	info	\N	\N	\N
276	123456	\N	2026-06-25 10:37:36	online	设备WebSocket连接建立	info	\N	\N	\N
277	123456	\N	2026-06-25 10:38:27	online	设备WebSocket连接建立	info	\N	\N	\N
278	123456	\N	2026-06-25 10:40:17	online	设备WebSocket连接建立	info	\N	\N	\N
279	123456	\N	2026-06-25 10:41:53	online	设备WebSocket连接建立	info	\N	\N	\N
280	123456	\N	2026-06-25 10:46:41	online	设备WebSocket连接建立	info	\N	\N	\N
281	123456	\N	2026-06-25 10:51:52	online	设备WebSocket连接建立	info	\N	\N	\N
282	123456	\N	2026-06-25 10:56:13	offline	设备WebSocket断开连接	warning	\N	\N	\N
283	123456	\N	2026-06-25 10:56:14	online	设备WebSocket连接建立	info	\N	\N	\N
284	123456	\N	2026-06-25 11:14:23	online	设备WebSocket连接建立	info	\N	\N	\N
285	123456	\N	2026-06-25 11:16:25	online	设备WebSocket连接建立	info	\N	\N	\N
286	123456	\N	2026-06-25 11:18:52	online	设备WebSocket连接建立	info	\N	\N	\N
287	101002	\N	2026-06-25 11:19:38	online	设备WebSocket连接建立	info	\N	\N	\N
288	123456	\N	2026-06-25 11:20:50	online	设备WebSocket连接建立	info	\N	\N	\N
289	101002	\N	2026-06-25 11:20:50	online	设备WebSocket连接建立	info	\N	\N	\N
290	123456	\N	2026-06-25 11:22:57	online	设备WebSocket连接建立	info	\N	\N	\N
291	101002	\N	2026-06-25 11:22:57	online	设备WebSocket连接建立	info	\N	\N	\N
292	123456	\N	2026-06-25 11:23:42	online	设备WebSocket连接建立	info	\N	\N	\N
293	101002	\N	2026-06-25 11:23:42	online	设备WebSocket连接建立	info	\N	\N	\N
294	123456	\N	2026-06-25 11:25:10	online	设备WebSocket连接建立	info	\N	\N	\N
295	101002	\N	2026-06-25 11:25:10	online	设备WebSocket连接建立	info	\N	\N	\N
296	123456	\N	2026-06-25 11:26:22	online	设备WebSocket连接建立	info	\N	\N	\N
297	101002	\N	2026-06-25 11:26:22	online	设备WebSocket连接建立	info	\N	\N	\N
298	123456	\N	2026-06-25 11:42:03	online	设备WebSocket连接建立	info	\N	\N	\N
299	123456	\N	2026-06-25 12:15:58	online	设备WebSocket连接建立	info	\N	\N	\N
300	123456	\N	2026-06-25 12:26:28	online	设备WebSocket连接建立	info	\N	\N	\N
301	123456	\N	2026-06-25 12:27:34	online	设备WebSocket连接建立	info	\N	\N	\N
302	123456	\N	2026-06-25 12:31:58	online	设备WebSocket连接建立	info	\N	\N	\N
303	123456	\N	2026-06-25 12:32:33	online	设备WebSocket连接建立	info	\N	\N	\N
304	123456	\N	2026-06-25 12:38:39	online	设备WebSocket连接建立	info	\N	\N	\N
305	123456	\N	2026-06-25 12:39:43	online	设备WebSocket连接建立	info	\N	\N	\N
306	123456	\N	2026-06-25 13:02:08	offline	设备WebSocket断开连接	warning	\N	\N	\N
307	123456	\N	2026-06-25 13:02:08	online	设备WebSocket连接建立	info	\N	\N	\N
308	123456	\N	2026-06-25 13:18:19	online	设备WebSocket连接建立	info	\N	\N	\N
309	123456	\N	2026-06-25 13:32:10	online	设备WebSocket连接建立	info	\N	\N	\N
310	123456	\N	2026-06-25 13:34:33	online	设备WebSocket连接建立	info	\N	\N	\N
311	123456	\N	2026-06-25 13:38:40	online	设备WebSocket连接建立	info	\N	\N	\N
312	123456	\N	2026-06-25 13:45:39	online	设备WebSocket连接建立	info	\N	\N	\N
313	123456	\N	2026-06-25 13:50:24	online	设备WebSocket连接建立	info	\N	\N	\N
314	101002	\N	2026-06-25 13:51:42	online	设备WebSocket连接建立	info	\N	\N	\N
315	101002	\N	2026-06-25 13:52:59	online	设备WebSocket连接建立	info	\N	\N	\N
316	101002	\N	2026-06-25 13:52:59	online	设备WebSocket连接建立	info	\N	\N	\N
317	101002	\N	2026-06-25 13:53:00	online	设备WebSocket连接建立	info	\N	\N	\N
318	101002	\N	2026-06-25 13:53:02	online	设备WebSocket连接建立	info	\N	\N	\N
319	101002	\N	2026-06-25 13:53:04	online	设备WebSocket连接建立	info	\N	\N	\N
320	101002	\N	2026-06-25 13:53:05	online	设备WebSocket连接建立	info	\N	\N	\N
321	101002	\N	2026-06-25 13:53:07	online	设备WebSocket连接建立	info	\N	\N	\N
322	101002	\N	2026-06-25 13:54:49	online	设备WebSocket连接建立	info	\N	\N	\N
323	123456	\N	2026-06-25 14:01:32	online	设备WebSocket连接建立	info	\N	\N	\N
324	101002	\N	2026-06-25 14:01:33	online	设备WebSocket连接建立	info	\N	\N	\N
325	101002	\N	2026-06-25 14:01:33	online	设备WebSocket连接建立	info	\N	\N	\N
326	101002	\N	2026-06-25 14:01:33	online	设备WebSocket连接建立	info	\N	\N	\N
327	101002	\N	2026-06-25 14:06:24	online	设备WebSocket连接建立	info	\N	\N	\N
328	123456	\N	2026-06-25 14:06:24	online	设备WebSocket连接建立	info	\N	\N	\N
329	101002	\N	2026-06-25 14:14:31	online	设备WebSocket连接建立	info	\N	\N	\N
330	123456	\N	2026-06-25 14:14:31	online	设备WebSocket连接建立	info	\N	\N	\N
331	123456	\N	2026-06-25 14:44:49	online	设备WebSocket连接建立	info	\N	\N	\N
332	123456	\N	2026-06-25 14:49:36	online	设备WebSocket连接建立	info	\N	\N	\N
333	101002	\N	2026-06-25 14:49:37	online	设备WebSocket连接建立	info	\N	\N	\N
334	101002	\N	2026-06-25 14:56:29	online	设备WebSocket连接建立	info	\N	\N	\N
335	123456	\N	2026-06-25 15:22:47	online	设备WebSocket连接建立	info	\N	\N	\N
336	123456	\N	2026-06-25 15:33:27	online	设备WebSocket连接建立	info	\N	\N	\N
337	123456	\N	2026-06-25 15:36:25	online	设备WebSocket连接建立	info	\N	\N	\N
338	123456	\N	2026-06-25 15:38:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
339	123456	\N	2026-06-25 15:38:25	online	设备WebSocket连接建立	info	\N	\N	\N
340	123456	\N	2026-06-25 15:46:24	offline	设备WebSocket断开连接	warning	\N	\N	\N
341	123456	\N	2026-06-25 15:46:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
342	123456	\N	2026-06-25 15:46:25	online	设备WebSocket连接建立	info	\N	\N	\N
343	123456	\N	2026-06-25 15:59:29	offline	设备WebSocket断开连接	warning	\N	\N	\N
344	123456	\N	2026-06-25 15:59:31	online	设备WebSocket连接建立	info	\N	\N	\N
345	123456	\N	2026-06-25 17:00:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
346	123456	\N	2026-06-25 22:22:56	online	设备WebSocket连接建立	info	\N	\N	\N
347	123456	\N	2026-06-25 22:27:31	online	设备WebSocket连接建立	info	\N	\N	\N
348	123456	\N	2026-06-25 22:35:32	online	设备WebSocket连接建立	info	\N	\N	\N
349	123456	\N	2026-06-25 22:37:37	online	设备WebSocket连接建立	info	\N	\N	\N
350	123456	\N	2026-06-25 22:38:17	online	设备WebSocket连接建立	info	\N	\N	\N
351	123456	\N	2026-06-25 22:42:19	online	设备WebSocket连接建立	info	\N	\N	\N
352	123456	\N	2026-06-25 22:44:58	online	设备WebSocket连接建立	info	\N	\N	\N
353	123456	\N	2026-06-25 22:45:32	online	设备WebSocket连接建立	info	\N	\N	\N
354	123456	\N	2026-06-25 22:50:18	online	设备WebSocket连接建立	info	\N	\N	\N
355	123456	\N	2026-06-25 22:56:18	online	设备WebSocket连接建立	info	\N	\N	\N
356	123456	\N	2026-06-25 23:01:17	online	设备WebSocket连接建立	info	\N	\N	\N
357	123456	\N	2026-06-25 23:06:32	offline	设备WebSocket断开连接	warning	\N	\N	\N
358	123456	\N	2026-06-25 23:06:33	online	设备WebSocket连接建立	info	\N	\N	\N
359	123456	\N	2026-06-25 23:06:33	online	设备WebSocket连接建立	info	\N	\N	\N
360	123456	\N	2026-06-25 23:06:34	online	设备WebSocket连接建立	info	\N	\N	\N
361	123456	\N	2026-06-25 23:06:35	online	设备WebSocket连接建立	info	\N	\N	\N
362	123456	\N	2026-06-25 23:06:37	online	设备WebSocket连接建立	info	\N	\N	\N
363	123456	\N	2026-06-25 23:06:38	online	设备WebSocket连接建立	info	\N	\N	\N
364	123456	\N	2026-06-25 23:06:39	online	设备WebSocket连接建立	info	\N	\N	\N
365	123456	\N	2026-06-25 23:06:40	online	设备WebSocket连接建立	info	\N	\N	\N
366	123456	\N	2026-06-25 23:06:42	online	设备WebSocket连接建立	info	\N	\N	\N
367	123456	\N	2026-06-25 23:06:43	online	设备WebSocket连接建立	info	\N	\N	\N
368	123456	\N	2026-06-25 23:06:44	online	设备WebSocket连接建立	info	\N	\N	\N
369	123456	\N	2026-06-25 23:10:42	online	设备WebSocket连接建立	info	\N	\N	\N
370	123456	\N	2026-06-25 23:10:42	online	设备WebSocket连接建立	info	\N	\N	\N
371	123456	\N	2026-06-25 23:10:42	online	设备WebSocket连接建立	info	\N	\N	\N
372	123456	\N	2026-06-25 23:10:44	online	设备WebSocket连接建立	info	\N	\N	\N
373	123456	\N	2026-06-25 23:29:27	online	设备WebSocket连接建立	info	\N	\N	\N
374	123456	\N	2026-06-25 23:32:50	online	设备WebSocket连接建立	info	\N	\N	\N
375	123456	\N	2026-06-25 23:33:24	online	设备WebSocket连接建立	info	\N	\N	\N
376	123456	\N	2026-06-25 23:38:10	offline	设备WebSocket断开连接	warning	\N	\N	\N
377	101002	\N	2026-06-26 00:29:54	online	设备WebSocket连接建立	info	\N	\N	\N
378	101002	\N	2026-06-26 00:31:09	online	设备WebSocket连接建立	info	\N	\N	\N
379	101002	\N	2026-06-26 00:44:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
380	123456	\N	2026-06-26 00:45:03	online	设备WebSocket连接建立	info	\N	\N	\N
381	123456	\N	2026-06-26 01:26:53	offline	设备WebSocket断开连接	warning	\N	\N	\N
382	123456	\N	2026-06-26 01:26:54	online	设备WebSocket连接建立	info	\N	\N	\N
383	123456	\N	2026-06-26 01:29:18	offline	设备WebSocket断开连接	warning	\N	\N	\N
384	123456	\N	2026-06-26 01:29:18	online	设备WebSocket连接建立	info	\N	\N	\N
385	123456	\N	2026-06-26 01:34:58	online	设备WebSocket连接建立	info	\N	\N	\N
386	123456	\N	2026-06-26 01:39:41	online	设备WebSocket连接建立	info	\N	\N	\N
387	123456	\N	2026-06-26 01:41:54	offline	设备WebSocket断开连接	warning	\N	\N	\N
388	123456	\N	2026-06-26 01:41:55	online	设备WebSocket连接建立	info	\N	\N	\N
389	123456	\N	2026-06-26 01:45:19	offline	设备WebSocket断开连接	warning	\N	\N	\N
390	123456	\N	2026-06-26 01:45:21	online	设备WebSocket连接建立	info	\N	\N	\N
391	123456	\N	2026-06-26 01:46:02	offline	设备WebSocket断开连接	warning	\N	\N	\N
392	123456	\N	2026-06-26 01:46:03	online	设备WebSocket连接建立	info	\N	\N	\N
393	123456	\N	2026-06-26 01:48:22	offline	设备WebSocket断开连接	warning	\N	\N	\N
394	123456	\N	2026-06-26 01:48:22	online	设备WebSocket连接建立	info	\N	\N	\N
395	123456	\N	2026-06-26 01:51:09	online	设备WebSocket连接建立	info	\N	\N	\N
396	123456	\N	2026-06-26 01:51:25	online	设备WebSocket连接建立	info	\N	\N	\N
397	123456	\N	2026-06-26 01:51:30	online	设备WebSocket连接建立	info	\N	\N	\N
398	123456	\N	2026-06-26 01:55:34	online	设备WebSocket连接建立	info	\N	\N	\N
399	123456	\N	2026-06-26 01:56:50	offline	设备WebSocket断开连接	warning	\N	\N	\N
400	123456	\N	2026-06-26 01:56:52	online	设备WebSocket连接建立	info	\N	\N	\N
401	123456	\N	2026-06-26 01:58:38	offline	设备WebSocket断开连接	warning	\N	\N	\N
402	123456	\N	2026-06-26 01:58:40	online	设备WebSocket连接建立	info	\N	\N	\N
403	123456	\N	2026-06-26 02:05:41	online	设备WebSocket连接建立	info	\N	\N	\N
404	123456	\N	2026-06-26 02:25:38	online	设备WebSocket连接建立	info	\N	\N	\N
405	123456	\N	2026-06-26 02:30:23	online	设备WebSocket连接建立	info	\N	\N	\N
406	123456	\N	2026-06-26 02:30:46	online	设备WebSocket连接建立	info	\N	\N	\N
407	123456	\N	2026-06-26 02:34:03	online	设备WebSocket连接建立	info	\N	\N	\N
408	123456	\N	2026-06-26 02:51:14	online	设备WebSocket连接建立	info	\N	\N	\N
409	123456	\N	2026-06-26 02:55:39	offline	设备WebSocket断开连接	warning	\N	\N	\N
410	123456	\N	2026-06-26 02:55:39	online	设备WebSocket连接建立	info	\N	\N	\N
411	123456	\N	2026-06-26 03:06:51	offline	设备WebSocket断开连接	warning	\N	\N	\N
412	123456	\N	2026-06-26 03:06:53	online	设备WebSocket连接建立	info	\N	\N	\N
413	123456	\N	2026-06-26 03:13:48	offline	设备WebSocket断开连接	warning	\N	\N	\N
414	123456	\N	2026-06-26 03:13:55	online	设备WebSocket连接建立	info	\N	\N	\N
415	123456	\N	2026-06-26 03:22:12	offline	设备WebSocket断开连接	warning	\N	\N	\N
416	123456	\N	2026-06-26 03:22:14	online	设备WebSocket连接建立	info	\N	\N	\N
417	123456	\N	2026-06-26 03:23:40	offline	设备WebSocket断开连接	warning	\N	\N	\N
418	123456	\N	2026-06-26 03:23:41	online	设备WebSocket连接建立	info	\N	\N	\N
419	123456	\N	2026-06-26 03:36:30	offline	设备WebSocket断开连接	warning	\N	\N	\N
420	123456	\N	2026-06-26 03:36:32	online	设备WebSocket连接建立	info	\N	\N	\N
421	123456	\N	2026-06-26 03:50:19	offline	设备WebSocket断开连接	warning	\N	\N	\N
422	123456	\N	2026-06-26 03:59:10	online	设备WebSocket连接建立	info	\N	\N	\N
423	123456	\N	2026-06-26 03:59:23	offline	设备WebSocket断开连接	warning	\N	\N	\N
424	123456	\N	2026-06-26 03:59:32	online	设备WebSocket连接建立	info	\N	\N	\N
425	123456	\N	2026-06-26 04:01:02	offline	设备WebSocket断开连接	warning	\N	\N	\N
426	123456	\N	2026-06-26 04:01:03	online	设备WebSocket连接建立	info	\N	\N	\N
427	123456	\N	2026-06-26 04:08:19	online	设备WebSocket连接建立	info	\N	\N	\N
428	123456	\N	2026-06-26 04:19:42	online	设备WebSocket连接建立	info	\N	\N	\N
429	123456	\N	2026-06-26 04:26:10	online	设备WebSocket连接建立	info	\N	\N	\N
430	123456	\N	2026-06-26 04:33:08	online	设备WebSocket连接建立	info	\N	\N	\N
431	123456	\N	2026-06-26 04:36:15	offline	设备WebSocket断开连接	warning	\N	\N	\N
432	123456	\N	2026-06-26 04:36:20	online	设备WebSocket连接建立	info	\N	\N	\N
433	123456	\N	2026-06-26 04:38:19	offline	设备WebSocket断开连接	warning	\N	\N	\N
434	123456	\N	2026-06-26 04:40:49	online	设备WebSocket连接建立	info	\N	\N	\N
435	123456	\N	2026-06-26 04:46:25	offline	设备WebSocket断开连接	warning	\N	\N	\N
436	123456	\N	2026-06-26 04:48:01	online	设备WebSocket连接建立	info	\N	\N	\N
437	123456	\N	2026-06-26 04:48:33	offline	设备WebSocket断开连接	warning	\N	\N	\N
438	123456	\N	2026-06-26 04:55:18	online	设备WebSocket连接建立	info	\N	\N	\N
439	123456	\N	2026-06-26 05:07:19	online	设备WebSocket连接建立	info	\N	\N	\N
440	123456	\N	2026-06-26 05:17:17	online	设备WebSocket连接建立	info	\N	\N	\N
441	123456	\N	2026-06-26 05:17:18	online	设备WebSocket连接建立	info	\N	\N	\N
442	123456	\N	2026-06-26 05:17:18	offline	设备WebSocket断开连接	warning	\N	\N	\N
443	123456	\N	2026-06-26 05:17:20	online	设备WebSocket连接建立	info	\N	\N	\N
444	123456	\N	2026-06-26 05:18:10	online	设备WebSocket连接建立	info	\N	\N	\N
445	123456	\N	2026-06-26 05:24:12	online	设备WebSocket连接建立	info	\N	\N	\N
446	123456	\N	2026-06-26 05:26:31	online	设备WebSocket连接建立	info	\N	\N	\N
447	123456	\N	2026-06-26 05:35:19	online	设备WebSocket连接建立	info	\N	\N	\N
448	123456	\N	2026-06-26 05:46:57	online	设备WebSocket连接建立	info	\N	\N	\N
449	123456	\N	2026-06-26 05:51:16	online	设备WebSocket连接建立	info	\N	\N	\N
450	123456	\N	2026-06-26 05:54:34	online	设备WebSocket连接建立	info	\N	\N	\N
451	123456	\N	2026-06-26 05:59:08	online	设备WebSocket连接建立	info	\N	\N	\N
452	123456	\N	2026-06-26 06:24:06	offline	设备WebSocket断开连接	warning	\N	\N	\N
453	100100	\N	2026-06-26 06:41:10	online	设备WebSocket连接建立	info	\N	\N	\N
454	100100	\N	2026-06-26 06:41:12	online	设备WebSocket连接建立	info	\N	\N	\N
455	100100	\N	2026-06-26 06:41:14	online	设备WebSocket连接建立	info	\N	\N	\N
456	100100	\N	2026-06-26 06:41:15	online	设备WebSocket连接建立	info	\N	\N	\N
457	100100	\N	2026-06-26 06:41:58	online	设备WebSocket连接建立	info	\N	\N	\N
458	100100	\N	2026-06-26 06:42:30	online	设备WebSocket连接建立	info	\N	\N	\N
459	100100	\N	2026-06-26 06:43:17	online	设备WebSocket连接建立	info	\N	\N	\N
460	100100	\N	2026-06-26 06:44:06	online	设备WebSocket连接建立	info	\N	\N	\N
461	100100	\N	2026-06-26 06:47:44	online	设备WebSocket连接建立	info	\N	\N	\N
462	100100	\N	2026-06-26 06:51:35	online	设备WebSocket连接建立	info	\N	\N	\N
463	100100	\N	2026-06-26 06:55:46	online	设备WebSocket连接建立	info	\N	\N	\N
464	100100	\N	2026-06-26 06:57:35	online	设备WebSocket连接建立	info	\N	\N	\N
465	100100	\N	2026-06-26 07:02:02	online	设备WebSocket连接建立	info	\N	\N	\N
466	100100	\N	2026-06-26 07:05:15	online	设备WebSocket连接建立	info	\N	\N	\N
467	100100	\N	2026-06-26 07:08:28	online	设备WebSocket连接建立	info	\N	\N	\N
468	100100	\N	2026-06-26 07:15:01	online	设备WebSocket连接建立	info	\N	\N	\N
469	100100	\N	2026-06-26 07:17:59	offline	设备WebSocket断开连接	warning	\N	\N	\N
470	100100	\N	2026-06-26 07:17:59	online	设备WebSocket连接建立	info	\N	\N	\N
471	100100	\N	2026-06-26 07:24:50	online	设备WebSocket连接建立	info	\N	\N	\N
472	100100	\N	2026-06-26 07:25:47	online	设备WebSocket连接建立	info	\N	\N	\N
473	100100	\N	2026-06-26 07:28:33	online	设备WebSocket连接建立	info	\N	\N	\N
474	100100	\N	2026-06-26 07:38:58	online	设备WebSocket连接建立	info	\N	\N	\N
475	100100	\N	2026-06-26 07:42:01	offline	设备WebSocket断开连接	warning	\N	\N	\N
476	100100	\N	2026-06-26 07:42:02	online	设备WebSocket连接建立	info	\N	\N	\N
477	100100	\N	2026-06-26 07:46:05	online	设备WebSocket连接建立	info	\N	\N	\N
478	100100	\N	2026-06-26 07:49:09	offline	设备WebSocket断开连接	warning	\N	\N	\N
479	100100	\N	2026-06-26 07:49:15	online	设备WebSocket连接建立	info	\N	\N	\N
480	100100	\N	2026-06-26 07:52:38	online	设备WebSocket连接建立	info	\N	\N	\N
481	100100	\N	2026-06-26 07:56:20	online	设备WebSocket连接建立	info	\N	\N	\N
482	100100	\N	2026-06-26 08:00:06	online	设备WebSocket连接建立	info	\N	\N	\N
483	100100	\N	2026-06-26 08:01:13	online	设备WebSocket连接建立	info	\N	\N	\N
484	100100	\N	2026-06-26 08:03:46	online	设备WebSocket连接建立	info	\N	\N	\N
485	100100	\N	2026-06-26 08:03:56	online	设备WebSocket连接建立	info	\N	\N	\N
486	100100	\N	2026-06-26 08:06:10	online	设备WebSocket连接建立	info	\N	\N	\N
487	100100	\N	2026-06-26 08:07:59	online	设备WebSocket连接建立	info	\N	\N	\N
488	100100	\N	2026-06-26 08:11:00	online	设备WebSocket连接建立	info	\N	\N	\N
489	100100	\N	2026-06-26 08:11:38	online	设备WebSocket连接建立	info	\N	\N	\N
490	test_main_app	\N	2026-06-27 07:07:00.301678	online	设备WebSocket连接建立	info	\N	\N	\N
491	test_main_app	\N	2026-06-27 07:07:03.253405	offline	设备WebSocket断开连接	warning	\N	\N	\N
492	100100	\N	2026-06-27 07:07:49.920075	online	设备WebSocket连接建立	info	\N	\N	\N
493	100100	\N	2026-06-27 07:07:49.994632	online	设备WebSocket连接建立	info	\N	\N	\N
494	100100	\N	2026-06-27 07:07:59.849589	offline	设备WebSocket断开连接	warning	\N	\N	\N
495	test_direct	\N	2026-06-27 07:08:15.618189	offline	设备WebSocket断开连接	warning	\N	\N	\N
496	test_nginx	\N	2026-06-27 07:08:18.584824	offline	设备WebSocket断开连接	warning	\N	\N	\N
497	test_nohost	\N	2026-06-27 07:08:21.604902	offline	设备WebSocket断开连接	warning	\N	\N	\N
498	test_recheck	\N	2026-06-27 07:08:53.415112	offline	设备WebSocket断开连接	warning	\N	\N	\N
499	test_py_direct	\N	2026-06-27 07:09:09.187288	online	设备WebSocket连接建立	info	\N	\N	\N
500	test_py_direct	\N	2026-06-27 07:09:09.31354	offline	设备WebSocket断开连接	warning	\N	\N	\N
501	test_single_host	\N	2026-06-27 07:09:30.583827	offline	设备WebSocket断开连接	warning	\N	\N	\N
502	test_default_host	\N	2026-06-27 07:09:32.608764	offline	设备WebSocket断开连接	warning	\N	\N	\N
503	100100	\N	2026-06-27 07:11:25.496255	online	设备WebSocket连接建立	info	\N	\N	\N
504	100100	\N	2026-06-27 07:11:30.823681	offline	设备WebSocket断开连接	warning	\N	\N	\N
505	100100	\N	2026-06-27 07:11:32.630952	online	设备WebSocket连接建立	info	\N	\N	\N
506	100100	\N	2026-06-27 07:11:43.019813	offline	设备WebSocket断开连接	warning	\N	\N	\N
507	100100	\N	2026-06-27 07:11:47.552613	online	设备WebSocket连接建立	info	\N	\N	\N
508	100100	\N	2026-06-27 07:11:48.766999	offline	设备WebSocket断开连接	warning	\N	\N	\N
509	100100	\N	2026-06-27 07:13:38.830143	online	设备WebSocket连接建立	info	\N	\N	\N
510	100100	\N	2026-06-27 07:13:49.356182	offline	设备WebSocket断开连接	warning	\N	\N	\N
511	100100	\N	2026-06-27 07:13:49.948043	online	设备WebSocket连接建立	info	\N	\N	\N
512	100100	\N	2026-06-27 07:14:00.59405	offline	设备WebSocket断开连接	warning	\N	\N	\N
513	100100	\N	2026-06-27 07:14:05.351706	online	设备WebSocket连接建立	info	\N	\N	\N
514	100100	\N	2026-06-27 07:14:15.786697	offline	设备WebSocket断开连接	warning	\N	\N	\N
515	100100	\N	2026-06-27 07:14:34.229846	online	设备WebSocket连接建立	info	\N	\N	\N
516	100100	\N	2026-06-27 07:14:42.735172	offline	设备WebSocket断开连接	warning	\N	\N	\N
517	100100	\N	2026-06-27 07:15:02.45812	online	设备WebSocket连接建立	info	\N	\N	\N
518	100100	\N	2026-06-27 07:15:02.532131	online	设备WebSocket连接建立	info	\N	\N	\N
519	100100	\N	2026-06-27 07:15:07.316551	offline	设备WebSocket断开连接	warning	\N	\N	\N
520	100100	\N	2026-06-27 07:16:17.096168	online	设备WebSocket连接建立	info	\N	\N	\N
521	100100	\N	2026-06-27 07:16:27.177086	offline	设备WebSocket断开连接	warning	\N	\N	\N
522	100100	\N	2026-06-27 07:16:28.015272	online	设备WebSocket连接建立	info	\N	\N	\N
523	100100	\N	2026-06-27 07:16:28.089357	online	设备WebSocket连接建立	info	\N	\N	\N
524	100100	\N	2026-06-27 07:16:29.27177	online	设备WebSocket连接建立	info	\N	\N	\N
525	100100	\N	2026-06-27 07:16:38.069109	offline	设备WebSocket断开连接	warning	\N	\N	\N
526	100100	\N	2026-06-27 07:16:42.937619	online	设备WebSocket连接建立	info	\N	\N	\N
527	100100	\N	2026-06-27 07:16:53.29388	offline	设备WebSocket断开连接	warning	\N	\N	\N
528	100100	\N	2026-06-27 07:19:14.059323	online	设备WebSocket连接建立	info	\N	\N	\N
529	100100	\N	2026-06-27 07:19:15.714929	offline	设备WebSocket断开连接	warning	\N	\N	\N
530	100100	\N	2026-06-27 07:19:17.346032	online	设备WebSocket连接建立	info	\N	\N	\N
531	100100	\N	2026-06-27 07:19:27.60143	offline	设备WebSocket断开连接	warning	\N	\N	\N
532	100100	\N	2026-06-27 07:21:01.920009	online	设备WebSocket连接建立	info	\N	\N	\N
533	100100	\N	2026-06-27 07:21:06.695338	offline	设备WebSocket断开连接	warning	\N	\N	\N
534	100100	\N	2026-06-27 07:21:25.655849	online	设备WebSocket连接建立	info	\N	\N	\N
535	100100	\N	2026-06-27 07:21:35.819822	offline	设备WebSocket断开连接	warning	\N	\N	\N
536	100100	\N	2026-06-27 07:21:37.678149	online	设备WebSocket连接建立	info	\N	\N	\N
537	100100	\N	2026-06-27 07:21:38.454401	offline	设备WebSocket断开连接	warning	\N	\N	\N
538	100100	\N	2026-06-27 07:26:32.61367	online	设备WebSocket连接建立	info	\N	\N	\N
539	100100	\N	2026-06-27 07:26:42.936555	offline	设备WebSocket断开连接	warning	\N	\N	\N
540	100100	\N	2026-06-27 07:26:43.482596	online	设备WebSocket连接建立	info	\N	\N	\N
541	100100	\N	2026-06-27 07:26:53.586738	offline	设备WebSocket断开连接	warning	\N	\N	\N
542	100100	\N	2026-06-27 07:27:06.28456	online	设备WebSocket连接建立	info	\N	\N	\N
543	100100	\N	2026-06-27 07:27:16.960721	offline	设备WebSocket断开连接	warning	\N	\N	\N
544	100100	\N	2026-06-27 07:27:17.768058	online	设备WebSocket连接建立	info	\N	\N	\N
545	100100	\N	2026-06-27 07:27:17.848826	online	设备WebSocket连接建立	info	\N	\N	\N
546	100100	\N	2026-06-27 07:27:19.09849	online	设备WebSocket连接建立	info	\N	\N	\N
547	100100	\N	2026-06-27 07:27:20.404738	online	设备WebSocket连接建立	info	\N	\N	\N
548	100100	\N	2026-06-27 07:27:21.689969	online	设备WebSocket连接建立	info	\N	\N	\N
549	100100	\N	2026-06-27 07:27:27.819089	offline	设备WebSocket断开连接	warning	\N	\N	\N
550	100100	\N	2026-06-27 07:27:28.464966	online	设备WebSocket连接建立	info	\N	\N	\N
551	100100	\N	2026-06-27 07:27:38.902357	offline	设备WebSocket断开连接	warning	\N	\N	\N
552	100100	\N	2026-06-27 07:32:13.325294	online	设备WebSocket连接建立	info	\N	\N	\N
553	100100	\N	2026-06-27 07:37:28.570649	online	设备WebSocket连接建立	info	\N	\N	\N
554	100100	\N	2026-06-27 07:38:14.398408	online	设备WebSocket连接建立	info	\N	\N	\N
555	100100	\N	2026-06-27 07:39:48.077537	online	设备WebSocket连接建立	info	\N	\N	\N
556	100100	\N	2026-06-27 07:39:48.14737	online	设备WebSocket连接建立	info	\N	\N	\N
557	100100	\N	2026-06-27 07:39:53.312521	offline	设备WebSocket断开连接	warning	\N	\N	\N
558	100100	\N	2026-06-27 07:39:54.986883	online	设备WebSocket连接建立	info	\N	\N	\N
559	100100	\N	2026-06-27 07:39:55.058792	online	设备WebSocket连接建立	info	\N	\N	\N
560	100100	\N	2026-06-27 07:41:03.477678	offline	设备WebSocket断开连接	warning	\N	\N	\N
561	100100	\N	2026-06-27 07:46:23.52377	online	设备WebSocket连接建立	info	\N	\N	\N
562	100100	\N	2026-06-27 07:46:23.598796	online	设备WebSocket连接建立	info	\N	\N	\N
563	100100	\N	2026-06-27 07:47:59.775198	online	设备WebSocket连接建立	info	\N	\N	\N
564	100100	\N	2026-06-27 07:47:59.847962	online	设备WebSocket连接建立	info	\N	\N	\N
565	100100	\N	2026-06-27 07:48:42.627695	online	设备WebSocket连接建立	info	\N	\N	\N
566	100100	\N	2026-06-27 07:48:42.911862	online	设备WebSocket连接建立	info	\N	\N	\N
567	100100	\N	2026-06-27 07:49:40.670145	online	设备WebSocket连接建立	info	\N	\N	\N
568	100100	\N	2026-06-27 07:49:40.84826	online	设备WebSocket连接建立	info	\N	\N	\N
569	100100	\N	2026-06-27 07:50:23.530853	online	设备WebSocket连接建立	info	\N	\N	\N
570	100100	\N	2026-06-27 07:50:23.602611	online	设备WebSocket连接建立	info	\N	\N	\N
571	100100	\N	2026-06-27 07:51:13.694582	offline	设备WebSocket断开连接	warning	\N	\N	\N
572	100100	\N	2026-06-27 07:51:15.346679	online	设备WebSocket连接建立	info	\N	\N	\N
573	100100	\N	2026-06-27 07:51:15.418615	online	设备WebSocket连接建立	info	\N	\N	\N
574	100100	\N	2026-06-27 08:01:57.496137	online	设备WebSocket连接建立	info	\N	\N	\N
575	100100	\N	2026-06-27 08:01:57.699739	online	设备WebSocket连接建立	info	\N	\N	\N
576	100100	\N	2026-06-27 08:01:57.841181	online	设备WebSocket连接建立	info	\N	\N	\N
577	100100	\N	2026-06-27 08:01:58.0048	online	设备WebSocket连接建立	info	\N	\N	\N
578	100100	\N	2026-06-27 08:01:58.141504	online	设备WebSocket连接建立	info	\N	\N	\N
579	100100	\N	2026-06-27 08:01:58.255142	online	设备WebSocket连接建立	info	\N	\N	\N
580	100100	\N	2026-06-27 08:01:58.365135	online	设备WebSocket连接建立	info	\N	\N	\N
581	100100	\N	2026-06-27 08:01:58.468565	online	设备WebSocket连接建立	info	\N	\N	\N
582	100100	\N	2026-06-27 08:01:58.591619	online	设备WebSocket连接建立	info	\N	\N	\N
583	100100	\N	2026-06-27 08:01:58.694783	online	设备WebSocket连接建立	info	\N	\N	\N
584	100100	\N	2026-06-27 08:01:58.773445	online	设备WebSocket连接建立	info	\N	\N	\N
585	100100	\N	2026-06-27 08:01:58.854365	online	设备WebSocket连接建立	info	\N	\N	\N
586	100100	\N	2026-06-27 08:01:58.936643	online	设备WebSocket连接建立	info	\N	\N	\N
587	100100	\N	2026-06-27 08:01:59.025577	online	设备WebSocket连接建立	info	\N	\N	\N
588	100100	\N	2026-06-27 08:01:59.139865	online	设备WebSocket连接建立	info	\N	\N	\N
589	100100	\N	2026-06-27 08:01:59.267478	online	设备WebSocket连接建立	info	\N	\N	\N
590	100100	\N	2026-06-27 08:01:59.370057	online	设备WebSocket连接建立	info	\N	\N	\N
591	100100	\N	2026-06-27 08:01:59.474922	online	设备WebSocket连接建立	info	\N	\N	\N
592	100100	\N	2026-06-27 08:01:59.600359	online	设备WebSocket连接建立	info	\N	\N	\N
593	100100	\N	2026-06-27 08:01:59.706794	online	设备WebSocket连接建立	info	\N	\N	\N
594	100100	\N	2026-06-27 08:01:59.848186	online	设备WebSocket连接建立	info	\N	\N	\N
595	100100	\N	2026-06-27 08:01:59.984033	online	设备WebSocket连接建立	info	\N	\N	\N
596	100100	\N	2026-06-27 08:02:00.100096	online	设备WebSocket连接建立	info	\N	\N	\N
597	100100	\N	2026-06-27 08:02:00.281605	online	设备WebSocket连接建立	info	\N	\N	\N
598	100100	\N	2026-06-27 08:02:00.404908	online	设备WebSocket连接建立	info	\N	\N	\N
599	100100	\N	2026-06-27 08:02:00.567731	online	设备WebSocket连接建立	info	\N	\N	\N
600	100100	\N	2026-06-27 08:02:00.677776	online	设备WebSocket连接建立	info	\N	\N	\N
601	100100	\N	2026-06-27 08:02:00.785178	online	设备WebSocket连接建立	info	\N	\N	\N
602	100100	\N	2026-06-27 08:02:00.904658	online	设备WebSocket连接建立	info	\N	\N	\N
603	100100	\N	2026-06-27 08:02:01.139699	online	设备WebSocket连接建立	info	\N	\N	\N
604	100100	\N	2026-06-27 08:02:01.268646	online	设备WebSocket连接建立	info	\N	\N	\N
605	100100	\N	2026-06-27 08:02:01.391763	online	设备WebSocket连接建立	info	\N	\N	\N
606	100100	\N	2026-06-27 08:02:01.520832	online	设备WebSocket连接建立	info	\N	\N	\N
607	100100	\N	2026-06-27 08:02:01.713331	online	设备WebSocket连接建立	info	\N	\N	\N
608	100100	\N	2026-06-27 08:02:01.877701	online	设备WebSocket连接建立	info	\N	\N	\N
609	100100	\N	2026-06-27 08:02:01.987966	online	设备WebSocket连接建立	info	\N	\N	\N
610	100100	\N	2026-06-27 08:02:02.099473	online	设备WebSocket连接建立	info	\N	\N	\N
611	100100	\N	2026-06-27 08:02:02.22473	online	设备WebSocket连接建立	info	\N	\N	\N
612	100100	\N	2026-06-27 08:02:02.358641	online	设备WebSocket连接建立	info	\N	\N	\N
613	100100	\N	2026-06-27 08:02:02.505784	online	设备WebSocket连接建立	info	\N	\N	\N
614	100100	\N	2026-06-27 08:02:02.631772	online	设备WebSocket连接建立	info	\N	\N	\N
615	100100	\N	2026-06-27 08:02:02.735229	online	设备WebSocket连接建立	info	\N	\N	\N
616	100100	\N	2026-06-27 08:02:02.909846	online	设备WebSocket连接建立	info	\N	\N	\N
617	100100	\N	2026-06-27 08:02:03.100049	online	设备WebSocket连接建立	info	\N	\N	\N
618	100100	\N	2026-06-27 08:02:03.259716	online	设备WebSocket连接建立	info	\N	\N	\N
619	100100	\N	2026-06-27 08:02:03.371661	online	设备WebSocket连接建立	info	\N	\N	\N
620	100100	\N	2026-06-27 08:02:03.503362	online	设备WebSocket连接建立	info	\N	\N	\N
621	100100	\N	2026-06-27 08:02:03.614068	online	设备WebSocket连接建立	info	\N	\N	\N
622	100100	\N	2026-06-27 08:02:03.742594	online	设备WebSocket连接建立	info	\N	\N	\N
623	100100	\N	2026-06-27 08:02:03.849478	online	设备WebSocket连接建立	info	\N	\N	\N
624	100100	\N	2026-06-27 08:02:03.952519	online	设备WebSocket连接建立	info	\N	\N	\N
625	100100	\N	2026-06-27 08:02:04.067065	online	设备WebSocket连接建立	info	\N	\N	\N
626	100100	\N	2026-06-27 08:02:04.188167	online	设备WebSocket连接建立	info	\N	\N	\N
627	100100	\N	2026-06-27 08:02:04.311739	online	设备WebSocket连接建立	info	\N	\N	\N
628	100100	\N	2026-06-27 08:02:04.444432	online	设备WebSocket连接建立	info	\N	\N	\N
629	100100	\N	2026-06-27 08:02:04.575747	online	设备WebSocket连接建立	info	\N	\N	\N
630	100100	\N	2026-06-27 08:02:04.662168	online	设备WebSocket连接建立	info	\N	\N	\N
631	100100	\N	2026-06-27 08:02:04.773007	online	设备WebSocket连接建立	info	\N	\N	\N
632	100100	\N	2026-06-27 08:02:04.904869	online	设备WebSocket连接建立	info	\N	\N	\N
633	100100	\N	2026-06-27 08:02:05.035603	online	设备WebSocket连接建立	info	\N	\N	\N
634	100100	\N	2026-06-27 08:02:05.151722	online	设备WebSocket连接建立	info	\N	\N	\N
635	100100	\N	2026-06-27 08:02:05.261679	online	设备WebSocket连接建立	info	\N	\N	\N
636	100100	\N	2026-06-27 08:02:05.358955	online	设备WebSocket连接建立	info	\N	\N	\N
637	100100	\N	2026-06-27 08:02:05.456372	online	设备WebSocket连接建立	info	\N	\N	\N
638	100100	\N	2026-06-27 08:02:05.591032	online	设备WebSocket连接建立	info	\N	\N	\N
639	100100	\N	2026-06-27 08:02:05.706154	online	设备WebSocket连接建立	info	\N	\N	\N
640	100100	\N	2026-06-27 08:02:05.828754	online	设备WebSocket连接建立	info	\N	\N	\N
641	100100	\N	2026-06-27 08:02:05.969284	online	设备WebSocket连接建立	info	\N	\N	\N
642	100100	\N	2026-06-27 08:02:06.085176	online	设备WebSocket连接建立	info	\N	\N	\N
643	100100	\N	2026-06-27 08:02:06.203122	online	设备WebSocket连接建立	info	\N	\N	\N
644	100100	\N	2026-06-27 08:02:06.463728	online	设备WebSocket连接建立	info	\N	\N	\N
645	100100	\N	2026-06-27 08:02:06.556779	online	设备WebSocket连接建立	info	\N	\N	\N
646	100100	\N	2026-06-27 08:02:06.694292	online	设备WebSocket连接建立	info	\N	\N	\N
647	100100	\N	2026-06-27 08:02:06.820348	online	设备WebSocket连接建立	info	\N	\N	\N
648	100100	\N	2026-06-27 08:02:07.784928	online	设备WebSocket连接建立	info	\N	\N	\N
649	100100	\N	2026-06-27 08:02:07.863227	online	设备WebSocket连接建立	info	\N	\N	\N
650	100100	\N	2026-06-27 08:07:08.834843	offline	设备WebSocket断开连接	warning	\N	\N	\N
651	100100	\N	2026-06-27 08:09:52.223981	online	设备WebSocket连接建立	info	\N	\N	\N
652	100100	\N	2026-06-27 08:09:52.295145	online	设备WebSocket连接建立	info	\N	\N	\N
653	100100	\N	2026-06-27 08:23:35.30851	offline	设备WebSocket断开连接	warning	\N	\N	\N
654	100100	\N	2026-06-27 08:23:37.990941	online	设备WebSocket连接建立	info	\N	\N	\N
655	100100	\N	2026-06-27 08:23:38.155039	online	设备WebSocket连接建立	info	\N	\N	\N
656	100100	\N	2026-06-27 08:23:38.296156	online	设备WebSocket连接建立	info	\N	\N	\N
657	100100	\N	2026-06-27 08:23:38.454977	online	设备WebSocket连接建立	info	\N	\N	\N
658	100100	\N	2026-06-27 08:23:38.604012	online	设备WebSocket连接建立	info	\N	\N	\N
659	100100	\N	2026-06-27 08:23:38.815946	online	设备WebSocket连接建立	info	\N	\N	\N
660	100100	\N	2026-06-27 08:23:39.000675	online	设备WebSocket连接建立	info	\N	\N	\N
661	100100	\N	2026-06-27 08:23:39.174236	online	设备WebSocket连接建立	info	\N	\N	\N
662	100100	\N	2026-06-27 08:23:39.383758	online	设备WebSocket连接建立	info	\N	\N	\N
663	100100	\N	2026-06-27 08:23:39.489247	online	设备WebSocket连接建立	info	\N	\N	\N
664	100100	\N	2026-06-27 08:23:39.594399	online	设备WebSocket连接建立	info	\N	\N	\N
665	100100	\N	2026-06-27 08:23:39.7237	online	设备WebSocket连接建立	info	\N	\N	\N
666	100100	\N	2026-06-27 08:23:39.854101	online	设备WebSocket连接建立	info	\N	\N	\N
667	100100	\N	2026-06-27 08:23:39.977666	online	设备WebSocket连接建立	info	\N	\N	\N
668	100100	\N	2026-06-27 08:23:40.078705	online	设备WebSocket连接建立	info	\N	\N	\N
669	100100	\N	2026-06-27 08:23:40.331062	online	设备WebSocket连接建立	info	\N	\N	\N
670	100100	\N	2026-06-27 08:23:40.475743	online	设备WebSocket连接建立	info	\N	\N	\N
671	100100	\N	2026-06-27 08:23:40.602833	online	设备WebSocket连接建立	info	\N	\N	\N
672	100100	\N	2026-06-27 08:23:40.741812	online	设备WebSocket连接建立	info	\N	\N	\N
673	100100	\N	2026-06-27 08:23:40.836207	online	设备WebSocket连接建立	info	\N	\N	\N
674	100100	\N	2026-06-27 08:23:40.979722	online	设备WebSocket连接建立	info	\N	\N	\N
675	100100	\N	2026-06-27 08:23:41.095083	online	设备WebSocket连接建立	info	\N	\N	\N
676	100100	\N	2026-06-27 08:23:41.205933	online	设备WebSocket连接建立	info	\N	\N	\N
677	100100	\N	2026-06-27 08:23:41.344735	online	设备WebSocket连接建立	info	\N	\N	\N
678	100100	\N	2026-06-27 08:23:41.443333	online	设备WebSocket连接建立	info	\N	\N	\N
679	100100	\N	2026-06-27 08:23:41.553562	online	设备WebSocket连接建立	info	\N	\N	\N
680	100100	\N	2026-06-27 08:23:41.673768	online	设备WebSocket连接建立	info	\N	\N	\N
681	100100	\N	2026-06-27 08:23:41.77857	online	设备WebSocket连接建立	info	\N	\N	\N
682	100100	\N	2026-06-27 08:23:41.929595	online	设备WebSocket连接建立	info	\N	\N	\N
683	100100	\N	2026-06-27 08:23:42.050001	online	设备WebSocket连接建立	info	\N	\N	\N
684	100100	\N	2026-06-27 08:23:42.23466	online	设备WebSocket连接建立	info	\N	\N	\N
685	100100	\N	2026-06-27 08:23:42.399422	online	设备WebSocket连接建立	info	\N	\N	\N
686	100100	\N	2026-06-27 08:23:42.588765	online	设备WebSocket连接建立	info	\N	\N	\N
687	100100	\N	2026-06-27 08:23:42.723485	online	设备WebSocket连接建立	info	\N	\N	\N
688	100100	\N	2026-06-27 08:23:42.875494	online	设备WebSocket连接建立	info	\N	\N	\N
689	100100	\N	2026-06-27 08:23:42.995333	online	设备WebSocket连接建立	info	\N	\N	\N
690	100100	\N	2026-06-27 08:23:43.165802	online	设备WebSocket连接建立	info	\N	\N	\N
691	100100	\N	2026-06-27 08:23:43.318945	online	设备WebSocket连接建立	info	\N	\N	\N
692	100100	\N	2026-06-27 08:23:43.461646	online	设备WebSocket连接建立	info	\N	\N	\N
693	100100	\N	2026-06-27 08:23:43.594468	online	设备WebSocket连接建立	info	\N	\N	\N
694	100100	\N	2026-06-27 08:23:43.727414	online	设备WebSocket连接建立	info	\N	\N	\N
695	100100	\N	2026-06-27 08:23:43.868522	online	设备WebSocket连接建立	info	\N	\N	\N
696	100100	\N	2026-06-27 08:23:43.986802	online	设备WebSocket连接建立	info	\N	\N	\N
697	100100	\N	2026-06-27 08:23:44.133328	online	设备WebSocket连接建立	info	\N	\N	\N
698	100100	\N	2026-06-27 08:23:44.311219	online	设备WebSocket连接建立	info	\N	\N	\N
699	100100	\N	2026-06-27 08:23:44.395277	online	设备WebSocket连接建立	info	\N	\N	\N
700	100100	\N	2026-06-27 08:23:44.515819	online	设备WebSocket连接建立	info	\N	\N	\N
701	100100	\N	2026-06-27 08:23:44.630371	online	设备WebSocket连接建立	info	\N	\N	\N
702	100100	\N	2026-06-27 08:23:44.747498	online	设备WebSocket连接建立	info	\N	\N	\N
703	100100	\N	2026-06-27 08:23:44.851667	online	设备WebSocket连接建立	info	\N	\N	\N
704	100100	\N	2026-06-27 08:23:44.977214	online	设备WebSocket连接建立	info	\N	\N	\N
705	100100	\N	2026-06-27 08:23:45.11169	online	设备WebSocket连接建立	info	\N	\N	\N
706	100100	\N	2026-06-27 08:23:45.239682	online	设备WebSocket连接建立	info	\N	\N	\N
707	100100	\N	2026-06-27 08:23:45.365178	online	设备WebSocket连接建立	info	\N	\N	\N
708	100100	\N	2026-06-27 08:23:45.599694	online	设备WebSocket连接建立	info	\N	\N	\N
709	100100	\N	2026-06-27 08:23:45.720672	online	设备WebSocket连接建立	info	\N	\N	\N
710	100100	\N	2026-06-27 08:23:45.827951	online	设备WebSocket连接建立	info	\N	\N	\N
711	100100	\N	2026-06-27 08:23:45.943701	online	设备WebSocket连接建立	info	\N	\N	\N
712	100100	\N	2026-06-27 08:23:46.069777	online	设备WebSocket连接建立	info	\N	\N	\N
713	100100	\N	2026-06-27 08:23:46.195741	online	设备WebSocket连接建立	info	\N	\N	\N
714	100100	\N	2026-06-27 08:23:46.314834	online	设备WebSocket连接建立	info	\N	\N	\N
715	100100	\N	2026-06-27 08:23:46.451758	online	设备WebSocket连接建立	info	\N	\N	\N
716	100100	\N	2026-06-27 08:23:46.582143	online	设备WebSocket连接建立	info	\N	\N	\N
717	100100	\N	2026-06-27 08:23:46.723743	online	设备WebSocket连接建立	info	\N	\N	\N
718	100100	\N	2026-06-27 08:23:46.851217	online	设备WebSocket连接建立	info	\N	\N	\N
719	100100	\N	2026-06-27 08:23:46.970207	online	设备WebSocket连接建立	info	\N	\N	\N
720	100100	\N	2026-06-27 08:23:47.09319	online	设备WebSocket连接建立	info	\N	\N	\N
721	100100	\N	2026-06-27 08:23:47.22376	online	设备WebSocket连接建立	info	\N	\N	\N
722	100100	\N	2026-06-27 08:23:47.347102	online	设备WebSocket连接建立	info	\N	\N	\N
723	100100	\N	2026-06-27 08:23:47.475693	online	设备WebSocket连接建立	info	\N	\N	\N
724	100100	\N	2026-06-27 08:23:47.593158	online	设备WebSocket连接建立	info	\N	\N	\N
725	100100	\N	2026-06-27 08:23:47.710336	online	设备WebSocket连接建立	info	\N	\N	\N
726	100100	\N	2026-06-27 08:23:47.813769	online	设备WebSocket连接建立	info	\N	\N	\N
727	100100	\N	2026-06-27 08:23:47.947972	online	设备WebSocket连接建立	info	\N	\N	\N
728	100100	\N	2026-06-27 08:23:48.07837	online	设备WebSocket连接建立	info	\N	\N	\N
729	100100	\N	2026-06-27 08:23:48.182899	online	设备WebSocket连接建立	info	\N	\N	\N
730	100100	\N	2026-06-27 08:23:48.29439	online	设备WebSocket连接建立	info	\N	\N	\N
731	100100	\N	2026-06-27 08:23:48.412279	online	设备WebSocket连接建立	info	\N	\N	\N
732	100100	\N	2026-06-27 08:23:48.523964	online	设备WebSocket连接建立	info	\N	\N	\N
733	100100	\N	2026-06-27 08:23:48.639665	online	设备WebSocket连接建立	info	\N	\N	\N
734	100100	\N	2026-06-27 08:23:48.768833	online	设备WebSocket连接建立	info	\N	\N	\N
735	100100	\N	2026-06-27 08:23:48.883477	online	设备WebSocket连接建立	info	\N	\N	\N
736	100100	\N	2026-06-27 08:23:48.99725	online	设备WebSocket连接建立	info	\N	\N	\N
737	100100	\N	2026-06-27 08:23:49.107058	online	设备WebSocket连接建立	info	\N	\N	\N
738	100100	\N	2026-06-27 08:23:49.242252	online	设备WebSocket连接建立	info	\N	\N	\N
739	100100	\N	2026-06-27 08:23:49.378329	online	设备WebSocket连接建立	info	\N	\N	\N
740	100100	\N	2026-06-27 08:23:49.517968	online	设备WebSocket连接建立	info	\N	\N	\N
741	100100	\N	2026-06-27 08:23:49.640669	online	设备WebSocket连接建立	info	\N	\N	\N
742	100100	\N	2026-06-27 08:23:49.761056	online	设备WebSocket连接建立	info	\N	\N	\N
743	100100	\N	2026-06-27 08:23:49.883683	online	设备WebSocket连接建立	info	\N	\N	\N
744	100100	\N	2026-06-27 08:23:50.030942	online	设备WebSocket连接建立	info	\N	\N	\N
745	100100	\N	2026-06-27 08:23:50.134167	online	设备WebSocket连接建立	info	\N	\N	\N
746	100100	\N	2026-06-27 08:23:50.255726	online	设备WebSocket连接建立	info	\N	\N	\N
747	100100	\N	2026-06-27 08:23:50.383712	online	设备WebSocket连接建立	info	\N	\N	\N
748	100100	\N	2026-06-27 08:23:50.491078	online	设备WebSocket连接建立	info	\N	\N	\N
749	100100	\N	2026-06-27 08:23:50.582219	online	设备WebSocket连接建立	info	\N	\N	\N
750	100100	\N	2026-06-27 08:23:50.698163	online	设备WebSocket连接建立	info	\N	\N	\N
751	100100	\N	2026-06-27 08:23:50.967209	online	设备WebSocket连接建立	info	\N	\N	\N
752	100100	\N	2026-06-27 08:23:51.106618	online	设备WebSocket连接建立	info	\N	\N	\N
753	100100	\N	2026-06-27 08:23:51.271823	online	设备WebSocket连接建立	info	\N	\N	\N
754	100100	\N	2026-06-27 08:23:51.443791	online	设备WebSocket连接建立	info	\N	\N	\N
755	100100	\N	2026-06-27 08:23:51.632587	online	设备WebSocket连接建立	info	\N	\N	\N
756	100100	\N	2026-06-27 08:23:52.196388	online	设备WebSocket连接建立	info	\N	\N	\N
757	100100	\N	2026-06-27 08:23:52.335703	online	设备WebSocket连接建立	info	\N	\N	\N
758	100100	\N	2026-06-27 08:41:57.529524	online	设备WebSocket连接建立	info	\N	\N	\N
759	100100	\N	2026-06-27 08:41:57.610579	online	设备WebSocket连接建立	info	\N	\N	\N
760	100100	\N	2026-06-27 08:46:21.239845	online	设备WebSocket连接建立	info	\N	\N	\N
761	100100	\N	2026-06-27 08:46:21.312773	online	设备WebSocket连接建立	info	\N	\N	\N
762	100100	\N	2026-06-27 08:48:52.389343	online	设备WebSocket连接建立	info	\N	\N	\N
763	100100	\N	2026-06-27 08:48:52.462133	online	设备WebSocket连接建立	info	\N	\N	\N
764	100100	\N	2026-06-27 08:50:49.520522	online	设备WebSocket连接建立	info	\N	\N	\N
765	100100	\N	2026-06-27 08:50:49.698649	online	设备WebSocket连接建立	info	\N	\N	\N
766	100100	\N	2026-06-27 08:51:39.122688	offline	设备WebSocket断开连接	warning	\N	\N	\N
767	100100	\N	2026-06-27 08:52:00.421699	online	设备WebSocket连接建立	info	\N	\N	\N
768	100100	\N	2026-06-27 08:52:00.572863	online	设备WebSocket连接建立	info	\N	\N	\N
769	100100	\N	2026-06-27 08:52:00.738695	online	设备WebSocket连接建立	info	\N	\N	\N
770	100100	\N	2026-06-27 08:52:00.930374	online	设备WebSocket连接建立	info	\N	\N	\N
771	100100	\N	2026-06-27 08:52:01.098709	online	设备WebSocket连接建立	info	\N	\N	\N
772	100100	\N	2026-06-27 08:52:01.259235	online	设备WebSocket连接建立	info	\N	\N	\N
773	100100	\N	2026-06-27 08:52:01.400896	online	设备WebSocket连接建立	info	\N	\N	\N
774	100100	\N	2026-06-27 08:52:01.569248	online	设备WebSocket连接建立	info	\N	\N	\N
775	100100	\N	2026-06-27 08:52:01.702029	online	设备WebSocket连接建立	info	\N	\N	\N
776	100100	\N	2026-06-27 08:52:01.8887	online	设备WebSocket连接建立	info	\N	\N	\N
777	100100	\N	2026-06-27 08:52:02.064501	online	设备WebSocket连接建立	info	\N	\N	\N
778	100100	\N	2026-06-27 08:52:02.218369	online	设备WebSocket连接建立	info	\N	\N	\N
779	100100	\N	2026-06-27 08:52:02.398658	online	设备WebSocket连接建立	info	\N	\N	\N
780	100100	\N	2026-06-27 08:52:02.573291	online	设备WebSocket连接建立	info	\N	\N	\N
781	100100	\N	2026-06-27 08:52:02.718611	online	设备WebSocket连接建立	info	\N	\N	\N
782	100100	\N	2026-06-27 08:52:02.868915	online	设备WebSocket连接建立	info	\N	\N	\N
783	100100	\N	2026-06-27 08:52:03.020824	online	设备WebSocket连接建立	info	\N	\N	\N
784	100100	\N	2026-06-27 08:52:03.214655	online	设备WebSocket连接建立	info	\N	\N	\N
785	100100	\N	2026-06-27 08:52:03.402656	online	设备WebSocket连接建立	info	\N	\N	\N
786	100100	\N	2026-06-27 08:52:03.556352	online	设备WebSocket连接建立	info	\N	\N	\N
787	100100	\N	2026-06-27 08:52:03.722712	online	设备WebSocket连接建立	info	\N	\N	\N
788	100100	\N	2026-06-27 08:52:03.887234	online	设备WebSocket连接建立	info	\N	\N	\N
789	100100	\N	2026-06-27 08:52:04.054655	online	设备WebSocket连接建立	info	\N	\N	\N
790	100100	\N	2026-06-27 08:52:04.222654	online	设备WebSocket连接建立	info	\N	\N	\N
791	100100	\N	2026-06-27 08:52:04.39467	online	设备WebSocket连接建立	info	\N	\N	\N
792	100100	\N	2026-06-27 08:52:04.564901	online	设备WebSocket连接建立	info	\N	\N	\N
793	100100	\N	2026-06-27 08:52:05.664309	online	设备WebSocket连接建立	info	\N	\N	\N
794	100100	\N	2026-06-27 08:52:05.755919	online	设备WebSocket连接建立	info	\N	\N	\N
795	100100	\N	2026-06-27 08:55:00.951488	offline	设备WebSocket断开连接	warning	\N	\N	\N
796	100100	\N	2026-06-27 08:55:02.807762	online	设备WebSocket连接建立	info	\N	\N	\N
797	100100	\N	2026-06-27 08:55:02.87911	online	设备WebSocket连接建立	info	\N	\N	\N
798	100100	\N	2026-06-27 08:55:14.788586	offline	设备WebSocket断开连接	warning	\N	\N	\N
799	100100	\N	2026-06-27 08:55:21.554363	online	设备WebSocket连接建立	info	\N	\N	\N
800	100100	\N	2026-06-27 08:55:21.62645	online	设备WebSocket连接建立	info	\N	\N	\N
801	100100	\N	2026-06-27 09:04:03.863715	offline	设备WebSocket断开连接	warning	\N	\N	\N
802	100100	\N	2026-06-27 09:04:10.566687	online	设备WebSocket连接建立	info	\N	\N	\N
803	100100	\N	2026-06-27 09:04:10.635507	online	设备WebSocket连接建立	info	\N	\N	\N
804	100100	\N	2026-06-27 09:07:05.773296	online	设备WebSocket连接建立	info	\N	\N	\N
805	100100	\N	2026-06-27 09:07:05.842667	online	设备WebSocket连接建立	info	\N	\N	\N
806	100100	\N	2026-06-27 09:07:41.158637	online	设备WebSocket连接建立	info	\N	\N	\N
807	100100	\N	2026-06-27 09:07:41.328407	online	设备WebSocket连接建立	info	\N	\N	\N
808	100100	\N	2026-06-27 09:11:17.032884	online	设备WebSocket连接建立	info	\N	\N	\N
809	100100	\N	2026-06-27 09:11:17.106342	online	设备WebSocket连接建立	info	\N	\N	\N
810	100100	\N	2026-06-27 09:14:03.864547	online	设备WebSocket连接建立	info	\N	\N	\N
811	100100	\N	2026-06-27 09:14:03.977787	online	设备WebSocket连接建立	info	\N	\N	\N
812	100100	\N	2026-06-27 09:14:53.140792	offline	设备WebSocket断开连接	warning	\N	\N	\N
813	100100	\N	2026-06-27 09:14:59.153499	online	设备WebSocket连接建立	info	\N	\N	\N
814	100100	\N	2026-06-27 09:14:59.224784	online	设备WebSocket连接建立	info	\N	\N	\N
815	100100	\N	2026-06-27 09:15:41.822782	online	设备WebSocket连接建立	info	\N	\N	\N
816	100100	\N	2026-06-27 09:15:41.892461	online	设备WebSocket连接建立	info	\N	\N	\N
817	100100	\N	2026-06-27 09:16:17.888262	online	设备WebSocket连接建立	info	\N	\N	\N
818	100100	\N	2026-06-27 09:16:17.957712	online	设备WebSocket连接建立	info	\N	\N	\N
819	100100	\N	2026-06-27 09:16:46.536239	offline	设备WebSocket断开连接	warning	\N	\N	\N
820	100100	\N	2026-06-27 09:16:52.597931	online	设备WebSocket连接建立	info	\N	\N	\N
821	100100	\N	2026-06-27 09:16:52.667865	online	设备WebSocket连接建立	info	\N	\N	\N
822	100100	\N	2026-06-27 09:19:16.410604	online	设备WebSocket连接建立	info	\N	\N	\N
823	100100	\N	2026-06-27 09:19:16.480169	online	设备WebSocket连接建立	info	\N	\N	\N
824	100100	\N	2026-06-27 09:19:41.007387	online	设备WebSocket连接建立	info	\N	\N	\N
825	100100	\N	2026-06-27 09:19:41.077839	online	设备WebSocket连接建立	info	\N	\N	\N
826	100100	\N	2026-06-27 09:20:01.283109	online	设备WebSocket连接建立	info	\N	\N	\N
827	100100	\N	2026-06-27 09:20:01.520093	online	设备WebSocket连接建立	info	\N	\N	\N
828	100100	\N	2026-06-27 09:25:39.500852	offline	设备WebSocket断开连接	warning	\N	\N	\N
829	100100	\N	2026-06-27 09:28:44.856743	online	设备WebSocket连接建立	info	\N	\N	\N
830	100100	\N	2026-06-27 09:28:44.927084	online	设备WebSocket连接建立	info	\N	\N	\N
831	101002	\N	2026-06-27 09:30:03.054066	online	设备WebSocket连接建立	info	\N	\N	\N
832	101002	\N	2026-06-27 09:30:03.44534	online	设备WebSocket连接建立	info	\N	\N	\N
833	100100	\N	2026-06-27 09:30:40.527159	offline	设备WebSocket断开连接	warning	\N	\N	\N
834	101002	\N	2026-06-27 09:32:44.997691	online	设备WebSocket连接建立	info	\N	\N	\N
835	101002	\N	2026-06-27 09:32:45.072307	online	设备WebSocket连接建立	info	\N	\N	\N
836	101002	\N	2026-06-27 09:33:32.203307	offline	设备WebSocket断开连接	warning	\N	\N	\N
837	100100	\N	2026-06-27 09:34:28.374679	online	设备WebSocket连接建立	info	\N	\N	\N
838	100100	\N	2026-06-27 09:34:28.450571	online	设备WebSocket连接建立	info	\N	\N	\N
839	100100	\N	2026-06-27 09:35:08.435515	offline	设备WebSocket断开连接	warning	\N	\N	\N
840	100100	\N	2026-06-27 09:35:10.18376	online	设备WebSocket连接建立	info	\N	\N	\N
841	100100	\N	2026-06-27 09:35:10.254397	online	设备WebSocket连接建立	info	\N	\N	\N
842	100100	\N	2026-06-27 09:44:33.582762	online	设备WebSocket连接建立	info	\N	\N	\N
843	100100	\N	2026-06-27 09:44:33.655708	online	设备WebSocket连接建立	info	\N	\N	\N
844	100100	\N	2026-06-27 09:56:33.481557	online	设备WebSocket连接建立	info	\N	\N	\N
845	100100	\N	2026-06-27 09:56:33.588043	online	设备WebSocket连接建立	info	\N	\N	\N
846	100100	\N	2026-06-27 09:56:44.130368	offline	设备WebSocket断开连接	warning	\N	\N	\N
847	100100	\N	2026-06-27 09:56:50.38847	online	设备WebSocket连接建立	info	\N	\N	\N
848	100100	\N	2026-06-27 09:56:50.457702	online	设备WebSocket连接建立	info	\N	\N	\N
849	100100	\N	2026-06-27 10:00:36.551863	online	设备WebSocket连接建立	info	\N	\N	\N
850	100100	\N	2026-06-27 10:00:36.691174	online	设备WebSocket连接建立	info	\N	\N	\N
851	100100	\N	2026-06-27 10:03:17.237719	online	设备WebSocket连接建立	info	\N	\N	\N
852	100100	\N	2026-06-27 10:03:17.52969	online	设备WebSocket连接建立	info	\N	\N	\N
853	100100	\N	2026-06-27 10:24:58.993539	online	设备WebSocket连接建立	info	\N	\N	\N
854	100100	\N	2026-06-27 10:24:59.248373	online	设备WebSocket连接建立	info	\N	\N	\N
855	100100	\N	2026-06-27 10:43:23.957255	online	设备WebSocket连接建立	info	\N	\N	\N
856	100100	\N	2026-06-27 10:43:24.025221	online	设备WebSocket连接建立	info	\N	\N	\N
\.


--
-- Data for Name: device_update_logs; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.device_update_logs (id, device_id, success, version_name, version_code, error_msg, created_at) FROM stdin;
1	100101	0	1.2.43	163	download failed after 3 attempts	2026-06-29 17:59:25.384688
2	100101	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:21:43.110741
3	100100	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:21:43.671315
4	100100	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:22:44.324238
5	100101	0	1.2.42	162	download failed after 3 attempts	2026-06-29 18:23:23.750406
6	100100	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:25:05.308861
7	100101	0	1.2.44	164	download failed after 3 attempts	2026-06-29 18:28:23.887634
8	100100	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:28:58.940139
9	100101	1	1.2.44	164		2026-06-29 18:31:29.881512
10	100100	0	1.2.43	163	download failed after 3 attempts	2026-06-29 18:31:44.225639
11	100100	1	1.2.44	164		2026-06-29 18:33:30.472128
12	100100	1	1.2.45	165		2026-06-29 19:08:15.95283
13	100100	1	1.2.45	165		2026-06-29 19:12:33.485324
14	100100	1	1.2.45	165		2026-06-29 19:16:11.857288
15	100100	0	1.2.47	167	download failed after 3 attempts	2026-06-30 06:43:35.817405
16	100100	0	1.2.47	167	download failed after 3 attempts	2026-06-30 06:48:35.539134
17	100100	1	1.2.47	167		2026-06-30 06:49:15.911007
18	100100	1	1.2.47	167		2026-06-30 06:59:18.170105
19	100100	1	1.2.47	167		2026-06-30 07:04:29.70872
20	100100	1	1.2.48	168		2026-06-30 07:24:08.785417
21	100100	1	1.2.49	169		2026-06-30 07:41:15.22582
22	100101	1	1.2.49	169		2026-06-30 08:45:01.213992
23	100100	1	1.2.50	170		2026-06-30 09:27:38.310403
24	100101	1	1.2.50	170		2026-06-30 09:27:47.445625
25	100100	1	1.2.50	170		2026-06-30 18:35:21.09168
26	100103	1	1.2.50	170		2026-07-01 09:17:47.992567
27	100100	1	1.2.50	170		2026-07-02 22:04:15.23215
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.devices (id, device_id, device_name, device_type, status, remark, update_time) FROM stdin;
\.


--
-- Data for Name: door_query_cache; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.door_query_cache (request_id, device_id, board_no, lock_no, cabinet_id, is_open, door_status, query_success, created_at) FROM stdin;
3646077d	100103	1	1	27	\N	\N	\N	2026-07-01 10:37:11.958339
11b811e3	100103	1	13	27	\N	\N	\N	2026-07-01 10:38:51.222137
451a32a9	100101	2	11	24	\N	\N	\N	2026-07-01 10:39:05.622162
3ce1e67f	100103	2	7	27	\N	\N	\N	2026-07-01 10:45:37.664328
f84d0dd8	100101	2	12	24	\N	\N	\N	2026-07-01 10:48:46.896871
1f646c79	100103	1	12	27	\N	\N	\N	2026-07-01 10:49:03.818923
924e27f6	100100	1	1	16	\N	\N	\N	2026-07-01 10:49:25.582679
0f3abe13	100101	3	7	24	\N	\N	\N	2026-07-01 11:36:30.546017
5c902495	100101	2	12	24	\N	\N	\N	2026-07-01 13:31:43.686308
da50fcf4	100101	2	12	24	f	closed	t	2026-07-01 13:38:03.949423
cb9455b0	100101	2	12	24	f	closed	t	2026-07-01 13:42:39.810867
cb15b346	100101	2	12	24	f	closed	t	2026-07-01 13:46:05.806344
10c70f55	100103	2	12	27	f	closed	t	2026-07-02 07:29:38.781061
2c3143ea	100103	1	13	27	f	closed	t	2026-07-02 09:00:30.366928
64e2a857	100103	1	1	27	f	closed	t	2026-07-02 17:05:32.661227
1068d0ba	100103	3	1	27	f	closed	t	2026-07-02 17:05:37.022356
\.


--
-- Data for Name: door_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.door_records (id, device_id, board_no, lock_no, order_id, open_type, create_time) FROM stdin;
1	TEST_DEVICE_001	1	1	1	remote	2026-06-17 09:19:40
2	DEV001	1	1	1	remote	2026-06-17 09:21:09
3	123456	1	5	test001	0	2026-06-17 20:35:12
4	123456	1	5	test001	0	2026-06-17 20:41:36
5	123456	0	0	\N	manual	2026-06-17 21:01:45
6	123456	0	0	\N	manual	2026-06-17 21:07:28
7	123456	0	0	\N	manual	2026-06-17 21:07:59
8	123456	0	0	\N	manual	2026-06-17 21:10:44
9	123456	1	10	\N	YBM	2026-06-24 03:44:42
10	123456	1	10	20260624114601985736	YBM	2026-06-24 03:46:09
11	123456	1	11	\N	YBM	2026-06-24 03:58:27
12	123456	1	10	20260624143247226180	YBM	2026-06-24 06:32:58
13	123456	1	10	196	YBM	2026-06-24 09:01:04
14	123456	1	10	196	YBM	2026-06-24 10:06:50
15	123456	1	1	\N	YBM	2026-06-24 10:07:01
16	123456	1	10	196	YBM	2026-06-24 10:07:52
17	123456	1	10	196	YBM	2026-06-24 12:09:09
18	123456	1	7	178	YBM	2026-06-24 12:18:03
19	123456	1	7	178	YBM	2026-06-24 12:20:52
20	123456	1	4	\N	YBM	2026-06-25 08:49:43
21	123456	1	12	269	YBM	2026-06-25 08:56:59
22	123456	2	1	\N	YBM	2026-06-25 09:42:12
23	123456	2	2	\N	YBM	2026-06-25 09:59:45
24	101002	2	17	278	YBM	2026-06-25 11:00:10
25	101002	2	17	278	YBM	2026-06-25 11:00:22
26	101002	2	17	278	YBM	2026-06-25 11:00:28
27	123456	2	18	277	YBM	2026-06-25 11:00:42
28	101002	1	1	\N	YBM	2026-06-25 11:21:09
29	101002	1	2	\N	YBM	2026-06-25 11:21:51
30	123456	2	21	283	YBM	2026-06-25 13:10:46
31	123456	2	22	284	YBM	2026-06-25 13:14:40
32	123456	2	22	284	YBM	2026-06-25 13:15:10
33	123456	2	22	284	YBM	2026-06-25 13:19:35
34	123456	2	22	284	YBM	2026-06-25 13:22:44
35	123456	2	22	284	YBM	2026-06-25 13:28:16
36	123456	2	22	284	YBM	2026-06-25 13:29:52
37	123456	2	21	283	YBM	2026-06-25 13:32:58
38	123456	2	21	283	YBM	2026-06-25 13:35:51
39	123456	1	A24	20260625214644063856	YBM	2026-06-25 13:50:24
40	101002	1	1	\N	YBM	2026-06-25 13:55:20
41	101002	1	1	\N	YBM	2026-06-25 13:57:27
42	101002	1	1	\N	YBM	2026-06-25 14:01:32
43	101002	1	1	\N	YBM	2026-06-25 14:01:33
44	101002	1	1	\N	YBM	2026-06-25 14:01:33
45	101002	1	1	\N	YBM	2026-06-25 14:01:42
46	101002	1	1	\N	YBM	2026-06-25 14:04:53
47	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
48	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
49	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
50	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
51	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
52	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
53	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
54	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
55	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
56	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
57	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
58	123456	1	A26	20260625220242082866	YBM	2026-06-25 14:06:24
59	\N	1	1	\N	YBM	2026-06-25 14:14:33
60	123456	1	A29	20260625224205854601	YBM	2026-06-25 14:42:11
61	123456	1	A30	20260625224556086478	YBM	2026-06-25 14:46:02
62	123456	1	A30	20260625224556086478	YBM	2026-06-25 14:49:36
63	101002	1	1	\N	YBM	2026-06-25 14:50:04
64	101002	1	1	\N	YBM	2026-06-25 14:50:15
65	101002	1	1	\N	YBM	2026-06-25 14:50:39
66	101002	1	1	\N	YBM	2026-06-25 14:52:26
67	101002	1	1	\N	YBM	2026-06-25 14:52:32
68	101002	1	1	\N	YBM	2026-06-25 14:54:38
69	101002	1	1	\N	YBM	2026-06-25 14:54:46
70	101002	1	1	\N	YBM	2026-06-25 14:56:57
71	123456	1	A31	20260625230123439689	YBM	2026-06-25 15:01:31
72	123456	2	14	\N	YBM	2026-06-25 15:29:41
73	123456	1	A32	20260625233005853236	YBM	2026-06-25 15:30:11
74	123456	1	A33	20260625233407427886	YBM	2026-06-25 15:36:24
75	123456	1	A34	20260625234133881159	YBM	2026-06-25 15:41:41
76	123456	1	A34	20260625234133881159	YBM	2026-06-25 15:41:50
77	123456	1	A35	20260625234710366176	YBM	2026-06-25 15:47:15
78	123456	1	A35	20260625234710366176	YBM	2026-06-25 15:47:23
79	123456	1	A36	20260625234755209987	YBM	2026-06-25 15:48:02
80	123456	1	A36	20260625234755209987	YBM	2026-06-25 15:48:12
81	123456	1	A37	20260625235027193965	YBM	2026-06-25 15:50:39
82	123456	1	A38	20260625235218620187	YBM	2026-06-25 15:52:25
83	123456	1	A38	20260625235218620187	YBM	2026-06-25 15:52:35
84	123456	3	38	300	YBM	2026-06-25 22:27:51
85	123456	3	37	299	YBM	2026-06-25 22:27:56
86	123456	2	16	\N	YBM	2026-06-25 22:29:01
87	123456	3	1	\N	YBM	2026-06-25 22:29:17
88	123456	3	2	\N	YBM	2026-06-25 22:29:23
89	123456	3	3	\N	YBM	2026-06-25 22:29:27
90	123456	3	38	300	YBM	2026-06-25 22:29:40
91	123456	3	7	\N	YBM	2026-06-25 22:30:46
92	123456	3	6	\N	YBM	2026-06-25 22:30:50
93	123456	3	5	\N	YBM	2026-06-25 22:30:53
94	123456	3	16	\N	YBM	2026-06-25 22:31:51
95	123456	3	15	\N	YBM	2026-06-25 22:31:57
96	123456	3	16	\N	YBM	2026-06-25 22:32:00
97	123456	3	14	\N	YBM	2026-06-25 22:32:04
98	123456	3	7	\N	YBM	2026-06-25 22:39:13
99	123456	3	38	300	YBM	2026-06-25 22:57:09
100	123456	3	8	\N	YBM	2026-06-25 22:57:24
101	123456	3	38	300	YBM	2026-06-25 23:03:17
102	123456	3	8	\N	YBM	2026-06-25 23:11:40
103	123456	3	16	\N	YBM	2026-06-25 23:11:45
104	123456	3	38	300	YBM	2026-06-25 23:28:33
105	123456	3	8	\N	YBM	2026-06-25 23:36:02
106	101002	1	1	\N	YBM	2026-06-26 00:42:23
107	123456	1	1	\N	YBM	2026-06-26 00:47:02
108	123456	1	1	\N	YBM	2026-06-26 00:50:45
109	123456	3	12	20260626091635740650	YBM	2026-06-26 01:17:16
110	123456	3	12	20260626091635740650	YBM	2026-06-26 01:17:42
111	123456	1	1	\N	YBM	2026-06-26 01:34:58
112	123456	1	1	\N	YBM	2026-06-26 01:34:58
113	123456	1	1	\N	YBM	2026-06-26 01:34:58
114	123456	1	1	\N	YBM	2026-06-26 01:35:17
115	123456	1	3	\N	YBM	2026-06-26 01:35:20
116	123456	1	1	311	YBM	2026-06-26 01:35:37
117	123456	1	5	315	YBM	2026-06-26 01:49:04
118	123456	1	1	\N	YBM	2026-06-26 02:38:40
119	123456	1	5	315	YBM	2026-06-26 04:02:45
120	123456	1	6	316	YBM	2026-06-26 04:25:43
121	123456	1	6	316	YBM	2026-06-26 04:44:18
122	100100	1	1	\N	YBM	2026-06-26 06:42:11
123	100100	1	1	\N	YBM	2026-06-26 06:47:18
124	100100	1	1	\N	YBM	2026-06-26 07:02:50
125	100100	1	2	\N	YBM	2026-06-26 07:02:59
126	100100	1	1	\N	YBM	2026-06-26 07:42:26
127	100100	1	1	\N	YBM	2026-06-26 07:42:52
128	100100	1	1	\N	YBM	2026-06-26 07:42:54
129	100100	1	1	\N	YBM	2026-06-26 07:42:56
130	100100	1	1	\N	YBM	2026-06-26 07:42:58
131	100100	1	2	\N	YBM	2026-06-26 07:43:01
132	100100	2	14	\N	YBM	2026-06-26 07:43:04
133	100100	1	1	\N	YBM	2026-06-26 07:58:00
134	100100	1	1	\N	YBM	2026-06-26 07:58:02
135	100100	1	2	\N	YBM	2026-06-26 07:58:04
136	100100	2	6	20260626155413206167	YBM	2026-06-26 17:28:40.710572
137	100100	2	4	20260626152942192997	YBM	2026-06-26 17:34:14.772993
138	100100	2	22	332	YBM	2026-06-26 17:49:02.718622
139	100100	2	1		YBM	2026-06-26 18:00:47.295769
140	100100	2	2		YBM	2026-06-26 18:02:49.467996
141	100100	2	1		YBM	2026-06-26 18:03:04.705283
142	100100	2	1		YBM	2026-06-26 18:09:25.596607
143	100100	1	1		YBM	2026-06-26 19:31:03.002828
144	100100	2	1		YBM	2026-06-26 19:31:07.517309
145	100100	2	3		YBM	2026-06-26 19:47:07.679332
146	100100	2	3		YBM	2026-06-26 19:47:19.025095
147	100100	2	1		YBM	2026-06-26 19:51:55.631717
148	100100	1	13	20260626195241140324	YBM	2026-06-26 19:53:03.057647
149	100100	2	3		YBM	2026-06-26 19:54:39.222165
150	100100	1	15		YBM	2026-06-26 19:54:45.972923
151	100100	2	3		YBM	2026-06-26 19:54:50.09196
152	100100	1	1		YBM	2026-06-26 19:55:26.877275
153	100100	1	14	20260626203440517799	YBM	2026-06-26 20:35:02.323958
154	100100	2	15	20260626203849898493	YBM	2026-06-26 20:39:21.522362
155	100100	1	2	20260626211119806002	YBM	2026-06-26 21:11:38.372213
156	100100	1	3	20260626211337376195	YBM	2026-06-26 21:14:06.708637
157	100100	2	31	353	YBM	2026-06-27 06:34:58.789463
158	100100	1	3	359	YBM	2026-06-27 06:35:15.702873
159	100100	2	31	353	YBM	2026-06-27 06:35:29.634192
160	100100	1	1		YBM	2026-06-27 06:35:47.738114
161	100100	1	1		YBM	2026-06-27 06:36:00.46266
162	100100	1	3	359	YBM	2026-06-27 06:36:14.528238
163	100100	2	31	353	YBM	2026-06-27 06:54:21.404689
164	100100	1	14	352	YBM	2026-06-27 07:02:59.185218
165	100100	1	1		YBM	2026-06-27 07:07:46.902472
166	100100	1	1		YBM	2026-06-27 07:07:57.014345
167	100100	1	16		YBM	2026-06-27 07:08:03.732724
168	100100	1	2		YBM	2026-06-27 09:31:15.556471
169	100100	1	2		YBM	2026-06-27 09:34:43.595835
170	100100	1	1		YBM	2026-06-27 10:03:35.861388
171	100100	1	15		YBM	2026-06-27 10:03:41.127345
172	100100	2	3		YBM	2026-06-27 10:03:58.54928
173	100100	2	16		YBM	2026-06-27 10:04:08.616789
174	100100	3	10	20260627100422451091	YBM	2026-06-27 10:05:21.633816
175	101001	1	2		YBM	2026-06-27 11:17:24.079408
176	101001	1	2		YBM	2026-06-27 11:17:31.899584
177	101001	1	2		YBM	2026-06-27 11:17:51.953095
178	101001	1	2		YBM	2026-06-27 11:18:10.716614
179	101001	1	2		YBM	2026-06-27 11:18:32.624113
180	101001	1	2		YBM	2026-06-27 11:18:56.387405
181	101001	1	2		YBM	2026-06-27 11:20:28.725241
182	101001	1	10	20260627112151757434	YBM	2026-06-27 11:22:27.340018
183	101001	1	1		YBM	2026-06-27 11:24:21.089085
184	101001	1	1		YBM	2026-06-27 11:24:44.748915
185	101001	1	1		YBM	2026-06-27 11:25:12.138513
186	101001	1	2		YBM	2026-06-27 11:25:33.265636
187	101001	1	2		YBM	2026-06-27 11:27:03.102306
188	101001	1	2		YBM	2026-06-27 11:27:19.788709
189	101001	1	2		YBM	2026-06-27 11:34:39.256151
190	101001	1	2		YBM	2026-06-27 11:35:05.458595
191	101001	1	10		YBM	2026-06-27 11:36:49.927683
192	101001	1	1		YBM	2026-06-27 11:40:26.108381
193	101001	1	1		YBM	2026-06-27 11:40:35.477012
194	101001	1	11	20260627114452740267	WT	2026-06-27 11:45:25.258865
195	100100	1	1		YBM	2026-06-27 11:55:37.838345
196	100100	1	1		YBM	2026-06-27 11:55:46.097519
197	100100	1	1		YBM	2026-06-27 11:56:21.1827
198	100100	1	1		YBM	2026-06-27 11:59:35.726011
199	100100	1	1		YBM	2026-06-27 11:59:49.203863
200	100100	1	1		YBM	2026-06-27 11:59:55.794778
201	100100	1	10		YBM	2026-06-27 12:00:00.40752
202	100100	1	10		YBM	2026-06-27 12:00:04.742742
203	100100	1	2	20260627123001901085	YBM	2026-06-27 12:30:16.951011
204	100100	1	2	376	YBM	2026-06-27 12:30:23.812217
205	100100	1	2	376	YBM	2026-06-27 12:30:26.167561
206	100100	1	2	376	YBM	2026-06-27 12:30:27.454293
207	100100	1	2		YBM	2026-06-27 12:32:08.162881
208	101001	1	1		YBM	2026-06-27 14:00:41.503607
209	101001	1	1		YBM	2026-06-27 14:00:49.857725
210	101001	1	1		WT	2026-06-27 14:11:11.919237
211	101001	1	1		WT	2026-06-27 14:12:07.737293
212	101001	1	1		WT	2026-06-27 14:13:03.612532
213	101001	1	1		WT	2026-06-27 14:19:48.883615
214	100100	1	2	376	YBM	2026-06-27 14:27:59.811893
215	100100	1	2	376	YBM	2026-06-27 14:28:06.976602
216	101001	1	1		WT	2026-06-27 14:31:38.577035
217	101001	1	1		WT	2026-06-27 14:42:31.79207
218	101001	1	1		WT	2026-06-27 14:42:43.862746
219	101001	1	1		WT	2026-06-27 15:15:32.363497
220	101001	1	1		WT	2026-06-27 15:17:30.738994
221	101001	1	1		WT	2026-06-27 15:17:47.889182
222	101001	1	1		WT	2026-06-27 15:36:38.798084
223	101001	1	1		WT	2026-06-27 15:36:45.365057
224	101001	1	1		WT	2026-06-27 15:43:06.498132
225	100100	1	5	20260627155423256198	YBM	2026-06-27 15:54:39.124728
226	100100	1	5	379	YBM	2026-06-27 15:54:46.83573
227	100100	1	6	20260627160102439699	YBM	2026-06-27 16:01:17.988511
228	100100	1	6	380	YBM	2026-06-27 16:01:24.254021
229	100100	1	6	380	YBM	2026-06-27 16:01:25.896282
230	100100	1	7	20260627160609859877	YBM	2026-06-27 16:06:33.798075
231	100100	1	8	20260627161116110216	YBM	2026-06-27 16:11:33.424228
232	100100	1	8	382	YBM	2026-06-27 16:11:39.849037
233	100100	1	8	382	YBM	2026-06-27 16:11:42.765564
234	100100	1	10	20260627163808998198	YBM	2026-06-27 16:38:26.541136
235	101001	1	2	20260627180155088478	WT	2026-06-27 18:02:24.794482
236	101001	1	3	20260627180357317523	WT	2026-06-27 18:04:23.777241
237	101001	1	1		WT	2026-06-27 22:44:59.317513
238	100100	1	14	20260628075013324398	YBM	2026-06-28 07:50:38.579811
239	101001	1	4	20260628082951623603	WT	2026-06-28 08:30:08.597418
240	101001	1	5	20260628083429993292	WT	2026-06-28 08:35:13.974034
241	100100	2	2	20260628084105846088	YBM	2026-06-28 08:41:27.75471
242	100100	2	3	20260628084559522187	YBM	2026-06-28 08:46:21.766696
243	101001	1	1		WT	2026-06-28 09:01:48.235463
244	101001	1	1		WT	2026-06-28 09:02:21.852486
245	101001	1	1		WT	2026-06-28 09:07:42.869597
246	100100	2	5	20260628093341461556	YBM	2026-06-28 09:34:39.713336
247	100100	2	6	20260628093722986540	YBM	2026-06-28 09:37:42.669354
248	100100	2	7	20260628094511242522	YBM	2026-06-28 09:45:59.483708
249	101001	1	1		WT	2026-06-28 11:01:38.682996
250	101001	1	1	test_wt_v2_0628	WT	2026-06-28 11:32:52.464013
251	101001	1	1		WT	2026-06-28 11:33:56.440954
252	101001	1	1		WT	2026-06-28 11:35:49.499495
253	100100	2	9	20260628145155650131	YBM	2026-06-28 14:52:23.335601
254	100100	2	9	405	YBM	2026-06-28 14:52:35.242697
255	100100	2	11	20260628152256512875	YBM	2026-06-28 15:23:20.170806
256	100100	2	12	20260628152957019526	YBM	2026-06-28 15:30:18.667362
257	100100	2	1		YBM	2026-06-29 14:10:11.930726
258	100100	2	16		YBM	2026-06-29 14:10:25.993702
259	100100	1	1		YBM	2026-06-29 14:27:08.907076
260	100100	1	16		YBM	2026-06-29 14:27:13.153185
261	100101	1	1		YBM	2026-06-29 17:58:49.943371
262	100101	1	1		YBM	2026-06-29 17:58:59.429119
263	100101	1	1		YBM	2026-06-29 18:01:47.924831
264	100101	1	1		YBM	2026-06-29 18:02:57.259235
265	100100	1	1		YBM	2026-06-29 18:34:55.139601
266	100100	1	1		YBM	2026-06-29 18:48:00.607375
267	100101	1	1	20260629185752358994	YBM	2026-06-29 18:58:05.338125
268	100100	1	1		YBM	2026-06-29 19:07:16.439413
269	100100	1	1		YBM	2026-06-29 19:13:08.171311
270	100100	1	1		YBM	2026-06-29 19:13:19.932361
271	100100	1	1		YBM	2026-06-29 19:17:15.975671
272	100100	1	1		YBM	2026-06-29 19:49:48.543162
273	100100	1	1		YBM	2026-06-29 20:04:23.834251
274	100100	2	1		YBM	2026-06-29 20:11:47.036434
275	100100	2	2		YBM	2026-06-29 20:11:49.120075
276	100100	1	1		YBM	2026-06-29 21:06:15.876232
277	100100	1	1		YBM	2026-06-29 21:06:35.172079
278	100101	1	1		YBM	2026-06-29 21:17:05.316974
279	100100	2	16	20260629212626345012	YBM	2026-06-29 21:26:52.8618
280	100100	2	16	413	YBM	2026-06-29 21:27:06.075798
281	100101	1	1		YBM	2026-06-29 21:41:33.553255
282	100101	1	1		YBM	2026-06-29 21:42:09.39771
283	100101	1	1		YBM	2026-06-29 21:42:39.144564
284	100101	1	1		YBM	2026-06-29 21:43:24.713408
285	100100	2	2		YBM	2026-06-29 21:44:10.420219
286	100100	2	2		YBM	2026-06-29 21:44:15.149402
287	100100	2	2		YBM	2026-06-29 21:44:23.171959
288	100101	1	1		YBM	2026-06-29 21:45:20.15733
289	100101	1	1		YBM	2026-06-29 21:45:36.332599
290	100101	1	1		YBM	2026-06-29 21:46:10.726343
291	100100	1	10		YBM	2026-06-29 21:46:22.71304
292	100100	2	2		YBM	2026-06-29 21:46:24.696673
293	100101	1	1		YBM	2026-06-29 21:46:50.305969
294	100101	1	1		YBM	2026-06-29 21:47:01.332641
295	100101	1	1		YBM	2026-06-29 21:47:54.093014
296	100101	1	1		YBM	2026-06-29 21:48:14.642625
297	100101	1	1		YBM	2026-06-29 21:49:09.388508
298	100101	1	1		YBM	2026-06-29 21:50:59.655457
299	100100	1	9	20260629225052014226	YBM	2026-06-29 22:51:26.722028
300	100100	1	9	422	YBM	2026-06-29 22:51:38.250472
301	100100	1	11	20260629225224739911	YBM	2026-06-29 22:52:47.252035
302	100100	1	11	424	YBM	2026-06-29 22:53:13.965713
303	100100	1	10	423	YBM	2026-06-29 22:53:18.072603
304	100100	1	9	422	YBM	2026-06-29 22:53:22.651312
305	100100	1	11	424	YBM	2026-06-29 22:53:27.503918
306	100100	1	11		YBM	2026-06-29 22:54:37.307648
307	100100	1	11	424	YBM	2026-06-29 22:58:40.798704
308	100100	1	11	424	YBM	2026-06-29 23:00:00.811437
309	100100	1	9	422	YBM	2026-06-29 23:00:06.665536
310	100100	1	11	424	YBM	2026-06-29 23:01:38.605745
311	100100	1	11		YBM	2026-06-30 06:47:59.307582
312	100100	1	11		YBM	2026-06-30 07:02:42.830258
313	100100	1	1		YBM	2026-06-30 07:02:49.035021
314	100100	1	3		YBM	2026-06-30 07:02:57.266608
315	100100	1	2		YBM	2026-06-30 07:04:22.012273
316	100100	1	3		YBM	2026-06-30 07:04:22.382264
317	100100	1	4		YBM	2026-06-30 07:04:28.978664
318	100100	2	3	20260630070731985915	YBM	2026-06-30 07:08:08.530842
319	100100	2	3	432	YBM	2026-06-30 07:08:14.820521
320	100100	2	3	432	YBM	2026-06-30 07:08:18.467624
321	100100	2	7	20260630071102574249	YBM	2026-06-30 07:11:20.904692
322	100100	2	9	20260630072823856658	YBM	2026-06-30 07:28:54.321585
323	100100	2	9	20260630072823856658	YBM	2026-06-30 07:28:54.444181
324	100100	2	11	20260630075016897517	YBM	2026-06-30 07:50:37.438644
325	100100	2	11	440	YBM	2026-06-30 07:50:43.175227
326	100100	2	12	20260630075135072321	YBM	2026-06-30 07:51:52.955115
327	100101	1	1		YBM	2026-06-30 08:45:45.975405
328	100101	1	8	20260630090354376183	YBM	2026-06-30 09:04:02.328782
329	100101	1	9	20260630091101819765	YBM	2026-06-30 09:11:19.745932
330	100100	1	5	20260630091211403812	YBM	2026-06-30 09:13:28.18941
331	100101	1	11	20260630093015601516	YBM	2026-06-30 09:30:39.780994
332	100101	1	11	20260630093015601516	YBM	2026-06-30 09:30:39.961738
333	100101	1	15	20260630093905337250	YBM	2026-06-30 09:39:23.528154
334	100100	1	12	20260630094022158852	YBM	2026-06-30 09:49:43.268354
335	100100	1	16	478	YBM	2026-06-30 09:52:45.632332
336	100100	1	16	478	YBM	2026-06-30 09:52:48.025159
337	100100	1	12	470	YBM	2026-06-30 09:53:20.666603
338	100100	2	2	20260630095414309240	YBM	2026-06-30 09:54:35.060545
339	100100	2	2	20260630095414309240	YBM	2026-06-30 09:54:35.347354
340	100101	2	7	20260630101459139734	YBM	2026-06-30 10:15:35.271449
341	100100	2	6	20260630101943467907	YBM	2026-06-30 10:20:03.54907
342	100100	2	6	487	YBM	2026-06-30 10:20:08.708711
343	100100	2	6	487	YBM	2026-06-30 10:20:17.608822
344	100100	2	6		YBM	2026-06-30 10:20:34.090533
345	100100	2	6		YBM	2026-06-30 10:20:42.449595
346	100100	2	7	20260630105405124207	YBM	2026-06-30 10:54:40.869212
347	100100	2	7	488	YBM	2026-06-30 10:54:46.261232
348	100100	2	7	488	YBM	2026-06-30 10:54:50.082436
349	100100	2	23	488	YBM	2026-06-30 10:57:08.924072
350	100100	2	23	488	YBM	2026-06-30 10:57:28.792694
351	100100	2	7		YBM	2026-06-30 10:58:00.3729
352	100100	2	7		YBM	2026-06-30 10:58:58.873946
353	100100	2	23	488	YBM	2026-06-30 10:59:54.182377
354	100100	2	23	488	YBM	2026-06-30 11:00:08.172771
355	100100	2	11	20260630110420701345	YBM	2026-06-30 11:04:39.117063
356	100100	2	11	492	YBM	2026-06-30 11:04:44.843203
357	100100	2	10	491	YBM	2026-06-30 11:05:24.837296
358	100100	2	12	20260630111758918131	YBM	2026-06-30 11:18:17.923867
359	100100	2	12	493	YBM	2026-06-30 11:18:25.536618
360	100101	2	8	20260630112639381589	YBM	2026-06-30 11:26:59.020428
361	100101	2	8	494	YBM	2026-06-30 11:27:07.244798
362	100101	2	10	20260630113938731600	YBM	2026-06-30 11:40:00.958974
363	100100	2	13	20260630114500326407	YBM	2026-06-30 11:45:16.989931
364	100100	2	13	497	YBM	2026-06-30 11:49:15.531079
365	100101	2	11	20260630120430300084	YBM	2026-06-30 12:04:52.595139
366	100101	2	13	20260630122321456133	YBM	2026-06-30 12:23:42.559744
367	100101	2	14	20260630123806951872	YBM	2026-06-30 12:38:27.240106
368	100101	3	4	20260630123939351137	YBM	2026-06-30 12:40:01.289122
369	100101	3	1	20260630123932308808	YBM	2026-06-30 12:40:01.38284
370	100101	3	3	20260630123936503848	YBM	2026-06-30 12:40:07.374217
371	100101	3	5	20260630123952112437	YBM	2026-06-30 12:40:15.98035
372	100101	3	9	20260630124010539133	YBM	2026-06-30 12:40:30.921776
373	100101	3	7	20260630123959529209	YBM	2026-06-30 12:40:50.179061
374	100101	3	10	20260630124135737562	YBM	2026-06-30 12:42:00.664721
375	100101	3	12	20260630125108236602	YBM	2026-06-30 12:51:45.842866
376	100101	3	12	20260630125108236602	YBM	2026-06-30 12:51:46.01883
377	100101	3	12	514	YBM	2026-06-30 12:52:21.834812
378	100101	3	14	20260630125130451288	YBM	2026-06-30 12:52:31.111164
379	100101	3	15	20260630130421202757	YBM	2026-06-30 13:04:54.47108
380	100101	4	1	20260630130451524847	YBM	2026-06-30 13:05:24.69847
381	100101	4	3	20260630131251511581	YBM	2026-06-30 13:13:16.358173
382	100101	4	5	20260630132913118022	YBM	2026-06-30 13:29:47.12957
383	100101	4	6	20260630133057596999	YBM	2026-06-30 13:31:26.686877
384	100101	4	8	20260630133404595989	YBM	2026-06-30 13:34:33.287737
385	100100	2	15	20260630134559767386	YBM	2026-06-30 13:46:20.445059
386	100101	4	10	20260630134555889371	YBM	2026-06-30 13:46:23.976211
387	100100	2	15	530	YBM	2026-06-30 13:46:27.683317
388	100100	2	15	530	YBM	2026-06-30 13:46:32.165383
389	100100	2	15	530	YBM	2026-06-30 13:46:51.715518
390	100100	2	15	530	YBM	2026-06-30 13:46:56.585164
391	100101	4	12	20260630134846640888	YBM	2026-06-30 13:49:06.178843
392	100100	2	15	530	YBM	2026-06-30 13:49:07.504898
393	100100	2	15	530	YBM	2026-06-30 13:49:11.792453
394	100101	4	13	20260630140052363155	YBM	2026-06-30 14:01:19.943276
395	100101	4	15	20260630141511676928	YBM	2026-06-30 14:15:36.917777
396	100101	1	1	20260630141613856704	YBM	2026-06-30 14:16:30.094043
397	100101	1	2	20260630141616444325	YBM	2026-06-30 14:16:50.139383
398	100101	1	3	20260630141812626447	YBM	2026-06-30 14:18:37.101546
399	100101	1	5	20260630144750539670	YBM	2026-06-30 14:48:09.04823
400	100101	3	12	514	YBM	2026-06-30 14:51:14.797436
401	100101	1	7	20260630145256257792	YBM	2026-06-30 14:53:12.653362
402	100101	1	7	20260630145256257792	YBM	2026-06-30 14:53:12.798531
403	100101	2	14		YBM	2026-06-30 15:09:22.964234
404	100101	1	9	20260630152451000570	YBM	2026-06-30 15:25:19.23546
405	100101	1	11	20260630152726665334	YBM	2026-06-30 15:27:44.679125
406	100101	1	12	20260630153014147323	YBM	2026-06-30 15:30:47.089534
407	100101	1	13	20260630155114892074	YBM	2026-06-30 15:51:36.246515
408	100101	1	1	537	YBM	2026-06-30 16:56:09.637197
409	100100	2	16	20260630170632583423	YBM	2026-06-30 17:06:55.339107
410	100100	2	16	550	YBM	2026-06-30 17:08:19.489604
411	100100	1	1	20260630171440638549	YBM	2026-06-30 17:15:14.079407
412	100101	1	13	549	YBM	2026-06-30 17:39:29.165414
413	100100	1	3	20260630180308393971	YBM	2026-06-30 18:03:26.085858
414	100100	1	6	20260630180349917874	YBM	2026-06-30 18:04:04.471303
415	100100	1	7	20260630184408267234	YBM	2026-06-30 18:44:45.79894
416	100100	1	7	20260630184408267234	YBM	2026-06-30 18:44:45.942936
417	100100	1	9	20260630185425159147	YBM	2026-06-30 18:55:37.184263
418	100100	1	9	558	YBM	2026-06-30 18:55:42.782919
419	100100	1	9	558	remote_reopen	2026-06-30 18:55:42.784552
420	100101	1	15	20260701075530128450	YBM	2026-07-01 07:55:48.445872
421	100100	1	1		YBM	2026-07-01 07:58:45.149465
422	100100	1	14	20260701075928784045	YBM	2026-07-01 07:59:46.87162
423	100100	1	14	564	YBM	2026-07-01 07:59:52.092639
424	100100	1	14	564	remote_reopen	2026-07-01 07:59:52.094092
425	100101	2	1	20260701080252681224	YBM	2026-07-01 08:03:09.604746
426	100101	2	2	20260701083251034222	YBM	2026-07-01 08:33:15.276643
427	100101	2	3	20260701083356818933	YBM	2026-07-01 08:34:20.717368
428	100101	2	5	20260701084052491507	YBM	2026-07-01 08:41:16.460283
429	100101	2	6	20260701085322762885	YBM	2026-07-01 08:53:52.602939
430	100101	2	8	20260701090447589462	YBM	2026-07-01 09:05:25.816991
431	100101	2	8	20260701090447589462	YBM	2026-07-01 09:05:25.906982
432	100103	1	1		YBM	2026-07-01 09:18:20.499429
433	100103	3	16		YBM	2026-07-01 09:18:26.657286
434	100103	1	2		YBM	2026-07-01 09:20:09.935372
435	100101	4	2	merchant_remote	YBM	2026-07-01 09:25:56.191611
436	100101	4	1	merchant_remote	YBM	2026-07-01 09:26:23.56003
437	100103	1	12	merchant_remote	YBM	2026-07-01 10:49:01.76439
438	100100	1	1	merchant_remote	YBM	2026-07-01 10:49:22.32964
439	100103	1	3	20260701115715162390	YBM	2026-07-01 11:57:38.838454
440	100101	2	13	20260701115720962016	YBM	2026-07-01 11:57:43.777348
441	100101	2	14	20260701115720312297	YBM	2026-07-01 11:57:44.347405
442	100101	2	14	20260701115720312297	YBM	2026-07-01 11:57:44.517976
443	100103	1	5	20260701115720270337	YBM	2026-07-01 11:57:45.893932
444	100103	1	6	20260701115727590523	YBM	2026-07-01 11:57:46.544234
445	100103	1	6	20260701115727590523	YBM	2026-07-01 11:57:46.61906
446	100103	1	9	20260701115757810612	YBM	2026-07-01 11:58:19.627924
447	100101	2	16	20260701115824636294	YBM	2026-07-01 11:58:41.272996
448	100103	1	13	20260701115843896819	YBM	2026-07-01 11:58:56.698117
449	100103	1	10	20260701115813210130	YBM	2026-07-01 11:58:57.560545
450	100103	1	12	20260701115838902322	YBM	2026-07-01 11:58:58.963942
451	100103	1	11	20260701115835256322	YBM	2026-07-01 11:59:04.205465
452	100103	1	14	20260701115900319392	YBM	2026-07-01 11:59:26.808053
453	100101	3	6	20260701120639790566	YBM	2026-07-01 12:07:21.209586
454	100101	3	7	20260701125600825759	YBM	2026-07-01 12:56:18.526203
455	100101	3	8	20260701130626543594	YBM	2026-07-01 13:07:02.265432
456	100101	1	6	20260701141804957030	YBM	2026-07-01 14:18:28.548882
457	100101	3	13	20260701145427482126	YBM	2026-07-01 14:54:48.687859
458	100100	1	4	20260701152234730339	YBM	2026-07-01 15:22:52.179448
459	100100	1	4	20260701152234730339	YBM	2026-07-01 15:22:58.311795
460	100100	1	1		YBM	2026-07-01 18:40:21.804229
461	100100	1	1		YBM	2026-07-01 19:48:46.568085
462	100101	4	2	20260702074556912851	YBM	2026-07-02 07:46:37.942431
463	100101	4	2	20260702074556912851	YBM	2026-07-02 07:46:38.014269
464	100101	4	4	20260702074612869156	YBM	2026-07-02 07:46:45.853912
465	100101	4	9	20260702074733928541	YBM	2026-07-02 07:47:55.866475
466	100103	2	2	20260702074750034164	YBM	2026-07-02 07:48:20.827746
467	100101	4	11	20260702074836334811	YBM	2026-07-02 07:49:13.251976
468	100103	2	3	20260702075044906912	YBM	2026-07-02 07:51:08.915541
469	100103	2	4	20260702075630097930	YBM	2026-07-02 07:56:46.060066
470	100101	4	14	20260702080225458420	YBM	2026-07-02 08:03:19.655074
471	100103	2	7	20260702080341688802	YBM	2026-07-02 08:04:04.190068
472	100103	2	7	20260702080341688802	YBM	2026-07-02 08:04:04.322949
473	100103	2	6	20260702080341534703	YBM	2026-07-02 08:04:11.76136
474	100101	4	16	20260702080418511793	YBM	2026-07-02 08:04:37.352097
475	100101	1	8	20260702080513726588	YBM	2026-07-02 08:05:44.040305
476	100101	3	3	20260702080815398352	YBM	2026-07-02 08:08:32.897276
477	100103	2	12	20260702081123882535	YBM	2026-07-02 08:11:49.501505
478	100101	3	10	20260702081438390022	YBM	2026-07-02 08:15:01.841537
479	100101	3	12	20260702081546040373	YBM	2026-07-02 08:16:18.12473
480	100103	2	13	20260702081622517982	YBM	2026-07-02 08:16:47.051655
481	100103	2	13	20260702081622517982	YBM	2026-07-02 08:16:47.21912
482	100101	3	14	20260702081651889788	YBM	2026-07-02 08:17:16.147794
483	100101	3	15	20260702081738212190	YBM	2026-07-02 08:17:55.15362
485	100103	2	15	20260702082339209075	YBM	2026-07-02 08:23:59.337084
489	100103	3	2	20260702083352775935	YBM	2026-07-02 08:34:13.583647
490	100101	4	5	20260702083353472648	YBM	2026-07-02 08:34:15.646282
491	100101	4	5	20260702083353472648	YBM	2026-07-02 08:34:15.714262
495	100103	3	3	20260702083627459366	YBM	2026-07-02 08:36:51.837785
496	100103	3	4	20260702084221943712	YBM	2026-07-02 08:42:45.849064
498	100101	4	12	20260702084500628342	YBM	2026-07-02 08:45:30.138441
499	100101	4	12	20260702084500628342	YBM	2026-07-02 08:45:30.301557
502	100103	3	7	20260702084753583818	YBM	2026-07-02 08:49:47.227275
484	100103	2	14	20260702081807013160	YBM	2026-07-02 08:18:25.330102
486	100103	3	1	20260702083221633278	YBM	2026-07-02 08:32:49.689994
487	100101	4	3	20260702083258247995	YBM	2026-07-02 08:33:14.147579
488	100101	4	1	20260702083242496787	YBM	2026-07-02 08:33:17.341751
492	100101	4	6	20260702083423681975	YBM	2026-07-02 08:34:45.043587
493	100101	4	9	20260702074733928541	YBM	2026-07-02 08:35:11.669735
494	100101	4	8	20260702083539933571	YBM	2026-07-02 08:36:05.606655
497	100101	4	10	20260702084440802683	YBM	2026-07-02 08:45:01.040733
500	100103	3	7	20260702084753583818	YBM	2026-07-02 08:48:12.843924
501	100101	4	15	20260702084803210252	YBM	2026-07-02 08:48:20.770543
503	100103	3	9	20260702085549357029	YBM	2026-07-02 08:56:14.951344
504	100101	1	1	20260702090033429063	YBM	2026-07-02 09:00:53.282204
505	100101	1	2	20260702090827849691	YBM	2026-07-02 09:08:51.693905
506	100103	3	11	20260702091414791295	YBM	2026-07-02 09:14:32.377526
507	100103	3	11	20260702091414791295	YBM	2026-07-02 09:14:32.459245
508	100101	1	3	20260702092715633641	YBM	2026-07-02 09:27:35.317308
509	100103	3	14	20260702092712724404	YBM	2026-07-02 09:27:38.338176
510	100103	3	12	20260702092709666775	YBM	2026-07-02 09:27:46.949444
511	100101	1	5	20260702092734180783	YBM	2026-07-02 09:27:57.749912
512	100101	1	7	20260702092747248696	YBM	2026-07-02 09:28:18.540647
513	100103	3	15	20260702092830764645	YBM	2026-07-02 09:28:48.749753
514	100101	1	11	20260702092841308699	YBM	2026-07-02 09:29:01.750292
515	100101	1	11	20260702092841308699	YBM	2026-07-02 09:29:01.771542
516	100101	1	12	20260702092933837798	YBM	2026-07-02 09:30:07.128878
517	100103	3	16	20260702093419009655	YBM	2026-07-02 09:34:34.273169
518	100103	1	1	20260702093614692304	YBM	2026-07-02 09:36:31.649393
519	100101	1	13	20260702093610225179	YBM	2026-07-02 09:36:36.452015
520	100101	1	12	1461	QM	2026-07-02 09:46:01.695884
521	100101	1	3	1455	QM	2026-07-02 09:47:42.563166
522	100103	3	2	1437	QM	2026-07-02 09:47:57.820121
523	100103	3	4	1442	QM	2026-07-02 09:48:31.26081
524	100103	3	16	1462	QM	2026-07-02 09:49:13.818427
525	100103	1	1	1464	QM	2026-07-02 09:57:05.688354
526	100101	1	3		YBM	2026-07-02 09:59:08.471078
527	100103	2	14	1431	QM	2026-07-02 09:59:24.368959
528	100101	4	4		YBM	2026-07-02 09:59:40.981607
529	100101	4	1		YBM	2026-07-02 09:59:54.220156
530	100103	2	13	1428	QM	2026-07-02 10:00:04.222786
531	100101	4	4	1410	QM	2026-07-02 10:00:04.632871
532	100103	1	2	20260702100050634764	YBM	2026-07-02 10:01:40.288805
533	100101	1	15	20260702100349927451	YBM	2026-07-02 10:04:12.723585
534	100103	2	6	1419	QM	2026-07-02 10:05:21.388895
535	100101	4	3	1436	QM	2026-07-02 10:10:01.715287
536	100103	3	9	1448	QM	2026-07-02 10:10:23.70096
537	100101	4	15	1447	QM	2026-07-02 10:11:34.390273
538	100101	2	1	20260702101247406216	YBM	2026-07-02 10:13:20.321244
539	100101	2	3	20260702101512496081	YBM	2026-07-02 10:15:34.619685
540	100103	1	3	20260702101724901386	YBM	2026-07-02 10:17:50.467765
541	100103	1	3	20260702101724901386	YBM	2026-07-02 10:17:50.481583
542	100101	1	11	1460	QM	2026-07-02 10:17:50.96913
543	100101	2	3	1470	QM	2026-07-02 10:21:38.339422
544	100101	3	15	1430	QM	2026-07-02 10:22:42.64278
545	100101	2	4	20260702102316076531	YBM	2026-07-02 10:23:31.670422
546	100103	3	7	1446	QM	2026-07-02 10:23:44.648209
547	100101	2	5	20260702102630123341	YBM	2026-07-02 10:26:59.16357
548	100103	1	3	1471	QM	2026-07-02 10:27:23.115306
549	100103	1	2	1465	QM	2026-07-02 10:27:41.562402
550	100101	2	6	20260702102723971816	YBM	2026-07-02 10:27:49.583266
551	100101	2	7	20260702102735750065	YBM	2026-07-02 10:27:54.576862
552	100103	3	15	1458	QM	2026-07-02 10:28:02.847253
553	100101	2	8	20260702103004600615	YBM	2026-07-02 10:30:21.009516
554	100101	2	8	1476	QM	2026-07-02 10:30:50.612576
555	100101	1	5	1456	QM	2026-07-02 10:31:11.322877
556	100101	1	13	1463	QM	2026-07-02 10:31:24.522308
557	100101	1	7	1457	QM	2026-07-02 10:32:09.126903
558	100101	2	9	20260702103315015792	YBM	2026-07-02 10:33:37.593083
559	100103	1	4	20260702103318265226	YBM	2026-07-02 10:33:38.395496
560	100101	1	2	1450	QM	2026-07-02 10:33:59.896203
561	100103	1	4	1478	QM	2026-07-02 10:35:02.289421
562	100101	2	7	1475	QM	2026-07-02 10:37:29.524991
563	100103	3	16	1462	QM	2026-07-02 10:39:29.337051
564	100101	2	1	1468	QM	2026-07-02 10:40:48.064632
565	100101	1	15	1467	QM	2026-07-02 10:41:00.74321
566	100101	2	7	1475	QM	2026-07-02 10:42:04.926609
567	100101	2	10	20260702104259276956	YBM	2026-07-02 10:43:18.505519
568	100103	1	4	1478	QM	2026-07-02 10:44:01.171712
569	100103	3	14	1454	QM	2026-07-02 10:44:35.917423
570	100101	2	11	20260702104611100936	YBM	2026-07-02 10:46:36.218006
571	100103	1	5	20260702104821797511	YBM	2026-07-02 10:48:43.871092
572	100103	1	6	20260702104834237506	YBM	2026-07-02 10:48:54.412302
573	100103	1	6	1482	QM	2026-07-02 10:50:14.448054
574	100101	2	1	1468	QM	2026-07-02 10:51:02.043821
575	100101	2	11	1480	QM	2026-07-02 10:55:15.064636
576	100103	1	2	1465	QM	2026-07-02 10:57:45.939588
577	100101	2	12	20260702105727455044	YBM	2026-07-02 10:57:52.257652
578	100101	2	12	20260702105727455044	YBM	2026-07-02 10:57:52.271073
579	100101	3	1	20260702105836273110	YBM	2026-07-02 10:58:58.625666
580	100101	3	1	1487	QM	2026-07-02 11:00:17.933646
581	100103	1	5	1481	QM	2026-07-02 11:00:28.556177
582	100101	2	6	1474	QM	2026-07-02 11:05:58.253235
583	100103	1	1	1464	QM	2026-07-02 11:06:24.352584
584	100101	2	4	1472	QM	2026-07-02 11:08:22.814215
585	100103	3	12	1452	QM	2026-07-02 11:09:22.594638
586	100101	2	5	1473	QM	2026-07-02 11:09:35.553886
587	100103	1	6	1482	QM	2026-07-02 11:14:48.248967
588	100101	2	9	1477	QM	2026-07-02 11:16:08.897729
589	100101	2	8	1476	QM	2026-07-02 11:17:30.372434
590	100101	2	4	1472	QM	2026-07-02 11:17:53.907484
591	100101	2	12	1483	QM	2026-07-02 11:18:25.902633
592	100101	4	14	1417	QM	2026-07-02 11:19:08.860585
593	100101	3	4	20260702112054638183	YBM	2026-07-02 11:21:12.845284
594	100101	2	11	1480	QM	2026-07-02 11:26:09.44896
595	100103	1	7	20260702112614101432	YBM	2026-07-02 11:26:35.615084
596	100101	4	6	1439	QM	2026-07-02 11:26:35.882517
597	100103	1	4	1478	QM	2026-07-02 11:27:56.91582
598	100101	3	6	20260702112842498012	YBM	2026-07-02 11:29:17.466346
599	100101	3	8	20260702113002858214	YBM	2026-07-02 11:30:53.639414
600	100101	3	6	1491	QM	2026-07-02 11:31:50.381657
601	100101	3	6	1491	QM	2026-07-02 11:32:10.059691
602	100101	3	6	1491	QM	2026-07-02 11:33:03.426708
603	100103	1	7	1490	QM	2026-07-02 11:33:16.057174
604	100101	2	10	1479	QM	2026-07-02 11:33:40.075287
605	100101	3	8	1493	QM	2026-07-02 11:34:55.174745
606	100101	2	11	1480	QM	2026-07-02 11:35:34.000607
607	100101	3	4	1489	QM	2026-07-02 11:40:09.87515
608	100101	4	16	1421	QM	2026-07-02 11:41:41.481893
609	100101	1	4	20260702114337770323	YBM	2026-07-02 11:43:56.075751
610	100101	1	4	20260702114337770323	YBM	2026-07-02 11:43:56.252544
611	100101	4	16	1421	QM	2026-07-02 11:44:20.283572
612	100101	2	4	1472	QM	2026-07-02 11:47:46.664799
613	100103	1	4	1478	QM	2026-07-02 11:49:13.496274
614	100101	1	11	1460	QM	2026-07-02 11:54:08.074483
615	100103	1	5	1481	QM	2026-07-02 11:56:49.181223
616	100101	4	2	1407	QM	2026-07-02 12:27:12.584738
617	100101	1	6	20260702124747088994	YBM	2026-07-02 12:48:11.30958
618	100101	3	6	1491	QM	2026-07-02 12:52:08.182706
619	100101	1	6	1495	QM	2026-07-02 12:56:40.69619
620	100101	3	6	1491	QM	2026-07-02 13:02:52.173976
621	100101	3	6	1491	QM	2026-07-02 13:04:19.778559
622	100101	1	6	1495	QM	2026-07-02 13:33:57.111801
623	100101	1	4	1494	QM	2026-07-02 13:35:41.504385
624	100101	3	11	20260702134039042484	YBM	2026-07-02 13:40:55.976475
625	100103	1	8	20260702134040354145	YBM	2026-07-02 13:41:00.339978
626	100101	3	13	20260702134104573220	YBM	2026-07-02 13:41:27.059771
627	100101	3	16	20260702134132115829	YBM	2026-07-02 13:42:05.401843
628	100101	4	2	20260702134148787231	YBM	2026-07-02 13:42:13.408701
629	100101	1	4	1494	QM	2026-07-02 13:43:10.216803
630	100101	4	4	20260702135424743179	YBM	2026-07-02 13:54:42.473481
631	100103	1	8	1497	QM	2026-07-02 13:58:22.532978
632	100101	4	4	1501	QM	2026-07-02 13:59:31.273073
633	100103	1	8	1497	QM	2026-07-02 13:59:58.614518
634	100101	3	11	1496	QM	2026-07-02 14:00:10.119507
635	100103	1	8	1497	QM	2026-07-02 14:01:25.081958
636	100101	4	7	20260702140217485233	YBM	2026-07-02 14:02:48.822558
637	100103	1	8	1497	QM	2026-07-02 14:03:04.531924
638	100101	4	7	1502	QM	2026-07-02 14:03:23.04057
639	100101	4	9	20260702140306046418	YBM	2026-07-02 14:03:27.459519
640	100101	4	4	1501	QM	2026-07-02 14:05:26.240787
641	100101	3	6	1491	QM	2026-07-02 14:07:15.649277
642	100101	4	7	1502	QM	2026-07-02 14:07:33.668676
643	100101	4	11	20260702140724250870	YBM	2026-07-02 14:07:42.989891
644	100101	3	3	20260702140730396695	YBM	2026-07-02 14:07:59.932528
645	100103	1	9	20260702140744122992	YBM	2026-07-02 14:08:06.769936
646	100101	3	10	20260702140754601295	YBM	2026-07-02 14:08:17.055288
647	100103	1	10	20260702140755030152	YBM	2026-07-02 14:08:17.130205
648	100101	3	10	20260702140754601295	YBM	2026-07-02 14:08:17.213894
649	100101	3	12	20260702140827587893	YBM	2026-07-02 14:08:47.459286
650	100103	1	8	1497	QM	2026-07-02 14:09:32.655426
651	100101	3	3	1506	QM	2026-07-02 14:11:50.214183
652	100101	3	15	20260702141512471432	YBM	2026-07-02 14:15:33.554379
653	100103	1	8	1497	QM	2026-07-02 14:18:19.553231
654	100103	1	8	1497	QM	2026-07-02 14:20:33.261813
655	100101	4	1	20260702142039515714	YBM	2026-07-02 14:20:58.579196
656	100101	4	7	1502	QM	2026-07-02 14:21:04.968363
657	100101	1	4	1494	QM	2026-07-02 14:22:47.743931
658	100101	3	4	1489	QM	2026-07-02 14:23:20.939579
659	100101	4	14	1417	QM	2026-07-02 14:23:37.005453
660	100101	4	16	1421	QM	2026-07-02 14:24:09.592517
661	100103	1	8	1497	QM	2026-07-02 14:25:02.916034
662	100101	3	11	1496	QM	2026-07-02 14:27:48.545445
663	100101	4	7	1502	QM	2026-07-02 14:32:35.442643
664	100101	4	4	1501	QM	2026-07-02 14:33:40.224337
665	100101	3	13	1498	QM	2026-07-02 14:35:11.696636
666	100103	1	10	1509	QM	2026-07-02 14:35:27.743986
667	100101	3	16	1499	QM	2026-07-02 14:36:05.501228
668	100101	4	14	20260702143544071556	YBM	2026-07-02 14:36:05.66278
669	100101	1	6	1495	QM	2026-07-02 14:36:18.340447
670	100101	4	2	1500	QM	2026-07-02 14:36:36.312814
671	100101	3	6	1491	QM	2026-07-02 14:36:53.184108
672	100101	3	3	1506	QM	2026-07-02 14:37:07.242391
673	100101	4	9	1503	QM	2026-07-02 14:37:48.032857
674	100101	4	16	20260702143734679789	YBM	2026-07-02 14:37:52.719816
675	100103	1	11	20260702143754225919	YBM	2026-07-02 14:38:10.821695
676	100101	4	14	1514	QM	2026-07-02 14:38:19.370561
677	100101	4	5	20260702143856371695	YBM	2026-07-02 14:39:15.676162
678	100101	4	6	20260702143900147067	YBM	2026-07-02 14:39:19.275542
679	100101	4	6	20260702143900147067	YBM	2026-07-02 14:39:19.489543
680	100101	3	10	1508	QM	2026-07-02 14:39:43.091109
681	100103	1	12	20260702143914147229	YBM	2026-07-02 14:40:00.262497
682	100103	1	10	1509	QM	2026-07-02 14:41:42.63558
683	100103	1	8	1497	QM	2026-07-02 14:42:00.187162
684	100101	3	15	1512	QM	2026-07-02 14:44:45.210611
685	100101	4	14	1514	QM	2026-07-02 14:45:24.530824
686	100101	4	8	20260702144526866350	YBM	2026-07-02 14:46:13.768799
687	100101	4	12	20260702144854973401	YBM	2026-07-02 14:49:13.932389
688	100101	4	12	1523	QM	2026-07-02 14:52:17.128091
689	100103	1	12	1520	QM	2026-07-02 14:52:49.211352
690	100101	4	7	1502	QM	2026-07-02 14:55:50.375001
691	100101	1	1	20260702145538688668	YBM	2026-07-02 14:56:23.017381
692	100103	1	11	1516	QM	2026-07-02 14:58:25.092005
693	100101	4	11	1504	QM	2026-07-02 15:01:31.84365
694	100101	4	6	1519	QM	2026-07-02 15:03:10.3025
695	100101	1	3	20260702150309568596	YBM	2026-07-02 15:03:25.659267
696	100101	1	5	20260702150323389885	YBM	2026-07-02 15:03:39.931242
697	100103	1	13	20260702150316102064	YBM	2026-07-02 15:03:50.667064
698	100103	1	14	20260702150337366312	YBM	2026-07-02 15:04:02.601676
699	100103	1	8	1497	QM	2026-07-02 15:04:15.021212
700	100101	4	11	1504	QM	2026-07-02 15:04:17.218207
701	100101	1	3	1527	QM	2026-07-02 15:04:33.156671
702	100103	1	16	20260702150800495797	YBM	2026-07-02 15:08:23.475031
703	100103	1	11	1516	QM	2026-07-02 15:10:37.693088
704	100101	1	7	20260702151350162558	YBM	2026-07-02 15:14:08.124382
705	100101	1	7	20260702151350162558	YBM	2026-07-02 15:14:08.228396
706	100101	1	7	1533	QM	2026-07-02 15:14:28.366393
707	100101	1	3	1527	QM	2026-07-02 15:14:50.41376
708	100103	2	2	20260702152133481623	YBM	2026-07-02 15:21:51.301111
709	100101	1	5	1529	QM	2026-07-02 15:26:47.1211
710	100101	1	11	20260702152903962518	YBM	2026-07-02 15:29:43.765719
711	100103	1	14	1530	QM	2026-07-02 15:29:51.423082
712	100101	3	12	1510	QM	2026-07-02 15:30:18.00869
713	100103	1	9	1507	QM	2026-07-02 15:30:55.396225
714	100101	4	16	1515	QM	2026-07-02 15:32:44.363197
715	100100	1	15	20260702153319838903	YBM	2026-07-02 15:33:48.38089
716	100100	1	15	20260702153319838903	YBM	2026-07-02 15:33:55.822085
717	100101	1	13	20260702153326808824	YBM	2026-07-02 15:33:56.585115
718	100101	1	13	20260702153326808824	YBM	2026-07-02 15:33:56.788755
719	100101	4	5	1518	QM	2026-07-02 15:34:14.826582
720	100100	1	15	1537	QM	2026-07-02 15:34:52.650638
721	100101	4	6	1519	QM	2026-07-02 15:35:58.561574
722	100101	4	11	1504	QM	2026-07-02 15:36:44.842438
723	100101	1	3	1527	QM	2026-07-02 15:37:26.932189
724	100101	1	1	1525	QM	2026-07-02 15:37:55.30582
725	100103	2	4	20260702153748669240	YBM	2026-07-02 15:38:03.5849
726	100103	2	5	20260702153854213248	YBM	2026-07-02 15:39:55.618745
727	100103	1	13	1528	QM	2026-07-02 15:40:47.270435
728	100103	1	11	1516	QM	2026-07-02 15:41:18.195173
729	100101	1	14	20260702154118599900	YBM	2026-07-02 15:41:31.288767
730	100101	1	14	20260702154118599900	YBM	2026-07-02 15:41:31.44308
731	100101	4	12	1523	QM	2026-07-02 15:41:44.427157
732	100101	4	14	1514	QM	2026-07-02 15:42:05.286095
733	100103	1	16	1532	QM	2026-07-02 15:44:52.289952
734	100101	3	3	1506	QM	2026-07-02 15:47:53.36235
735	100101	1	13	1539	QM	2026-07-02 15:51:52.11021
736	100103	2	6	20260702155329081576	YBM	2026-07-02 15:54:11.642814
737	100101	1	15	20260702155503957573	YBM	2026-07-02 15:55:28.141369
738	100101	4	8	1521	QM	2026-07-02 15:55:34.143717
739	100101	1	11	1536	QM	2026-07-02 15:57:17.41503
740	100101	1	3	1527	QM	2026-07-02 15:58:46.112488
741	100101	1	3	1527	QM	2026-07-02 15:59:35.952788
742	100101	4	1	1513	QM	2026-07-02 15:59:49.340769
743	100103	2	2	1534	QM	2026-07-02 16:01:03.74301
744	100101	4	4		YBM	2026-07-02 16:03:57.852426
745	100103	2	4	1540	QM	2026-07-02 16:06:53.296883
746	100101	1	14	1542	QM	2026-07-02 16:09:52.824409
747	100101	1	7	1533	QM	2026-07-02 16:10:59.992579
748	100103	2	6	1543	QM	2026-07-02 16:16:03.102186
749	100100	2	4	20260702161750709323	YBM	2026-07-02 16:18:07.184555
750	100101	1	15	1544	QM	2026-07-02 16:18:13.646596
751	100100	2	4	1547	QM	2026-07-02 16:18:37.616587
752	100103	2	5	1541	QM	2026-07-02 16:18:41.21651
753	100100	2	10	20260702215500274169	YBM	2026-07-02 21:55:20.106646
754	100100	2	10	20260702215500274169	YBM	2026-07-02 21:55:31.599538
755	100100	1	4	20260701152234730339	YBM	2026-07-02 22:01:37.906387
756	100100	2	4	20260702161750709323	YBM	2026-07-02 22:01:53.49222
757	100100	2	4	20260702161750709323	YBM	2026-07-02 22:01:58.321056
758	100100	1	15	20260702153319838903	YBM	2026-07-02 22:02:04.853382
759	100100	1	15	20260702153319838903	YBM	2026-07-02 22:02:13.949957
760	100100	2	4	20260702161750709323	YBM	2026-07-02 22:02:19.030769
761	100100	2	10	20260702215500274169	YBM	2026-07-02 22:02:24.613224
762	100100	3	1	20260702220528243130	YBM	2026-07-02 22:05:48.212651
763	100100	3	1	20260702220528243130	YBM	2026-07-02 22:05:48.575562
764	100100	3	1	20260702220528243130	YBM	2026-07-02 22:05:54.738939
765	100100	3	1	1551	QM	2026-07-02 22:06:05.63939
766	101010	1	1	1552	QM	2026-07-02 22:13:07.826582
767	101010	1	1	1553	QM	2026-07-02 22:13:43.715214
768	101010	1	1	1557	QM	2026-07-02 22:22:11.840467
769	100100	2	10	1549	QM	2026-07-02 22:29:07.303957
770	101010	1	1	1558	QM	2026-07-02 22:34:37.108808
771	101010	1	1	1559	QM	2026-07-02 22:34:59.722422
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.employees (id, merchant_id, name, phone, password_hash, role, status, created_at, auth_token, permissions, login_attempts, is_locked, plain_password) FROM stdin;
5	1	李百棚	17726689234	scrypt:32768:8:1$oCVMF2uLqBocgKAI$2ca8735301194c27872e457f7fd4a9829ff9984984dbfe0898eb6f7ae3cb15096bdf0d35a6f75dad7fb3a876fd8ae94c70b947a496b77c521f93dcddfb151fe1	admin	1	2026-07-01 11:30:27.861381	d40f1f0134f9caee736e6e026276afce	["dashboard","devices","orders","statistics","alerts","full_data"]	0	0	123456
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.locations (id, merchant_id, name, address, longitude, latitude, status, created_at, withdraw_enabled, auto_approve_day, auto_approve_time, auto_approve_rate, click_free_count, anti_test_minutes, anti_test_auto_refund, hide_ratio, whitelist_phones, duplicate_filter_enabled, duplicate_filter_days, duplicate_filter_limit, show_refunding_status, refund_approve_rate, refund_approve_start_min, refund_approve_end_min, contact_phone, open_time, close_time, allow_slot_select, slot_assign_mode, allow_mid_retrieve, retrieve_mode, allow_h5_to_mp, show_qr_follow, force_follow_mp, h5_url, show_slot_count, screen_show_title, screen_title, slot_full_alert, slot_full_text, end_alert_minutes, enable_clear_box, clear_box_time, clear_box_cycle, deposit_random, deposit_min, deposit_max, contact_name, refund_mode, withdraw_mode, province, agent_id, city, usage_rules, deposit_amount, mp_appid, balance_hide_enabled, balance_hide_days) FROM stdin;
4	1	测试网点_修改测试	新地址	\N	\N	1	2026-06-12 05:12:41	1	1	12:00	50	3	30	1	30	13900139000	0	7	3	1	50	10	20	\N	08:00	22:00	0	auto	1	both	1	0	0	\N	0	1	\N	0	\N	0	1	23:00	1	0	0	0	1895588779	auto_approve	manual_approve	\N	\N	\N	test rules for locker	20		1	30
6	4	淮海考场	河南商丘市	\N	\N	1	2026-06-25 09:24:57	1	1	12:00	80	3	30	1	0	\N	0	7	3	1	80	60	300	139000000000	08:00	22:00	0	auto	1	both	1	0	0	\N	0	1	\N	0	\N	0	0	23:00	1	0	0	0	李	auto_approve	manual_approve	\N	\N	\N	\N	20		0	30
8	5	誉荣科目三		\N	\N	1	2026-07-02 21:21:43.884414	1	3	02:00	0	3	5	1	25		0	7	3	1	80	60	300		08:00	22:00	0	auto	1	both	0	0	0		1	1		0		0	0	23:00	1	0	0	0		auto_approve	manual_approve		\N			20		0	30
7	1	亿航驾校		\N	\N	1	2026-06-29 17:43:30.813267	1	3	02:00	0	3	5	1	30		0	7	3	1	80	60	300	13549878542	08:00	22:00	0	auto	1	both	1	0	0		1	1		0		0	0	23:00	1	0	0	0	wang	auto_approve	manual_approve		\N			20		1	30
9	6	运鑫科目三		\N	\N	1	2026-07-02 21:34:07.913709	1	3	02:00	0	3	30	0	0		0	7	3	1	80	60	300		08:00	22:00	0	auto	1	both	0	0	0		1	1		0		0	0	23:00	1	0	0	0		auto_approve	manual_approve		\N			20		0	30
10	7	宁陵科目三		\N	\N	1	2026-07-02 21:42:43.646023	1	3	02:00	0	3	30	0	30		0	7	3	0	80	60	300		08:00	22:00	0	auto	1	both	1	0	0		1	1		0		0	1	23:00	1	0	0	0		auto_approve	manual_approve		\N			20		0	30
11	8	偃师考场		\N	\N	1	2026-07-02 22:02:52.267989	1	1	12:00	80	3	30	1	0		0	7	3	1	80	60	300		08:00	22:00	0	auto	1	both	0	0	0		1	1		0		0	0	23:00	1	0	0	0		auto_approve	manual_approve		\N			20		0	30
\.


--
-- Data for Name: mainboards; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.mainboards (id, cabinet_id, board_index, slot_count, name, created_at, serial_port, baud_rate, address, board_type, protocol) FROM stdin;
1	2	1	24	主板1	2026-06-13 09:06:31	ttyS1	9600	\N	main	YBM
2	2	2	20	主板2	2026-06-13 09:06:35	ttyS1	9600	\N	main	YBM
3	3	1	12	主板1	2026-06-13 12:39:42	ttyS1	9600	\N	main	YBM
4	5	1	24	主板1	2026-06-14 14:39:36	ttyS1	9600	\N	main	YBM
13	9	1	12	\N	2026-06-16 14:16:02	ttyS1	9600	\N	main	YBM
14	10	1	12	\N	2026-06-16 22:59:14	ttyS4	9600	\N	main	YBM
15	11	1	12	\N	2026-06-16 22:59:42	ttyS3	115200	\N	main	WT
17	13	1	12	\N	2026-06-17 13:59:08	ttyS4	9600	\N	main	YBM
18	14	1	12	\N	2026-06-17 15:08:06	ttyS4	9600	\N	main	YBM
6	8	1	24	主板1	2026-06-15 01:53:20	ttyS4	9600	01	main	WT
10	8	2	24	主板2	2026-06-16 06:38:59	ttyS4	9600	02	main	WT
11	8	3	4	主板3	2026-06-16 07:36:30	ttyS4	9600	03	main	WT
38	26	1	16	\N	2026-06-30 16:53:09.14436	ttyS4	9600		main	YBM
37	24	1	16	\N	2026-06-30 06:45:40.017764	ttyS4	9600		main	YBM
39	28	1	16	\N	2026-07-02 21:03:11.011864	ttyS4	9600		main	YBM
40	38	1	16	\N	2026-07-02 21:45:50.444829	ttyS4	9600		main	YBM
36	15	1	16	\N	2026-06-28 07:19:10.849061	ttyS3	115200		main	YBM
33	16	1	24	\N	2026-06-26 02:05:06	ttyS4	9600	\N	main	YBM
34	16	2	24	\N	2026-06-26 02:05:06	ttyS4	9600	\N	main	YBM
35	16	3	24	\N	2026-06-26 02:05:06	ttyS4	9600	\N	main	YBM
\.


--
-- Data for Name: merchants; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.merchants (id, name, contact_name, contact_phone, password_hash, status, created_at, agent_id, auth_token, permissions, login_attempts, is_locked, plain_password, commission_per_order, text_labels, merchant_number, dashboard_config, last_login_at) FROM stdin;
5	誉荣考场	李	17726689234	scrypt:32768:8:1$ZRneBET4QOwm94TU$59e4b135065fa8d1ae3f7e82d35916ae11a95de6252cdd65027c6931b882bcd0fdb01ad2b0de5011ad45294a81d54f81da4b49e507eae6b665bdc6d011362d9a	1	2026-07-02 21:19:36.730711	1	\N	["dashboard","locations","devices","orders","statistics"]	0	0	Mch@gT	0.00	{}	誉荣考场	{"show_network_section":true,"show_today_section":true,"show_yesterday_section":true,"show_last_month_section":true}	\N
4	淮海驾校	李	13900000000	scrypt:32768:8:1$2WaV8luT0i8JqjOZ$ba81b3fc7638277ddcc7a1fe018bef12499cddb233a1d0ddbfa573ccf0f203be062dc6adf6167a07234d3e2b77ae67e4e0ce9c627145185ca3e2aecdda9df843	1	2026-06-25 09:23:45	1	224972a9a93de6bab94518b12bf93f8e	[]	0	0	Mch@LKAjmw	7.00	{}	淮海驾校	{"show_network_section":true,"show_today_section":true,"show_yesterday_section":true,"show_last_month_section":true,"show_refund_fields":true,"show_recharge_fields":true,"show_withdraw_fields":true}	\N
2	自动密码商家	自动密码商家	13900004444	scrypt:32768:8:1$Ipmd6SYsIzmWko38$47667ddf01b50d3b5bc19d39671d77a53aa48dc171646c470aa183e52f18cafedfd9e51fb73890a6d33a7892c7051b1be6332de954b146350b67030b39df3ded	1	2026-06-23 08:51:37	1	\N	[]	0	0	Mch@nCgpsy	0.00	{}	自动密码商家	{"show_network_section":true,"show_today_section":true,"show_yesterday_section":true,"show_last_month_section":true,"show_refund_fields":true,"show_recharge_fields":true,"show_withdraw_fields":true}	\N
6	运鑫考场	李	17726689233	scrypt:32768:8:1$tYFBdL2mH7awWhIy$e5a4603465541f0dc8e3c13bd9f27a5a4c7a27164e87a60f7763b71c745af1468d9033a036bac39f41bbe87d676b242cc6803d66503caf54d9c81d6742fa2fb6	1	2026-07-02 21:32:41.974372	1	\N	["orders","dashboard","locations","statistics"]	0	0	Mch@Pe	0.00	{}	运鑫考场	\N	\N
7	宁陵科目三	李	17726689231	scrypt:32768:8:1$ibu0WqoCWWvChDix$09a14bb27c6eea07e42c6dcd62ae2e67e071e1770e87fd632615f8b7a9a0bf6e223f4562ecdf0a1b42bcc57fa1d598d58dce94f9bb8acb1496d3ae90ddedd7ae	1	2026-07-02 21:41:28.372278	1	\N	["dashboard","locations","devices","orders","statistics"]	0	0	Mch@42	0.00	{}	宁陵科目三	\N	\N
8	偃师考场	李	17726689235	scrypt:32768:8:1$sxc7094R9uGiZ4Y1$86f4260426e5533ea86a91e507a9bcccdc7d5a47c5ec9f2d43057759882acae89096beb2d4e0aaed6e0407468295cc847ceb357fd43b5b8ebe2fa46e65ecf255	1	2026-07-02 22:01:25.537372	1	\N	["dashboard","locations","devices","orders","statistics"]	0	0	Mch@WB	0.00	{}	偃师考场	\N	\N
1	王	\N	13667618419	scrypt:32768:8:1$9odYkfXTPkKx5fWE$ca500c08ac33c0523a68b1b105ea958c1b3084959fd061adae0e4f4cee8dba31da36c1de32b162c3a42557142078d6bea0ac3a0292c235ea9363393141f04fe7	1	2026-06-11 05:56:47	1	9fce0f7631460bc040445a5f0f3bf6d1	["dashboard","locations","devices","orders","statistics","withdrawal","alerts","merchant_manage","full_data"]	0	0	Mch@jjb2ay	0.00	{}	王	{"show_network_section":true,"show_today_section":true,"show_yesterday_section":true,"show_last_month_section":true,"show_refund_fields":true,"show_recharge_fields":true,"show_withdraw_fields":true}	2026-07-02 12:22:08.351824
\.


--
-- Data for Name: offline_retrieve_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.offline_retrieve_records (id, order_no, retrieve_code, cabinet_id, slot_id, slot_number, retrieved_at, synced, uploaded) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.orders (id, order_no, user_phone, slot_id, cabinet_id, compartment_number, access_code, deposit_amount, status, store_time, retrieve_time, created_at, group_id, cabinet_code, cabinet_name, slot_size, transaction_id, refund_id, pay_time, refund_time, payment_channel_id, refund_mark, refund_status, refund_amount, logical_mark, logic_mark, logic_hide, note, admin_remark, pickup_time, updated_at, openid, unionid) FROM stdin;
3	20260612123727077142	13811112222	1	1	1	6666	20	4	2026-06-12 12:37:27.81512	\N	2026-06-12 04:37:27	\N	\N	\N	\N	MOCK20260612123731687721	\N	2026-06-12 12:37:31.594703	2026-07-01 14:35:28.816357	\N	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
4	20260612124106814078	13833334444	2	1	2	8888	20	4	2026-06-12 12:41:06.648616	\N	2026-06-12 04:41:06	\N	\N	\N	\N	MOCK20260612124112354956	\N	2026-06-12 12:41:12.466456	2026-07-01 14:35:28.816357	\N	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
6	20260612125720101658	13855556666	3	1	3	5555	20	4	2026-06-12 12:57:20.93579	\N	2026-06-12 04:57:20	\N	\N	\N	\N	MOCK20260612125721052779	\N	2026-06-12 12:57:21.097809	2026-07-01 14:35:28.816357	\N	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
572	20260701090447589462	18705206991	614	24	E24	3569	20	4	2026-07-01 09:04:47.083127	2026-07-01 15:17:10.66717	2026-07-01 09:04:47.078852	\N	\N	\N	\N	4200003177202607014903359735	\N	2026-07-01 09:05:25.900867	2026-07-01 17:16:52.774136	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA819Zjec3Z04Pb-rAgMOQ-nsE	
600	20260701141803673210	18336926660	594	24	E4	1765	20	5	2026-07-01 14:18:03.424363	\N	2026-07-01 14:18:03.420375	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA818XVpD8LoLHNMkgx7tfHTCE	
559	20260630214806741718	17726689234	504	16	B10	1234	20	5	2026-06-30 21:48:06.593936	\N	2026-06-30 21:48:06.58799	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	
560	20260630214824020439	17726689234	505	16	B11	1234	20	5	2026-06-30 21:48:24.538727	\N	2026-06-30 21:48:24.535435	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	
594	20260701120453107102	18137063193	623	24	E33	0370	20	5	2026-07-01 12:04:53.928753	\N	2026-07-01 12:04:53.924042	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81--Z4Op2Q70yCPLojW8e2Ns	
1406	20260702074555585426	15837068521	638	24	E48	1212	20	5	2026-07-02 07:45:55.455054	\N	2026-07-02 07:45:55.450927	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA817JN3Bz9532eCCUzjuU7x-0	
310	20260626092711160596	18896963355	\N	8	A45	1234	20	4	2026-06-26 09:27:11.556338	\N	2026-06-26 01:27:11	\N	\N	\N	\N	4200003125202606267155536409	50300907442026070135362635753	2026-06-26 09:27:18.112181	2026-07-01 14:35:29.78967	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
311	20260626093121031571	18896963355	447	8	1	1472	20	4	2026-06-26 09:31:21.065921	\N	2026-06-26 01:31:21	\N	\N	\N	\N	4200003129202606262955618549	50302907662026070151546143508	2026-06-26 09:34:58.933456	2026-07-01 14:35:30.597257	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
299	20260625235027193965	17725196748	\N	8	A37	2588	20	3	2026-06-25 23:50:27.826689	2026-06-26 09:25:55	2026-06-25 15:50:27	\N	\N	\N	\N	\N	\N	2026-06-25 23:50:39.600723	\N	1	1	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N	\N
35	20260613112009044932	13667618419	11	1	11	1234	20	4	2026-06-13 11:20:09.3219	2026-06-13 16:54:54.138127	2026-06-13 03:20:09	\N	\N	\N	\N	MOCK20260613112010821772	\N	2026-06-13 11:20:10.929253	2026-07-01 14:35:28.816357	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
601	20260701141804957030	18336926660	596	24	E6	1765	20	3	2026-07-01 14:18:04.34834	2026-07-01 15:18:09.61695	2026-07-01 14:18:04.344998	\N	\N	\N	\N	4200003120202607016553069160	\N	2026-07-01 14:18:28.543221	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA818XVpD8LoLHNMkgx7tfHTCE	
1408	20260702074604458078	16650694701	717	27	D15	0811	20	5	2026-07-02 07:46:04.67604	\N	2026-07-02 07:46:04.672374	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oLhbm2FsOXehsq0hbDNTlmOLSS5E	
1409	20260702074606647924	16650694701	718	27	D16	0811	20	5	2026-07-02 07:46:06.360985	\N	2026-07-02 07:46:06.357659	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oLhbm2FsOXehsq0hbDNTlmOLSS5E	
1466	20260702100348209458	15343725078	604	24	E14	6666	20	5	2026-07-02 10:03:48.37371	\N	2026-07-02 10:03:48.370028	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81_QYIhpTnIP_MguSINPWeMQ	
1467	20260702100349927451	15343725078	605	24	E15	6666	20	3	2026-07-02 10:03:49.367914	2026-07-02 10:41:00.734204	2026-07-02 10:03:49.364559	\N	\N	\N	\N	4200003190202607028099219979	\N	2026-07-02 10:04:12.717652	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81_QYIhpTnIP_MguSINPWeMQ	
1411	20260702074732988247	13460149121	645	24	E55	9121	20	5	2026-07-02 07:47:32.388649	\N	2026-07-02 07:47:32.384501	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA816HTb34u_l7onE9K378FUeY	
1465	20260702100050634764	19850171704	704	27	D2	1228	20	3	2026-07-02 10:00:50.905612	2026-07-02 10:57:45.932407	2026-07-02 10:00:50.887906	\N	\N	\N	\N	4200003145202607025153502260	\N	2026-07-02 10:01:40.284632	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81wJNprd-lhv0B7zEZGRpR8Q	
602	20260701145426450983	18439030153	633	24	E43	0153	20	5	2026-07-01 14:54:26.529602	\N	2026-07-01 14:54:26.525085	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA817SgAsGAcHjpLZsg9x3poLk	
561	20260630225621876847	13667618419	604	24	E14	1223	20	5	2026-06-30 22:56:21.267751	\N	2026-06-30 22:56:21.26316	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	
1551	20260702220528243130	18888889999	799	16	B33	1234	20	4	2026-07-02 22:05:28.545651	2026-07-02 22:06:05.625793	2026-07-02 22:05:28.540102	\N	\N	\N	\N	4200003180202607028648226753	\N	2026-07-02 22:05:48.569218	2026-07-02 23:25:03.693925	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	
1414	20260702074836334811	15993979586	649	24	E59	1234	20	3	2026-07-02 07:48:36.845097	2026-07-02 08:03:32.238153	2026-07-02 07:48:36.841502	\N	\N	\N	\N	4200003116202607024798095091	\N	2026-07-02 07:49:13.24706	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA814HKJCkcV1qPzdiW-kGgh0Q	
1413	20260702074750034164	15824752199	720	27	D18	0412	20	3	2026-07-02 07:47:50.623948	2026-07-02 09:12:36.374992	2026-07-02 07:47:50.620753	\N	\N	\N	\N	4200003167202607023557167923	\N	2026-07-02 07:48:20.822231	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA811Ywqe14WBCysW4hxNgAAxU	
1412	20260702074733928541	13460149121	647	24	E57	9121	20	3	2026-07-02 07:47:33.427716	2026-07-02 09:29:04.606787	2026-07-02 07:47:33.424238	\N	\N	\N	\N	4200003164202607020264045936	\N	2026-07-02 07:47:55.86036	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816HTb34u_l7onE9K378FUeY	
1410	20260702074612869156	15103773844	642	24	E52	3521	20	3	2026-07-02 07:46:12.77395	2026-07-02 10:00:04.624579	2026-07-02 07:46:12.770233	\N	\N	\N	\N	4200003207202607021980567195	\N	2026-07-02 07:46:45.8478	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816r2XDtvPrsYSYu7CYL3Jh4	
29	20260613105400223433	13667618419	5	1	5	1234	20	4	2026-06-13 10:54:00.714045	2026-06-20 07:28:37.901891	2026-06-13 02:54:00	\N	\N	\N	\N	MOCK20260613105402524401	\N	2026-06-13 10:54:02.304042	2026-06-30 18:20:19.706673	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
28	20260613103956052882	18996093393	5	1	5	1234	20	3	2026-06-13 10:39:56.434611	2026-06-13 10:40:52.646938	2026-06-13 02:39:56	\N	\N	\N	\N	MOCK20260613103958690879	\N	2026-06-13 10:39:58.025961	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
25	20260613103518582221	13667618419	2	1	2	1234	20	4	2026-06-13 10:35:18.188338	2026-06-18 16:24:07.583328	2026-06-13 02:35:18	\N	\N	\N	\N	MOCK20260613103519579330	\N	2026-06-13 10:35:19.76699	2026-06-30 18:20:26.014794	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
1529	20260702150323389885	19639308701	595	24	E5	8701	20	4	2026-07-02 15:03:23.505689	2026-07-02 15:26:47.112451	2026-07-02 15:03:23.50244	\N	\N	\N	\N	4200003215202607023206734800	\N	2026-07-02 15:03:39.926032	2026-07-02 15:31:25.207137	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-zeWU3yEM4u6Kbk8NxGWc4	
1486	20260702105835552913	15937086006	622	24	E32	1112	20	5	2026-07-02 10:58:35.635669	\N	2026-07-02 10:58:35.630991	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA8121MDcJ_BFR0HwO-FrCDkoU	
1487	20260702105836273110	15937086006	623	24	E33	1112	20	4	2026-07-02 10:58:36.604167	\N	2026-07-02 10:58:36.600691	\N	\N	\N	\N	4200003212202607023456875779	\N	2026-07-02 10:58:58.619769	2026-07-02 12:07:50.580286	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA8121MDcJ_BFR0HwO-FrCDkoU	
1407	20260702074556912851	15837068521	640	24	E50	1212	20	3	2026-07-02 07:45:56.642459	2026-07-02 12:27:12.576395	2026-07-02 07:45:56.639319	\N	\N	\N	\N	4200003205202607024094312739	\N	2026-07-02 07:46:38.006595	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA817JN3Bz9532eCCUzjuU7x-0	
574	20260701092146323147	18996093393	704	27	2	1111	20	5	2026-07-01 09:21:46.099679	\N	2026-07-01 09:21:46.095623	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	
5	20260612125238878728	13844445555	3	1	3	1234	20	4	2026-06-12 12:52:38.906724	2026-06-12 12:52:39.19345	2026-06-12 04:52:38	\N	\N	\N	\N	MOCK20260612125239933782	MOCK_R20260612125239053174	2026-06-12 12:52:39.075634	2026-06-12 12:52:39.19345	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
8	20260612125806054979	13800001111	4	1	4	1111	20	4	2026-06-12 12:58:06.520154	2026-06-12 12:58:06.798029	2026-06-12 04:58:06	\N	\N	\N	\N	MOCK20260612125806736595	MOCK_R20260612125806149070	2026-06-12 12:58:06.678324	2026-06-12 12:58:06.798029	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
9	20260612130727372053	13877778888	4	1	4	9999	20	4	2026-06-12 13:07:27.142639	2026-06-12 13:07:27.422495	2026-06-12 05:07:27	\N	\N	\N	\N	MOCK20260612130727077299	MOCK_R20260612130727819069	2026-06-12 13:07:27.300624	2026-06-12 13:07:27.422495	\N	0	none	0	N	\N	\N	\N	\N	\N	\N	\N	\N
1528	20260702150316102064	13619875632	715	27	D13	2587	20	3	2026-07-02 15:03:16.101504	2026-07-02 15:40:47.261067	2026-07-02 15:03:16.098151	\N	\N	\N	\N	4200003136202607028549904705	\N	2026-07-02 15:03:50.662291	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA812bIt3wABkRP5W74pZqnzAM	
1526	20260702150258701819	19639308701	592	24	E2	8701	20	5	2026-07-02 15:02:58.068944	\N	2026-07-02 15:02:58.06478	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81-zeWU3yEM4u6Kbk8NxGWc4	
1549	20260702215500274169	13667618419	520	16	B26	1475	20	4	2026-07-02 21:55:00.451597	2026-07-02 22:29:07.29601	2026-07-02 21:55:00.447884	\N	\N	\N	\N	4200003150202607023016233942	\N	2026-07-02 21:55:20.099786	2026-07-02 23:25:00.365935	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	
1562	20260702232957358478	18888889999	456	8	10	7513	20	5	2026-07-02 23:29:57.08138	\N	2026-07-02 23:29:57.078005	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N		
1563	20260702233048836567	18888889999	457	8	11	0851	20	5	2026-07-02 23:30:48.175729	\N	2026-07-02 23:30:48.17166	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYigtDeifFYs	
470	20260630094022158852	17726689234	506	16	12	4265	20	4	2026-06-30 09:40:22.786174	2026-06-30 09:40:22.764245	2026-06-30 09:40:22.764245	\N	\N	\N	\N	4200003173202606305670319510	\N	2026-06-30 09:49:43.241028	2026-07-01 14:35:33.894579	3	1	refunded	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
576	20260701115657653883	15964686705	616	24	E26	0000	20	5	2026-07-01 11:56:57.864712	\N	2026-07-01 11:56:57.859563	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		
577	20260701115706693871	15964686705	617	24	E27	0000	20	5	2026-07-01 11:57:06.802422	\N	2026-07-01 11:57:06.798905	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N		
590	20260701115835256322	19025302365	713	27	11	0714	20	4	2026-07-01 11:58:35.082833	2026-07-01 12:39:03.622035	2026-07-01 11:58:35.079433	\N	\N	\N	\N	4200003196202607016811623968	\N	2026-07-01 11:59:04.201306	2026-07-01 17:33:55.992475	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81ycBLSSc4MBzuD4oFZuMBfo	
1530	20260702150337366312	18738086168	716	27	D14	8888	20	3	2026-07-02 15:03:37.130524	2026-07-02 15:29:51.416061	2026-07-02 15:03:37.126915	\N	\N	\N	\N	4200003109202607027208938309	\N	2026-07-02 15:04:02.595373	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816eRP5_FiWPMOi70wsPN4vY	
1527	20260702150309568596	15919267157	593	24	E3	0814	20	3	2026-07-02 15:03:09.974142	2026-07-02 15:59:35.945604	2026-07-02 15:03:09.970552	\N	\N	\N	\N	4200003194202607020830242967	\N	2026-07-02 15:03:25.653045	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA815JUJ37T0UZRAH3stjwiNZM	
564	20260701075928784045	17726689234	508	16	B14	1234	20	3	2026-07-01 07:59:28.845326	2026-07-01 08:00:10.286068	2026-07-01 07:59:28.840616	\N	\N	\N	\N	4200003176202607019207023760	\N	2026-07-01 07:59:46.860993	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	
469	20260630093905337250	18996093393	605	24	E15	1234	20	4	2026-06-30 09:39:05.780707	2026-06-30 09:39:05.759763	2026-06-30 09:39:05.759763	\N	\N	\N	\N	4200003213202606301295336829	\N	2026-06-30 09:39:23.520017	2026-07-01 10:18:16.009243	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
1497	20260702134040354145	15265092163	710	27	D8	2580	20	4	2026-07-02 13:40:40.557665	2026-07-02 15:04:15.009602	2026-07-02 13:40:40.554271	\N	\N	\N	\N	4200003221202607027850051403	\N	2026-07-02 13:41:00.334541	2026-07-02 19:27:08.910742	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2GiCaKhEaaqfMQbOunafSCo	
603	20260701145427482126	18439030153	635	24	E45	0153	20	3	2026-07-01 14:54:27.678032	2026-07-01 14:56:27.658175	2026-07-01 14:54:27.6747	\N	\N	\N	\N	4200003152202607011502175243	\N	2026-07-01 14:54:48.678031	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA817SgAsGAcHjpLZsg9x3poLk	
573	20260701092145692115	18996093393	703	27	1	1111	20	5	2026-07-01 09:21:45.038714	\N	2026-07-01 09:21:45.035447	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	
385	20260627180155088478	18996093393	464	15	2	1111	1	4	2026-06-27 18:01:55.789566	2026-06-28 08:30:57.233902	2026-06-27 18:01:55.784048	\N	\N	\N	\N	4200003215202606279493063491	\N	2026-06-27 18:02:24.752173	2026-07-01 10:18:37.478003	\N	1	refunded	1	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
1415	20260702075044906912	15839055361	721	27	D19	5566	20	2	2026-07-02 07:50:44.107814	\N	2026-07-02 07:50:44.102946	\N	\N	\N	\N	4200003128202607028245438250	\N	2026-07-02 07:51:08.908144	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	oLhbm2AXKx2eoxKIRnh8tdL9iZOs	
595	20260701120522609091	18137063193	624	24	E34	0370	20	5	2026-07-01 12:05:22.203351	\N	2026-07-01 12:05:22.198442	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81--Z4Op2Q70yCPLojW8e2Ns	
1531	20260702150759387560	17838825515	717	27	D15	2013	20	5	2026-07-02 15:07:59.463943	\N	2026-07-02 15:07:59.442226	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81-HaXjCIpJLaElFsOc2c2gY	
457	20260630091101819765	18996093393	599	24	E9	1234	20	4	2026-06-30 09:11:01.276431	2026-06-30 09:11:01.254235	2026-06-30 09:11:01.254235	\N	\N	\N	\N	4200003186202606300691410477	\N	2026-06-30 09:11:19.737264	2026-07-01 10:18:19.605697	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
1446	20260702084753583818	15239932935	741	27	D39	3993	20	4	2026-07-02 08:47:53.726405	2026-07-02 10:23:44.639354	2026-07-02 08:47:53.722483	\N	\N	\N	\N	4200003209202607020002423439	\N	2026-07-02 08:48:12.838298	2026-07-03 01:11:45.929597	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA816T8KS6QqBABmZa2xuqWmTY	
501	20260630123806951872	18265820019	620	24	E30	0099	20	3	2026-06-30 12:38:06.906077	2026-06-30 15:09:03.911412	2026-06-30 12:38:06.884662	\N	\N	\N	\N	4200003115202606303234817522	50300207922026063016371921591	2026-06-30 12:38:27.2341	2026-06-30 21:24:15.600965	3	1	success	20	N	\N	\N	\N	\N	\N	\N		\N
509	20260630123959529209	15806753783	629	24	E39	0420	20	4	2026-06-30 12:39:59.297656	2026-06-30 14:46:23	2026-06-30 12:39:59.276555	\N	\N	\N	\N	4200003189202606303949941723	\N	2026-06-30 12:40:50.158171	2026-06-30 14:46:27.352347	1	1	refunded	20	N	\N	\N	\N	\N	2026-06-30 14:46:23	2026-06-30 14:46:23		\N
306	20260626070704844022	17726689234	\N	8	A42	1234	20	4	2026-06-26 07:07:04.286167	2026-06-26 09:25:55	2026-06-25 23:07:04	\N	\N	\N	\N	4200003222202606267015269936	\N	2026-06-26 07:10:42.381455	\N	1	0	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
511	20260630124010539133	13207075405	631	24	E41	1314	20	2	2026-06-30 12:40:10.410691	\N	2026-06-30 12:40:10.389848	\N	\N	\N	\N	4200003197202606302682250482	\N	2026-06-30 12:40:30.91608	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
526	20260630133404595989	15138943614	646	24	E56	5219	20	3	2026-06-30 13:34:04.912326	2026-06-30 16:04:17.890288	2026-06-30 13:34:04.892193	\N	\N	\N	\N	4200003147202606302705451991	\N	2026-06-30 13:34:33.280437	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
1548	20260702215459020279	13667618419	518	16	B24	1475	20	5	2026-07-02 21:54:59.331034	\N	2026-07-02 21:54:59.327581	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	
300	20260625235218620187	17725196748	\N	8	A38	1475	20	3	2026-06-25 23:52:18.95125	2026-06-26 09:25:55	2026-06-25 15:52:18	\N	\N	\N	\N	\N	\N	2026-06-25 23:52:25.211139	\N	1	1	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N	\N
301	20260626062352442950	17725196748	\N	8	A39	1234	20	3	2026-06-26 06:23:52.388604	2026-06-26 09:25:55	2026-06-25 22:23:52	\N	\N	\N	\N	4200003126202606266486005168	\N	2026-06-26 06:26:00.886014	\N	1	1	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N	\N
302	20260626065241645773	17725196748	\N	8	A40	1234	20	3	2026-06-26 06:52:41.110615	2026-06-26 09:25:55	2026-06-25 22:52:41	\N	\N	\N	\N	4200003206202606266399413240	\N	2026-06-26 06:56:19.145714	\N	1	1	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	\N	\N
537	20260630141613856704	15254409526	591	24	E1	9526	20	4	2026-06-30 14:16:13.618081	2026-06-30 17:09:24	2026-06-30 14:16:13.598124	\N	\N	\N	\N	4200003211202606304706104835	\N	2026-06-30 14:16:30.087308	2026-06-30 17:09:32.775869	1	1	refunded	20	N	\N	\N	\N	\N	2026-06-30 17:09:24	2026-06-30 17:09:24		\N
543	20260630145256257792	19254304011	597	24	E7	4011	20	2	2026-06-30 14:52:56.59766	\N	2026-06-30 14:52:56.578078	\N	\N	\N	\N	4200003178202606304648003361	\N	2026-06-30 14:53:12.791167	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N		\N
568	20260701084052108306	17838863123	610	24	E20	5858	20	5	2026-07-01 08:40:52.026617	\N	2026-07-01 08:40:52.0215	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA814e5qmXK53w6jTxGFCQvrMo	
546	20260630152726665334	15324821187	601	24	E11	1013	20	3	2026-06-30 15:27:26.746166	2026-06-30 16:10:06.63983	2026-06-30 15:27:26.724031	\N	\N	\N	\N	4200003183202606304945740720	\N	2026-06-30 15:27:44.656396	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
1468	20260702101247406216	15238586310	607	24	E17	4567	20	3	2026-07-02 10:12:47.022226	2026-07-02 10:51:02.036052	2026-07-02 10:12:47.017531	\N	\N	\N	\N	4200003185202607021007608092	\N	2026-07-02 10:13:20.315893	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816bz5qUV3jcjZcEuRMHFH44	
1488	20260702112011386859	17753648530	624	24	E34	0629	20	5	2026-07-02 11:20:11.730521	\N	2026-07-02 11:20:11.710433	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA815j2zKUz_ITVwi98Zz3XETg	
1416	20260702075630097930	19836582073	722	27	D20	2006	20	4	2026-07-02 07:56:30.030627	2026-07-02 09:19:37.266298	2026-07-02 07:56:30.027083	\N	\N	\N	\N	4200003185202607023665818129	\N	2026-07-02 07:56:46.054589	2026-07-02 12:36:56.142398	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA812v0tMAGKvDt_KYlQO1m2Y8	
405	20260628145155650131	18888889999	519	16	25	1234	20	4	2026-06-28 14:51:55.54862	2026-06-28 14:51:55.544538	2026-06-28 14:51:55.544538	\N	\N	\N	\N	4200003187202606285994990390	\N	2026-06-28 14:52:23.293635	2026-06-30 12:29:58.796656	\N	0	none	20	N	N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
539	20260630141812626447	19544562686	593	24	E3	1234	20	4	2026-06-30 14:18:12.222058	2026-06-30 16:10:29.361524	2026-06-30 14:18:12.201694	\N	\N	\N	\N	4200003115202606301960636307	\N	2026-06-30 14:18:37.078692	2026-07-01 10:16:22.524745	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA814ZbDx9Sa3EUrwREReSYPhY	\N
549	20260630155114892074	15656087879	603	24	E13	0808	20	3	2026-06-30 15:51:14.350607	2026-06-30 18:23:09.845366	2026-06-30 15:51:14.330299	\N	\N	\N	\N	4200003165202606304574377209	\N	2026-06-30 15:51:36.239475	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N		\N
15	20260612220646836729	13667619418	5	1	5	1234	20	4	2026-06-12 22:06:46.722765	\N	2026-06-12 14:06:46	\N	\N	\N	\N	MOCK20260612220648303668	\N	2026-06-12 22:06:48.35446	2026-07-01 14:35:28.816357	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
16	20260612221713749602	13667619418	6	1	6	1234	20	4	2026-06-12 22:17:13.723193	\N	2026-06-12 14:17:13	\N	\N	\N	\N	MOCK20260612221715620901	\N	2026-06-12 22:17:15.374401	2026-07-01 14:35:28.816357	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
18	20260613071529364557	13667619418	7	1	7	1234	20	4	2026-06-13 07:15:29.564058	\N	2026-06-12 23:15:29	\N	\N	\N	\N	MOCK20260613071531279605	\N	2026-06-13 07:15:31.12188	2026-07-01 14:35:28.816357	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
32	20260613110923352760	13667618491	8	1	8	1234	20	4	2026-06-13 11:09:23.383141	2026-06-20 07:45:34	2026-06-13 03:09:23	\N	\N	\N	\N	MOCK20260613110924025926	\N	2026-06-13 11:09:24.983525	2026-07-01 14:35:28.816357	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	\N	\N
14	20260612220410413004	13667618419	4	1	4	1234	20	4	2026-06-12 22:04:10.832917	\N	2026-06-12 14:04:10	\N	\N	\N	\N	MOCK20260612220412535185	\N	2026-06-12 22:04:12.482515	2026-07-01 14:35:28.816357	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
326	20260626151140780127	18888889999	\N	16	19	1234	20	4	2026-06-26 15:11:40.037844	\N	2026-06-26 07:11:40	\N	\N	\N	\N	4200003196202606264025106289	50300907402026070106529338200	2026-06-26 15:15:59.100626	2026-07-01 14:35:31.417912	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
328	20260626152942192997	18888889999	\N	16	20	1234	20	4	2026-06-26 15:29:42.720861	\N	2026-06-26 07:29:42	\N	\N	\N	\N	4200003223202606261012234681	50300107482026070165222946626	2026-06-26 17:34:14.73608	2026-07-01 14:35:32.208032	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
330	20260626154702233246	18888889999	\N	16	21	1234	20	4	2026-06-26 15:47:02.451091	\N	2026-06-26 07:47:02	\N	\N	\N	\N	4200003208202606261431066067	50302707502026070163552328291	2026-06-26 15:47:09.175571	2026-07-01 14:35:33.015725	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
381	20260627160609859877	18888889999	501	16	7	1234	20	4	2026-06-27 16:06:09.568076	\N	2026-06-27 16:06:09.564124	\N	\N	\N	\N	4200003194202606274482878253	50301307852026070112810853566	2026-06-27 16:06:33.756775	2026-07-01 14:37:25.156408	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
393	20260628083429993292	18983079797	467	15	5	1111	1	4	2026-06-28 08:34:29.816315	\N	2026-06-28 08:34:29.81235	\N	\N	\N	\N	4200003127202606285009377611	50301107692026070140774071608	2026-06-28 08:35:13.935168	2026-07-01 14:37:26.226775	1	1	refunded	1	N	\N	\N	\N	\N	\N	\N	oWrA81-sAdleVupXM1QWH2jwpywk	\N
380	20260627160102439699	18888889999	500	16	6	1234	20	4	2026-06-27 16:01:02.420536	\N	2026-06-27 16:01:02.416518	\N	\N	\N	\N	4200003186202606272613703359	50303907992026070102115059185	2026-06-27 16:01:17.946145	2026-07-01 14:37:27.305763	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
384	20260627163808998198	18888889999	504	16	10	1234	20	4	2026-06-27 16:38:08.255333	\N	2026-06-27 16:38:08.251689	\N	\N	\N	\N	4200003137202606271203499467	50302707942026070127881195457	2026-06-27 16:38:26.498928	2026-07-01 14:37:28.367007	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
382	20260627161116110216	18888889999	502	16	8	1234	20	4	2026-06-27 16:11:16.267593	\N	2026-06-27 16:11:16.264003	\N	\N	\N	\N	4200003222202606276645933201	50300107762026070155617905032	2026-06-27 16:11:33.379517	2026-07-01 14:37:29.374895	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
408	20260628152957019526	17722332233	522	16	28	2584	20	4	2026-06-28 15:29:57.720409	2026-06-28 15:29:57.716683	2026-06-28 15:29:57.716683	\N	\N	\N	\N	4200003133202606283862175972	\N	2026-06-28 15:30:18.625375	2026-06-30 12:29:58.796656	\N	0	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
1489	20260702112054638183	13557288765	626	24	E36	1314	20	3	2026-07-02 11:20:54.571356	2026-07-02 14:23:20.931711	2026-07-02 11:20:54.567939	\N	\N	\N	\N	4200003113202607021080319275	\N	2026-07-02 11:21:12.839657	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA811Qp4IUIc8nb3HcQAyb4Fic	
1417	20260702080225458420	13557288765	652	24	E62	1314	20	3	2026-07-02 08:02:25.117063	2026-07-02 14:23:36.995262	2026-07-02 08:02:25.113298	\N	\N	\N	\N	4200003171202607023215871691	\N	2026-07-02 08:03:19.647746	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA811Qp4IUIc8nb3HcQAyb4Fic	
317	20260626131340677421	18888889999	453	8	7	1234	20	3	2026-06-26 13:13:40.256117	2026-06-26 13:13:40.256117	2026-06-26 05:13:40	\N	\N	\N	\N	4200003204202606269502378651	\N	2026-06-26 13:15:47.744732	\N	1	1	none	20	N	Y	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
399	20260628093341461556	18888889999	515	16	21	1234	20	4	2026-06-28 09:33:41.75497	\N	2026-06-28 09:33:41.751031	\N	\N	\N	\N	4200003177202606285617651946	50302607782026070161435143475	2026-06-28 09:34:39.676769	2026-07-01 14:37:30.438743	1	1	refunded	20	N	Y	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
1461	20260702092933837798	18272685238	602	24	E12	5238	20	4	2026-07-02 09:29:34.015377	2026-07-02 09:46:01.688145	2026-07-02 09:29:33.996799	\N	\N	\N	\N	4200003210202607022932241494	\N	2026-07-02 09:30:07.122137	2026-07-02 11:02:23.265029	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA814xoEvsso80LHMIF3J9Beiw	
1479	20260702104259276956	15938352984	616	24	E26	0813	20	3	2026-07-02 10:42:59.032878	2026-07-02 11:33:40.065951	2026-07-02 10:42:59.028919	\N	\N	\N	\N	4200003215202607022002773454	\N	2026-07-02 10:43:18.501043	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81yXA2cIn-m6OHGbotLqLQi0	
1517	20260702143855709858	19037881852	641	24	E51	0000	20	5	2026-07-02 14:38:55.683875	\N	2026-07-02 14:38:55.68052	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA813XY9444KQ-jha8DDs9QkJM	
458	20260630091211403812	17726689234	499	16	5	4234	20	4	2026-06-30 09:12:11.240047	2026-06-30 11:22:12.951859	2026-06-30 09:12:11.22009	\N	\N	\N	\N	4200003097202606307976765838	\N	2026-06-30 09:13:28.184024	2026-07-01 14:35:33.523445	3	1	refunded	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
530	20260630134559767386	17726689234	525	16	31	1234	20	4	2026-06-30 13:45:59.983915	2026-06-30 13:45:59.962796	2026-06-30 13:45:59.962796	\N	\N	\N	\N	4200003194202606305055023900	50302007902026063036986140386	2026-06-30 13:46:20.422718	2026-07-01 14:35:36.278493	2	1	refunded	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
1463	20260702093610225179	15237883857	603	24	E13	1111	20	3	2026-07-02 09:36:10.145139	2026-07-02 10:31:24.515692	2026-07-02 09:36:10.141345	\N	\N	\N	\N	4200003168202607025204765058	\N	2026-07-02 09:36:36.446622	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA813ogxC3GhKPZQZ47Ag8lE3Q	
1462	20260702093419009655	13213132919	750	27	D48	8879	20	3	2026-07-02 09:34:19.498022	2026-07-02 10:39:29.328725	2026-07-02 09:34:19.479303	\N	\N	\N	\N	4200003208202607029573246727	\N	2026-07-02 09:34:34.267358	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2L_VX83kwHGtp10m_uZhTlU	
1482	20260702104834237506	13856712830	708	27	D6	1119	20	3	2026-07-02 10:48:34.79152	2026-07-02 11:14:48.242098	2026-07-02 10:48:34.787663	\N	\N	\N	\N	4200003117202607027113909708	\N	2026-07-02 10:48:54.408519	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2Juw9wVRI4ZXSEYhrRw5pTY	
1480	20260702104611100936	18530250688	617	24	E27	0214	20	3	2026-07-02 10:46:11.091669	2026-07-02 11:35:33.993414	2026-07-02 10:46:11.071131	\N	\N	\N	\N	4200003102202607026311960447	\N	2026-07-02 10:46:36.211333	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA8193Mm87lcVp84Wv7r0UNEyQ	
1481	20260702104821797511	15617023131	707	27	D5	1234	20	4	2026-07-02 10:48:21.987498	2026-07-02 11:58:26.168191	2026-07-02 10:48:21.98363	\N	\N	\N	\N	4200003109202607021531885026	\N	2026-07-02 10:48:43.864003	2026-07-02 12:44:36.938893	5	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-IRSJObx78pJHOh_rAdMCc	
1522	20260702144804467173	15603705779	648	24	E58	0708	20	5	2026-07-02 14:48:04.015917	\N	2026-07-02 14:48:04.011967	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA814Am6sA-8OcprrgCQGFPMOM	
1523	20260702144854973401	15603705779	650	24	E60	0708	20	3	2026-07-02 14:48:54.190528	2026-07-02 15:41:44.419979	2026-07-02 14:48:54.186815	\N	\N	\N	\N	4200003108202607021175010829	\N	2026-07-02 14:49:13.925819	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA814Am6sA-8OcprrgCQGFPMOM	
1521	20260702144526866350	17555309098	646	24	E56	1234	20	3	2026-07-02 14:45:26.092215	2026-07-02 15:55:34.135671	2026-07-02 14:45:26.070758	\N	\N	\N	\N	4200003183202607024711759060	\N	2026-07-02 14:46:13.762169	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA815i3m7PT-6lU3FM6eLjv3wM	
401	20260628094511242522	18888889999	517	16	23	1234	20	3	2026-06-28 09:45:11.146479	2026-06-28 17:48:14	2026-06-28 09:45:11.142633	\N	\N	\N	\N	4200003205202606284880898631	\N	2026-06-28 09:45:59.44543	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-28 17:48:14	2026-06-28 17:48:14	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
318	20260626135530670593	18888889999	454	8	8	2584	20	4	2026-06-26 13:55:30.485465	2026-06-26 06:54:23	2026-06-26 05:55:30	\N	\N	\N	\N	4200003189202606260554928901	50302107622026062666051552700	2026-06-26 13:57:38.738504	2026-06-26 06:54:23	1	0	none	0	N	Y	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
307	20260626073004388401	17726689234	\N	8	A43	1234	20	4	2026-06-26 07:30:04.21892	2026-06-26 09:25:55	2026-06-25 23:30:04	\N	\N	\N	\N	4200003135202606260982950090	\N	2026-06-26 07:31:20.124597	\N	1	0	none	20	N	\N	\N	\N	\N	2026-06-26 09:25:55	2026-06-26 09:25:55	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
1532	20260702150800495797	17838825515	718	27	D16	2013	20	3	2026-07-02 15:08:00.60515	2026-07-02 15:44:52.281961	2026-07-02 15:08:00.602277	\N	\N	\N	\N	4200003105202607027027012156	\N	2026-07-02 15:08:23.464271	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81-HaXjCIpJLaElFsOc2c2gY	
315	20260626094615190546	18888889999	451	8	5	5555	20	4	2026-06-26 09:46:15.591414	2026-06-26 02:48:20	2026-06-26 01:46:15	\N	\N	\N	\N	4200003184202606264338045728	50300807642026062648651889940	2026-06-26 09:46:21.93903	2026-06-26 02:48:20	1	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
316	20260626094918519644	18888889999	452	8	6	1234	20	4	2026-06-26 09:49:18.491913	2026-06-26 04:04:47	2026-06-26 01:49:18	\N	\N	\N	\N	4200003183202606260475366817	50301707452026062667399424477	2026-06-26 10:53:39.424639	2026-06-26 04:04:47	1	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
1471	20260702101724901386	17550270621	705	27	D3	0621	20	3	2026-07-02 10:17:24.289031	2026-07-02 10:27:23.105005	2026-07-02 10:17:24.282937	\N	\N	\N	\N	4200003149202607028930188965	\N	2026-07-02 10:17:50.476207	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA818pWmo_jLWCMOI9N82JPLSQ	
1545	20260702161532597654	13667618419	510	16	B16	1234	20	5	2026-07-02 16:15:32.809526	\N	2026-07-02 16:15:32.80584	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	
1546	20260702161534427322	13667618419	511	16	B17	1234	20	5	2026-07-02 16:15:34.456038	\N	2026-07-02 16:15:34.452311	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	
481	20260630095414309240	17726689234	512	16	18	1234	20	4	2026-06-30 09:54:14.221902	2026-06-30 09:54:14.202174	2026-06-30 09:54:14.202174	\N	\N	\N	\N	4200003188202606309691633192	\N	2026-06-30 09:54:35.340731	2026-07-01 14:35:34.237615	2	1	refunded	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
487	20260630101943467907	17726689234	516	16	22	1234	20	4	2026-06-30 10:19:43.691053	2026-06-30 10:19:43.670884	2026-06-30 10:19:43.670884	\N	\N	\N	\N	4200003106202606308927643382	\N	2026-06-30 10:20:03.524516	2026-07-01 14:35:34.601571	3	1	refunded	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
488	20260630105405124207	17726689234	517	16	23	1234	20	4	2026-06-30 10:54:05.502862	2026-06-30 10:54:05.48182	2026-06-30 10:54:05.48182	\N	\N	\N	\N	4200003186202606300773799142	\N	2026-06-30 10:54:40.858662	2026-07-01 14:35:34.918161	2	1	refunded	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
492	20260630110420701345	17726689234	521	16	27	1234	20	4	2026-06-30 11:04:20.348808	2026-06-30 11:04:20.327317	2026-06-30 11:04:20.327317	\N	\N	\N	\N	4200003130202606306918520781	\N	2026-06-30 11:04:39.110419	2026-07-01 14:35:35.239183	1	1	refunded	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
497	20260630114500326407	17726689234	523	16	29	1234	20	4	2026-06-30 11:45:00.055863	2026-06-30 11:45:00.034393	2026-06-30 11:45:00.034393	\N	\N	\N	\N	4200003121202606303979181027	\N	2026-06-30 11:45:16.979316	2026-07-01 14:35:35.965493	3	1	refunded	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
570	20260701085322762885	17861769100	612	24	E22	0205	20	4	2026-07-01 08:53:22.131087	2026-07-01 12:51:21.314891	2026-07-01 08:53:22.126282	\N	\N	\N	\N	4200003171202607018665847991	\N	2026-07-01 08:53:52.59695	2026-07-01 18:31:37.526495	5	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA817c8U3V_yL3p7whB9YfxycQ	
1534	20260702152133481623	17530271182	720	27	D18	0212	20	3	2026-07-02 15:21:33.500965	2026-07-02 16:01:03.732352	2026-07-02 15:21:33.496847	\N	\N	\N	\N	4200003218202607023259112054	\N	2026-07-02 15:21:51.293623	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA811TwH7MogCPmuLm7kYsr9SE	
1533	20260702151350162558	15560048291	597	24	E7	1234	20	4	2026-07-02 15:13:50.031833	2026-07-02 16:10:59.985548	2026-07-02 15:13:50.028443	\N	\N	\N	\N	4200003136202607027385860641	\N	2026-07-02 15:14:08.222872	2026-07-02 16:25:32.57367	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA8153eXe4paFZN2xGYV_sT0wc	
597	20260701120639790566	18137063193	628	24	E38	0370	20	3	2026-07-01 12:06:39.435663	2026-07-01 14:18:41.555404	2026-07-01 12:06:39.432303	\N	\N	\N	\N	4200003112202607017131420267	\N	2026-07-01 12:07:21.203563	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81--Z4Op2Q70yCPLojW8e2Ns	
604	20260701152234730339	13667618419	498	16	B4	1234	20	3	2026-07-01 15:22:34.780512	2026-07-01 15:23:19.508386	2026-07-01 15:22:34.77664	\N	\N	\N	\N	4200003208202607016431755364	\N	2026-07-01 15:22:52.172123	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	
562	20260701075530128450	17726689234	605	24	E15	1234	20	3	2026-07-01 07:55:30.013338	2026-07-01 08:01:35.544624	2026-07-01 07:55:30.008966	\N	\N	\N	\N	4200003214202607019490189977	\N	2026-07-01 07:55:48.439436	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	
386	20260627180357317523	18983079797	465	15	3	1111	1	3	2026-06-27 18:03:57.305456	2026-06-27 18:06:36.345558	2026-06-27 18:03:57.30143	\N	\N	\N	\N	4200003131202606271749527663	\N	2026-06-27 18:04:23.73262	\N	\N	1	none	1	N	\N	\N	\N	\N	\N	\N	oWrA81-sAdleVupXM1QWH2jwpywk	\N
374	20260627114452740267	18996093393	473	15	11	1111	1	4	2026-06-27 11:44:52.795958	2026-06-27 12:40:46	2026-06-27 11:44:52.791747	\N	\N	\N	\N	4200003183202606272953018543	\N	2026-06-27 11:45:25.221999	2026-07-01 10:18:43.309922	\N	1	refunded	1	N	\N	\N	\N	\N	2026-06-27 12:40:46	2026-06-27 12:40:46	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
596	20260701120600453787	18137063193	626	24	E36	0370	20	5	2026-07-01 12:06:00.51759	\N	2026-07-01 12:06:00.512208	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81--Z4Op2Q70yCPLojW8e2Ns	
1492	20260702113000467184	18253020029	629	24	E39	1234	20	5	2026-07-02 11:30:00.867915	\N	2026-07-02 11:30:00.864126	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA815n0urc4XyC3tj_9X4Q-Cuc	
1490	20260702112614101432	17753648530	709	27	D7	0629	20	3	2026-07-02 11:26:14.32873	2026-07-02 11:33:16.049673	2026-07-02 11:26:14.324469	\N	\N	\N	\N	4200003157202607026085128959	\N	2026-07-02 11:26:35.609281	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA815j2zKUz_ITVwi98Zz3XETg	
1433	20260702083220291669	18838441692	734	27	D32	1123	20	5	2026-07-02 08:32:20.311991	\N	2026-07-02 08:32:20.30825	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA816aueWI5e_0YLIs67waiWBQ	
571	20260701085837218210	13854016305	613	24	E23	1234	20	5	2026-07-01 08:58:37.752752	\N	2026-07-01 08:58:37.749382	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oLhbm2EZ1nbD-lprp6bYvqdQFXzU	
593	20260701115900319392	15964428331	716	27	14	0707	20	3	2026-07-01 11:59:00.289613	2026-07-01 12:40:02.394209	2026-07-01 11:59:00.285731	\N	\N	\N	\N	4200003143202607012889738113	\N	2026-07-01 11:59:26.802135	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816xdTuUlnwYSMz_AD2X4m88	
1484	20260702105732317966	15937086006	619	24	E29	1112	20	5	2026-07-02 10:57:32.476525	\N	2026-07-02 10:57:32.473186	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA8121MDcJ_BFR0HwO-FrCDkoU	
1485	20260702105733584266	15937086006	620	24	E30	1112	20	5	2026-07-02 10:57:33.676873	\N	2026-07-02 10:57:33.673381	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA8121MDcJ_BFR0HwO-FrCDkoU	
1524	20260702145537778400	15690868029	653	24	E63	5658	20	5	2026-07-02 14:55:37.23827	\N	2026-07-02 14:55:37.233542	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA818JXY2ke-_WwcrdF-38BRyE	
422	20260629225052014226	13667618419	503	16	9	1234	20	4	2026-06-29 22:50:52.343292	2026-06-29 22:50:52.341273	2026-06-29 22:50:52.341273	\N	\N	\N	\N	4200003196202606294886056707	50302707742026063072046541887	2026-06-29 22:51:26.69975	2026-06-30 12:30:36.497195	\N	0	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
1550	20260702220339468034	13667618419	524	16	B30	1234	20	5	2026-07-02 22:03:39.595306	\N	2026-07-02 22:03:39.591385	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	
353	20260626203849898493	18888889999	\N	16	31	1234	20	3	2026-06-26 20:38:49.379353	2026-06-27 12:36:26	2026-06-26 20:38:49.37593	\N	\N	\N	\N	4200003195202606264695707051	\N	2026-06-26 20:39:21.485707	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-27 12:36:26	2026-06-27 12:36:26	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
352	20260626203440517799	18888889999	\N	16	14	1234	20	4	2026-06-26 20:34:40.996024	2026-06-27 13:01:09	2026-06-26 20:34:40.992904	\N	\N	\N	\N	4200003125202606264648421174	\N	2026-06-26 20:35:02.286861	2026-06-27 13:01:13.283609	\N	1	refunded	20	N	\N	\N	\N	\N	2026-06-27 13:01:09	2026-06-27 13:01:09	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
1418	20260702080338984148	15515613024	723	27	D21	0718	20	5	2026-07-02 08:03:38.758696	\N	2026-07-02 08:03:38.753896	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA810DW_yygbMfuYYQvU640g6M	
347	20260626195241140324	18888889999	\N	16	13	1234	20	4	2026-06-26 19:52:41.308565	2026-06-27 13:08:19	2026-06-26 19:52:41.305257	\N	\N	\N	\N	4200003178202606268143428277	\N	2026-06-26 19:53:03.021625	2026-06-27 13:08:24.915191	\N	1	refunded	20	N	\N	\N	\N	\N	2026-06-27 13:08:19	2026-06-27 13:08:19	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
1422	20260702080513726588	15993979586	598	24	E8	9586	20	3	2026-07-02 08:05:13.435	2026-07-02 08:07:02.787718	2026-07-02 08:05:13.431767	\N	\N	\N	\N	4200003222202607021077370828	\N	2026-07-02 08:05:44.034072	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA814HKJCkcV1qPzdiW-kGgh0Q	
373	20260627112151757434	18996093393	472	15	10	1111	1	4	2026-06-27 11:21:51.938666	2026-06-27 13:00:57.157798	2026-06-27 11:21:51.93423	\N	\N	\N	\N	4200003189202606278759826892	\N	2026-06-27 11:22:27.301772	2026-06-27 13:00:57.157798	\N	1	refunded	1	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
1493	20260702113002858214	18253020029	630	24	E40	1234	20	4	2026-07-02 11:30:02.211203	2026-07-02 11:34:55.163287	2026-07-02 11:30:02.207732	\N	\N	\N	\N	4200003178202607028156695335	\N	2026-07-02 11:30:53.633659	2026-07-02 11:55:58.48954	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA815n0urc4XyC3tj_9X4Q-Cuc	
1420	20260702080341688802	15836489131	725	27	D23	1111	20	4	2026-07-02 08:03:41.625887	2026-07-02 09:01:05.34263	2026-07-02 08:03:41.622721	\N	\N	\N	\N	4200003109202607028904338697	\N	2026-07-02 08:04:04.317183	2026-07-02 09:36:13.600147	5	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA810QKe4UvoUGtbjxzCCAvRLs	
1419	20260702080341534703	15515613024	724	27	D22	0718	20	3	2026-07-02 08:03:41.451209	2026-07-02 10:05:21.378451	2026-07-02 08:03:41.447616	\N	\N	\N	\N	4200003098202607021414688092	\N	2026-07-02 08:04:11.754582	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA810DW_yygbMfuYYQvU640g6M	
1470	20260702101512496081	13523176144	609	24	E19	6144	20	4	2026-07-02 10:15:12.068882	2026-07-02 10:21:38.325306	2026-07-02 10:15:12.064987	\N	\N	\N	\N	4200003158202607029573672800	\N	2026-07-02 10:15:34.613123	2026-07-02 13:41:33.079427	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA817TcXvAw-MlNurmpFzu7MTY	
1469	20260702101510116869	13523176144	608	24	E18	6144	20	5	2026-07-02 10:15:10.969578	\N	2026-07-02 10:15:10.964263	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA817TcXvAw-MlNurmpFzu7MTY	
1421	20260702080418511793	18530783963	654	24	E64	0000	20	3	2026-07-02 08:04:18.409305	2026-07-02 14:24:09.585131	2026-07-02 08:04:18.405925	\N	\N	\N	\N	4200003125202607026801522001	\N	2026-07-02 08:04:37.348213	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xX8hez494yZ9-kMOkXXQ4c	
1491	20260702112842498012	15660881573	628	24	E38	0608	20	3	2026-07-02 11:28:42.817001	2026-07-02 14:36:53.177058	2026-07-02 11:28:42.813225	\N	\N	\N	\N	4200003193202607024305570989	\N	2026-07-02 11:29:17.460694	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA817WxsE5e2yQdyUtmMPIYRrQ	
1535	20260702152902781559	19251695576	599	24	E9	1234	20	5	2026-07-02 15:29:02.995662	\N	2026-07-02 15:29:02.992204	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA812HZXwlQ55AENyFFBYx3a-c	
1536	20260702152903962518	19251695576	601	24	E11	1234	20	4	2026-07-02 15:29:03.996198	2026-07-02 15:57:17.405365	2026-07-02 15:29:03.992352	\N	\N	\N	\N	4200003155202607025576943705	\N	2026-07-02 15:29:43.760778	2026-07-02 16:37:35.707996	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA812HZXwlQ55AENyFFBYx3a-c	
598	20260701125600825759	18691666092	629	24	E39	0205	20	3	2026-07-01 12:56:00.303827	2026-07-01 14:59:40.597697	2026-07-01 12:56:00.281456	\N	\N	\N	\N	4200003131202607017215309404	\N	2026-07-01 12:56:18.519535	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA811jjTbF5LBNF3y4f5Vds2CE	
1426	20260702081438390022	19339616898	632	24	E42	6898	20	3	2026-07-02 08:14:38.853981	2026-07-02 09:36:59.92869	2026-07-02 08:14:38.850834	\N	\N	\N	\N	4200003223202607020958305631	\N	2026-07-02 08:15:01.83476	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA814uiMq24c_vGENp0TEARkKA	
1427	20260702081546040373	15839096977	634	24	E44	1234	20	3	2026-07-02 08:15:46.945987	2026-07-02 09:41:21.865232	2026-07-02 08:15:46.942364	\N	\N	\N	\N	4200003183202607022098103977	\N	2026-07-02 08:16:18.112375	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA815egAE_pNywyzuTiI4e2OZQ	
1424	20260702081121088451	16650694701	729	27	D27	0811	20	5	2026-07-02 08:11:21.987002	\N	2026-07-02 08:11:21.983405	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oLhbm2FsOXehsq0hbDNTlmOLSS5E	
563	20260701075927078738	17726689234	507	16	B13	1234	20	5	2026-07-01 07:59:27.266432	\N	2026-07-01 07:59:27.261632	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	
575	20260701101336327576	19353007158	615	24	E25	1398	20	5	2026-07-01 10:13:36.514058	\N	2026-07-01 10:13:36.509314	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81zy0WL9Bq00aBnawZAVr48g	
412	20260629185752358994	18996093393	591	24	E1	1111	20	4	2026-06-29 18:57:52.050962	2026-06-29 18:57:52.048506	2026-06-29 18:57:52.048506	\N	\N	\N	\N	4200003198202606291966260716	\N	2026-06-29 18:58:05.315628	2026-07-01 10:18:29.82919	\N	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
391	20260628082951623603	18996093393	466	15	4	1111	1	4	2026-06-28 08:29:51.401874	2026-06-28 08:31:00.780515	2026-06-28 08:29:51.396946	\N	\N	\N	\N	4200003213202606286027761813	\N	2026-06-28 08:30:08.559875	2026-07-01 10:18:33.492837	\N	1	refunded	1	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
359	20260626211337376195	18996093393	\N	16	3	1234	20	4	2026-06-26 21:13:37.547959	2026-06-27 02:01:04	2026-06-26 21:13:37.544542	\N	\N	\N	\N	4200003190202606262178436345	\N	2026-06-26 21:14:06.670619	2026-07-01 10:18:46.722351	\N	1	refunded	20	N	\N	\N	\N	\N	2026-06-27 02:01:04	2026-06-27 02:01:04	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
358	20260626211119806002	18996093393	\N	16	2	1234	20	4	2026-06-26 21:11:19.719376	2026-06-26 21:11:50.818076	2026-06-26 21:11:19.716109	\N	\N	\N	\N	4200003203202606266721579288	\N	2026-06-26 21:11:38.334743	2026-07-01 10:18:49.9143	\N	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
1494	20260702114337770323	13557288765	594	24	E4	1314	20	3	2026-07-02 11:43:37.625961	2026-07-02 14:22:47.737295	2026-07-02 11:43:37.622472	\N	\N	\N	\N	4200003166202607029865162989	\N	2026-07-02 11:43:56.246157	\N	3	1	none	20	N	N	\N	\N	\N	\N	\N	oWrA811Qp4IUIc8nb3HcQAyb4Fic	
407	20260628152256512875	17722332233	521	16	27	1475	20	4	2026-06-28 15:22:56.856654	2026-06-28 15:22:56.852527	2026-06-28 15:22:56.852527	\N	\N	\N	\N	4200003223202606288663233889	\N	2026-06-28 15:23:20.132205	2026-06-30 12:29:58.796656	\N	0	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
376	20260627123001901085	18888889999	496	16	2	1234	20	4	2026-06-27 12:30:01.700717	2026-06-27 12:58:36.902548	2026-06-27 12:30:01.695111	\N	\N	\N	\N	4200003136202606276068779383	\N	2026-06-27 12:30:16.889189	2026-06-27 12:58:36.902548	\N	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
1435	20260702083242496787	15539090389	639	24	E49	1222	20	3	2026-07-02 08:32:42.643187	2026-07-02 10:00:30.073162	2026-07-02 08:32:42.639449	\N	\N	\N	\N	4200003134202607026403183912	\N	2026-07-02 08:33:17.336243	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA812YRQLw0X9WUZStfvUrtwOA	
1436	20260702083258247995	15660700620	641	24	E51	0620	20	3	2026-07-02 08:32:58.674273	2026-07-02 10:10:01.705431	2026-07-02 08:32:58.670277	\N	\N	\N	\N	4200003216202607024064491950	\N	2026-07-02 08:33:14.142276	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA818dHKZ_5gHq_XAXghC3Hpic	
1431	20260702081807013160	19139066893	732	27	D30	1129	20	3	2026-07-02 08:18:07.612956	2026-07-02 09:59:24.360976	2026-07-02 08:18:07.609957	\N	\N	\N	\N	4200003135202607020917459955	\N	2026-07-02 08:18:25.323327	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2EPNzH7fIg51R4voCEe1yiY	
1428	20260702081622517982	19837087059	731	27	D29	0314	20	3	2026-07-02 08:16:22.295182	2026-07-02 10:00:04.214763	2026-07-02 08:16:22.291562	\N	\N	\N	\N	4200003172202607027299271319	\N	2026-07-02 08:16:47.211034	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA813midBHJj2gaaxjeVGWHyFo	
1430	20260702081738212190	15637001160	637	24	E47	1160	20	3	2026-07-02 08:17:38.340218	2026-07-02 10:22:42.628829	2026-07-02 08:17:38.336301	\N	\N	\N	\N	4200003207202607022849662371	\N	2026-07-02 08:17:55.149893	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2EnsrO-ZkeR8tHm0hY6gCY8	
1434	20260702083221633278	18838441692	735	27	D33	1123	20	3	2026-07-02 08:32:21.360198	2026-07-02 09:06:36.035745	2026-07-02 08:32:21.356626	\N	\N	\N	\N	4200003144202607020899239706	\N	2026-07-02 08:32:49.683043	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816aueWI5e_0YLIs67waiWBQ	
1439	20260702083423681975	13183298887	644	24	E54	1234	20	3	2026-07-02 08:34:23.072103	2026-07-02 11:26:35.874486	2026-07-02 08:34:23.068536	\N	\N	\N	\N	4200003145202607024483210716	\N	2026-07-02 08:34:45.038119	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA815ug_YJ7QxjM61cAsF7JcNU	
1539	20260702153326808824	17634328712	603	24	E13	1111	20	3	2026-07-02 15:33:26.834265	2026-07-02 15:51:52.101503	2026-07-02 15:33:26.829885	\N	\N	\N	\N	4200003154202607024444863308	\N	2026-07-02 15:33:56.782044	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81ztTXW1He3CfMl8mOG2feqM	
1429	20260702081651889788	19139362917	636	24	E46	1234	20	3	2026-07-02 08:16:51.34477	2026-07-02 09:07:23.364567	2026-07-02 08:16:51.341484	\N	\N	\N	\N	4200003121202607023061991751	\N	2026-07-02 08:17:16.14303	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xA9gzh57QS5csiBbNkTPGE	
1423	20260702080815398352	19245821928	625	24	E35	0530	20	3	2026-07-02 08:08:15.245935	2026-07-02 09:16:32.454222	2026-07-02 08:08:15.227724	\N	\N	\N	\N	4200003112202607026161337973	\N	2026-07-02 08:08:32.892215	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA813mcLnMvQmNYtkVPU8VQKmA	
1432	20260702082339209075	18738065631	733	27	D31	2005	20	3	2026-07-02 08:23:39.600805	2026-07-02 09:32:12.108895	2026-07-02 08:23:39.597291	\N	\N	\N	\N	4200003121202607022143839361	\N	2026-07-02 08:23:59.332625	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA8184R5USheUKUd6aNfRal1fM	
1438	20260702083353472648	19913257953	643	24	E53	8318	20	3	2026-07-02 08:33:53.237899	2026-07-02 09:36:32.157629	2026-07-02 08:33:53.234576	\N	\N	\N	\N	4200003207202607025773122788	\N	2026-07-02 08:34:15.709689	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81zbmnzK7nJjzMnagrb8bojM	
379	20260627155423256198	18888889999	499	16	5	1234	20	3	2026-06-27 15:54:23.610202	2026-06-28 07:21:51	2026-06-27 15:54:23.605346	\N	\N	\N	\N	4200003209202606279977784591	\N	2026-06-27 15:54:39.077132	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-28 07:21:51	2026-06-28 07:21:51	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
1425	20260702081123882535	16650694701	730	27	D28	0811	20	4	2026-07-02 08:11:23.788003	2026-07-02 09:18:35.760204	2026-07-02 08:11:23.784594	\N	\N	\N	\N	4200003121202607029879350091	\N	2026-07-02 08:11:49.496097	2026-07-02 12:53:35.411355	5	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2FsOXehsq0hbDNTlmOLSS5E	
1538	20260702153325270161	17634328712	602	24	E12	1111	20	5	2026-07-02 15:33:25.827012	\N	2026-07-02 15:33:25.823456	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81ztTXW1He3CfMl8mOG2feqM	
1437	20260702083352775935	19233600317	736	27	D34	0702	20	4	2026-07-02 08:33:52.790969	2026-07-02 09:47:57.813312	2026-07-02 08:33:52.786883	\N	\N	\N	\N	4200003183202607022876371781	\N	2026-07-02 08:34:13.578231	2026-07-02 21:57:45.649338	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA8177WxIeNqyqQzQDe3yP2Y58	
1537	20260702153319838903	13667618419	509	16	B15	1234	20	3	2026-07-02 15:33:19.708571	2026-07-02 15:34:52.641868	2026-07-02 15:33:19.686971	\N	\N	\N	\N	4200003113202607027891324584	\N	2026-07-02 15:33:48.373941	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	
1472	20260702102316076531	13523176144	610	24	E20	6144	20	4	2026-07-02 10:23:16.791126	2026-07-02 11:47:46.654097	2026-07-02 10:23:16.785223	\N	\N	\N	\N	4200003199202607025400708435	\N	2026-07-02 10:23:31.665698	2026-07-02 13:41:29.605154	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA817TcXvAw-MlNurmpFzu7MTY	
1495	20260702124747088994	17554760510	596	24	E6	2007	20	3	2026-07-02 12:47:47.718468	2026-07-02 14:36:18.333201	2026-07-02 12:47:47.713576	\N	\N	\N	\N	4200003106202607025301030545	\N	2026-07-02 12:48:11.304326	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81yGgyQp6k0KArC2bDCg-AOo	
454	20260630090354376183	18996093393	598	24	E8	1234	20	4	2026-06-30 09:03:54.10188	2026-06-30 09:03:54.081831	2026-06-30 09:03:54.081831	\N	\N	\N	\N	4200003183202606303659442815	\N	2026-06-30 09:04:02.318368	2026-07-01 10:18:26.417015	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
1540	20260702153748669240	18238033278	722	27	D20	0302	20	3	2026-07-02 15:37:48.657807	2026-07-02 16:06:53.288316	2026-07-02 15:37:48.652823	\N	\N	\N	\N	4200003201202607021042795465	\N	2026-07-02 15:38:03.5797	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2HZkvXVQ6v_cybMC7LG5-xQ	
1441	20260702083627459366	13783560310	737	27	D35	0310	20	3	2026-07-02 08:36:27.135531	2026-07-02 09:32:48.151272	2026-07-02 08:36:27.131798	\N	\N	\N	\N	4200003134202607025605887297	\N	2026-07-02 08:36:51.833277	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xGKZXuj6d1GJzKvmxZ1W7I	
1440	20260702083539933571	15909265992	646	24	E56	0923	20	3	2026-07-02 08:35:39.905011	2026-07-02 09:40:05.726193	2026-07-02 08:35:39.901053	\N	\N	\N	\N	4200003151202607029237071811	\N	2026-07-02 08:36:05.599823	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA818VHew3gFO623fbttvT6txM	
584	20260701115727590523	17346902460	708	27	6	4599	20	3	2026-07-01 11:57:27.878248	2026-07-01 13:09:34.410003	2026-07-01 11:57:27.875003	\N	\N	\N	\N	4200003160202607013707414179	\N	2026-07-01 11:57:46.613898	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xN1nYud88nFNzeIP1nvHzI	
583	20260701115720312297	18356795403	620	24	E30	0710	20	3	2026-07-01 11:57:20.942864	2026-07-01 13:22:57.309578	2026-07-01 11:57:20.939087	\N	\N	\N	\N	4200003150202607010821379177	\N	2026-07-01 11:57:44.51209	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA815X34Q0bdaJaGtxESJEC7cE	
599	20260701130626543594	15186672778	630	24	E40	2580	20	3	2026-07-01 13:06:26.550151	2026-07-01 13:42:33.584659	2026-07-01 13:06:26.545064	\N	\N	\N	\N	4200003179202607011727208664	\N	2026-07-01 13:07:02.259003	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81_Kec6OckOEGFtA4JK6ivgE	
1444	20260702084500628342	15842660777	650	24	E60	8718	20	3	2026-07-02 08:45:00.600478	2026-07-02 09:42:24.574592	2026-07-02 08:45:00.596543	\N	\N	\N	\N	4200003124202607025302592093	\N	2026-07-02 08:45:30.296621	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA810Y8WflOSvGD02abudm10Ag	
1442	20260702084221943712	19836511038	738	27	D36	1038	20	3	2026-07-02 08:42:21.169495	2026-07-02 09:48:31.253862	2026-07-02 08:42:21.165932	\N	\N	\N	\N	4200003211202607027976588887	\N	2026-07-02 08:42:45.843041	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA8165r_1j3OPLw-g-gCViRQMs	
461	20260630093015601516	18983079797	601	24	E11	1234	20	3	2026-06-30 09:30:15.203007	2026-06-30 09:30:15.181189	2026-06-30 09:30:15.181189	\N	\N	\N	\N	4200003185202606305579509474	\N	2026-06-30 09:30:39.947353	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81-sAdleVupXM1QWH2jwpywk	\N
1443	20260702084440802683	19337028036	648	24	E58	8888	20	4	2026-07-02 08:44:40.80552	2026-07-02 08:45:41.005646	2026-07-02 08:44:40.802012	\N	\N	\N	\N	4200003124202607027557818764	\N	2026-07-02 08:45:01.03456	2026-07-02 10:00:36.777062	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA812oTTIp1f3twgeW-_0xEtgs	
440	20260630075016897517	17726689234	521	16	27	1234	20	4	2026-06-30 07:50:16.303948	2026-06-30 07:54:56.206145	2026-06-30 07:50:16.28316	\N	\N	\N	\N	4200003126202606304942694629	\N	2026-06-30 07:50:37.421189	2026-06-30 12:29:58.796656	1	0	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
493	20260630111758918131	17726689234	522	16	28	1234	20	4	2026-06-30 11:17:58.486108	2026-06-30 11:17:58.465235	2026-06-30 11:17:58.465235	\N	\N	\N	\N	4200003174202606308573605856	\N	2026-06-30 11:18:17.916737	2026-07-01 14:35:35.618751	3	1	refunded	20	N	\N	\N	\N	\N	\N	2026-06-30 15:36:26.717548	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
506	20260630123939351137	18254067609	626	24	E36	2007	20	3	2026-06-30 12:39:39.072378	2026-06-30 18:27:44.766091	2026-06-30 12:39:39.051439	\N	\N	\N	\N	4200003190202606306991859861	50302107702026063010864677966	2026-06-30 12:40:01.282903	2026-06-30 21:24:15.600965	2	1	success	20	N	\N	\N	\N	\N	\N	2026-06-30 18:27:44.766091	oWrA81yIpUhQohO1TptlV1HLGlGU	\N
484	20260630101459139734	19905939796	613	24	E23	8106	20	3	2026-06-30 10:14:59.088933	2026-06-30 10:14:59.067319	2026-06-30 10:14:59.067319	\N	\N	\N	\N	4200003224202606309624402648	\N	2026-06-30 10:15:35.26215	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81x-B7qKpyyzunCQ79w_44Uo	\N
1474	20260702102723971816	15836493002	612	24	E22	0509	20	3	2026-07-02 10:27:23.056033	2026-07-02 11:05:58.245274	2026-07-02 10:27:23.052521	\N	\N	\N	\N	4200003105202607023567622032	\N	2026-07-02 10:27:49.5781	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81_rFRm7u2X-oilv9yZLkMQY	
303	20260626070425643415	17726689234	\N	8	A41	1234	20	4	2026-06-26 07:04:25.78776	2026-06-26 07:07:47	2026-06-25 23:04:25	\N	\N	\N	\N	4200003184202606262064245079	\N	2026-06-26 07:06:32.966761	2026-06-30 12:29:58.796656	1	0	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
1473	20260702102630123341	15065370778	611	24	E21	1920	20	3	2026-07-02 10:26:30.930217	2026-07-02 11:09:35.546162	2026-07-02 10:26:30.925037	\N	\N	\N	\N	4200003190202607020392026579	\N	2026-07-02 10:26:59.15701	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81wuBCqHNzGr9sDF-wFXJp2I	
1500	20260702134148787231	13323972142	640	24	E50	9999	20	3	2026-07-02 13:41:48.719591	2026-07-02 14:36:36.305709	2026-07-02 13:41:48.715393	\N	\N	\N	\N	4200003100202607020096329816	\N	2026-07-02 13:42:13.403276	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81yzw_POSOjDnBWrj73937C4	
1445	20260702084752583541	15239932935	740	27	D38	3993	20	5	2026-07-02 08:47:52.744723	\N	2026-07-02 08:47:52.726892	\N	\N	\N	\N	\N	\N	\N	\N	1	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA816T8KS6QqBABmZa2xuqWmTY	
1503	20260702140306046418	18530250688	647	24	E57	0214	20	3	2026-07-02 14:03:06.954188	2026-07-02 14:37:48.02642	2026-07-02 14:03:06.949991	\N	\N	\N	\N	4200003177202607020269594290	\N	2026-07-02 14:03:27.455436	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA8193Mm87lcVp84Wv7r0UNEyQ	
578	20260701115709517813	17861769100	618	24	E28	0205	20	5	2026-07-01 11:57:09.437269	\N	2026-07-01 11:57:09.432691	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA817c8U3V_yL3p7whB9YfxycQ	
585	20260701115732646895	15054012361	709	27	7	0000	20	5	2026-07-01 11:57:32.459471	\N	2026-07-01 11:57:32.455852	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA815CE4K5rUqMmftCAJTm1S30	
581	20260701115720270337	15514642606	707	27	5	0303	20	3	2026-07-01 11:57:20.518413	2026-07-01 12:45:09.374782	2026-07-01 11:57:20.514866	\N	\N	\N	\N	4200003168202607016957955981	\N	2026-07-01 11:57:45.888185	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA819Lx-sIzmvxY6tz8YZjwNIc	
587	20260701115757810612	15554513417	711	27	9	0704	20	3	2026-07-01 11:57:57.457779	2026-07-01 13:26:41.381057	2026-07-01 11:57:57.4545	\N	\N	\N	\N	4200003146202607010349055012	\N	2026-07-01 11:58:19.623139	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA8120rleeG_cU57X62VK9CytA	
565	20260701080252681224	13655676086	607	24	E17	6699	20	3	2026-07-01 08:02:52.16279	2026-07-01 13:30:54.58668	2026-07-01 08:02:52.158452	\N	\N	\N	\N	4200003118202607014815002149	\N	2026-07-01 08:03:09.600199	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2ELXC34oFmP0lsNf1Ot1iCA	
1449	20260702090033429063	15751766581	591	24	E1	0919	20	4	2026-07-02 09:00:33.316107	2026-07-02 09:22:19.093927	2026-07-02 09:00:33.3129	\N	\N	\N	\N	4200003111202607023388388960	\N	2026-07-02 09:00:53.276007	2026-07-02 13:17:39.11094	3	1	refunded	20	N	Y	\N	\N	\N	\N	\N	oWrA811t76_2yyWusSObq9nSrfcg	
505	20260630123936503848	15617060696	625	24	E35	5656	20	4	2026-06-30 12:39:36.449014	2026-07-01 15:13:44.668126	2026-06-30 12:39:36.428076	\N	\N	\N	\N	4200003204202606306642224931	\N	2026-06-30 12:40:07.351985	2026-07-02 09:44:33.115684	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81w-5cgkKNolzfRIie4yxyu0	\N
1448	20260702085549357029	18137062351	743	27	D41	1234	20	3	2026-07-02 08:55:49.373278	2026-07-02 10:10:23.694185	2026-07-02 08:55:49.369716	\N	\N	\N	\N	4200003180202607022018395569	\N	2026-07-02 08:56:14.946092	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA812OXNMzRfoAM_-w9lTAf0J8	
1447	20260702084803210252	18133317626	653	24	E63	0000	20	4	2026-07-02 08:48:03.526115	2026-07-02 10:11:34.379322	2026-07-02 08:48:03.52269	\N	\N	\N	\N	4200003201202607027770748026	\N	2026-07-02 08:48:20.764501	2026-07-02 10:22:41.013224	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2FZ9P28KBn5ApgCiGpMs5r0	
1498	20260702134104573220	15136011309	635	24	E45	1472	20	3	2026-07-02 13:41:04.44203	2026-07-02 14:35:11.687958	2026-07-02 13:41:04.438518	\N	\N	\N	\N	4200003200202607024843596481	\N	2026-07-02 13:41:27.050305	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA814a2nNpcpm6wn0rsN5_cl1Y	
1501	20260702135424743179	17527227908	642	24	E52	0816	20	3	2026-07-02 13:54:24.868174	2026-07-02 14:33:40.216701	2026-07-02 13:54:24.864586	\N	\N	\N	\N	4200003165202607021379068692	\N	2026-07-02 13:54:42.468375	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA817nAVIOva_3x9Nr-Oomqvv8	
1507	20260702140744122992	18039160828	711	27	D9	2007	20	3	2026-07-02 14:07:44.64612	2026-07-02 15:30:55.386926	2026-07-02 14:07:44.642429	\N	\N	\N	\N	4200003141202607027079386733	\N	2026-07-02 14:08:06.764258	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA810XuBZkcAV8pyGXYUhpCLA4	
1499	20260702134132115829	15939273255	638	24	E48	3255	20	3	2026-07-02 13:41:32.554938	2026-07-02 14:36:05.494115	2026-07-02 13:41:32.551349	\N	\N	\N	\N	4200003150202607027837612120	\N	2026-07-02 13:42:05.396515	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81-P8o1xlaZJIc_VsRJwp1Iw	
1508	20260702140754601295	17753648530	632	24	E42	0629	20	3	2026-07-02 14:07:54.84499	2026-07-02 14:39:43.084263	2026-07-02 14:07:54.841104	\N	\N	\N	\N	4200003175202607021935154341	\N	2026-07-02 14:08:17.208145	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA815j2zKUz_ITVwi98Zz3XETg	
1509	20260702140755030152	19639308701	712	27	D10	8701	20	4	2026-07-02 14:07:55.409982	2026-07-02 14:41:42.620585	2026-07-02 14:07:55.406716	\N	\N	\N	\N	4200003141202607026367937191	\N	2026-07-02 14:08:17.118848	2026-07-02 15:31:28.65186	5	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-zeWU3yEM4u6Kbk8NxGWc4	
507	20260630123952112437	18865018110	627	24	E37	1886	20	2	2026-06-30 12:39:52.568609	\N	2026-06-30 12:39:52.545299	\N	\N	\N	\N	4200003223202606301431470228	\N	2026-06-30 12:40:15.974605	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA816FjsBSQwPthTIM5WXpjYVI	\N
1502	20260702140217485233	17698950605	645	24	E55	2580	20	3	2026-07-02 14:02:17.770793	2026-07-02 14:55:50.366505	2026-07-02 14:02:17.767472	\N	\N	\N	\N	4200003219202607026278961303	\N	2026-07-02 14:02:48.816589	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA819UjvsavRe5EzlNKw46Eqo4	
1504	20260702140724250870	18455712691	649	24	E59	1234	20	3	2026-07-02 14:07:24.754317	2026-07-02 15:36:44.833655	2026-07-02 14:07:24.750863	\N	\N	\N	\N	4200003172202607022875337007	\N	2026-07-02 14:07:42.983996	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA817WlHfrZUcskfKLMmqTuZCI	
1505	20260702140728934675	19337089231	598	24	E8	9210	20	5	2026-07-02 14:07:28.76366	\N	2026-07-02 14:07:28.760124	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA815sx6kJjrzjGgTlP1ybY5UM	
1496	20260702134039042484	17503709333	633	24	E43	9333	20	3	2026-07-02 13:40:39.61041	2026-07-02 14:27:48.535157	2026-07-02 13:40:39.606135	\N	\N	\N	\N	4200003138202607029128063523	\N	2026-07-02 13:40:55.969725	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81z7APIi80z5qbuLjBW44FMA	
413	20260629212626345012	13667618419	526	16	32	1234	20	4	2026-06-29 21:26:26.194231	2026-06-29 21:26:26.191915	2026-06-29 21:26:26.191915	\N	\N	\N	\N	4200003134202606295998962135	\N	2026-06-29 21:26:52.835011	2026-06-30 12:29:58.796656	\N	0	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
1506	20260702140730396695	19337089231	625	24	E35	9210	20	3	2026-07-02 14:07:30.363268	2026-07-02 15:47:53.350256	2026-07-02 14:07:30.360175	\N	\N	\N	\N	4200003173202607020245488486	\N	2026-07-02 14:07:59.925731	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA815sx6kJjrzjGgTlP1ybY5UM	
567	20260701083356818933	19261605685	609	24	E19	1112	20	3	2026-07-01 08:33:56.393288	2026-07-01 14:07:38.874842	2026-07-01 08:33:56.38981	\N	\N	\N	\N	4200003207202607016860589133	\N	2026-07-01 08:34:20.71339	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA813GNHV6SjKHLTefeayzCI1E	
512	20260630124135737562	15098366660	632	24	E42	1013	20	4	2026-06-30 12:41:35.535429	2026-06-30 15:08:55	2026-06-30 12:41:35.51477	\N	\N	\N	\N	4200003149202606301063935560	\N	2026-06-30 12:42:00.659396	2026-06-30 15:09:00.253175	3	1	refunded	20	N	\N	\N	\N	\N	2026-06-30 15:08:55	2026-06-30 15:08:55	oWrA814SNv6vojll-l7fnoshhlRk	\N
514	20260630125108236602	18265005796	634	24	E44	7878	20	4	2026-06-30 12:51:08.816958	2026-06-30 15:16:02.742288	2026-06-30 12:51:08.796771	\N	\N	\N	\N	4200003224202606306671084085	\N	2026-06-30 12:51:46.013373	2026-07-01 08:10:45.619277	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81-ItgTPxpuU_KnmJnRQIZc8	\N
532	20260630134846640888	13791463202	650	24	E60	1234	20	3	2026-06-30 13:48:46.550553	2026-06-30 15:17:35.702619	2026-06-30 13:48:46.52923	\N	\N	\N	\N	4200003223202606307199431243	\N	2026-06-30 13:49:06.172062	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA819H2B8_mgblRP2ZpM42vNUY	\N
1475	20260702102735750065	15938352984	613	24	E23	0813	20	3	2026-07-02 10:27:35.155316	2026-07-02 10:42:28.55759	2026-07-02 10:27:35.149895	\N	\N	\N	\N	4200003103202607021755216792	\N	2026-07-02 10:27:54.57117	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81yXA2cIn-m6OHGbotLqLQi0	
566	20260701083251034222	15090698884	608	24	E18	1013	20	3	2026-07-01 08:32:51.021735	2026-07-01 10:25:55.515148	2026-07-01 08:32:51.017162	\N	\N	\N	\N	4200003184202607016775152766	\N	2026-07-01 08:33:15.269382	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA810fvi3viiR0SZjFt8saWwj8	
528	20260630134555889371	18953074181	648	24	E58	1234	20	3	2026-06-30 13:45:55.349822	2026-06-30 15:29:00.865583	2026-06-30 13:45:55.32821	\N	\N	\N	\N	4200003180202606305224957902	\N	2026-06-30 13:46:23.954501	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA811vea15wVBi1JfZ3bWsqaQU	\N
519	20260630130451524847	19286022436	639	24	E49	6666	20	4	2026-06-30 13:04:51.133104	2026-06-30 15:18:21.865765	2026-06-30 13:04:51.109839	\N	\N	\N	\N	4200003138202606302528916179	\N	2026-06-30 13:05:24.693386	2026-06-30 16:50:51.910392	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA81yNEVUEKWc7GIPodzG2yGXE	\N
580	20260701115719192570	15514642606	706	27	4	0303	20	5	2026-07-01 11:57:19.414044	\N	2026-07-01 11:57:19.410298	\N	\N	\N	\N	\N	\N	\N	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA819Lx-sIzmvxY6tz8YZjwNIc	
1450	20260702090827849691	18338751797	592	24	E2	0000	20	4	2026-07-02 09:08:27.380817	2026-07-02 10:33:59.888462	2026-07-02 09:08:27.376445	\N	\N	\N	\N	4200003163202607021765635733	\N	2026-07-02 09:08:51.687625	2026-07-02 10:37:04.132749	5	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA811zMPTqnGWHvmqlBfn2wwJA	
582	20260701115720962016	17838930615	619	24	E29	5474	20	3	2026-07-01 11:57:20.783064	2026-07-01 12:41:57.726626	2026-07-01 11:57:20.779598	\N	\N	\N	\N	4200003111202607019568875762	\N	2026-07-01 11:57:43.7715	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA814FpDvSeL8zrtGms5pmTL34	
588	20260701115813210130	18238060772	712	27	10	1234	20	3	2026-07-01 11:58:13.984192	2026-07-01 12:40:31.315239	2026-07-01 11:58:13.980475	\N	\N	\N	\N	4200003193202607017798897870	\N	2026-07-01 11:58:57.554867	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA8165UBZ7Orymi-LSK1VjzqzQ	
523	20260630132913118022	15275043796	643	24	E53	8011	20	3	2026-06-30 13:29:13.617642	2026-06-30 16:12:23.934446	2026-06-30 13:29:13.59594	\N	\N	\N	\N	4200003128202606309427246633	\N	2026-06-30 13:29:47.108379	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA817RU4v8eQ-ItnK1Sjcj3d7Q	\N
579	20260701115715162390	15136012752	705	27	3	0805	20	3	2026-07-01 11:57:15.050592	2026-07-01 12:55:33.339775	2026-07-01 11:57:15.04579	\N	\N	\N	\N	4200003174202607012552503843	\N	2026-07-01 11:57:38.829814	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816c_JmOH0j8iJ0Icdo59A48	
516	20260630125130451288	18326741968	636	24	E46	9999	20	3	2026-06-30 12:51:30.444471	2026-06-30 15:12:49.55469	2026-06-30 12:51:30.424234	\N	\N	\N	\N	4200003151202606305421787597	\N	2026-06-30 12:52:31.090413	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xM1eyqfXkFpnjHU05ps_LU	\N
1510	20260702140827587893	18272662178	634	24	E44	1214	20	3	2026-07-02 14:08:27.357222	2026-07-02 15:30:17.998753	2026-07-02 14:08:27.352775	\N	\N	\N	\N	4200003190202607028572185645	\N	2026-07-02 14:08:47.455715	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA810A_OcB_7y5WIAkbKFcoIQg	
1511	20260702141511067735	15137051381	636	24	E46	1205	20	5	2026-07-02 14:15:11.628494	\N	2026-07-02 14:15:11.624848	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA813UlMB5Lcgr348eJ_7sgGrg	
524	20260630133057596999	18438398466	644	24	E54	8466	20	3	2026-06-30 13:30:57.276719	2026-06-30 15:54:09.750178	2026-06-30 13:30:57.256674	\N	\N	\N	\N	4200003135202606306343380379	\N	2026-06-30 13:31:26.664935	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA812I_KJbezJSGRt8wnBfzK4s	\N
1541	20260702153854213248	19273906997	723	27	D21	1314	20	3	2026-07-02 15:38:54.574615	2026-07-02 16:18:41.209091	2026-07-02 15:38:54.570122	\N	\N	\N	\N	4200003133202607020095979243	\N	2026-07-02 15:39:55.612503	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA811nPB5h_tQVxuI4CzaD3ZX4	
521	20260630131251511581	18637010208	641	24	E51	1111	20	4	2026-06-30 13:12:51.853737	2026-06-30 16:31:24.751435	2026-06-30 13:12:51.832105	\N	\N	\N	\N	4200003097202606302709695392	\N	2026-06-30 13:13:16.351852	2026-06-30 17:12:18.658536	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA8123pVky5DBpbOF-0YgfVVOA	\N
517	20260630130421202757	15657821278	637	24	E47	1314	20	3	2026-06-30 13:04:21.911241	2026-06-30 13:04:21.890156	2026-06-30 13:04:21.890156	\N	\N	\N	\N	4200003218202606304060814654	\N	2026-06-30 13:04:54.464287	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA8119oPBjRQBBnEdipGqRawa8	\N
1512	20260702141512471432	15137051381	637	24	E47	1205	20	3	2026-07-02 14:15:12.727293	2026-07-02 14:44:45.203243	2026-07-02 14:15:12.723431	\N	\N	\N	\N	4200003185202607021345853362	\N	2026-07-02 14:15:33.548707	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA813UlMB5Lcgr348eJ_7sgGrg	
424	20260629225224739911	13667618419	505	16	11	1234	20	4	2026-06-29 22:52:24.82795	2026-06-29 22:52:24.825913	2026-06-29 22:52:24.825913	\N	\N	\N	\N	4200003199202606299595869587	50302707822026063078239768103	2026-06-29 22:52:47.231275	2026-06-30 12:29:33.041215	\N	0	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
432	20260630070731985915	13667618419	513	16	19	1234	20	4	2026-06-30 07:07:31.383625	2026-06-30 07:07:31.36396	2026-06-30 07:07:31.36396	\N	\N	\N	\N	4200003185202606302618664886	50300607922026063003185761556	2026-06-30 07:08:08.499015	2026-06-30 12:29:28.501642	2	0	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
441	20260630075135072321	17726689234	522	16	28	1234	20	4	2026-06-30 07:51:35.654789	2026-06-30 07:51:35.63506	2026-06-30 07:51:35.63506	\N	\N	\N	\N	4200003102202606301301964997	\N	2026-06-30 07:51:52.930912	2026-06-30 12:29:58.796656	3	0	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
494	20260630112639381589	13667618419	614	24	E24	1234	20	4	2026-06-30 11:26:39.555022	2026-06-30 11:26:39.522294	2026-06-30 11:26:39.522294	\N	\N	\N	\N	4200003131202606308786195009	\N	2026-06-30 11:26:59.012298	2026-06-30 11:38:11.28106	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
396	20260628084105846088	17722332233	512	16	18	3698	20	4	2026-06-28 08:41:05.289221	2026-06-28 08:41:05.285541	2026-06-28 08:41:05.285541	\N	\N	\N	\N	4200003183202606281049040918	\N	2026-06-28 08:41:27.716368	2026-06-30 12:29:58.796656	\N	0	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
332	20260626155413206167	18888889999	\N	16	22	1234	20	4	2026-06-26 15:54:13.158122	2026-06-26 07:54:13	2026-06-26 07:54:13	\N	\N	\N	\N	4200003214202606261349170060	\N	2026-06-26 17:28:40.671384	2026-06-30 12:29:58.796656	1	0	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
397	20260628084559522187	17722332233	513	16	19	1234	20	4	2026-06-28 08:45:59.421579	2026-06-28 08:45:59.417494	2026-06-28 08:45:59.417494	\N	\N	\N	\N	4200003133202606282333152255	\N	2026-06-28 08:46:21.724518	2026-06-30 12:29:58.796656	\N	0	none	20	N	Y	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
436	20260630071102574249	17726689234	517	16	23	1234	20	4	2026-06-30 07:11:02.520772	2026-06-30 07:11:02.498729	2026-06-30 07:11:02.498729	\N	\N	\N	\N	4200003119202606306901998225	\N	2026-06-30 07:11:20.883796	2026-06-30 12:29:58.796656	3	0	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
438	20260630072823856658	17726689234	519	16	25	1234	20	4	2026-06-30 07:28:23.32169	2026-06-30 07:28:23.300015	2026-06-30 07:28:23.300015	\N	\N	\N	\N	4200003196202606302480741718	\N	2026-06-30 07:28:54.438649	2026-06-30 12:29:58.796656	2	0	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
30	20260613105455853270	13667618419	6	1	6	1245	20	4	2026-06-13 10:54:55.784146	2026-06-20 07:28:42.627193	2026-06-13 02:54:55	\N	\N	\N	\N	MOCK20260613105457264570	\N	2026-06-13 10:54:57.370452	2026-06-30 18:20:16.692277	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
33	20260613111339242608	13667618419	9	1	9	1234	20	4	2026-06-13 11:13:39.831526	2026-06-20 07:28:30.680119	2026-06-13 03:13:39	\N	\N	\N	\N	MOCK20260613111341731060	\N	2026-06-13 11:13:41.426004	2026-06-30 18:20:30.370586	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
34	20260613111950247604	13667618419	10	1	10	1234	20	4	2026-06-13 11:19:50.101529	2026-06-20 07:28:25.534453	2026-06-13 03:19:50	\N	\N	\N	\N	MOCK20260613111951029532	\N	2026-06-13 11:19:51.705278	2026-06-30 18:20:23.259416	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
1513	20260702142039515714	15236859855	639	24	E49	7910	20	3	2026-07-02 14:20:39.574054	2026-07-02 15:59:49.333715	2026-07-02 14:20:39.57054	\N	\N	\N	\N	4200003163202607027240900916	\N	2026-07-02 14:20:58.573409	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA814i0R3Twjzkz8oJauUChfEY	
500	20260630122321456133	13667618419	619	24	E29	1234	20	4	2026-06-30 12:23:21.850439	2026-06-30 12:23:21.83036	2026-06-30 12:23:21.83036	\N	\N	\N	\N	4200003190202606303089652659	50301907852026063066869054592	2026-06-30 12:23:42.549796	2026-06-30 12:29:22.440017	1	0	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
496	20260630113938731600	13667618419	616	24	E26	1234	20	4	2026-06-30 11:39:38.085987	2026-06-30 11:39:38.065986	2026-06-30 11:39:38.065986	\N	\N	\N	\N	4200003210202606300113915182	50302207982026063021246271353	2026-06-30 11:40:00.921905	2026-06-30 12:29:23.388248	1	0	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
586	20260701115748007727	15136012752	710	27	8	0805	20	5	2026-07-01 11:57:48.329584	\N	2026-07-01 11:57:48.324453	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA816c_JmOH0j8iJ0Icdo59A48	
498	20260630120430300084	13667618419	617	24	E27	1234	20	4	2026-06-30 12:04:30.058494	2026-06-30 12:04:30.037885	2026-06-30 12:04:30.037885	\N	\N	\N	\N	4200003130202606309674975458	\N	2026-06-30 12:04:52.582013	2026-06-30 12:29:58.796656	2	0	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
533	20260630140052363155	19693594027	651	24	E61	4027	20	2	2026-06-30 14:00:52.422918	\N	2026-06-30 14:00:52.4012	\N	\N	\N	\N	4200003107202606306060143584	\N	2026-06-30 14:01:19.933992	\N	3	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81xxlAxojDpUE3Q5nxIdLaSA	\N
313	20260626093604565096	18888889999	449	8	3	1234	20	3	2026-06-26 09:36:04.314655	2026-06-26 09:36:04.314655	2026-06-26 01:36:04	\N	\N	\N	\N	4200003188202606261236674981	\N	2026-06-26 09:39:42.377781	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
314	20260626094216584004	18888889999	450	8	4	1234	20	3	2026-06-26 09:42:16.701258	2026-06-26 09:42:16.701258	2026-06-26 01:42:16	\N	\N	\N	\N	4200003186202606263086244068	\N	2026-06-26 09:42:30.426072	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
312	20260626093458449115	18888889999	448	8	2	1472	20	3	2026-06-26 09:34:58.429982	2026-06-26 09:35:30	2026-06-26 01:34:58	\N	\N	\N	\N	\N	\N	\N	\N	1	1	none	20	N	\N	\N	\N	\N	2026-06-26 09:35:30	2026-06-26 09:35:30	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
400	20260628093722986540	18888889999	516	16	22	1234	20	3	2026-06-28 09:37:22.654169	2026-06-29 08:51:01	2026-06-28 09:37:22.650293	\N	\N	\N	\N	4200003191202606283617596483	\N	2026-06-28 09:37:42.630942	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-29 08:51:01	2026-06-29 08:51:01	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
368	20260627100422451091	18888889999	\N	16	42	1234	20	3	2026-06-27 10:04:22.568878	2026-06-27 12:41:16	2026-06-27 10:04:22.56541	\N	\N	\N	\N	4200003132202606278136500376	\N	2026-06-27 10:05:21.590954	\N	\N	1	none	20	N	\N	\N	\N	\N	2026-06-27 12:41:16	2026-06-27 12:41:16	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
390	20260628075013324398	18888889999	508	16	14	1234	20	3	2026-06-28 07:50:13.359321	2026-06-28 07:50:13.355498	2026-06-28 07:50:13.355498	\N	\N	\N	\N	4200003179202606284370748705	\N	2026-06-28 07:50:38.542911	2026-06-30 12:29:58.796656	\N	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81-wvf2HDTxBYtigtDeifFYs	\N
503	20260630123932308808	15550752925	623	24	E33	2925	20	3	2026-06-30 12:39:32.545394	2026-06-30 12:39:32.523626	2026-06-30 12:39:32.523626	\N	\N	\N	\N	4200003197202606308771166775	\N	2026-06-30 12:40:01.370608	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA8105UJTohMvSF-xYM6nVUWOA	\N
1542	20260702154118599900	17503709333	604	24	E14	9333	20	3	2026-07-02 15:41:18.32903	2026-07-02 16:09:52.815477	2026-07-02 15:41:18.323084	\N	\N	\N	\N	4200003124202607023587875983	\N	2026-07-02 15:41:31.434369	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81z7APIi80z5qbuLjBW44FMA	
1451	20260702091414791295	13213132919	745	27	D43	8879	20	3	2026-07-02 09:14:14.999046	2026-07-02 09:17:08.597806	2026-07-02 09:14:14.995131	\N	\N	\N	\N	4200003191202607029964163717	\N	2026-07-02 09:14:32.453606	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2L_VX83kwHGtp10m_uZhTlU	
535	20260630141511676928	15225299085	653	24	E63	1479	20	3	2026-06-30 14:15:11.916386	2026-06-30 16:18:10.688146	2026-06-30 14:15:11.894956	\N	\N	\N	\N	4200003178202606309902143709	\N	2026-06-30 14:15:36.906924	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81_esql0oaMLcsIiLopvL1Ro	\N
538	20260630141616444325	19137096192	592	24	E2	1223	20	3	2026-06-30 14:16:16.447977	2026-06-30 16:17:34.490627	2026-06-30 14:16:16.427624	\N	\N	\N	\N	4200003131202606303988984290	\N	2026-06-30 14:16:50.133427	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81wqfJhuq3HGJQDiZ2Ak3Tfs	\N
547	20260630153014147323	15238586310	602	24	E12	2014	20	3	2026-06-30 15:30:14.440812	2026-06-30 16:04:59.130736	2026-06-30 15:30:14.417352	\N	\N	\N	\N	4200003195202606308924862181	\N	2026-06-30 15:30:47.064928	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816bz5qUV3jcjZcEuRMHFH44	\N
1476	20260702103004600615	15082976378	614	24	E24	5689	20	3	2026-07-02 10:30:04.996297	2026-07-02 11:17:30.365658	2026-07-02 10:30:04.9735	\N	\N	\N	\N	4200003102202607023272523584	\N	2026-07-02 10:30:21.002289	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2PocIcfNQ4WGD1NSHqtUbx0	
1514	20260702143544071556	13037508763	652	24	E62	1123	20	3	2026-07-02 14:35:44.398435	2026-07-02 15:42:05.27532	2026-07-02 14:35:44.377649	\N	\N	\N	\N	4200003169202607028076885757	\N	2026-07-02 14:36:05.657055	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81wO1786IWNXq1FDGLhLNzFs	
550	20260630170632583423	13667618419	526	16	B32	1234	20	4	2026-06-30 17:06:32.680209	2026-06-30 18:01:54.880741	2026-06-30 17:06:32.658578	\N	\N	\N	\N	4200003222202606308558391939	50301907932026063088068532403	2026-06-30 17:06:55.328244	2026-06-30 18:20:03.547609	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
541	20260630144750539670	17837383155	595	24	E5	1111	20	3	2026-06-30 14:47:50.589861	2026-06-30 15:53:14.208293	2026-06-30 14:47:50.569696	\N	\N	\N	\N	4200003222202606307073662743	\N	2026-06-30 14:48:09.042125	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA819WcGgl_cqgsG8_eviSMIC4	\N
545	20260630152451000570	15836435632	599	24	E9	1128	20	4	2026-06-30 15:24:51.048001	2026-06-30 16:09:27.308745	2026-06-30 15:24:51.027615	\N	\N	\N	\N	4200003117202606305680864882	\N	2026-06-30 15:25:19.229084	2026-06-30 17:26:27.645257	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA817pPlLyzrGVF3-hC7nUqcmM	\N
551	20260630171440638549	17726689234	495	16	B1	1234	20	4	2026-06-30 17:14:40.953679	2026-06-30 18:01:14.416481	2026-06-30 17:14:40.926802	\N	\N	\N	\N	4200003194202606303961998936	50301607892026063088905827155	2026-06-30 17:15:14.066993	2026-06-30 18:18:41.678075	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
556	20260630184408267234	17726689234	501	16	B7	1234	20	4	2026-06-30 18:44:08.337573	2026-06-30 18:45:23.614578	2026-06-30 18:44:08.333052	\N	\N	\N	\N	4200003127202606301108384981	50302107702026063045282922691	2026-06-30 18:44:45.936285	2026-06-30 19:50:31.358649	1	1	none	20	N	Y	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
591	20260701115838902322	15798651828	714	27	12	1215	20	3	2026-07-01 11:58:38.977152	2026-07-01 12:46:20.422248	2026-07-01 11:58:38.973983	\N	\N	\N	\N	4200003216202607018730917634	\N	2026-07-01 11:58:58.958829	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81zv-1BW57sCu570qx28bQgA	
19	20260613084316775983	13667618419	8	1	8	1234	20	4	2026-06-13 08:43:16.360938	\N	2026-06-13 00:43:16	\N	\N	\N	\N	MOCK20260613084317461012	\N	2026-06-13 08:43:17.926972	2026-07-01 14:35:28.816357	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
555	20260630180349917874	17726689234	500	16	B6	1234	20	4	2026-06-30 18:03:49.221853	2026-06-30 18:04:46.043121	2026-06-30 18:03:49.216679	\N	\N	\N	\N	4200003195202606307167196149	50302907982026063000954853964	2026-06-30 18:04:04.46539	2026-06-30 18:18:50.742941	2	1	none	20	N	Y	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
553	20260630180308393971	17726689234	497	16	B3	1234	20	4	2026-06-30 18:03:08.846984	2026-06-30 18:04:49.5678	2026-06-30 18:03:08.84262	\N	\N	\N	\N	4200003166202606301245248017	50301707692026063008618973650	2026-06-30 18:03:26.071888	2026-06-30 18:18:45.677994	3	1	none	20	N	Y	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
20	20260613084722495070	13667618419	9	1	9	1234	20	4	2026-06-13 08:47:22.984184	\N	2026-06-13 00:47:22	\N	\N	\N	\N	MOCK20260613084724403496	\N	2026-06-13 08:47:24.553551	2026-07-01 14:35:28.816357	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
21	20260613084812016560	18996093393	10	1	10	1234	20	4	2026-06-13 08:48:12.982301	\N	2026-06-13 00:48:12	\N	\N	\N	\N	MOCK20260613084814527585	\N	2026-06-13 08:48:14.541599	2026-07-01 14:35:28.816357	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
22	20260613084905903310	18996093393	11	1	11	1234	20	4	2026-06-13 08:49:05.895363	\N	2026-06-13 00:49:05	\N	\N	\N	\N	MOCK20260613084907298375	\N	2026-06-13 08:49:07.467623	2026-07-01 14:35:28.816357	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
23	20260613085201409181	18996093393	12	1	12	1234	20	4	2026-06-13 08:52:01.526147	\N	2026-06-13 00:52:01	\N	\N	\N	\N	MOCK20260613085203062507	\N	2026-06-13 08:52:03.085261	2026-07-01 14:35:28.816357	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
24	20260613092059472982	13667618419	1	1	1	1234	20	4	2026-06-13 09:20:59.159071	\N	2026-06-13 01:20:59	\N	\N	\N	\N	MOCK20260613092100550571	\N	2026-06-13 09:21:00.710869	2026-07-01 14:35:28.816357	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
26	20260613103608102085	13667618419	3	1	3	1234	20	4	2026-06-13 10:36:08.034442	2026-06-20 07:45:34	2026-06-13 02:36:08	\N	\N	\N	\N	MOCK20260613103609423697	\N	2026-06-13 10:36:09.620615	2026-07-01 14:35:28.816357	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
27	20260613103836064964	13667618419	4	1	4	1234	20	4	2026-06-13 10:38:36.153748	2026-06-20 07:45:34	2026-06-13 02:38:36	\N	\N	\N	\N	MOCK20260613103837623027	\N	2026-06-13 10:38:37.746003	2026-07-01 14:35:28.816357	3	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
31	20260613110035310163	13667618419	7	1	7	1245	20	4	2026-06-13 11:00:35.50103	2026-06-20 07:45:34	2026-06-13 03:00:35	\N	\N	\N	\N	MOCK20260613110037508854	\N	2026-06-13 11:00:37.0886	2026-07-01 14:35:28.816357	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
558	20260630185425159147	17726689234	503	16	B9	1234	20	4	2026-06-30 18:54:25.129048	2026-06-30 18:56:02.171276	2026-06-30 18:54:25.125252	\N	\N	\N	\N	4200003110202606309731825407	50300707802026063096662335272	2026-06-30 18:55:37.177167	2026-06-30 19:50:35.233245	3	1	none	20	N	Y	\N	\N	\N	\N	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
569	20260701084052491507	17838863123	611	24	E21	5858	20	3	2026-07-01 08:40:52.996737	2026-07-01 13:33:42.598876	2026-07-01 08:40:52.992032	\N	\N	\N	\N	4200003142202607013866834431	\N	2026-07-01 08:41:16.453537	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA814e5qmXK53w6jTxGFCQvrMo	
589	20260701115824636294	19165928949	622	24	E32	2580	20	3	2026-07-01 11:58:24.483001	2026-07-01 12:35:19.706301	2026-07-01 11:58:24.477541	\N	\N	\N	\N	4200003214202607013994112347	\N	2026-07-01 11:58:41.2676	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81zIpOyNSHnd_FrJiX9XLyMA	
1455	20260702092715633641	18530272656	593	24	E3	2656	20	4	2026-07-02 09:27:15.602718	2026-07-02 10:46:09	2026-07-02 09:27:15.599477	\N	\N	\N	\N	4200003215202607028342275591	\N	2026-07-02 09:27:35.305436	2026-07-02 10:46:11.906311	2	1	refunded	20	N	\N	\N	\N	\N	2026-07-02 10:46:09	2026-07-02 10:46:09	oWrA816oaku14e9dBVLjDIMnnfX8	
1478	20260702103318265226	18260768573	706	27	D4	8573	20	3	2026-07-02 10:33:18.596201	2026-07-02 11:49:13.48526	2026-07-02 10:33:18.592406	\N	\N	\N	\N	4200003184202607026485766840	\N	2026-07-02 10:33:38.389758	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816Cp9pI4S2Z4a357GgTeImc	
1477	20260702103315015792	18237036782	615	24	E25	6782	20	3	2026-07-02 10:33:15.411942	2026-07-02 11:16:08.886142	2026-07-02 10:33:15.408244	\N	\N	\N	\N	4200003182202607027488155699	\N	2026-07-02 10:33:37.58701	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81_LWtK9aJ8SZef2ODkoIZrc	
1457	20260702092747248696	15695672792	597	24	E7	7777	20	3	2026-07-02 09:27:47.258158	2026-07-02 10:32:09.11778	2026-07-02 09:27:47.253568	\N	\N	\N	\N	4200003145202607027289014830	\N	2026-07-02 09:28:18.535237	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA817KtvSu6zXKQJJUqYJb9UTg	
1453	20260702092711765736	19840015972	747	27	D45	9999	20	5	2026-07-02 09:27:11.547069	\N	2026-07-02 09:27:11.543281	\N	\N	\N	\N	\N	\N	\N	\N	2	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA818KJlRo33yjDQXZUXyc1SA8	
1452	20260702092709666775	18836568219	746	27	D44	1012	20	4	2026-07-02 09:27:09.531179	2026-07-02 11:09:22.586076	2026-07-02 09:27:09.527049	\N	\N	\N	\N	4200003214202607021322537295	\N	2026-07-02 09:27:46.943401	2026-07-02 11:22:43.104223	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA811XkchsEFE3FOiVex5RHtZA	
1459	20260702092840429581	18736838325	599	24	E9	3698	20	5	2026-07-02 09:28:40.689411	\N	2026-07-02 09:28:40.686127	\N	\N	\N	\N	\N	\N	\N	\N	5	0	none	0	N	\N	\N	\N	\N	\N	\N	oWrA81wGkKUTMb3SpY4-FDmVsEwQ	
1458	20260702092830764645	17627072353	749	27	D47	2353	20	3	2026-07-02 09:28:30.776133	2026-07-02 10:28:02.839115	2026-07-02 09:28:30.772742	\N	\N	\N	\N	4200003142202607026841596755	\N	2026-07-02 09:28:48.745031	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2M3LzSrgB2-BYQJKN1dQ5U8	
1456	20260702092734180783	19149247152	595	24	E5	1125	20	3	2026-07-02 09:27:34.734827	2026-07-02 10:31:11.315761	2026-07-02 09:27:34.731203	\N	\N	\N	\N	4200003143202607022377096081	\N	2026-07-02 09:27:57.744065	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816FYQPXOeLqf4Jf17S8y3V4	
1460	20260702092841308699	18736838325	601	24	E11	3698	20	3	2026-07-02 09:28:41.608467	2026-07-02 11:54:08.064088	2026-07-02 09:28:41.60425	\N	\N	\N	\N	4200003168202607022555926853	\N	2026-07-02 09:29:01.762963	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81wGkKUTMb3SpY4-FDmVsEwQ	
1454	20260702092712724404	19840015972	748	27	D46	9999	20	3	2026-07-02 09:27:12.616414	2026-07-02 10:44:35.910863	2026-07-02 09:27:12.612801	\N	\N	\N	\N	4200003137202607029661406106	\N	2026-07-02 09:27:38.332236	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA818KJlRo33yjDQXZUXyc1SA8	
1515	20260702143734679789	17739015172	654	24	E64	5172	20	3	2026-07-02 14:37:34.450925	2026-07-02 15:32:44.355216	2026-07-02 14:37:34.433576	\N	\N	\N	\N	4200003205202607025979262909	\N	2026-07-02 14:37:52.714709	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816i6Sh2fGUYosFrRUlooqU4	
1543	20260702155329081576	19913817011	724	27	D22	0000	20	4	2026-07-02 15:53:29.045267	2026-07-02 16:16:03.092494	2026-07-02 15:53:29.041089	\N	\N	\N	\N	4200003148202607025766640415	\N	2026-07-02 15:54:11.636697	2026-07-02 16:42:56.138398	5	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA812nZV4AU4uKQLkUP2jOojkg	
592	20260701115843896819	15054012361	715	27	13	0000	20	4	2026-07-01 11:58:43.423569	2026-07-01 13:04:53.691973	2026-07-01 11:58:43.42004	\N	\N	\N	\N	4200003137202607013217034258	\N	2026-07-01 11:58:56.693293	2026-07-02 18:57:03.559505	1	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oWrA815CE4K5rUqMmftCAJTm1S30	
1520	20260702143914147229	15690868029	714	27	D12	5658	20	3	2026-07-02 14:39:14.148521	2026-07-02 14:52:49.203725	2026-07-02 14:39:14.144749	\N	\N	\N	\N	4200003124202607025377126337	\N	2026-07-02 14:40:00.255571	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA818JXY2ke-_WwcrdF-38BRyE	
1518	20260702143856371695	19037881852	643	24	E53	0000	20	3	2026-07-02 14:38:56.49862	2026-07-02 15:34:14.815568	2026-07-02 14:38:56.494761	\N	\N	\N	\N	4200003111202607023230866108	\N	2026-07-02 14:39:15.670355	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA813XY9444KQ-jha8DDs9QkJM	
1519	20260702143900147067	15836704325	644	24	E54	0088	20	3	2026-07-02 14:39:00.388316	2026-07-02 15:35:58.553366	2026-07-02 14:39:00.384717	\N	\N	\N	\N	4200003116202607026732020493	\N	2026-07-02 14:39:19.48444	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA811dZeSPnohPZAUJrsoSyVCk	
1516	20260702143754225919	15737005525	713	27	D11	1023	20	3	2026-07-02 14:37:54.175837	2026-07-02 15:41:18.18303	2026-07-02 14:37:54.157882	\N	\N	\N	\N	4200003180202607026961272077	\N	2026-07-02 14:38:10.81557	\N	2	1	none	20	N	\N	\N	\N	\N	\N	\N	oLhbm2NF1iiboWasqwEiXBWviqQc	
1544	20260702155503957573	16692633387	605	24	E15	2001	20	3	2026-07-02 15:55:03.140951	2026-07-02 16:18:13.635629	2026-07-02 15:55:03.137274	\N	\N	\N	\N	4200003219202607029594762557	\N	2026-07-02 15:55:28.135389	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA81z4E1a6VqllQU0uvYd8zzwk	
1464	20260702093614692304	18513686701	703	27	D1	0000	20	3	2026-07-02 09:36:14.341773	2026-07-02 11:06:24.345044	2026-07-02 09:36:14.322197	\N	\N	\N	\N	4200003102202607024879212246	\N	2026-07-02 09:36:31.639489	\N	3	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA815kB7bWZbwC9RHh3L3qZF6g	
1483	20260702105727455044	15238586310	618	24	E28	1234	20	3	2026-07-02 10:57:27.146029	2026-07-02 11:18:25.895387	2026-07-02 10:57:27.142339	\N	\N	\N	\N	4200003205202607026118780016	\N	2026-07-02 10:57:52.265459	\N	1	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA816bz5qUV3jcjZcEuRMHFH44	
1525	20260702145538688668	15690868029	591	24	E1	5658	20	3	2026-07-02 14:55:38.803145	2026-07-02 15:37:55.298668	2026-07-02 14:55:38.799604	\N	\N	\N	\N	4200003143202607024093099296	\N	2026-07-02 14:56:22.998023	\N	5	1	none	20	N	\N	\N	\N	\N	\N	\N	oWrA818JXY2ke-_WwcrdF-38BRyE	
1547	20260702161750709323	13667618419	514	16	B20	1234	20	4	2026-07-02 16:17:50.91156	2026-07-02 16:18:37.609537	2026-07-02 16:17:50.90768	\N	\N	\N	\N	4200003130202607020210345700	\N	2026-07-02 16:18:07.179107	2026-07-02 23:24:56.268624	2	1	refunded	20	N	\N	\N	\N	\N	\N	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	
\.


--
-- Data for Name: payment_channels; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.payment_channels (id, name, channel_type, mch_id, api_key, app_id, app_secret, cert_name, extra_config, is_active, weight, daily_limit, total_amount, total_count, last_used_at, created_at, rotation_index, cert_serial_no) FROM stdin;
3	微信支付-商户3	wechat	1746577840	lichengju0904LICHENGJU0904libp98	wxd85204d0ec930d46	e2f27e35864226bf2668643b27f149d9	1746577840	\N	1	1	0	2540	127	2026-07-02 21:55:20.108945	2026-06-12 07:00:31	0	21623753D8FD8C3B4112CC04409397ADA7F1B15A
5	微信支付-商户4	wechat	1747572495	lichengju0904LICHENGJU0904libaip	wxd85204d0ec930d46	552e27fa9a260a6640bf6983bd3470f5	1747572495	\N	1	1	0	1540	85	2026-07-02 22:04:09.255405	2026-06-30 08:15:38.051917	0	62E70B19EA3A009D9293DF05CCDDECD516170DDF
1	微信支付-主商户	wechat	1113658351	lichengju0904LICHENGJU0904libp98	wxd85204d0ec930d46	e2f27e35864226bf2668643b27f149d9	apiclient	\N	1	1	0	2500	125	2026-07-02 22:05:48.57693	2026-06-12 07:00:31	0	39B1456463F2857B9B1F762C2D10D7B104E008FD
2	微信支付-商户2	wechat	1745738973	lichengju0904LICHENGJU0904libp98	wxd85204d0ec930d46	e2f27e35864226bf2668643b27f149d9	1745738973	\N	1	1	0	2520	127	2026-07-02 16:18:07.186979	2026-06-12 07:00:31	0	280C9268D8D09D8ECAF32D552CF5B7BA72D2F737
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.payments (id, order_id, type, amount, transaction_id, status, created_at, refund_transaction_id) FROM stdin;
1	3	1	20	MOCK20260612123731687721	1	2026-06-12 04:37:31	\N
2	4	1	20	MOCK20260612124112354956	1	2026-06-12 04:41:12	\N
3	5	1	20	MOCK20260612125239933782	1	2026-06-12 04:52:39	\N
4	5	2	20	\N	1	2026-06-12 04:52:39	MOCK_R20260612125239053174
5	6	1	20	MOCK20260612125721052779	1	2026-06-12 04:57:21	\N
6	8	1	20	MOCK20260612125806736595	1	2026-06-12 04:58:06	\N
7	8	2	20	\N	1	2026-06-12 04:58:06	MOCK_R20260612125806149070
8	9	1	20	MOCK20260612130727077299	1	2026-06-12 05:07:27	\N
9	9	2	20	\N	1	2026-06-12 05:07:27	MOCK_R20260612130727819069
10	14	1	20	MOCK20260612220412535185	1	2026-06-12 14:04:12	\N
11	15	1	20	MOCK20260612220648303668	1	2026-06-12 14:06:48	\N
12	16	1	20	MOCK20260612221715620901	1	2026-06-12 14:17:15	\N
13	18	1	20	MOCK20260613071531279605	1	2026-06-12 23:15:31	\N
14	19	1	20	MOCK20260613084317461012	1	2026-06-13 00:43:17	\N
15	20	1	20	MOCK20260613084724403496	1	2026-06-13 00:47:24	\N
16	21	1	20	MOCK20260613084814527585	1	2026-06-13 00:48:14	\N
17	22	1	20	MOCK20260613084907298375	1	2026-06-13 00:49:07	\N
18	23	1	20	MOCK20260613085203062507	1	2026-06-13 00:52:03	\N
19	24	1	20	MOCK20260613092100550571	1	2026-06-13 01:21:00	\N
20	25	1	20	MOCK20260613103519579330	1	2026-06-13 02:35:19	\N
21	26	1	20	MOCK20260613103609423697	1	2026-06-13 02:36:09	\N
22	27	1	20	MOCK20260613103837623027	1	2026-06-13 02:38:37	\N
23	28	1	20	MOCK20260613103958690879	1	2026-06-13 02:39:58	\N
972	1407	1	20	4200003205202607024094312739	1	2026-07-02 07:46:38.00682	\N
25	29	1	20	MOCK20260613105402524401	1	2026-06-13 02:54:02	\N
26	30	1	20	MOCK20260613105457264570	1	2026-06-13 02:54:57	\N
27	31	1	20	MOCK20260613110037508854	1	2026-06-13 03:00:37	\N
28	32	1	20	MOCK20260613110924025926	1	2026-06-13 03:09:24	\N
29	33	1	20	MOCK20260613111341731060	1	2026-06-13 03:13:41	\N
30	34	1	20	MOCK20260613111951029532	1	2026-06-13 03:19:51	\N
31	35	1	20	MOCK20260613112010821772	1	2026-06-13 03:20:10	\N
32	35	2	20	\N	0	2026-06-13 08:54:54	\N
33	74	1	20	MOCK20260615195200058468	1	2026-06-15 11:52:00	\N
34	75	1	20	MOCK20260615212238084163	1	2026-06-15 13:22:38	\N
35	78	1	20	4200003197202606157747962293	1	2026-06-15 14:47:03	\N
36	79	1	20	4200003209202606156654791224	1	2026-06-15 14:51:32	\N
37	81	1	20	4200003196202606163226158236	1	2026-06-16 02:09:38	\N
38	82	1	20	4200003129202606161854087446	1	2026-06-16 02:26:35	\N
39	84	1	20	4200003189202606165694456320	1	2026-06-16 03:26:32	\N
40	87	1	20	4200003131202606165905503583	1	2026-06-16 04:28:08	\N
41	88	1	20	4200003136202606165732011683	1	2026-06-16 04:28:56	\N
42	90	1	20	4200003223202606162762774344	1	2026-06-16 05:10:46	\N
43	92	1	20	4200003125202606166578988744	1	2026-06-16 06:43:56	\N
44	93	1	20	4200003187202606163240242798	1	2026-06-16 06:45:04	\N
45	94	1	20	4200003203202606160572494080	1	2026-06-16 07:47:24	\N
46	95	1	20	4200003201202606160806649078	1	2026-06-16 08:43:11	\N
47	98	1	20	4200003214202606163984242235	1	2026-06-16 08:56:36	\N
48	101	1	20	4200003211202606161176191397	1	2026-06-16 09:21:57	\N
49	103	1	20	4200003197202606160258458376	1	2026-06-16 12:05:03	\N
50	124	1	20	4200003134202606202313414267	1	2026-06-20 06:38:00	\N
51	124	1	20	4200003134202606202313414267	1	2026-06-20 06:38:31	\N
52	125	1	20	4200003130202606207192208715	1	2026-06-20 07:00:09	\N
53	125	1	20	4200003130202606207192208715	1	2026-06-20 07:00:39	\N
54	126	1	20	4200003214202606203948138371	1	2026-06-20 07:49:10	\N
55	127	1	20	4200003197202606204893669758	1	2026-06-20 07:49:45	\N
56	125	2	20	4200003130202606207192208715	1	2026-06-20 15:56:06.615305	RF20260620155606125
57	124	2	20	4200003134202606202313414267	1	2026-06-20 15:56:10.453777	RF20260620155610124
58	98	2	20	4200003214202606163984242235	1	2026-06-20 17:06:24.13429	RF2026062017062498
59	95	2	20	4200003201202606160806649078	1	2026-06-20 17:09:56.176641	RF2026062017095695
60	94	2	20	4200003203202606160572494080	1	2026-06-20 17:13:56.780917	RF2026062017135694
61	126	2	20	4200003214202606203948138371	1	2026-06-20 17:38:22.569721	RF20260620173821126
62	136	1	20	4200003185202606216413763246	1	2026-06-21 02:01:18	\N
63	138	1	20	4200003215202606211382457072	1	2026-06-21 02:02:57	\N
64	136	2	20	\N	1	2026-06-21 05:48:05	MOCK_R202606211348054318
65	160	1	20	4200003112202606227000683871	1	2026-06-21 23:51:10	\N
66	160	2	20	\N	1	2026-06-22 00:08:44	MOCK_R202606220808448368
67	162	1	20	4200003187202606221169857264	1	2026-06-22 00:59:23	\N
68	162	2	20	\N	1	2026-06-22 00:59:51	MOCK_R202606220859510289
69	163	1	20	4200003207202606223015137996	1	2026-06-22 02:45:24	\N
70	1	2	20	\N	0	2026-06-22 02:58:48	\N
71	1	2	20	\N	0	2026-06-22 03:02:45	\N
72	163	2	20	\N	1	2026-06-22 03:13:11	MOCK_R202606221113118916
73	164	1	20	4200003161202606220715893776	1	2026-06-22 03:45:56	\N
74	164	2	20	\N	1	2026-06-22 03:47:39	MOCK_R202606221147394386
75	165	1	20	4200003190202606223203070588	1	2026-06-22 04:29:23	\N
76	127	2	20	4200003197202606204893669758	1	2026-06-22 17:07:00.18928	RF20260622170659127
77	125	2	20	4200003130202606207192208715	1	2026-06-22 17:34:41.632235	RF20260622173440125
78	167	1	20	4200003213202606228028335181	1	2026-06-22 09:40:59	\N
79	169	1	20	4200003161202606224316828891	1	2026-06-22 10:11:29	\N
80	169	2	20	\N	1	2026-06-22 11:00:19	MOCK_R202606221900190931
81	171	1	20	4200003134202606238092863920	1	2026-06-23 13:46:08	\N
82	171	2	20	\N	1	2026-06-23 13:50:43	MOCK_R202606232150434694
83	172	1	20	4200003205202606239399871354	1	2026-06-23 14:42:29	\N
84	173	1	20	4200003167202606239067117617	1	2026-06-23 15:08:26	\N
85	175	1	20	4200003131202606234724155894	1	2026-06-23 15:10:06	\N
86	176	1	20	4200003183202606237930294670	1	2026-06-23 15:10:25	\N
87	177	1	20	4200003111202606235388301444	1	2026-06-23 15:21:41	\N
88	178	1	20	4200003131202606234306287373	1	2026-06-23 15:22:27	\N
89	177	2	20	\N	1	2026-06-23 15:54:23	MOCK_R202606232354236405
90	180	1	20	4200003186202606245075059432	1	2026-06-23 16:10:24	\N
91	184	1	20	4200003156202606240131921142	1	2026-06-23 22:24:17	\N
92	176	2	20	\N	1	2026-06-23 22:27:19	MOCK_R202606240627196147
93	185	1	20	4200003208202606240871033738	1	2026-06-23 22:42:08	\N
94	175	2	20	\N	1	2026-06-23 23:02:58	MOCK_R202606240702589758
95	186	1	20	4200003187202606241549677511	1	2026-06-23 23:03:56	\N
96	187	1	20	4200003211202606245418929050	1	2026-06-23 23:28:08	\N
97	188	1	20	4200003179202606249375880551	1	2026-06-23 23:47:21	\N
98	189	1	20	4200003141202606247314158381	1	2026-06-23 23:48:53	\N
99	190	1	20	4200003202202606247319480008	1	2026-06-24 00:07:55	\N
100	189	2	20	\N	1	2026-06-24 01:20:47	MOCK_R202606240920470170
101	191	1	20	4200003203202606248887967052	1	2026-06-24 02:25:47	\N
102	191	2	20	\N	1	2026-06-24 02:26:08	MOCK_R202606241026080405
103	193	1	20	4200003118202606243319941721	1	2026-06-24 03:44:11	\N
104	193	2	20	\N	1	2026-06-24 03:45:03	MOCK_R202606241145033822
105	194	1	20	4200003148202606249425682380	1	2026-06-24 03:46:09	\N
106	194	2	20	\N	1	2026-06-24 03:47:04	MOCK_R202606241147049804
107	190	2	20	4200003202202606247319480008	1	2026-06-24 11:58:40.028901	RF20260624115839190
108	195	1	20	4200003136202606242171328386	1	2026-06-24 06:32:58	\N
109	195	1	20	4200003136202606242171328386	1	2026-06-24 06:32:58	\N
110	195	2	20	\N	1	2026-06-24 06:34:57	MOCK_R20260624143457962311
111	196	1	20	4200003184202606249304133409	1	2026-06-24 07:37:45	\N
112	194	2	20	4200003148202606249425682380	1	2026-06-24 19:10:58.366656	RF20260624191057194
113	196	2	20	\N	0	2026-06-24 12:08:58	\N
114	198	1	20	4200003188202606240188305829	1	2026-06-24 14:37:50	\N
115	198	2	20	\N	0	2026-06-24 14:39:50	\N
116	275	1	20	4200003196202606259252043903	1	2026-06-25 09:24:58	\N
117	276	1	20	4200003215202606251844643887	1	2026-06-25 09:39:59	\N
118	277	1	20	4200003212202606259109040544	1	2026-06-25 09:47:12	\N
119	277	1	20	4200003212202606259109040544	1	2026-06-25 09:48:42	\N
120	277	2	20	\N	0	2026-06-25 09:49:11	\N
121	277	1	20	4200003212202606259109040544	1	2026-06-25 09:51:20	\N
122	278	1	20	4200003221202606256483320125	1	2026-06-25 10:54:43	\N
123	283	1	20	4200003128202606256100234318	1	2026-06-25 13:00:38	\N
124	284	1	20	4200003188202606258522730680	1	2026-06-25 13:07:45	\N
125	284	1	20	4200003188202606258522730680	1	2026-06-25 13:09:15	\N
126	285	1	20	4200003182202606254736104552	1	2026-06-25 13:44:08	\N
127	286	1	20	4200003217202606258317286550	1	2026-06-25 13:48:53	\N
128	287	1	20	4200003131202606253826643798	1	2026-06-25 14:00:02	\N
129	288	1	20	4200003136202606253757337202	1	2026-06-25 14:04:53	\N
130	289	1	20	4200003206202606258412608378	1	2026-06-25 14:13:01	\N
131	290	1	20	4200003128202606253899404960	1	2026-06-25 14:37:16	\N
132	291	1	20	4200003142202606255874904089	1	2026-06-25 14:43:18	\N
133	292	1	20	4200003111202606255715225042	1	2026-06-25 14:48:06	\N
134	295	1	20	\N	1	2026-06-25 15:34:23	\N
135	293	1	20	4200003185202606254397243023	1	2026-06-25 15:36:25	\N
136	296	1	20	\N	1	2026-06-25 15:41:41	\N
137	294	1	20	4200003191202606257942699219	1	2026-06-25 15:44:24	\N
138	297	1	20	\N	1	2026-06-25 15:47:15	\N
139	298	1	20	\N	1	2026-06-25 15:48:02	\N
140	299	1	20	\N	1	2026-06-25 15:50:39	\N
141	300	1	20	\N	1	2026-06-25 15:52:25	\N
142	301	1	20	4200003126202606266486005168	1	2026-06-25 22:26:00	\N
143	302	1	20	4200003206202606266399413240	1	2026-06-25 22:54:48	\N
144	302	1	20	4200003206202606266399413240	1	2026-06-25 22:56:19	\N
145	303	1	20	4200003184202606262064245079	1	2026-06-25 23:04:32	\N
146	303	1	20	4200003184202606262064245079	1	2026-06-25 23:06:32	\N
147	306	1	20	4200003222202606267015269936	1	2026-06-25 23:09:11	\N
148	306	1	20	4200003222202606267015269936	1	2026-06-25 23:10:42	\N
149	306	1	20	4200003222202606267015269936	1	2026-06-25 23:10:42	\N
150	307	1	20	4200003135202606260982950090	1	2026-06-25 23:31:20	\N
151	310	1	20	4200003125202606267155536409	1	2026-06-26 01:27:18	\N
152	311	1	20	4200003129202606262955618549	1	2026-06-26 01:33:28	\N
153	311	1	20	4200003129202606262955618549	1	2026-06-26 01:34:58	\N
154	313	1	20	4200003188202606261236674981	1	2026-06-26 01:38:11	\N
155	313	1	20	4200003188202606261236674981	1	2026-06-26 01:39:42	\N
156	314	1	20	4200003186202606263086244068	1	2026-06-26 01:42:30	\N
157	315	1	20	4200003184202606264338045728	1	2026-06-26 01:46:21	\N
158	316	1	20	4200003183202606260475366817	1	2026-06-26 02:53:39	\N
159	317	1	20	4200003204202606269502378651	1	2026-06-26 05:15:47	\N
160	318	1	20	4200003189202606260554928901	1	2026-06-26 05:57:38	\N
161	326	1	20	4200003196202606264025106289	1	2026-06-26 07:15:59	\N
162	330	1	20	4200003208202606261431066067	1	2026-06-26 07:47:09	\N
163	332	1	20	4200003214202606261349170060	1	2026-06-26 08:58:37	\N
164	332	1	20	4200003214202606261349170060	1	2026-06-26 17:28:40.670006	\N
165	328	1	20	4200003223202606261012234681	1	2026-06-26 17:34:14.734917	\N
166	347	1	20	4200003178202606268143428277	1	2026-06-26 19:53:03.020549	\N
167	352	1	20	4200003125202606264648421174	1	2026-06-26 20:35:02.285683	\N
168	353	1	20	4200003195202606264695707051	1	2026-06-26 20:39:21.484571	\N
169	358	1	20	4200003203202606266721579288	1	2026-06-26 21:11:38.333582	\N
968	572	2	20	4200003177202607014903359735	1	2026-07-01 17:16:53.675677	RF20260701171652572
171	359	1	20	4200003190202606262178436345	1	2026-06-26 21:14:06.669444	\N
970	570	2	20	4200003171202607018665847991	1	2026-07-01 18:31:38.435634	RF20260701183137570
977	1415	1	20	4200003128202607028245438250	1	2026-07-02 07:51:08.908346	\N
978	1416	2	20	4200003185202607023665818129	1	2026-07-02 07:56:46.054196	\N
175	368	1	20	4200003132202606278136500376	1	2026-06-27 10:05:21.589816	\N
176	373	1	1	4200003189202606278759826892	1	2026-06-27 11:22:27.300618	\N
177	374	1	1	4200003183202606272953018543	1	2026-06-27 11:45:25.220677	\N
178	376	1	20	4200003136202606276068779383	1	2026-06-27 12:30:16.888008	\N
179	376	2	20	4200003136202606276068779383	1	2026-06-27 12:58:36.902548	RF20260627124832376
180	373	2	1	4200003189202606278759826892	1	2026-06-27 13:00:58.079687	RF20260627130057373
181	352	2	20	4200003125202606264648421174	1	2026-06-27 13:01:14.084133	RF20260627130113352
182	347	2	20	4200003178202606268143428277	1	2026-06-27 13:08:25.746961	RF20260627130824347
183	379	1	20	4200003209202606279977784591	1	2026-06-27 15:54:39.07598	\N
184	380	1	20	4200003186202606272613703359	1	2026-06-27 16:01:17.944934	\N
185	381	1	20	4200003194202606274482878253	1	2026-06-27 16:06:33.755489	\N
186	382	1	20	4200003222202606276645933201	1	2026-06-27 16:11:33.378261	\N
187	384	1	20	4200003137202606271203499467	1	2026-06-27 16:38:26.497389	\N
188	385	1	1	4200003215202606279493063491	1	2026-06-27 18:02:24.751033	\N
189	386	1	1	4200003131202606271749527663	1	2026-06-27 18:04:23.731391	\N
190	390	1	20	4200003179202606284370748705	1	2026-06-28 07:50:38.541754	\N
191	391	1	1	4200003213202606286027761813	1	2026-06-28 08:30:08.558633	\N
192	393	1	1	4200003127202606285009377611	1	2026-06-28 08:35:13.934019	\N
193	396	1	20	4200003183202606281049040918	1	2026-06-28 08:41:27.715242	\N
194	397	1	20	4200003133202606282333152255	1	2026-06-28 08:46:21.723308	\N
195	399	1	20	4200003177202606285617651946	1	2026-06-28 09:34:39.675548	\N
196	400	1	20	4200003191202606283617596483	1	2026-06-28 09:37:42.629482	\N
197	401	1	20	4200003205202606284880898631	1	2026-06-28 09:45:59.444138	\N
198	405	1	20	4200003187202606285994990390	1	2026-06-28 14:52:23.292359	\N
199	407	1	20	4200003223202606288663233889	1	2026-06-28 15:23:20.131006	\N
200	408	1	20	4200003133202606283862175972	1	2026-06-28 15:30:18.624103	\N
980	1420	2	20	4200003109202607028904338697	1	2026-07-02 08:04:04.18451	\N
982	1419	1	20	4200003098202607021414688092	1	2026-07-02 08:04:11.754806	\N
983	1421	2	20	4200003125202607026801522001	1	2026-07-02 08:04:37.347861	\N
984	1422	1	20	4200003222202607021077370828	1	2026-07-02 08:05:44.034272	\N
985	1423	1	20	4200003112202607026161337973	1	2026-07-02 08:08:32.892406	\N
986	1425	2	20	4200003121202607029879350091	1	2026-07-02 08:11:49.495721	\N
987	1426	2	20	4200003223202607020958305631	1	2026-07-02 08:15:01.834349	\N
988	1427	1	20	4200003183202607022098103977	1	2026-07-02 08:16:18.112572	\N
989	1428	2	20	4200003172202607027299271319	1	2026-07-02 08:16:47.047392	\N
991	1429	2	20	4200003121202607023061991751	1	2026-07-02 08:17:16.142713	\N
992	1430	2	20	4200003207202607022849662371	1	2026-07-02 08:17:55.149546	\N
993	1431	1	20	4200003135202607020917459955	1	2026-07-02 08:18:25.323554	\N
994	1432	2	20	4200003121202607022143839361	1	2026-07-02 08:23:59.332289	\N
995	1434	1	20	4200003144202607020899239706	1	2026-07-02 08:32:49.683249	\N
996	1436	1	20	4200003216202607024064491950	1	2026-07-02 08:33:14.142504	\N
997	1435	1	20	4200003134202607026403183912	1	2026-07-02 08:33:17.336439	\N
998	1437	2	20	4200003183202607022876371781	1	2026-07-02 08:34:13.577836	\N
999	1438	2	20	4200003207202607025773122788	1	2026-07-02 08:34:15.640035	\N
1001	1439	1	20	4200003145202607024483210716	1	2026-07-02 08:34:45.038337	\N
1002	1440	1	20	4200003151202607029237071811	1	2026-07-02 08:36:05.600027	\N
225	493	2	20	4200003174202606308573605856	1	2026-06-30 11:24:42.160669	RF20260630112441493
1003	1441	2	20	4200003134202607025605887297	1	2026-07-02 08:36:51.83297	\N
227	494	2	20	4200003131202606308786195009	1	2026-06-30 11:38:12.111092	RF20260630113811494
1004	1442	2	20	4200003211202607027976588887	1	2026-07-02 08:42:45.842603	\N
1005	1443	1	20	4200003124202607027557818764	1	2026-07-02 08:45:01.03476	\N
1006	1444	2	20	4200003124202607025302592093	1	2026-07-02 08:45:30.133952	\N
1009	1447	1	20	4200003201202607027770748026	1	2026-07-02 08:48:20.764676	\N
1013	1451	2	20	4200003191202607029964163717	1	2026-07-02 09:14:32.371727	\N
1015	1455	2	20	4200003215202607028342275591	1	2026-07-02 09:27:35.305108	\N
1016	1454	1	20	4200003137202607029661406106	1	2026-07-02 09:27:38.332458	\N
1017	1452	1	20	4200003214202607021322537295	1	2026-07-02 09:27:46.94363	\N
1018	1456	1	20	4200003143202607022377096081	1	2026-07-02 09:27:57.744269	\N
1019	1457	1	20	4200003145202607027289014830	1	2026-07-02 09:28:18.535404	\N
1020	1458	2	20	4200003142202607026841596755	1	2026-07-02 09:28:48.744614	\N
1021	1460	2	20	4200003168202607022555926853	1	2026-07-02 09:29:01.74513	\N
1024	1462	1	20	4200003208202607029573246727	1	2026-07-02 09:34:34.267597	\N
1027	1463	2	20	4200003168202607025204765058	1	2026-07-02 09:36:36.446248	\N
1029	1443	2	20	4200003124202607027557818764	1	2026-07-02 10:00:37.699955	RF202607021000361443
1030	1465	2	20	4200003145202607025153502260	1	2026-07-02 10:01:40.284311	\N
1031	1467	1	20	4200003190202607028099219979	1	2026-07-02 10:04:12.717849	\N
1033	1470	2	20	4200003158202607029573672800	1	2026-07-02 10:15:34.612812	\N
1035	1471	1	20	4200003149202607028930188965	1	2026-07-02 10:17:50.476335	\N
201	412	2	20	4200003198202606291966260716	1	2026-06-29 18:58:05.315308	\N
202	413	2	20	4200003134202606295998962135	1	2026-06-29 21:26:52.834635	\N
203	422	2	20	4200003196202606294886056707	1	2026-06-29 22:51:26.699427	\N
204	424	2	20	4200003199202606299595869587	1	2026-06-29 22:52:47.230947	\N
257	509	2	20	4200003189202606303949941723	1	2026-06-30 14:46:28.27256	RF20260630144627509
261	512	2	20	4200003149202606301063935560	1	2026-06-30 15:09:01.125273	RF20260630150900512
205	432	2	20	4200003185202606302618664886	1	2026-06-30 07:08:08.498714	\N
206	436	2	20	4200003119202606306901998225	1	2026-06-30 07:11:20.883493	\N
207	438	2	20	4200003196202606302480741718	1	2026-06-30 07:28:54.288154	\N
208	438	2	20	4200003196202606302480741718	1	2026-06-30 07:28:54.438848	\N
209	440	2	20	4200003126202606304942694629	1	2026-06-30 07:50:37.421378	\N
210	441	2	20	4200003102202606301301964997	1	2026-06-30 07:51:52.930567	\N
211	454	2	20	4200003183202606303659442815	1	2026-06-30 09:04:02.318598	\N
212	457	2	20	4200003186202606300691410477	1	2026-06-30 09:11:19.737468	\N
213	458	2	20	4200003097202606307976765838	1	2026-06-30 09:13:28.184242	\N
214	461	2	20	4200003185202606305579509474	1	2026-06-30 09:30:39.755877	\N
215	461	2	20	4200003185202606305579509474	1	2026-06-30 09:30:39.947542	\N
216	469	2	20	4200003213202606301295336829	1	2026-06-30 09:39:23.520247	\N
217	470	2	20	4200003173202606305670319510	1	2026-06-30 09:49:43.240687	\N
218	481	2	20	4200003188202606309691633192	1	2026-06-30 09:54:35.033376	\N
219	481	2	20	4200003188202606309691633192	1	2026-06-30 09:54:35.340922	\N
220	484	2	20	4200003224202606309624402648	1	2026-06-30 10:15:35.262354	\N
221	487	2	20	4200003106202606308927643382	1	2026-06-30 10:20:03.524165	\N
222	488	2	20	4200003186202606300773799142	1	2026-06-30 10:54:40.858873	\N
223	492	2	20	4200003130202606306918520781	1	2026-06-30 11:04:39.110611	\N
224	493	2	20	4200003174202606308573605856	1	2026-06-30 11:18:17.91693	\N
226	494	2	20	4200003131202606308786195009	1	2026-06-30 11:26:59.0125	\N
228	496	2	20	4200003210202606300113915182	1	2026-06-30 11:40:00.921451	\N
229	497	2	20	4200003121202606303979181027	1	2026-06-30 11:45:16.979502	\N
230	498	2	20	4200003130202606309674975458	1	2026-06-30 12:04:52.582203	\N
231	500	2	20	4200003190202606303089652659	1	2026-06-30 12:23:42.549994	\N
232	501	2	20	4200003115202606303234817522	1	2026-06-30 12:38:27.234265	\N
233	506	2	20	4200003190202606306991859861	1	2026-06-30 12:40:01.283078	\N
234	503	2	20	4200003197202606308771166775	1	2026-06-30 12:40:01.370824	\N
235	505	2	20	4200003204202606306642224931	1	2026-06-30 12:40:07.351634	\N
236	507	2	20	4200003223202606301431470228	1	2026-06-30 12:40:15.974819	\N
237	511	2	20	4200003197202606302682250482	1	2026-06-30 12:40:30.916278	\N
238	509	2	20	4200003189202606303949941723	1	2026-06-30 12:40:50.157881	\N
239	512	2	20	4200003149202606301063935560	1	2026-06-30 12:42:00.6596	\N
240	514	2	20	4200003224202606306671084085	1	2026-06-30 12:51:45.820534	\N
241	514	2	20	4200003224202606306671084085	1	2026-06-30 12:51:46.013587	\N
242	516	2	20	4200003151202606305421787597	1	2026-06-30 12:52:31.08996	\N
243	517	2	20	4200003218202606304060814654	1	2026-06-30 13:04:54.464525	\N
244	519	2	20	4200003138202606302528916179	1	2026-06-30 13:05:24.693581	\N
245	521	2	20	4200003097202606302709695392	1	2026-06-30 13:13:16.352066	\N
246	523	2	20	4200003128202606309427246633	1	2026-06-30 13:29:47.107098	\N
247	524	2	20	4200003135202606306343380379	1	2026-06-30 13:31:26.664399	\N
248	526	2	20	4200003147202606302705451991	1	2026-06-30 13:34:33.280636	\N
249	530	2	20	4200003194202606305055023900	1	2026-06-30 13:46:20.422411	\N
250	528	2	20	4200003180202606305224957902	1	2026-06-30 13:46:23.954144	\N
251	532	2	20	4200003223202606307199431243	1	2026-06-30 13:49:06.172293	\N
252	533	2	20	4200003107202606306060143584	1	2026-06-30 14:01:19.934189	\N
253	535	2	20	4200003178202606309902143709	1	2026-06-30 14:15:36.907132	\N
254	537	2	20	4200003211202606304706104835	1	2026-06-30 14:16:30.087529	\N
255	538	2	20	4200003131202606303988984290	1	2026-06-30 14:16:50.133669	\N
256	539	2	20	4200003115202606301960636307	1	2026-06-30 14:18:37.078243	\N
258	541	2	20	4200003222202606307073662743	1	2026-06-30 14:48:09.042358	\N
259	543	2	20	4200003178202606304648003361	1	2026-06-30 14:53:12.629742	\N
260	543	2	20	4200003178202606304648003361	1	2026-06-30 14:53:12.79136	\N
262	545	2	20	4200003117202606305680864882	1	2026-06-30 15:25:19.229295	\N
263	546	2	20	4200003183202606304945740720	1	2026-06-30 15:27:44.656072	\N
264	547	2	20	4200003195202606308924862181	1	2026-06-30 15:30:47.06444	\N
265	549	2	20	4200003165202606304574377209	1	2026-06-30 15:51:36.239668	\N
266	519	2	20	4200003138202606302528916179	1	2026-06-30 16:50:52.842004	RF20260630165051519
267	550	1	20	4200003222202606308558391939	1	2026-06-30 17:06:55.328442	\N
268	537	2	20	4200003211202606304706104835	1	2026-06-30 17:09:33.58124	RF20260630170932537
269	521	2	20	4200003097202606302709695392	1	2026-06-30 17:12:19.662631	RF20260630171218521
270	551	1	20	4200003194202606303961998936	1	2026-06-30 17:15:14.067188	\N
271	545	2	20	4200003117202606305680864882	1	2026-06-30 17:26:28.528735	RF20260630172627545
272	553	1	20	4200003166202606301245248017	1	2026-06-30 18:03:26.072108	\N
273	555	1	20	4200003195202606307167196149	1	2026-06-30 18:04:04.46551	\N
274	556	2	20	4200003127202606301108384981	1	2026-06-30 18:44:45.78393	\N
275	556	1	20	4200003127202606301108384981	1	2026-06-30 18:44:45.93648	\N
276	558	2	20	4200003110202606309731825407	1	2026-06-30 18:55:37.176824	\N
277	562	1	20	4200003214202607019490189977	1	2026-07-01 07:55:48.439684	\N
278	564	1	20	4200003176202607019207023760	1	2026-07-01 07:59:46.861243	\N
279	565	2	20	4200003118202607014815002149	1	2026-07-01 08:03:09.599874	\N
280	514	2	20	4200003224202606306671084085	1	2026-07-01 08:10:46.494076	RF20260701081045514
281	566	1	20	4200003184202607016775152766	1	2026-07-01 08:33:15.269591	\N
282	567	2	20	4200003207202607016860589133	1	2026-07-01 08:34:20.712975	\N
283	569	1	20	4200003142202607013866834431	1	2026-07-01 08:41:16.453739	\N
284	570	2	20	4200003171202607018665847991	1	2026-07-01 08:53:52.596585	\N
285	572	2	20	4200003177202607014903359735	1	2026-07-01 09:05:25.810047	\N
286	572	1	20	4200003177202607014903359735	1	2026-07-01 09:05:25.901061	\N
287	539	2	20	4200003115202606301960636307	1	2026-07-01 10:16:23.441801	RF20260701101622539
288	469	2	20	4200003213202606301295336829	1	2026-07-01 10:18:16.783969	RF20260701101816469
289	457	2	20	4200003186202606300691410477	1	2026-07-01 10:18:20.389875	RF20260701101819457
290	454	2	20	4200003183202606303659442815	1	2026-07-01 10:18:27.220785	RF20260701101826454
291	412	2	20	4200003198202606291966260716	1	2026-07-01 10:18:30.588564	RF20260701101829412
292	391	2	1	4200003213202606286027761813	1	2026-07-01 10:18:34.296336	RF20260701101833391
293	385	2	1	4200003215202606279493063491	1	2026-07-01 10:18:37.775775	RF20260701101837385
294	374	2	1	4200003183202606272953018543	1	2026-07-01 10:18:44.113541	RF20260701101843374
295	359	2	20	4200003190202606262178436345	1	2026-07-01 10:18:47.009417	RF20260701101846359
296	358	2	20	4200003203202606266721579288	1	2026-07-01 10:18:50.733862	RF20260701101849358
297	579	1	20	4200003174202607012552503843	1	2026-07-01 11:57:38.830007	\N
298	582	1	20	4200003111202607019568875762	1	2026-07-01 11:57:43.771719	\N
299	583	2	20	4200003150202607010821379177	1	2026-07-01 11:57:44.342858	\N
300	583	1	20	4200003150202607010821379177	1	2026-07-01 11:57:44.512315	\N
301	581	1	20	4200003168202607016957955981	1	2026-07-01 11:57:45.888355	\N
302	584	2	20	4200003160202607013707414179	1	2026-07-01 11:57:46.53896	\N
303	584	1	20	4200003160202607013707414179	1	2026-07-01 11:57:46.614083	\N
304	587	1	20	4200003146202607010349055012	1	2026-07-01 11:58:19.623372	\N
305	589	1	20	4200003214202607013994112347	1	2026-07-01 11:58:41.267803	\N
306	592	1	20	4200003137202607013217034258	1	2026-07-01 11:58:56.693465	\N
307	588	2	20	4200003193202607017798897870	1	2026-07-01 11:58:57.554516	\N
308	591	1	20	4200003216202607018730917634	1	2026-07-01 11:58:58.95903	\N
309	590	2	20	4200003196202607016811623968	1	2026-07-01 11:59:04.200883	\N
310	593	1	20	4200003143202607012889738113	1	2026-07-01 11:59:26.802343	\N
311	597	1	20	4200003112202607017131420267	1	2026-07-01 12:07:21.203791	\N
312	598	1	20	4200003131202607017215309404	1	2026-07-01 12:56:18.519715	\N
313	599	2	20	4200003179202607011727208664	1	2026-07-01 13:07:02.258701	\N
314	601	2	20	4200003120202607016553069160	1	2026-07-01 14:18:28.542924	\N
315	310	2	20	4200003125202606267155536409	1	2026-07-01 14:35:29.790903	RF20260701143528310930
316	311	2	20	4200003129202606262955618549	1	2026-07-01 14:35:30.598832	RF20260701143529311186
317	326	2	20	4200003196202606264025106289	1	2026-07-01 14:35:31.419349	RF20260701143530326162
318	328	2	20	4200003223202606261012234681	1	2026-07-01 14:35:32.209209	RF20260701143531328696
319	330	2	20	4200003208202606261431066067	1	2026-07-01 14:35:33.016794	RF20260701143532330255
320	381	2	20	4200003194202606274482878253	1	2026-07-01 14:37:25.1575	RF20260701143724381760
321	393	2	1	4200003127202606285009377611	1	2026-07-01 14:37:26.227854	RF20260701143725393485
322	380	2	20	4200003186202606272613703359	1	2026-07-01 14:37:27.306911	RF20260701143726380320
323	384	2	20	4200003137202606271203499467	1	2026-07-01 14:37:28.368108	RF20260701143727384269
324	382	2	20	4200003222202606276645933201	1	2026-07-01 14:37:29.376041	RF20260701143728382323
325	399	2	20	4200003177202606285617651946	1	2026-07-01 14:37:30.439862	RF20260701143729399687
326	603	1	20	4200003152202607011502175243	1	2026-07-01 14:54:48.678226	\N
327	604	1	20	4200003208202607016431755364	1	2026-07-01 15:22:52.172331	\N
969	590	2	20	4200003196202607016811623968	1	2026-07-01 17:33:56.970997	RF20260701173355590
971	1407	2	20	4200003205202607024094312739	1	2026-07-02 07:46:37.929955	\N
973	1410	1	20	4200003207202607021980567195	1	2026-07-02 07:46:45.848009	\N
974	1412	1	20	4200003164202607020264045936	1	2026-07-02 07:47:55.860574	\N
975	1413	1	20	4200003167202607023557167923	1	2026-07-02 07:48:20.822455	\N
976	1414	1	20	4200003116202607024798095091	1	2026-07-02 07:49:13.247253	\N
979	1417	2	20	4200003171202607023215871691	1	2026-07-02 08:03:19.647304	\N
981	1420	1	20	4200003109202607028904338697	1	2026-07-02 08:04:04.317374	\N
990	1428	1	20	4200003172202607027299271319	1	2026-07-02 08:16:47.211235	\N
1000	1438	1	20	4200003207202607025773122788	1	2026-07-02 08:34:15.709892	\N
1007	1444	1	20	4200003124202607025302592093	1	2026-07-02 08:45:30.296834	\N
1008	1446	2	20	4200003209202607020002423439	1	2026-07-02 08:48:12.837995	\N
1010	1448	2	20	4200003180202607022018395569	1	2026-07-02 08:56:14.945675	\N
1011	1449	2	20	4200003111202607023388388960	1	2026-07-02 09:00:53.275652	\N
1012	1450	2	20	4200003163202607021765635733	1	2026-07-02 09:08:51.687299	\N
1014	1451	1	20	4200003191202607029964163717	1	2026-07-02 09:14:32.453814	\N
1022	1460	1	20	4200003168202607022555926853	1	2026-07-02 09:29:01.763173	\N
1023	1461	1	20	4200003210202607022932241494	1	2026-07-02 09:30:07.122368	\N
1025	1420	2	20	4200003109202607028904338697	1	2026-07-02 09:36:14.403426	RF202607020936131420
1026	1464	1	20	4200003102202607024879212246	1	2026-07-02 09:36:31.639675	\N
1028	505	2	20	4200003204202606306642224931	1	2026-07-02 09:44:34.080417	RF20260702094433505
1032	1468	1	20	4200003185202607021007608092	1	2026-07-02 10:13:20.316096	\N
1034	1471	2	20	4200003149202607028930188965	1	2026-07-02 10:17:50.461928	\N
1036	1447	2	20	4200003201202607027770748026	1	2026-07-02 10:22:41.896276	RF202607021022411447
1037	1472	2	20	4200003199202607025400708435	1	2026-07-02 10:23:31.665303	\N
1038	1473	1	20	4200003190202607020392026579	1	2026-07-02 10:26:59.15726	\N
1039	1474	2	20	4200003105202607023567622032	1	2026-07-02 10:27:49.577701	\N
1040	1475	1	20	4200003103202607021755216792	1	2026-07-02 10:27:54.571404	\N
1041	1476	2	20	4200003102202607023272523584	1	2026-07-02 10:30:21.001972	\N
1042	1477	2	20	4200003182202607027488155699	1	2026-07-02 10:33:37.586678	\N
1043	1478	1	20	4200003184202607026485766840	1	2026-07-02 10:33:38.389979	\N
1044	1450	2	20	4200003163202607021765635733	1	2026-07-02 10:37:05.097449	RF202607021037041450
1045	1479	2	20	4200003215202607022002773454	1	2026-07-02 10:43:18.500693	\N
1046	1455	2	20	4200003215202607028342275591	1	2026-07-02 10:46:12.712266	RF202607021046111455
1047	1480	1	20	4200003102202607026311960447	1	2026-07-02 10:46:36.211519	\N
1048	1481	2	20	4200003109202607021531885026	1	2026-07-02 10:48:43.86363	\N
1049	1482	2	20	4200003117202607027113909708	1	2026-07-02 10:48:54.408176	\N
1050	1483	2	20	4200003205202607026118780016	1	2026-07-02 10:57:52.23822	\N
1051	1483	1	20	4200003205202607026118780016	1	2026-07-02 10:57:52.265653	\N
1052	1487	2	20	4200003212202607023456875779	1	2026-07-02 10:58:58.619401	\N
1053	1461	2	20	4200003210202607022932241494	1	2026-07-02 11:02:24.207147	RF202607021102231461
1054	1489	2	20	4200003113202607021080319275	1	2026-07-02 11:21:12.839236	\N
1055	1452	2	20	4200003214202607021322537295	1	2026-07-02 11:22:43.936087	RF202607021122431452
1056	1490	2	20	4200003157202607026085128959	1	2026-07-02 11:26:35.608926	\N
1057	1491	1	20	4200003193202607024305570989	1	2026-07-02 11:29:17.460906	\N
1058	1493	2	20	4200003178202607028156695335	1	2026-07-02 11:30:53.633313	\N
1059	1494	2	20	4200003166202607029865162989	1	2026-07-02 11:43:56.069371	\N
1060	1494	1	20	4200003166202607029865162989	1	2026-07-02 11:43:56.246396	\N
1061	1493	2	20	4200003178202607028156695335	1	2026-07-02 11:55:59.453945	RF202607021155581493
1062	1487	2	20	4200003212202607023456875779	1	2026-07-02 12:07:51.502252	RF202607021207501487
1063	1416	2	20	4200003185202607023665818129	1	2026-07-02 12:36:56.969864	RF202607021236561416
1064	1481	2	20	4200003109202607021531885026	1	2026-07-02 12:44:37.822126	RF202607021244361481
1065	1495	2	20	4200003106202607025301030545	1	2026-07-02 12:48:11.304031	\N
1066	1425	2	20	4200003121202607029879350091	1	2026-07-02 12:53:36.335535	RF202607021253351425
1067	1449	2	20	4200003111202607023388388960	1	2026-07-02 13:17:40.078238	RF202607021317391449
1068	1496	1	20	4200003138202607029128063523	1	2026-07-02 13:40:55.969938	\N
1069	1497	1	20	4200003221202607027850051403	1	2026-07-02 13:41:00.334734	\N
1070	1498	1	20	4200003200202607024843596481	1	2026-07-02 13:41:27.050551	\N
1071	1472	2	20	4200003199202607025400708435	1	2026-07-02 13:41:30.653719	RF202607021341291472
1072	1470	2	20	4200003158202607029573672800	1	2026-07-02 13:41:33.991507	RF202607021341331470
1073	1499	2	20	4200003150202607027837612120	1	2026-07-02 13:42:05.39621	\N
1074	1500	1	20	4200003100202607020096329816	1	2026-07-02 13:42:13.40349	\N
1075	1501	2	20	4200003165202607021379068692	1	2026-07-02 13:54:42.46797	\N
1076	1502	2	20	4200003219202607026278961303	1	2026-07-02 14:02:48.816151	\N
1077	1503	2	20	4200003177202607020269594290	1	2026-07-02 14:03:27.455063	\N
1078	1504	1	20	4200003172202607022875337007	1	2026-07-02 14:07:42.984192	\N
1079	1506	1	20	4200003173202607020245488486	1	2026-07-02 14:07:59.925998	\N
1080	1507	2	20	4200003141202607027079386733	1	2026-07-02 14:08:06.763883	\N
1081	1508	2	20	4200003175202607021935154341	1	2026-07-02 14:08:17.050817	\N
1082	1509	1	20	4200003141202607026367937191	1	2026-07-02 14:08:17.11905	\N
1083	1508	1	20	4200003175202607021935154341	1	2026-07-02 14:08:17.208328	\N
1084	1510	2	20	4200003190202607028572185645	1	2026-07-02 14:08:47.455382	\N
1085	1512	2	20	4200003185202607021345853362	1	2026-07-02 14:15:33.548394	\N
1086	1513	2	20	4200003163202607027240900916	1	2026-07-02 14:20:58.572966	\N
1087	1514	1	20	4200003169202607028076885757	1	2026-07-02 14:36:05.657265	\N
1088	1515	1	20	4200003205202607025979262909	1	2026-07-02 14:37:52.714924	\N
1089	1516	1	20	4200003180202607026961272077	1	2026-07-02 14:38:10.815765	\N
1090	1518	2	20	4200003111202607023230866108	1	2026-07-02 14:39:15.669929	\N
1091	1519	2	20	4200003116202607026732020493	1	2026-07-02 14:39:19.271327	\N
1092	1519	1	20	4200003116202607026732020493	1	2026-07-02 14:39:19.484641	\N
1093	1520	1	20	4200003124202607025377126337	1	2026-07-02 14:40:00.255751	\N
1094	1521	2	20	4200003183202607024711759060	1	2026-07-02 14:46:13.761767	\N
1095	1523	1	20	4200003108202607021175010829	1	2026-07-02 14:49:13.925997	\N
1096	1525	2	20	4200003143202607024093099296	1	2026-07-02 14:56:22.997724	\N
1097	1527	2	20	4200003194202607020830242967	1	2026-07-02 15:03:25.652632	\N
1098	1529	2	20	4200003215202607023206734800	1	2026-07-02 15:03:39.925631	\N
1099	1528	2	20	4200003136202607028549904705	1	2026-07-02 15:03:50.661879	\N
1100	1530	1	20	4200003109202607027208938309	1	2026-07-02 15:04:02.595561	\N
1101	1532	2	20	4200003105202607027027012156	1	2026-07-02 15:08:23.463944	\N
1102	1533	2	20	4200003136202607027385860641	1	2026-07-02 15:14:08.117521	\N
1103	1533	1	20	4200003136202607027385860641	1	2026-07-02 15:14:08.223086	\N
1104	1534	1	20	4200003218202607023259112054	1	2026-07-02 15:21:51.293863	\N
1105	1536	2	20	4200003155202607025576943705	1	2026-07-02 15:29:43.760353	\N
1106	1529	2	20	4200003215202607023206734800	1	2026-07-02 15:31:26.037661	RF202607021531251529
1107	1509	2	20	4200003141202607026367937191	1	2026-07-02 15:31:29.445747	RF202607021531281509
1108	1537	1	20	4200003113202607027891324584	1	2026-07-02 15:33:48.374158	\N
1109	1539	2	20	4200003154202607024444863308	1	2026-07-02 15:33:56.576589	\N
1110	1539	1	20	4200003154202607024444863308	1	2026-07-02 15:33:56.782253	\N
1111	1540	1	20	4200003201202607021042795465	1	2026-07-02 15:38:03.579819	\N
1112	1541	2	20	4200003133202607020095979243	1	2026-07-02 15:39:55.612152	\N
1113	1542	2	20	4200003124202607023587875983	1	2026-07-02 15:41:31.281913	\N
1114	1542	1	20	4200003124202607023587875983	1	2026-07-02 15:41:31.434574	\N
1115	1543	1	20	4200003148202607025766640415	1	2026-07-02 15:54:11.636915	\N
1116	1544	2	20	4200003219202607029594762557	1	2026-07-02 15:55:28.135015	\N
1117	1547	2	20	4200003130202607020210345700	1	2026-07-02 16:18:07.17867	\N
1118	1533	2	20	4200003136202607027385860641	1	2026-07-02 16:25:33.460986	RF202607021625321533
1119	1536	2	20	4200003155202607025576943705	1	2026-07-02 16:37:36.677243	RF202607021637351536
1120	1543	2	20	4200003148202607025766640415	1	2026-07-02 16:42:57.065435	RF202607021642561543
1121	592	2	20	4200003137202607013217034258	1	2026-07-02 18:57:04.398172	RF20260702185703592
1122	1497	2	20	4200003221202607027850051403	1	2026-07-02 19:27:09.899536	RF202607021927081497
1123	1549	1	20	4200003150202607023016233942	1	2026-07-02 21:55:20.099991	\N
1124	1437	2	20	4200003183202607022876371781	1	2026-07-02 21:57:46.69325	RF202607022157451437
1125	1551	2	20	4200003180202607028648226753	1	2026-07-02 22:05:48.20735	\N
1126	1551	1	20	4200003180202607028648226753	1	2026-07-02 22:05:48.569427	\N
1127	1547	2	20	4200003130202607020210345700	1	2026-07-02 23:24:57.062932	RF202607022324561547
1128	1549	2	20	4200003150202607023016233942	1	2026-07-02 23:25:01.209275	RF202607022325001549
1129	1551	2	20	4200003180202607028648226753	1	2026-07-02 23:25:04.501194	RF202607022325031551
1130	1446	2	20	4200003209202607020002423439	1	2026-07-03 01:11:46.855058	RF202607030111451446
\.


--
-- Data for Name: pending_lock_cmds; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.pending_lock_cmds (id, device_id, board_no, lock_no, protocol, order_id, created_at, delivered, cabinet_id, slot_id, command, status) FROM stdin;
752	100101	1	1	YBM		2026-06-29 17:58:49.9421	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 17:58:49"}	\N
753	100101	1	1	YBM		2026-06-29 17:58:59.427278	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 17:58:59"}	\N
755	100101	1	1	YBM		2026-06-29 18:01:47.922967	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 18:01:47"}	\N
756	100101	1	1	YBM		2026-06-29 18:02:57.255984	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 18:02:57"}	\N
765	100101	1	4	YBM		2026-06-29 18:32:47.1652	1	\N	\N	{"type": "open_lock", "device_id": "100101", "board_no": 1, "lock_no": 4, "protocol": "YBM"}	\N
767	100100	1	1	YBM		2026-06-29 18:34:55.136809	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 18:34:55"}	\N
768	100100	1	1	YBM		2026-06-29 18:48:00.605753	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 18:48:00"}	\N
769	100101	1	1	YBM	20260629185752358994	2026-06-29 18:58:05.33557	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260629185752358994", "orderId": "20260629185752358994", "timestamp": "2026-06-29 18:58:05"}	\N
771	100100	1	1	YBM		2026-06-29 19:07:16.438059	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 19:07:16"}	\N
774	100100	1	1	YBM		2026-06-29 19:13:08.168097	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 19:13:08"}	\N
775	100100	1	1	YBM		2026-06-29 19:13:19.930529	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 19:13:19"}	\N
777	100100	1	1	YBM		2026-06-29 19:17:15.974371	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 19:17:15"}	\N
779	100100	1	1	YBM		2026-06-29 19:49:48.539559	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 19:49:48"}	\N
780	100100	1	1	YBM		2026-06-29 20:04:23.833055	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 20:04:23"}	\N
781	100100	2	1	YBM		2026-06-29 20:11:47.034832	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 20:11:47"}	\N
782	100100	2	2	YBM		2026-06-29 20:11:49.117073	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 20:11:49"}	\N
786	100100	1	1	YBM		2026-06-29 21:06:15.874013	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:06:15"}	\N
787	100100	1	1	YBM		2026-06-29 21:06:35.170836	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:06:35"}	\N
788	100101	1	1	YBM		2026-06-29 21:17:05.31348	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:17:05"}	\N
789	100100	2	16	YBM	20260629212626345012	2026-06-29 21:26:52.857814	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "20260629212626345012", "orderId": "20260629212626345012", "timestamp": "2026-06-29 21:26:52"}	\N
790	100100	2	16	YBM	413	2026-06-29 21:27:06.073925	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": 413, "orderId": "413", "timestamp": "2026-06-29 21:27:06"}	\N
791	100101	1	1	YBM		2026-06-29 21:41:33.551369	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:41:33"}	\N
795	100100	2	2	YBM		2026-06-29 21:44:10.418469	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:44:10"}	\N
796	100100	2	2	YBM		2026-06-29 21:44:15.147683	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:44:15"}	\N
792	100101	1	1	YBM		2026-06-29 21:42:09.396463	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:42:09"}	\N
793	100101	1	1	YBM		2026-06-29 21:42:39.142927	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:42:39"}	\N
794	100101	1	1	YBM		2026-06-29 21:43:24.712002	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:43:24"}	\N
797	100100	2	2	YBM		2026-06-29 21:44:23.169926	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:44:23"}	\N
798	100101	1	1	YBM		2026-06-29 21:45:20.155706	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:45:20"}	\N
799	100101	1	1	YBM		2026-06-29 21:45:36.33112	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:45:36"}	\N
800	100101	1	1	YBM		2026-06-29 21:46:10.72505	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:46:10"}	\N
802	100100	2	2	YBM		2026-06-29 21:46:24.69516	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:46:24"}	\N
801	100100	1	10	YBM		2026-06-29 21:46:22.708857	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:46:22"}	\N
803	100101	1	1	YBM		2026-06-29 21:46:50.304061	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:46:50"}	\N
804	100101	1	1	YBM		2026-06-29 21:47:01.328915	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:47:01"}	\N
805	100101	1	1	YBM		2026-06-29 21:47:54.091569	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:47:54"}	\N
806	100101	1	1	YBM		2026-06-29 21:48:14.641273	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:48:14"}	\N
807	100101	1	1	YBM		2026-06-29 21:49:09.386899	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:49:09"}	\N
808	100101	1	1	YBM		2026-06-29 21:50:59.653998	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 21:50:59"}	\N
809	100100	1	9	YBM	20260629225052014226	2026-06-29 22:51:26.719145	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260629225052014226", "orderId": "20260629225052014226", "timestamp": "2026-06-29 22:51:26"}	\N
810	100100	1	9	YBM	422	2026-06-29 22:51:38.248415	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": 422, "orderId": "422", "timestamp": "2026-06-29 22:51:38"}	\N
811	100100	1	11	YBM	20260629225224739911	2026-06-29 22:52:47.249755	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260629225224739911", "orderId": "20260629225224739911", "timestamp": "2026-06-29 22:52:47"}	\N
812	100100	1	11	YBM	424	2026-06-29 22:53:13.964346	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 424, "orderId": "424", "timestamp": "2026-06-29 22:53:13"}	\N
813	100100	1	10	YBM	423	2026-06-29 22:53:18.071095	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": 423, "orderId": "423", "timestamp": "2026-06-29 22:53:18"}	\N
814	100100	1	9	YBM	422	2026-06-29 22:53:22.649846	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": 422, "orderId": "422", "timestamp": "2026-06-29 22:53:22"}	\N
815	100100	1	11	YBM	424	2026-06-29 22:53:27.502555	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 424, "orderId": "424", "timestamp": "2026-06-29 22:53:27"}	\N
816	100100	1	11	YBM		2026-06-29 22:54:37.306212	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-29 22:54:37"}	\N
817	100100	1	11	YBM	424	2026-06-29 22:58:40.796864	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 424, "orderId": "424", "timestamp": "2026-06-29 22:58:40"}	\N
818	100100	1	11	YBM	424	2026-06-29 23:00:00.810008	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 424, "orderId": "424", "timestamp": "2026-06-29 23:00:00"}	\N
819	100100	1	9	YBM	422	2026-06-29 23:00:06.66189	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": 422, "orderId": "422", "timestamp": "2026-06-29 23:00:06"}	\N
820	100100	1	11	YBM	424	2026-06-29 23:01:38.604056	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 424, "orderId": "424", "timestamp": "2026-06-29 23:01:38"}	\N
825	100100	1	11	YBM		2026-06-30 06:47:59.306262	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 06:47:59"}	\N
835	100100	1	11	YBM		2026-06-30 07:02:42.829024	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:02:42"}	\N
836	100100	1	1	YBM		2026-06-30 07:02:49.033764	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:02:49"}	\N
837	100100	1	3	YBM		2026-06-30 07:02:57.265125	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:02:57"}	\N
859	100100	2	9	YBM	20260630072823856658	2026-06-30 07:28:54.442782	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630072823856658", "orderId": "20260630072823856658", "timestamp": "2026-06-30 07:28:54"}	\N
842	100100	1	2	YBM		2026-06-30 07:04:22.011135	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:04:22"}	\N
843	100100	1	3	YBM		2026-06-30 07:04:22.380583	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:04:22"}	\N
844	100100	1	4	YBM		2026-06-30 07:04:28.977258	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 07:04:28"}	\N
845	100100	1	4	YBM	test_070635_4	2026-06-30 07:06:35.122525	1	\N	\N	{"type": "open_lock", "device_id": "100100", "board_no": 1, "lock_no": 4, "protocol": "YBM", "order_id": "test_070635_4"}	\N
846	100100	1	1	YBM	test_070635_1	2026-06-30 07:06:35.125698	1	\N	\N	{"type": "open_lock", "device_id": "100100", "board_no": 1, "lock_no": 1, "protocol": "YBM", "order_id": "test_070635_1"}	\N
847	100100	1	3	YBM	test_070635_3	2026-06-30 07:06:35.129172	1	\N	\N	{"type": "open_lock", "device_id": "100100", "board_no": 1, "lock_no": 3, "protocol": "YBM", "order_id": "test_070635_3"}	\N
848	100100	1	5	YBM	test_070635_5	2026-06-30 07:06:35.137562	1	\N	\N	{"type": "open_lock", "device_id": "100100", "board_no": 1, "lock_no": 5, "protocol": "YBM", "order_id": "test_070635_5"}	\N
849	100100	1	2	YBM	test_070635_2	2026-06-30 07:06:35.136148	1	\N	\N	{"type": "open_lock", "device_id": "100100", "board_no": 1, "lock_no": 2, "protocol": "YBM", "order_id": "test_070635_2"}	\N
850	100100	2	3	YBM	20260630070731985915	2026-06-30 07:08:08.528208	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260630070731985915", "orderId": "20260630070731985915", "timestamp": "2026-06-30 07:08:08"}	\N
851	100100	2	3	YBM	432	2026-06-30 07:08:14.819079	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": 432, "orderId": "432", "timestamp": "2026-06-30 07:08:14"}	\N
852	100100	2	3	YBM	432	2026-06-30 07:08:18.466375	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": 432, "orderId": "432", "timestamp": "2026-06-30 07:08:18"}	\N
853	100100	2	7	YBM	20260630071102574249	2026-06-30 07:11:20.901474	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630071102574249", "orderId": "20260630071102574249", "timestamp": "2026-06-30 07:11:20"}	\N
858	100100	2	9	YBM	20260630072823856658	2026-06-30 07:28:54.317847	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630072823856658", "orderId": "20260630072823856658", "timestamp": "2026-06-30 07:28:54"}	\N
862	101001	1	\N	YBM		2026-06-30 07:40:37.386314	0	15	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.49", "version_code": 169, "force": true, "file_md5": "996dc013243b5066d87ee61508639839"}	pending
863	123456	1	\N	YBM		2026-06-30 07:40:37.409165	0	8	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.49", "version_code": 169, "force": true, "file_md5": "996dc013243b5066d87ee61508639839"}	pending
860	100100	1	\N	YBM		2026-06-30 07:40:37.34113	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.49", "version_code": 169, "force": true, "file_md5": "996dc013243b5066d87ee61508639839"}	pending
864	100100	2	11	YBM	20260630075016897517	2026-06-30 07:50:37.435786	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630075016897517", "orderId": "20260630075016897517", "timestamp": "2026-06-30 07:50:37"}	\N
865	100100	2	11	YBM	440	2026-06-30 07:50:43.17386	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 440, "orderId": "440", "timestamp": "2026-06-30 07:50:43"}	\N
866	100100	2	12	YBM	20260630075135072321	2026-06-30 07:51:52.952597	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630075135072321", "orderId": "20260630075135072321", "timestamp": "2026-06-30 07:51:52"}	\N
861	100101	1	\N	YBM		2026-06-30 07:40:37.359481	1	24	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.49", "version_code": 169, "force": true, "file_md5": "996dc013243b5066d87ee61508639839"}	pending
867	100101	1	1	YBM		2026-06-30 08:45:45.971947	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 08:45:45"}	\N
868	100101	1	8	YBM	20260630090354376183	2026-06-30 09:04:02.326195	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260630090354376183", "orderId": "20260630090354376183", "timestamp": "2026-06-30 09:04:02"}	\N
869	100101	1	9	YBM	20260630091101819765	2026-06-30 09:11:19.743701	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630091101819765", "orderId": "20260630091101819765", "timestamp": "2026-06-30 09:11:19"}	\N
870	100100	1	5	YBM	20260630091211403812	2026-06-30 09:13:28.187945	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260630091211403812", "orderId": "20260630091211403812", "timestamp": "2026-06-30 09:13:28"}	\N
871	123456	1	\N	YBM		2026-06-30 09:27:15.44261	0	8	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
872	101001	1	\N	YBM		2026-06-30 09:27:15.44261	0	15	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
875	1001002	1	\N	YBM		2026-06-30 09:27:15.44261	0	26	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
874	100101	1	\N	YBM		2026-06-30 09:27:15.44261	1	24	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
873	100100	1	\N	YBM		2026-06-30 09:27:15.44261	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
876	100101	1	11	YBM	20260630093015601516	2026-06-30 09:30:39.777412	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630093015601516", "orderId": "20260630093015601516", "timestamp": "2026-06-30 09:30:39"}	\N
877	100101	1	11	YBM	20260630093015601516	2026-06-30 09:30:39.954142	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630093015601516", "orderId": "20260630093015601516", "timestamp": "2026-06-30 09:30:39"}	\N
878	100101	1	15	YBM	20260630093905337250	2026-06-30 09:39:23.526127	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260630093905337250", "orderId": "20260630093905337250", "timestamp": "2026-06-30 09:39:23"}	\N
879	100100	1	12	YBM	20260630094022158852	2026-06-30 09:49:43.264043	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630094022158852", "orderId": "20260630094022158852", "timestamp": "2026-06-30 09:49:43"}	\N
880	100100	1	16	YBM	478	2026-06-30 09:52:45.629938	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": 478, "orderId": "478", "timestamp": "2026-06-30 09:52:45"}	\N
881	100100	1	16	YBM	478	2026-06-30 09:52:48.023677	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": 478, "orderId": "478", "timestamp": "2026-06-30 09:52:48"}	\N
882	100100	1	12	YBM	470	2026-06-30 09:53:20.665141	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": 470, "orderId": "470", "timestamp": "2026-06-30 09:53:20"}	\N
883	100100	2	2	YBM	20260630095414309240	2026-06-30 09:54:35.056502	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260630095414309240", "orderId": "20260630095414309240", "timestamp": "2026-06-30 09:54:35"}	\N
884	100100	2	2	YBM	20260630095414309240	2026-06-30 09:54:35.34468	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260630095414309240", "orderId": "20260630095414309240", "timestamp": "2026-06-30 09:54:35"}	\N
885	100101	2	7	YBM	20260630101459139734	2026-06-30 10:15:35.270155	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630101459139734", "orderId": "20260630101459139734", "timestamp": "2026-06-30 10:15:35"}	\N
886	100100	2	6	YBM	20260630101943467907	2026-06-30 10:20:03.546293	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260630101943467907", "orderId": "20260630101943467907", "timestamp": "2026-06-30 10:20:03"}	\N
887	100100	2	6	YBM	487	2026-06-30 10:20:08.706746	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": 487, "orderId": "487", "timestamp": "2026-06-30 10:20:08"}	\N
888	100100	2	6	YBM	487	2026-06-30 10:20:17.607213	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": 487, "orderId": "487", "timestamp": "2026-06-30 10:20:17"}	\N
889	100100	2	6	YBM		2026-06-30 10:20:34.089165	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 10:20:34"}	\N
890	100100	2	6	YBM		2026-06-30 10:20:42.448156	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 10:20:42"}	\N
891	100100	2	7	YBM	20260630105405124207	2026-06-30 10:54:40.865163	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630105405124207", "orderId": "20260630105405124207", "timestamp": "2026-06-30 10:54:40"}	\N
892	100100	2	7	YBM	488	2026-06-30 10:54:46.257909	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": 488, "orderId": "488", "timestamp": "2026-06-30 10:54:46"}	\N
893	100100	2	7	YBM	488	2026-06-30 10:54:50.079813	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": 488, "orderId": "488", "timestamp": "2026-06-30 10:54:50"}	\N
894	100100	2	23	YBM	488	2026-06-30 10:57:08.922761	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 23, "lockNo": 23, "protocol": "YBM", "order_id": "488", "orderId": "488", "timestamp": "2026-06-30 10:57:08"}	\N
895	100100	2	23	YBM	488	2026-06-30 10:57:28.788881	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 23, "lockNo": 23, "protocol": "YBM", "order_id": "488", "orderId": "488", "timestamp": "2026-06-30 10:57:28"}	\N
896	100100	2	7	YBM		2026-06-30 10:58:00.371201	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 10:58:00"}	\N
897	100100	2	7	YBM		2026-06-30 10:58:58.872311	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 10:58:58"}	\N
898	100100	2	23	YBM	488	2026-06-30 10:59:54.180046	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 23, "lockNo": 23, "protocol": "YBM", "order_id": "488", "orderId": "488", "timestamp": "2026-06-30 10:59:54"}	\N
899	100100	2	23	YBM	488	2026-06-30 11:00:08.171111	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 23, "lockNo": 23, "protocol": "YBM", "order_id": "488", "orderId": "488", "timestamp": "2026-06-30 11:00:08"}	\N
900	100100	2	11	YBM	20260630110420701345	2026-06-30 11:04:39.115718	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630110420701345", "orderId": "20260630110420701345", "timestamp": "2026-06-30 11:04:39"}	\N
901	100100	2	11	YBM	492	2026-06-30 11:04:44.841468	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": 492, "orderId": "492", "timestamp": "2026-06-30 11:04:44"}	\N
902	100100	2	10	YBM	491	2026-06-30 11:05:24.835614	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": 491, "orderId": "491", "timestamp": "2026-06-30 11:05:24"}	\N
903	100100	2	12	YBM	20260630111758918131	2026-06-30 11:18:17.921932	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630111758918131", "orderId": "20260630111758918131", "timestamp": "2026-06-30 11:18:17"}	\N
904	100100	2	12	YBM	493	2026-06-30 11:18:25.535304	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": 493, "orderId": "493", "timestamp": "2026-06-30 11:18:25"}	\N
905	100101	2	8	YBM	20260630112639381589	2026-06-30 11:26:59.01898	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260630112639381589", "orderId": "20260630112639381589", "timestamp": "2026-06-30 11:26:59"}	\N
906	100101	2	8	YBM	494	2026-06-30 11:27:07.242982	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": 494, "orderId": "494", "timestamp": "2026-06-30 11:27:07"}	\N
907	100101	2	10	YBM	20260630113938731600	2026-06-30 11:40:00.952082	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260630113938731600", "orderId": "20260630113938731600", "timestamp": "2026-06-30 11:40:00"}	\N
908	100100	2	13	YBM	20260630114500326407	2026-06-30 11:45:16.987841	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260630114500326407", "orderId": "20260630114500326407", "timestamp": "2026-06-30 11:45:16"}	\N
909	100100	2	13	YBM	497	2026-06-30 11:49:15.527334	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "497", "orderId": "497", "timestamp": "2026-06-30 11:49:15"}	\N
910	100101	2	11	YBM	20260630120430300084	2026-06-30 12:04:52.593056	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630120430300084", "orderId": "20260630120430300084", "timestamp": "2026-06-30 12:04:52"}	\N
911	100101	2	13	YBM	20260630122321456133	2026-06-30 12:23:42.55809	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260630122321456133", "orderId": "20260630122321456133", "timestamp": "2026-06-30 12:23:42"}	\N
912	100101	2	14	YBM	20260630123806951872	2026-06-30 12:38:27.238237	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260630123806951872", "orderId": "20260630123806951872", "timestamp": "2026-06-30 12:38:27"}	\N
913	100101	3	4	YBM	20260630123939351137	2026-06-30 12:40:01.287511	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260630123939351137", "orderId": "20260630123939351137", "timestamp": "2026-06-30 12:40:01"}	\N
914	100101	3	1	YBM	20260630123932308808	2026-06-30 12:40:01.381319	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260630123932308808", "orderId": "20260630123932308808", "timestamp": "2026-06-30 12:40:01"}	\N
915	100101	3	3	YBM	20260630123936503848	2026-06-30 12:40:07.370917	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260630123936503848", "orderId": "20260630123936503848", "timestamp": "2026-06-30 12:40:07"}	\N
916	100101	3	5	YBM	20260630123952112437	2026-06-30 12:40:15.978863	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260630123952112437", "orderId": "20260630123952112437", "timestamp": "2026-06-30 12:40:15"}	\N
917	100101	3	9	YBM	20260630124010539133	2026-06-30 12:40:30.920291	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630124010539133", "orderId": "20260630124010539133", "timestamp": "2026-06-30 12:40:30"}	\N
918	100101	3	7	YBM	20260630123959529209	2026-06-30 12:40:50.176599	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630123959529209", "orderId": "20260630123959529209", "timestamp": "2026-06-30 12:40:50"}	\N
919	100101	3	10	YBM	20260630124135737562	2026-06-30 12:42:00.663047	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260630124135737562", "orderId": "20260630124135737562", "timestamp": "2026-06-30 12:42:00"}	\N
920	100101	3	12	YBM	20260630125108236602	2026-06-30 12:51:45.839335	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630125108236602", "orderId": "20260630125108236602", "timestamp": "2026-06-30 12:51:45"}	\N
921	100101	3	12	YBM	20260630125108236602	2026-06-30 12:51:46.017535	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630125108236602", "orderId": "20260630125108236602", "timestamp": "2026-06-30 12:51:46"}	\N
922	100101	3	12	YBM	514	2026-06-30 12:52:21.832861	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": 514, "orderId": "514", "timestamp": "2026-06-30 12:52:21"}	\N
923	100101	3	14	YBM	20260630125130451288	2026-06-30 12:52:31.108721	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260630125130451288", "orderId": "20260630125130451288", "timestamp": "2026-06-30 12:52:31"}	\N
924	100101	3	15	YBM	20260630130421202757	2026-06-30 13:04:54.46945	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260630130421202757", "orderId": "20260630130421202757", "timestamp": "2026-06-30 13:04:54"}	\N
925	100101	4	1	YBM	20260630130451524847	2026-06-30 13:05:24.697041	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260630130451524847", "orderId": "20260630130451524847", "timestamp": "2026-06-30 13:05:24"}	\N
926	100101	4	3	YBM	20260630131251511581	2026-06-30 13:13:16.356508	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260630131251511581", "orderId": "20260630131251511581", "timestamp": "2026-06-30 13:13:16"}	\N
927	100101	4	5	YBM	20260630132913118022	2026-06-30 13:29:47.127515	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260630132913118022", "orderId": "20260630132913118022", "timestamp": "2026-06-30 13:29:47"}	\N
928	100101	4	6	YBM	20260630133057596999	2026-06-30 13:31:26.684711	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260630133057596999", "orderId": "20260630133057596999", "timestamp": "2026-06-30 13:31:26"}	\N
929	100101	4	8	YBM	20260630133404595989	2026-06-30 13:34:33.285874	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260630133404595989", "orderId": "20260630133404595989", "timestamp": "2026-06-30 13:34:33"}	\N
930	100100	2	15	YBM	20260630134559767386	2026-06-30 13:46:20.441528	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260630134559767386", "orderId": "20260630134559767386", "timestamp": "2026-06-30 13:46:20"}	\N
931	100101	4	10	YBM	20260630134555889371	2026-06-30 13:46:23.973575	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260630134555889371", "orderId": "20260630134555889371", "timestamp": "2026-06-30 13:46:23"}	\N
932	100100	2	15	YBM	530	2026-06-30 13:46:27.681865	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:46:27"}	\N
933	100100	2	15	YBM	530	2026-06-30 13:46:32.163341	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:46:32"}	\N
934	100100	2	15	YBM	530	2026-06-30 13:46:51.713416	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:46:51"}	\N
935	100100	2	15	YBM	530	2026-06-30 13:46:56.582472	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:46:56"}	\N
936	100101	4	12	YBM	20260630134846640888	2026-06-30 13:49:06.176774	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630134846640888", "orderId": "20260630134846640888", "timestamp": "2026-06-30 13:49:06"}	\N
937	100100	2	15	YBM	530	2026-06-30 13:49:07.503647	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:49:07"}	\N
938	100100	2	15	YBM	530	2026-06-30 13:49:11.791087	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": 530, "orderId": "530", "timestamp": "2026-06-30 13:49:11"}	\N
939	100101	4	13	YBM	20260630140052363155	2026-06-30 14:01:19.938952	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260630140052363155", "orderId": "20260630140052363155", "timestamp": "2026-06-30 14:01:19"}	\N
940	100101	4	15	YBM	20260630141511676928	2026-06-30 14:15:36.912609	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260630141511676928", "orderId": "20260630141511676928", "timestamp": "2026-06-30 14:15:36"}	\N
941	100101	1	1	YBM	20260630141613856704	2026-06-30 14:16:30.091552	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260630141613856704", "orderId": "20260630141613856704", "timestamp": "2026-06-30 14:16:30"}	\N
942	100101	1	2	YBM	20260630141616444325	2026-06-30 14:16:50.137825	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260630141616444325", "orderId": "20260630141616444325", "timestamp": "2026-06-30 14:16:50"}	\N
943	100101	1	3	YBM	20260630141812626447	2026-06-30 14:18:37.098645	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260630141812626447", "orderId": "20260630141812626447", "timestamp": "2026-06-30 14:18:37"}	\N
944	100101	1	5	YBM	20260630144750539670	2026-06-30 14:48:09.046948	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260630144750539670", "orderId": "20260630144750539670", "timestamp": "2026-06-30 14:48:09"}	\N
945	100101	3	12	YBM	514	2026-06-30 14:51:14.795709	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": 514, "orderId": "514", "timestamp": "2026-06-30 14:51:14"}	\N
946	100101	1	7	YBM	20260630145256257792	2026-06-30 14:53:12.649568	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630145256257792", "orderId": "20260630145256257792", "timestamp": "2026-06-30 14:53:12"}	\N
947	100101	1	7	YBM	20260630145256257792	2026-06-30 14:53:12.796791	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630145256257792", "orderId": "20260630145256257792", "timestamp": "2026-06-30 14:53:12"}	\N
948	100101	2	14	YBM		2026-06-30 15:09:22.959856	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-06-30 15:09:22"}	\N
949	100101	1	9	YBM	20260630152451000570	2026-06-30 15:25:19.233486	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630152451000570", "orderId": "20260630152451000570", "timestamp": "2026-06-30 15:25:19"}	\N
950	100101	1	11	YBM	20260630152726665334	2026-06-30 15:27:44.675261	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260630152726665334", "orderId": "20260630152726665334", "timestamp": "2026-06-30 15:27:44"}	\N
951	100101	1	12	YBM	20260630153014147323	2026-06-30 15:30:47.083831	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260630153014147323", "orderId": "20260630153014147323", "timestamp": "2026-06-30 15:30:47"}	\N
952	100101	1	13	YBM	20260630155114892074	2026-06-30 15:51:36.244949	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260630155114892074", "orderId": "20260630155114892074", "timestamp": "2026-06-30 15:51:36"}	\N
953	100101	1	1	YBM	537	2026-06-30 16:56:09.634971	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": 537, "orderId": "537", "timestamp": "2026-06-30 16:56:09"}	\N
954	100100	2	16	YBM	20260630170632583423	2026-06-30 17:06:55.336605	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "20260630170632583423", "orderId": "20260630170632583423", "timestamp": "2026-06-30 17:06:55"}	\N
955	100100	2	16	YBM	550	2026-06-30 17:08:19.488077	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": 550, "orderId": "550", "timestamp": "2026-06-30 17:08:19"}	\N
956	100100	1	1	YBM	20260630171440638549	2026-06-30 17:15:14.077437	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260630171440638549", "orderId": "20260630171440638549", "timestamp": "2026-06-30 17:15:14"}	\N
957	100101	1	13	YBM	549	2026-06-30 17:39:29.157936	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": 549, "orderId": "549", "timestamp": "2026-06-30 17:39:29"}	\N
958	100100	1	3	YBM	20260630180308393971	2026-06-30 18:03:26.08157	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260630180308393971", "orderId": "20260630180308393971", "timestamp": "2026-06-30 18:03:26"}	\N
959	100100	1	6	YBM	20260630180349917874	2026-06-30 18:04:04.46966	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260630180349917874", "orderId": "20260630180349917874", "timestamp": "2026-06-30 18:04:04"}	\N
960	100100	1	\N	YBM		2026-06-30 18:35:05.352038	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
961	100100	1	7	YBM	20260630184408267234	2026-06-30 18:44:45.793995	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630184408267234", "orderId": "20260630184408267234", "timestamp": "2026-06-30 18:44:45"}	\N
962	100100	1	7	YBM	20260630184408267234	2026-06-30 18:44:45.941694	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260630184408267234", "orderId": "20260630184408267234", "timestamp": "2026-06-30 18:44:45"}	\N
963	100100	1	9	YBM	20260630185425159147	2026-06-30 18:55:37.180175	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260630185425159147", "orderId": "20260630185425159147", "timestamp": "2026-06-30 18:55:37"}	\N
964	100100	1	9	YBM	558	2026-06-30 18:55:42.77916	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": 558, "orderId": "558", "timestamp": "2026-06-30 18:55:42"}	\N
965	100101	1	15	YBM	20260701075530128450	2026-07-01 07:55:48.444556	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260701075530128450", "orderId": "20260701075530128450", "timestamp": "2026-07-01 07:55:48"}	\N
1013	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	455	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "slot_number": 9, "slot_label": "9"}	pending
1014	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	456	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "slot_number": 10, "slot_label": "10"}	pending
966	100100	1	1	YBM		2026-07-01 07:58:45.148156	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-07-01 07:58:45"}	\N
967	100100	1	14	YBM	20260701075928784045	2026-07-01 07:59:46.86616	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260701075928784045", "orderId": "20260701075928784045", "timestamp": "2026-07-01 07:59:46"}	\N
968	100100	1	14	YBM	564	2026-07-01 07:59:52.090258	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": 564, "orderId": "564", "timestamp": "2026-07-01 07:59:52"}	\N
969	100101	2	1	YBM	20260701080252681224	2026-07-01 08:03:09.602708	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260701080252681224", "orderId": "20260701080252681224", "timestamp": "2026-07-01 08:03:09"}	\N
970	100101	2	2	YBM	20260701083251034222	2026-07-01 08:33:15.275075	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260701083251034222", "orderId": "20260701083251034222", "timestamp": "2026-07-01 08:33:15"}	\N
971	100101	2	3	YBM	20260701083356818933	2026-07-01 08:34:20.715893	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260701083356818933", "orderId": "20260701083356818933", "timestamp": "2026-07-01 08:34:20"}	\N
972	100101	2	5	YBM	20260701084052491507	2026-07-01 08:41:16.4588	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260701084052491507", "orderId": "20260701084052491507", "timestamp": "2026-07-01 08:41:16"}	\N
973	100101	2	6	YBM	20260701085322762885	2026-07-01 08:53:52.599542	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260701085322762885", "orderId": "20260701085322762885", "timestamp": "2026-07-01 08:53:52"}	\N
974	100101	2	8	YBM	20260701090447589462	2026-07-01 09:05:25.813383	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260701090447589462", "orderId": "20260701090447589462", "timestamp": "2026-07-01 09:05:25"}	\N
975	100101	2	8	YBM	20260701090447589462	2026-07-01 09:05:25.905324	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260701090447589462", "orderId": "20260701090447589462", "timestamp": "2026-07-01 09:05:25"}	\N
976	100103	1	\N	YBM		2026-07-01 09:17:27.260312	1	27	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
977	100103	1	1	YBM		2026-07-01 09:18:20.497981	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-07-01 09:18:20"}	\N
978	100103	3	16	YBM		2026-07-01 09:18:26.655754	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-07-01 09:18:26"}	\N
979	100103	1	2	YBM		2026-07-01 09:20:09.933235	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-07-01 09:20:09"}	\N
980	100101	4	2	YBM	merchant_remote	2026-07-01 09:25:56.189899	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "merchant_remote", "orderId": "merchant_remote", "timestamp": "2026-07-01 09:25:56"}	\N
981	100101	4	1	YBM	merchant_remote	2026-07-01 09:26:23.557283	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "merchant_remote", "orderId": "merchant_remote", "timestamp": "2026-07-01 09:26:23"}	\N
982	100103	1	12	YBM	merchant_remote	2026-07-01 10:49:01.75658	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "merchant_remote", "orderId": "merchant_remote", "timestamp": "2026-07-01 10:49:01"}	\N
983	100100	1	1	YBM	merchant_remote	2026-07-01 10:49:22.327941	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "merchant_remote", "orderId": "merchant_remote", "timestamp": "2026-07-01 10:49:22"}	\N
984	100103	1	3	YBM	20260701115715162390	2026-07-01 11:57:38.835271	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260701115715162390", "orderId": "20260701115715162390", "timestamp": "2026-07-01 11:57:38"}	\N
985	100101	2	13	YBM	20260701115720962016	2026-07-01 11:57:43.775761	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260701115720962016", "orderId": "20260701115720962016", "timestamp": "2026-07-01 11:57:43"}	\N
986	100101	2	14	YBM	20260701115720312297	2026-07-01 11:57:44.345626	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260701115720312297", "orderId": "20260701115720312297", "timestamp": "2026-07-01 11:57:44"}	\N
992	100101	2	16	YBM	20260701115824636294	2026-07-01 11:58:41.271457	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "20260701115824636294", "orderId": "20260701115824636294", "timestamp": "2026-07-01 11:58:41"}	\N
987	100101	2	14	YBM	20260701115720312297	2026-07-01 11:57:44.516204	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260701115720312297", "orderId": "20260701115720312297", "timestamp": "2026-07-01 11:57:44"}	\N
988	100103	1	5	YBM	20260701115720270337	2026-07-01 11:57:45.892138	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260701115720270337", "orderId": "20260701115720270337", "timestamp": "2026-07-01 11:57:45"}	\N
989	100103	1	6	YBM	20260701115727590523	2026-07-01 11:57:46.541603	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260701115727590523", "orderId": "20260701115727590523", "timestamp": "2026-07-01 11:57:46"}	\N
990	100103	1	6	YBM	20260701115727590523	2026-07-01 11:57:46.617715	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260701115727590523", "orderId": "20260701115727590523", "timestamp": "2026-07-01 11:57:46"}	\N
991	100103	1	9	YBM	20260701115757810612	2026-07-01 11:58:19.626704	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260701115757810612", "orderId": "20260701115757810612", "timestamp": "2026-07-01 11:58:19"}	\N
993	100103	1	13	YBM	20260701115843896819	2026-07-01 11:58:56.696942	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260701115843896819", "orderId": "20260701115843896819", "timestamp": "2026-07-01 11:58:56"}	\N
994	100103	1	10	YBM	20260701115813210130	2026-07-01 11:58:57.557368	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260701115813210130", "orderId": "20260701115813210130", "timestamp": "2026-07-01 11:58:57"}	\N
995	100103	1	12	YBM	20260701115838902322	2026-07-01 11:58:58.962172	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260701115838902322", "orderId": "20260701115838902322", "timestamp": "2026-07-01 11:58:58"}	\N
996	100103	1	11	YBM	20260701115835256322	2026-07-01 11:59:04.203559	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260701115835256322", "orderId": "20260701115835256322", "timestamp": "2026-07-01 11:59:04"}	\N
997	100103	1	14	YBM	20260701115900319392	2026-07-01 11:59:26.806514	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260701115900319392", "orderId": "20260701115900319392", "timestamp": "2026-07-01 11:59:26"}	\N
998	100101	3	6	YBM	20260701120639790566	2026-07-01 12:07:21.207911	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260701120639790566", "orderId": "20260701120639790566", "timestamp": "2026-07-01 12:07:21"}	\N
999	100101	3	7	YBM	20260701125600825759	2026-07-01 12:56:18.523741	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260701125600825759", "orderId": "20260701125600825759", "timestamp": "2026-07-01 12:56:18"}	\N
1000	100101	3	8	YBM	20260701130626543594	2026-07-01 13:07:02.261771	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260701130626543594", "orderId": "20260701130626543594", "timestamp": "2026-07-01 13:07:02"}	\N
1001	100101	1	6	YBM	20260701141804957030	2026-07-01 14:18:28.545803	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260701141804957030", "orderId": "20260701141804957030", "timestamp": "2026-07-01 14:18:28"}	\N
1002	100101	3	13	YBM	20260701145427482126	2026-07-01 14:54:48.686441	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260701145427482126", "orderId": "20260701145427482126", "timestamp": "2026-07-01 14:54:48"}	\N
1003	100100	1	4	YBM	20260701152234730339	2026-07-01 15:22:52.177675	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260701152234730339", "orderId": "20260701152234730339", "timestamp": "2026-07-01 15:22:52"}	\N
1004	100100	1	4	YBM	20260701152234730339	2026-07-01 15:22:58.310643	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260701152234730339", "orderId": "20260701152234730339", "timestamp": "2026-07-01 15:22:58"}	\N
1005	100100	1	1	YBM		2026-07-01 18:40:21.796907	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-07-01 18:40:21"}	\N
1006	100100	1	1	YBM		2026-07-01 19:48:46.566641	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-07-01 19:48:46"}	\N
1007	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	448	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "slot_number": 2, "slot_label": "2"}	pending
1008	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	449	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "slot_number": 3, "slot_label": "3"}	pending
1009	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	450	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "slot_number": 4, "slot_label": "4"}	pending
1010	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	451	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "slot_number": 5, "slot_label": "5"}	pending
1011	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	452	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "slot_number": 6, "slot_label": "6"}	pending
1012	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	453	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "slot_number": 7, "slot_label": "7"}	pending
1015	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	457	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "slot_number": 11, "slot_label": "11"}	pending
1016	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	458	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "slot_number": 12, "slot_label": "12"}	pending
1017	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	459	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "slot_number": 13, "slot_label": "13"}	pending
1018	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	460	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "slot_number": 14, "slot_label": "14"}	pending
1019	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	461	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "slot_number": 15, "slot_label": "15"}	pending
1020	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	462	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "slot_number": 16, "slot_label": "16"}	pending
1021	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	447	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "slot_number": 1, "slot_label": "1"}	pending
1022	\N	1	\N	YBM		2026-07-01 23:00:05.801251	0	8	454	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "slot_number": 8, "slot_label": "8"}	pending
1023	100101	4	2	YBM	20260702074556912851	2026-07-02 07:46:37.939435	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260702074556912851", "orderId": "20260702074556912851", "timestamp": "2026-07-02 07:46:37"}	\N
1024	100101	4	2	YBM	20260702074556912851	2026-07-02 07:46:38.011748	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260702074556912851", "orderId": "20260702074556912851", "timestamp": "2026-07-02 07:46:38"}	\N
1025	100101	4	4	YBM	20260702074612869156	2026-07-02 07:46:45.85241	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702074612869156", "orderId": "20260702074612869156", "timestamp": "2026-07-02 07:46:45"}	\N
1026	100101	4	9	YBM	20260702074733928541	2026-07-02 07:47:55.864926	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260702074733928541", "orderId": "20260702074733928541", "timestamp": "2026-07-02 07:47:55"}	\N
1027	100103	2	2	YBM	20260702074750034164	2026-07-02 07:48:20.826259	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260702074750034164", "orderId": "20260702074750034164", "timestamp": "2026-07-02 07:48:20"}	\N
1028	100101	4	11	YBM	20260702074836334811	2026-07-02 07:49:13.250548	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260702074836334811", "orderId": "20260702074836334811", "timestamp": "2026-07-02 07:49:13"}	\N
1029	100103	2	3	YBM	20260702075044906912	2026-07-02 07:51:08.914042	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260702075044906912", "orderId": "20260702075044906912", "timestamp": "2026-07-02 07:51:08"}	\N
1030	100103	2	4	YBM	20260702075630097930	2026-07-02 07:56:46.05711	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702075630097930", "orderId": "20260702075630097930", "timestamp": "2026-07-02 07:56:46"}	\N
1031	100101	4	14	YBM	20260702080225458420	2026-07-02 08:03:19.650805	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260702080225458420", "orderId": "20260702080225458420", "timestamp": "2026-07-02 08:03:19"}	\N
1032	100103	2	7	YBM	20260702080341688802	2026-07-02 08:04:04.187724	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260702080341688802", "orderId": "20260702080341688802", "timestamp": "2026-07-02 08:04:04"}	\N
1033	100103	2	7	YBM	20260702080341688802	2026-07-02 08:04:04.321505	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260702080341688802", "orderId": "20260702080341688802", "timestamp": "2026-07-02 08:04:04"}	\N
1034	100103	2	6	YBM	20260702080341534703	2026-07-02 08:04:11.758655	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260702080341534703", "orderId": "20260702080341534703", "timestamp": "2026-07-02 08:04:11"}	\N
1035	100101	4	16	YBM	20260702080418511793	2026-07-02 08:04:37.350663	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "20260702080418511793", "orderId": "20260702080418511793", "timestamp": "2026-07-02 08:04:37"}	\N
1036	100101	1	8	YBM	20260702080513726588	2026-07-02 08:05:44.038817	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260702080513726588", "orderId": "20260702080513726588", "timestamp": "2026-07-02 08:05:44"}	\N
1037	100101	3	3	YBM	20260702080815398352	2026-07-02 08:08:32.895784	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260702080815398352", "orderId": "20260702080815398352", "timestamp": "2026-07-02 08:08:32"}	\N
1038	100103	2	12	YBM	20260702081123882535	2026-07-02 08:11:49.498739	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702081123882535", "orderId": "20260702081123882535", "timestamp": "2026-07-02 08:11:49"}	\N
1039	100101	3	10	YBM	20260702081438390022	2026-07-02 08:15:01.837665	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260702081438390022", "orderId": "20260702081438390022", "timestamp": "2026-07-02 08:15:01"}	\N
1040	100101	3	12	YBM	20260702081546040373	2026-07-02 08:16:18.122499	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702081546040373", "orderId": "20260702081546040373", "timestamp": "2026-07-02 08:16:18"}	\N
1045	100103	2	14	YBM	20260702081807013160	2026-07-02 08:18:25.32889	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260702081807013160", "orderId": "20260702081807013160", "timestamp": "2026-07-02 08:18:25"}	\N
1047	100103	3	1	YBM	20260702083221633278	2026-07-02 08:32:49.688436	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702083221633278", "orderId": "20260702083221633278", "timestamp": "2026-07-02 08:32:49"}	\N
1048	100101	4	3	YBM	20260702083258247995	2026-07-02 08:33:14.146219	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260702083258247995", "orderId": "20260702083258247995", "timestamp": "2026-07-02 08:33:14"}	\N
1049	100101	4	1	YBM	20260702083242496787	2026-07-02 08:33:17.340326	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702083242496787", "orderId": "20260702083242496787", "timestamp": "2026-07-02 08:33:17"}	\N
1053	100101	4	6	YBM	20260702083423681975	2026-07-02 08:34:45.04217	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260702083423681975", "orderId": "20260702083423681975", "timestamp": "2026-07-02 08:34:45"}	\N
1054	100101	4	9	YBM	20260702074733928541	2026-07-02 08:35:11.66817	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260702074733928541", "orderId": "20260702074733928541", "timestamp": "2026-07-02 08:35:11"}	\N
1055	100101	4	8	YBM	20260702083539933571	2026-07-02 08:36:05.604736	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260702083539933571", "orderId": "20260702083539933571", "timestamp": "2026-07-02 08:36:05"}	\N
1058	100101	4	10	YBM	20260702084440802683	2026-07-02 08:45:01.039199	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260702084440802683", "orderId": "20260702084440802683", "timestamp": "2026-07-02 08:45:01"}	\N
1041	100103	2	13	YBM	20260702081622517982	2026-07-02 08:16:47.050139	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260702081622517982", "orderId": "20260702081622517982", "timestamp": "2026-07-02 08:16:47"}	\N
1042	100103	2	13	YBM	20260702081622517982	2026-07-02 08:16:47.215592	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260702081622517982", "orderId": "20260702081622517982", "timestamp": "2026-07-02 08:16:47"}	\N
1043	100101	3	14	YBM	20260702081651889788	2026-07-02 08:17:16.145099	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260702081651889788", "orderId": "20260702081651889788", "timestamp": "2026-07-02 08:17:16"}	\N
1044	100101	3	15	YBM	20260702081738212190	2026-07-02 08:17:55.152315	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702081738212190", "orderId": "20260702081738212190", "timestamp": "2026-07-02 08:17:55"}	\N
1046	100103	2	15	YBM	20260702082339209075	2026-07-02 08:23:59.334943	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702082339209075", "orderId": "20260702082339209075", "timestamp": "2026-07-02 08:23:59"}	\N
1050	100103	3	2	YBM	20260702083352775935	2026-07-02 08:34:13.580883	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260702083352775935", "orderId": "20260702083352775935", "timestamp": "2026-07-02 08:34:13"}	\N
1051	100101	4	5	YBM	20260702083353472648	2026-07-02 08:34:15.643138	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260702083353472648", "orderId": "20260702083353472648", "timestamp": "2026-07-02 08:34:15"}	\N
1052	100101	4	5	YBM	20260702083353472648	2026-07-02 08:34:15.713177	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260702083353472648", "orderId": "20260702083353472648", "timestamp": "2026-07-02 08:34:15"}	\N
1056	100103	3	3	YBM	20260702083627459366	2026-07-02 08:36:51.83557	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260702083627459366", "orderId": "20260702083627459366", "timestamp": "2026-07-02 08:36:51"}	\N
1057	100103	3	4	YBM	20260702084221943712	2026-07-02 08:42:45.845699	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702084221943712", "orderId": "20260702084221943712", "timestamp": "2026-07-02 08:42:45"}	\N
1059	100101	4	12	YBM	20260702084500628342	2026-07-02 08:45:30.136691	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702084500628342", "orderId": "20260702084500628342", "timestamp": "2026-07-02 08:45:30"}	\N
1060	100101	4	12	YBM	20260702084500628342	2026-07-02 08:45:30.300036	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702084500628342", "orderId": "20260702084500628342", "timestamp": "2026-07-02 08:45:30"}	\N
1061	100103	3	7	YBM	20260702084753583818	2026-07-02 08:48:12.841307	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260702084753583818", "orderId": "20260702084753583818", "timestamp": "2026-07-02 08:48:12"}	\N
1062	100101	4	15	YBM	20260702084803210252	2026-07-02 08:48:20.769165	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702084803210252", "orderId": "20260702084803210252", "timestamp": "2026-07-02 08:48:20"}	\N
1063	100103	3	7	YBM	20260702084753583818	2026-07-02 08:49:47.225894	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260702084753583818", "orderId": "20260702084753583818", "timestamp": "2026-07-02 08:49:47"}	\N
1064	100103	3	9	YBM	20260702085549357029	2026-07-02 08:56:14.948622	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260702085549357029", "orderId": "20260702085549357029", "timestamp": "2026-07-02 08:56:14"}	\N
1065	100101	1	1	YBM	20260702090033429063	2026-07-02 09:00:53.278472	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702090033429063", "orderId": "20260702090033429063", "timestamp": "2026-07-02 09:00:53"}	\N
1066	100101	1	2	YBM	20260702090827849691	2026-07-02 09:08:51.690464	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260702090827849691", "orderId": "20260702090827849691", "timestamp": "2026-07-02 09:08:51"}	\N
1067	100103	3	11	YBM	20260702091414791295	2026-07-02 09:14:32.375022	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260702091414791295", "orderId": "20260702091414791295", "timestamp": "2026-07-02 09:14:32"}	\N
1068	100103	3	11	YBM	20260702091414791295	2026-07-02 09:14:32.457826	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260702091414791295", "orderId": "20260702091414791295", "timestamp": "2026-07-02 09:14:32"}	\N
1069	100101	1	3	YBM	20260702092715633641	2026-07-02 09:27:35.308164	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260702092715633641", "orderId": "20260702092715633641", "timestamp": "2026-07-02 09:27:35"}	\N
1070	100103	3	14	YBM	20260702092712724404	2026-07-02 09:27:38.336248	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260702092712724404", "orderId": "20260702092712724404", "timestamp": "2026-07-02 09:27:38"}	\N
1071	100103	3	12	YBM	20260702092709666775	2026-07-02 09:27:46.948106	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702092709666775", "orderId": "20260702092709666775", "timestamp": "2026-07-02 09:27:46"}	\N
1072	100101	1	5	YBM	20260702092734180783	2026-07-02 09:27:57.748376	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260702092734180783", "orderId": "20260702092734180783", "timestamp": "2026-07-02 09:27:57"}	\N
1073	100101	1	7	YBM	20260702092747248696	2026-07-02 09:28:18.539218	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260702092747248696", "orderId": "20260702092747248696", "timestamp": "2026-07-02 09:28:18"}	\N
1074	100103	3	15	YBM	20260702092830764645	2026-07-02 09:28:48.747897	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702092830764645", "orderId": "20260702092830764645", "timestamp": "2026-07-02 09:28:48"}	\N
1075	100101	1	11	YBM	20260702092841308699	2026-07-02 09:29:01.748222	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260702092841308699", "orderId": "20260702092841308699", "timestamp": "2026-07-02 09:29:01"}	\N
1076	100101	1	11	YBM	20260702092841308699	2026-07-02 09:29:01.768204	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260702092841308699", "orderId": "20260702092841308699", "timestamp": "2026-07-02 09:29:01"}	\N
1077	100101	1	12	YBM	20260702092933837798	2026-07-02 09:30:07.126853	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702092933837798", "orderId": "20260702092933837798", "timestamp": "2026-07-02 09:30:07"}	\N
1078	100103	3	16	YBM	20260702093419009655	2026-07-02 09:34:34.271561	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "20260702093419009655", "orderId": "20260702093419009655", "timestamp": "2026-07-02 09:34:34"}	\N
1079	100103	1	1	YBM	20260702093614692304	2026-07-02 09:36:31.64631	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702093614692304", "orderId": "20260702093614692304", "timestamp": "2026-07-02 09:36:31"}	\N
1080	100101	1	13	YBM	20260702093610225179	2026-07-02 09:36:36.449676	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260702093610225179", "orderId": "20260702093610225179", "timestamp": "2026-07-02 09:36:36"}	\N
1081	100101	1	12	QM	1461	2026-07-02 09:46:01.694483	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "QM", "order_id": "1461", "orderId": "1461", "timestamp": "2026-07-02 09:46:01"}	\N
1082	100101	1	3	QM	1455	2026-07-02 09:47:42.561756	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1455", "orderId": "1455", "timestamp": "2026-07-02 09:47:42"}	\N
1083	100103	3	2	QM	1437	2026-07-02 09:47:57.818924	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 2, "lockNo": 2, "protocol": "QM", "order_id": "1437", "orderId": "1437", "timestamp": "2026-07-02 09:47:57"}	\N
1084	100103	3	4	QM	1442	2026-07-02 09:48:31.25951	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1442", "orderId": "1442", "timestamp": "2026-07-02 09:48:31"}	\N
1085	100103	3	16	QM	1462	2026-07-02 09:49:13.817041	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 16, "lockNo": 16, "protocol": "QM", "order_id": "1462", "orderId": "1462", "timestamp": "2026-07-02 09:49:13"}	\N
1086	100103	1	1	QM	1464	2026-07-02 09:57:05.684841	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1464", "orderId": "1464", "timestamp": "2026-07-02 09:57:05"}	\N
1087	100101	1	3	YBM		2026-07-02 09:59:08.468974	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-07-02 09:59:08"}	\N
1088	100103	2	14	QM	1431	2026-07-02 09:59:24.367706	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 14, "lockNo": 14, "protocol": "QM", "order_id": "1431", "orderId": "1431", "timestamp": "2026-07-02 09:59:24"}	\N
1089	100101	4	4	YBM		2026-07-02 09:59:40.97943	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-07-02 09:59:40"}	\N
1090	100101	4	1	YBM		2026-07-02 09:59:54.218125	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-07-02 09:59:54"}	\N
1091	100103	2	13	QM	1428	2026-07-02 10:00:04.221549	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "protocol": "QM", "order_id": "1428", "orderId": "1428", "timestamp": "2026-07-02 10:00:04"}	\N
1092	100101	4	4	QM	1410	2026-07-02 10:00:04.631257	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1410", "orderId": "1410", "timestamp": "2026-07-02 10:00:04"}	\N
1093	100103	1	2	YBM	20260702100050634764	2026-07-02 10:01:40.286874	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260702100050634764", "orderId": "20260702100050634764", "timestamp": "2026-07-02 10:01:40"}	\N
1094	100101	1	15	YBM	20260702100349927451	2026-07-02 10:04:12.721726	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702100349927451", "orderId": "20260702100349927451", "timestamp": "2026-07-02 10:04:12"}	\N
1095	100103	2	6	QM	1419	2026-07-02 10:05:21.386122	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1419", "orderId": "1419", "timestamp": "2026-07-02 10:05:21"}	\N
1096	100101	4	3	QM	1436	2026-07-02 10:10:01.713628	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1436", "orderId": "1436", "timestamp": "2026-07-02 10:10:01"}	\N
1097	100103	3	9	QM	1448	2026-07-02 10:10:23.699724	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 9, "lockNo": 9, "protocol": "QM", "order_id": "1448", "orderId": "1448", "timestamp": "2026-07-02 10:10:23"}	\N
1098	100101	4	15	QM	1447	2026-07-02 10:11:34.386772	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 15, "lockNo": 15, "protocol": "QM", "order_id": "1447", "orderId": "1447", "timestamp": "2026-07-02 10:11:34"}	\N
1099	100101	2	1	YBM	20260702101247406216	2026-07-02 10:13:20.319709	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702101247406216", "orderId": "20260702101247406216", "timestamp": "2026-07-02 10:13:20"}	\N
1100	100101	2	3	YBM	20260702101512496081	2026-07-02 10:15:34.615453	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260702101512496081", "orderId": "20260702101512496081", "timestamp": "2026-07-02 10:15:34"}	\N
1101	100103	1	3	YBM	20260702101724901386	2026-07-02 10:17:50.465007	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260702101724901386", "orderId": "20260702101724901386", "timestamp": "2026-07-02 10:17:50"}	\N
1102	100103	1	3	YBM	20260702101724901386	2026-07-02 10:17:50.480188	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260702101724901386", "orderId": "20260702101724901386", "timestamp": "2026-07-02 10:17:50"}	\N
1103	100101	1	11	QM	1460	2026-07-02 10:17:50.967727	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1460", "orderId": "1460", "timestamp": "2026-07-02 10:17:50"}	\N
1104	100101	2	3	QM	1470	2026-07-02 10:21:38.334707	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1470", "orderId": "1470", "timestamp": "2026-07-02 10:21:38"}	\N
1105	100101	3	15	QM	1430	2026-07-02 10:22:42.63471	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 15, "lockNo": 15, "protocol": "QM", "order_id": "1430", "orderId": "1430", "timestamp": "2026-07-02 10:22:42"}	\N
1106	100101	2	4	YBM	20260702102316076531	2026-07-02 10:23:31.668696	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702102316076531", "orderId": "20260702102316076531", "timestamp": "2026-07-02 10:23:31"}	\N
1107	100103	3	7	QM	1446	2026-07-02 10:23:44.645818	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1446", "orderId": "1446", "timestamp": "2026-07-02 10:23:44"}	\N
1108	100101	2	5	YBM	20260702102630123341	2026-07-02 10:26:59.162029	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260702102630123341", "orderId": "20260702102630123341", "timestamp": "2026-07-02 10:26:59"}	\N
1109	100103	1	3	QM	1471	2026-07-02 10:27:23.113091	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1471", "orderId": "1471", "timestamp": "2026-07-02 10:27:23"}	\N
1110	100103	1	2	QM	1465	2026-07-02 10:27:41.561017	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "QM", "order_id": "1465", "orderId": "1465", "timestamp": "2026-07-02 10:27:41"}	\N
1111	100101	2	6	YBM	20260702102723971816	2026-07-02 10:27:49.581096	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260702102723971816", "orderId": "20260702102723971816", "timestamp": "2026-07-02 10:27:49"}	\N
1112	100101	2	7	YBM	20260702102735750065	2026-07-02 10:27:54.575154	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260702102735750065", "orderId": "20260702102735750065", "timestamp": "2026-07-02 10:27:54"}	\N
1113	100103	3	15	QM	1458	2026-07-02 10:28:02.845973	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 15, "lockNo": 15, "protocol": "QM", "order_id": "1458", "orderId": "1458", "timestamp": "2026-07-02 10:28:02"}	\N
1114	100101	2	8	YBM	20260702103004600615	2026-07-02 10:30:21.005628	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260702103004600615", "orderId": "20260702103004600615", "timestamp": "2026-07-02 10:30:21"}	\N
1115	100101	2	8	QM	1476	2026-07-02 10:30:50.609981	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1476", "orderId": "1476", "timestamp": "2026-07-02 10:30:50"}	\N
1116	100101	1	5	QM	1456	2026-07-02 10:31:11.321404	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "QM", "order_id": "1456", "orderId": "1456", "timestamp": "2026-07-02 10:31:11"}	\N
1117	100101	1	13	QM	1463	2026-07-02 10:31:24.521044	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "QM", "order_id": "1463", "orderId": "1463", "timestamp": "2026-07-02 10:31:24"}	\N
1118	100101	1	7	QM	1457	2026-07-02 10:32:09.12548	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1457", "orderId": "1457", "timestamp": "2026-07-02 10:32:09"}	\N
1120	100103	1	4	YBM	20260702103318265226	2026-07-02 10:33:38.394223	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702103318265226", "orderId": "20260702103318265226", "timestamp": "2026-07-02 10:33:38"}	\N
1119	100101	2	9	YBM	20260702103315015792	2026-07-02 10:33:37.591327	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260702103315015792", "orderId": "20260702103315015792", "timestamp": "2026-07-02 10:33:37"}	\N
1121	100101	1	2	QM	1450	2026-07-02 10:33:59.894811	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "QM", "order_id": "1450", "orderId": "1450", "timestamp": "2026-07-02 10:33:59"}	\N
1122	100103	1	4	QM	1478	2026-07-02 10:35:02.287931	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1478", "orderId": "1478", "timestamp": "2026-07-02 10:35:02"}	\N
1123	100101	2	7	QM	1475	2026-07-02 10:37:29.521252	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1475", "orderId": "1475", "timestamp": "2026-07-02 10:37:29"}	\N
1124	100103	3	16	QM	1462	2026-07-02 10:39:29.335564	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 16, "lockNo": 16, "protocol": "QM", "order_id": "1462", "orderId": "1462", "timestamp": "2026-07-02 10:39:29"}	\N
1125	100101	2	1	QM	1468	2026-07-02 10:40:48.06212	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1468", "orderId": "1468", "timestamp": "2026-07-02 10:40:48"}	\N
1126	100101	1	15	QM	1467	2026-07-02 10:41:00.74183	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "QM", "order_id": "1467", "orderId": "1467", "timestamp": "2026-07-02 10:41:00"}	\N
1127	100101	2	7	QM	1475	2026-07-02 10:42:04.924138	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1475", "orderId": "1475", "timestamp": "2026-07-02 10:42:04"}	\N
1128	100101	2	10	YBM	20260702104259276956	2026-07-02 10:43:18.5036	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260702104259276956", "orderId": "20260702104259276956", "timestamp": "2026-07-02 10:43:18"}	\N
1129	100103	1	4	QM	1478	2026-07-02 10:44:01.170028	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1478", "orderId": "1478", "timestamp": "2026-07-02 10:44:01"}	\N
1130	100103	3	14	QM	1454	2026-07-02 10:44:35.915964	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 14, "lockNo": 14, "protocol": "QM", "order_id": "1454", "orderId": "1454", "timestamp": "2026-07-02 10:44:35"}	\N
1131	100101	2	11	YBM	20260702104611100936	2026-07-02 10:46:36.215374	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260702104611100936", "orderId": "20260702104611100936", "timestamp": "2026-07-02 10:46:36"}	\N
1132	100103	1	5	YBM	20260702104821797511	2026-07-02 10:48:43.866277	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260702104821797511", "orderId": "20260702104821797511", "timestamp": "2026-07-02 10:48:43"}	\N
1133	100103	1	6	YBM	20260702104834237506	2026-07-02 10:48:54.41072	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260702104834237506", "orderId": "20260702104834237506", "timestamp": "2026-07-02 10:48:54"}	\N
1134	100103	1	6	QM	1482	2026-07-02 10:50:14.446286	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1482", "orderId": "1482", "timestamp": "2026-07-02 10:50:14"}	\N
1135	100101	2	1	QM	1468	2026-07-02 10:51:02.042113	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1468", "orderId": "1468", "timestamp": "2026-07-02 10:51:02"}	\N
1136	100101	2	11	QM	1480	2026-07-02 10:55:15.06318	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1480", "orderId": "1480", "timestamp": "2026-07-02 10:55:15"}	\N
1137	100103	1	2	QM	1465	2026-07-02 10:57:45.938477	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "protocol": "QM", "order_id": "1465", "orderId": "1465", "timestamp": "2026-07-02 10:57:45"}	\N
1138	100101	2	12	YBM	20260702105727455044	2026-07-02 10:57:52.255255	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702105727455044", "orderId": "20260702105727455044", "timestamp": "2026-07-02 10:57:52"}	\N
1139	100101	2	12	YBM	20260702105727455044	2026-07-02 10:57:52.269599	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702105727455044", "orderId": "20260702105727455044", "timestamp": "2026-07-02 10:57:52"}	\N
1140	100101	3	1	YBM	20260702105836273110	2026-07-02 10:58:58.623122	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702105836273110", "orderId": "20260702105836273110", "timestamp": "2026-07-02 10:58:58"}	\N
1141	100101	3	1	QM	1487	2026-07-02 11:00:17.929819	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1487", "orderId": "1487", "timestamp": "2026-07-02 11:00:17"}	\N
1142	100103	1	5	QM	1481	2026-07-02 11:00:28.554767	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "QM", "order_id": "1481", "orderId": "1481", "timestamp": "2026-07-02 11:00:28"}	\N
1143	100101	2	6	QM	1474	2026-07-02 11:05:58.251665	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1474", "orderId": "1474", "timestamp": "2026-07-02 11:05:58"}	\N
1144	100103	1	1	QM	1464	2026-07-02 11:06:24.351002	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1464", "orderId": "1464", "timestamp": "2026-07-02 11:06:24"}	\N
1145	100101	2	4	QM	1472	2026-07-02 11:08:22.809655	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1472", "orderId": "1472", "timestamp": "2026-07-02 11:08:22"}	\N
1146	100103	3	12	QM	1452	2026-07-02 11:09:22.593011	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "QM", "order_id": "1452", "orderId": "1452", "timestamp": "2026-07-02 11:09:22"}	\N
1147	100101	2	5	QM	1473	2026-07-02 11:09:35.55263	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 5, "lockNo": 5, "protocol": "QM", "order_id": "1473", "orderId": "1473", "timestamp": "2026-07-02 11:09:35"}	\N
1148	100103	1	6	QM	1482	2026-07-02 11:14:48.24761	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1482", "orderId": "1482", "timestamp": "2026-07-02 11:14:48"}	\N
1149	100101	2	9	QM	1477	2026-07-02 11:16:08.896157	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 9, "lockNo": 9, "protocol": "QM", "order_id": "1477", "orderId": "1477", "timestamp": "2026-07-02 11:16:08"}	\N
1150	100101	2	8	QM	1476	2026-07-02 11:17:30.371081	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1476", "orderId": "1476", "timestamp": "2026-07-02 11:17:30"}	\N
1151	100101	2	4	QM	1472	2026-07-02 11:17:53.90622	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1472", "orderId": "1472", "timestamp": "2026-07-02 11:17:53"}	\N
1152	100101	2	12	QM	1483	2026-07-02 11:18:25.901058	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "protocol": "QM", "order_id": "1483", "orderId": "1483", "timestamp": "2026-07-02 11:18:25"}	\N
1153	100101	4	14	QM	1417	2026-07-02 11:19:08.857566	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 14, "lockNo": 14, "protocol": "QM", "order_id": "1417", "orderId": "1417", "timestamp": "2026-07-02 11:19:08"}	\N
1154	100101	3	4	YBM	20260702112054638183	2026-07-02 11:21:12.842413	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702112054638183", "orderId": "20260702112054638183", "timestamp": "2026-07-02 11:21:12"}	\N
1155	100101	2	11	QM	1480	2026-07-02 11:26:09.447584	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1480", "orderId": "1480", "timestamp": "2026-07-02 11:26:09"}	\N
1157	100101	4	6	QM	1439	2026-07-02 11:26:35.88115	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1439", "orderId": "1439", "timestamp": "2026-07-02 11:26:35"}	\N
1156	100103	1	7	YBM	20260702112614101432	2026-07-02 11:26:35.612298	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260702112614101432", "orderId": "20260702112614101432", "timestamp": "2026-07-02 11:26:35"}	\N
1158	100103	1	4	QM	1478	2026-07-02 11:27:56.914634	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1478", "orderId": "1478", "timestamp": "2026-07-02 11:27:56"}	\N
1159	100101	3	6	YBM	20260702112842498012	2026-07-02 11:29:17.464662	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260702112842498012", "orderId": "20260702112842498012", "timestamp": "2026-07-02 11:29:17"}	\N
1160	100101	3	8	YBM	20260702113002858214	2026-07-02 11:30:53.636141	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260702113002858214", "orderId": "20260702113002858214", "timestamp": "2026-07-02 11:30:53"}	\N
1161	100101	3	6	QM	1491	2026-07-02 11:31:50.380281	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1491", "orderId": "1491", "timestamp": "2026-07-02 11:31:50"}	\N
1162	100101	3	6	QM	1491	2026-07-02 11:32:10.058251	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1491", "orderId": "1491", "timestamp": "2026-07-02 11:32:10"}	\N
1163	100101	3	6	QM	1491	2026-07-02 11:33:03.425542	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1491", "orderId": "1491", "timestamp": "2026-07-02 11:33:03"}	\N
1164	100103	1	7	QM	1490	2026-07-02 11:33:16.055887	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1490", "orderId": "1490", "timestamp": "2026-07-02 11:33:16"}	\N
1165	100101	2	10	QM	1479	2026-07-02 11:33:40.072305	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "protocol": "QM", "order_id": "1479", "orderId": "1479", "timestamp": "2026-07-02 11:33:40"}	\N
1166	100101	3	8	QM	1493	2026-07-02 11:34:55.171356	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1493", "orderId": "1493", "timestamp": "2026-07-02 11:34:55"}	\N
1167	100101	2	11	QM	1480	2026-07-02 11:35:33.999474	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1480", "orderId": "1480", "timestamp": "2026-07-02 11:35:33"}	\N
1168	100101	3	4	QM	1489	2026-07-02 11:40:09.873047	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1489", "orderId": "1489", "timestamp": "2026-07-02 11:40:09"}	\N
1169	100101	4	16	QM	1421	2026-07-02 11:41:41.480377	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 16, "lockNo": 16, "protocol": "QM", "order_id": "1421", "orderId": "1421", "timestamp": "2026-07-02 11:41:41"}	\N
1170	100101	1	4	YBM	20260702114337770323	2026-07-02 11:43:56.072381	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702114337770323", "orderId": "20260702114337770323", "timestamp": "2026-07-02 11:43:56"}	\N
1171	100101	1	4	YBM	20260702114337770323	2026-07-02 11:43:56.251124	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702114337770323", "orderId": "20260702114337770323", "timestamp": "2026-07-02 11:43:56"}	\N
1172	100101	4	16	QM	1421	2026-07-02 11:44:20.281916	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 16, "lockNo": 16, "protocol": "QM", "order_id": "1421", "orderId": "1421", "timestamp": "2026-07-02 11:44:20"}	\N
1173	100101	2	4	QM	1472	2026-07-02 11:47:46.663261	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1472", "orderId": "1472", "timestamp": "2026-07-02 11:47:46"}	\N
1174	100103	1	4	QM	1478	2026-07-02 11:49:13.493703	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1478", "orderId": "1478", "timestamp": "2026-07-02 11:49:13"}	\N
1175	100101	1	11	QM	1460	2026-07-02 11:54:08.072873	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1460", "orderId": "1460", "timestamp": "2026-07-02 11:54:08"}	\N
1176	100103	1	5	QM	1481	2026-07-02 11:56:49.179334	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "QM", "order_id": "1481", "orderId": "1481", "timestamp": "2026-07-02 11:56:49"}	\N
1177	100101	4	2	QM	1407	2026-07-02 12:27:12.583328	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 2, "lockNo": 2, "protocol": "QM", "order_id": "1407", "orderId": "1407", "timestamp": "2026-07-02 12:27:12"}	\N
1178	100101	1	6	YBM	20260702124747088994	2026-07-02 12:48:11.306831	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260702124747088994", "orderId": "20260702124747088994", "timestamp": "2026-07-02 12:48:11"}	\N
1179	100101	3	6	QM	1491	2026-07-02 12:52:08.181093	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1491", "orderId": "1491", "timestamp": "2026-07-02 12:52:08"}	\N
1180	100101	1	6	QM	1495	2026-07-02 12:56:40.694736	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1495", "orderId": "1495", "timestamp": "2026-07-02 12:56:40"}	\N
1181	100101	3	6	QM	1491	2026-07-02 13:02:52.172494	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1491", "orderId": "1491", "timestamp": "2026-07-02 13:02:52"}	\N
1182	100101	3	6	QM	1491	2026-07-02 13:04:19.776754	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1491", "orderId": "1491", "timestamp": "2026-07-02 13:04:19"}	\N
1183	100101	1	6	QM	1495	2026-07-02 13:33:57.110493	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1495", "orderId": "1495", "timestamp": "2026-07-02 13:33:57"}	\N
1184	100101	1	4	QM	1494	2026-07-02 13:35:41.502398	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1494", "orderId": "1494", "timestamp": "2026-07-02 13:35:41"}	\N
1185	100101	3	11	YBM	20260702134039042484	2026-07-02 13:40:55.974745	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260702134039042484", "orderId": "20260702134039042484", "timestamp": "2026-07-02 13:40:55"}	\N
1186	100103	1	8	YBM	20260702134040354145	2026-07-02 13:41:00.33823	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260702134040354145", "orderId": "20260702134040354145", "timestamp": "2026-07-02 13:41:00"}	\N
1187	100101	3	13	YBM	20260702134104573220	2026-07-02 13:41:27.058484	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260702134104573220", "orderId": "20260702134104573220", "timestamp": "2026-07-02 13:41:27"}	\N
1188	100101	3	16	YBM	20260702134132115829	2026-07-02 13:42:05.399067	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "20260702134132115829", "orderId": "20260702134132115829", "timestamp": "2026-07-02 13:42:05"}	\N
1189	100101	4	2	YBM	20260702134148787231	2026-07-02 13:42:13.407262	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260702134148787231", "orderId": "20260702134148787231", "timestamp": "2026-07-02 13:42:13"}	\N
1190	100101	1	4	QM	1494	2026-07-02 13:43:10.2153	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1494", "orderId": "1494", "timestamp": "2026-07-02 13:43:10"}	\N
1191	100101	4	4	YBM	20260702135424743179	2026-07-02 13:54:42.470706	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702135424743179", "orderId": "20260702135424743179", "timestamp": "2026-07-02 13:54:42"}	\N
1192	100103	1	8	QM	1497	2026-07-02 13:58:22.53132	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1497", "orderId": "1497", "timestamp": "2026-07-02 13:58:22"}	\N
1193	100101	4	4	QM	1501	2026-07-02 13:59:31.271752	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1501", "orderId": "1501", "timestamp": "2026-07-02 13:59:31"}	\N
1194	100103	1	8	QM	1497	2026-07-02 13:59:58.612856	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1497", "orderId": "1497", "timestamp": "2026-07-02 13:59:58"}	\N
1195	100101	3	11	QM	1496	2026-07-02 14:00:10.116853	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1496", "orderId": "1496", "timestamp": "2026-07-02 14:00:10"}	\N
1196	100103	1	8	QM	1497	2026-07-02 14:01:25.080572	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1497", "orderId": "1497", "timestamp": "2026-07-02 14:01:25"}	\N
1197	100101	4	7	YBM	20260702140217485233	2026-07-02 14:02:48.819408	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260702140217485233", "orderId": "20260702140217485233", "timestamp": "2026-07-02 14:02:48"}	\N
1198	100103	1	8	QM	1497	2026-07-02 14:03:04.530353	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1497", "orderId": "1497", "timestamp": "2026-07-02 14:03:04"}	\N
1232	100101	3	6	QM	1491	2026-07-02 14:36:53.182714	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1491", "orderId": "1491", "timestamp": "2026-07-02 14:36:53"}	\N
1199	100101	4	7	QM	1502	2026-07-02 14:03:23.039095	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1502", "orderId": "1502", "timestamp": "2026-07-02 14:03:23"}	\N
1201	100101	4	4	QM	1501	2026-07-02 14:05:26.239401	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1501", "orderId": "1501", "timestamp": "2026-07-02 14:05:26"}	\N
1202	100101	3	6	QM	1491	2026-07-02 14:07:15.647369	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1491", "orderId": "1491", "timestamp": "2026-07-02 14:07:15"}	\N
1203	100101	4	7	QM	1502	2026-07-02 14:07:33.667336	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1502", "orderId": "1502", "timestamp": "2026-07-02 14:07:33"}	\N
1204	100101	4	11	YBM	20260702140724250870	2026-07-02 14:07:42.988463	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260702140724250870", "orderId": "20260702140724250870", "timestamp": "2026-07-02 14:07:42"}	\N
1205	100101	3	3	YBM	20260702140730396695	2026-07-02 14:07:59.930228	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260702140730396695", "orderId": "20260702140730396695", "timestamp": "2026-07-02 14:07:59"}	\N
1211	100103	1	8	QM	1497	2026-07-02 14:09:32.653983	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1497", "orderId": "1497", "timestamp": "2026-07-02 14:09:32"}	\N
1212	100101	3	3	QM	1506	2026-07-02 14:11:50.212708	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1506", "orderId": "1506", "timestamp": "2026-07-02 14:11:50"}	\N
1214	100103	1	8	QM	1497	2026-07-02 14:18:19.551564	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1497", "orderId": "1497", "timestamp": "2026-07-02 14:18:19"}	\N
1200	100101	4	9	YBM	20260702140306046418	2026-07-02 14:03:27.457772	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260702140306046418", "orderId": "20260702140306046418", "timestamp": "2026-07-02 14:03:27"}	\N
1206	100103	1	9	YBM	20260702140744122992	2026-07-02 14:08:06.766297	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "YBM", "order_id": "20260702140744122992", "orderId": "20260702140744122992", "timestamp": "2026-07-02 14:08:06"}	\N
1207	100101	3	10	YBM	20260702140754601295	2026-07-02 14:08:17.053753	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260702140754601295", "orderId": "20260702140754601295", "timestamp": "2026-07-02 14:08:17"}	\N
1209	100101	3	10	YBM	20260702140754601295	2026-07-02 14:08:17.211616	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260702140754601295", "orderId": "20260702140754601295", "timestamp": "2026-07-02 14:08:17"}	\N
1208	100103	1	10	YBM	20260702140755030152	2026-07-02 14:08:17.12364	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260702140755030152", "orderId": "20260702140755030152", "timestamp": "2026-07-02 14:08:17"}	\N
1210	100101	3	12	YBM	20260702140827587893	2026-07-02 14:08:47.457871	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702140827587893", "orderId": "20260702140827587893", "timestamp": "2026-07-02 14:08:47"}	\N
1213	100101	3	15	YBM	20260702141512471432	2026-07-02 14:15:33.551357	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702141512471432", "orderId": "20260702141512471432", "timestamp": "2026-07-02 14:15:33"}	\N
1215	100103	1	8	QM	1497	2026-07-02 14:20:33.260511	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1497", "orderId": "1497", "timestamp": "2026-07-02 14:20:33"}	\N
1216	100101	4	1	YBM	20260702142039515714	2026-07-02 14:20:58.576055	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702142039515714", "orderId": "20260702142039515714", "timestamp": "2026-07-02 14:20:58"}	\N
1217	100101	4	7	QM	1502	2026-07-02 14:21:04.967227	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1502", "orderId": "1502", "timestamp": "2026-07-02 14:21:04"}	\N
1218	100101	1	4	QM	1494	2026-07-02 14:22:47.742557	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1494", "orderId": "1494", "timestamp": "2026-07-02 14:22:47"}	\N
1219	100101	3	4	QM	1489	2026-07-02 14:23:20.938219	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1489", "orderId": "1489", "timestamp": "2026-07-02 14:23:20"}	\N
1220	100101	4	14	QM	1417	2026-07-02 14:23:37.00277	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 14, "lockNo": 14, "protocol": "QM", "order_id": "1417", "orderId": "1417", "timestamp": "2026-07-02 14:23:37"}	\N
1221	100101	4	16	QM	1421	2026-07-02 14:24:09.591173	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 16, "lockNo": 16, "protocol": "QM", "order_id": "1421", "orderId": "1421", "timestamp": "2026-07-02 14:24:09"}	\N
1222	100103	1	8	QM	1497	2026-07-02 14:25:02.9132	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1497", "orderId": "1497", "timestamp": "2026-07-02 14:25:02"}	\N
1223	100101	3	11	QM	1496	2026-07-02 14:27:48.543233	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1496", "orderId": "1496", "timestamp": "2026-07-02 14:27:48"}	\N
1224	100101	4	7	QM	1502	2026-07-02 14:32:35.44136	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1502", "orderId": "1502", "timestamp": "2026-07-02 14:32:35"}	\N
1225	100101	4	4	QM	1501	2026-07-02 14:33:40.223072	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1501", "orderId": "1501", "timestamp": "2026-07-02 14:33:40"}	\N
1226	100101	3	13	QM	1498	2026-07-02 14:35:11.695019	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 13, "lockNo": 13, "protocol": "QM", "order_id": "1498", "orderId": "1498", "timestamp": "2026-07-02 14:35:11"}	\N
1227	100103	1	10	QM	1509	2026-07-02 14:35:27.741108	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "protocol": "QM", "order_id": "1509", "orderId": "1509", "timestamp": "2026-07-02 14:35:27"}	\N
1228	100101	3	16	QM	1499	2026-07-02 14:36:05.499913	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 16, "lockNo": 16, "protocol": "QM", "order_id": "1499", "orderId": "1499", "timestamp": "2026-07-02 14:36:05"}	\N
1229	100101	4	14	YBM	20260702143544071556	2026-07-02 14:36:05.661282	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260702143544071556", "orderId": "20260702143544071556", "timestamp": "2026-07-02 14:36:05"}	\N
1230	100101	1	6	QM	1495	2026-07-02 14:36:18.339221	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1495", "orderId": "1495", "timestamp": "2026-07-02 14:36:18"}	\N
1231	100101	4	2	QM	1500	2026-07-02 14:36:36.311228	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 2, "lockNo": 2, "protocol": "QM", "order_id": "1500", "orderId": "1500", "timestamp": "2026-07-02 14:36:36"}	\N
1233	100101	3	3	QM	1506	2026-07-02 14:37:07.238772	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1506", "orderId": "1506", "timestamp": "2026-07-02 14:37:07"}	\N
1234	100101	4	9	QM	1503	2026-07-02 14:37:48.031548	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 9, "lockNo": 9, "protocol": "QM", "order_id": "1503", "orderId": "1503", "timestamp": "2026-07-02 14:37:48"}	\N
1235	100101	4	16	YBM	20260702143734679789	2026-07-02 14:37:52.718579	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "20260702143734679789", "orderId": "20260702143734679789", "timestamp": "2026-07-02 14:37:52"}	\N
1236	100103	1	11	YBM	20260702143754225919	2026-07-02 14:38:10.819138	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260702143754225919", "orderId": "20260702143754225919", "timestamp": "2026-07-02 14:38:10"}	\N
1237	100101	4	14	QM	1514	2026-07-02 14:38:19.369253	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 14, "lockNo": 14, "protocol": "QM", "order_id": "1514", "orderId": "1514", "timestamp": "2026-07-02 14:38:19"}	\N
1238	100101	4	5	YBM	20260702143856371695	2026-07-02 14:39:15.672739	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260702143856371695", "orderId": "20260702143856371695", "timestamp": "2026-07-02 14:39:15"}	\N
1239	100101	4	6	YBM	20260702143900147067	2026-07-02 14:39:19.273911	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260702143900147067", "orderId": "20260702143900147067", "timestamp": "2026-07-02 14:39:19"}	\N
1240	100101	4	6	YBM	20260702143900147067	2026-07-02 14:39:19.488389	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260702143900147067", "orderId": "20260702143900147067", "timestamp": "2026-07-02 14:39:19"}	\N
1241	100101	3	10	QM	1508	2026-07-02 14:39:43.089731	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 10, "lockNo": 10, "protocol": "QM", "order_id": "1508", "orderId": "1508", "timestamp": "2026-07-02 14:39:43"}	\N
1242	100103	1	12	YBM	20260702143914147229	2026-07-02 14:40:00.260872	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702143914147229", "orderId": "20260702143914147229", "timestamp": "2026-07-02 14:40:00"}	\N
1243	100103	1	10	QM	1509	2026-07-02 14:41:42.628595	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "protocol": "QM", "order_id": "1509", "orderId": "1509", "timestamp": "2026-07-02 14:41:42"}	\N
1244	100103	1	8	QM	1497	2026-07-02 14:42:00.185706	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1497", "orderId": "1497", "timestamp": "2026-07-02 14:42:00"}	\N
1245	100101	3	15	QM	1512	2026-07-02 14:44:45.20846	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 15, "lockNo": 15, "protocol": "QM", "order_id": "1512", "orderId": "1512", "timestamp": "2026-07-02 14:44:45"}	\N
1246	100101	4	14	QM	1514	2026-07-02 14:45:24.528221	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 14, "lockNo": 14, "protocol": "QM", "order_id": "1514", "orderId": "1514", "timestamp": "2026-07-02 14:45:24"}	\N
1247	100101	4	8	YBM	20260702144526866350	2026-07-02 14:46:13.765244	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 8, "lockNo": 8, "protocol": "YBM", "order_id": "20260702144526866350", "orderId": "20260702144526866350", "timestamp": "2026-07-02 14:46:13"}	\N
1248	100101	4	12	YBM	20260702144854973401	2026-07-02 14:49:13.929966	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 12, "lockNo": 12, "protocol": "YBM", "order_id": "20260702144854973401", "orderId": "20260702144854973401", "timestamp": "2026-07-02 14:49:13"}	\N
1249	100101	4	12	QM	1523	2026-07-02 14:52:17.126802	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 12, "lockNo": 12, "protocol": "QM", "order_id": "1523", "orderId": "1523", "timestamp": "2026-07-02 14:52:17"}	\N
1250	100103	1	12	QM	1520	2026-07-02 14:52:49.209793	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "protocol": "QM", "order_id": "1520", "orderId": "1520", "timestamp": "2026-07-02 14:52:49"}	\N
1251	100101	4	7	QM	1502	2026-07-02 14:55:50.373264	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1502", "orderId": "1502", "timestamp": "2026-07-02 14:55:50"}	\N
1252	100101	1	1	YBM	20260702145538688668	2026-07-02 14:56:23.014145	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702145538688668", "orderId": "20260702145538688668", "timestamp": "2026-07-02 14:56:23"}	\N
1253	100103	1	11	QM	1516	2026-07-02 14:58:25.090104	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1516", "orderId": "1516", "timestamp": "2026-07-02 14:58:25"}	\N
1254	100101	4	11	QM	1504	2026-07-02 15:01:31.841504	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1504", "orderId": "1504", "timestamp": "2026-07-02 15:01:31"}	\N
1255	100101	4	6	QM	1519	2026-07-02 15:03:10.301129	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1519", "orderId": "1519", "timestamp": "2026-07-02 15:03:10"}	\N
1256	100101	1	3	YBM	20260702150309568596	2026-07-02 15:03:25.655478	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "YBM", "order_id": "20260702150309568596", "orderId": "20260702150309568596", "timestamp": "2026-07-02 15:03:25"}	\N
1257	100101	1	5	YBM	20260702150323389885	2026-07-02 15:03:39.928738	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260702150323389885", "orderId": "20260702150323389885", "timestamp": "2026-07-02 15:03:39"}	\N
1258	100103	1	13	YBM	20260702150316102064	2026-07-02 15:03:50.664726	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260702150316102064", "orderId": "20260702150316102064", "timestamp": "2026-07-02 15:03:50"}	\N
1259	100103	1	14	YBM	20260702150337366312	2026-07-02 15:04:02.599904	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260702150337366312", "orderId": "20260702150337366312", "timestamp": "2026-07-02 15:04:02"}	\N
1260	100103	1	8	QM	1497	2026-07-02 15:04:15.016804	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1497", "orderId": "1497", "timestamp": "2026-07-02 15:04:15"}	\N
1261	100101	4	11	QM	1504	2026-07-02 15:04:17.216908	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1504", "orderId": "1504", "timestamp": "2026-07-02 15:04:17"}	\N
1262	100101	1	3	QM	1527	2026-07-02 15:04:33.154997	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1527", "orderId": "1527", "timestamp": "2026-07-02 15:04:33"}	\N
1263	100103	1	16	YBM	20260702150800495797	2026-07-02 15:08:23.466902	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "protocol": "YBM", "order_id": "20260702150800495797", "orderId": "20260702150800495797", "timestamp": "2026-07-02 15:08:23"}	\N
1264	100103	1	11	QM	1516	2026-07-02 15:10:37.691676	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1516", "orderId": "1516", "timestamp": "2026-07-02 15:10:37"}	\N
1265	100101	1	7	YBM	20260702151350162558	2026-07-02 15:14:08.120615	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260702151350162558", "orderId": "20260702151350162558", "timestamp": "2026-07-02 15:14:08"}	\N
1266	100101	1	7	YBM	20260702151350162558	2026-07-02 15:14:08.227211	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "YBM", "order_id": "20260702151350162558", "orderId": "20260702151350162558", "timestamp": "2026-07-02 15:14:08"}	\N
1267	100101	1	7	QM	1533	2026-07-02 15:14:28.36462	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1533", "orderId": "1533", "timestamp": "2026-07-02 15:14:28"}	\N
1268	100101	1	3	QM	1527	2026-07-02 15:14:50.412259	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1527", "orderId": "1527", "timestamp": "2026-07-02 15:14:50"}	\N
1269	100103	2	2	YBM	20260702152133481623	2026-07-02 15:21:51.298866	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "YBM", "order_id": "20260702152133481623", "orderId": "20260702152133481623", "timestamp": "2026-07-02 15:21:51"}	\N
1270	100101	1	5	QM	1529	2026-07-02 15:26:47.11959	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "protocol": "QM", "order_id": "1529", "orderId": "1529", "timestamp": "2026-07-02 15:26:47"}	\N
1271	100101	1	11	YBM	20260702152903962518	2026-07-02 15:29:43.763521	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "YBM", "order_id": "20260702152903962518", "orderId": "20260702152903962518", "timestamp": "2026-07-02 15:29:43"}	\N
1272	100103	1	14	QM	1530	2026-07-02 15:29:51.421792	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "protocol": "QM", "order_id": "1530", "orderId": "1530", "timestamp": "2026-07-02 15:29:51"}	\N
1273	100101	3	12	QM	1510	2026-07-02 15:30:18.006873	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "protocol": "QM", "order_id": "1510", "orderId": "1510", "timestamp": "2026-07-02 15:30:18"}	\N
1274	100103	1	9	QM	1507	2026-07-02 15:30:55.393721	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "protocol": "QM", "order_id": "1507", "orderId": "1507", "timestamp": "2026-07-02 15:30:55"}	\N
1275	100101	4	16	QM	1515	2026-07-02 15:32:44.361217	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 16, "lockNo": 16, "protocol": "QM", "order_id": "1515", "orderId": "1515", "timestamp": "2026-07-02 15:32:44"}	\N
1276	100100	1	15	YBM	20260702153319838903	2026-07-02 15:33:48.379412	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702153319838903", "orderId": "20260702153319838903", "timestamp": "2026-07-02 15:33:48"}	\N
1277	100100	1	15	YBM	20260702153319838903	2026-07-02 15:33:55.820711	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702153319838903", "orderId": "20260702153319838903", "timestamp": "2026-07-02 15:33:55"}	\N
1278	100101	1	13	YBM	20260702153326808824	2026-07-02 15:33:56.579241	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260702153326808824", "orderId": "20260702153326808824", "timestamp": "2026-07-02 15:33:56"}	\N
1279	100101	1	13	YBM	20260702153326808824	2026-07-02 15:33:56.78703	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "YBM", "order_id": "20260702153326808824", "orderId": "20260702153326808824", "timestamp": "2026-07-02 15:33:56"}	\N
1280	100101	4	5	QM	1518	2026-07-02 15:34:14.821875	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 5, "lockNo": 5, "protocol": "QM", "order_id": "1518", "orderId": "1518", "timestamp": "2026-07-02 15:34:14"}	\N
1281	100100	1	15	QM	1537	2026-07-02 15:34:52.648966	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "QM", "order_id": "1537", "orderId": "1537", "timestamp": "2026-07-02 15:34:52"}	\N
1282	100101	4	6	QM	1519	2026-07-02 15:35:58.560018	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1519", "orderId": "1519", "timestamp": "2026-07-02 15:35:58"}	\N
1283	100101	4	11	QM	1504	2026-07-02 15:36:44.840754	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1504", "orderId": "1504", "timestamp": "2026-07-02 15:36:44"}	\N
1284	100101	1	3	QM	1527	2026-07-02 15:37:26.930887	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1527", "orderId": "1527", "timestamp": "2026-07-02 15:37:26"}	\N
1285	100101	1	1	QM	1525	2026-07-02 15:37:55.304086	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1525", "orderId": "1525", "timestamp": "2026-07-02 15:37:55"}	\N
1286	100103	2	4	YBM	20260702153748669240	2026-07-02 15:38:03.583555	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702153748669240", "orderId": "20260702153748669240", "timestamp": "2026-07-02 15:38:03"}	\N
1287	100103	2	5	YBM	20260702153854213248	2026-07-02 15:39:55.615241	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 5, "lockNo": 5, "protocol": "YBM", "order_id": "20260702153854213248", "orderId": "20260702153854213248", "timestamp": "2026-07-02 15:39:55"}	\N
1288	100103	1	13	QM	1528	2026-07-02 15:40:47.268235	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "QM", "order_id": "1528", "orderId": "1528", "timestamp": "2026-07-02 15:40:47"}	\N
1289	100103	1	11	QM	1516	2026-07-02 15:41:18.1937	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1516", "orderId": "1516", "timestamp": "2026-07-02 15:41:18"}	\N
1290	100101	1	14	YBM	20260702154118599900	2026-07-02 15:41:31.285001	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260702154118599900", "orderId": "20260702154118599900", "timestamp": "2026-07-02 15:41:31"}	\N
1291	100101	1	14	YBM	20260702154118599900	2026-07-02 15:41:31.440749	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "protocol": "YBM", "order_id": "20260702154118599900", "orderId": "20260702154118599900", "timestamp": "2026-07-02 15:41:31"}	\N
1292	100101	4	12	QM	1523	2026-07-02 15:41:44.425821	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 12, "lockNo": 12, "protocol": "QM", "order_id": "1523", "orderId": "1523", "timestamp": "2026-07-02 15:41:44"}	\N
1293	100101	4	14	QM	1514	2026-07-02 15:42:05.283959	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 14, "lockNo": 14, "protocol": "QM", "order_id": "1514", "orderId": "1514", "timestamp": "2026-07-02 15:42:05"}	\N
1294	100103	1	16	QM	1532	2026-07-02 15:44:52.288452	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "protocol": "QM", "order_id": "1532", "orderId": "1532", "timestamp": "2026-07-02 15:44:52"}	\N
1295	100101	3	3	QM	1506	2026-07-02 15:47:53.360728	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 3, "boardNo": 3, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1506", "orderId": "1506", "timestamp": "2026-07-02 15:47:53"}	\N
1296	100101	1	13	QM	1539	2026-07-02 15:51:52.107911	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "protocol": "QM", "order_id": "1539", "orderId": "1539", "timestamp": "2026-07-02 15:51:52"}	\N
1297	100103	2	6	YBM	20260702155329081576	2026-07-02 15:54:11.641255	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "YBM", "order_id": "20260702155329081576", "orderId": "20260702155329081576", "timestamp": "2026-07-02 15:54:11"}	\N
1298	100101	1	15	YBM	20260702155503957573	2026-07-02 15:55:28.138117	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702155503957573", "orderId": "20260702155503957573", "timestamp": "2026-07-02 15:55:28"}	\N
1299	100101	4	8	QM	1521	2026-07-02 15:55:34.142445	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 8, "lockNo": 8, "protocol": "QM", "order_id": "1521", "orderId": "1521", "timestamp": "2026-07-02 15:55:34"}	\N
1300	100101	1	11	QM	1536	2026-07-02 15:57:17.410163	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "protocol": "QM", "order_id": "1536", "orderId": "1536", "timestamp": "2026-07-02 15:57:17"}	\N
1301	100101	1	3	QM	1527	2026-07-02 15:58:46.110777	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1527", "orderId": "1527", "timestamp": "2026-07-02 15:58:46"}	\N
1302	100101	1	3	QM	1527	2026-07-02 15:59:35.95146	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "protocol": "QM", "order_id": "1527", "orderId": "1527", "timestamp": "2026-07-02 15:59:35"}	\N
1303	100101	4	1	QM	1513	2026-07-02 15:59:49.339437	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1513", "orderId": "1513", "timestamp": "2026-07-02 15:59:49"}	\N
1304	100103	2	2	QM	1534	2026-07-02 16:01:03.74	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "protocol": "QM", "order_id": "1534", "orderId": "1534", "timestamp": "2026-07-02 16:01:03"}	\N
1305	100101	4	4	YBM		2026-07-02 16:03:57.850908	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 4, "boardNo": 4, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "", "orderId": "", "timestamp": "2026-07-02 16:03:57"}	\N
1306	100103	2	4	QM	1540	2026-07-02 16:06:53.295222	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1540", "orderId": "1540", "timestamp": "2026-07-02 16:06:53"}	\N
1307	100101	1	14	QM	1542	2026-07-02 16:09:52.822639	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "protocol": "QM", "order_id": "1542", "orderId": "1542", "timestamp": "2026-07-02 16:09:52"}	\N
1308	100101	1	7	QM	1533	2026-07-02 16:10:59.991041	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "protocol": "QM", "order_id": "1533", "orderId": "1533", "timestamp": "2026-07-02 16:10:59"}	\N
1309	100103	2	6	QM	1543	2026-07-02 16:16:03.10026	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "protocol": "QM", "order_id": "1543", "orderId": "1543", "timestamp": "2026-07-02 16:16:03"}	\N
1310	100100	2	4	YBM	20260702161750709323	2026-07-02 16:18:07.182079	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702161750709323", "orderId": "20260702161750709323", "timestamp": "2026-07-02 16:18:07"}	\N
1311	100101	1	15	QM	1544	2026-07-02 16:18:13.644863	1	\N	\N	{"type": "open_lock", "device_id": "100101", "deviceId": "100101", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "QM", "order_id": "1544", "orderId": "1544", "timestamp": "2026-07-02 16:18:13"}	\N
1312	100100	2	4	QM	1547	2026-07-02 16:18:37.615143	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "QM", "order_id": "1547", "orderId": "1547", "timestamp": "2026-07-02 16:18:37"}	\N
1313	100103	2	5	QM	1541	2026-07-02 16:18:41.215258	1	\N	\N	{"type": "open_lock", "device_id": "100103", "deviceId": "100103", "board_no": 2, "boardNo": 2, "lock_no": 5, "lockNo": 5, "protocol": "QM", "order_id": "1541", "orderId": "1541", "timestamp": "2026-07-02 16:18:41"}	\N
1314	100100	2	10	YBM	20260702215500274169	2026-07-02 21:55:20.10477	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260702215500274169", "orderId": "20260702215500274169", "timestamp": "2026-07-02 21:55:20"}	\N
1315	100100	2	10	YBM	20260702215500274169	2026-07-02 21:55:31.598004	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260702215500274169", "orderId": "20260702215500274169", "timestamp": "2026-07-02 21:55:31"}	\N
1316	100100	1	4	YBM	20260701152234730339	2026-07-02 22:01:37.904863	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260701152234730339", "orderId": "20260701152234730339", "timestamp": "2026-07-02 22:01:37"}	\N
1317	100100	2	4	YBM	20260702161750709323	2026-07-02 22:01:53.485981	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702161750709323", "orderId": "20260702161750709323", "timestamp": "2026-07-02 22:01:53"}	\N
1318	100100	2	4	YBM	20260702161750709323	2026-07-02 22:01:58.319407	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702161750709323", "orderId": "20260702161750709323", "timestamp": "2026-07-02 22:01:58"}	\N
1319	100100	1	15	YBM	20260702153319838903	2026-07-02 22:02:04.851534	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702153319838903", "orderId": "20260702153319838903", "timestamp": "2026-07-02 22:02:04"}	\N
1320	100100	1	15	YBM	20260702153319838903	2026-07-02 22:02:13.948181	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "protocol": "YBM", "order_id": "20260702153319838903", "orderId": "20260702153319838903", "timestamp": "2026-07-02 22:02:13"}	\N
1321	100100	2	4	YBM	20260702161750709323	2026-07-02 22:02:19.029252	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "protocol": "YBM", "order_id": "20260702161750709323", "orderId": "20260702161750709323", "timestamp": "2026-07-02 22:02:19"}	\N
1322	100100	2	10	YBM	20260702215500274169	2026-07-02 22:02:24.610537	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "protocol": "YBM", "order_id": "20260702215500274169", "orderId": "20260702215500274169", "timestamp": "2026-07-02 22:02:24"}	\N
1323	100100	1	\N	YBM		2026-07-02 22:04:02.571275	1	16	\N	{"type": "force_update", "download_url": "https://locker.cqdyxl.com/static/locker.apk", "version_name": "1.2.50", "version_code": 170, "force": true, "file_md5": ""}	pending
1324	100100	3	1	YBM	20260702220528243130	2026-07-02 22:05:48.210214	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702220528243130", "orderId": "20260702220528243130", "timestamp": "2026-07-02 22:05:48"}	\N
1325	100100	3	1	YBM	20260702220528243130	2026-07-02 22:05:48.574048	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702220528243130", "orderId": "20260702220528243130", "timestamp": "2026-07-02 22:05:48"}	\N
1326	100100	3	1	YBM	20260702220528243130	2026-07-02 22:05:54.737401	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "protocol": "YBM", "order_id": "20260702220528243130", "orderId": "20260702220528243130", "timestamp": "2026-07-02 22:05:54"}	\N
1327	100100	3	1	QM	1551	2026-07-02 22:06:05.636191	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1551", "orderId": "1551", "timestamp": "2026-07-02 22:06:05"}	\N
1328	101010	1	1	QM	1552	2026-07-02 22:13:07.824534	0	\N	\N	{"type": "open_lock", "device_id": "101010", "deviceId": "101010", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1552", "orderId": "1552", "timestamp": "2026-07-02 22:13:07"}	\N
1329	101010	1	1	QM	1553	2026-07-02 22:13:43.713625	0	\N	\N	{"type": "open_lock", "device_id": "101010", "deviceId": "101010", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1553", "orderId": "1553", "timestamp": "2026-07-02 22:13:43"}	\N
1330	101010	1	1	QM	1557	2026-07-02 22:22:11.839037	0	\N	\N	{"type": "open_lock", "device_id": "101010", "deviceId": "101010", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1557", "orderId": "1557", "timestamp": "2026-07-02 22:22:11"}	\N
1331	100100	2	10	QM	1549	2026-07-02 22:29:07.302409	1	\N	\N	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "protocol": "QM", "order_id": "1549", "orderId": "1549", "timestamp": "2026-07-02 22:29:07"}	\N
1332	101010	1	1	QM	1558	2026-07-02 22:34:37.107221	0	\N	\N	{"type": "open_lock", "device_id": "101010", "deviceId": "101010", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1558", "orderId": "1558", "slot_number": "1", "slot_label": "", "timestamp": "2026-07-02 22:34:37"}	\N
1333	101010	1	1	QM	1559	2026-07-02 22:34:59.721016	0	\N	\N	{"type": "open_lock", "device_id": "101010", "deviceId": "101010", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "protocol": "QM", "order_id": "1559", "orderId": "1559", "slot_number": "1", "slot_label": "", "timestamp": "2026-07-02 22:34:59"}	\N
1334	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	448	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "slot_number": 2, "slot_label": "2"}	pending
1335	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	449	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "slot_number": 3, "slot_label": "3"}	pending
1336	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	450	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "slot_number": 4, "slot_label": "4"}	pending
1337	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	451	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "slot_number": 5, "slot_label": "5"}	pending
1338	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	452	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "slot_number": 6, "slot_label": "6"}	pending
1339	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	453	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "slot_number": 7, "slot_label": "7"}	pending
1340	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	455	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "slot_number": 9, "slot_label": "9"}	pending
1341	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	456	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "slot_number": 10, "slot_label": "10"}	pending
1342	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	457	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "slot_number": 11, "slot_label": "11"}	pending
1343	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	458	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "slot_number": 12, "slot_label": "12"}	pending
1344	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	459	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "slot_number": 13, "slot_label": "13"}	pending
1345	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	460	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "slot_number": 14, "slot_label": "14"}	pending
1346	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	461	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "slot_number": 15, "slot_label": "15"}	pending
1347	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	462	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "slot_number": 16, "slot_label": "16"}	pending
1348	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	447	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "slot_number": 1, "slot_label": "1"}	pending
1349	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	8	454	{"type": "open_lock", "device_id": "123456", "deviceId": "123456", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "slot_number": 8, "slot_label": "8"}	pending
1350	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	495	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "slot_number": 1, "slot_label": "B1"}	pending
1351	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	507	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "slot_number": 13, "slot_label": "B13"}	pending
1352	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	496	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "slot_number": 2, "slot_label": "B2"}	pending
1353	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	505	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "slot_number": 11, "slot_label": "B11"}	pending
1354	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	498	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "slot_number": 4, "slot_label": "B4"}	pending
1355	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	506	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "slot_number": 12, "slot_label": "B12"}	pending
1356	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	502	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "slot_number": 8, "slot_label": "B8"}	pending
1357	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	504	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "slot_number": 10, "slot_label": "B10"}	pending
1358	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	501	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "slot_number": 7, "slot_label": "B7"}	pending
1359	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	503	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "slot_number": 9, "slot_label": "B9"}	pending
1360	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	500	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "slot_number": 6, "slot_label": "B6"}	pending
1361	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	497	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "slot_number": 3, "slot_label": "B3"}	pending
1362	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	508	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "slot_number": 14, "slot_label": "B14"}	pending
1363	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	510	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "slot_number": 16, "slot_label": "B16"}	pending
1364	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	511	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 1, "lockNo": 1, "slot_number": 17, "slot_label": "B17"}	pending
1365	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	513	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "slot_number": 19, "slot_label": "B19"}	pending
1366	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	515	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 5, "lockNo": 5, "slot_number": 21, "slot_label": "B21"}	pending
1367	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	518	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "slot_number": 24, "slot_label": "B24"}	pending
1368	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	519	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 9, "lockNo": 9, "slot_number": 25, "slot_label": "B25"}	pending
1369	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	514	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "slot_number": 20, "slot_label": "B20"}	pending
1370	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	512	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "slot_number": 18, "slot_label": "B18"}	pending
1371	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	800	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 2, "lockNo": 2, "slot_number": 34, "slot_label": "B34"}	pending
1372	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	801	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 3, "lockNo": 3, "slot_number": 35, "slot_label": "B35"}	pending
1373	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	802	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 4, "lockNo": 4, "slot_number": 36, "slot_label": "B36"}	pending
1374	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	803	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 5, "lockNo": 5, "slot_number": 37, "slot_label": "B37"}	pending
1375	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	804	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "slot_number": 38, "slot_label": "B38"}	pending
1376	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	805	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 7, "lockNo": 7, "slot_number": 39, "slot_label": "B39"}	pending
1377	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	806	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 8, "lockNo": 8, "slot_number": 40, "slot_label": "B40"}	pending
1378	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	807	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 9, "lockNo": 9, "slot_number": 41, "slot_label": "B41"}	pending
1379	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	808	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 10, "lockNo": 10, "slot_number": 42, "slot_label": "B42"}	pending
1380	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	809	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 11, "lockNo": 11, "slot_number": 43, "slot_label": "B43"}	pending
1381	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	810	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "slot_number": 44, "slot_label": "B44"}	pending
1382	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	811	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 13, "lockNo": 13, "slot_number": 45, "slot_label": "B45"}	pending
1383	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	812	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 14, "lockNo": 14, "slot_number": 46, "slot_label": "B46"}	pending
1384	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	813	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 15, "lockNo": 15, "slot_number": 47, "slot_label": "B47"}	pending
1385	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	814	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 16, "lockNo": 16, "slot_number": 48, "slot_label": "B48"}	pending
1386	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	815	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 1, "lockNo": 1, "slot_number": 49, "slot_label": "B49"}	pending
1387	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	816	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 2, "lockNo": 2, "slot_number": 50, "slot_label": "B50"}	pending
1388	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	817	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 3, "lockNo": 3, "slot_number": 51, "slot_label": "B51"}	pending
1389	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	818	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 4, "lockNo": 4, "slot_number": 52, "slot_label": "B52"}	pending
1390	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	819	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 5, "lockNo": 5, "slot_number": 53, "slot_label": "B53"}	pending
1391	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	820	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 6, "lockNo": 6, "slot_number": 54, "slot_label": "B54"}	pending
1392	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	821	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 7, "lockNo": 7, "slot_number": 55, "slot_label": "B55"}	pending
1393	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	822	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 8, "lockNo": 8, "slot_number": 56, "slot_label": "B56"}	pending
1394	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	823	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 9, "lockNo": 9, "slot_number": 57, "slot_label": "B57"}	pending
1395	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	824	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 10, "lockNo": 10, "slot_number": 58, "slot_label": "B58"}	pending
1396	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	825	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 11, "lockNo": 11, "slot_number": 59, "slot_label": "B59"}	pending
1397	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	826	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 12, "lockNo": 12, "slot_number": 60, "slot_label": "B60"}	pending
1398	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	827	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 13, "lockNo": 13, "slot_number": 61, "slot_label": "B61"}	pending
1399	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	828	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 14, "lockNo": 14, "slot_number": 62, "slot_label": "B62"}	pending
1400	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	829	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 15, "lockNo": 15, "slot_number": 63, "slot_label": "B63"}	pending
1401	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	830	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 4, "boardNo": 4, "lock_no": 16, "lockNo": 16, "slot_number": 64, "slot_label": "B64"}	pending
1402	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	524	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 14, "lockNo": 14, "slot_number": 30, "slot_label": "B30"}	pending
1403	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	526	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "slot_number": 32, "slot_label": "B32"}	pending
1404	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	520	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "slot_number": 26, "slot_label": "B26"}	pending
1405	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	509	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "slot_number": 15, "slot_label": "B15"}	pending
1406	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	799	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "slot_number": 33, "slot_label": "B33"}	pending
1407	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	516	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "slot_number": 22, "slot_label": "B22"}	pending
1408	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	517	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "slot_number": 23, "slot_label": "B23"}	pending
1409	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	499	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "slot_number": 5, "slot_label": "B5"}	pending
1410	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	521	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "slot_number": 27, "slot_label": "B27"}	pending
1411	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	522	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "slot_number": 28, "slot_label": "B28"}	pending
1412	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	523	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "slot_number": 29, "slot_label": "B29"}	pending
1413	\N	1	\N	YBM		2026-07-02 23:00:53.844629	0	16	525	{"type": "open_lock", "device_id": "100100", "deviceId": "100100", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "slot_number": 31, "slot_label": "B31"}	pending
1414	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1471	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 1, "lockNo": 1, "slot_number": 1, "slot_label": "1"}	pending
1415	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1472	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 2, "lockNo": 2, "slot_number": 2, "slot_label": "2"}	pending
1416	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1473	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 3, "lockNo": 3, "slot_number": 3, "slot_label": "3"}	pending
1417	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1474	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 4, "lockNo": 4, "slot_number": 4, "slot_label": "4"}	pending
1418	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1475	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 5, "lockNo": 5, "slot_number": 5, "slot_label": "5"}	pending
1419	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1476	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 6, "lockNo": 6, "slot_number": 6, "slot_label": "6"}	pending
1420	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1477	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 7, "lockNo": 7, "slot_number": 7, "slot_label": "7"}	pending
1421	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1478	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 8, "lockNo": 8, "slot_number": 8, "slot_label": "8"}	pending
1422	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1479	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 9, "lockNo": 9, "slot_number": 9, "slot_label": "9"}	pending
1423	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1480	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 10, "lockNo": 10, "slot_number": 10, "slot_label": "10"}	pending
1424	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1481	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 11, "lockNo": 11, "slot_number": 11, "slot_label": "11"}	pending
1425	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1482	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 12, "lockNo": 12, "slot_number": 12, "slot_label": "12"}	pending
1426	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1483	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 13, "lockNo": 13, "slot_number": 13, "slot_label": "13"}	pending
1427	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1484	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 14, "lockNo": 14, "slot_number": 14, "slot_label": "14"}	pending
1428	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1485	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 15, "lockNo": 15, "slot_number": 15, "slot_label": "15"}	pending
1429	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1486	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 1, "boardNo": 1, "lock_no": 16, "lockNo": 16, "slot_number": 16, "slot_label": "16"}	pending
1430	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1487	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 1, "lockNo": 1, "slot_number": 17, "slot_label": "17"}	pending
1431	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1488	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 2, "lockNo": 2, "slot_number": 18, "slot_label": "18"}	pending
1432	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1489	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 3, "lockNo": 3, "slot_number": 19, "slot_label": "19"}	pending
1433	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1490	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 4, "lockNo": 4, "slot_number": 20, "slot_label": "20"}	pending
1434	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1491	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 5, "lockNo": 5, "slot_number": 21, "slot_label": "21"}	pending
1435	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1492	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 6, "lockNo": 6, "slot_number": 22, "slot_label": "22"}	pending
1436	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1493	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 7, "lockNo": 7, "slot_number": 23, "slot_label": "23"}	pending
1437	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1494	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 8, "lockNo": 8, "slot_number": 24, "slot_label": "24"}	pending
1438	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1495	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 9, "lockNo": 9, "slot_number": 25, "slot_label": "25"}	pending
1439	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1496	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 10, "lockNo": 10, "slot_number": 26, "slot_label": "26"}	pending
1440	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1497	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 11, "lockNo": 11, "slot_number": 27, "slot_label": "27"}	pending
1441	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1498	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 12, "lockNo": 12, "slot_number": 28, "slot_label": "28"}	pending
1442	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1499	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 13, "lockNo": 13, "slot_number": 29, "slot_label": "29"}	pending
1443	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1500	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 14, "lockNo": 14, "slot_number": 30, "slot_label": "30"}	pending
1444	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1501	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 15, "lockNo": 15, "slot_number": 31, "slot_label": "31"}	pending
1445	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1502	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 2, "boardNo": 2, "lock_no": 16, "lockNo": 16, "slot_number": 32, "slot_label": "32"}	pending
1446	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1503	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 1, "lockNo": 1, "slot_number": 33, "slot_label": "33"}	pending
1447	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1504	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 2, "lockNo": 2, "slot_number": 34, "slot_label": "34"}	pending
1448	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1505	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 3, "lockNo": 3, "slot_number": 35, "slot_label": "35"}	pending
1449	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1506	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 4, "lockNo": 4, "slot_number": 36, "slot_label": "36"}	pending
1450	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1507	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 5, "lockNo": 5, "slot_number": 37, "slot_label": "37"}	pending
1451	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1508	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 6, "lockNo": 6, "slot_number": 38, "slot_label": "38"}	pending
1452	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1509	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 7, "lockNo": 7, "slot_number": 39, "slot_label": "39"}	pending
1453	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1510	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 8, "lockNo": 8, "slot_number": 40, "slot_label": "40"}	pending
1454	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1511	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 9, "lockNo": 9, "slot_number": 41, "slot_label": "41"}	pending
1455	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1512	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 10, "lockNo": 10, "slot_number": 42, "slot_label": "42"}	pending
1456	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1513	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 11, "lockNo": 11, "slot_number": 43, "slot_label": "43"}	pending
1457	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1514	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 12, "lockNo": 12, "slot_number": 44, "slot_label": "44"}	pending
1458	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1515	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 13, "lockNo": 13, "slot_number": 45, "slot_label": "45"}	pending
1459	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1516	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 14, "lockNo": 14, "slot_number": 46, "slot_label": "46"}	pending
1460	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1517	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 15, "lockNo": 15, "slot_number": 47, "slot_label": "47"}	pending
1461	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1518	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 3, "boardNo": 3, "lock_no": 16, "lockNo": 16, "slot_number": 48, "slot_label": "48"}	pending
1462	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1519	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 1, "lockNo": 1, "slot_number": 49, "slot_label": "49"}	pending
1463	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1520	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 2, "lockNo": 2, "slot_number": 50, "slot_label": "50"}	pending
1464	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1521	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 3, "lockNo": 3, "slot_number": 51, "slot_label": "51"}	pending
1465	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1522	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 4, "lockNo": 4, "slot_number": 52, "slot_label": "52"}	pending
1466	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1523	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 5, "lockNo": 5, "slot_number": 53, "slot_label": "53"}	pending
1467	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1524	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 6, "lockNo": 6, "slot_number": 54, "slot_label": "54"}	pending
1468	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1525	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 7, "lockNo": 7, "slot_number": 55, "slot_label": "55"}	pending
1469	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1526	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 8, "lockNo": 8, "slot_number": 56, "slot_label": "56"}	pending
1470	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1527	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 9, "lockNo": 9, "slot_number": 57, "slot_label": "57"}	pending
1471	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1528	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 10, "lockNo": 10, "slot_number": 58, "slot_label": "58"}	pending
1472	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1529	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 11, "lockNo": 11, "slot_number": 59, "slot_label": "59"}	pending
1473	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1530	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 12, "lockNo": 12, "slot_number": 60, "slot_label": "60"}	pending
1474	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1531	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 13, "lockNo": 13, "slot_number": 61, "slot_label": "61"}	pending
1475	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1532	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 14, "lockNo": 14, "slot_number": 62, "slot_label": "62"}	pending
1476	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1533	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 15, "lockNo": 15, "slot_number": 63, "slot_label": "63"}	pending
1477	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1534	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 4, "boardNo": 4, "lock_no": 16, "lockNo": 16, "slot_number": 64, "slot_label": "64"}	pending
1478	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1535	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 1, "lockNo": 1, "slot_number": 65, "slot_label": "65"}	pending
1479	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1536	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 2, "lockNo": 2, "slot_number": 66, "slot_label": "66"}	pending
1480	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1537	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 3, "lockNo": 3, "slot_number": 67, "slot_label": "67"}	pending
1481	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1538	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 4, "lockNo": 4, "slot_number": 68, "slot_label": "68"}	pending
1482	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1539	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 5, "lockNo": 5, "slot_number": 69, "slot_label": "69"}	pending
1483	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1540	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 6, "lockNo": 6, "slot_number": 70, "slot_label": "70"}	pending
1484	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1541	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 7, "lockNo": 7, "slot_number": 71, "slot_label": "71"}	pending
1485	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1542	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 8, "lockNo": 8, "slot_number": 72, "slot_label": "72"}	pending
1486	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1543	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 9, "lockNo": 9, "slot_number": 73, "slot_label": "73"}	pending
1487	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1544	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 10, "lockNo": 10, "slot_number": 74, "slot_label": "74"}	pending
1488	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1545	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 11, "lockNo": 11, "slot_number": 75, "slot_label": "75"}	pending
1489	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1546	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 12, "lockNo": 12, "slot_number": 76, "slot_label": "76"}	pending
1490	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1547	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 13, "lockNo": 13, "slot_number": 77, "slot_label": "77"}	pending
1491	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1548	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 14, "lockNo": 14, "slot_number": 78, "slot_label": "78"}	pending
1492	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1549	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 15, "lockNo": 15, "slot_number": 79, "slot_label": "79"}	pending
1493	\N	1	\N	YBM		2026-07-02 23:00:53.865907	0	38	1550	{"type": "open_lock", "device_id": "101014", "deviceId": "101014", "board_no": 5, "boardNo": 5, "lock_no": 16, "lockNo": 16, "slot_number": 80, "slot_label": "80"}	pending
\.


--
-- Data for Name: phone_openids; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.phone_openids (id, phone, openid, created_at, updated_at, wechat_name, unionid) FROM stdin;
2	17722332233	oWrA81xyJP1aI7beoqhd2rxBGPfw	2026-06-28 15:30:04.779791	2026-06-28 15:30:04.779791		\N
321	17554760510	oWrA81yGgyQp6k0KArC2bDCg-AOo	2026-07-02 12:47:47.302534	2026-07-02 12:48:02.041464		
174	13460149121	oWrA816HTb34u_l7onE9K378FUeY	2026-07-02 07:47:32.183365	2026-07-02 07:47:49.415997		
178	15824752199	oWrA811Ywqe14WBCysW4hxNgAAxU	2026-07-02 07:47:50.480051	2026-07-02 07:48:05.356038		
182	15839055361	oLhbm2AXKx2eoxKIRnh8tdL9iZOs	2026-07-02 07:50:44.005903	2026-07-02 07:50:44.005903	AAA余兴华15839055361	
120	17838930615	oWrA814FpDvSeL8zrtGms5pmTL34	2026-07-01 11:57:20.341436	2026-07-01 11:57:35.125592		
183	19836582073	oWrA812v0tMAGKvDt_KYlQO1m2Y8	2026-07-02 07:56:29.830882	2026-07-02 07:56:38.810406		
122	18356795403	oWrA815X34Q0bdaJaGtxESJEC7cE	2026-07-01 11:57:20.859641	2026-07-01 11:57:35.417222		
119	15514642606	oWrA819Lx-sIzmvxY6tz8YZjwNIc	2026-07-01 11:57:19.313465	2026-07-01 11:57:36.37428		
123	17346902460	oWrA81xN1nYud88nFNzeIP1nvHzI	2026-07-01 11:57:27.793666	2026-07-01 11:57:38.01506		
192	18530783963	oWrA81xX8hez494yZ9-kMOkXXQ4c	2026-07-02 08:04:18.333854	2026-07-02 08:04:29.447663		
187	15515613024	oWrA810DW_yygbMfuYYQvU640g6M	2026-07-02 08:03:38.217585	2026-07-02 08:03:53.318042		
189	15836489131	oWrA810QKe4UvoUGtbjxzCCAvRLs	2026-07-02 08:03:41.394975	2026-07-02 08:03:55.522663		
16	17726689234	oWrA81xyJP1aI7beoqhd2rxBGPfw	2026-06-30 07:11:10.210251	2026-07-01 07:59:36.426039		
98	13655676086	oLhbm2ELXC34oFmP0lsNf1Ot1iCA	2026-07-01 08:02:52.054731	2026-07-01 08:02:52.054731		
180	15993979586	oWrA814HKJCkcV1qPzdiW-kGgh0Q	2026-07-02 07:48:36.725436	2026-07-02 08:05:23.635819		
99	15090698884	oWrA810fvi3viiR0SZjFt8saWwj8	2026-07-01 08:32:50.939626	2026-07-01 08:33:05.276099		
101	19261605685	oWrA813GNHV6SjKHLTefeayzCI1E	2026-07-01 08:33:55.912587	2026-07-01 08:34:08.528142		
196	19245821928	oWrA813mcLnMvQmNYtkVPU8VQKmA	2026-07-02 08:08:14.896856	2026-07-02 08:08:26.483958		
25	18983079797	oWrA81-sAdleVupXM1QWH2jwpywk	2026-06-30 09:30:24.412491	2026-06-30 09:50:22.169829		\N
103	17838863123	oWrA814e5qmXK53w6jTxGFCQvrMo	2026-07-01 08:40:51.950467	2026-07-01 08:41:05.985587		
168	16650694701	oLhbm2FsOXehsq0hbDNTlmOLSS5E	2026-07-02 07:46:04.295465	2026-07-02 08:11:23.376189	瘦肉丸	
108	13854016305	oLhbm2EZ1nbD-lprp6bYvqdQFXzU	2026-07-01 08:58:37.582411	2026-07-01 08:58:37.582411	ㅤ	
39	19905939796	oWrA81x-B7qKpyyzunCQ79w_44Uo	2026-06-30 10:15:22.039783	2026-06-30 10:15:22.039783		\N
200	19339616898	oWrA814uiMq24c_vGENp0TEARkKA	2026-07-02 08:14:38.77355	2026-07-02 08:14:52.809504		
109	18705206991	oWrA819Zjec3Z04Pb-rAgMOQ-nsE	2026-07-01 09:04:46.986406	2026-07-01 09:05:03.77862		
202	15839096977	oWrA815egAE_pNywyzuTiI4e2OZQ	2026-07-02 08:15:46.872428	2026-07-02 08:16:03.544341		
117	15136012752	oWrA816c_JmOH0j8iJ0Icdo59A48	2026-07-01 11:57:14.978019	2026-07-01 11:57:59.11488		
23	18996093393	oWrA819aVj0AQxk0XRwFiuGi9W5k	2026-06-30 09:11:11.151822	2026-07-01 09:21:52.054618		
114	19353007158	oWrA81zy0WL9Bq00aBnawZAVr48g	2026-07-01 10:13:36.369454	2026-07-01 10:13:56.910577		
204	19837087059	oWrA813midBHJj2gaaxjeVGWHyFo	2026-07-02 08:16:22.208233	2026-07-02 08:16:37.919754		
48	15550752925	oWrA8105UJTohMvSF-xYM6nVUWOA	2026-06-30 12:39:43.421461	2026-06-30 12:39:43.421461		\N
49	18254067609	oWrA81yIpUhQohO1TptlV1HLGlGU	2026-06-30 12:39:52.176612	2026-06-30 12:39:52.176612		\N
50	15617060696	oWrA81w-5cgkKNolzfRIie4yxyu0	2026-06-30 12:39:55.144986	2026-06-30 12:39:55.144986		\N
51	18865018110	oWrA816FjsBSQwPthTIM5WXpjYVI	2026-06-30 12:40:04.701644	2026-06-30 12:40:04.701644		\N
52	15098366660	oWrA814SNv6vojll-l7fnoshhlRk	2026-06-30 12:41:50.269223	2026-06-30 12:41:50.269223		\N
132	15554513417	oWrA8120rleeG_cU57X62VK9CytA	2026-07-01 11:57:57.364828	2026-07-01 11:58:09.408687		
54	18265005796	oWrA81-ItgTPxpuU_KnmJnRQIZc8	2026-06-30 12:51:27.043021	2026-06-30 12:51:39.340206		\N
56	18326741968	oWrA81xM1eyqfXkFpnjHU05ps_LU	2026-06-30 12:52:07.490643	2026-06-30 12:52:07.490643		\N
57	15657821278	oWrA8119oPBjRQBBnEdipGqRawa8	2026-06-30 13:04:37.433039	2026-06-30 13:04:37.433039		\N
58	19286022436	oWrA81yNEVUEKWc7GIPodzG2yGXE	2026-06-30 13:05:08.587031	2026-06-30 13:05:14.984333		\N
60	18637010208	oWrA8123pVky5DBpbOF-0YgfVVOA	2026-06-30 13:13:07.638923	2026-06-30 13:13:07.638923		\N
61	15275043796	oWrA817RU4v8eQ-ItnK1Sjcj3d7Q	2026-06-30 13:29:26.693839	2026-06-30 13:29:34.918138		\N
63	18438398466	oWrA812I_KJbezJSGRt8wnBfzK4s	2026-06-30 13:31:13.990218	2026-06-30 13:31:13.990218		\N
64	18953074181	oWrA811vea15wVBi1JfZ3bWsqaQU	2026-06-30 13:46:06.806399	2026-06-30 13:46:14.300522		\N
67	13791463202	oWrA819H2B8_mgblRP2ZpM42vNUY	2026-06-30 13:48:57.834205	2026-06-30 13:48:57.834205		\N
68	19693594027	oWrA81xxlAxojDpUE3Q5nxIdLaSA	2026-06-30 14:01:07.382151	2026-06-30 14:01:07.382151		\N
69	15225299085	oWrA81_esql0oaMLcsIiLopvL1Ro	2026-06-30 14:15:27.970106	2026-06-30 14:15:27.970106		\N
70	19137096192	oWrA81wqfJhuq3HGJQDiZ2Ak3Tfs	2026-06-30 14:16:41.440176	2026-06-30 14:16:41.440176		\N
71	19544562686	oWrA814ZbDx9Sa3EUrwREReSYPhY	2026-06-30 14:18:26.599021	2026-06-30 14:18:26.599021		\N
72	17837383155	oWrA819WcGgl_cqgsG8_eviSMIC4	2026-06-30 14:48:03.229392	2026-06-30 14:48:03.229392		\N
73	15836435632	oWrA817pPlLyzrGVF3-hC7nUqcmM	2026-06-30 15:25:08.618728	2026-06-30 15:25:08.618728		\N
206	19139362917	oWrA81xA9gzh57QS5csiBbNkTPGE	2026-07-02 08:16:51.255216	2026-07-02 08:17:05.466995		
208	15637001160	oLhbm2EnsrO-ZkeR8tHm0hY6gCY8	2026-07-02 08:17:37.931903	2026-07-02 08:17:37.931903	联通路子欣15637001160	
209	19139066893	oLhbm2EPNzH7fIg51R4voCEe1yiY	2026-07-02 08:18:07.562225	2026-07-02 08:18:07.562225	Gad	
210	18738065631	oWrA8184R5USheUKUd6aNfRal1fM	2026-07-02 08:23:39.526939	2026-07-02 08:23:50.642096		
106	17861769100	oWrA817c8U3V_yL3p7whB9YfxycQ	2026-07-01 08:53:22.055101	2026-07-01 11:57:18.65765		
156	15186672778	oWrA81_Kec6OckOEGFtA4JK6ivgE	2026-07-01 13:06:26.424801	2026-07-01 13:06:53.051267		
212	18838441692	oWrA816aueWI5e_0YLIs67waiWBQ	2026-07-02 08:32:20.216032	2026-07-02 08:32:40.084019		
135	18238060772	oWrA8165UBZ7Orymi-LSK1VjzqzQ	2026-07-01 11:58:13.329227	2026-07-01 11:58:29.832371		
136	19165928949	oWrA81zIpOyNSHnd_FrJiX9XLyMA	2026-07-01 11:58:24.390965	2026-07-01 11:58:34.642961		
215	15539090389	oWrA812YRQLw0X9WUZStfvUrtwOA	2026-07-02 08:32:42.164061	2026-07-02 08:33:01.626679		
216	15660700620	oWrA818dHKZ_5gHq_XAXghC3Hpic	2026-07-02 08:32:58.29472	2026-07-02 08:33:07.76614		
139	19025302365	oWrA81ycBLSSc4MBzuD4oFZuMBfo	2026-07-01 11:58:34.9853	2026-07-01 11:58:49.34042		
125	15054012361	oWrA815CE4K5rUqMmftCAJTm1S30	2026-07-01 11:57:32.374244	2026-07-01 11:58:49.642462		
140	15798651828	oWrA81zv-1BW57sCu570qx28bQgA	2026-07-01 11:58:38.167899	2026-07-01 11:58:49.999201		
145	15964428331	oWrA816xdTuUlnwYSMz_AD2X4m88	2026-07-01 11:59:16.940547	2026-07-01 11:59:16.940547		
219	19233600317	oWrA8177WxIeNqyqQzQDe3yP2Y58	2026-07-02 08:33:52.354671	2026-07-02 08:34:05.910732		
220	19913257953	oWrA81zbmnzK7nJjzMnagrb8bojM	2026-07-02 08:33:53.165034	2026-07-02 08:34:06.772879		
223	13183298887	oWrA815ug_YJ7QxjM61cAsF7JcNU	2026-07-02 08:34:22.888711	2026-07-02 08:34:35.979887		
225	15909265992	oWrA818VHew3gFO623fbttvT6txM	2026-07-02 08:35:39.807491	2026-07-02 08:35:56.032986		
146	18137063193	oWrA81--Z4Op2Q70yCPLojW8e2Ns	2026-07-01 12:04:53.841121	2026-07-01 12:07:10.931332		
154	18691666092	oWrA811jjTbF5LBNF3y4f5Vds2CE	2026-07-01 12:56:00.202109	2026-07-01 12:56:09.886083		
227	13783560310	oWrA81xGKZXuj6d1GJzKvmxZ1W7I	2026-07-02 08:36:27.0525	2026-07-02 08:36:44.139731		
158	18336926660	oWrA818XVpD8LoLHNMkgx7tfHTCE	2026-07-01 14:18:03.336091	2026-07-01 14:18:20.03357		
161	18439030153	oWrA817SgAsGAcHjpLZsg9x3poLk	2026-07-01 14:54:26.313785	2026-07-01 14:54:36.765629		
74	15238586310	oWrA816bz5qUV3jcjZcEuRMHFH44	2026-06-30 15:30:36.37806	2026-07-02 10:57:39.064047		
166	15837068521	oWrA817JN3Bz9532eCCUzjuU7x-0	2026-07-02 07:45:55.328565	2026-07-02 07:46:23.960562		
170	15103773844	oWrA816r2XDtvPrsYSYu7CYL3Jh4	2026-07-02 07:46:12.696927	2026-07-02 07:46:26.269172		
229	19836511038	oWrA8165r_1j3OPLw-g-gCViRQMs	2026-07-02 08:42:20.915876	2026-07-02 08:42:33.415544		
231	19337028036	oWrA812oTTIp1f3twgeW-_0xEtgs	2026-07-02 08:44:40.722362	2026-07-02 08:44:52.921229		
185	13557288765	oWrA811Qp4IUIc8nb3HcQAyb4Fic	2026-07-02 08:02:25.041922	2026-07-02 11:43:46.49992		
233	15842660777	oWrA810Y8WflOSvGD02abudm10Ag	2026-07-02 08:45:00.520142	2026-07-02 08:45:12.72544		
324	15265092163	oLhbm2GiCaKhEaaqfMQbOunafSCo	2026-07-02 13:40:39.832415	2026-07-02 13:40:39.832415	L	
237	18133317626	oLhbm2FZ9P28KBn5ApgCiGpMs5r0	2026-07-02 08:48:02.318493	2026-07-02 08:48:02.318493	青衫湿	
235	15239932935	oWrA816T8KS6QqBABmZa2xuqWmTY	2026-07-02 08:47:52.660964	2026-07-02 08:48:04.54596		
239	18137062351	oWrA812OXNMzRfoAM_-w9lTAf0J8	2026-07-02 08:55:49.299483	2026-07-02 08:56:05.44882		
241	15751766581	oWrA811t76_2yyWusSObq9nSrfcg	2026-07-02 09:00:33.116898	2026-07-02 09:00:45.606248		
326	15136011309	oWrA814a2nNpcpm6wn0rsN5_cl1Y	2026-07-02 13:41:04.34347	2026-07-02 13:41:17.188334		
243	18338751797	oWrA811zMPTqnGWHvmqlBfn2wwJA	2026-07-02 09:08:27.2897	2026-07-02 09:08:40.475912		
328	15939273255	oWrA81-P8o1xlaZJIc_VsRJwp1Iw	2026-07-02 13:41:32.389606	2026-07-02 13:41:53.748373		
329	13323972142	oWrA81yzw_POSOjDnBWrj73937C4	2026-07-02 13:41:48.640459	2026-07-02 13:41:59.944261		
332	17527227908	oWrA817nAVIOva_3x9Nr-Oomqvv8	2026-07-02 13:54:24.788886	2026-07-02 13:54:35.258286		
250	18530272656	oWrA816oaku14e9dBVLjDIMnnfX8	2026-07-02 09:27:15.349502	2026-07-02 09:27:26.431592		
248	19840015972	oWrA818KJlRo33yjDQXZUXyc1SA8	2026-07-02 09:27:11.447207	2026-07-02 09:27:31.141818		
247	18836568219	oWrA811XkchsEFE3FOiVex5RHtZA	2026-07-02 09:27:09.385903	2026-07-02 09:27:32.153054		
334	17698950605	oWrA819UjvsavRe5EzlNKw46Eqo4	2026-07-02 14:02:17.671631	2026-07-02 14:02:36.990631		
255	19149247152	oWrA816FYQPXOeLqf4Jf17S8y3V4	2026-07-02 09:27:34.502947	2026-07-02 09:27:49.022637		
256	15695672792	oWrA817KtvSu6zXKQJJUqYJb9UTg	2026-07-02 09:27:46.829425	2026-07-02 09:28:02.563617		
259	17627072353	oLhbm2M3LzSrgB2-BYQJKN1dQ5U8	2026-07-02 09:28:30.698216	2026-07-02 09:28:30.698216	海᳐蒂᳐੭ 🇨🇳	
305	15937086006	oWrA8121MDcJ_BFR0HwO-FrCDkoU	2026-07-02 10:58:35.392994	2026-07-02 10:58:50.874115		
260	18736838325	oWrA81wGkKUTMb3SpY4-FDmVsEwQ	2026-07-02 09:28:40.602352	2026-07-02 09:28:53.07823		
298	18530250688	oWrA8193Mm87lcVp84Wv7r0UNEyQ	2026-07-02 10:46:10.960463	2026-07-02 14:03:18.200042		
263	18272685238	oWrA814xoEvsso80LHMIF3J9Beiw	2026-07-02 09:29:33.88391	2026-07-02 09:29:50.46119		
245	13213132919	oLhbm2L_VX83kwHGtp10m_uZhTlU	2026-07-02 09:14:14.84427	2026-07-02 09:34:18.927755	许立业	
267	18513686701	oWrA815kB7bWZbwC9RHh3L3qZF6g	2026-07-02 09:36:14.220791	2026-07-02 09:36:24.241412		
266	15237883857	oWrA813ogxC3GhKPZQZ47Ag8lE3Q	2026-07-02 09:36:10.054425	2026-07-02 09:36:25.340143		
270	19850171704	oWrA81wJNprd-lhv0B7zEZGRpR8Q	2026-07-02 10:00:50.59639	2026-07-02 10:01:11.026855		
338	18455712691	oWrA817WlHfrZUcskfKLMmqTuZCI	2026-07-02 14:07:24.53981	2026-07-02 14:07:36.571477		
272	15343725078	oWrA81_QYIhpTnIP_MguSINPWeMQ	2026-07-02 10:03:48.309019	2026-07-02 10:04:00.075506		
339	19337089231	oWrA815sx6kJjrzjGgTlP1ybY5UM	2026-07-02 14:07:28.648881	2026-07-02 14:07:50.349961		
343	18039160828	oWrA810XuBZkcAV8pyGXYUhpCLA4	2026-07-02 14:07:44.561266	2026-07-02 14:07:56.407147		
281	17550270621	oWrA818pWmo_jLWCMOI9N82JPLSQ	2026-07-02 10:17:24.197477	2026-07-02 10:17:38.713882		
308	17753648530	oWrA815j2zKUz_ITVwi98Zz3XETg	2026-07-02 11:20:11.433126	2026-07-02 14:08:06.988567		
277	13523176144	oWrA817TcXvAw-MlNurmpFzu7MTY	2026-07-02 10:15:10.894043	2026-07-02 10:23:24.112493		
285	15065370778	oWrA81wuBCqHNzGr9sDF-wFXJp2I	2026-07-02 10:26:30.723481	2026-07-02 10:26:50.429352		
350	18272662178	oWrA810A_OcB_7y5WIAkbKFcoIQg	2026-07-02 14:08:27.279248	2026-07-02 14:08:38.561851		
287	15836493002	oWrA81_rFRm7u2X-oilv9yZLkMQY	2026-07-02 10:27:22.951122	2026-07-02 10:27:42.456683		
291	15082976378	oLhbm2PocIcfNQ4WGD1NSHqtUbx0	2026-07-02 10:30:04.91418	2026-07-02 10:30:04.91418	H	
357	13037508763	oWrA81wO1786IWNXq1FDGLhLNzFs	2026-07-02 14:35:44.307886	2026-07-02 14:35:57.939076		
352	15137051381	oWrA813UlMB5Lcgr348eJ_7sgGrg	2026-07-02 14:15:11.524175	2026-07-02 14:15:25.183241		
292	18237036782	oWrA81_LWtK9aJ8SZef2ODkoIZrc	2026-07-02 10:33:15.257147	2026-07-02 10:33:28.87613		
293	18260768573	oWrA816Cp9pI4S2Z4a357GgTeImc	2026-07-02 10:33:18.36515	2026-07-02 10:33:29.825258		
288	15938352984	oWrA81yXA2cIn-m6OHGbotLqLQi0	2026-07-02 10:27:34.916997	2026-07-02 10:43:08.891057		
355	15236859855	oWrA814i0R3Twjzkz8oJauUChfEY	2026-07-02 14:20:39.486206	2026-07-02 14:20:49.967898		
301	13856712830	oLhbm2Juw9wVRI4ZXSEYhrRw5pTY	2026-07-02 10:48:34.695899	2026-07-02 10:48:34.695899	J	
300	15617023131	oWrA81-IRSJObx78pJHOh_rAdMCc	2026-07-02 10:48:21.547908	2026-07-02 10:48:36.713287		
359	17739015172	oWrA816i6Sh2fGUYosFrRUlooqU4	2026-07-02 14:37:34.374525	2026-07-02 14:37:44.363265		
361	15737005525	oLhbm2NF1iiboWasqwEiXBWviqQc	2026-07-02 14:37:54.076861	2026-07-02 14:37:54.076861	一拳打穿地球	
313	15660881573	oWrA817WxsE5e2yQdyUtmMPIYRrQ	2026-07-02 11:28:42.739358	2026-07-02 11:29:02.524857		
367	15690868029	oWrA818JXY2ke-_WwcrdF-38BRyE	2026-07-02 14:39:13.733442	2026-07-02 14:56:04.629987		
315	18253020029	oWrA815n0urc4XyC3tj_9X4Q-Cuc	2026-07-02 11:30:00.78677	2026-07-02 11:30:33.406211		
362	19037881852	oWrA813XY9444KQ-jha8DDs9QkJM	2026-07-02 14:38:55.576195	2026-07-02 14:39:05.84217		
364	15836704325	oWrA811dZeSPnohPZAUJrsoSyVCk	2026-07-02 14:39:00.284299	2026-07-02 14:39:12.130351		
369	17555309098	oWrA815i3m7PT-6lU3FM6eLjv3wM	2026-07-02 14:45:25.936916	2026-07-02 14:46:00.564801		
371	15603705779	oWrA814Am6sA-8OcprrgCQGFPMOM	2026-07-02 14:48:03.906957	2026-07-02 14:49:02.837992		
381	15919267157	oWrA815JUJ37T0UZRAH3stjwiNZM	2026-07-02 15:03:09.897187	2026-07-02 15:03:17.811971		
382	13619875632	oWrA812bIt3wABkRP5W74pZqnzAM	2026-07-02 15:03:16.033056	2026-07-02 15:03:26.330629		
345	19639308701	oWrA81-zeWU3yEM4u6Kbk8NxGWc4	2026-07-02 14:07:54.670236	2026-07-02 15:03:32.494221		
387	18738086168	oWrA816eRP5_FiWPMOi70wsPN4vY	2026-07-02 15:03:37.056582	2026-07-02 15:03:51.302862		
396	19251695576	oWrA812HZXwlQ55AENyFFBYx3a-c	2026-07-02 15:29:02.899652	2026-07-02 15:29:20.993546		
389	17838825515	oWrA81-HaXjCIpJLaElFsOc2c2gY	2026-07-02 15:07:59.351756	2026-07-02 15:08:13.428977		
392	15560048291	oWrA8153eXe4paFZN2xGYV_sT0wc	2026-07-02 15:13:49.952617	2026-07-02 15:13:59.688966		
394	17530271182	oWrA811TwH7MogCPmuLm7kYsr9SE	2026-07-02 15:21:33.4107	2026-07-02 15:21:44.580638		
406	18238033278	oLhbm2HZkvXVQ6v_cybMC7LG5-xQ	2026-07-02 15:37:48.411506	2026-07-02 15:37:48.411506	_.	
401	17634328712	oWrA81ztTXW1He3CfMl8mOG2feqM	2026-07-02 15:33:25.596291	2026-07-02 15:33:47.192564		
407	19273906997	oWrA811nPB5h_tQVxuI4CzaD3ZX4	2026-07-02 15:38:54.485183	2026-07-02 15:39:03.972509		
323	17503709333	oWrA81z7APIi80z5qbuLjBW44FMA	2026-07-02 13:40:39.186197	2026-07-02 15:41:24.898339		
411	19913817011	oWrA812nZV4AU4uKQLkUP2jOojkg	2026-07-02 15:53:28.969554	2026-07-02 15:53:47.454358		
413	16692633387	oWrA81z4E1a6VqllQU0uvYd8zzwk	2026-07-02 15:55:02.895704	2026-07-02 15:55:19.815303		
426	18888889999	oWrA81-wvf2HDTxBYtigtDeifFYs	2026-07-02 22:05:28.473604	2026-07-02 22:05:35.25958		
3	13667618419	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	2026-06-29 17:03:50.202911	2026-07-02 22:03:39.53786	？？？	
\.


--
-- Data for Name: remote_open_logs; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.remote_open_logs (id, merchant_id, cabinet_id, device_id, slot_id, slot_number, action_type, operator, result, success, ip_address, created_at) FROM stdin;
1	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:11
2	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:19
3	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:25
4	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:40
5	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-19 07:41:54
6	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:57:00
7	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 07:57:06
8	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 08:06:49
9	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-19 08:07:01
10	\N	\N	\N	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:42:00
11	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:43:59
12	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:48:37
13	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:51:17
14	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 08:56:00
15	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:36:55
16	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:46:50
17	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:51:45
18	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 10:53:47
19	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 12:34:41
20	\N	\N	123456	1	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
21	\N	\N	123456	2	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
22	\N	\N	123456	3	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
23	\N	\N	123456	4	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
24	\N	\N	123456	5	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
25	\N	\N	123456	6	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
26	\N	\N	123456	7	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
27	\N	\N	123456	8	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
28	\N	\N	123456	9	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
29	\N	\N	123456	10	\N	admin_batch_open	admin	success	1	\N	2026-06-19 15:54:14
30	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 15:56:00
31	\N	\N	123456	1	\N	admin_batch_open	admin	success	1	\N	2026-06-19 16:07:22
32	\N	\N	123456	2	\N	admin_batch_open	admin	success	1	\N	2026-06-19 16:07:22
33	\N	\N	123456	3	\N	admin_batch_open	admin	success	1	\N	2026-06-19 16:07:22
34	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 16:07:22
35	\N	\N	test	1	1	emergency_open	\N	success	1	\N	2026-06-19 16:43:59
36	\N	\N	123456	1	1	emergency_open	\N	success	1	\N	2026-06-20 00:50:25
37	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 22:21:48
38	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-19 22:23:28
39	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 02:50:47
40	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 02:58:54
41	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:01:38
42	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:02:07
43	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:30:31
44	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:32:56
45	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:33:42
46	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 03:43:31
47	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:13:41
48	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-20 04:13:48
49	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:14:13
50	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:14:21
51	\N	\N	123456	1	\N	admin_open	admin	success	1	\N	2026-06-20 04:17:51
52	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-20 04:25:38
53	\N	\N	123456	98	\N	admin_open	admin	success	1	\N	2026-06-20 04:25:54
54	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-20 10:36:31
55	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-20 22:34:47
56	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-20 22:35:12
57	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 02:03:43
58	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 02:03:57
59	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 02:04:09
60	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:38:48
61	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:40:07
62	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:51:33
63	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-21 07:54:04
64	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:55:17
65	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 07:55:34
66	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:00:02
67	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:10:13
68	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:10:40
69	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:22:38
70	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 08:29:29
71	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 13:04:31
72	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-21 13:05:22
73	\N	\N	123456	153	\N	admin_open	admin	success	1	\N	2026-06-21 13:06:10
74	\N	\N	123456	177	\N	admin_open	admin	success	1	\N	2026-06-21 13:07:43
75	\N	\N	123456	107	\N	admin_open	admin	success	1	\N	2026-06-21 15:08:05
76	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:25:26
77	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:27:37
78	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:31:56
79	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 04:49:25
80	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 04:49:29
81	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 05:57:34
82	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 05:57:58
83	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 06:08:20
84	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 09:19:12
85	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:19:16
86	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:14
87	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:19
88	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:23
89	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:28
90	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:34
91	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:40
92	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 09:20:45
93	\N	\N	123456	98	\N	admin_open	admin	success	1	\N	2026-06-22 10:52:11
94	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 10:52:17
95	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:22
96	\N	\N	123456	98	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:26
97	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:29
98	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 10:58:33
99	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 13:01:15
100	\N	\N	123456	97	\N	admin_open	admin	success	1	\N	2026-06-22 23:45:38
101	\N	\N	123456	108	\N	admin_open	admin	success	1	\N	2026-06-22 23:45:43
102	\N	\N	123456	145	\N	admin_open	admin	success	1	\N	2026-06-22 23:45:52
103	\N	\N	123456	145	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:01
104	\N	\N	123456	147	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:04
105	\N	\N	123456	148	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:08
106	\N	\N	123456	149	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:11
107	\N	\N	123456	153	\N	admin_open	admin	success	1	\N	2026-06-22 23:46:16
108	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 23:52:33
109	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-22 23:52:38
110	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 23:53:21
111	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-22 23:55:27
112	\N	\N	123456	96	\N	admin_open	admin	success	1	\N	2026-06-22 23:56:23
113	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-22 23:57:56
114	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:05:31
115	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:07:55
116	\N	\N	123456	153	\N	admin_open	admin	success	1	\N	2026-06-23 00:08:26
117	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:09:11
118	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:09:44
119	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:10:25
120	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:13:08
121	\N	\N	123456	95	\N	admin_open	admin	success	1	\N	2026-06-23 00:13:40
122	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:14:51
123	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:14:55
124	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:16:36
125	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:17:22
126	\N	\N	123456	94	\N	admin_open	admin	success	1	\N	2026-06-23 00:17:38
127	\N	\N	123456	152	\N	admin_open	admin	success	1	\N	2026-06-23 00:18:39
128	\N	\N	123456	93	\N	admin_open	admin	success	1	\N	2026-06-23 00:21:00
129	\N	\N	123456	152	\N	admin_open	admin	success	1	\N	2026-06-23 00:21:03
130	\N	\N	123456	270	\N	admin_open	admin	success	1	\N	2026-06-23 01:00:16
131	\N	\N	123456	271	\N	admin_open	admin	success	1	\N	2026-06-23 01:00:26
132	\N	\N	123456	287	\N	admin_open	admin	success	1	\N	2026-06-23 01:01:01
133	\N	\N	123456	288	\N	admin_open	admin	success	1	\N	2026-06-23 01:01:06
134	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-23 01:01:10
135	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 04:42:15
136	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 06:00:34
137	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 07:40:55
138	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 07:59:01
139	\N	\N	123456	270	\N	admin_open	admin	success	1	\N	2026-06-23 07:59:05
140	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-23 11:36:57
141	1	8	\N	261	7	emergency_open	\N	success	1	127.0.0.1	2026-06-24 00:43:00
142	\N	\N	123456	256	\N	admin_open	admin	success	1	\N	2026-06-24 01:37:24
143	\N	\N	123456	256	\N	admin_open	admin	success	1	\N	2026-06-24 03:11:29
144	\N	\N	123456	264	\N	admin_open	admin	success	1	\N	2026-06-24 03:44:42
145	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-24 10:07:01
146	\N	\N	123456	258	\N	admin_open	admin	success	1	\N	2026-06-25 08:49:43
147	1	8	\N	255	1	emergency_open	\N	success	1	127.0.0.1	2026-06-25 09:18:38
148	1	8	\N	255	1	emergency_open	\N	success	1	127.0.0.1	2026-06-25 09:18:41
149	1	8	\N	269	15	emergency_open	\N	success	1	127.0.0.1	2026-06-25 09:18:46
150	\N	\N	123456	271	\N	admin_open	admin	success	1	\N	2026-06-25 09:42:12
151	\N	\N	123456	272	\N	admin_open	admin	success	1	\N	2026-06-25 09:59:45
152	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 11:21:09
153	\N	\N	101002	352	\N	admin_open	admin	success	1	\N	2026-06-25 11:21:51
154	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 13:55:20
155	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 13:57:27
156	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:32
157	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:32
158	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:33
159	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:01:42
160	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:04:53
161	\N	\N	\N	13	\N	admin_open	admin	success	1	\N	2026-06-25 14:14:33
162	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:50:04
163	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:50:15
164	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:50:39
165	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:52:26
166	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:52:32
167	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:54:38
168	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:54:46
169	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-25 14:56:57
170	\N	\N	123456	284	\N	admin_open	admin	success	1	\N	2026-06-25 15:29:41
171	\N	\N	123456	286	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:01
172	\N	\N	123456	287	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:17
173	\N	\N	123456	288	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:23
174	\N	\N	123456	289	\N	admin_open	admin	success	1	\N	2026-06-25 22:29:27
175	\N	\N	123456	293	\N	admin_open	admin	success	1	\N	2026-06-25 22:30:46
176	\N	\N	123456	292	\N	admin_open	admin	success	1	\N	2026-06-25 22:30:50
177	\N	\N	123456	291	\N	admin_open	admin	success	1	\N	2026-06-25 22:30:53
178	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-25 22:31:51
179	\N	\N	123456	301	\N	admin_open	admin	success	1	\N	2026-06-25 22:31:57
180	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-25 22:32:00
181	\N	\N	123456	300	\N	admin_open	admin	success	1	\N	2026-06-25 22:32:04
182	\N	\N	123456	293	\N	admin_open	admin	success	1	\N	2026-06-25 22:39:13
183	\N	\N	123456	294	\N	admin_open	admin	success	1	\N	2026-06-25 22:57:24
184	\N	\N	123456	294	\N	admin_open	admin	success	1	\N	2026-06-25 23:11:40
185	\N	\N	123456	302	\N	admin_open	admin	success	1	\N	2026-06-25 23:11:45
186	\N	\N	123456	294	\N	admin_open	admin	success	1	\N	2026-06-25 23:36:02
187	\N	\N	101002	351	\N	admin_open	admin	success	1	\N	2026-06-26 00:42:23
188	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-26 00:47:02
189	\N	\N	123456	255	\N	admin_open	admin	success	1	\N	2026-06-26 00:50:45
190	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:34:58
191	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:34:58
192	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:34:58
193	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 01:35:17
194	\N	\N	123456	449	\N	admin_open	admin	success	1	\N	2026-06-26 01:35:20
195	\N	\N	123456	447	\N	admin_open	admin	success	1	\N	2026-06-26 02:38:40
196	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 06:42:11
197	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 06:47:18
198	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:02:50
199	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-26 07:02:59
200	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:26
201	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:52
202	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:54
203	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:56
204	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:42:58
205	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-26 07:43:01
206	\N	\N	100100	380	\N	admin_open	admin	success	1	\N	2026-06-26 07:43:04
207	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:58:00
208	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 07:58:02
209	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-26 07:58:04
210	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 18:00:47.25663
211	\N	\N	100100	368	\N	admin_open	admin	success	1	\N	2026-06-26 18:02:49.428502
212	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 18:03:04.666112
213	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 18:09:25.559611
214	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 19:31:02.96323
215	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 19:31:07.474492
216	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:47:07.639074
217	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:47:18.988
218	\N	\N	100100	367	\N	admin_open	admin	success	1	\N	2026-06-26 19:51:55.59031
219	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:54:39.18208
220	\N	\N	100100	365	\N	admin_open	admin	success	1	\N	2026-06-26 19:54:45.935272
221	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-26 19:54:50.053577
222	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-26 19:55:26.839841
223	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 06:35:47.700775
224	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 06:36:00.425405
225	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 07:07:46.863249
226	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 07:07:56.974742
227	\N	\N	100100	366	\N	admin_open	admin	success	1	\N	2026-06-27 07:08:03.695459
228	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-27 09:31:15.5171
229	\N	\N	100100	352	\N	admin_open	admin	success	1	\N	2026-06-27 09:34:43.557133
230	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 10:03:35.824128
231	\N	\N	100100	365	\N	admin_open	admin	success	1	\N	2026-06-27 10:03:41.08763
232	\N	\N	100100	369	\N	admin_open	admin	success	1	\N	2026-06-27 10:03:58.509552
233	\N	\N	100100	382	\N	admin_open	admin	success	1	\N	2026-06-27 10:04:08.579255
234	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:17:24.043736
235	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:17:31.858963
236	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:17:51.915017
237	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:18:10.678942
238	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:18:32.586337
239	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:18:56.349357
240	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:20:28.687406
241	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:24:21.048594
242	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:24:44.709947
243	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:25:12.098877
244	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:25:33.222225
245	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:27:03.063312
246	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:27:19.749983
247	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:34:39.219236
248	\N	\N	101001	464	\N	admin_open	admin	success	1	\N	2026-06-27 11:35:05.419812
249	\N	\N	101001	472	\N	admin_open	admin	success	1	\N	2026-06-27 11:36:49.888779
250	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:40:26.06909
251	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 11:40:35.438744
252	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 11:55:37.797842
253	\N	\N	100100	351	\N	admin_open	admin	success	1	\N	2026-06-27 11:55:46.059861
254	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:56:21.144599
255	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:59:35.689044
256	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:59:49.166442
257	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-27 11:59:55.756528
258	\N	\N	100100	504	\N	admin_open	admin	success	1	\N	2026-06-27 12:00:00.363297
259	\N	\N	100100	504	\N	admin_open	admin	success	1	\N	2026-06-27 12:00:04.704309
260	\N	\N	100100	496	\N	admin_open	admin	success	1	\N	2026-06-27 12:32:08.114549
261	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:00:41.46164
262	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:00:49.816395
263	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:11:11.861336
264	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:12:07.682438
265	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:13:03.557823
266	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:19:48.827768
267	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:31:38.510832
268	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:42:31.732545
269	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 14:42:43.807844
270	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:15:32.294565
271	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:17:30.683167
272	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:17:47.831749
273	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:36:38.738447
274	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:36:45.303563
275	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 15:43:06.440158
276	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-27 22:44:59.262628
277	\N	\N	101001	463	\N	admin_open	admin	success	1	\N	2026-06-28 11:01:38.619476
278	\N	\N	100100	511	\N	admin_open	admin	success	1	\N	2026-06-29 14:10:11.866566
279	\N	\N	100100	526	\N	admin_open	admin	success	1	\N	2026-06-29 14:10:25.937038
280	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 14:27:08.84106
281	\N	\N	100100	510	\N	admin_open	admin	success	1	\N	2026-06-29 14:27:13.095342
282	\N	\N	100101	527	\N	admin_open	admin	success	1	\N	2026-06-29 17:58:49.935854
283	\N	\N	100101	527	\N	admin_open	admin	success	1	\N	2026-06-29 17:58:59.422955
284	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 18:01:47.919895
285	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 18:02:57.25271
286	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 18:34:55.13289
287	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 18:48:00.600876
288	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 19:07:16.434661
289	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 19:13:08.164342
290	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 19:13:19.927212
291	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 19:17:15.96919
292	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 19:49:48.533904
293	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 20:04:23.829393
294	\N	\N	100100	511	\N	admin_open	admin	success	1	\N	2026-06-29 20:11:47.030582
295	\N	\N	100100	512	\N	admin_open	admin	success	1	\N	2026-06-29 20:11:49.113197
296	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 21:06:15.866017
297	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-29 21:06:35.167651
298	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:17:05.307546
299	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:41:33.546361
300	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:42:09.393018
301	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:42:39.13946
302	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:43:24.708841
303	\N	\N	100100	512	\N	admin_open	admin	success	1	\N	2026-06-29 21:44:10.414823
304	\N	\N	100100	512	\N	admin_open	admin	success	1	\N	2026-06-29 21:44:15.14457
305	\N	\N	100100	512	\N	admin_open	admin	success	1	\N	2026-06-29 21:44:23.166384
306	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:45:20.151645
307	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:45:36.32817
308	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:46:10.721647
309	\N	\N	100100	504	\N	admin_open	admin	success	1	\N	2026-06-29 21:46:22.70543
310	\N	\N	100100	512	\N	admin_open	admin	success	1	\N	2026-06-29 21:46:24.689492
311	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:46:50.298239
312	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:47:01.325612
313	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:47:54.088397
314	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:48:14.637
315	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:49:09.383058
316	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-29 21:50:59.648433
317	\N	\N	100100	505	\N	admin_open	admin	success	1	\N	2026-06-29 22:54:37.302943
318	\N	\N	100100	505	\N	admin_open	admin	success	1	\N	2026-06-30 06:47:59.299396
319	\N	\N	100100	505	\N	admin_open	admin	success	1	\N	2026-06-30 07:02:42.822988
320	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-06-30 07:02:49.030649
321	\N	\N	100100	497	\N	admin_open	admin	success	1	\N	2026-06-30 07:02:57.262244
322	\N	\N	100100	496	\N	admin_open	admin	success	1	\N	2026-06-30 07:04:22.006839
323	\N	\N	100100	497	\N	admin_open	admin	success	1	\N	2026-06-30 07:04:22.376033
324	\N	\N	100100	498	\N	admin_open	admin	success	1	\N	2026-06-30 07:04:28.974208
325	\N	\N	100101	591	\N	admin_open	admin	success	1	\N	2026-06-30 08:45:45.965665
326	\N	\N	100100	516	\N	admin_open	admin	success	1	\N	2026-06-30 10:20:34.08443
327	\N	\N	100100	516	\N	admin_open	admin	success	1	\N	2026-06-30 10:20:42.44505
328	\N	\N	100100	517	\N	admin_open	admin	success	1	\N	2026-06-30 10:58:00.366525
329	\N	\N	100100	517	\N	admin_open	admin	success	1	\N	2026-06-30 10:58:58.868537
330	\N	\N	100101	620	\N	admin_open	admin	success	1	\N	2026-06-30 15:09:22.954176
331	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-07-01 07:58:45.14398
332	\N	\N	100103	703	\N	admin_open	admin	success	1	\N	2026-07-01 09:18:20.494348
333	\N	\N	100103	750	\N	admin_open	admin	success	1	\N	2026-07-01 09:18:26.651608
334	\N	\N	100103	704	\N	admin_open	admin	success	1	\N	2026-07-01 09:20:09.927958
335	\N	24	100101	640	50	merchant_open	merchant	success	1	127.0.0.1	2026-07-01 09:25:56.187867
336	\N	24	100101	639	49	merchant_open	merchant	success	1	127.0.0.1	2026-07-01 09:26:23.555534
337	\N	27	100103	714	12	merchant_open	merchant	success	1	127.0.0.1	2026-07-01 10:49:01.754935
338	\N	16	100100	495	1	merchant_open	merchant	success	1	127.0.0.1	2026-07-01 10:49:22.326546
339	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-07-01 18:40:21.791263
340	\N	\N	100100	495	\N	admin_open	admin	success	1	\N	2026-07-01 19:48:46.561166
341	\N	\N	100101	593	\N	admin_open	admin	success	1	\N	2026-07-02 09:59:08.464794
342	\N	\N	100101	642	\N	admin_open	admin	success	1	\N	2026-07-02 09:59:40.976026
343	\N	\N	100101	639	\N	admin_open	admin	success	1	\N	2026-07-02 09:59:54.214377
344	\N	\N	100101	642	\N	admin_open	admin	success	1	\N	2026-07-02 16:03:57.846507
\.


--
-- Data for Name: sms_codes; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.sms_codes (id, phone, code, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: storage_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.storage_records (id, cabinet_id, compartment_number, user_phone, access_code, status, store_time, retrieve_time, created_at) FROM stdin;
1	1	3	13844445555	1234	1	2026-06-12 12:52:38.906724	2026-06-12 12:52:39.193363	2026-06-12 04:52:39
2	1	4	13800001111	1111	1	2026-06-12 12:58:06.520154	2026-06-12 12:58:06.797935	2026-06-12 04:58:06
3	1	4	13877778888	9999	1	2026-06-12 13:07:27.142639	2026-06-12 13:07:27.422383	2026-06-12 05:07:27
4	8	10	17725196748	1234	2	2026-06-24 14:32:47.145958	2026-06-24 14:34:44.027213	2026-06-24 06:34:44
5	8	10	17725196748	1234	1	2026-06-24 14:32:47.145958	2026-06-24 14:34:57.748019	2026-06-24 06:34:57
6	8	A10	17725196748	1234	1	2026-06-24 15:33:30.907419	2026-06-24 17:57:15.690936	2026-06-24 09:57:15
7	8	A10	17725196748	1234	1	2026-06-24 15:33:30.907419	2026-06-24 20:08:58.563297	2026-06-24 12:08:58
8	8	A1	13667618419	2584	1	2026-06-24 22:37:34.737997	2026-06-24 22:39:50.475957	2026-06-24 14:39:50
9	8	A15	17725196748	1234	2	2026-06-25 17:24:49.211634	2026-06-25 17:27:38.913835	2026-06-25 09:27:38
10	8	A17	17725196748	1234	2	2026-06-25 17:39:37.186267	2026-06-25 17:42:32.72969	2026-06-25 09:42:32
11	8	A18	17725196748	1234	2	2026-06-25 17:47:03.188676	2026-06-25 17:48:56.614529	2026-06-25 09:48:56
12	8	A18	17725196748	1234	1	2026-06-25 17:47:03.188676	2026-06-25 17:49:10.749128	2026-06-25 09:49:10
13	8	A22	13667618419	1234	2	2026-06-25 21:07:31.636984	2026-06-25 21:36:27.913417	2026-06-25 13:36:27
14	8	A42	17726689234	1234	2	2026-06-26 07:07:04.286167	2026-06-26 07:29:38.957188	2026-06-25 23:29:38
15	8	A43	17726689234	1234	2	2026-06-26 07:30:04.21892	2026-06-26 07:34:24.71674	2026-06-25 23:34:24
16	8	4	18888889999	1234	1	2026-06-26 09:42:16.701258	2026-06-26 09:51:26.378147	2026-06-26 01:51:26
17	8	3	18888889999	1234	1	2026-06-26 09:36:04.314655	2026-06-26 09:51:58.611342	2026-06-26 01:51:58
18	8	6	18888889999	1234	1	2026-06-26 09:49:18.491913	2026-06-26 11:31:45.256536	2026-06-26 03:31:45
19	8	7	18888889999	1234	2	2026-06-26 13:13:40.256117	2026-06-26 13:17:38.140905	2026-06-26 05:17:38
20	8	7	18888889999	1234	1	2026-06-26 13:13:40.256117	2026-06-26 13:17:55.427649	2026-06-26 05:17:55
21	16	13	18888889999	1234	2	2026-06-26 19:52:41.308565	2026-06-26 19:55:06.79708	2026-06-26 19:55:06.794832
22	16	13	18888889999	1234	2	2026-06-26 19:52:41.308565	2026-06-26 19:55:19.183534	2026-06-26 19:55:19.181113
23	16	14	18888889999	1234	2	2026-06-26 20:34:40.996024	2026-06-26 20:38:20.736155	2026-06-26 20:38:20.733726
24	16	42	18888889999	1234	2	2026-06-27 10:04:22.568878	2026-06-27 10:07:53.971529	2026-06-27 10:07:53.969284
25	15	10	18996093393	1111	1	2026-06-27 11:21:51.938666	2026-06-27 11:37:31.395637	2026-06-27 11:37:31.393462
26	16	2	18888889999	1234	1	2026-06-27 12:30:01.700717	2026-06-27 12:37:46.547675	2026-06-27 12:37:46.545524
27	16	14	18888889999	1234	2	2026-06-28 07:50:13.359321	2026-06-28 07:51:05.05579	2026-06-28 07:51:05.053476
28	16	14	18888889999	1234	2	2026-06-28 07:50:13.359321	2026-06-28 07:51:22.960896	2026-06-28 07:51:22.95866
29	16	14	18888889999	1234	1	2026-06-28 07:50:13.359321	2026-06-28 07:51:52.073067	2026-06-28 07:51:52.0707
30	16	28	17722332233	2584	1	2026-06-28 15:29:57.720409	2026-06-28 15:31:16.549595	2026-06-28 15:31:16.547281
31	16	25	18888889999	1234	2	2026-06-28 14:51:55.54862	2026-06-28 15:32:12.795953	2026-06-28 15:32:12.793405
32	16	25	18888889999	1234	1	2026-06-28 14:51:55.54862	2026-06-28 15:32:31.404132	2026-06-28 15:32:31.401547
33	16	27	17722332233	1475	1	2026-06-28 15:22:56.856654	2026-06-28 15:34:04.539229	2026-06-28 15:34:04.537009
34	16	19	17722332233	1234	1	2026-06-28 08:45:59.421579	2026-06-28 15:34:06.147277	2026-06-28 15:34:06.144756
35	16	18	17722332233	3698	1	2026-06-28 08:41:05.289221	2026-06-28 15:34:07.976224	2026-06-28 15:34:07.974022
36	24	E1	18996093393	1111	1	2026-06-29 18:57:52.050962	2026-06-29 18:59:17.247001	2026-06-29 18:59:17.245909
37	16	32	13667618419	1234	2	2026-06-29 21:26:26.194231	2026-06-29 21:42:04.194226	2026-06-29 21:42:04.193277
38	16	32	13667618419	1234	1	2026-06-29 21:26:26.194231	2026-06-29 21:42:19.775018	2026-06-29 21:42:19.774136
39	16	19	13667618419	1234	1	2026-06-30 07:07:31.383625	2026-06-30 07:09:41.240801	2026-06-30 07:09:41.239736
40	16	11	13667618419	1234	1	2026-06-29 22:52:24.82795	2026-06-30 07:09:56.648032	2026-06-30 07:09:56.647077
41	16	9	13667618419	1234	1	2026-06-29 22:50:52.343292	2026-06-30 07:10:07.987463	2026-06-30 07:10:07.986451
42	16	23	17726689234	1234	1	2026-06-30 07:11:02.520772	2026-06-30 07:11:50.615626	2026-06-30 07:11:50.614245
43	16	25	17726689234	1234	1	2026-06-30 07:28:23.32169	2026-06-30 07:29:11.513319	2026-06-30 07:29:11.512131
44	16	28	17726689234	1234	1	2026-06-30 07:51:35.654789	2026-06-30 07:52:53.508899	2026-06-30 07:52:53.507574
45	24	E8	18996093393	1234	1	2026-06-30 09:03:54.10188	2026-06-30 09:05:10.563743	2026-06-30 09:05:10.56276
46	24	E9	18996093393	1234	1	2026-06-30 09:11:01.276431	2026-06-30 09:12:48.681011	2026-06-30 09:12:48.679925
47	24	E11	18983079797	1234	1	2026-06-30 09:30:15.203007	2026-06-30 09:31:20.677737	2026-06-30 09:31:20.676985
48	24	E15	18996093393	1234	1	2026-06-30 09:39:05.780707	2026-06-30 09:39:55.003171	2026-06-30 09:39:55.001795
49	16	12	17726689234	4265	1	2026-06-30 09:40:22.786174	2026-06-30 09:53:29.098988	2026-06-30 09:53:29.098118
50	16	18	17726689234	1234	1	2026-06-30 09:54:14.221902	2026-06-30 10:00:30.462017	2026-06-30 10:00:30.461167
51	16	22	17726689234	1234	2	2026-06-30 10:19:43.691053	2026-06-30 10:21:31.732258	2026-06-30 10:21:31.730278
52	16	22	17726689234	1234	2	2026-06-30 10:19:43.691053	2026-06-30 10:21:45.245931	2026-06-30 10:21:45.244904
53	16	22	17726689234	1234	1	2026-06-30 10:19:43.691053	2026-06-30 10:21:59.283675	2026-06-30 10:21:59.282638
54	24	E23	19905939796	8106	2	2026-06-30 10:14:59.088933	2026-06-30 10:53:37.799461	2026-06-30 10:53:37.798423
55	24	E23	19905939796	8106	1	2026-06-30 10:14:59.088933	2026-06-30 10:53:43.919655	2026-06-30 10:53:43.918668
56	16	23	17726689234	1234	1	2026-06-30 10:54:05.502862	2026-06-30 10:55:11.600232	2026-06-30 10:55:11.599401
57	16	27	17726689234	1234	1	2026-06-30 11:04:20.348808	2026-06-30 11:08:12.565185	2026-06-30 11:08:12.563787
58	16	28	17726689234	1234	1	2026-06-30 11:17:58.486108	2026-06-30 11:18:51.346839	2026-06-30 11:18:51.345815
59	24	E24	13667618419	1234	1	2026-06-30 11:26:39.555022	2026-06-30 11:30:18.842996	2026-06-30 11:30:18.840971
60	24	E26	13667618419	1234	1	2026-06-30 11:39:38.085987	2026-06-30 11:42:29.910952	2026-06-30 11:42:29.909578
61	16	29	17726689234	1234	1	2026-06-30 11:45:00.055863	2026-06-30 11:45:41.205097	2026-06-30 11:45:41.203741
62	24	E27	13667618419	1234	1	2026-06-30 12:04:30.058494	2026-06-30 12:05:19.907884	2026-06-30 12:05:19.90699
63	24	E29	13667618419	1234	1	2026-06-30 12:23:21.850439	2026-06-30 12:25:20.681237	2026-06-30 12:25:20.679456
64	24	E30	18265820019	0099	2	2026-06-30 12:38:06.906077	2026-06-30 12:42:03.16104	2026-06-30 12:42:03.160198
65	24	E44	18265005796	7878	2	2026-06-30 12:51:08.816958	2026-06-30 12:52:50.258867	2026-06-30 12:52:50.257887
66	24	E49	19286022436	6666	2	2026-06-30 13:04:51.133104	2026-06-30 13:06:22.755616	2026-06-30 13:06:22.754722
67	24	E47	15657821278	1314	2	2026-06-30 13:04:21.911241	2026-06-30 13:11:11.289929	2026-06-30 13:11:11.288889
68	24	E51	18637010208	1111	2	2026-06-30 13:12:51.853737	2026-06-30 13:14:16.476945	2026-06-30 13:14:16.475925
69	24	E51	18637010208	1111	2	2026-06-30 13:12:51.853737	2026-06-30 13:14:26.397012	2026-06-30 13:14:26.396095
70	24	E51	18637010208	1111	2	2026-06-30 13:12:51.853737	2026-06-30 13:20:02.004368	2026-06-30 13:20:02.003436
71	24	E47	15657821278	1314	1	2026-06-30 13:04:21.911241	2026-06-30 13:41:31.474064	2026-06-30 13:41:31.473033
72	24	E54	18438398466	8466	2	2026-06-30 13:30:57.276719	2026-06-30 13:46:04.435709	2026-06-30 13:46:04.434483
73	24	E53	15275043796	8011	2	2026-06-30 13:29:13.617642	2026-06-30 13:46:30.039567	2026-06-30 13:46:30.037521
74	16	31	17726689234	1234	2	2026-06-30 13:45:59.983915	2026-06-30 13:49:34.851634	2026-06-30 13:49:34.850596
75	16	31	17726689234	1234	1	2026-06-30 13:45:59.983915	2026-06-30 13:49:46.176206	2026-06-30 13:49:46.175068
76	24	E33	15550752925	2925	1	2026-06-30 12:39:32.545394	2026-06-30 13:51:57.650656	2026-06-30 13:51:57.649631
77	24	E53	15275043796	8011	2	2026-06-30 13:29:13.617642	2026-06-30 13:58:33.086826	2026-06-30 13:58:33.085831
78	24	E54	18438398466	8466	2	2026-06-30 13:30:57.276719	2026-06-30 14:02:34.429618	2026-06-30 14:02:34.428599
79	24	E54	18438398466	8466	2	2026-06-30 13:30:57.276719	2026-06-30 14:06:57.955625	2026-06-30 14:06:57.954273
80	24	E51	18637010208	1111	2	2026-06-30 13:12:51.853737	2026-06-30 14:10:57.383062	2026-06-30 14:10:57.382136
84	24	E51	18637010208	1111	2	2026-06-30 13:12:51.853737	2026-06-30 14:14:24.674435	2026-06-30 14:14:24.673478
85	24	E54	18438398466	8466	2	2026-06-30 13:30:57.276719	2026-06-30 14:15:06.129598	2026-06-30 14:15:06.128607
188	24	E13	15656087879	0808	2	2026-06-30 15:51:14.350607	2026-06-30 17:39:18.896291	2026-06-30 17:39:18.895683
87	24	E3	19544562686	1234	2	2026-06-30 14:18:12.222058	2026-06-30 14:19:22.053902	2026-06-30 14:19:22.052904
89	24	E53	15275043796	8011	2	2026-06-30 13:29:13.617642	2026-06-30 14:27:17.732956	2026-06-30 14:27:17.731543
90	24	E49	19286022436	6666	2	2026-06-30 13:04:51.133104	2026-06-30 14:31:28.783358	2026-06-30 14:31:28.782465
92	24	E30	18265820019	0099	2	2026-06-30 12:38:06.906077	2026-06-30 14:39:48.174274	2026-06-30 14:39:48.173322
94	24	E49	19286022436	6666	2	2026-06-30 13:04:51.133104	2026-06-30 14:41:39.478497	2026-06-30 14:41:39.477393
199	16	B32	13667618419	1234	1	2026-06-30 17:06:32.680209	2026-06-30 18:01:54.881842	2026-06-30 18:01:54.880741
198	16	B1	17726689234	1234	1	2026-06-30 17:14:40.953679	2026-06-30 18:01:14.41759	2026-06-30 18:01:14.416481
200	16	B6	17726689234	1234	1	2026-06-30 18:03:49.221853	2026-06-30 18:04:46.044111	2026-06-30 18:04:46.043121
201	16	B3	17726689234	1234	1	2026-06-30 18:03:08.846984	2026-06-30 18:04:49.568652	2026-06-30 18:04:49.5678
202	24	E13	15656087879	0808	1	2026-06-30 15:51:14.350607	2026-06-30 18:23:09.846589	2026-06-30 18:23:09.845366
203	16	B7	17726689234	1234	1	2026-06-30 18:44:08.337573	2026-06-30 18:45:23.615489	2026-06-30 18:45:23.614578
204	16	B9	17726689234	1234	1	2026-06-30 18:54:25.129048	2026-06-30 18:56:02.172187	2026-06-30 18:56:02.171276
111	24	E30	18265820019	0099	2	2026-06-30 12:38:06.906077	2026-06-30 15:02:53.876683	2026-06-30 15:02:53.875753
205	16	B14	17726689234	1234	1	2026-07-01 07:59:28.845326	2026-07-01 08:00:10.286957	2026-07-01 08:00:10.286068
206	24	E15	17726689234	1234	1	2026-07-01 07:55:30.013338	2026-07-01 08:01:35.545746	2026-07-01 08:01:35.544624
207	24	E17	13655676086	6699	2	2026-07-01 08:02:52.16279	2026-07-01 08:13:11.818946	2026-07-01 08:13:11.817845
208	24	E18	15090698884	1013	2	2026-07-01 08:32:51.021735	2026-07-01 08:38:27.858699	2026-07-01 08:38:27.857682
209	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 09:07:18.844164	2026-07-01 09:07:18.843211
210	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 09:08:55.75624	2026-07-01 09:08:55.75536
211	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 09:11:23.395673	2026-07-01 09:11:23.394821
119	24	E30	18265820019	0099	1	2026-06-30 12:38:06.906077	2026-06-30 15:09:03.912283	2026-06-30 15:09:03.911412
120	24	E46	18326741968	9999	1	2026-06-30 12:51:30.444471	2026-06-30 15:12:49.555653	2026-06-30 15:12:49.55469
121	24	E7	19254304011	4011	2	2026-06-30 14:52:56.59766	2026-06-30 15:14:19.02911	2026-06-30 15:14:19.027825
122	24	E44	18265005796	7878	1	2026-06-30 12:51:08.816958	2026-06-30 15:16:02.743389	2026-06-30 15:16:02.742288
123	24	E60	13791463202	1234	1	2026-06-30 13:48:46.550553	2026-06-30 15:17:35.703566	2026-06-30 15:17:35.702619
124	24	E49	19286022436	6666	1	2026-06-30 13:04:51.133104	2026-06-30 15:18:21.867044	2026-06-30 15:18:21.865765
125	24	E58	18953074181	1234	1	2026-06-30 13:45:55.349822	2026-06-30 15:29:00.86689	2026-06-30 15:29:00.865583
126	24	E5	17837383155	1111	1	2026-06-30 14:47:50.589861	2026-06-30 15:53:14.209131	2026-06-30 15:53:14.208293
127	24	E54	18438398466	8466	1	2026-06-30 13:30:57.276719	2026-06-30 15:54:09.751122	2026-06-30 15:54:09.750178
128	24	E56	15138943614	5219	1	2026-06-30 13:34:04.912326	2026-06-30 16:04:17.891388	2026-06-30 16:04:17.890288
129	24	E12	15238586310	2014	1	2026-06-30 15:30:14.440812	2026-06-30 16:04:59.131753	2026-06-30 16:04:59.130736
130	24	E9	15836435632	1128	1	2026-06-30 15:24:51.048001	2026-06-30 16:09:27.309733	2026-06-30 16:09:27.308745
131	24	E11	15324821187	1013	1	2026-06-30 15:27:26.746166	2026-06-30 16:10:06.640691	2026-06-30 16:10:06.63983
132	24	E3	19544562686	1234	1	2026-06-30 14:18:12.222058	2026-06-30 16:10:29.362563	2026-06-30 16:10:29.361524
133	24	E53	15275043796	8011	1	2026-06-30 13:29:13.617642	2026-06-30 16:12:23.935274	2026-06-30 16:12:23.934446
134	24	E2	19137096192	1223	1	2026-06-30 14:16:16.447977	2026-06-30 16:17:34.491611	2026-06-30 16:17:34.490627
135	24	E63	15225299085	1479	1	2026-06-30 14:15:11.916386	2026-06-30 16:18:10.689029	2026-06-30 16:18:10.688146
136	24	E51	18637010208	1111	1	2026-06-30 13:12:51.853737	2026-06-30 16:31:24.752387	2026-06-30 16:31:24.751435
212	24	E21	17838863123	5858	2	2026-07-01 08:40:52.996737	2026-07-01 09:27:11.274643	2026-07-01 09:27:11.273756
213	24	E21	17838863123	5858	2	2026-07-01 08:40:52.996737	2026-07-01 09:30:31.239099	2026-07-01 09:30:31.238179
214	24	E18	15090698884	1013	2	2026-07-01 08:32:51.021735	2026-07-01 10:10:52.465483	2026-07-01 10:10:52.464574
215	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 10:11:16.714865	2026-07-01 10:11:16.71375
216	24	E19	19261605685	1112	2	2026-07-01 08:33:56.393288	2026-07-01 10:11:51.965935	2026-07-01 10:11:51.965113
217	24	E21	17838863123	5858	2	2026-07-01 08:40:52.996737	2026-07-01 10:12:17.696557	2026-07-01 10:12:17.695632
218	24	E22	17861769100	0205	2	2026-07-01 08:53:22.131087	2026-07-01 10:12:46.113666	2026-07-01 10:12:46.112746
219	24	E19	19261605685	1112	2	2026-07-01 08:33:56.393288	2026-07-01 10:14:58.868018	2026-07-01 10:14:58.866991
220	24	E18	15090698884	1013	2	2026-07-01 08:32:51.021735	2026-07-01 10:15:47.556704	2026-07-01 10:15:47.554695
221	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 10:16:16.414879	2026-07-01 10:16:16.413952
222	24	E18	15090698884	1013	1	2026-07-01 08:32:51.021735	2026-07-01 10:25:55.516061	2026-07-01 10:25:55.515148
223	24	E21	17838863123	5858	2	2026-07-01 08:40:52.996737	2026-07-01 10:50:57.726484	2026-07-01 10:50:57.7251
224	24	E19	19261605685	1112	2	2026-07-01 08:33:56.393288	2026-07-01 10:51:24.665979	2026-07-01 10:51:24.665066
225	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 11:18:01.176426	2026-07-01 11:18:01.175459
226	24	E21	17838863123	5858	2	2026-07-01 08:40:52.996737	2026-07-01 11:33:59.329937	2026-07-01 11:33:59.329033
227	24	E19	19261605685	1112	2	2026-07-01 08:33:56.393288	2026-07-01 11:40:51.539616	2026-07-01 11:40:51.538096
228	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 11:42:20.164825	2026-07-01 11:42:20.163711
229	24	E19	19261605685	1112	2	2026-07-01 08:33:56.393288	2026-07-01 11:42:44.156329	2026-07-01 11:42:44.155395
230	24	E21	17838863123	5858	2	2026-07-01 08:40:52.996737	2026-07-01 11:54:30.619993	2026-07-01 11:54:30.619058
231	24	E21	17838863123	5858	2	2026-07-01 08:40:52.996737	2026-07-01 11:57:37.268773	2026-07-01 11:57:37.267916
232	24	E22	17861769100	0205	2	2026-07-01 08:53:22.131087	2026-07-01 11:57:58.066641	2026-07-01 11:57:58.065668
233	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 11:58:13.097662	2026-07-01 11:58:13.0967
234	24	E17	13655676086	6699	2	2026-07-01 08:02:52.16279	2026-07-01 11:58:40.488083	2026-07-01 11:58:40.487149
235	24	E30	18356795403	0710	2	2026-07-01 11:57:20.942864	2026-07-01 12:02:22.360082	2026-07-01 12:02:22.358942
236	24	E17	13655676086	6699	2	2026-07-01 08:02:52.16279	2026-07-01 12:02:32.606165	2026-07-01 12:02:32.60533
237	24	E38	18137063193	0370	2	2026-07-01 12:06:39.435663	2026-07-01 12:26:59.277505	2026-07-01 12:26:59.276605
238	24	E32	19165928949	2580	1	2026-07-01 11:58:24.483001	2026-07-01 12:35:19.707165	2026-07-01 12:35:19.706301
239	27	11	19025302365	0714	1	2026-07-01 11:58:35.082833	2026-07-01 12:39:03.622854	2026-07-01 12:39:03.622035
240	27	14	15964428331	0707	1	2026-07-01 11:59:00.289613	2026-07-01 12:40:02.395142	2026-07-01 12:40:02.394209
241	27	10	18238060772	1234	1	2026-07-01 11:58:13.984192	2026-07-01 12:40:31.316166	2026-07-01 12:40:31.315239
242	24	E29	17838930615	5474	1	2026-07-01 11:57:20.783064	2026-07-01 12:41:57.727618	2026-07-01 12:41:57.726626
243	27	5	15514642606	0303	1	2026-07-01 11:57:20.518413	2026-07-01 12:45:09.375659	2026-07-01 12:45:09.374782
244	27	12	15798651828	1215	1	2026-07-01 11:58:38.977152	2026-07-01 12:46:20.423065	2026-07-01 12:46:20.422248
245	24	E19	19261605685	1112	2	2026-07-01 08:33:56.393288	2026-07-01 12:49:33.827333	2026-07-01 12:49:33.826388
246	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 12:49:58.925658	2026-07-01 12:49:58.924687
247	24	E22	17861769100	0205	1	2026-07-01 08:53:22.131087	2026-07-01 12:51:21.31571	2026-07-01 12:51:21.314891
248	24	E38	18137063193	0370	2	2026-07-01 12:06:39.435663	2026-07-01 12:52:41.599441	2026-07-01 12:52:41.598764
249	24	E17	13655676086	6699	2	2026-07-01 08:02:52.16279	2026-07-01 12:52:53.306701	2026-07-01 12:52:53.305738
250	27	3	15136012752	0805	1	2026-07-01 11:57:15.050592	2026-07-01 12:55:33.340666	2026-07-01 12:55:33.339775
251	24	E38	18137063193	0370	2	2026-07-01 12:06:39.435663	2026-07-01 12:55:57.35569	2026-07-01 12:55:57.354691
252	24	E39	18691666092	0205	2	2026-07-01 12:56:00.303827	2026-07-01 13:02:45.396643	2026-07-01 13:02:45.395762
253	24	E38	18137063193	0370	2	2026-07-01 12:06:39.435663	2026-07-01 13:04:41.587974	2026-07-01 13:04:41.587295
254	27	13	15054012361	0000	1	2026-07-01 11:58:43.423569	2026-07-01 13:04:53.692859	2026-07-01 13:04:53.691973
255	24	E39	18691666092	0205	2	2026-07-01 12:56:00.303827	2026-07-01 13:06:10.487673	2026-07-01 13:06:10.486766
256	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 13:06:56.675065	2026-07-01 13:06:56.674192
257	27	6	17346902460	4599	1	2026-07-01 11:57:27.878248	2026-07-01 13:09:34.410947	2026-07-01 13:09:34.410003
258	24	E39	18691666092	0205	2	2026-07-01 12:56:00.303827	2026-07-01 13:10:31.939586	2026-07-01 13:10:31.938746
259	24	E17	13655676086	6699	2	2026-07-01 08:02:52.16279	2026-07-01 13:17:35.39759	2026-07-01 13:17:35.396716
260	24	E38	18137063193	0370	2	2026-07-01 12:06:39.435663	2026-07-01 13:17:59.578556	2026-07-01 13:17:59.57761
261	24	E30	18356795403	0710	2	2026-07-01 11:57:20.942864	2026-07-01 13:18:52.728231	2026-07-01 13:18:52.727375
262	24	E30	18356795403	0710	1	2026-07-01 11:57:20.942864	2026-07-01 13:22:57.310651	2026-07-01 13:22:57.309578
263	24	E38	18137063193	0370	2	2026-07-01 12:06:39.435663	2026-07-01 13:24:09.435295	2026-07-01 13:24:09.434213
264	27	9	15554513417	0704	1	2026-07-01 11:57:57.457779	2026-07-01 13:26:41.38197	2026-07-01 13:26:41.381057
265	24	E17	13655676086	6699	2	2026-07-01 08:02:52.16279	2026-07-01 13:30:09.08899	2026-07-01 13:30:09.087946
266	24	E17	13655676086	6699	1	2026-07-01 08:02:52.16279	2026-07-01 13:30:54.58761	2026-07-01 13:30:54.58668
267	24	E21	17838863123	5858	1	2026-07-01 08:40:52.996737	2026-07-01 13:33:42.599686	2026-07-01 13:33:42.598876
268	24	E40	15186672778	2580	1	2026-07-01 13:06:26.550151	2026-07-01 13:42:33.585761	2026-07-01 13:42:33.584659
269	24	E24	18705206991	3569	2	2026-07-01 09:04:47.083127	2026-07-01 13:47:31.06533	2026-07-01 13:47:31.064456
270	24	E38	18137063193	0370	2	2026-07-01 12:06:39.435663	2026-07-01 13:47:52.74986	2026-07-01 13:47:52.748888
271	24	E19	19261605685	1112	1	2026-07-01 08:33:56.393288	2026-07-01 14:07:38.875646	2026-07-01 14:07:38.874842
272	24	E38	18137063193	0370	1	2026-07-01 12:06:39.435663	2026-07-01 14:18:41.556318	2026-07-01 14:18:41.555404
273	24	E45	18439030153	0153	1	2026-07-01 14:54:27.678032	2026-07-01 14:56:27.659152	2026-07-01 14:56:27.658175
274	24	E39	18691666092	0205	1	2026-07-01 12:56:00.303827	2026-07-01 14:59:40.598571	2026-07-01 14:59:40.597697
275	24	E35	15617060696	5656	1	2026-06-30 12:39:36.449014	2026-07-01 15:13:44.669074	2026-07-01 15:13:44.668126
276	24	E24	18705206991	3569	1	2026-07-01 09:04:47.083127	2026-07-01 15:17:10.668006	2026-07-01 15:17:10.66717
277	24	E6	18336926660	1765	1	2026-07-01 14:18:04.34834	2026-07-01 15:18:09.617827	2026-07-01 15:18:09.61695
278	16	B4	13667618419	1234	1	2026-07-01 15:22:34.780512	2026-07-01 15:23:19.509271	2026-07-01 15:23:19.508386
279	24	E52	15103773844	3521	2	2026-07-02 07:46:12.77395	2026-07-02 07:48:58.968111	2026-07-02 07:48:58.967127
280	27	D20	19836582073	2006	2	2026-07-02 07:56:30.030627	2026-07-02 07:58:04.62214	2026-07-02 07:58:04.621313
281	24	E59	15993979586	1234	1	2026-07-02 07:48:36.845097	2026-07-02 08:03:32.238966	2026-07-02 08:03:32.238153
282	24	E8	15993979586	9586	1	2026-07-02 08:05:13.435	2026-07-02 08:07:02.788479	2026-07-02 08:07:02.787718
283	24	E35	19245821928	0530	2	2026-07-02 08:08:15.245935	2026-07-02 08:09:02.500136	2026-07-02 08:09:02.499182
284	27	D29	19837087059	0314	2	2026-07-02 08:16:22.295182	2026-07-02 08:18:14.294456	2026-07-02 08:18:14.29358
285	27	D20	19836582073	2006	2	2026-07-02 07:56:30.030627	2026-07-02 08:18:22.188426	2026-07-02 08:18:22.187268
286	27	D20	19836582073	2006	2	2026-07-02 07:56:30.030627	2026-07-02 08:18:26.461147	2026-07-02 08:18:26.459998
287	27	D20	19836582073	2006	2	2026-07-02 07:56:30.030627	2026-07-02 08:18:30.15017	2026-07-02 08:18:30.1492
288	27	D20	19836582073	2006	2	2026-07-02 07:56:30.030627	2026-07-02 08:18:32.788077	2026-07-02 08:18:32.787183
289	24	E46	19139362917	1234	2	2026-07-02 08:16:51.34477	2026-07-02 08:20:41.613189	2026-07-02 08:20:41.61227
290	24	E47	15637001160	1160	2	2026-07-02 08:17:38.340218	2026-07-02 08:23:38.007848	2026-07-02 08:23:38.006751
291	27	D30	19139066893	1129	2	2026-07-02 08:18:07.612956	2026-07-02 08:26:41.112684	2026-07-02 08:26:41.111749
292	27	D20	19836582073	2006	2	2026-07-02 07:56:30.030627	2026-07-02 08:26:57.885372	2026-07-02 08:26:57.884453
293	27	D29	19837087059	0314	2	2026-07-02 08:16:22.295182	2026-07-02 08:27:48.726482	2026-07-02 08:27:48.725623
294	27	D29	19837087059	0314	2	2026-07-02 08:16:22.295182	2026-07-02 08:30:49.414365	2026-07-02 08:30:49.413466
295	24	E47	15637001160	1160	2	2026-07-02 08:17:38.340218	2026-07-02 08:31:31.1274	2026-07-02 08:31:31.12654
296	27	D30	19139066893	1129	2	2026-07-02 08:18:07.612956	2026-07-02 08:35:20.517999	2026-07-02 08:35:20.517183
297	24	E46	19139362917	1234	2	2026-07-02 08:16:51.34477	2026-07-02 08:36:13.237408	2026-07-02 08:36:13.236513
298	24	E54	13183298887	1234	2	2026-07-02 08:34:23.072103	2026-07-02 08:36:49.895875	2026-07-02 08:36:49.894922
299	24	E56	15909265992	0923	2	2026-07-02 08:35:39.905011	2026-07-02 08:37:03.766578	2026-07-02 08:37:03.765668
300	27	D34	19233600317	0702	2	2026-07-02 08:33:52.790969	2026-07-02 08:37:36.620455	2026-07-02 08:37:36.619615
301	27	D35	13783560310	0310	2	2026-07-02 08:36:27.135531	2026-07-02 08:38:35.763896	2026-07-02 08:38:35.762992
302	24	E47	15637001160	1160	2	2026-07-02 08:17:38.340218	2026-07-02 08:44:56.337829	2026-07-02 08:44:56.33696
303	24	E58	19337028036	8888	1	2026-07-02 08:44:40.80552	2026-07-02 08:45:41.006527	2026-07-02 08:45:41.005646
304	24	E60	15842660777	8718	2	2026-07-02 08:45:00.600478	2026-07-02 08:50:19.857609	2026-07-02 08:50:19.856741
305	27	D23	15836489131	1111	1	2026-07-02 08:03:41.625887	2026-07-02 09:01:05.343576	2026-07-02 09:01:05.34263
306	27	D33	18838441692	1123	1	2026-07-02 08:32:21.360198	2026-07-02 09:06:36.036821	2026-07-02 09:06:36.035745
307	24	E46	19139362917	1234	1	2026-07-02 08:16:51.34477	2026-07-02 09:07:23.365408	2026-07-02 09:07:23.364567
308	24	E47	15637001160	1160	2	2026-07-02 08:17:38.340218	2026-07-02 09:11:36.270736	2026-07-02 09:11:36.2699
309	27	D18	15824752199	0412	1	2026-07-02 07:47:50.623948	2026-07-02 09:12:36.375846	2026-07-02 09:12:36.374992
310	24	E2	18338751797	0000	2	2026-07-02 09:08:27.380817	2026-07-02 09:13:00.407738	2026-07-02 09:13:00.406776
311	24	E35	19245821928	0530	1	2026-07-02 08:08:15.245935	2026-07-02 09:16:32.455266	2026-07-02 09:16:32.454222
312	27	D19	15839055361	5566	2	2026-07-02 07:50:44.107814	2026-07-02 09:16:44.010354	2026-07-02 09:16:44.009389
313	27	D43	13213132919	8879	1	2026-07-02 09:14:14.999046	2026-07-02 09:17:08.59876	2026-07-02 09:17:08.597806
314	27	D28	16650694701	0811	1	2026-07-02 08:11:23.788003	2026-07-02 09:18:35.760954	2026-07-02 09:18:35.760204
315	27	D20	19836582073	2006	2	2026-07-02 07:56:30.030627	2026-07-02 09:19:05.818268	2026-07-02 09:19:05.817351
316	27	D20	19836582073	2006	1	2026-07-02 07:56:30.030627	2026-07-02 09:19:37.267287	2026-07-02 09:19:37.266298
317	24	E1	15751766581	0919	1	2026-07-02 09:00:33.316107	2026-07-02 09:22:19.094942	2026-07-02 09:22:19.093927
318	24	E57	13460149121	9121	1	2026-07-02 07:47:33.427716	2026-07-02 09:29:04.607712	2026-07-02 09:29:04.606787
319	24	E5	19149247152	1125	2	2026-07-02 09:27:34.734827	2026-07-02 09:29:47.827235	2026-07-02 09:29:47.826286
320	24	E51	15660700620	0620	2	2026-07-02 08:32:58.674273	2026-07-02 09:30:02.747975	2026-07-02 09:30:02.74708
321	27	D31	18738065631	2005	1	2026-07-02 08:23:39.600805	2026-07-02 09:32:12.109779	2026-07-02 09:32:12.108895
322	27	D35	13783560310	0310	1	2026-07-02 08:36:27.135531	2026-07-02 09:32:48.152158	2026-07-02 09:32:48.151272
323	24	E53	19913257953	8318	1	2026-07-02 08:33:53.237899	2026-07-02 09:36:32.158601	2026-07-02 09:36:32.157629
324	24	E42	19339616898	6898	1	2026-07-02 08:14:38.853981	2026-07-02 09:36:59.929646	2026-07-02 09:36:59.92869
325	24	E56	15909265992	0923	1	2026-07-02 08:35:39.905011	2026-07-02 09:40:05.7271	2026-07-02 09:40:05.726193
326	24	E13	15237883857	1111	2	2026-07-02 09:36:10.145139	2026-07-02 09:40:51.242945	2026-07-02 09:40:51.24209
327	24	E44	15839096977	1234	1	2026-07-02 08:15:46.945987	2026-07-02 09:41:21.866048	2026-07-02 09:41:21.865232
328	24	E60	15842660777	8718	1	2026-07-02 08:45:00.600478	2026-07-02 09:42:24.575475	2026-07-02 09:42:24.574592
329	24	E12	18272685238	5238	1	2026-07-02 09:29:34.015377	2026-07-02 09:46:01.689023	2026-07-02 09:46:01.688145
330	24	E3	18530272656	2656	2	2026-07-02 09:27:15.602718	2026-07-02 09:47:42.559636	2026-07-02 09:47:42.558766
331	27	D34	19233600317	0702	1	2026-07-02 08:33:52.790969	2026-07-02 09:47:57.814359	2026-07-02 09:47:57.813312
332	27	D36	19836511038	1038	1	2026-07-02 08:42:21.169495	2026-07-02 09:48:31.254971	2026-07-02 09:48:31.253862
333	27	D48	13213132919	8879	2	2026-07-02 09:34:19.498022	2026-07-02 09:49:13.813888	2026-07-02 09:49:13.812658
334	27	D1	18513686701	0000	2	2026-07-02 09:36:14.341773	2026-07-02 09:57:05.682635	2026-07-02 09:57:05.681795
335	27	D30	19139066893	1129	1	2026-07-02 08:18:07.612956	2026-07-02 09:59:24.361922	2026-07-02 09:59:24.360976
336	27	D29	19837087059	0314	1	2026-07-02 08:16:22.295182	2026-07-02 10:00:04.215598	2026-07-02 10:00:04.214763
337	24	E52	15103773844	3521	1	2026-07-02 07:46:12.77395	2026-07-02 10:00:04.625917	2026-07-02 10:00:04.624579
338	27	D22	15515613024	0718	1	2026-07-02 08:03:41.451209	2026-07-02 10:05:21.379385	2026-07-02 10:05:21.378451
339	24	E51	15660700620	0620	1	2026-07-02 08:32:58.674273	2026-07-02 10:10:01.706434	2026-07-02 10:10:01.705431
340	27	D41	18137062351	1234	1	2026-07-02 08:55:49.373278	2026-07-02 10:10:23.695028	2026-07-02 10:10:23.694185
341	24	E63	18133317626	0000	1	2026-07-02 08:48:03.526115	2026-07-02 10:11:34.380234	2026-07-02 10:11:34.379322
342	24	E11	18736838325	3698	2	2026-07-02 09:28:41.608467	2026-07-02 10:17:50.963739	2026-07-02 10:17:50.962605
343	24	E19	13523176144	6144	1	2026-07-02 10:15:12.068882	2026-07-02 10:21:38.326232	2026-07-02 10:21:38.325306
344	24	E47	15637001160	1160	1	2026-07-02 08:17:38.340218	2026-07-02 10:22:42.629744	2026-07-02 10:22:42.628829
345	27	D39	15239932935	3993	1	2026-07-02 08:47:53.726405	2026-07-02 10:23:44.640339	2026-07-02 10:23:44.639354
346	27	D3	17550270621	0621	1	2026-07-02 10:17:24.289031	2026-07-02 10:27:23.106106	2026-07-02 10:27:23.105005
347	27	D2	19850171704	1228	2	2026-07-02 10:00:50.905612	2026-07-02 10:27:41.55822	2026-07-02 10:27:41.557071
348	27	D47	17627072353	2353	1	2026-07-02 09:28:30.776133	2026-07-02 10:28:02.840101	2026-07-02 10:28:02.839115
349	24	E24	15082976378	5689	2	2026-07-02 10:30:04.996297	2026-07-02 10:30:50.606396	2026-07-02 10:30:50.605461
350	24	E5	19149247152	1125	1	2026-07-02 09:27:34.734827	2026-07-02 10:31:11.316676	2026-07-02 10:31:11.315761
351	24	E13	15237883857	1111	1	2026-07-02 09:36:10.145139	2026-07-02 10:31:24.516674	2026-07-02 10:31:24.515692
352	24	E7	15695672792	7777	1	2026-07-02 09:27:47.258158	2026-07-02 10:32:09.118662	2026-07-02 10:32:09.11778
353	24	E2	18338751797	0000	1	2026-07-02 09:08:27.380817	2026-07-02 10:33:59.889329	2026-07-02 10:33:59.888462
354	27	D4	18260768573	8573	2	2026-07-02 10:33:18.596201	2026-07-02 10:35:02.284897	2026-07-02 10:35:02.28378
355	24	E23	15938352984	0813	2	2026-07-02 10:27:35.155316	2026-07-02 10:37:29.516532	2026-07-02 10:37:29.51557
356	27	D48	13213132919	8879	1	2026-07-02 09:34:19.498022	2026-07-02 10:39:29.329884	2026-07-02 10:39:29.328725
357	24	E17	15238586310	4567	2	2026-07-02 10:12:47.022226	2026-07-02 10:40:48.058028	2026-07-02 10:40:48.056751
358	24	E15	15343725078	6666	1	2026-07-02 10:03:49.367914	2026-07-02 10:41:00.735182	2026-07-02 10:41:00.734204
359	24	E23	15938352984	0813	2	2026-07-02 10:27:35.155316	2026-07-02 10:42:04.920751	2026-07-02 10:42:04.919895
360	27	D4	18260768573	8573	2	2026-07-02 10:33:18.596201	2026-07-02 10:44:01.167168	2026-07-02 10:44:01.166117
361	27	D46	19840015972	9999	1	2026-07-02 09:27:12.616414	2026-07-02 10:44:35.91173	2026-07-02 10:44:35.910863
362	27	D6	13856712830	1119	2	2026-07-02 10:48:34.79152	2026-07-02 10:50:14.443397	2026-07-02 10:50:14.442597
363	24	E17	15238586310	4567	1	2026-07-02 10:12:47.022226	2026-07-02 10:51:02.036967	2026-07-02 10:51:02.036052
364	24	E27	18530250688	0214	2	2026-07-02 10:46:11.091669	2026-07-02 10:55:15.06017	2026-07-02 10:55:15.059209
365	27	D2	19850171704	1228	1	2026-07-02 10:00:50.905612	2026-07-02 10:57:45.933328	2026-07-02 10:57:45.932407
366	24	E33	15937086006	1112	2	2026-07-02 10:58:36.604167	2026-07-02 11:00:17.926442	2026-07-02 11:00:17.925524
367	27	D5	15617023131	1234	2	2026-07-02 10:48:21.987498	2026-07-02 11:00:28.552234	2026-07-02 11:00:28.550911
368	24	E22	15836493002	0509	1	2026-07-02 10:27:23.056033	2026-07-02 11:05:58.246129	2026-07-02 11:05:58.245274
369	27	D1	18513686701	0000	1	2026-07-02 09:36:14.341773	2026-07-02 11:06:24.345863	2026-07-02 11:06:24.345044
370	24	E20	13523176144	6144	2	2026-07-02 10:23:16.791126	2026-07-02 11:08:22.805711	2026-07-02 11:08:22.804818
371	27	D44	18836568219	1012	1	2026-07-02 09:27:09.531179	2026-07-02 11:09:22.586953	2026-07-02 11:09:22.586076
372	24	E21	15065370778	1920	1	2026-07-02 10:26:30.930217	2026-07-02 11:09:35.547107	2026-07-02 11:09:35.546162
373	27	D6	13856712830	1119	1	2026-07-02 10:48:34.79152	2026-07-02 11:14:48.242881	2026-07-02 11:14:48.242098
374	24	E25	18237036782	6782	1	2026-07-02 10:33:15.411942	2026-07-02 11:16:08.887028	2026-07-02 11:16:08.886142
375	24	E24	15082976378	5689	1	2026-07-02 10:30:04.996297	2026-07-02 11:17:30.366501	2026-07-02 11:17:30.365658
376	24	E20	13523176144	6144	2	2026-07-02 10:23:16.791126	2026-07-02 11:17:53.903794	2026-07-02 11:17:53.902901
377	24	E28	15238586310	1234	1	2026-07-02 10:57:27.146029	2026-07-02 11:18:25.896283	2026-07-02 11:18:25.895387
378	24	E62	13557288765	1314	2	2026-07-02 08:02:25.117063	2026-07-02 11:19:08.85399	2026-07-02 11:19:08.853127
379	24	E27	18530250688	0214	2	2026-07-02 10:46:11.091669	2026-07-02 11:26:09.44491	2026-07-02 11:26:09.443911
380	24	E54	13183298887	1234	1	2026-07-02 08:34:23.072103	2026-07-02 11:26:35.875416	2026-07-02 11:26:35.874486
381	27	D4	18260768573	8573	2	2026-07-02 10:33:18.596201	2026-07-02 11:27:56.912698	2026-07-02 11:27:56.911934
382	24	E38	15660881573	0608	2	2026-07-02 11:28:42.817001	2026-07-02 11:31:50.377604	2026-07-02 11:31:50.376398
383	24	E38	15660881573	0608	2	2026-07-02 11:28:42.817001	2026-07-02 11:32:10.056	2026-07-02 11:32:10.055031
384	24	E38	15660881573	0608	2	2026-07-02 11:28:42.817001	2026-07-02 11:33:03.423336	2026-07-02 11:33:03.422416
385	27	D7	17753648530	0629	1	2026-07-02 11:26:14.32873	2026-07-02 11:33:16.050823	2026-07-02 11:33:16.049673
386	24	E26	15938352984	0813	1	2026-07-02 10:42:59.032878	2026-07-02 11:33:40.067048	2026-07-02 11:33:40.065951
387	24	E40	18253020029	1234	1	2026-07-02 11:30:02.211203	2026-07-02 11:34:55.164127	2026-07-02 11:34:55.163287
388	24	E27	18530250688	0214	1	2026-07-02 10:46:11.091669	2026-07-02 11:35:33.994364	2026-07-02 11:35:33.993414
389	24	E36	13557288765	1314	2	2026-07-02 11:20:54.571356	2026-07-02 11:40:09.870779	2026-07-02 11:40:09.86951
390	24	E64	18530783963	0000	2	2026-07-02 08:04:18.409305	2026-07-02 11:41:41.478256	2026-07-02 11:41:41.477407
391	24	E64	18530783963	0000	2	2026-07-02 08:04:18.409305	2026-07-02 11:44:20.279533	2026-07-02 11:44:20.278671
392	24	E20	13523176144	6144	1	2026-07-02 10:23:16.791126	2026-07-02 11:47:46.654999	2026-07-02 11:47:46.654097
393	27	D4	18260768573	8573	1	2026-07-02 10:33:18.596201	2026-07-02 11:49:13.486171	2026-07-02 11:49:13.48526
394	24	E11	18736838325	3698	1	2026-07-02 09:28:41.608467	2026-07-02 11:54:08.064875	2026-07-02 11:54:08.064088
395	27	D5	15617023131	1234	1	2026-07-02 10:48:21.987498	2026-07-02 11:56:49.173038	2026-07-02 11:56:49.172159
396	24	E50	15837068521	1212	1	2026-07-02 07:45:56.642459	2026-07-02 12:27:12.577398	2026-07-02 12:27:12.576395
397	24	E38	15660881573	0608	2	2026-07-02 11:28:42.817001	2026-07-02 12:52:08.178386	2026-07-02 12:52:08.177414
398	24	E6	17554760510	2007	2	2026-07-02 12:47:47.718468	2026-07-02 12:56:40.691856	2026-07-02 12:56:40.69099
399	24	E38	15660881573	0608	2	2026-07-02 11:28:42.817001	2026-07-02 13:02:52.167447	2026-07-02 13:02:52.166519
400	24	E38	15660881573	0608	2	2026-07-02 11:28:42.817001	2026-07-02 13:04:19.77368	2026-07-02 13:04:19.772667
401	24	E6	17554760510	2007	2	2026-07-02 12:47:47.718468	2026-07-02 13:33:57.107709	2026-07-02 13:33:57.106755
402	24	E4	13557288765	1314	2	2026-07-02 11:43:37.625961	2026-07-02 13:35:41.499218	2026-07-02 13:35:41.498316
403	24	E4	13557288765	1314	2	2026-07-02 11:43:37.625961	2026-07-02 13:43:10.212635	2026-07-02 13:43:10.211595
404	27	D8	15265092163	2580	2	2026-07-02 13:40:40.557665	2026-07-02 13:58:22.528815	2026-07-02 13:58:22.527855
405	24	E52	17527227908	0816	2	2026-07-02 13:54:24.868174	2026-07-02 13:59:31.269143	2026-07-02 13:59:31.268195
406	27	D8	15265092163	2580	2	2026-07-02 13:40:40.557665	2026-07-02 13:59:58.610342	2026-07-02 13:59:58.609472
407	24	E43	17503709333	9333	2	2026-07-02 13:40:39.61041	2026-07-02 14:00:10.114772	2026-07-02 14:00:10.113843
408	27	D8	15265092163	2580	2	2026-07-02 13:40:40.557665	2026-07-02 14:01:25.078471	2026-07-02 14:01:25.077569
409	27	D8	15265092163	2580	2	2026-07-02 13:40:40.557665	2026-07-02 14:03:04.527879	2026-07-02 14:03:04.527
410	24	E55	17698950605	2580	2	2026-07-02 14:02:17.770793	2026-07-02 14:03:23.036643	2026-07-02 14:03:23.035713
411	24	E52	17527227908	0816	2	2026-07-02 13:54:24.868174	2026-07-02 14:05:26.23707	2026-07-02 14:05:26.236195
412	24	E38	15660881573	0608	2	2026-07-02 11:28:42.817001	2026-07-02 14:07:15.644165	2026-07-02 14:07:15.643244
413	24	E55	17698950605	2580	2	2026-07-02 14:02:17.770793	2026-07-02 14:07:33.66494	2026-07-02 14:07:33.663884
414	27	D8	15265092163	2580	2	2026-07-02 13:40:40.557665	2026-07-02 14:09:32.651486	2026-07-02 14:09:32.650248
415	24	E35	19337089231	9210	2	2026-07-02 14:07:30.363268	2026-07-02 14:11:50.210116	2026-07-02 14:11:50.209187
416	27	D8	15265092163	2580	2	2026-07-02 13:40:40.557665	2026-07-02 14:18:19.549427	2026-07-02 14:18:19.548552
417	27	D8	15265092163	2580	2	2026-07-02 13:40:40.557665	2026-07-02 14:20:33.258431	2026-07-02 14:20:33.257453
418	24	E55	17698950605	2580	2	2026-07-02 14:02:17.770793	2026-07-02 14:21:04.964744	2026-07-02 14:21:04.963903
419	24	E4	13557288765	1314	1	2026-07-02 11:43:37.625961	2026-07-02 14:22:47.738312	2026-07-02 14:22:47.737295
420	24	E36	13557288765	1314	1	2026-07-02 11:20:54.571356	2026-07-02 14:23:20.932825	2026-07-02 14:23:20.931711
421	24	E62	13557288765	1314	1	2026-07-02 08:02:25.117063	2026-07-02 14:23:36.997169	2026-07-02 14:23:36.995262
422	24	E64	18530783963	0000	1	2026-07-02 08:04:18.409305	2026-07-02 14:24:09.586111	2026-07-02 14:24:09.585131
423	27	D8	15265092163	2580	2	2026-07-02 13:40:40.557665	2026-07-02 14:25:02.910564	2026-07-02 14:25:02.909445
424	24	E43	17503709333	9333	1	2026-07-02 13:40:39.61041	2026-07-02 14:27:48.536119	2026-07-02 14:27:48.535157
425	24	E55	17698950605	2580	2	2026-07-02 14:02:17.770793	2026-07-02 14:32:35.4385	2026-07-02 14:32:35.437537
426	24	E52	17527227908	0816	1	2026-07-02 13:54:24.868174	2026-07-02 14:33:40.217561	2026-07-02 14:33:40.216701
427	24	E45	15136011309	1472	1	2026-07-02 13:41:04.44203	2026-07-02 14:35:11.68882	2026-07-02 14:35:11.687958
428	27	D10	19639308701	8701	2	2026-07-02 14:07:55.409982	2026-07-02 14:35:27.735739	2026-07-02 14:35:27.734832
429	24	E48	15939273255	3255	1	2026-07-02 13:41:32.554938	2026-07-02 14:36:05.495077	2026-07-02 14:36:05.494115
430	24	E6	17554760510	2007	1	2026-07-02 12:47:47.718468	2026-07-02 14:36:18.33408	2026-07-02 14:36:18.333201
431	24	E50	13323972142	9999	1	2026-07-02 13:41:48.719591	2026-07-02 14:36:36.306565	2026-07-02 14:36:36.305709
432	24	E38	15660881573	0608	1	2026-07-02 11:28:42.817001	2026-07-02 14:36:53.1779	2026-07-02 14:36:53.177058
433	24	E35	19337089231	9210	2	2026-07-02 14:07:30.363268	2026-07-02 14:37:07.236108	2026-07-02 14:37:07.23502
434	24	E57	18530250688	0214	1	2026-07-02 14:03:06.954188	2026-07-02 14:37:48.027326	2026-07-02 14:37:48.02642
435	24	E62	13037508763	1123	2	2026-07-02 14:35:44.398435	2026-07-02 14:38:19.365892	2026-07-02 14:38:19.364994
436	24	E42	17753648530	0629	1	2026-07-02 14:07:54.84499	2026-07-02 14:39:43.085377	2026-07-02 14:39:43.084263
437	27	D10	19639308701	8701	1	2026-07-02 14:07:55.409982	2026-07-02 14:41:42.62149	2026-07-02 14:41:42.620585
438	27	D8	15265092163	2580	2	2026-07-02 13:40:40.557665	2026-07-02 14:42:00.183261	2026-07-02 14:42:00.182342
439	24	E47	15137051381	1205	1	2026-07-02 14:15:12.727293	2026-07-02 14:44:45.204075	2026-07-02 14:44:45.203243
440	24	E62	13037508763	1123	2	2026-07-02 14:35:44.398435	2026-07-02 14:45:24.524643	2026-07-02 14:45:24.523824
441	24	E60	15603705779	0708	2	2026-07-02 14:48:54.190528	2026-07-02 14:52:17.124234	2026-07-02 14:52:17.123278
442	27	D12	15690868029	5658	1	2026-07-02 14:39:14.148521	2026-07-02 14:52:49.204601	2026-07-02 14:52:49.203725
443	24	E55	17698950605	2580	1	2026-07-02 14:02:17.770793	2026-07-02 14:55:50.367352	2026-07-02 14:55:50.366505
444	27	D11	15737005525	1023	2	2026-07-02 14:37:54.175837	2026-07-02 14:58:25.085706	2026-07-02 14:58:25.084829
445	24	E59	18455712691	1234	2	2026-07-02 14:07:24.754317	2026-07-02 15:01:31.839092	2026-07-02 15:01:31.838049
446	24	E54	15836704325	0088	2	2026-07-02 14:39:00.388316	2026-07-02 15:03:10.298921	2026-07-02 15:03:10.297984
447	27	D8	15265092163	2580	1	2026-07-02 13:40:40.557665	2026-07-02 15:04:15.010543	2026-07-02 15:04:15.009602
448	24	E59	18455712691	1234	2	2026-07-02 14:07:24.754317	2026-07-02 15:04:17.214688	2026-07-02 15:04:17.213699
449	24	E3	15919267157	0814	2	2026-07-02 15:03:09.974142	2026-07-02 15:04:33.152518	2026-07-02 15:04:33.151695
450	27	D11	15737005525	1023	2	2026-07-02 14:37:54.175837	2026-07-02 15:10:37.68923	2026-07-02 15:10:37.688345
451	24	E7	15560048291	1234	2	2026-07-02 15:13:50.031833	2026-07-02 15:14:28.358596	2026-07-02 15:14:28.357646
452	24	E3	15919267157	0814	2	2026-07-02 15:03:09.974142	2026-07-02 15:14:50.410128	2026-07-02 15:14:50.409204
453	24	E5	19639308701	8701	1	2026-07-02 15:03:23.505689	2026-07-02 15:26:47.113329	2026-07-02 15:26:47.112451
454	27	D14	18738086168	8888	1	2026-07-02 15:03:37.130524	2026-07-02 15:29:51.417019	2026-07-02 15:29:51.416061
455	24	E44	18272662178	1214	1	2026-07-02 14:08:27.357222	2026-07-02 15:30:17.999822	2026-07-02 15:30:17.998753
456	27	D9	18039160828	2007	1	2026-07-02 14:07:44.64612	2026-07-02 15:30:55.388044	2026-07-02 15:30:55.386926
457	24	E64	17739015172	5172	1	2026-07-02 14:37:34.450925	2026-07-02 15:32:44.355986	2026-07-02 15:32:44.355216
458	24	E53	19037881852	0000	1	2026-07-02 14:38:56.49862	2026-07-02 15:34:14.81645	2026-07-02 15:34:14.815568
459	16	B15	13667618419	1234	1	2026-07-02 15:33:19.708571	2026-07-02 15:34:52.643014	2026-07-02 15:34:52.641868
460	24	E54	15836704325	0088	1	2026-07-02 14:39:00.388316	2026-07-02 15:35:58.554516	2026-07-02 15:35:58.553366
461	24	E59	18455712691	1234	1	2026-07-02 14:07:24.754317	2026-07-02 15:36:44.834592	2026-07-02 15:36:44.833655
462	24	E3	15919267157	0814	2	2026-07-02 15:03:09.974142	2026-07-02 15:37:26.928523	2026-07-02 15:37:26.927535
463	24	E1	15690868029	5658	1	2026-07-02 14:55:38.803145	2026-07-02 15:37:55.299668	2026-07-02 15:37:55.298668
464	27	D13	13619875632	2587	1	2026-07-02 15:03:16.101504	2026-07-02 15:40:47.262092	2026-07-02 15:40:47.261067
465	27	D11	15737005525	1023	1	2026-07-02 14:37:54.175837	2026-07-02 15:41:18.183939	2026-07-02 15:41:18.18303
466	24	E60	15603705779	0708	1	2026-07-02 14:48:54.190528	2026-07-02 15:41:44.421072	2026-07-02 15:41:44.419979
467	24	E62	13037508763	1123	1	2026-07-02 14:35:44.398435	2026-07-02 15:42:05.276189	2026-07-02 15:42:05.27532
468	27	D16	17838825515	2013	1	2026-07-02 15:08:00.60515	2026-07-02 15:44:52.282969	2026-07-02 15:44:52.281961
469	24	E35	19337089231	9210	1	2026-07-02 14:07:30.363268	2026-07-02 15:47:53.351045	2026-07-02 15:47:53.350256
470	24	E13	17634328712	1111	1	2026-07-02 15:33:26.834265	2026-07-02 15:51:52.102229	2026-07-02 15:51:52.101503
471	24	E56	17555309098	1234	1	2026-07-02 14:45:26.092215	2026-07-02 15:55:34.1365	2026-07-02 15:55:34.135671
472	24	E11	19251695576	1234	1	2026-07-02 15:29:03.996198	2026-07-02 15:57:17.406083	2026-07-02 15:57:17.405365
473	24	E3	15919267157	0814	2	2026-07-02 15:03:09.974142	2026-07-02 15:58:46.108436	2026-07-02 15:58:46.107564
474	24	E3	15919267157	0814	1	2026-07-02 15:03:09.974142	2026-07-02 15:59:35.946277	2026-07-02 15:59:35.945604
475	24	E49	15236859855	7910	1	2026-07-02 14:20:39.574054	2026-07-02 15:59:49.33465	2026-07-02 15:59:49.333715
476	27	D18	17530271182	0212	1	2026-07-02 15:21:33.500965	2026-07-02 16:01:03.733241	2026-07-02 16:01:03.732352
477	27	D20	18238033278	0302	1	2026-07-02 15:37:48.657807	2026-07-02 16:06:53.289088	2026-07-02 16:06:53.288316
478	24	E14	17503709333	9333	1	2026-07-02 15:41:18.32903	2026-07-02 16:09:52.81642	2026-07-02 16:09:52.815477
479	24	E7	15560048291	1234	1	2026-07-02 15:13:50.031833	2026-07-02 16:10:59.986422	2026-07-02 16:10:59.985548
480	27	D22	19913817011	0000	1	2026-07-02 15:53:29.045267	2026-07-02 16:16:03.093507	2026-07-02 16:16:03.092494
481	24	E15	16692633387	2001	1	2026-07-02 15:55:03.140951	2026-07-02 16:18:13.636544	2026-07-02 16:18:13.635629
482	16	B20	13667618419	1234	2	2026-07-02 16:17:50.91156	2026-07-02 16:18:34.393723	2026-07-02 16:18:34.393196
483	16	B20	13667618419	1234	1	2026-07-02 16:17:50.91156	2026-07-02 16:18:37.610418	2026-07-02 16:18:37.609537
484	27	D21	19273906997	1314	1	2026-07-02 15:38:54.574615	2026-07-02 16:18:41.210219	2026-07-02 16:18:41.209091
485	16	B33	18888889999	1234	1	2026-07-02 22:05:28.545651	2026-07-02 22:06:05.626809	2026-07-02 22:06:05.625793
486	34	1	18888889999	8888	1	2026-07-02 22:12:52.121589	2026-07-02 22:13:07.816739	2026-07-02 22:13:07.815737
487	34	1	18888889999	8888	1	2026-07-02 22:13:34.169298	2026-07-02 22:13:43.708929	2026-07-02 22:13:43.708079
488	34	1	18888889999	8888	1	2026-07-02 22:21:37.987992	2026-07-02 22:22:11.830454	2026-07-02 22:22:11.829386
489	16	B26	13667618419	1475	1	2026-07-02 21:55:00.451597	2026-07-02 22:29:07.296884	2026-07-02 22:29:07.29601
490	34	1	13800138001	8888	1	2026-07-02 22:34:31.023058	2026-07-02 22:34:37.100397	2026-07-02 22:34:37.09921
491	34	1	13800138002	9999	1	2026-07-02 22:34:54.388644	2026-07-02 22:34:59.715906	2026-07-02 22:34:59.71501
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.system_settings (id, setting_key, setting_value, description) FROM stdin;
1	deposit_amount	25	保证金金额（元）
2	sms_enabled	false	是否开启短信验证
3	system_name	智能寄存柜系统	系统名称
4	deposit_timeout	24	超时时间（小时）
12	pay_mode	wechat	支付模式：mock=模拟支付，wechat=微信支付
28	order_hide_rate	0	订单隐藏比例(%)
29	order_hide_whitelist	\N	订单隐藏白名单手机号(逗号分隔)
30	duplicate_days	7	重复用户过滤天数
31	duplicate_limit	5	重复用户过滤单数
32	duplicate_filter_enabled	0	是否开启重复用户过滤
3943	channel_rotation_mode	round_robin	支付渠道轮转模式: round_robin=严格轮转, weighted=加权随机
4024	test_key	test_value	\N
11185	allow_h5_to_mp	1	是否允许H5跳转小程序
\.


--
-- Data for Name: user_balance_details; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.user_balance_details (id, user_phone, order_id, amount, source_time, status, created_at) FROM stdin;
83	18691666092	598	20.00	2026-07-01 14:59:40.597697	pending	2026-07-01 14:59:40.597697
2	18996093393	28	20.00	2026-06-13 10:40:52.646938	available	2026-06-30 15:03:06.443668
72	15136012752	579	20.00	2026-07-01 12:55:33.339775	pending	2026-07-01 12:55:33.339775
728	15993979586	1414	20.00	2026-07-02 08:03:32.238153	available	2026-07-02 08:03:32.238153
732	18838441692	1434	20.00	2026-07-02 09:06:36.035745	available	2026-07-02 09:06:36.035745
7	17725196748	299	20.00	2026-06-26 09:25:55	available	2026-06-30 15:03:06.443668
8	17725196748	300	20.00	2026-06-26 09:25:55	available	2026-06-30 15:03:06.443668
9	17725196748	301	20.00	2026-06-26 09:25:55	available	2026-06-30 15:03:06.443668
10	17725196748	302	20.00	2026-06-26 09:25:55	available	2026-06-30 15:03:06.443668
11	18888889999	312	20.00	2026-06-26 09:35:30	available	2026-06-30 15:03:06.443668
12	18888889999	313	20.00	2026-06-26 09:36:04.314655	available	2026-06-30 15:03:06.443668
13	18888889999	314	20.00	2026-06-26 09:42:16.701258	available	2026-06-30 15:03:06.443668
14	18888889999	317	20.00	2026-06-26 13:13:40.256117	available	2026-06-30 15:03:06.443668
15	18888889999	353	20.00	2026-06-27 12:36:26	available	2026-06-30 15:03:06.443668
16	18996093393	358	20.00	2026-06-26 21:11:50.818076	available	2026-06-30 15:03:06.443668
17	18996093393	359	20.00	2026-06-27 02:01:04	available	2026-06-30 15:03:06.443668
18	18888889999	368	20.00	2026-06-27 12:41:16	available	2026-06-30 15:03:06.443668
19	18996093393	374	1.00	2026-06-27 12:40:46	available	2026-06-30 15:03:06.443668
20	18888889999	379	20.00	2026-06-28 07:21:51	available	2026-06-30 15:03:06.443668
21	18996093393	385	1.00	2026-06-28 08:30:57.233902	available	2026-06-30 15:03:06.443668
22	18983079797	386	1.00	2026-06-27 18:06:36.345558	available	2026-06-30 15:03:06.443668
23	18888889999	390	20.00	2026-06-28 07:50:13.355498	available	2026-06-30 15:03:06.443668
24	18996093393	391	1.00	2026-06-28 08:31:00.780515	available	2026-06-30 15:03:06.443668
25	18888889999	400	20.00	2026-06-29 08:51:01	available	2026-06-30 15:03:06.443668
26	18888889999	401	20.00	2026-06-28 17:48:14	available	2026-06-30 15:03:06.443668
27	18996093393	412	20.00	2026-06-29 18:57:52.048506	available	2026-06-30 15:03:06.443668
30	18983079797	461	20.00	2026-06-30 09:30:15.181189	available	2026-06-30 15:03:06.443668
32	19905939796	484	20.00	2026-06-30 10:14:59.067319	available	2026-06-30 15:03:06.443668
33	15550752925	503	20.00	2026-06-30 12:39:32.523626	available	2026-06-30 15:03:06.443668
34	15657821278	517	20.00	2026-06-30 13:04:21.890156	available	2026-06-30 15:03:06.443668
35	18265820019	501	20.00	2026-06-30 15:09:03.911412	pending	2026-06-30 15:09:03.911412
36	18326741968	516	20.00	2026-06-30 15:12:49.55469	available	2026-06-30 15:12:49.55469
37	18265005796	514	20.00	2026-06-30 15:16:02.742288	pending	2026-06-30 15:16:02.742288
38	13791463202	532	20.00	2026-06-30 15:17:35.702619	available	2026-06-30 15:17:35.702619
39	19286022436	519	20.00	2026-06-30 15:18:21.865765	available	2026-06-30 15:18:21.865765
40	18953074181	528	20.00	2026-06-30 15:29:00.865583	available	2026-06-30 15:29:00.865583
41	17726689234	548	20.00	2026-06-30 15:37:21.900677	withdrawn	2026-06-30 15:37:21.900677
42	17837383155	541	20.00	2026-06-30 15:53:14.208293	available	2026-06-30 15:53:14.208293
43	18438398466	524	20.00	2026-06-30 15:54:09.750178	available	2026-06-30 15:54:09.750178
44	15138943614	526	20.00	2026-06-30 16:04:17.890288	available	2026-06-30 16:04:17.890288
45	15238586310	547	20.00	2026-06-30 16:04:59.130736	available	2026-06-30 16:04:59.130736
46	15836435632	545	20.00	2026-06-30 16:09:27.308745	available	2026-06-30 16:09:27.308745
48	19544562686	539	20.00	2026-06-30 16:10:29.361524	pending	2026-06-30 16:10:29.361524
49	15275043796	523	20.00	2026-06-30 16:12:23.934446	pending	2026-06-30 16:12:23.934446
51	15225299085	535	20.00	2026-06-30 16:18:10.688146	available	2026-06-30 16:18:10.688146
52	18637010208	521	20.00	2026-06-30 16:31:24.751435	pending	2026-06-30 16:31:24.751435
50	19137096192	538	20.00	2026-06-30 16:17:34.490627	pending	2026-06-30 16:17:34.490627
53	17726689234	551	20.00	2026-06-30 18:01:14.416481	withdrawn	2026-06-30 18:01:14.416481
56	17726689234	553	20.00	2026-06-30 18:04:49.5678	withdrawn	2026-06-30 18:04:49.5678
55	17726689234	555	20.00	2026-06-30 18:04:46.043121	withdrawn	2026-06-30 18:04:46.043121
6	13667618419	34	20.00	2026-06-20 07:28:25.534453	pending	2026-06-30 15:03:06.443668
5	13667618419	33	20.00	2026-06-20 07:28:30.680119	pending	2026-06-30 15:03:06.443668
4	13667618419	30	20.00	2026-06-20 07:28:42.627193	pending	2026-06-30 15:03:06.443668
3	13667618419	29	20.00	2026-06-20 07:28:37.901891	pending	2026-06-30 15:03:06.443668
1	13667618419	25	20.00	2026-06-18 16:24:07.583328	pending	2026-06-30 15:03:06.443668
54	13667618419	550	20.00	2026-06-30 18:01:54.880741	withdrawn	2026-06-30 18:01:54.880741
58	18254067609	506	20.00	2026-06-30 18:27:44.766091	available	2026-06-30 18:27:44.766091
59	17726689234	556	20.00	2026-06-30 18:45:23.614578	withdrawn	2026-06-30 18:45:23.614578
60	17726689234	558	20.00	2026-06-30 18:56:02.171276	withdrawn	2026-06-30 18:56:02.171276
57	15656087879	549	20.00	2026-06-30 18:23:09.845366	pending	2026-06-30 18:23:09.845366
47	15324821187	546	20.00	2026-06-30 16:10:06.63983	pending	2026-06-30 16:10:06.63983
61	17726689234	564	20.00	2026-07-01 08:00:10.286068	pending	2026-07-01 08:00:10.286068
62	17726689234	562	20.00	2026-07-01 08:01:35.544624	pending	2026-07-01 08:01:35.544624
31	18996093393	469	20.00	2026-06-30 09:39:05.759763	pending	2026-06-30 15:03:06.443668
29	18996093393	457	20.00	2026-06-30 09:11:01.254235	pending	2026-06-30 15:03:06.443668
28	18996093393	454	20.00	2026-06-30 09:03:54.081831	pending	2026-06-30 15:03:06.443668
63	15090698884	566	20.00	2026-07-01 10:25:55.515148	available	2026-07-01 10:25:55.515148
65	19025302365	590	20.00	2026-07-01 12:39:03.622035	pending	2026-07-01 12:39:03.622035
67	18238060772	588	20.00	2026-07-01 12:40:31.315239	available	2026-07-01 12:40:31.315239
68	17838930615	582	20.00	2026-07-01 12:41:57.726626	available	2026-07-01 12:41:57.726626
66	15964428331	593	20.00	2026-07-01 12:40:02.394209	pending	2026-07-01 12:40:02.394209
69	15514642606	581	20.00	2026-07-01 12:45:09.374782	available	2026-07-01 12:45:09.374782
74	17346902460	584	20.00	2026-07-01 13:09:34.410003	available	2026-07-01 13:09:34.410003
73	15054012361	592	20.00	2026-07-01 13:04:53.691973	pending	2026-07-01 13:04:53.691973
75	18356795403	583	20.00	2026-07-01 13:22:57.309578	available	2026-07-01 13:22:57.309578
76	15554513417	587	20.00	2026-07-01 13:26:41.381057	available	2026-07-01 13:26:41.381057
77	13655676086	565	20.00	2026-07-01 13:30:54.58668	available	2026-07-01 13:30:54.58668
71	17861769100	570	20.00	2026-07-01 12:51:21.314891	pending	2026-07-01 12:51:21.314891
78	17838863123	569	20.00	2026-07-01 13:33:42.598876	available	2026-07-01 13:33:42.598876
70	15798651828	591	20.00	2026-07-01 12:46:20.422248	pending	2026-07-01 12:46:20.422248
79	15186672778	599	20.00	2026-07-01 13:42:33.584659	available	2026-07-01 13:42:33.584659
81	18137063193	597	20.00	2026-07-01 14:18:41.555404	available	2026-07-01 14:18:41.555404
82	18439030153	603	20.00	2026-07-01 14:56:27.658175	available	2026-07-01 14:56:27.658175
64	19165928949	589	20.00	2026-07-01 12:35:19.706301	pending	2026-07-01 12:35:19.706301
80	19261605685	567	20.00	2026-07-01 14:07:38.874842	pending	2026-07-01 14:07:38.874842
84	15617060696	505	20.00	2026-07-01 15:13:44.668126	pending	2026-07-01 15:13:44.668126
85	18705206991	572	20.00	2026-07-01 15:17:10.66717	available	2026-07-01 15:17:10.66717
86	18336926660	601	20.00	2026-07-01 15:18:09.61695	available	2026-07-01 15:18:09.61695
87	13667618419	604	20.00	2026-07-01 15:23:19.508386	pending	2026-07-01 15:23:19.508386
729	15993979586	1422	20.00	2026-07-02 08:07:02.787718	available	2026-07-02 08:07:02.787718
733	19139362917	1429	20.00	2026-07-02 09:07:23.364567	available	2026-07-02 09:07:23.364567
736	13213132919	1451	20.00	2026-07-02 09:17:08.597806	available	2026-07-02 09:17:08.597806
739	15751766581	1449	20.00	2026-07-02 09:22:19.093927	pending	2026-07-02 09:22:19.093927
742	13783560310	1441	20.00	2026-07-02 09:32:48.151272	available	2026-07-02 09:32:48.151272
745	15909265992	1440	20.00	2026-07-02 09:40:05.726193	available	2026-07-02 09:40:05.726193
748	18272685238	1461	20.00	2026-07-02 09:46:01.688145	available	2026-07-02 09:46:01.688145
751	19139066893	1431	20.00	2026-07-02 09:59:24.360976	available	2026-07-02 09:59:24.360976
754	15515613024	1419	20.00	2026-07-02 10:05:21.378451	pending	2026-07-02 10:05:21.378451
757	18133317626	1447	20.00	2026-07-02 10:11:34.379322	available	2026-07-02 10:11:34.379322
760	15239932935	1446	20.00	2026-07-02 10:23:44.639354	available	2026-07-02 10:23:44.639354
763	19149247152	1456	20.00	2026-07-02 10:31:11.315761	available	2026-07-02 10:31:11.315761
766	18338751797	1450	20.00	2026-07-02 10:33:59.888462	available	2026-07-02 10:33:59.888462
769	19840015972	1454	20.00	2026-07-02 10:44:35.910863	available	2026-07-02 10:44:35.910863
773	15836493002	1474	20.00	2026-07-02 11:05:58.245274	pending	2026-07-02 11:05:58.245274
776	15065370778	1473	20.00	2026-07-02 11:09:35.546162	available	2026-07-02 11:09:35.546162
779	15082976378	1476	20.00	2026-07-02 11:17:30.365658	available	2026-07-02 11:17:30.365658
782	17753648530	1490	20.00	2026-07-02 11:33:16.049673	available	2026-07-02 11:33:16.049673
785	18530250688	1480	20.00	2026-07-02 11:35:33.993414	available	2026-07-02 11:35:33.993414
791	13557288765	1494	20.00	2026-07-02 14:22:47.737295	available	2026-07-02 14:22:47.737295
794	18530783963	1421	20.00	2026-07-02 14:24:09.585131	available	2026-07-02 14:24:09.585131
797	15136011309	1498	20.00	2026-07-02 14:35:11.687958	available	2026-07-02 14:35:11.687958
803	17753648530	1508	20.00	2026-07-02 14:39:43.084263	available	2026-07-02 14:39:43.084263
806	15690868029	1520	20.00	2026-07-02 14:52:49.203725	available	2026-07-02 14:52:49.203725
800	13323972142	1500	20.00	2026-07-02 14:36:36.305709	pending	2026-07-02 14:36:36.305709
809	19639308701	1529	20.00	2026-07-02 15:26:47.112451	pending	2026-07-02 15:26:47.112451
812	18039160828	1507	20.00	2026-07-02 15:30:55.386926	pending	2026-07-02 15:30:55.386926
815	13667618419	1537	20.00	2026-07-02 15:34:52.641868	pending	2026-07-02 15:34:52.641868
818	15690868029	1525	20.00	2026-07-02 15:37:55.298668	available	2026-07-02 15:37:55.298668
821	15603705779	1523	20.00	2026-07-02 15:41:44.419979	available	2026-07-02 15:41:44.419979
824	19337089231	1506	20.00	2026-07-02 15:47:53.350256	pending	2026-07-02 15:47:53.350256
827	19251695576	1536	20.00	2026-07-02 15:57:17.405365	available	2026-07-02 15:57:17.405365
833	15560048291	1533	20.00	2026-07-02 16:10:59.985548	pending	2026-07-02 16:10:59.985548
788	18736838325	1460	20.00	2026-07-02 11:54:08.064088	pending	2026-07-02 11:54:08.064088
830	17530271182	1534	20.00	2026-07-02 16:01:03.732352	pending	2026-07-02 16:01:03.732352
836	13667618419	1547	20.00	2026-07-02 16:18:37.609537	available	2026-07-02 16:18:37.609537
839	18888889999	1552	20.00	2026-07-02 22:13:07.815737	available	2026-07-02 22:13:07.815737
840	18888889999	1553	20.00	2026-07-02 22:13:43.708079	available	2026-07-02 22:13:43.708079
843	13800138001	1558	20.00	2026-07-02 22:34:37.09921	available	2026-07-02 22:34:37.09921
844	13800138002	1559	30.00	2026-07-02 22:34:59.71501	available	2026-07-02 22:34:59.71501
730	19337028036	1443	20.00	2026-07-02 08:45:41.005646	available	2026-07-02 08:45:41.005646
734	15824752199	1413	20.00	2026-07-02 09:12:36.374992	available	2026-07-02 09:12:36.374992
737	16650694701	1425	20.00	2026-07-02 09:18:35.760204	available	2026-07-02 09:18:35.760204
740	13460149121	1412	20.00	2026-07-02 09:29:04.606787	available	2026-07-02 09:29:04.606787
743	19913257953	1438	20.00	2026-07-02 09:36:32.157629	available	2026-07-02 09:36:32.157629
746	15839096977	1427	20.00	2026-07-02 09:41:21.865232	available	2026-07-02 09:41:21.865232
749	19233600317	1437	20.00	2026-07-02 09:47:57.813312	available	2026-07-02 09:47:57.813312
752	19837087059	1428	20.00	2026-07-02 10:00:04.214763	available	2026-07-02 10:00:04.214763
755	15660700620	1436	20.00	2026-07-02 10:10:01.705431	available	2026-07-02 10:10:01.705431
758	13523176144	1470	20.00	2026-07-02 10:21:38.325306	available	2026-07-02 10:21:38.325306
761	17550270621	1471	20.00	2026-07-02 10:27:23.105005	available	2026-07-02 10:27:23.105005
764	15237883857	1463	20.00	2026-07-02 10:31:24.515692	available	2026-07-02 10:31:24.515692
767	13213132919	1462	20.00	2026-07-02 10:39:29.328725	available	2026-07-02 10:39:29.328725
770	18530272656	1455	20.00	2026-07-02 10:46:09.027493	available	2026-07-02 10:46:09.027493
771	15238586310	1468	20.00	2026-07-02 10:51:02.036052	available	2026-07-02 10:51:02.036052
774	18513686701	1464	20.00	2026-07-02 11:06:24.345044	available	2026-07-02 11:06:24.345044
780	15238586310	1483	20.00	2026-07-02 11:18:25.895387	available	2026-07-02 11:18:25.895387
786	13523176144	1472	20.00	2026-07-02 11:47:46.654097	available	2026-07-02 11:47:46.654097
789	15617023131	1481	20.00	2026-07-02 11:56:49.172159	available	2026-07-02 11:56:49.172159
777	13856712830	1482	20.00	2026-07-02 11:14:48.242098	pending	2026-07-02 11:14:48.242098
792	13557288765	1489	20.00	2026-07-02 14:23:20.931711	available	2026-07-02 14:23:20.931711
798	15939273255	1499	20.00	2026-07-02 14:36:05.494115	available	2026-07-02 14:36:05.494115
801	15660881573	1491	20.00	2026-07-02 14:36:53.177058	available	2026-07-02 14:36:53.177058
795	17503709333	1496	20.00	2026-07-02 14:27:48.535157	pending	2026-07-02 14:27:48.535157
807	17698950605	1502	20.00	2026-07-02 14:55:50.366505	pending	2026-07-02 14:55:50.366505
804	19639308701	1509	20.00	2026-07-02 14:41:42.620585	pending	2026-07-02 14:41:42.620585
783	15938352984	1479	20.00	2026-07-02 11:33:40.065951	pending	2026-07-02 11:33:40.065951
810	18738086168	1530	20.00	2026-07-02 15:29:51.416061	pending	2026-07-02 15:29:51.416061
813	17739015172	1515	20.00	2026-07-02 15:32:44.355216	available	2026-07-02 15:32:44.355216
816	15836704325	1519	20.00	2026-07-02 15:35:58.553366	available	2026-07-02 15:35:58.553366
819	13619875632	1528	20.00	2026-07-02 15:40:47.261067	available	2026-07-02 15:40:47.261067
822	13037508763	1514	20.00	2026-07-02 15:42:05.27532	pending	2026-07-02 15:42:05.27532
825	17634328712	1539	20.00	2026-07-02 15:51:52.101503	available	2026-07-02 15:51:52.101503
828	15919267157	1527	20.00	2026-07-02 15:59:35.945604	pending	2026-07-02 15:59:35.945604
831	18238033278	1540	20.00	2026-07-02 16:06:53.288316	available	2026-07-02 16:06:53.288316
834	19913817011	1543	20.00	2026-07-02 16:16:03.092494	available	2026-07-02 16:16:03.092494
837	19273906997	1541	20.00	2026-07-02 16:18:41.209091	available	2026-07-02 16:18:41.209091
841	18888889999	1557	20.00	2026-07-02 22:22:11.829386	available	2026-07-02 22:22:11.829386
568	13800000026	605	16.00	2026-06-25 00:50:57.53503	available	2026-07-01 15:31:57.529838
569	13800000040	606	24.00	2026-06-28 13:01:57.53503	available	2026-07-01 15:31:57.529838
570	13800000032	607	16.00	2026-06-28 15:51:57.53503	available	2026-07-01 15:31:57.529838
571	13800000048	608	20.00	2026-06-24 19:24:57.53503	available	2026-07-01 15:31:57.529838
572	13800000016	609	16.00	2026-06-30 20:32:57.53503	available	2026-07-01 15:31:57.529838
573	13800000042	610	16.00	2026-06-29 09:33:57.53503	available	2026-07-01 15:31:57.529838
574	13800000049	611	20.00	2026-06-27 06:47:57.53503	available	2026-07-01 15:31:57.529838
575	13800000048	612	16.00	2026-06-30 17:00:57.53503	available	2026-07-01 15:31:57.529838
576	13800000026	615	20.00	2026-06-26 11:33:57.53503	available	2026-07-01 15:31:57.529838
577	13800000014	616	16.00	2026-07-01 09:24:57.53503	available	2026-07-01 15:31:57.529838
578	13800000037	617	24.00	2026-06-28 04:05:57.53503	available	2026-07-01 15:31:57.529838
579	13800000014	618	12.00	2026-06-24 17:33:57.53503	available	2026-07-01 15:31:57.529838
580	13800000040	619	12.00	2026-06-24 06:08:57.53503	available	2026-07-01 15:31:57.529838
581	13800000006	620	24.00	2026-06-30 23:55:57.53503	available	2026-07-01 15:31:57.529838
582	13800000022	621	8.00	2026-06-29 08:15:57.53503	available	2026-07-01 15:31:57.529838
583	13800000040	622	24.00	2026-07-01 07:17:57.53503	available	2026-07-01 15:31:57.529838
584	13800000020	625	16.00	2026-06-30 22:54:57.53503	available	2026-07-01 15:31:57.529838
585	13800000043	626	20.00	2026-06-24 11:46:57.53503	available	2026-07-01 15:31:57.529838
586	13800000012	627	12.00	2026-06-27 20:04:57.53503	available	2026-07-01 15:31:57.529838
587	13800000033	628	12.00	2026-06-27 15:51:57.53503	available	2026-07-01 15:31:57.529838
588	13800000013	629	12.00	2026-06-29 03:18:57.53503	available	2026-07-01 15:31:57.529838
589	13800000025	630	12.00	2026-06-28 12:55:57.53503	available	2026-07-01 15:31:57.529838
590	13800000012	631	20.00	2026-06-29 07:23:57.53503	available	2026-07-01 15:31:57.529838
591	13800000031	632	8.00	2026-06-23 22:18:57.53503	available	2026-07-01 15:31:57.529838
592	13800000049	635	12.00	2026-06-29 03:23:57.53503	available	2026-07-01 15:31:57.529838
593	13800000035	636	16.00	2026-06-27 22:06:57.53503	available	2026-07-01 15:31:57.529838
594	13800000012	637	8.00	2026-06-23 21:05:57.53503	available	2026-07-01 15:31:57.529838
595	13800000034	638	24.00	2026-07-01 15:36:57.53503	available	2026-07-01 15:31:57.529838
596	13800000015	639	8.00	2026-06-26 19:23:57.53503	available	2026-07-01 15:31:57.529838
597	13800000045	640	8.00	2026-06-25 06:52:57.53503	available	2026-07-01 15:31:57.529838
598	13800000019	641	12.00	2026-06-27 06:27:57.53503	available	2026-07-01 15:31:57.529838
599	13800000004	642	8.00	2026-07-01 12:39:57.53503	available	2026-07-01 15:31:57.529838
600	13800000014	645	12.00	2026-07-01 09:16:57.53503	available	2026-07-01 15:31:57.529838
601	13800000019	646	8.00	2026-07-01 14:42:57.53503	available	2026-07-01 15:31:57.529838
602	13800000009	647	24.00	2026-06-24 20:42:57.53503	available	2026-07-01 15:31:57.529838
603	13800000013	648	24.00	2026-06-24 11:16:57.53503	available	2026-07-01 15:31:57.529838
604	13800000010	649	24.00	2026-06-25 10:36:57.53503	available	2026-07-01 15:31:57.529838
605	13800000033	650	20.00	2026-06-25 06:47:57.53503	available	2026-07-01 15:31:57.529838
606	13800000028	651	12.00	2026-06-25 20:09:57.53503	available	2026-07-01 15:31:57.529838
607	13800000021	652	20.00	2026-06-23 22:01:57.53503	available	2026-07-01 15:31:57.529838
608	13800000018	655	24.00	2026-06-30 13:10:57.53503	available	2026-07-01 15:31:57.529838
609	13800000014	656	8.00	2026-06-29 21:32:57.53503	available	2026-07-01 15:31:57.529838
610	13800000027	657	20.00	2026-07-01 05:13:57.53503	available	2026-07-01 15:31:57.529838
611	13800000022	658	24.00	2026-06-30 05:53:57.53503	available	2026-07-01 15:31:57.529838
612	13800000033	659	24.00	2026-06-24 22:03:57.53503	available	2026-07-01 15:31:57.529838
613	13800000034	660	12.00	2026-06-28 08:22:57.53503	available	2026-07-01 15:31:57.529838
614	13800000031	661	24.00	2026-06-27 18:51:57.53503	available	2026-07-01 15:31:57.529838
615	13800000001	662	24.00	2026-07-01 08:34:57.53503	available	2026-07-01 15:31:57.529838
616	13800000030	665	16.00	2026-06-26 16:33:57.53503	available	2026-07-01 15:31:57.529838
617	13800000024	666	24.00	2026-07-01 06:06:57.53503	available	2026-07-01 15:31:57.529838
618	13800000050	667	20.00	2026-07-01 01:44:57.53503	available	2026-07-01 15:31:57.529838
619	13800000023	668	8.00	2026-06-30 08:30:57.53503	available	2026-07-01 15:31:57.529838
620	13800000026	669	16.00	2026-07-01 06:55:57.53503	available	2026-07-01 15:31:57.529838
621	13800000022	670	12.00	2026-07-01 06:46:57.53503	available	2026-07-01 15:31:57.529838
622	13800000028	671	24.00	2026-06-23 18:52:57.53503	available	2026-07-01 15:31:57.529838
623	13800000044	672	24.00	2026-06-24 03:46:57.53503	available	2026-07-01 15:31:57.529838
624	13800000040	675	12.00	2026-06-28 05:14:57.53503	available	2026-07-01 15:31:57.529838
625	13800000020	676	20.00	2026-06-29 12:24:57.53503	available	2026-07-01 15:31:57.529838
626	13800000044	677	16.00	2026-06-28 23:48:57.53503	available	2026-07-01 15:31:57.529838
627	13800000015	678	20.00	2026-06-28 09:55:57.53503	available	2026-07-01 15:31:57.529838
628	13800000047	679	16.00	2026-06-27 16:43:57.53503	available	2026-07-01 15:31:57.529838
629	13800000048	680	24.00	2026-06-28 20:40:57.53503	available	2026-07-01 15:31:57.529838
630	13800000025	681	8.00	2026-06-28 08:27:57.53503	available	2026-07-01 15:31:57.529838
631	13800000016	682	8.00	2026-06-27 06:00:57.53503	available	2026-07-01 15:31:57.529838
632	13800000022	685	16.00	2026-06-28 09:21:57.53503	available	2026-07-01 15:31:57.529838
633	13800000006	686	12.00	2026-06-27 20:01:57.53503	available	2026-07-01 15:31:57.529838
634	13800000001	687	8.00	2026-06-30 16:17:57.53503	available	2026-07-01 15:31:57.529838
635	13800000007	688	12.00	2026-06-25 16:56:57.53503	available	2026-07-01 15:31:57.529838
636	13800000041	689	8.00	2026-06-24 06:48:57.53503	available	2026-07-01 15:31:57.529838
637	13800000050	690	24.00	2026-06-24 20:07:57.53503	available	2026-07-01 15:31:57.529838
638	13800000013	691	24.00	2026-06-27 14:18:57.53503	available	2026-07-01 15:31:57.529838
639	13800000038	692	8.00	2026-06-23 18:48:57.53503	available	2026-07-01 15:31:57.529838
640	13800000025	695	20.00	2026-06-27 19:25:57.53503	available	2026-07-01 15:31:57.529838
641	13800000017	696	24.00	2026-06-29 21:23:57.53503	available	2026-07-01 15:31:57.529838
642	13800000025	697	16.00	2026-06-25 17:12:57.53503	available	2026-07-01 15:31:57.529838
643	13800000021	698	8.00	2026-06-25 22:14:57.53503	available	2026-07-01 15:31:57.529838
644	13800000039	699	16.00	2026-06-30 15:01:57.53503	available	2026-07-01 15:31:57.529838
645	13800000027	700	20.00	2026-06-24 21:16:57.53503	available	2026-07-01 15:31:57.529838
646	13800000037	701	16.00	2026-06-29 11:26:57.53503	available	2026-07-01 15:31:57.529838
647	13800000042	702	20.00	2026-06-25 02:26:57.53503	available	2026-07-01 15:31:57.529838
648	13800000025	705	8.00	2026-06-29 17:39:57.53503	available	2026-07-01 15:31:57.529838
649	13800000010	706	8.00	2026-07-01 11:41:57.53503	available	2026-07-01 15:31:57.529838
650	13800000014	707	16.00	2026-06-24 03:16:57.53503	available	2026-07-01 15:31:57.529838
651	13800000048	708	16.00	2026-06-26 01:18:57.53503	available	2026-07-01 15:31:57.529838
652	13800000009	709	20.00	2026-06-27 17:53:57.53503	available	2026-07-01 15:31:57.529838
653	13800000024	710	20.00	2026-06-30 19:08:57.53503	available	2026-07-01 15:31:57.529838
654	13800000028	711	20.00	2026-06-26 14:05:57.53503	available	2026-07-01 15:31:57.529838
655	13800000035	712	12.00	2026-07-01 04:30:57.53503	available	2026-07-01 15:31:57.529838
656	13800000014	715	20.00	2026-06-28 05:10:57.53503	available	2026-07-01 15:31:57.529838
657	13800000013	716	12.00	2026-06-24 00:00:57.53503	available	2026-07-01 15:31:57.529838
658	13800000050	717	12.00	2026-06-23 18:50:57.53503	available	2026-07-01 15:31:57.529838
659	13800000026	718	16.00	2026-06-30 15:22:57.53503	available	2026-07-01 15:31:57.529838
660	13800000035	719	16.00	2026-06-29 05:30:57.53503	available	2026-07-01 15:31:57.529838
661	13800000016	720	20.00	2026-06-27 01:39:57.53503	available	2026-07-01 15:31:57.529838
662	13800000043	721	20.00	2026-06-28 19:10:57.53503	available	2026-07-01 15:31:57.529838
663	13800000010	722	20.00	2026-06-30 19:11:57.53503	available	2026-07-01 15:31:57.529838
664	13800000037	725	8.00	2026-06-30 10:51:57.53503	available	2026-07-01 15:31:57.529838
665	13800000016	726	16.00	2026-06-25 07:06:57.53503	available	2026-07-01 15:31:57.529838
666	13800000046	727	8.00	2026-06-23 17:40:57.53503	available	2026-07-01 15:31:57.529838
667	13800000018	728	20.00	2026-06-28 04:13:57.53503	available	2026-07-01 15:31:57.529838
668	13800000023	729	24.00	2026-06-29 20:43:57.53503	available	2026-07-01 15:31:57.529838
669	13800000028	730	16.00	2026-06-30 23:47:57.53503	available	2026-07-01 15:31:57.529838
670	13800000028	731	16.00	2026-06-24 13:29:57.53503	available	2026-07-01 15:31:57.529838
671	13800000002	732	16.00	2026-06-30 11:06:57.53503	available	2026-07-01 15:31:57.529838
672	13800000017	735	8.00	2026-07-01 07:39:57.53503	available	2026-07-01 15:31:57.529838
673	13800000047	736	20.00	2026-06-29 22:38:57.53503	available	2026-07-01 15:31:57.529838
674	13800000017	737	8.00	2026-06-30 06:17:57.53503	available	2026-07-01 15:31:57.529838
675	13800000049	738	24.00	2026-06-25 06:16:57.53503	available	2026-07-01 15:31:57.529838
676	13800000024	739	16.00	2026-06-27 08:02:57.53503	available	2026-07-01 15:31:57.529838
677	13800000005	740	20.00	2026-06-26 02:38:57.53503	available	2026-07-01 15:31:57.529838
678	13800000028	741	12.00	2026-06-30 19:37:57.53503	available	2026-07-01 15:31:57.529838
679	13800000049	742	16.00	2026-06-29 05:33:57.53503	available	2026-07-01 15:31:57.529838
680	13800000044	745	8.00	2026-07-01 05:44:57.53503	available	2026-07-01 15:31:57.529838
681	13800000015	746	24.00	2026-06-26 06:05:57.53503	available	2026-07-01 15:31:57.529838
682	13800000045	747	12.00	2026-06-26 19:03:57.53503	available	2026-07-01 15:31:57.529838
683	13800000023	748	8.00	2026-06-26 13:35:57.53503	available	2026-07-01 15:31:57.529838
684	13800000038	749	16.00	2026-06-24 11:11:57.53503	available	2026-07-01 15:31:57.529838
685	13800000004	750	12.00	2026-06-24 10:14:57.53503	available	2026-07-01 15:31:57.529838
686	13800000001	751	16.00	2026-06-28 23:40:57.53503	available	2026-07-01 15:31:57.529838
687	13800000032	752	8.00	2026-06-23 20:52:57.53503	available	2026-07-01 15:31:57.529838
688	13800000021	755	24.00	2026-06-29 12:56:57.53503	available	2026-07-01 15:31:57.529838
689	13800000046	756	24.00	2026-06-28 11:38:57.53503	available	2026-07-01 15:31:57.529838
690	13800000006	757	12.00	2026-06-25 00:55:57.53503	available	2026-07-01 15:31:57.529838
691	13800000050	758	16.00	2026-06-26 13:53:57.53503	available	2026-07-01 15:31:57.529838
692	13800000041	759	8.00	2026-06-24 00:40:57.53503	available	2026-07-01 15:31:57.529838
693	13800000027	760	24.00	2026-06-27 06:37:57.53503	available	2026-07-01 15:31:57.529838
694	13800000027	761	12.00	2026-06-24 20:17:57.53503	available	2026-07-01 15:31:57.529838
695	13800000045	762	16.00	2026-06-24 17:29:57.53503	available	2026-07-01 15:31:57.529838
696	13800000008	765	12.00	2026-06-08 07:08:57.53503	available	2026-07-01 15:31:57.529838
697	13800000011	766	12.00	2026-06-20 01:58:57.53503	available	2026-07-01 15:31:57.529838
698	13800000015	767	12.00	2026-06-05 08:15:57.53503	available	2026-07-01 15:31:57.529838
699	13800000044	768	16.00	2026-06-17 21:00:57.53503	available	2026-07-01 15:31:57.529838
700	13800000036	769	8.00	2026-06-17 18:51:57.53503	available	2026-07-01 15:31:57.529838
701	13800000010	770	12.00	2026-06-18 07:10:57.53503	available	2026-07-01 15:31:57.529838
702	13800000041	771	16.00	2026-06-18 04:58:57.53503	available	2026-07-01 15:31:57.529838
703	13800000010	772	12.00	2026-06-14 04:49:57.53503	available	2026-07-01 15:31:57.529838
704	13800000022	775	24.00	2026-06-17 14:23:57.53503	available	2026-07-01 15:31:57.529838
705	13800000031	776	8.00	2026-06-03 06:12:57.53503	available	2026-07-01 15:31:57.529838
706	13800000009	777	16.00	2026-06-19 13:48:57.53503	available	2026-07-01 15:31:57.529838
707	13800000009	778	12.00	2026-06-14 13:48:57.53503	available	2026-07-01 15:31:57.529838
708	13800000015	779	12.00	2026-06-04 17:56:57.53503	available	2026-07-01 15:31:57.529838
709	13800000025	780	20.00	2026-06-16 03:31:57.53503	available	2026-07-01 15:31:57.529838
710	13800000027	781	12.00	2026-06-13 07:57:57.53503	available	2026-07-01 15:31:57.529838
711	13800000033	782	12.00	2026-06-09 04:37:57.53503	available	2026-07-01 15:31:57.529838
731	15836489131	1420	20.00	2026-07-02 09:01:05.34263	available	2026-07-02 09:01:05.34263
735	19245821928	1423	20.00	2026-07-02 09:16:32.454222	available	2026-07-02 09:16:32.454222
738	19836582073	1416	20.00	2026-07-02 09:19:37.266298	available	2026-07-02 09:19:37.266298
741	18738065631	1432	20.00	2026-07-02 09:32:12.108895	available	2026-07-02 09:32:12.108895
744	19339616898	1426	20.00	2026-07-02 09:36:59.92869	available	2026-07-02 09:36:59.92869
747	15842660777	1444	20.00	2026-07-02 09:42:24.574592	available	2026-07-02 09:42:24.574592
750	19836511038	1442	20.00	2026-07-02 09:48:31.253862	available	2026-07-02 09:48:31.253862
753	15103773844	1410	20.00	2026-07-02 10:00:04.624579	available	2026-07-02 10:00:04.624579
756	18137062351	1448	20.00	2026-07-02 10:10:23.694185	available	2026-07-02 10:10:23.694185
759	15637001160	1430	20.00	2026-07-02 10:22:42.628829	available	2026-07-02 10:22:42.628829
762	17627072353	1458	20.00	2026-07-02 10:28:02.839115	available	2026-07-02 10:28:02.839115
765	15695672792	1457	20.00	2026-07-02 10:32:09.11778	available	2026-07-02 10:32:09.11778
768	15343725078	1467	20.00	2026-07-02 10:41:00.734204	available	2026-07-02 10:41:00.734204
772	19850171704	1465	20.00	2026-07-02 10:57:45.932407	available	2026-07-02 10:57:45.932407
775	18836568219	1452	20.00	2026-07-02 11:09:22.586076	available	2026-07-02 11:09:22.586076
712	13800000012	785	8.00	2026-05-14 16:38:57.53503	pending	2026-07-01 15:31:57.529838
713	13800000035	786	8.00	2026-05-31 08:48:57.53503	pending	2026-07-01 15:31:57.529838
714	13800000042	787	12.00	2026-05-15 15:17:57.53503	pending	2026-07-01 15:31:57.529838
715	13800000050	788	8.00	2026-05-05 03:58:57.53503	pending	2026-07-01 15:31:57.529838
716	13800000009	789	16.00	2026-05-08 16:42:57.53503	pending	2026-07-01 15:31:57.529838
717	13800000013	790	16.00	2026-05-06 20:23:57.53503	pending	2026-07-01 15:31:57.529838
718	13800000025	791	24.00	2026-05-27 15:44:57.53503	pending	2026-07-01 15:31:57.529838
719	13800000024	792	20.00	2026-05-13 06:43:57.53503	pending	2026-07-01 15:31:57.529838
720	13800000035	795	24.00	2026-05-02 23:09:57.53503	pending	2026-07-01 15:31:57.529838
721	13800000045	796	8.00	2026-05-27 13:05:57.53503	pending	2026-07-01 15:31:57.529838
722	13800000044	797	12.00	2026-05-10 18:14:57.53503	pending	2026-07-01 15:31:57.529838
723	13800000009	798	24.00	2026-05-29 06:22:57.53503	pending	2026-07-01 15:31:57.529838
724	13800000044	799	8.00	2026-05-11 00:24:57.53503	pending	2026-07-01 15:31:57.529838
725	13800000026	800	8.00	2026-05-30 03:15:57.53503	pending	2026-07-01 15:31:57.529838
726	13800000050	801	20.00	2026-05-04 14:15:57.53503	pending	2026-07-01 15:31:57.529838
727	13800000016	802	12.00	2026-05-05 17:11:57.53503	pending	2026-07-01 15:31:57.529838
778	18237036782	1477	20.00	2026-07-02 11:16:08.886142	pending	2026-07-02 11:16:08.886142
781	13183298887	1439	20.00	2026-07-02 11:26:35.874486	available	2026-07-02 11:26:35.874486
784	18253020029	1493	20.00	2026-07-02 11:34:55.163287	available	2026-07-02 11:34:55.163287
787	18260768573	1478	20.00	2026-07-02 11:49:13.48526	available	2026-07-02 11:49:13.48526
790	15837068521	1407	20.00	2026-07-02 12:27:12.576395	available	2026-07-02 12:27:12.576395
793	13557288765	1417	20.00	2026-07-02 14:23:36.995262	available	2026-07-02 14:23:36.995262
796	17527227908	1501	20.00	2026-07-02 14:33:40.216701	pending	2026-07-02 14:33:40.216701
802	18530250688	1503	20.00	2026-07-02 14:37:48.02642	available	2026-07-02 14:37:48.02642
799	17554760510	1495	20.00	2026-07-02 14:36:18.333201	pending	2026-07-02 14:36:18.333201
805	15137051381	1512	20.00	2026-07-02 14:44:45.203243	available	2026-07-02 14:44:45.203243
808	15265092163	1497	20.00	2026-07-02 15:04:15.009602	available	2026-07-02 15:04:15.009602
811	18272662178	1510	20.00	2026-07-02 15:30:17.998753	pending	2026-07-02 15:30:17.998753
814	19037881852	1518	20.00	2026-07-02 15:34:14.815568	available	2026-07-02 15:34:14.815568
817	18455712691	1504	20.00	2026-07-02 15:36:44.833655	available	2026-07-02 15:36:44.833655
820	15737005525	1516	20.00	2026-07-02 15:41:18.18303	available	2026-07-02 15:41:18.18303
823	17838825515	1532	20.00	2026-07-02 15:44:52.281961	available	2026-07-02 15:44:52.281961
826	17555309098	1521	20.00	2026-07-02 15:55:34.135671	available	2026-07-02 15:55:34.135671
829	15236859855	1513	20.00	2026-07-02 15:59:49.333715	available	2026-07-02 15:59:49.333715
832	17503709333	1542	20.00	2026-07-02 16:09:52.815477	available	2026-07-02 16:09:52.815477
835	16692633387	1544	20.00	2026-07-02 16:18:13.635629	available	2026-07-02 16:18:13.635629
838	18888889999	1551	20.00	2026-07-02 22:06:05.625793	available	2026-07-02 22:06:05.625793
842	13667618419	1549	20.00	2026-07-02 22:29:07.29601	available	2026-07-02 22:29:07.29601
\.


--
-- Data for Name: user_balances; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.user_balances (id, phone, balance, total_deposited, total_withdrawn, first_use_time, created_at, wechat_name, openid, unionid) FROM stdin;
43	15138943614	20	20	0	2026-06-30 16:04:17.893278	2026-06-30 16:04:17.890288			\N
2	13667618419	20	440	440	2026-06-12 13:50:47	2026-06-12 13:50:47	\N	oLhbm2DHcugL3Ez0gSfl4vlKPIUw	\N
7	13800138000	0	0	0	2026-06-12 04:31:14	2026-06-12 04:31:14	\N		\N
31	18438398466	40	40	0	2026-06-30 13:31:26.666245	2026-06-30 13:31:26.664399		oWrA812I_KJbezJSGRt8wnBfzK4s	\N
1	13667164843	0	0	0	2026-06-13 04:29:00	2026-06-13 04:29:00	\N		\N
27	15806753783	20	20	0	2026-06-30 12:40:50.15943	2026-06-30 12:40:50.157881			\N
4	13667618494	0	0	0	2026-06-13 08:45:25	2026-06-13 08:45:25	\N		\N
5	13667619418	0	0	0	2026-06-12 14:06:46	2026-06-12 14:06:46	\N		\N
6	13800001111	0	0	0	2026-06-12 04:57:50	2026-06-12 04:57:50	\N		\N
8	13811112222	0	0	0	2026-06-12 04:37:27	2026-06-12 04:37:27	\N		\N
9	13833334444	0	0	0	2026-06-12 04:41:06	2026-06-12 04:41:06	\N		\N
10	13844445555	0	0	0	2026-06-12 04:52:38	2026-06-12 04:52:38	\N		\N
11	13855556666	0	0	0	2026-06-12 04:57:20	2026-06-12 04:57:20	\N		\N
12	13877778888	0	0	0	2026-06-12 05:07:27	2026-06-12 05:07:27	\N		\N
13	13900001111	0	0	0	2026-06-11 08:46:51	2026-06-11 08:46:51	\N		\N
37	18265820019	0	20	20	2026-06-30 15:09:03.914187	2026-06-30 15:09:03.911412			\N
14	13900139000	0	0	0	2026-06-15 04:33:51	2026-06-15 04:33:51	\N		\N
21	18896963355	0	0	0	2026-06-26 09:27:18.112343	2026-06-26 01:27:18	\N		\N
16	13667618719	0	0	0	2026-06-23 22:42:29.591611	2026-06-23 14:42:29	\N		\N
15	18996093393	-31	142	0	2026-06-13 00:48:12	2026-06-13 00:48:12	\N	oWrA819aVj0AQxk0XRwFiuGi9W5k	\N
17	17725196748	0	0	0	2026-06-24 10:25:47.775458	2026-06-24 02:25:47	\N		\N
36	19254304011	20	20	0	2026-06-30 14:53:12.631388	2026-06-30 14:53:12.629742			\N
48	15656087879	0	20	0	2026-06-30 18:23:09.849548	2026-06-30 18:23:09.845366			\N
40	15324821187	20	40	0	2026-06-30 15:27:44.657406	2026-06-30 15:27:44.656072			\N
32	15657821278	20	20	0	2026-06-30 13:41:31.475858	2026-06-30 13:41:31.473033		oWrA8119oPBjRQBBnEdipGqRawa8	\N
244	18888889999	80	220	120	2026-07-02 22:22:11.833434	2026-07-02 22:22:11.829386		oWrA81-wvf2HDTxBYtigtDeifFYs	\N
150	18530783963	40	40	0	2026-07-02 08:04:37.349191	2026-07-02 08:04:37.347861		oWrA81xX8hez494yZ9-kMOkXXQ4c	\N
232	17634328712	40	40	0	2026-07-02 15:33:56.578037	2026-07-02 15:33:56.576589		oWrA81ztTXW1He3CfMl8mOG2feqM	\N
209	17527227908	20	40	0	2026-07-02 13:54:42.469417	2026-07-02 13:54:42.46797		oWrA817nAVIOva_3x9Nr-Oomqvv8	\N
216	15136011309	20	20	0	2026-07-02 14:35:11.69038	2026-07-02 14:35:11.687958		oWrA814a2nNpcpm6wn0rsN5_cl1Y	\N
25	19905939796	20	20	0	2026-06-30 10:53:43.923934	2026-06-30 10:53:43.918668		oWrA81x-B7qKpyyzunCQ79w_44Uo	\N
45	19137096192	0	20	20	2026-06-30 16:17:34.493401	2026-06-30 16:17:34.490627		oWrA81wqfJhuq3HGJQDiZ2Ak3Tfs	\N
39	19286022436	0	20	0	2026-06-30 15:18:21.868913	2026-06-30 15:18:21.865765		oWrA81yNEVUEKWc7GIPodzG2yGXE	\N
47	18637010208	-20	20	20	2026-06-30 16:31:24.754185	2026-06-30 16:31:24.751435		oWrA8123pVky5DBpbOF-0YgfVVOA	\N
57	18238060772	40	40	0	2026-07-01 11:58:57.556178	2026-07-01 11:58:57.554516		oWrA8165UBZ7Orymi-LSK1VjzqzQ	\N
61	17838930615	20	20	0	2026-07-01 12:41:57.729292	2026-07-01 12:41:57.726626		oWrA814FpDvSeL8zrtGms5pmTL34	\N
157	19233600317	20	40	0	2026-07-02 08:34:13.57945	2026-07-02 08:34:13.577836		oWrA8177WxIeNqyqQzQDe3yP2Y58	\N
208	15939273255	40	40	0	2026-07-02 13:42:05.397507	2026-07-02 13:42:05.39621		oWrA81-P8o1xlaZJIc_VsRJwp1Iw	\N
218	15660881573	20	20	0	2026-07-02 14:36:53.179953	2026-07-02 14:36:53.177058		oWrA817WxsE5e2yQdyUtmMPIYRrQ	\N
202	17753648530	80	80	0	2026-07-02 11:26:35.610745	2026-07-02 11:26:35.608926		oWrA815j2zKUz_ITVwi98Zz3XETg	\N
213	15137051381	40	40	0	2026-07-02 14:15:33.549858	2026-07-02 14:15:33.548394		oWrA813UlMB5Lcgr348eJ_7sgGrg	\N
238	19337089231	0	20	0	2026-07-02 15:47:53.352849	2026-07-02 15:47:53.350256		oWrA815sx6kJjrzjGgTlP1ybY5UM	\N
210	17698950605	20	40	0	2026-07-02 14:02:48.817791	2026-07-02 14:02:48.816151		oWrA819UjvsavRe5EzlNKw46Eqo4	\N
194	15938352984	40	60	0	2026-07-02 10:42:14.709526	2026-07-02 10:42:14.707536		oWrA81yXA2cIn-m6OHGbotLqLQi0	\N
224	15919267157	20	40	0	2026-07-02 15:03:25.653977	2026-07-02 15:03:25.652632		oWrA815JUJ37T0UZRAH3stjwiNZM	\N
55	18356795403	40	40	0	2026-07-01 11:57:44.34442	2026-07-01 11:57:44.342858		oWrA815X34Q0bdaJaGtxESJEC7cE	\N
49	18254067609	20	20	0	2026-06-30 18:28:15.649222	2026-06-30 18:28:15.649222		oWrA81yIpUhQohO1TptlV1HLGlGU	\N
67	15554513417	20	20	0	2026-07-01 13:26:41.383523	2026-07-01 13:26:41.381057		oWrA8120rleeG_cU57X62VK9CytA	\N
63	15798651828	0	20	0	2026-07-01 12:46:20.425117	2026-07-01 12:46:20.422248		oWrA81zv-1BW57sCu570qx28bQgA	\N
70	18137063193	20	20	0	2026-07-01 14:18:41.557959	2026-07-01 14:18:41.555404		oWrA81--Z4Op2Q70yCPLojW8e2Ns	\N
59	19165928949	0	20	0	2026-07-01 12:35:19.708791	2026-07-01 12:35:19.706301		oWrA81zIpOyNSHnd_FrJiX9XLyMA	\N
51	19261605685	20	40	0	2026-07-01 08:34:20.714751	2026-07-01 08:34:20.712975		oWrA813GNHV6SjKHLTefeayzCI1E	\N
69	18336926660	40	40	0	2026-07-01 14:18:28.544398	2026-07-01 14:18:28.542924		oWrA818XVpD8LoLHNMkgx7tfHTCE	\N
65	15054012361	-20	20	0	2026-07-01 13:04:53.694789	2026-07-01 13:04:53.691973		oWrA815CE4K5rUqMmftCAJTm1S30	\N
23	18983079797	41	41	0	2026-06-27 18:04:23.736538	2026-06-27 18:04:23.731391		oWrA81-sAdleVupXM1QWH2jwpywk	\N
20	17726689234	0	280	140	2026-06-26 07:04:32.799063	2026-06-25 23:04:32	\N	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
35	19544562686	-20	40	20	2026-06-30 14:18:37.079977	2026-06-30 14:18:37.078243		oWrA814ZbDx9Sa3EUrwREReSYPhY	\N
29	18326741968	40	40	0	2026-06-30 12:52:31.091806	2026-06-30 12:52:31.08996		oWrA81xM1eyqfXkFpnjHU05ps_LU	\N
33	18953074181	40	40	0	2026-06-30 13:46:23.955858	2026-06-30 13:46:23.954144		oWrA811vea15wVBi1JfZ3bWsqaQU	\N
24	17722332233	0	80	80	2026-06-28 08:41:27.717903	2026-06-28 08:41:27.715242		oWrA81xyJP1aI7beoqhd2rxBGPfw	\N
53	18705206991	20	40	0	2026-07-01 09:05:25.812059	2026-07-01 09:05:25.810047		oWrA819Zjec3Z04Pb-rAgMOQ-nsE	\N
154	19139362917	40	40	0	2026-07-02 08:17:16.143882	2026-07-02 08:17:16.142713		oWrA81xA9gzh57QS5csiBbNkTPGE	\N
72	18691666092	0	20	0	2026-07-01 14:59:40.600278	2026-07-01 14:59:40.597697		oWrA811jjTbF5LBNF3y4f5Vds2CE	\N
168	15824752199	20	20	0	2026-07-02 09:12:36.377194	2026-07-02 09:12:36.374992		oWrA811Ywqe14WBCysW4hxNgAAxU	\N
151	16650694701	20	40	0	2026-07-02 08:11:49.497386	2026-07-02 08:11:49.495721		oLhbm2FsOXehsq0hbDNTlmOLSS5E	\N
156	18738065631	40	40	0	2026-07-02 08:23:59.333652	2026-07-02 08:23:59.332289		oWrA8184R5USheUKUd6aNfRal1fM	\N
159	13783560310	40	40	0	2026-07-02 08:36:51.834344	2026-07-02 08:36:51.83297		oWrA81xGKZXuj6d1GJzKvmxZ1W7I	\N
158	19913257953	40	40	0	2026-07-02 08:34:15.641492	2026-07-02 08:34:15.640035		oWrA81zbmnzK7nJjzMnagrb8bojM	\N
152	19339616898	40	40	0	2026-07-02 08:15:01.836025	2026-07-02 08:15:01.834349		oWrA814uiMq24c_vGENp0TEARkKA	\N
161	15842660777	40	40	0	2026-07-02 08:45:30.13531	2026-07-02 08:45:30.133952		oWrA810Y8WflOSvGD02abudm10Ag	\N
160	19836511038	40	40	0	2026-07-02 08:42:45.844218	2026-07-02 08:42:45.842603		oWrA8165r_1j3OPLw-g-gCViRQMs	\N
153	19837087059	40	40	0	2026-07-02 08:16:47.048819	2026-07-02 08:16:47.047392		oWrA813midBHJj2gaaxjeVGWHyFo	\N
181	15539090389	20	20	0	2026-07-02 10:00:24.077999	2026-07-02 10:00:24.076588		oWrA812YRQLw0X9WUZStfvUrtwOA	\N
162	19337028036	0	20	0	2026-07-02 08:45:41.008138	2026-07-02 08:45:41.005646		oWrA812oTTIp1f3twgeW-_0xEtgs	\N
185	18133317626	0	20	0	2026-07-02 10:11:34.382485	2026-07-02 10:11:34.379322		oLhbm2FZ9P28KBn5ApgCiGpMs5r0	\N
155	15637001160	40	40	0	2026-07-02 08:17:55.150953	2026-07-02 08:17:55.149546		oLhbm2EnsrO-ZkeR8tHm0hY6gCY8	\N
175	15237883857	40	40	0	2026-07-02 09:36:36.448141	2026-07-02 09:36:36.446248		oWrA813ogxC3GhKPZQZ47Ag8lE3Q	\N
195	19840015972	20	20	0	2026-07-02 10:44:35.913428	2026-07-02 10:44:35.910863		oWrA818KJlRo33yjDQXZUXyc1SA8	\N
167	18338751797	20	40	0	2026-07-02 09:08:51.68897	2026-07-02 09:08:51.687299		oWrA811zMPTqnGWHvmqlBfn2wwJA	\N
178	18272685238	0	20	0	2026-07-02 09:46:01.690725	2026-07-02 09:46:01.688145		oWrA814xoEvsso80LHMIF3J9Beiw	\N
41	15238586310	100	100	0	2026-06-30 15:30:47.066451	2026-06-30 15:30:47.06444		oWrA816bz5qUV3jcjZcEuRMHFH44	\N
199	18513686701	20	20	0	2026-07-02 11:06:24.347545	2026-07-02 11:06:24.345044		oWrA815kB7bWZbwC9RHh3L3qZF6g	\N
188	15836493002	20	40	0	2026-07-02 10:27:49.57941	2026-07-02 10:27:49.577701		oWrA81_rFRm7u2X-oilv9yZLkMQY	\N
192	18237036782	20	40	0	2026-07-02 10:33:37.588329	2026-07-02 10:33:37.586678		oWrA81_LWtK9aJ8SZef2ODkoIZrc	\N
146	19836582073	20	40	0	2026-07-02 07:56:46.055545	2026-07-02 07:56:46.054196		oWrA812v0tMAGKvDt_KYlQO1m2Y8	\N
204	18253020029	20	40	0	2026-07-02 11:30:53.634691	2026-07-02 11:30:53.633313		oWrA815n0urc4XyC3tj_9X4Q-Cuc	\N
34	15550752925	20	20	0	2026-06-30 13:51:57.652261	2026-06-30 13:51:57.649631		oWrA8105UJTohMvSF-xYM6nVUWOA	\N
38	13791463202	20	20	0	2026-06-30 15:17:35.705352	2026-06-30 15:17:35.702619		oWrA819H2B8_mgblRP2ZpM42vNUY	\N
42	17837383155	20	20	0	2026-06-30 15:53:14.210799	2026-06-30 15:53:14.208293		oWrA819WcGgl_cqgsG8_eviSMIC4	\N
30	15275043796	0	40	20	2026-06-30 13:29:47.109922	2026-06-30 13:29:47.107098		oWrA817RU4v8eQ-ItnK1Sjcj3d7Q	\N
46	15225299085	20	20	0	2026-06-30 16:18:10.690747	2026-06-30 16:18:10.688146		oWrA81_esql0oaMLcsIiLopvL1Ro	\N
44	15836435632	0	20	0	2026-06-30 16:09:27.311529	2026-06-30 16:09:27.308745		oWrA817pPlLyzrGVF3-hC7nUqcmM	\N
28	18265005796	-20	40	20	2026-06-30 12:51:45.822212	2026-06-30 12:51:45.820534		oWrA81-ItgTPxpuU_KnmJnRQIZc8	\N
54	15090698884	20	20	0	2026-07-01 10:25:55.517593	2026-07-01 10:25:55.515148		oWrA810fvi3viiR0SZjFt8saWwj8	\N
60	15964428331	0	20	0	2026-07-01 12:40:02.396973	2026-07-01 12:40:02.394209		oWrA816xdTuUlnwYSMz_AD2X4m88	\N
62	15514642606	20	20	0	2026-07-01 12:45:09.37755	2026-07-01 12:45:09.374782		oWrA819Lx-sIzmvxY6tz8YZjwNIc	\N
56	17346902460	40	40	0	2026-07-01 11:57:46.540332	2026-07-01 11:57:46.53896		oWrA81xN1nYud88nFNzeIP1nvHzI	\N
50	13655676086	40	40	0	2026-07-01 08:03:09.601406	2026-07-01 08:03:09.599874		oLhbm2ELXC34oFmP0lsNf1Ot1iCA	\N
68	17838863123	20	20	0	2026-07-01 13:33:42.601201	2026-07-01 13:33:42.598876		oWrA814e5qmXK53w6jTxGFCQvrMo	\N
66	15186672778	40	40	0	2026-07-01 13:07:02.260419	2026-07-01 13:07:02.258701		oWrA81_Kec6OckOEGFtA4JK6ivgE	\N
71	18439030153	20	20	0	2026-07-01 14:56:27.661444	2026-07-01 14:56:27.658175		oWrA817SgAsGAcHjpLZsg9x3poLk	\N
147	13557288765	120	120	0	2026-07-02 08:03:19.649199	2026-07-02 08:03:19.647304		oWrA811Qp4IUIc8nb3HcQAyb4Fic	\N
170	19245821928	20	20	0	2026-07-02 09:16:32.456899	2026-07-02 09:16:32.454222		oWrA813mcLnMvQmNYtkVPU8VQKmA	\N
189	15082976378	40	40	0	2026-07-02 10:30:21.003937	2026-07-02 10:30:21.001972		oLhbm2PocIcfNQ4WGD1NSHqtUbx0	\N
64	15136012752	0	20	0	2026-07-01 12:55:33.342475	2026-07-01 12:55:33.339775		oWrA816c_JmOH0j8iJ0Icdo59A48	\N
58	19025302365	0	40	0	2026-07-01 11:59:04.202355	2026-07-01 11:59:04.200883		oWrA81ycBLSSc4MBzuD4oFZuMBfo	\N
165	15751766581	0	40	0	2026-07-02 09:00:53.276975	2026-07-02 09:00:53.275652		oWrA811t76_2yyWusSObq9nSrfcg	\N
176	15909265992	20	20	0	2026-07-02 09:40:05.728981	2026-07-02 09:40:05.726193		oWrA818VHew3gFO623fbttvT6txM	\N
26	15617060696	0	40	0	2026-06-30 12:40:07.35341	2026-06-30 12:40:07.351634		oWrA81w-5cgkKNolzfRIie4yxyu0	\N
179	19139066893	20	20	0	2026-07-02 09:59:24.363728	2026-07-02 09:59:24.360976		oLhbm2EPNzH7fIg51R4voCEe1yiY	\N
52	17861769100	0	40	0	2026-07-01 08:53:52.598248	2026-07-01 08:53:52.596585		oWrA817c8U3V_yL3p7whB9YfxycQ	\N
183	15515613024	0	20	0	2026-07-02 10:05:21.38159	2026-07-02 10:05:21.378451		oWrA810DW_yygbMfuYYQvU640g6M	\N
164	18137062351	40	40	0	2026-07-02 08:56:14.947273	2026-07-02 08:56:14.945675		oWrA812OXNMzRfoAM_-w9lTAf0J8	\N
200	18836568219	0	20	0	2026-07-02 11:09:22.58854	2026-07-02 11:09:22.586076		oWrA811XkchsEFE3FOiVex5RHtZA	\N
190	19149247152	20	20	0	2026-07-02 10:31:11.31831	2026-07-02 10:31:11.315761		oWrA816FYQPXOeLqf4Jf17S8y3V4	\N
169	13213132919	60	60	0	2026-07-02 09:14:32.373399	2026-07-02 09:14:32.371727		oLhbm2L_VX83kwHGtp10m_uZhTlU	\N
193	15343725078	20	20	0	2026-07-02 10:41:00.736821	2026-07-02 10:41:00.734204		oWrA81_QYIhpTnIP_MguSINPWeMQ	\N
148	15993979586	40	40	0	2026-07-02 08:03:32.240785	2026-07-02 08:03:32.238153		oWrA814HKJCkcV1qPzdiW-kGgh0Q	\N
182	19850171704	40	40	0	2026-07-02 10:01:40.285542	2026-07-02 10:01:40.284311		oWrA81wJNprd-lhv0B7zEZGRpR8Q	\N
203	13183298887	20	20	0	2026-07-02 11:26:35.877032	2026-07-02 11:26:35.874486		oWrA815ug_YJ7QxjM61cAsF7JcNU	\N
186	13523176144	40	80	0	2026-07-02 10:15:34.614113	2026-07-02 10:15:34.612812		oWrA817TcXvAw-MlNurmpFzu7MTY	\N
196	15617023131	20	40	0	2026-07-02 10:48:43.864864	2026-07-02 10:48:43.86363		oWrA81-IRSJObx78pJHOh_rAdMCc	\N
197	13856712830	20	40	0	2026-07-02 10:48:54.409455	2026-07-02 10:48:54.408176		oLhbm2Juw9wVRI4ZXSEYhrRw5pTY	\N
205	18530250688	60	60	0	2026-07-02 11:35:33.996262	2026-07-02 11:35:33.993414		oWrA8193Mm87lcVp84Wv7r0UNEyQ	\N
207	17554760510	20	40	0	2026-07-02 12:48:11.305525	2026-07-02 12:48:11.304031		oWrA81yGgyQp6k0KArC2bDCg-AOo	\N
235	15737005525	20	20	0	2026-07-02 15:41:18.185855	2026-07-02 15:41:18.18303		oLhbm2NF1iiboWasqwEiXBWviqQc	\N
217	13323972142	0	20	0	2026-07-02 14:36:36.308436	2026-07-02 14:36:36.305709		oWrA81yzw_POSOjDnBWrj73937C4	\N
231	17739015172	20	20	0	2026-07-02 15:32:44.357939	2026-07-02 15:32:44.355216		oWrA816i6Sh2fGUYosFrRUlooqU4	\N
219	19037881852	40	40	0	2026-07-02 14:39:15.67134	2026-07-02 14:39:15.669929		oWrA813XY9444KQ-jha8DDs9QkJM	\N
220	15836704325	40	40	0	2026-07-02 14:39:19.272717	2026-07-02 14:39:19.271327		oWrA811dZeSPnohPZAUJrsoSyVCk	\N
233	18455712691	20	20	0	2026-07-02 15:36:44.836718	2026-07-02 15:36:44.833655		oWrA817WlHfrZUcskfKLMmqTuZCI	\N
223	15690868029	60	60	0	2026-07-02 14:52:49.205984	2026-07-02 14:52:49.203725		oWrA818JXY2ke-_WwcrdF-38BRyE	\N
237	13037508763	0	20	0	2026-07-02 15:42:05.277991	2026-07-02 15:42:05.27532		oWrA81wO1786IWNXq1FDGLhLNzFs	\N
227	17838825515	40	40	0	2026-07-02 15:08:23.465484	2026-07-02 15:08:23.463944		oWrA81-HaXjCIpJLaElFsOc2c2gY	\N
222	17555309098	40	40	0	2026-07-02 14:46:13.763761	2026-07-02 14:46:13.761767		oWrA815i3m7PT-6lU3FM6eLjv3wM	\N
241	18238033278	20	20	0	2026-07-02 16:06:53.290718	2026-07-02 16:06:53.288316		oLhbm2HZkvXVQ6v_cybMC7LG5-xQ	\N
242	19913817011	0	20	0	2026-07-02 16:16:03.095567	2026-07-02 16:16:03.092494		oWrA812nZV4AU4uKQLkUP2jOojkg	\N
228	15560048291	0	40	0	2026-07-02 15:14:08.119057	2026-07-02 15:14:08.117521		oWrA8153eXe4paFZN2xGYV_sT0wc	\N
214	15236859855	40	40	0	2026-07-02 14:20:58.574492	2026-07-02 14:20:58.572966		oWrA814i0R3Twjzkz8oJauUChfEY	\N
166	18838441692	20	20	0	2026-07-02 09:06:36.039173	2026-07-02 09:06:36.035745		oWrA816aueWI5e_0YLIs67waiWBQ	\N
174	13460149121	20	20	0	2026-07-02 09:29:04.609566	2026-07-02 09:29:04.606787		oWrA816HTb34u_l7onE9K378FUeY	\N
149	15836489131	20	40	0	2026-07-02 08:04:04.186294	2026-07-02 08:04:04.18451		oWrA810QKe4UvoUGtbjxzCCAvRLs	\N
177	15839096977	20	20	0	2026-07-02 09:41:21.867678	2026-07-02 09:41:21.865232		oWrA815egAE_pNywyzuTiI4e2OZQ	\N
180	15103773844	20	20	0	2026-07-02 10:00:04.628066	2026-07-02 10:00:04.624579		oWrA816r2XDtvPrsYSYu7CYL3Jh4	\N
184	15660700620	20	20	0	2026-07-02 10:10:01.708431	2026-07-02 10:10:01.705431		oWrA818dHKZ_5gHq_XAXghC3Hpic	\N
187	17550270621	40	40	0	2026-07-02 10:17:50.463548	2026-07-02 10:17:50.461928		oWrA818pWmo_jLWCMOI9N82JPLSQ	\N
172	17627072353	40	40	0	2026-07-02 09:28:48.74619	2026-07-02 09:28:48.744614		oLhbm2M3LzSrgB2-BYQJKN1dQ5U8	\N
191	15695672792	20	20	0	2026-07-02 10:32:09.12049	2026-07-02 10:32:09.11778		oWrA817KtvSu6zXKQJJUqYJb9UTg	\N
230	18738086168	0	20	0	2026-07-02 15:29:51.418921	2026-07-02 15:29:51.416061		oWrA816eRP5_FiWPMOi70wsPN4vY	\N
215	17503709333	40	60	0	2026-07-02 14:27:48.537886	2026-07-02 14:27:48.535157		oWrA81z7APIi80z5qbuLjBW44FMA	\N
171	18530272656	20	40	0	2026-07-02 09:27:35.306715	2026-07-02 09:27:35.305108		oWrA816oaku14e9dBVLjDIMnnfX8	\N
198	15937086006	20	20	0	2026-07-02 10:58:58.620977	2026-07-02 10:58:58.619401		oWrA8121MDcJ_BFR0HwO-FrCDkoU	\N
201	15065370778	20	20	0	2026-07-02 11:09:35.549336	2026-07-02 11:09:35.546162		oWrA81wuBCqHNzGr9sDF-wFXJp2I	\N
173	18736838325	20	40	0	2026-07-02 09:29:01.746745	2026-07-02 09:29:01.74513		oWrA81wGkKUTMb3SpY4-FDmVsEwQ	\N
206	18260768573	20	20	0	2026-07-02 11:49:13.48825	2026-07-02 11:49:13.48526		oWrA816Cp9pI4S2Z4a357GgTeImc	\N
145	15837068521	40	40	0	2026-07-02 07:46:37.935288	2026-07-02 07:46:37.929955		oWrA817JN3Bz9532eCCUzjuU7x-0	\N
240	17530271182	0	20	0	2026-07-02 16:01:03.735058	2026-07-02 16:01:03.732352		oWrA811TwH7MogCPmuLm7kYsr9SE	\N
239	16692633387	40	40	0	2026-07-02 15:55:28.1365	2026-07-02 15:55:28.135015		oWrA81z4E1a6VqllQU0uvYd8zzwk	\N
221	19639308701	-20	60	0	2026-07-02 14:41:42.623239	2026-07-02 14:41:42.620585		oWrA81-zeWU3yEM4u6Kbk8NxGWc4	\N
211	18039160828	20	40	0	2026-07-02 14:08:06.765063	2026-07-02 14:08:06.763883		oWrA810XuBZkcAV8pyGXYUhpCLA4	\N
212	18272662178	20	40	0	2026-07-02 14:08:47.456652	2026-07-02 14:08:47.455382		oWrA810A_OcB_7y5WIAkbKFcoIQg	\N
225	13619875632	40	40	0	2026-07-02 15:03:50.663387	2026-07-02 15:03:50.661879		oWrA812bIt3wABkRP5W74pZqnzAM	\N
236	15603705779	20	20	0	2026-07-02 15:41:44.422886	2026-07-02 15:41:44.419979		oWrA814Am6sA-8OcprrgCQGFPMOM	\N
234	19273906997	40	40	0	2026-07-02 15:39:55.613928	2026-07-02 15:39:55.612152		oWrA811nPB5h_tQVxuI4CzaD3ZX4	\N
229	19251695576	20	40	0	2026-07-02 15:29:43.761907	2026-07-02 15:29:43.760353		oWrA812HZXwlQ55AENyFFBYx3a-c	\N
226	15265092163	0	20	0	2026-07-02 15:04:15.012474	2026-07-02 15:04:15.009602		oLhbm2GiCaKhEaaqfMQbOunafSCo	\N
163	15239932935	20	40	0	2026-07-02 08:48:12.839668	2026-07-02 08:48:12.837995		oWrA816T8KS6QqBABmZa2xuqWmTY	\N
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.user_profiles (openid, wechat_name, updated_at, unionid) FROM stdin;
oLhbm2EIT023DkRuiPqj6APR4ihs	智空	2026-06-30 14:42:08.867673	\N
oLhbm2CXJc6pavQnuCs6MckJCwas	乐观的悲观者	2026-06-30 14:47:29.733244	\N
oLhbm2FDANhiUAWBXIAONn214dqI	微信用户	2026-07-02 15:03:03.826966	\N
oLhbm2AvvUOwVozZZfm5HcFIqo2M	力	2026-06-30 14:52:38.141819	\N
oLhbm2ABYy3nt1CKFaBxbpHBdXcc	微信用户	2026-06-30 14:52:41.121321	\N
oLhbm2EsutFALRZhVWPATION6_Ng	.	2026-06-30 14:52:50.267843	\N
oLhbm2H09XtplEUhVW46VY-c1Xf4	微信用户	2026-06-30 15:15:02.601331	\N
oLhbm2DjPAgvVpBQdWbtZv0pn4WM	易小名	2026-06-30 15:24:34.606998	\N
oLhbm2OgNeOSiAfcoTRzC12cPJMw	沐泽.	2026-06-30 15:24:54.36629	\N
oLhbm2I0XFboukiKwYeoAhtiD-Rw	不考一本不改名	2026-06-30 15:27:14.809806	\N
oLhbm2EToXyVevCGUzDTqLV8gSuc	微信用户	2026-07-01 08:39:50.168726	\N
oLhbm2H6Cfq3ycUGbXyF_PdQhJAk	-	2026-06-30 12:37:48.740227	\N
oLhbm2N5EDl6FFtWeHD3cOPuH1ns	Lucas	2026-06-30 12:38:04.599553	\N
oLhbm2LLh7ggG9qQlPIYvGCzFgTQ	闲游一生	2026-06-30 12:39:08.336324	\N
oLhbm2FLRJGUPAfzViiQHKngpXqU	微信用户	2026-07-02 09:28:18.125227	\N
oLhbm2O6OboL0tQL7Kl6V1XC8iPg	微信用户	2026-07-02 15:21:18.261311	\N
oLhbm2KvyCUTFmrM3cKFpKTNOJAg	王语诺	2026-06-30 12:39:19.818554	\N
oLhbm2EhTRGAcmO8GqNc97KHagLw	R	2026-06-30 12:39:21.704179	\N
oLhbm2MjWCP87tHOgcoOh1lBQjoo	云雾	2026-06-30 12:39:35.140439	\N
oLhbm2Oiyq0fdl-stXmjrMU3JiGg	.	2026-06-30 12:39:39.262795	\N
oLhbm2HnWSjZrQUXeSOA4N449J0E	单思豪	2026-06-30 12:39:54.343009	\N
oLhbm2JuYEboN4SxLUlNKpfSfT24	阿啵	2026-06-30 12:40:59.611252	\N
oLhbm2A6JtOJDpTlfI_IMhKZwr9Y	微信用户	2026-06-30 12:49:55.638167	\N
oLhbm2MNeHErtSinzW5UZduIFMRE	十二.	2026-06-30 12:50:10.564032	\N
oLhbm2F46i0hw0ncI9vJ6QL0p2Y8	智能寄存柜	2026-06-30 09:50:01.910301	\N
oLhbm2DpiO4RBSoDGSY5fG7qbRSk	熊页翔	2026-06-30 10:14:36.191432	\N
oLhbm2L37l3xIo9NfOo1XoQXCq54	吴彦祖	2026-06-30 12:50:41.87017	\N
oLhbm2CegcLUOudngMNwdzBhHA7U	666智能寄存柜	2026-07-02 16:17:43.329436	\N
oLhbm2Llm6eRKQfe2xuISqK2gOkQ	王长军	2026-06-30 12:50:53.07693	\N
oLhbm2E8bLv1WOodh6RQta1A_fDU	明月人静夜	2026-06-30 10:42:10.889456	\N
oLhbm2IDJeTxYyadP8lnXcbVbXaw	瑾儿	2026-06-30 10:42:34.330377	\N
oLhbm2KI-nFeB8GquYu3BRHKG4Ho	微信用户	2026-06-30 15:50:53.414424	\N
oLhbm2KV03rQh9xd6xQ8Gj42cA2I	烟雨	2026-06-30 15:51:02.799344	\N
oLhbm2PT4OTbk3nO81vNjlKIhE5g	微信用户	2026-07-02 15:28:40.107649	
oLhbm2LPScxGqKQwih_qAzbspcac	初心	2026-06-30 13:04:04.444317	\N
oLhbm2HEFZP-hSYr5ZGwGQDEArNw	小星	2026-06-30 13:04:33.735222	\N
oLhbm2OIiOVK8BGCSaFS6o-Y1FXI	微信用户	2026-07-02 07:56:13.15803	\N
oLhbm2Ox2Z7oerbXhmM7Cb3Qv3mQ	 	2026-06-30 13:12:37.299486	\N
oLhbm2BclnrQy_uaR6Mgf9V0vsWQ	卖鸡的卖鸡的卖鸡的收摊！！！	2026-06-30 13:28:52.901929	\N
oLhbm2OM7IdiwSgi40RfJo27jvTc	微信用户	2026-06-30 13:30:35.433104	\N
oLhbm2ITc8YCUR8upK8PIRRy6xqc	诸葛匹夫子	2026-06-30 13:30:45.855339	\N
oLhbm2FX0qKKA9juI_bTL7i_bdeg	骑猪看夕阳	2026-06-30 13:33:45.443291	\N
oLhbm2BaKKHhX9pfBL-K7Jj7lTR4	微信用户	2026-06-30 13:45:34.052405	\N
oLhbm2H3hzWZ79Aku76YUHNt7OHw	望眠屿	2026-06-30 13:45:41.442991	\N
oLhbm2EAwGhxbH1ky5KZDqCH4Aw4	微信用户	2026-07-02 14:37:38.941612	\N
oLhbm2L5idqDPVz28EQ4Ir6HIvCU	逸逸的奇妙冒险	2026-06-30 13:48:24.336655	\N
oLhbm2A5LSGwnBCHK2VEVPgq_0ZU	微信用户	2026-07-02 07:45:24.666099	
oLhbm2E9D3EVMJSh1Y1TM7tvYg4A	微信用户	2026-07-02 09:28:13.829517	\N
oLhbm2CRvKiA4RCLMlM513iqcb_o	能能～杨惠丹17838863123	2026-07-01 08:40:41.36324	
oLhbm2Ks4WcpQdMtm6cri6aJ9MN0	Shhshiii_	2026-06-30 14:00:36.769047	\N
oLhbm2KrlZvBmZAyjLvWIz84Y9Ys	....King	2026-06-30 14:14:48.395104	\N
oLhbm2J6Kzl6-UFdSrodo05bkES4	微信用户	2026-07-02 10:27:17.981686	\N
oLhbm2E8WSNST7xidFWa1K6w-eq4	雪芙🍰	2026-06-30 14:15:00.523837	\N
oLhbm2DLwLhKx1sJJ9nFrDzPuoWI	乐游	2026-06-30 14:15:25.692415	\N
oLhbm2Nyj6xFLVYq5lMRnukqNRQw	Kovy.🍀	2026-06-30 14:15:57.078296	\N
oLhbm2Fo3JFprUsWfsfSS5mmF8WA	微信用户	2026-06-30 14:17:45.36862	\N
oLhbm2KSXafPUmo7PMKg3qp8fqHQ	X	2026-06-30 14:17:57.927567	\N
oLhbm2LrGNu2Ka_r96cs6wF-Tu0E	小王	2026-07-02 21:53:43.552084	\N
oLhbm2EqedLPca2_VAPNwPSg919U	微信用户	2026-07-02 07:45:52.097924	\N
oLhbm2GvwSDsBQ8sQpGBSI7Mn54U	微信用户	2026-07-02 09:27:10.822837	\N
oLhbm2NHMIb0QoUXSzSUVqaPUzXs	微信用户	2026-07-01 08:32:19.992445	
oLhbm2GXrL8741t9ryJDJmAHpa3k	不想睡	2026-07-01 08:32:30.347869	
oLhbm2BX88UBKYrByTPrvBS6hCKA	微信用户	2026-07-01 08:57:42.62003	\N
oLhbm2L44a6N2wjslnTM3d1_ADAM	远方不远	2026-07-01 08:33:40.064677	
oLhbm2EZ1nbD-lprp6bYvqdQFXzU	ㅤ	2026-07-01 08:57:51.990947	
oLhbm2FflYFhvA87W0OA2iGUa0sU	长城	2026-07-01 09:04:20.447208	
oLhbm2IKU1hjvWzontU_nfBXhvOg	清风	2026-07-01 10:13:17.019124	
oLhbm2OXtnYOix_zmbmo57vCQuyA	微信用户	2026-07-02 07:47:33.022453	\N
oLhbm2HsJGTwT1dgbemrapthwWS0	微信用户	2026-07-02 14:35:28.235177	\N
oLhbm2ELXC34oFmP0lsNf1Ot1iCA		2026-07-01 13:32:58.118562	
oLhbm2A1us7NZNLb46nrW8Etu26A	我是一只咪	2026-07-01 11:57:03.885109	
oLhbm2OpP9rpfBnfIrUjNx8Zwnfo	詹贺博	2026-07-01 11:57:03.946623	
oLhbm2CeM-32zjafTNxvwRfTjx7E	    陈科皓	2026-07-01 11:57:03.973401	
oLhbm2EVb0lz2VUhyIxIR0kw5BL4	葛一嘉	2026-07-01 11:57:05.876588	
oLhbm2L5k6d5GNl9L7phFUoR_GoE	椿.	2026-07-01 11:57:09.577282	
oLhbm2AZnD3s6cyNda3cnHyPQYyM	微信用户	2026-07-02 13:54:11.815278	\N
oLhbm2HxZeKl4csdD5gkM7bmurj0	微信用户	2026-07-02 14:14:46.799671	\N
oLhbm2OvV35n-SHDJjFh0s28rBhw	微信用户	2026-07-02 14:17:45.917794	\N
oLhbm2Kv31twyLrcSjrNQLq5y834	微信用户	2026-07-02 08:59:32.857783	
oLhbm2NPmTXytEfJHCQe8A0TPKyE	微信用户	2026-07-02 10:03:24.800435	\N
oLhbm2PEsutbrx1I7HHa3rDDzfU0	微信用户	2026-07-02 13:40:13.725921	
oLhbm2Ca0aITNBPd86WtJmeRDK8o	微信用户	2026-07-02 15:02:54.141904	\N
oLhbm2B51PnUhE7xLwREJUvZ6EEI	微信用户	2026-07-02 15:37:33.61979	\N
oLhbm2KhBL_EwHD5hvwekgdwC8TQ	微信用户	2026-07-02 08:33:45.686077	\N
oLhbm2Owiw63J-xSNSs89hgdtvuc	花园吴洋	2026-07-02 10:57:21.045937	\N
oLhbm2NCQcJbu27amdxV0CAIJQNM	微信用户	2026-07-02 09:00:16.021776	\N
oLhbm2PIllEdcv-LGy1MALDhyuQY	微信用户	2026-07-02 10:58:21.78127	\N
oLhbm2HwT3rn7zE_ciqgvf0l3bEM	微信用户	2026-07-02 10:16:55.024186	
oLhbm2EXpgzKEypXs0nbAAOYGaao	微信用户	2026-07-02 14:38:35.233494	
oLhbm2Dl7uLa70dVcAb9F27u-HWk	微信用户	2026-07-02 10:46:36.371209	\N
oLhbm2DEq7Wqmw5hMe-5kDGnHqPk	微信用户	2026-07-02 11:19:46.716699	\N
oLhbm2PBws2XUF7Sol5n-zB4y-iw	微信用户	2026-07-02 14:38:43.094494	\N
oLhbm2IWu4x8r-U9ZFh4E7Tw55ZE	五万五	2026-07-02 12:47:41.012364	\N
oLhbm2EoF3zqez6Iu7dbSwFcCdCA	微信用户	2026-07-02 15:07:35.085234	\N
oLhbm2DHcugL3Ez0gSfl4vlKPIUw	？？？	2026-07-02 22:12:30.272097	\N
oLhbm2Cn0EK2TCWtKawcI86UbGrE	惜来年	2026-07-01 11:57:26.413747	
oLhbm2GFRWEeFeC5Q33Trpxt2gYY	微信用户	2026-07-01 11:58:06.01121	
oLhbm2JD0MnWEzPBIQrrybgdW3pI	让我再睡会吧	2026-07-01 11:58:39.007328	
oLhbm2IpUX6BAu8J8HwE_fCK13M0	Nașul	2026-07-01 11:58:41.158741	
oLhbm2Pr38fBYUndHepuJv6Y4ZCM	赴朝暮.	2026-07-01 11:58:47.929302	
oLhbm2PJNpj7UjmQ1gY7IPKHiVQI	微信用户	2026-07-02 09:08:04.219212	
oLhbm2L0gC5qYQLg2ZCBVLe2HS0E	初阳熙	2026-07-01 11:57:19.543416	
oLhbm2Mgbf22Ws2801iYU6U8W-t0	。	2026-07-01 11:57:47.846228	
oLhbm2Kfavu6clgEtUuMSmwO3x-Y	王	2026-07-01 11:58:14.429101	
oLhbm2G77EPfGRV6TTeSyiV5egtw	CC66	2026-07-01 11:58:18.196455	
oLhbm2ExJdIuZorgWfsZkbcrXOHQ	Zzzzz、	2026-07-01 11:58:16.364037	
oLhbm2KvsRD4tOE8eo4XA3uegPfQ	Lotus	2026-07-01 11:59:28.011967	
oLhbm2N8kOzk_BJImxLGWNy_Wdyg	敬昨天，李忠義	2026-07-01 12:05:46.876141	
oLhbm2DCMTdvfB99q7FDv7EBUdQc	mmdw_my	2026-07-01 12:55:47.624528	
oLhbm2IGvFUMEyi78SYT5XTMGqss	石头	2026-07-01 13:06:14.153005	
oLhbm2I-siUVrWtxdiD7pQMgxGgU	微信用户	2026-07-01 14:17:35.074723	
oLhbm2E82K8eFrNuVesg1ryNVjl0	芦浩【超市精品专供】	2026-07-01 14:17:44.703279	
oLhbm2L7IgpILGY6BNX50_iKkERk	早睡	2026-07-01 14:54:17.354124	
oLhbm2EDN92D20OHQ2AXPWfN4RvA	໑ຼ້ₒ₂₅ོ财神的小心甘	2026-07-02 07:45:36.521465	
oLhbm2N3rW0C6DrVT46cyR2-3sCY	。。。	2026-07-02 07:46:59.843244	
oLhbm2EP-R_qFB_YyNrfS2uz6iA8	next.	2026-07-02 07:47:01.762817	
oLhbm2P1IuyNdo13RTb2LciLqhqU	微信用户	2026-07-02 07:48:21.251456	
oLhbm2MBUR-XiPfgZeqigu6qzFjU	ぴ夏末烟雨	2026-07-02 07:48:23.248886	
oLhbm2AXKx2eoxKIRnh8tdL9iZOs	AAA余兴华15839055361	2026-07-02 07:49:25.379636	
oLhbm2Hi2prbVHsTXbZVO4JeC0b4	.	2026-07-02 07:56:19.902958	
oLhbm2M_uKEU_AAPerHGZgxHrZRA	北雨	2026-07-02 08:03:26.47812	
oLhbm2J8RBlcnMZYP_c49Z2ei1yo	空	2026-07-02 08:03:32.514897	
oLhbm2KSXmsJaaGXBEbasqG7TkQY	F.	2026-07-02 08:04:06.339193	
oLhbm2MNijy29Hn-YelXcUD0VVRg	商丘古城	2026-07-02 08:04:54.46131	
oLhbm2OAFSzfoyb3kCY70TQwvlNE	微信用户	2026-07-02 08:08:00.132739	
oLhbm2Gif4y250PGmKehVcpnz-PI	约定看海.	2026-07-02 08:08:06.106218	
oLhbm2FsOXehsq0hbDNTlmOLSS5E	瘦肉丸	2026-07-02 08:11:15.374848	
oLhbm2JU9VtKW5Qla7poNlpsRXek	a-晚风.	2026-07-02 08:14:21.712088	
oLhbm2Gff1xJor74Z0CVzd37GzKo	张义坤	2026-07-02 08:15:34.145482	
oLhbm2Ov7_QoCuIfwk1TIldcD4Xg	慢慢	2026-07-02 08:16:07.227414	
oLhbm2F1Zlzwyjy9f6H8VupZ1x-A	微信用户	2026-07-02 08:16:26.240504	
oLhbm2NZAiOxe2bjwir40b7OG7jI	c🍩l🍩r	2026-07-02 08:16:36.409236	
oLhbm2KUUDoWa7LOE6TrWHMLYLdQ	微信用户	2026-07-02 08:17:12.640221	
oLhbm2EnsrO-ZkeR8tHm0hY6gCY8	联通路子欣15637001160	2026-07-02 08:17:22.66142	
oLhbm2EPNzH7fIg51R4voCEe1yiY	Gad	2026-07-02 08:17:44.58395	
oLhbm2CJcUhKgDiDBR4MrN4lGFHE	微信用户	2026-07-02 14:07:09.45421	
oLhbm2N_dcJ4ErxER-lMImO93k0Q	.	2026-07-02 08:23:26.483321	
oLhbm2OpGLp5HSeU4Mm11GSXcZ2Y	1123	2026-07-02 08:32:08.051802	
oLhbm2F5zoszujN0KW6ue-w6A22s	梧影伴曦行.	2026-07-02 08:32:26.871103	
oLhbm2BCUOifmOZqndPth4440fuU	DeeMo🌟	2026-07-02 08:32:47.619211	
oLhbm2JwRGQuHtEbvh9j8EgkySu0	微信用户	2026-07-02 08:33:24.79011	
oLhbm2G2Du0CeFc4BmIcsF1okBag	微信用户	2026-07-02 08:33:29.753553	
oLhbm2GbVJO2fhfoW1KOQEq2iJD0	：小 軒	2026-07-02 08:33:33.439738	
oLhbm2JCRk3BebcB_I_MIezYrHI4	.	2026-07-02 08:33:38.113739	
oLhbm2ETngOyhtZklK2PXCG54CfQ	A彩钢瓦方管圆管总经销13183298887	2026-07-02 08:33:58.324521	
oLhbm2B6WmFj_vLZ6pPEV4PMCQmE	微信用户	2026-07-02 08:35:23.313936	
oLhbm2L56C47nAKZ-cvuKQSMO8Yc	先吃饭	2026-07-02 08:35:31.448863	
oLhbm2Pg2ZkVrhHfdkiiEFx_FlgE	.	2026-07-02 08:36:15.163412	
oLhbm2GmvlAi65S-wRI1dWZxa8-8	孙宁	2026-07-02 08:42:08.181971	
oLhbm2LDCHMNZp_TtXwMDjfTc0fA	小鱼蛋	2026-07-02 08:44:22.854706	
oLhbm2Kp0T70XLIdx32smXPs7MFI	浩博	2026-07-02 08:44:51.468243	
oLhbm2FZ9P28KBn5ApgCiGpMs5r0	青衫湿	2026-07-02 08:47:29.504999	
oLhbm2MWk-Q10StX9abdN1gN1BP4	0906	2026-07-02 08:47:35.561982	
oLhbm2GzBB7MXim7JMITIC6bW2WI	云儿	2026-07-02 08:55:28.200556	
oLhbm2JIDZNVoCEaBawlBOLa8GXs	🌸一凡	2026-07-02 09:08:11.470217	
oLhbm2L_VX83kwHGtp10m_uZhTlU	许立业	2026-07-02 09:34:12.134915	
oLhbm2KE1cRsrIz2sB9QfvLP7lU0	林林林微微	2026-07-02 09:24:25.281131	
oLhbm2E-Jm9DYlgTnypRhASRPYPo	🌹🌹小趴菜🌹🌹	2026-07-02 09:26:45.716936	
oLhbm2P3sczKaZD3S4a66N3KQbnk	记住	2026-07-02 09:26:59.143263	
oLhbm2OTzUjV4dVtI2nMco-Q95to	微信用户	2026-07-02 09:27:15.787774	
oLhbm2G8cYMkhoOXLGJsDB5zhv8E	MD·鞋包集合店（朋友圈看款）	2026-07-02 09:27:22.249523	
oLhbm2EvHPF0gdb0NEHlWKi0cmos	Sincere	2026-07-02 09:27:26.793977	
oLhbm2G7rykLAwHGRFBP9jSB9RgY	微信用户	2026-07-02 09:28:09.346304	
oLhbm2M3LzSrgB2-BYQJKN1dQ5U8	海᳐蒂᳐੭ 🇨🇳	2026-07-02 09:28:18.194865	
oLhbm2NR6rHWolpvFgMrxGCWcWiM	温湖屿	2026-07-02 09:28:24.295844	
oLhbm2Me0L5ER1DO9oRnT68T1mEQ	微信用户	2026-07-02 09:28:31.877231	
oLhbm2KQhorgPtpcgrNHXfiA7Tgk	千杯不醉	2026-07-02 09:29:17.394713	
oLhbm2KHsGjdKaj-KW5NPGXO2na8	陈阳	2026-07-02 09:36:02.366787	
oLhbm2Bpx6dH_3x1_gXgd3p6DEyw	陈栋	2026-07-02 09:57:15.679146	
oLhbm2PVnXgE53w-cl5rskf3O4sI	·	2026-07-02 09:59:07.673767	
oLhbm2Lrd2GC4o71Ntrx2xmb0jdg	ez	2026-07-02 09:59:55.771207	
oLhbm2JsafCHoEP-xwkOxz3oEZwQ	K	2026-07-02 10:03:37.039205	
oLhbm2D1XpD_AnqJmUpCKIqz2Nqs	微信用户	2026-07-02 10:10:53.332594	
oLhbm2JK_KgPFrC5Bcc79bWYbQM8	微信用户	2026-07-02 10:32:43.135196	
oLhbm2OVDXTzXOIiS-vL1jIjS7YA	微信用户	2026-07-02 10:14:54.361088	
oLhbm2PSS3hx8k28bDKuI6KHEdaQ	AAAAAA姝淇《鹦鹉养殖》	2026-07-02 10:17:06.137153	
oLhbm2Gli9gcqLwUu9FMrGsO9Efs	哈艮图斯	2026-07-02 10:21:49.224482	
oLhbm2Ce8jpgEM_MXRD75pMjyKdo	¥	2026-07-02 10:23:11.215848	
oLhbm2CJXXwaD1YhMLnwHX2nEFAc	微信用户	2026-07-02 10:25:46.693763	
oLhbm2IjDbw193uaoCpKBAM0Qsks	杨又串	2026-07-02 10:25:54.684198	
oLhbm2DWu-DCipOTm1wg6cVOr3oo	-.-	2026-07-02 10:27:10.344844	
oLhbm2GhEBU_4vVII0BcsMr27BTI	微信用户	2026-07-02 10:29:47.871562	
oLhbm2PocIcfNQ4WGD1NSHqtUbx0	H	2026-07-02 10:29:56.239802	
oLhbm2CYT0IHqGLW5iwlgZgJ06X0	车干	2026-07-02 10:32:49.560089	
oLhbm2HwqBBdt5ibIHisQv_nNsdE	微信用户	2026-07-02 15:38:38.119476	
oLhbm2B3KdXkTe3FObpero71Vyrs	微信用户	2026-07-02 10:45:43.512813	
oLhbm2Lh-iEctrtsINez3DXwSMqo	微信用户	2026-07-02 14:07:19.490597	
oLhbm2OU_X5WN1H4VQiftwIDyEnQ	微信用户	2026-07-02 11:28:01.714065	
oLhbm2Bmru55OEwR7GO_XUAVSGQA	💕坤ℒℴѵℯ小ۣۖ¹³¹⁴	2026-07-02 11:43:30.894911	
oLhbm2JCj8SyaMAMnDouzqTU6Mn4	微信用户	2026-07-02 15:33:04.273402	
oLhbm2DXN7oRf1jd2ZTXC1BgFAJA	微信用户	2026-07-02 15:02:52.961286	
oLhbm2Aqy4kHLXGaiNc7zdFuIPSc	微信用户	2026-07-02 14:07:22.801716	
oLhbm2E_uEdLhTqUUDTUstbRFaow	微信用户	2026-07-02 14:37:18.169368	
oLhbm2OkS4ucDwWNNEtm2bate9Vo	微信用户	2026-07-02 14:38:33.957898	
oLhbm2NoGtqexgHG98RzrCxV7O_o	年糕	2026-07-02 10:33:01.927059	
oLhbm2BMrvkeWnq1-aHlqW-IiTHY	卖萌被肘击	2026-07-02 10:42:48.239999	
oLhbm2HcW7tlAex7RZXoFI0kuvw4	微信用户	2026-07-02 10:47:42.458027	\N
oLhbm2Juw9wVRI4ZXSEYhrRw5pTY	J	2026-07-02 10:48:19.805709	
oLhbm2AAJPdfscNqs9GFlJ11JI7k	Mwacy	2026-07-02 10:58:27.834049	
oLhbm2HNMSl0-W2kYLzDbQxxwjRQ	～快乐～	2026-07-02 11:22:13.047614	
oLhbm2Bx_veqCcNDKVsUYYg5yEYc	W.	2026-07-02 11:28:09.027775	
oLhbm2LFI6kgmZxxrrcggr4nd7y4	水木清华💖🇨🇳🐉🌹🌹	2026-07-02 11:28:22.82416	
oLhbm2HUA4adAvzJZmx9caqf8nRc	深仁厚泽	2026-07-02 11:58:02.291197	
oLhbm2GiCaKhEaaqfMQbOunafSCo	L	2026-07-02 13:40:27.012457	
oLhbm2FlIOqZSgR27FVn1N6g3CNg	微信用户	2026-07-02 13:40:30.894917	
oLhbm2IRMVqsHU3oexL4abbdCRnI	Joy芝士	2026-07-02 13:40:55.072437	
oLhbm2GlfnsOK6Hg24ZIQ6EXdcpY	微信用户	2026-07-02 13:41:16.516815	
oLhbm2Iw1gM2X9pMpO_xPWuGDOvs	很酷勿扰	2026-07-02 13:41:22.504288	
oLhbm2D0tALH_PkvEwuLEQi4S5j8	拾安	2026-07-02 13:41:24.467641	
oLhbm2Chfy91AVNedVPbCSbAmAf8	别看我i	2026-07-02 13:54:17.827895	
oLhbm2FP9-jq5C9UyoflBmiqJgYc	一江远山	2026-07-02 14:02:03.484928	
oLhbm2Noc53F_Ner3yyq6Uc8uOL4	鲨鱼辣椒	2026-07-02 14:03:01.498642	
oLhbm2EbNIfjlPAEQUn5ZKYq2tyk	微信用户	2026-07-02 14:07:07.717986	
oLhbm2CpASAEviDrHGkJAQ2PxBUQ	🥟	2026-07-02 14:07:14.768393	
oLhbm2L4PzQSvEfkO5Oqkl4rG_1w	你尔多隆吗	2026-07-02 14:07:20.065347	
oLhbm2BV1esdA23OBjg7FWw-awxE	Yi.	2026-07-02 14:07:31.233357	
oLhbm2NQ8m_5BBEkDhv4zhyZVBIk	Cajay	2026-07-02 14:07:50.213864	
oLhbm2OQuHTKuscwzNruVzvdt5Uw	陈	2026-07-02 14:08:17.81256	
oLhbm2PAfsTLtUW7fQX3O7YjvqPo	。	2026-07-02 14:14:54.380009	
oLhbm2Mcd8LMFo0RVFVySY4TpR7s	'	2026-07-02 14:17:52.224679	
oLhbm2GPZSNFbho40tYMgVO2Jbjs	微信用户	2026-07-02 14:20:24.806096	
oLhbm2JjnuBYm9I5D0qHA0xnnu4s	暗流	2026-07-02 14:20:29.409868	
oLhbm2A7UsWcvJIW7JPXDocw46Yg	蛋团是七个好蛋	2026-07-02 14:35:34.656777	
oLhbm2PnVSQu6SBPObKtTRgLXqf4	嫋嫋	2026-07-02 14:37:24.792099	
oLhbm2NF1iiboWasqwEiXBWviqQc	一拳打穿地球	2026-07-02 14:37:45.727254	
oLhbm2FehFmUevIKlQWkdflxbYQk	邢佳旺	2026-07-02 14:38:41.56118	
oLhbm2N4Esxc4iSEgcGeWDKsJKvo	￣帆风顺666666	2026-07-02 14:45:00.400372	
oLhbm2KGr_kUVzG8ztxLj1Pfv3ek	微信用户	2026-07-02 14:47:47.865148	
oLhbm2K6PqfVryBJpsXCrSp8gXJw	体重下降	2026-07-02 14:48:49.038365	
oLhbm2NWfnBEOevhL2qr-HZjTKeo	LiJin	2026-07-02 14:55:12.934249	
oLhbm2Fttlk-8nhY6bAY5r_kgsbw	趙さん	2026-07-02 15:02:58.466605	
oLhbm2NzW60Xn7Xq2PvUNiP7mp1I	天马行空 🌌🛸	2026-07-02 15:03:01.868738	
oLhbm2LqPg4KGkDFLUvFvxtC3MVA	yoo	2026-07-02 15:03:09.18714	
oLhbm2B1dQFRW2az3jjPUO73AZg8	李鑫	2026-07-02 15:07:47.846007	
oLhbm2C518waUtAFU7yT8Zzc3PMc	怀旧辞	2026-07-02 15:13:40.982023	
oLhbm2LRtyfHYwry5K9QbQJAAcrk	W.	2026-07-02 15:21:23.251351	
oLhbm2JC1I3dU6SXjHSsosrzPF5g	7	2026-07-02 15:28:04.46873	
oLhbm2PWWZPWPjbetWUVEqX_owx0	比揽胜还懒的女人	2026-07-02 15:28:48.574404	
oLhbm2F_RoyHoEwlPyATqqt0BI3g	财神爷的小跟班	2026-07-02 15:33:11.045385	
oLhbm2LnrOCqZEh5Fc2F_5Ly_9DU	随心	2026-07-02 15:35:45.527801	
oLhbm2HZkvXVQ6v_cybMC7LG5-xQ	_.	2026-07-02 15:37:40.12015	
oLhbm2EgkAPWXaDoVYvbA5OfSSFw	￣へ￣	2026-07-02 15:38:45.734595	
oLhbm2OcxXKDObqo-GHHLt2Oi5GU	SHINE	2026-07-02 15:41:11.634766	
oLhbm2MzumFYqgrLL3AXVEtQdT08	微信用户	2026-07-02 15:53:08.769895	
oLhbm2OWROjlXnBn-UzbG-0YwQ9w	暮雪初	2026-07-02 15:53:18.777309	
oLhbm2MdmO8niK55nPB8F4rmOYdY	齐福祥设计二部 高文博	2026-07-02 15:54:50.341744	
\.


--
-- Data for Name: user_tokens; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.user_tokens (id, user_type, user_id, token, created_at) FROM stdin;
14	agent	1	c785834fe5ba4997b9ba800cde636744	2026-07-02 23:50:27.292993
15	agent	1	30a23671fbe536475ae0557b64858722	2026-07-03 00:34:57.572433
16	agent	1	46f2ddb8c0ecd7e62a1f1946b1747558	2026-07-03 01:10:37.835834
\.


--
-- Data for Name: withdrawal_records; Type: TABLE DATA; Schema: public; Owner: locker_admin
--

COPY public.withdrawal_records (id, order_id, user_phone, amount, status, apply_time, approve_time, approver, click_count, auto_approve_time, created_at, openid, error_msg, order_ids) FROM stdin;
3	\N	17725196748	20	3	2026-06-24 03:03:43	\N	\N	1	\N	2026-06-24 03:03:43	\N	\N	[]
4	\N	13667618419	20	3	2026-06-24 03:07:02	\N	\N	1	\N	2026-06-24 03:07:02	\N	\N	[]
5	\N	17725196748	20	3	2026-06-24 03:57:10	\N	\N	1	\N	2026-06-24 03:57:10	\N	\N	[]
6	\N	13667618419	10	3	2026-06-24 04:15:03	\N	\N	1	\N	2026-06-24 04:15:03	\N	\N	[]
7	\N	17725196748	20	2	2026-06-24 04:16:56	\N	\N	1	\N	2026-06-24 04:16:56	\N	\N	[]
9	\N	17725196748	20	3	2026-06-24 06:35:26	\N	\N	1	2026-06-24 06:35:26	2026-06-24 06:35:26	\N	\N	[]
10	\N	17725196748	20	3	2026-06-24 09:45:35	2026-06-24 09:47:18	admin	1	\N	2026-06-24 09:45:35	\N	\N	[]
14	196	17725196748	20	2	2026-06-24 12:08:58	2026-06-25 10:06:55	\N	1	2026-06-24 20:08:58	2026-06-24 12:08:58	\N	\N	[]
15	198	13667618419	20	2	2026-06-24 14:39:50	2026-06-25 10:06:56	\N	1	2026-06-24 22:39:50	2026-06-24 14:39:50	\N	\N	[]
17	\N	17725196748	40	3	2026-06-24 15:23:46	\N	\N	1	2026-06-24 15:23:46	2026-06-24 15:23:46	\N	\N	[]
18	129	13800138000	20	3	2026-06-24 16:59:19	\N	\N	1	2026-06-24 16:59:19	2026-06-24 16:59:19	\N	\N	[]
19	129	13800138000	20	3	2026-06-24 17:03:24	\N	\N	1	2026-06-24 17:03:24	2026-06-24 17:03:24	\N	\N	[]
20	277	17725196748	20	3	2026-06-25 09:49:11	\N	\N	1	2026-06-25 17:49:11	2026-06-25 09:49:11	\N	\N	[]
32	277	17725196748	20	2	2026-06-25 10:51:58	\N	system	1	2026-06-25 10:51:58	2026-06-25 10:51:58	\N	\N	[]
33	276	17725196748	10	2	2026-06-25 11:26:30	\N	system	1	2026-06-25 11:26:30	2026-06-25 11:26:30	\N	\N	[]
34	275	17725196748	20	2	2026-06-25 11:38:03	\N	system	1	2026-06-25 11:38:03	2026-06-25 11:38:03	\N	\N	[]
39	316	18888889999	20	2	2026-06-26 04:04:47	\N	system	1	2026-06-26 04:04:47	2026-06-26 04:04:47	\N	\N	[]
40	318	18888889999	20	2	2026-06-26 06:54:23	\N	system	1	2026-06-26 06:54:23	2026-06-26 06:54:23	\N	\N	[]
79	390	18888889999	20	2	2026-06-28 08:02:31.470551	\N	\N	1	2026-06-28 08:02:31.470551+08	2026-06-28 08:02:31.470551		\N	[]
94	\N	17722332233	100	5	2026-06-28 15:33:50.52335	\N	system_cleanup	1	\N	2026-06-28 15:33:50.52335	\N	\N	[]
38	315	18888889999	20	2	2026-06-26 02:48:21	\N	system	1	2026-06-26 02:48:21	2026-06-26 02:48:21	\N	订单已全额退款	[]
35	284	13667618419	20	3	2026-06-26 00:04:10	\N	\N	1	2026-06-26 00:04:10	2026-06-26 00:04:10	\N	\N	[]
36	188	13667618719	20	3	2026-06-26 00:06:38	\N	\N	1	2026-06-26 00:06:38	2026-06-26 00:06:38	\N	\N	[]
80	\N	18888889999	20	5	2026-06-28 08:39:07.769374	\N	system_cleanup	1	\N	2026-06-28 08:39:07.769374		\N	[]
44	302	17725196748	20	3	2026-06-26 21:07:22.894042	\N	\N	1	2026-06-26 21:07:22.894042+08	2026-06-26 21:07:22.894042	\N	\N	[]
45	302	17725196748	20	3	2026-06-26 21:11:30.524503	\N	\N	1	2026-06-26 21:11:30.524503+08	2026-06-26 21:11:30.524503	\N	\N	[]
85	\N	18888889999	460	5	2026-06-28 15:18:39.397813	\N	system_cleanup	1	\N	2026-06-28 15:18:39.397813	\N	\N	[]
86	\N	18888889999	460	5	2026-06-28 15:18:43.106437	\N	system_cleanup	1	\N	2026-06-28 15:18:43.106437	\N	\N	[]
87	\N	18888889999	460	5	2026-06-28 15:18:49.610057	\N	system_cleanup	1	\N	2026-06-28 15:18:49.610057	\N	\N	[]
83	\N	13800138000	10	5	2026-06-28 10:49:16.606119	\N	system_cleanup	1	\N	2026-06-28 10:49:16.606119	\N	\N	[]
21	\N	13800138000	5	3	2026-06-25 09:57:30	\N	\N	1	\N	2026-06-25 09:57:30	\N	\N	[]
43	302	17725196748	20	2	2026-06-26 19:56:16.528003	\N	\N	1	2026-06-26 19:56:16.528003+08	2026-06-26 19:56:16.528003	\N	\N	[]
88	\N	18888889999	460	5	2026-06-28 15:20:59.819987	\N	system_cleanup	1	\N	2026-06-28 15:20:59.819987	\N	\N	[]
22	\N	13800138000	5	3	2026-06-25 09:57:54	\N	\N	1	\N	2026-06-25 09:57:54	\N	\N	[]
89	\N	18888889999	460	5	2026-06-28 15:21:02.545764	\N	system_cleanup	1	\N	2026-06-28 15:21:02.545764	\N	\N	[]
23	265	13800138000	20	3	2026-06-25 09:58:35	\N	\N	1	\N	2026-06-25 09:58:35	\N	\N	[]
84	\N	13800138000	10	5	2026-06-28 12:16:47.023477	\N	system_cleanup	1	\N	2026-06-28 12:16:47.023477	\N	\N	[]
81	391	18996093393	47	5	2026-06-28 09:04:09.5201	\N	system_cleanup	1	\N	2026-06-28 09:04:09.5201	oLhbm2LrGNu2Ka_r96cs6wF-Tu0E	\N	[]
82	393	18983079797	3	5	2026-06-28 09:04:20.367748	\N	system_cleanup	1	\N	2026-06-28 09:04:20.367748	oLhbm2F46i0hw0ncI9vJ6QL0p2Y8	\N	[]
90	\N	17722332233	40	5	2026-06-28 15:22:32.563121	\N	system_cleanup	1	\N	2026-06-28 15:22:32.563121	\N	\N	[]
91	\N	13800138000	1	5	2026-06-28 15:24:18.840454	\N	system_cleanup	1	\N	2026-06-28 15:24:18.840454	\N	\N	[]
92	\N	17722332233	60	5	2026-06-28 15:24:30.750934	\N	system_cleanup	1	\N	2026-06-28 15:24:30.750934	\N	\N	[]
93	\N	17722332233	60	5	2026-06-28 15:24:32.700862	\N	system_cleanup	1	\N	2026-06-28 15:24:32.700862	\N	\N	[]
95	\N	17722332233	160	5	2026-06-28 16:07:49.110583	\N	system_cleanup	1	\N	2026-06-28 16:07:49.110583	\N	\N	[]
96	\N	17722332233	160	5	2026-06-28 16:07:50.923614	\N	system_cleanup	1	\N	2026-06-28 16:07:50.923614	\N	\N	[]
97	408	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N	[]
98	407	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N	[]
99	397	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N	[]
100	396	17722332233	20	2	2026-06-28 16:21:32.996878	\N	\N	1	2026-06-28 16:21:32.996878+08	2026-06-28 16:21:32.996878	\N	\N	[]
101	307	17726689234	20	2	2026-06-28 16:23:28.184636	\N	\N	1	2026-06-28 16:23:28.184636+08	2026-06-28 16:23:28.184636	\N	\N	[]
78	389	18888889999	20	4	2026-06-28 07:56:51.812019	\N	\N	1	2026-06-28 07:56:51.812019+08	2026-06-28 07:56:51.812019		记录不存在	[]
102	405	18888889999	20	2	2026-06-28 17:25:25.120129	\N	\N	1	2026-06-28 17:25:25.120129+08	2026-06-28 17:25:25.120129	\N	\N	[]
123	497	17726689234	20	2	2026-06-30 11:45:56.681978	\N	\N	1	2026-06-30 11:45:56.681978+08	2026-06-30 11:45:56.681978	\N	\N	[]
122	\N	13667618419	20	2	2026-06-30 11:42:48.554701	2026-06-30 11:50:07.656641	admin	1	\N	2026-06-30 11:42:48.554701		\N	[]
142	553	17726689234	20	2	2026-06-30 18:13:57.300004	2026-06-30 18:18:44.811429	admin	1	\N	2026-06-30 18:13:57.300004	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N	[]
151	556	17726689234	20	2	2026-06-30 18:53:55.270986	2026-06-30 19:50:30.618775	admin	1	\N	2026-06-30 18:53:55.270986	oLhbm2CegcLUOudngMNwdzBhHA7U	\N	[]
104	413	13667618419	20	2	2026-06-29 22:15:00.717779	\N	\N	1	2026-06-29 22:15:00.717779+08	2026-06-29 22:15:00.717779	\N	\N	[]
105	\N	18996093393	40	2	2026-06-30 09:13:17.248572	2026-06-30 09:51:24.294182	admin	1	\N	2026-06-30 09:13:17.248572	\N	\N	[]
106	\N	18983079797	41	2	2026-06-30 09:32:29.817975	2026-06-30 09:51:27.695488	admin	1	\N	2026-06-30 09:32:29.817975	\N	\N	[]
107	470	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
108	458	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
109	441	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
110	440	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
111	438	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
112	436	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
113	306	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
114	303	17726689234	20	2	2026-06-30 09:53:05.102253	\N	\N	1	2026-06-30 09:53:05.102253+08	2026-06-30 09:53:05.102253	\N	\N	[]
115	481	17726689234	20	2	2026-06-30 10:00:36.24959	\N	\N	1	2026-06-30 10:00:36.24959+08	2026-06-30 10:00:36.24959	\N	\N	[]
116	488	17726689234	20	2	2026-06-30 11:00:44.841762	\N	\N	1	2026-06-30 11:00:44.841762+08	2026-06-30 11:00:44.841762	\N	\N	[]
117	487	17726689234	20	2	2026-06-30 11:00:44.841762	\N	\N	1	2026-06-30 11:00:44.841762+08	2026-06-30 11:00:44.841762	\N	\N	[]
118	492	17726689234	20	2	2026-06-30 11:05:07.460834	\N	\N	1	2026-06-30 11:05:07.460834+08	2026-06-30 11:05:07.460834	\N	\N	[]
136	\N	18265005796	20	0	2026-06-30 15:16:16.196909	\N	\N	1	\N	2026-06-30 15:16:16.196909		\N	[514]
77	332	18888889999	20	2	2026-06-27 19:22:32.159527	\N	system	1	2026-06-27 19:22:32.159527+08	2026-06-27 19:22:32.159527	\N	订单已全额退款	[]
380	1419	15515613024	20	0	2026-07-02 10:06:03.765426	\N	\N	1	\N	2026-07-02 10:06:03.765426	oLhbm2M_uKEU_AAPerHGZgxHrZRA	\N	[]
125	498	13667618419	20	2	2026-06-30 12:06:15.143365	\N	\N	1	2026-06-30 12:06:15.143365+08	2026-06-30 12:06:15.143365	\N	\N	[]
152	558	17726689234	20	2	2026-06-30 19:24:29.929941	2026-06-30 19:50:34.406098	admin	1	\N	2026-06-30 19:24:29.929941		\N	[]
126	500	13667618419	20	2	2026-06-30 12:29:22.440017	\N	\N	1	2026-06-30 12:29:22.440017+08	2026-06-30 12:29:22.440017	\N	\N	[]
127	496	13667618419	20	2	2026-06-30 12:29:23.388248	\N	\N	1	2026-06-30 12:29:23.388248+08	2026-06-30 12:29:23.388248	\N	\N	[]
128	432	13667618419	20	2	2026-06-30 12:29:28.501642	\N	\N	1	2026-06-30 12:29:28.501642+08	2026-06-30 12:29:28.501642	\N	\N	[]
119	493	17726689234	20	2	2026-06-30 11:19:26.804	\N	\N	1	2026-06-30 11:19:26.804+08	2026-06-30 11:19:26.804	\N	\N	[]
129	424	13667618419	20	2	2026-06-30 12:29:33.041215	\N	\N	1	2026-06-30 12:29:33.041215+08	2026-06-30 12:29:33.041215	\N	\N	[]
103	\N	18996093393	82	2	2026-06-29 18:59:48.984255	2026-06-30 10:24:31.009584	admin	1	\N	2026-06-29 18:59:48.984255	\N	\N	[]
130	422	13667618419	20	2	2026-06-30 12:30:36.497195	\N	\N	1	2026-06-30 12:30:36.497195+08	2026-06-30 12:30:36.497195	\N	\N	[]
399	1533	15560048291	20	2	2026-07-02 16:12:52.95162	2026-07-02 16:25:32.57367	管理员	1	\N	2026-07-02 16:12:52.95162		\N	[]
143	555	17726689234	20	2	2026-06-30 18:13:57.300004	2026-06-30 18:18:49.841431	admin	1	\N	2026-06-30 18:13:57.300004	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N	[]
121	\N	13667618419	20	2	2026-06-30 11:30:24.574198	2026-06-30 11:31:07.901284	admin	1	\N	2026-06-30 11:30:24.574198		\N	[]
153	549	15656087879	20	0	2026-06-30 20:37:10.794774	\N	\N	1	\N	2026-06-30 20:37:10.794774		\N	[]
120	\N	13667618419	120	2	2026-06-30 11:30:09.856373	2026-06-30 11:37:05.425108	admin	1	\N	2026-06-30 11:30:09.856373		\N	[]
145	550	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:02.788767	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
140	\N	18637010208	20	0	2026-06-30 16:32:25.505544	\N	\N	1	\N	2026-06-30 16:32:25.505544		\N	[521]
141	\N	19137096192	20	0	2026-06-30 16:41:56.094547	\N	\N	1	\N	2026-06-30 16:41:56.094547		\N	[538]
134	530	17726689234	20	2	2026-06-30 14:06:06.176592	2026-06-30 14:27:49.528093	admin	1	\N	2026-06-30 14:06:06.176592		\N	[]
155	564	17726689234	20	0	2026-07-01 08:01:21.927045	\N	\N	1	\N	2026-07-01 08:01:21.927045		\N	[]
135	\N	18265820019	20	0	2026-06-30 15:09:15.541254	\N	\N	1	\N	2026-06-30 15:09:15.541254		\N	[501]
148	30	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:16.691669	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
137	\N	17726689234	20	2	2026-06-30 15:37:59.548873	2026-06-30 15:39:03.424493	admin_test	1	\N	2026-06-30 15:37:59.548873	\N	\N	[548]
149	29	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:19.706076	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
156	562	17726689234	20	0	2026-07-01 08:01:43.583329	\N	\N	1	\N	2026-07-01 08:01:43.583329		\N	[]
138	\N	19544562686	20	0	2026-06-30 16:11:35.598208	\N	\N	1	\N	2026-06-30 16:11:35.598208		\N	[539]
133	\N	17726689234	40	5	2026-06-30 13:50:05.009292	\N	\N	1	\N	2026-06-30 13:50:05.009292	oLhbm2CegcLUOudngMNwdzBhHA7U	系统修复：取消旧版无订单关联的提现记录	[]
139	\N	15275043796	20	0	2026-06-30 16:12:58.540861	\N	\N	1	\N	2026-06-30 16:12:58.540861		\N	[523]
144	551	17726689234	20	2	2026-06-30 18:13:57.300004	2026-06-30 18:18:40.862269	admin	1	\N	2026-06-30 18:13:57.300004	oWrA81xyJP1aI7beoqhd2rxBGPfw	\N	[]
146	34	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:23.258836	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
150	25	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:26.014054	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
147	33	13667618419	20	2	2026-06-30 18:19:19.890462	2026-06-30 18:20:30.369821	admin	1	\N	2026-06-30 18:19:19.890462		\N	[]
154	546	15324821187	20	0	2026-07-01 01:12:24.436217	\N	\N	1	\N	2026-07-01 01:12:24.436217		\N	[]
157	469	18996093393	20	2	2026-07-01 08:41:37.776265	2026-07-01 10:18:16.009243	管理员	1	\N	2026-07-01 08:41:37.776265		\N	[]
158	457	18996093393	20	2	2026-07-01 08:41:37.776265	2026-07-01 10:18:19.605697	管理员	1	\N	2026-07-01 08:41:37.776265		\N	[]
159	454	18996093393	10	2	2026-07-01 08:41:37.776265	2026-07-01 10:18:26.417015	管理员	1	\N	2026-07-01 08:41:37.776265		\N	[]
384	1501	17527227908	20	0	2026-07-02 14:34:30.552428	\N	\N	1	\N	2026-07-02 14:34:30.552428		\N	[]
389	1500	13323972142	20	0	2026-07-02 15:15:50.784552	\N	\N	1	\N	2026-07-02 15:15:50.784552		\N	[]
390	1479	15938352984	20	0	2026-07-02 15:26:01.33786	\N	\N	1	\N	2026-07-02 15:26:01.33786		\N	[]
395	1537	13667618419	20	0	2026-07-02 15:37:52.281762	\N	\N	1	\N	2026-07-02 15:37:52.281762	oLhbm2CegcLUOudngMNwdzBhHA7U	\N	[]
400	1460	18736838325	20	0	2026-07-02 16:13:03.357981	\N	\N	1	\N	2026-07-02 16:13:03.357981		\N	[]
401	1534	17530271182	20	0	2026-07-02 16:13:11.882261	\N	\N	1	\N	2026-07-02 16:13:11.882261		\N	[]
385	1496	17503709333	20	0	2026-07-02 14:37:01.947997	\N	\N	1	\N	2026-07-02 14:37:01.947997		\N	[]
167	505	15617060696	20	2	2026-07-01 15:13:56.793457	2026-07-02 09:44:33.115684	管理员	1	\N	2026-07-01 15:13:56.793457		\N	[]
290	605	13800000026	20	3	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:44:57	2026-07-01 15:31:57		\N	[]
291	606	13800000040	30	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:46:57	2026-07-01 15:31:57		\N	[]
292	607	13800000032	20	3	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:44:57	2026-07-01 15:31:57		\N	[]
293	608	13800000048	25	3	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:44:57	2026-07-01 15:31:57		\N	[]
294	609	13800000016	20	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:47:57	2026-07-01 15:31:57		\N	[]
295	610	13800000042	20	3	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:50:57	2026-07-01 15:31:57		\N	[]
296	615	13800000026	25	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:47:57	2026-07-01 15:31:57		\N	[]
297	616	13800000014	20	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:44:57	2026-07-01 15:31:57		\N	[]
298	617	13800000037	30	3	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:42:57	2026-07-01 15:31:57		\N	[]
161	593	15964428331	20	0	2026-07-01 12:44:29.079509	\N	\N	1	\N	2026-07-01 12:44:29.079509		\N	[]
299	618	13800000014	15	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:50:57	2026-07-01 15:31:57		\N	[]
300	619	13800000040	15	3	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:43:57	2026-07-01 15:31:57		\N	[]
301	620	13800000006	30	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:42:57	2026-07-01 15:31:57		\N	[]
302	625	13800000020	20	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:48:57	2026-07-01 15:31:57		\N	[]
303	626	13800000043	25	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:49:57	2026-07-01 15:31:57		\N	[]
304	627	13800000012	15	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:42:57	2026-07-01 15:31:57		\N	[]
165	589	19165928949	20	0	2026-07-01 14:57:00.880954	\N	\N	1	\N	2026-07-01 14:57:00.880954		\N	[]
305	628	13800000033	15	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:43:57	2026-07-01 15:31:57		\N	[]
306	629	13800000013	15	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:41:57	2026-07-01 15:31:57		\N	[]
166	567	19261605685	20	0	2026-07-01 15:06:15.860658	\N	\N	1	\N	2026-07-01 15:06:15.860658		\N	[]
307	630	13800000025	15	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:49:57	2026-07-01 15:31:57		\N	[]
308	635	13800000049	15	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:43:57	2026-07-01 15:31:57		\N	[]
309	636	13800000035	20	3	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:49:57	2026-07-01 15:31:57		\N	[]
310	637	13800000012	10	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:47:57	2026-07-01 15:31:57		\N	[]
311	638	13800000034	30	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:50:57	2026-07-01 15:31:57		\N	[]
312	639	13800000015	10	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:42:57	2026-07-01 15:31:57		\N	[]
313	640	13800000045	10	3	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:46:57	2026-07-01 15:31:57		\N	[]
168	604	13667618419	20	0	2026-07-01 15:23:50.483315	\N	\N	1	\N	2026-07-01 15:23:50.483315		\N	[]
314	645	13800000014	15	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:44:57	2026-07-01 15:31:57		\N	[]
164	591	15798651828	20	0	2026-07-01 13:39:38.166998	\N	\N	1	\N	2026-07-01 13:39:38.166998		\N	[]
315	646	13800000019	10	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:47:57	2026-07-01 15:31:57		\N	[]
316	647	13800000009	30	3	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:43:57	2026-07-01 15:31:57		\N	[]
317	648	13800000013	30	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:50:57	2026-07-01 15:31:57		\N	[]
318	649	13800000010	30	2	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:50:57	2026-07-01 15:31:57		\N	[]
319	650	13800000033	25	3	2026-07-01 15:31:57.701189	2026-07-01 15:31:57.701189	test_sys	1	2026-07-01 15:44:57	2026-07-01 15:31:57		\N	[]
132	35	13667618419	20	4	2026-06-30 12:30:37.467936	\N	\N	1	2026-06-30 12:30:37.467936+08	2026-06-30 12:30:37.467936	\N	记录不存在	[]
381	1474	15836493002	20	0	2026-07-02 11:07:26.410268	\N	\N	1	\N	2026-07-02 11:07:26.410268	oLhbm2DWu-DCipOTm1wg6cVOr3oo	\N	[]
391	1529	19639308701	20	2	2026-07-02 15:27:05.184566	2026-07-02 15:31:25.207137	管理员	1	\N	2026-07-02 15:27:05.184566		\N	[]
396	1514	13037508763	20	0	2026-07-02 15:42:40.041611	\N	\N	1	\N	2026-07-02 15:42:40.041611		\N	[]
163	570	17861769100	20	2	2026-07-01 13:31:58.869438	2026-07-01 18:31:37.526495	管理员	1	\N	2026-07-01 13:31:58.869438		\N	[]
160	590	19025302365	20	2	2026-07-01 12:39:53.000132	2026-07-01 17:33:55.992475	管理员	1	\N	2026-07-01 12:39:53.000132		\N	[]
162	592	15054012361	20	2	2026-07-01 13:13:56.747526	2026-07-02 18:57:03.559505	管理员	1	\N	2026-07-01 13:13:56.747526		\N	[]
131	422	13667618419	20	4	2026-06-30 12:30:36.685084	\N	\N	1	2026-06-30 12:30:36.685084+08	2026-06-30 12:30:36.685084	\N	订单已全额退款	[]
320	705	13800000025	10	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
321	706	13800000010	10	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
322	707	13800000014	20	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
323	708	13800000048	20	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
324	709	13800000009	25	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
325	710	13800000024	25	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
326	715	13800000014	25	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
327	716	13800000013	15	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
328	717	13800000050	15	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
329	718	13800000026	20	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
330	719	13800000035	20	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
331	720	13800000016	25	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
332	725	13800000037	10	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
333	726	13800000016	20	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
334	727	13800000046	10	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
335	728	13800000018	25	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
336	729	13800000023	30	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
337	730	13800000028	20	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
338	735	13800000017	10	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
339	736	13800000047	25	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
340	737	13800000017	10	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
341	738	13800000049	30	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
342	739	13800000024	20	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
343	740	13800000005	25	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
344	745	13800000044	10	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
345	746	13800000015	30	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
346	747	13800000045	15	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
347	748	13800000023	10	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
348	749	13800000038	20	3	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
349	750	13800000004	15	2	2026-07-01 15:31:57.758373	2026-07-01 15:31:57.758373	sys_auto	1	2026-07-01 02:00:00	2026-06-28 15:31:57		\N	[]
378	579	15136012752	20	0	2026-07-01 16:43:13.288481	\N	\N	1	\N	2026-07-01 16:43:13.288481		\N	[]
382	1477	18237036782	20	0	2026-07-02 11:16:54.255628	\N	\N	1	\N	2026-07-02 11:16:54.255628	oLhbm2CYT0IHqGLW5iwlgZgJ06X0	\N	[]
386	1495	17554760510	20	0	2026-07-02 14:38:42.820255	\N	\N	1	\N	2026-07-02 14:38:42.820255		\N	[]
392	1530	18738086168	20	0	2026-07-02 15:30:47.957158	\N	\N	1	\N	2026-07-02 15:30:47.957158	oLhbm2LqPg4KGkDFLUvFvxtC3MVA	\N	[]
397	1506	19337089231	20	0	2026-07-02 15:57:10.217374	\N	\N	1	\N	2026-07-02 15:57:10.217374		\N	[]
379	1449	15751766581	20	2	2026-07-02 09:23:28.564639	2026-07-02 13:17:39.11094	管理员	1	\N	2026-07-02 09:23:28.564639	oLhbm2KE1cRsrIz2sB9QfvLP7lU0	\N	[]
383	1482	13856712830	20	0	2026-07-02 14:21:43.059111	\N	\N	1	\N	2026-07-02 14:21:43.059111		\N	[]
387	1502	17698950605	20	0	2026-07-02 15:00:18.771648	\N	\N	1	\N	2026-07-02 15:00:18.771648		\N	[]
388	1509	19639308701	20	2	2026-07-02 15:03:18.509501	2026-07-02 15:31:28.65186	管理员	1	\N	2026-07-02 15:03:18.509501	oLhbm2JC1I3dU6SXjHSsosrzPF5g	\N	[]
393	1507	18039160828	20	0	2026-07-02 15:31:32.895388	\N	\N	1	\N	2026-07-02 15:31:32.895388	oLhbm2BV1esdA23OBjg7FWw-awxE	\N	[]
394	1510	18272662178	20	0	2026-07-02 15:32:38.819197	\N	\N	1	\N	2026-07-02 15:32:38.819197		\N	[]
398	1527	15919267157	20	0	2026-07-02 15:59:42.037682	\N	\N	1	\N	2026-07-02 15:59:42.037682		\N	[]
229	598	18691666092	20	0	2026-07-01 15:28:18.047236	\N	\N	1	\N	2026-07-01 15:28:18.047236		\N	[]
\.


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 1, true);


--
-- Name: after_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.after_sales_id_seq', 1, true);


--
-- Name: agents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.agents_id_seq', 3, true);


--
-- Name: alarms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.alarms_id_seq', 1, true);


--
-- Name: apk_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.apk_version_id_seq', 46, true);


--
-- Name: blacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.blacklist_id_seq', 1, true);


--
-- Name: cabinet_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cabinet_groups_id_seq', 1, true);


--
-- Name: cabinet_slots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cabinet_slots_id_seq', 1614, true);


--
-- Name: cabinets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cabinets_id_seq', 39, true);


--
-- Name: cached_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.cached_orders_id_seq', 1, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.companies_id_seq', 2, true);


--
-- Name: complaints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.complaints_id_seq', 13, true);


--
-- Name: device_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.device_alerts_id_seq', 682, true);


--
-- Name: device_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.device_logs_id_seq', 856, true);


--
-- Name: device_update_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.device_update_logs_id_seq', 27, true);


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.devices_id_seq', 1, true);


--
-- Name: door_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.door_records_id_seq', 771, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.employees_id_seq', 5, true);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.locations_id_seq', 11, true);


--
-- Name: mainboards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.mainboards_id_seq', 40, true);


--
-- Name: merchants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.merchants_id_seq', 8, true);


--
-- Name: offline_retrieve_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.offline_retrieve_records_id_seq', 1, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.orders_id_seq', 1563, true);


--
-- Name: payment_channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.payment_channels_id_seq', 6, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.payments_id_seq', 1130, true);


--
-- Name: pending_lock_cmds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.pending_lock_cmds_id_seq', 1493, true);


--
-- Name: phone_openids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.phone_openids_id_seq', 429, true);


--
-- Name: remote_open_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.remote_open_logs_id_seq', 344, true);


--
-- Name: sms_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.sms_codes_id_seq', 1, true);


--
-- Name: storage_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.storage_records_id_seq', 491, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 11235, true);


--
-- Name: user_balance_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.user_balance_details_id_seq', 844, true);


--
-- Name: user_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.user_balances_id_seq', 246, true);


--
-- Name: user_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.user_tokens_id_seq', 16, true);


--
-- Name: withdrawal_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: locker_admin
--

SELECT pg_catalog.setval('public.withdrawal_records_id_seq', 401, true);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_username_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_username_key UNIQUE (username);


--
-- Name: after_sales after_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.after_sales
    ADD CONSTRAINT after_sales_pkey PRIMARY KEY (id);


--
-- Name: after_sales after_sales_ticket_no_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.after_sales
    ADD CONSTRAINT after_sales_ticket_no_key UNIQUE (ticket_no);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: alarms alarms_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.alarms
    ADD CONSTRAINT alarms_pkey PRIMARY KEY (id);


--
-- Name: apk_version apk_version_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.apk_version
    ADD CONSTRAINT apk_version_pkey PRIMARY KEY (id);


--
-- Name: blacklist blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.blacklist
    ADD CONSTRAINT blacklist_pkey PRIMARY KEY (id);


--
-- Name: cabinet_groups cabinet_groups_group_code_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_groups
    ADD CONSTRAINT cabinet_groups_group_code_key UNIQUE (group_code);


--
-- Name: cabinet_groups cabinet_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_groups
    ADD CONSTRAINT cabinet_groups_pkey PRIMARY KEY (id);


--
-- Name: cabinet_slots cabinet_slots_cabinet_id_slot_number_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_slots
    ADD CONSTRAINT cabinet_slots_cabinet_id_slot_number_key UNIQUE (cabinet_id, slot_number);


--
-- Name: cabinet_slots cabinet_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinet_slots
    ADD CONSTRAINT cabinet_slots_pkey PRIMARY KEY (id);


--
-- Name: cabinets cabinets_cabinet_code_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinets
    ADD CONSTRAINT cabinets_cabinet_code_key UNIQUE (cabinet_code);


--
-- Name: cabinets cabinets_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cabinets
    ADD CONSTRAINT cabinets_pkey PRIMARY KEY (id);


--
-- Name: cached_orders cached_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.cached_orders
    ADD CONSTRAINT cached_orders_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: complaints complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.complaints
    ADD CONSTRAINT complaints_pkey PRIMARY KEY (id);


--
-- Name: device_alerts device_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_alerts
    ADD CONSTRAINT device_alerts_pkey PRIMARY KEY (id);


--
-- Name: device_logs device_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_logs
    ADD CONSTRAINT device_logs_pkey PRIMARY KEY (id);


--
-- Name: device_update_logs device_update_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.device_update_logs
    ADD CONSTRAINT device_update_logs_pkey PRIMARY KEY (id);


--
-- Name: devices devices_device_id_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_device_id_key UNIQUE (device_id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: door_query_cache door_query_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.door_query_cache
    ADD CONSTRAINT door_query_cache_pkey PRIMARY KEY (request_id);


--
-- Name: door_records door_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.door_records
    ADD CONSTRAINT door_records_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: mainboards mainboards_cabinet_id_board_index_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.mainboards
    ADD CONSTRAINT mainboards_cabinet_id_board_index_key UNIQUE (cabinet_id, board_index);


--
-- Name: mainboards mainboards_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.mainboards
    ADD CONSTRAINT mainboards_pkey PRIMARY KEY (id);


--
-- Name: merchants merchants_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT merchants_pkey PRIMARY KEY (id);


--
-- Name: offline_retrieve_records offline_retrieve_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.offline_retrieve_records
    ADD CONSTRAINT offline_retrieve_records_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_no_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_no_key UNIQUE (order_no);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payment_channels payment_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payment_channels
    ADD CONSTRAINT payment_channels_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: pending_lock_cmds pending_lock_cmds_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.pending_lock_cmds
    ADD CONSTRAINT pending_lock_cmds_pkey PRIMARY KEY (id);


--
-- Name: phone_openids phone_openids_phone_openid_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.phone_openids
    ADD CONSTRAINT phone_openids_phone_openid_key UNIQUE (phone, openid);


--
-- Name: phone_openids phone_openids_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.phone_openids
    ADD CONSTRAINT phone_openids_pkey PRIMARY KEY (id);


--
-- Name: remote_open_logs remote_open_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.remote_open_logs
    ADD CONSTRAINT remote_open_logs_pkey PRIMARY KEY (id);


--
-- Name: sms_codes sms_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.sms_codes
    ADD CONSTRAINT sms_codes_pkey PRIMARY KEY (id);


--
-- Name: storage_records storage_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.storage_records
    ADD CONSTRAINT storage_records_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_key UNIQUE (setting_key);


--
-- Name: user_balance_details user_balance_details_order_id_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balance_details
    ADD CONSTRAINT user_balance_details_order_id_key UNIQUE (order_id);


--
-- Name: user_balance_details user_balance_details_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balance_details
    ADD CONSTRAINT user_balance_details_pkey PRIMARY KEY (id);


--
-- Name: user_balances user_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_balances
    ADD CONSTRAINT user_balances_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (openid);


--
-- Name: user_tokens user_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT user_tokens_pkey PRIMARY KEY (id);


--
-- Name: user_tokens user_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT user_tokens_token_key UNIQUE (token);


--
-- Name: withdrawal_records withdrawal_records_pkey; Type: CONSTRAINT; Schema: public; Owner: locker_admin
--

ALTER TABLE ONLY public.withdrawal_records
    ADD CONSTRAINT withdrawal_records_pkey PRIMARY KEY (id);


--
-- Name: idx_balance_details_order; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_balance_details_order ON public.user_balance_details USING btree (order_id);


--
-- Name: idx_balance_details_phone_status; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_balance_details_phone_status ON public.user_balance_details USING btree (user_phone, status);


--
-- Name: idx_cabinets_heartbeat; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_cabinets_heartbeat ON public.cabinets USING btree (last_heartbeat);


--
-- Name: idx_cabinets_location; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_cabinets_location ON public.cabinets USING btree (location_id);


--
-- Name: idx_cabinets_mainboard; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_cabinets_mainboard ON public.cabinets USING btree (mainboard_device_id);


--
-- Name: idx_complaints_order_id; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_complaints_order_id ON public.complaints USING btree (order_id);


--
-- Name: idx_orders_cabinet; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_orders_cabinet ON public.orders USING btree (cabinet_id);


--
-- Name: idx_orders_phone; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_orders_phone ON public.orders USING btree (user_phone);


--
-- Name: idx_orders_slot; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_orders_slot ON public.orders USING btree (slot_id);


--
-- Name: idx_phone_openids_phone; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE UNIQUE INDEX idx_phone_openids_phone ON public.phone_openids USING btree (phone);


--
-- Name: idx_phone_openids_unionid; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_phone_openids_unionid ON public.phone_openids USING btree (unionid);


--
-- Name: idx_slots_cabinet; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_slots_cabinet ON public.cabinet_slots USING btree (cabinet_id);


--
-- Name: idx_slots_status; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_slots_status ON public.cabinet_slots USING btree (status);


--
-- Name: idx_user_balances_unionid; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_user_balances_unionid ON public.user_balances USING btree (unionid);


--
-- Name: idx_user_tokens_token; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_user_tokens_token ON public.user_tokens USING btree (token);


--
-- Name: idx_user_tokens_type_id; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE INDEX idx_user_tokens_type_id ON public.user_tokens USING btree (user_type, user_id);


--
-- Name: user_balances_phone_openid_uk; Type: INDEX; Schema: public; Owner: locker_admin
--

CREATE UNIQUE INDEX user_balances_phone_openid_uk ON public.user_balances USING btree (phone, openid);


--
-- PostgreSQL database dump complete
--

\unrestrict rIE7xzRrbHDMa7jpj7BMggWRqQByuA1ky3houiM1t5qJ88cnxiIcOfS7yuZvcfw

