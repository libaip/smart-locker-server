/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.XcbConstantValue
 *  javax.servlet.http.HttpServletResponse
 *  org.apache.poi.ss.usermodel.Cell
 *  org.apache.poi.ss.usermodel.CellStyle
 *  org.apache.poi.ss.usermodel.DataFormat
 *  org.apache.poi.ss.usermodel.Font
 *  org.apache.poi.ss.usermodel.RichTextString
 *  org.apache.poi.ss.usermodel.Row
 *  org.apache.poi.ss.usermodel.Sheet
 *  org.apache.poi.ss.usermodel.Workbook
 *  org.apache.poi.xssf.streaming.SXSSFWorkbook
 *  org.apache.poi.xssf.usermodel.XSSFCellStyle
 *  org.apache.poi.xssf.usermodel.XSSFColor
 *  org.apache.poi.xssf.usermodel.XSSFRichTextString
 */
package com.jcg.agent.common;

import com.jcg.common.model.XcbConstantValue;
import java.awt.Color;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;

public class ExportToExcel {
    public void exportExcel(String filedisplay, String title, String titleCode, String[] headers, String[] fieldNams, List<Object> dataList, HttpServletResponse response, Map<String, String> patternMp, ArrayList<?> specialHandleList) throws Exception {
        BufferedOutputStream out = null;
        SXSSFWorkbook workbook = new SXSSFWorkbook();
        Sheet sheet = workbook.createSheet(title);
        sheet.setDefaultColumnWidth(15);
        XSSFCellStyle style = this.getTitleStyle((Workbook)workbook);
        XSSFCellStyle style2 = this.getContentStyle((Workbook)workbook);
        XSSFCellStyle style3 = this.getTotalContentStyle((Workbook)workbook);
        Row row = sheet.createRow(0);
        for (int i = 0; i < headers.length; i = (int)((short)(i + 1))) {
            Cell cell = row.createCell(i);
            cell.setCellStyle((CellStyle)style);
            XSSFRichTextString text = new XSSFRichTextString(headers[i]);
            cell.setCellValue((RichTextString)text);
        }
        BigDecimal rechargeMoney = new BigDecimal(0);
        BigDecimal awardMoney = new BigDecimal(0);
        Iterator<Object> iterator = dataList.iterator();
        int index = 0;
        while (iterator.hasNext()) {
            row = sheet.createRow(++index);
            Object obj = iterator.next();
            for (int i = 0; i < fieldNams.length; i = (int)((short)(i + 1))) {
                Cell cell = row.createCell(i);
                cell.setCellStyle((CellStyle)style2);
                String fieldName = null;
                String getMethodName = null;
                Object methodReturnValue = null;
                fieldName = fieldNams[i];
                if (!fieldName.equalsIgnoreCase("rowIndex")) {
                    getMethodName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
                    Class<?> refClass = obj.getClass();
                    Method getMethod = refClass.getMethod(getMethodName, new Class[0]);
                    methodReturnValue = getMethod.invoke(obj, new Object[0]);
                } else {
                    methodReturnValue = index;
                }
                if (methodReturnValue == null) {
                    methodReturnValue = "";
                }
                if (XcbConstantValue.EXPORT_ZJLS.equals(titleCode) && specialHandleList != null && specialHandleList.contains(fieldName) && methodReturnValue instanceof String) {
                    String[] methodReturnValueArr = ((String)methodReturnValue).split(":");
                    String orderIdTypePrefix = methodReturnValueArr[0];
                    String cashflowItemCode = methodReturnValueArr[1];
                    String cashflowItemValue = methodReturnValueArr[2];
                    if (XcbConstantValue.CASH_STREAM_CBJCZ.equals(cashflowItemCode)) {
                        if ("10".equals(orderIdTypePrefix)) {
                            methodReturnValue = "\u50a8\u5907\u91d1\u5145\u503c-\u6765\u81ea\u8ba2\u5355\u6536\u5165";
                        } else if ("23".equals(orderIdTypePrefix)) {
                            methodReturnValue = "\u50a8\u5907\u91d1\u5145\u503c-\u6765\u81ea\u8d26\u6237\u5145\u503c";
                        }
                    } else {
                        methodReturnValue = cashflowItemValue;
                    }
                }
                String pattern = this.getDatePattern(fieldName, patternMp);
                String goldControlFlg = this.getGoldFlgPattern("goldControl", patternMp);
                this.cellFieldSet((Workbook)workbook, cell, methodReturnValue, pattern, fieldName, goldControlFlg);
            }
        }
        for (int k = 0; k < headers.length; k = (int)((short)(k + 1))) {
            sheet.autoSizeColumn(k);
            sheet.setColumnWidth(k, 5120);
        }
        try {
            this.settingResponse(response, filedisplay);
            out = new BufferedOutputStream((OutputStream)response.getOutputStream());
            workbook.write((OutputStream)out);
            ((OutputStream)out).flush();
            if (out != null) {
                this.closeOutputStream(out);
            }
        }
        catch (Exception e) {
            try {
                throw e;
            }
            catch (Throwable throwable) {
                if (out != null) {
                    this.closeOutputStream(out);
                }
                throw throwable;
            }
        }
    }

    private String getDatePattern(String fieldName, Map<String, String> patternMp) {
        String pattern = "yyyy-MM-dd";
        if (patternMp != null && !patternMp.equals("")) {
            Set<String> set = patternMp.keySet();
            for (String strKey : set) {
                if (!fieldName.equalsIgnoreCase(strKey)) continue;
                pattern = patternMp.get(strKey);
            }
        }
        return pattern;
    }

    private String getGoldFlgPattern(String keyStr, Map<String, String> patternMp) {
        String obj;
        if (patternMp != null && !patternMp.equals("") && (obj = patternMp.get(keyStr)) != null) {
            return obj.toString();
        }
        return "";
    }

    private void cellFieldSet(Workbook workbook, Cell cell, Object methodReturnValue, String pattern, String fieldName, String goldControlFlg) {
        String textValue = null;
        if (methodReturnValue instanceof Integer) {
            int intValue = (Integer)methodReturnValue;
            cell.setCellValue((double)intValue);
        } else if (methodReturnValue instanceof Float) {
            float fValue = ((Float)methodReturnValue).floatValue();
            textValue = String.valueOf(fValue);
            cell.setCellValue(textValue);
        } else if (methodReturnValue instanceof Double) {
            double dValue = (Double)methodReturnValue;
            DataFormat format = workbook.createDataFormat();
            XSSFCellStyle cellStyle = this.getContentStyle(workbook);
            String strVal = BigDecimal.valueOf(dValue).stripTrailingZeros().toPlainString();
            int inx = strVal.indexOf(".");
            if (inx == -1) {
                cellStyle.setDataFormat(format.getFormat("#,##0"));
            } else {
                String suffix = strVal.substring(inx + 1);
                if (suffix.length() == 1 && suffix.equals("0")) {
                    cellStyle.setDataFormat(format.getFormat("#,##0"));
                } else {
                    cellStyle.setDataFormat(format.getFormat("#,##0.00"));
                }
            }
            cell.setCellStyle((CellStyle)cellStyle);
            if (goldControlFlg == null || goldControlFlg.equals("")) {
                cell.setCellValue(dValue);
                cell.setCellType(0);
            } else if (goldControlFlg.equalsIgnoreCase("accBalance")) {
                if (dValue != 0.0 || fieldName.equalsIgnoreCase("afterBalance")) {
                    cell.setCellValue(dValue);
                    cell.setCellType(0);
                }
            } else {
                cell.setCellValue(dValue);
                cell.setCellType(0);
            }
        } else if (methodReturnValue instanceof Long) {
            long longValue = (Long)methodReturnValue;
            cell.setCellValue((double)longValue);
        } else if (methodReturnValue instanceof Date) {
            Date date = (Date)methodReturnValue;
            SimpleDateFormat sdf = new SimpleDateFormat(pattern);
            textValue = sdf.format(date);
        } else {
            textValue = methodReturnValue.toString();
        }
        if (textValue != null) {
            Pattern p = Pattern.compile("^//d+(//.//d+)?$");
            Matcher matcher = p.matcher(textValue);
            if (matcher.matches()) {
                cell.setCellValue(Double.parseDouble(textValue));
            } else {
                XSSFRichTextString richString = new XSSFRichTextString(textValue);
                cell.setCellValue((RichTextString)richString);
            }
        }
    }

    private XSSFCellStyle getContentStyle(Workbook workbook) {
        XSSFCellStyle style2 = (XSSFCellStyle)workbook.createCellStyle();
        style2.setFillForegroundColor(new XSSFColor(Color.WHITE));
        style2.setFillPattern((short)1);
        style2.setBorderBottom((short)1);
        style2.setBorderLeft((short)1);
        style2.setBorderRight((short)1);
        style2.setBorderTop((short)1);
        style2.setAlignment((short)2);
        style2.setVerticalAlignment((short)1);
        Font font2 = workbook.createFont();
        font2.setColor(new XSSFColor(Color.BLACK).getIndexed());
        font2.setBoldweight((short)400);
        style2.setFont(font2);
        return style2;
    }

    private XSSFCellStyle getTotalContentStyle(Workbook workbook) {
        XSSFCellStyle style3 = (XSSFCellStyle)workbook.createCellStyle();
        style3.setFillForegroundColor(new XSSFColor(Color.WHITE));
        style3.setFillPattern((short)1);
        style3.setBorderBottom((short)1);
        style3.setBorderLeft((short)1);
        style3.setBorderRight((short)1);
        style3.setBorderTop((short)1);
        style3.setAlignment((short)2);
        style3.setVerticalAlignment((short)1);
        style3.setAlignment((short)1);
        Font font3 = workbook.createFont();
        font3.setColor(new XSSFColor(Color.BLACK).getIndexed());
        font3.setBoldweight((short)700);
        font3.setFontHeightInPoints((short)18);
        style3.setFont(font3);
        return style3;
    }

    private XSSFCellStyle getTitleStyle(Workbook workbook) {
        XSSFCellStyle style = (XSSFCellStyle)workbook.createCellStyle();
        style.setFillForegroundColor(new XSSFColor(Color.lightGray));
        style.setFillPattern((short)1);
        style.setBorderBottom((short)1);
        style.setBorderLeft((short)1);
        style.setBorderRight((short)1);
        style.setBorderTop((short)1);
        style.setAlignment((short)2);
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short)12);
        font.setBoldweight((short)700);
        style.setFont(font);
        return style;
    }

    public void settingResponse(HttpServletResponse response, String filedisplay) throws UnsupportedEncodingException {
        response.reset();
        response.addHeader("pragma", "NO-cache");
        response.addHeader("Cache-Control", "no-cache");
        response.addDateHeader("Expries", 0L);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/x-msdownload");
        filedisplay = URLEncoder.encode(filedisplay, "UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename*=utf-8'zh_cn'" + filedisplay);
    }

    public void closeOutputStream(OutputStream out) {
        try {
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Object getMethodReturnValue(Object obj, String fieldName) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
        String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
        Class<?> refClass = obj.getClass();
        Method getMethod = refClass.getMethod(getMethodName, new Class[0]);
        return getMethod.invoke(obj, new Object[0]);
    }
}

