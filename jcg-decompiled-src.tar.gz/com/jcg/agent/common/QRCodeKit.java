/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.zxing.BarcodeFormat
 *  com.google.zxing.EncodeHintType
 *  com.google.zxing.MultiFormatWriter
 *  com.google.zxing.WriterException
 *  com.google.zxing.common.BitMatrix
 *  com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
 */
package com.jcg.agent.common;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import javax.imageio.ImageIO;

public class QRCodeKit {
    private static final int IMAGE_WIDTH = 100;
    private static final int IMAGE_HEIGHT = 100;
    private static final int IMAGE_HALF_WIDTH = 50;
    private static final int FRAME_WIDTH = 2;
    private static MultiFormatWriter mutiWriter = new MultiFormatWriter();

    public static void encode(String content, int width, int height, String srcImagePath, String destImagePath) {
        try {
            ImageIO.write((RenderedImage)QRCodeKit.genBarcode(content, width, height, srcImagePath), "jpg", new File(destImagePath));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (WriterException e) {
            e.printStackTrace();
        }
    }

    private static BufferedImage genBarcode(String content, int width, int height, String srcImagePath) throws WriterException, IOException {
        BufferedImage scaleImage = QRCodeKit.scale(srcImagePath, 100, 100, true);
        int[][] srcPixels = new int[100][100];
        for (int i = 0; i < scaleImage.getWidth(); ++i) {
            for (int j = 0; j < scaleImage.getHeight(); ++j) {
                srcPixels[i][j] = scaleImage.getRGB(i, j);
            }
        }
        HashMap<EncodeHintType, String> hint = new HashMap<EncodeHintType, String>();
        hint.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hint.put(EncodeHintType.ERROR_CORRECTION, (String)ErrorCorrectionLevel.H);
        BitMatrix matrix = mutiWriter.encode(content, BarcodeFormat.QR_CODE, width, height, hint);
        int halfW = matrix.getWidth() / 2;
        int halfH = matrix.getHeight() / 2;
        int[] pixels = new int[width * height];
        for (int y = 0; y < matrix.getHeight(); ++y) {
            for (int x = 0; x < matrix.getWidth(); ++x) {
                if (x > 0 && x < 170 && y > 0 && y < 170) {
                    Color color = new Color(231, 144, 56);
                    int colorInt = color.getRGB();
                    pixels[y * width + x] = matrix.get(x, y) ? colorInt : 0xFFFFFF;
                    continue;
                }
                if (x > halfW - 50 && x < halfW + 50 && y > halfH - 50 && y < halfH + 50) {
                    pixels[y * width + x] = srcPixels[x - halfW + 50][y - halfH + 50];
                    continue;
                }
                if (x > halfW - 50 - 2 && x < halfW - 50 + 2 && y > halfH - 50 - 2 && y < halfH + 50 + 2 || x > halfW + 50 - 2 && x < halfW + 50 + 2 && y > halfW - 50 - 2 && y < halfH + 50 + 2 || x > halfW - 50 - 2 && x < halfW + 50 + 2 && y > halfH - 50 - 2 && y < halfH - 50 + 2 || x > halfW - 50 - 2 && x < halfW + 50 + 2 && y > halfH + 50 - 2 && y < halfH + 50 + 2) {
                    pixels[y * width + x] = 0xFFFFFFF;
                    continue;
                }
                int num1 = (int)(50.0 - 37.0 / (double)matrix.getHeight() * (double)(y + 1));
                int num2 = (int)(165.0 - 93.0 / (double)matrix.getHeight() * (double)(y + 1));
                int num3 = (int)(162.0 - 55.0 / (double)matrix.getHeight() * (double)(y + 1));
                Color color = new Color(num1, num2, num3);
                int colorInt = color.getRGB();
                pixels[y * width + x] = matrix.get(x, y) ? colorInt : 0xFFFFFF;
            }
        }
        BufferedImage image = new BufferedImage(width, height, 1);
        image.getRaster().setDataElements(0, 0, width, height, pixels);
        return image;
    }

    private static BufferedImage scale(String srcImageFile, int height, int width, boolean hasFiller) throws IOException {
        double ratio = 0.0;
        File file = new File(srcImageFile);
        BufferedImage srcImage = ImageIO.read(file);
        Image destImage = srcImage.getScaledInstance(width, height, 4);
        if (srcImage.getHeight() > height || srcImage.getWidth() > width) {
            ratio = srcImage.getHeight() > srcImage.getWidth() ? new Integer(height).doubleValue() / (double)srcImage.getHeight() : new Integer(width).doubleValue() / (double)srcImage.getWidth();
            AffineTransformOp op = new AffineTransformOp(AffineTransform.getScaleInstance(ratio, ratio), null);
            destImage = op.filter(srcImage, null);
        }
        if (hasFiller) {
            BufferedImage image = new BufferedImage(width, height, 1);
            Graphics2D graphic = image.createGraphics();
            graphic.setColor(Color.white);
            graphic.fillRect(0, 0, width, height);
            if (width == destImage.getWidth(null)) {
                graphic.drawImage(destImage, 0, (height - destImage.getHeight(null)) / 2, destImage.getWidth(null), destImage.getHeight(null), Color.white, null);
            } else {
                graphic.drawImage(destImage, (width - destImage.getWidth(null)) / 2, 0, destImage.getWidth(null), destImage.getHeight(null), Color.white, null);
            }
            graphic.dispose();
            destImage = image;
        }
        return (BufferedImage)destImage;
    }

    public static void main(String[] args) throws UnsupportedEncodingException {
        String filePath = "E:/project/projSpace/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/xcbweb-agent/resources/img/netpic/agent/1/netpoint_1/device_1/";
        File file = new File(filePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        QRCodeKit.encode("https://liuyueyi.github.io/hexblog/", 432, 432, "E:\\MY\\proj\\ams\\src\\images\\logo-min.jpg", filePath + "ewm.jpg");
    }
}

