/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cn.hutool.core.util.StrUtil
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_agent_way
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.authentication.AuthenticationManager
 *  org.springframework.security.authentication.UsernamePasswordAuthenticationToken
 *  org.springframework.security.core.Authentication
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.security.core.userdetails.UserDetails
 *  org.springframework.security.core.userdetails.UserDetailsService
 *  org.springframework.security.crypto.password.StandardPasswordEncoder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.jcg.agent.common.BaseController;
import com.jcg.agent.common.PromptProperties;
import com.jcg.agent.common.RedisUtil;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_agent_way;
import com.jcg.agent.security.JwtTokenUtil;
import com.jcg.agent.service.AgentServiceImpl;
import com.jcg.agent.service.WebServiceImpl;
import com.jcg.agent.vo.LoginUser;
import com.jcg.agent.zf.wx.WXzfCommon;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/agent"})
public class AgentController
extends BaseController {
    @Autowired
    private AgentServiceImpl agentService;
    @Autowired
    private StandardPasswordEncoder standardPasswordEncoder;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    @Autowired
    private WXzfCommon wxzfCommon;
    @Autowired
    private WebServiceImpl webService;
    @Autowired
    private RedisUtil redis;

    @RequestMapping(value={"/createShop"})
    @ResponseBody
    public Map<String, Object> createShop(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.agentService.createShop(identifier, agent);
        int result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            Tb_agent_way agentWay = new Tb_agent_way();
            agentWay.setSr_user_name(agent.getSr_user_name());
            agentWay.setSr_old_user_name(agent.getSr_user_name());
            agentWay.setSr_way(XcbConstantValue.LOGIN_WAY);
            this.webService.createAgentWay(identifier, agentWay);
        }
        return ret;
    }

    @RequestMapping(value={"/createRole"})
    @ResponseBody
    public Map<String, Object> createRole(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.agentService.createRole(identifier, agent);
        int result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            Tb_agent_way agentWay = new Tb_agent_way();
            agentWay.setSr_user_name(agent.getSr_user_name());
            agentWay.setSr_old_user_name(agent.getSr_user_name());
            agentWay.setSr_way(XcbConstantValue.LOGIN_WAY);
            this.webService.createAgentWay(identifier, agentWay);
        }
        return ret;
    }

    @RequestMapping(value={"/findAgentByParam"})
    @ResponseBody
    public Map<String, Object> findAgentByParam(HttpServletRequest request, Tb_agent agent, Page page) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.findAgentByParam(identifier, agent, page);
        return result_map;
    }

    @RequestMapping(value={"/deleteAgentById"})
    @ResponseBody
    public Map<String, Object> deleteAgentById(HttpServletRequest request, String sd_agent_id) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.deleteAgentById(identifier, sd_agent_id);
        return result_map;
    }

    @RequestMapping(value={"/findAllUserByAgentId"})
    @ResponseBody
    public Map<String, Object> findAllUserByAgentId(HttpServletRequest request, Tb_agent agent, Page page) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.findAllUserByAgentId(identifier, agent, page);
        return result_map;
    }

    @RequestMapping(value={"/updateAgentById"})
    @ResponseBody
    public Map<String, Object> updateAgentById(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_user_name());
        Map<String, Object> result_map = this.agentService.updateAgentById(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/updateAgentStatusById"})
    @ResponseBody
    public Map<String, Object> updateAgentStatusById(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_user_name());
        Map<String, Object> result_map = this.agentService.updateAgentStatusById(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/updateAgentSettingById"})
    @ResponseBody
    public Map<String, Object> updateAgentSettingById(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_user_name());
        Map<String, Object> result_map = this.agentService.updateAgentSettingById(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/resetAgentPasswordById"})
    @ResponseBody
    public Map<String, Object> resetAgentPasswordById(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_user_name());
        Map<String, Object> result_map = this.agentService.resetAgentPasswordById(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/updatePassword"})
    @ResponseBody
    public Map<String, Object> updatePassword(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_user_name());
        Map<String, Object> result_map = this.agentService.updatePassword(identifier, agent);
        int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            HashMap<String, Object> dataMap = new HashMap<String, Object>();
            HashMap<String, Object> userInfodataMap = new HashMap<String, Object>();
            agent = (Tb_agent)result_map.get(XcbConstantValue.DATA);
            LoginUser loginUser = new LoginUser();
            loginUser.setUsername(agent.getSr_user_name());
            loginUser.setPassword(agent.getSr_password_mw());
            Authentication authentication = this.authenticationManager.authenticate((Authentication)new UsernamePasswordAuthenticationToken((Object)loginUser.getUsername(), (Object)loginUser.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            agent = (Tb_agent)this.userDetailsService.loadUserByUsername(loginUser.getUsername());
            Collection authList = agent.getAuthorities();
            String token = this.jwtTokenUtil.generateToken((UserDetails)agent, authList);
            dataMap.put("token", token);
            userInfodataMap.put("name", agent.getSr_agent_name());
            userInfodataMap.put("avatar", XcbConstantValue.AGENT_AVATAR_DEFAULT);
            userInfodataMap.put("access", new String[]{"admin"});
            userInfodataMap.put("userid", agent.getSd_agent_id());
            userInfodataMap.put("companyid", agent.getSw_company_id());
            dataMap.put("info", userInfodataMap);
            dataMap.put("sex", agent.getSr_sex());
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            result_map.put(XcbConstantValue.DATA, dataMap);
        }
        return result_map;
    }

    @RequestMapping(value={"/validateAgentOldPasswd"})
    @ResponseBody
    public Map<String, Object> validateAgentOldPasswd(HttpServletRequest request, String sd_agent_id, String oldPasswd) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        HashMap<String, Object> map = new HashMap<String, Object>();
        HashMap<String, Boolean> dataMap = new HashMap<String, Boolean>();
        boolean isSamePasswd = false;
        Tb_agent a = new Tb_agent();
        a.setSd_agent_id(Integer.valueOf(XcbStringUtils.getObjtoint((Object)sd_agent_id)));
        Map<String, Object> result_map = this.agentService.findAgentById(identifier, a);
        if (result_map.get(XcbConstantValue.DATA) != null) {
            Tb_agent agent = (Tb_agent)result_map.get(XcbConstantValue.DATA);
            isSamePasswd = this.standardPasswordEncoder.matches((CharSequence)oldPasswd, agent.getPassword());
            dataMap.put("isSamePasswd", isSamePasswd);
        }
        map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        map.put(XcbConstantValue.DATA, dataMap);
        map.put(XcbConstantValue.MSG, "");
        return map;
    }

    @RequestMapping(value={"/findAgentById"})
    @ResponseBody
    public Map<String, Object> findAgentById(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.agentService.findAgentById(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/validateAgentUsername"})
    @ResponseBody
    public Map<String, Object> validateAgentUsername(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> ret = this.agentService.validateAgentUsername(identifier, agent);
        return ret;
    }

    @RequestMapping(value={"/genCode"})
    @ResponseBody
    public Map<String, Object> genCode(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.agentService.genCode(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/sendSms"})
    @ResponseBody
    public Map<String, Object> sendSms(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.agentService.sendSms(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/genWxCode"})
    @ResponseBody
    public Map<String, Object> genWxCode(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.agentService.genWxCode(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/validateWxCode"})
    @ResponseBody
    public Map<String, Object> validateWxCode(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        if (agent.getSr_open_id() != null && this.redis.haskey(agent.getSr_user_name()) && !agent.getSr_open_id().equals(this.redis.getStr(agent.getSr_user_name())) && StrUtil.isNotBlank((CharSequence)this.redis.getStr(agent.getSr_user_name()))) {
            result_map.put(XcbConstantValue.DATA, this.redis.getStr(agent.getSr_user_name()));
            result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("wxopenid.get.success"));
        } else {
            result_map.put(XcbConstantValue.DATA, "");
            result_map.put(XcbConstantValue.MSG, "");
        }
        return result_map;
    }

    @RequestMapping(value={"/getOpenid"}, produces={"text/html"})
    @ResponseBody
    public String getOpenid(HttpServletRequest request, HttpServletResponse response, Tb_agent agent) throws Exception {
        Identifier identifier = new Identifier();
        String msg = "openId\u83b7\u53d6\u6210\u529f,\u8bf7\u524d\u5f80\u7cfb\u7edf\u9a8c\u8bc1";
        String code = request.getParameter("code");
        this.log.info("\u83b7\u5f97\u5fae\u4fe1\u4e34\u65f6\u51ed\u8bc1:" + code);
        Map<String, Object> result_map = this.agentService.findAgentById(identifier, agent);
        agent = (Tb_agent)result_map.get(XcbConstantValue.DATA);
        Tb_company company = this.wxzfCommon.getCompany(identifier, agent.getSw_company_id(), null);
        String openId_str = this.wxzfCommon.getOpenid(code, company);
        JSONObject jsonObj = JSONObject.parseObject((String)openId_str);
        this.log.info(jsonObj.toString());
        String sr_open_id = jsonObj.getString("openid");
        this.redis.setStr(agent.getSr_user_name(), sr_open_id);
        StringBuffer sbHtml = new StringBuffer();
        sbHtml.append("<!doctype html><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
        sbHtml.append("<title>\u63d0\u793a</title></head><body><div style='width:100%;height:auto;position:absolute;top:50%;left:0;right:0;bottom:0;text-align:center;font-size:50px'>" + msg + "</div><div id=\"openid\" hidden>" + sr_open_id + "</div></body></html>");
        PrintWriter out = response.getWriter();
        response.setHeader("Content-Type", "text/html;charset=UTF-8");
        out.write(sbHtml.toString());
        out.flush();
        out.close();
        return null;
    }

    @RequestMapping(value={"/saveOpenid"})
    @ResponseBody
    public Map<String, Object> saveOpenid(HttpServletRequest request, HttpServletResponse response) {
        HashMap<String, Object> result_map2 = new HashMap<String, Object>();
        Tb_agent agent = new Tb_agent();
        try {
            BufferedReader bufferReader = request.getReader();
            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = bufferReader.readLine()) != null) {
                sb.append(line);
            }
            String postData = sb.toString();
            JSONObject jsonObj = JSONObject.parseObject((String)postData);
            agent.setSd_agent_id(jsonObj.getInteger("sd_agent_id"));
            String code = jsonObj.getString("code");
            this.log.info("saveOpenid\u8bf7\u6c42request\u53c2\u6570\uff1a" + postData);
            Identifier identifier = new Identifier();
            Map<String, Object> result_map = this.agentService.findAgentById(identifier, agent);
            Tb_agent agentInDB = (Tb_agent)result_map.get(XcbConstantValue.DATA);
            Tb_company company = this.wxzfCommon.getCompany(identifier, agentInDB.getSw_company_id(), null);
            String openId_str = this.wxzfCommon.getOpenid(code, company);
            JSONObject jsonObj2 = JSONObject.parseObject((String)openId_str);
            this.log.info(jsonObj2.toString());
            String sr_open_id = jsonObj2.getString("openid");
            this.redis.setStrForTimeMIN(agentInDB.getSr_user_name(), sr_open_id, 5L);
            result_map2.put(XcbConstantValue.DATA, "");
            result_map2.put(XcbConstantValue.MSG, "\u64cd\u4f5c\u6210\u529f");
            result_map2.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error("saveOpenid\u62a5\u9519\uff1a" + e.getMessage());
            result_map2.put(XcbConstantValue.DATA, "");
            result_map2.put(XcbConstantValue.MSG, "\u64cd\u4f5c\u5931\u8d25");
            result_map2.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        return result_map2;
    }

    @RequestMapping(value={"/findUserRolesByUserId"})
    @ResponseBody
    public Map<String, Object> findUserRolesByUserId(HttpServletRequest request, String sd_agent_id) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.agentService.findUserRolesByUserId(identifier, sd_agent_id);
        return ret;
    }

    @RequestMapping(value={"/updateUserRolesByUserId"})
    @ResponseBody
    public Map<String, Object> updateUserRolesByUserId(HttpServletRequest request, String sd_agent_id, String[] roleArr) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.agentService.updateUserRolesByUserId(identifier, sd_agent_id, roleArr);
        return ret;
    }

    @RequestMapping(value={"/findAgentByAreaCode"})
    @ResponseBody
    public Map<String, Object> findAgentByAreaCode(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.findAgentByAreaCode(identifier, agent);
        return result_map;
    }
}

