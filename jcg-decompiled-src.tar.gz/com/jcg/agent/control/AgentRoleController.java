/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_agent_authorities
 *  com.jcg.agent.model.Tb_agent_roles
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_agent_authorities;
import com.jcg.agent.model.Tb_agent_roles;
import com.jcg.agent.service.AgentRoleServiceImpl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/role"})
public class AgentRoleController
extends BaseController {
    @Autowired
    private AgentRoleServiceImpl roleService;

    @RequestMapping(value={"/createRole"})
    @ResponseBody
    public Map<String, Object> createRole(HttpServletRequest request, Tb_agent_roles role) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> ret = this.roleService.createRole(identifier, role);
        return ret;
    }

    @RequestMapping(value={"/findRoleById"})
    @ResponseBody
    public Map<String, Object> findRoleById(HttpServletRequest request, String sd_roles_id) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.roleService.findRoleById(identifier, sd_roles_id);
        return result_map;
    }

    @RequestMapping(value={"/findRoleByParam"})
    @ResponseBody
    public Map<String, Object> findRoleByParam(HttpServletRequest request, HttpServletResponse response, Tb_agent_roles role, Page page) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.roleService.findRoleByParam(identifier, role, page);
        return result_map;
    }

    @RequestMapping(value={"/updateRoleById"})
    @ResponseBody
    public Map<String, Object> updateRoleById(HttpServletRequest request, Tb_agent_roles role) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.roleService.updateRoleById(identifier, role);
        return result_map;
    }

    @RequestMapping(value={"/deleteRoleById"})
    @ResponseBody
    public Map<String, Object> deleteRoleById(HttpServletRequest request, String sd_roles_id) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.roleService.deleteRoleById(identifier, sd_roles_id);
        return result_map;
    }

    @RequestMapping(value={"/findRoleAuthById"})
    @ResponseBody
    public Map<String, Object> findRoleAuthById(HttpServletRequest request, HttpServletResponse response, String sd_roles_id, String sr_is_app) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.roleService.findRoleAuthById(identifier, sd_roles_id, sr_is_app);
        return result_map;
    }

    @RequestMapping(value={"/updateRoleAuthById"})
    @ResponseBody
    public Map<String, Object> updateRoleAuthById(HttpServletRequest request, HttpServletResponse response, String sd_roles_id, String[] authArr, String[] netArr) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.roleService.updateRoleAuthById(identifier, sd_roles_id, authArr, netArr);
        return result_map;
    }

    @RequestMapping(value={"/createAuth"})
    @ResponseBody
    public Map<String, Object> createAuth(HttpServletRequest request, Tb_agent_authorities auth) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> ret = this.roleService.createAuth(identifier, auth);
        return ret;
    }

    @RequestMapping(value={"/updateAuthById"})
    @ResponseBody
    public Map<String, Object> updateAuthById(HttpServletRequest request, Tb_agent_authorities auth) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> ret = this.roleService.updateAuthById(identifier, auth);
        return ret;
    }

    @RequestMapping(value={"/delAuthById"})
    @ResponseBody
    public Map<String, Object> delAuthById(HttpServletRequest request, Integer sd_authority_id) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> ret = this.roleService.delAuthById(identifier, sd_authority_id);
        return ret;
    }

    @RequestMapping(value={"/batchDeleteById"})
    @ResponseBody
    public Map<String, Object> batchDeleteById(HttpServletRequest request, HttpServletResponse response, String[] authArr) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.roleService.batchDeleteById(identifier, authArr);
        return result_map;
    }
}

