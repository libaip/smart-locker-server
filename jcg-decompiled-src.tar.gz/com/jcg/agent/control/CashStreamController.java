/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_cash_stream
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.company.model.Tb_sys_param
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.common.ExportToExcel;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_cash_stream;
import com.jcg.agent.service.CashStreamServiceImpl;
import com.jcg.agent.service.SysParamServiceImpl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.company.model.Tb_sys_param;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/cashstream"})
public class CashStreamController
extends BaseController {
    @Autowired
    private CashStreamServiceImpl cashStreamService;
    @Autowired
    private SysParamServiceImpl sysParamService;

    @RequestMapping(value={"/findCashStreamByAgentId"})
    @ResponseBody
    public Map<String, Object> findCashStreamByAgentId(HttpServletRequest request, Integer sd_agent_id) throws Exception {
        this.log.debug("cashflowInfo================\u8fdb\u5165\u9996\u9875\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.cashStreamService.findCashStreamByAgentId(identifier, sd_agent_id);
        return result_map;
    }

    @RequestMapping(value={"/findCashflowByParam"})
    @ResponseBody
    public Map<String, Object> findCashflowByParam(HttpServletRequest request, Tb_cash_stream cashstream, Page page) throws Exception {
        this.log.debug("cashflowInfo================\u5546\u5bb6\u6d41\u6c34\u67e5\u8be2");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.cashStreamService.findCashStreamByCash(identifier, cashstream, page);
        return result_map;
    }

    @RequestMapping(value={"/expExcelCashStream"})
    @ResponseBody
    public Map<String, Object> expExcelCashStream(HttpServletRequest request, HttpServletResponse response, Tb_cash_stream cashstream) throws Exception {
        this.log.debug("cashflowInfo================\u8fdb\u5165\u8d44\u91d1\u6d41\u6c34\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> maxExpMap = this.sysParamService.findSysParamByKeyCode(identifier, XcbConstantValue.XTCL, XcbConstantValue.EXPMAX);
        Tb_sys_param sysparam = (Tb_sys_param)maxExpMap.get("sysParam");
        Integer maxExpCnt = Integer.valueOf(sysparam.getSr_param_value());
        Page page = new Page();
        page.setStart(0);
        page.setPageSize(maxExpCnt.intValue());
        Map<String, Object> result_map = this.cashStreamService.findCashStreamByCash(identifier, cashstream, page);
        Map dataMap = (Map)result_map.get(XcbConstantValue.DATA);
        List cashStreamLst = (List)dataMap.get("cashstreams");
        this.genTransExcelFile(request, response, cashStreamLst);
        return null;
    }

    private void genTransExcelFile(HttpServletRequest request, HttpServletResponse response, List dataList) throws Exception {
        this.log.debug("cashflowInfo================\u5bfc\u51fa");
        Date currentDt = new Date();
        String StrCurrentDt = XcbDateUtil.formatDate((Date)currentDt, (String)"yyyyMMddHHmmss");
        String filedisplay = StrCurrentDt + "\u8d44\u91d1\u6d41\u6c34.xlsx";
        String title = "\u8d44\u91d1\u6d41\u6c34";
        String titleCode = XcbConstantValue.EXPORT_ZJLS;
        String[] headers = new String[]{"\u6d41\u6c34ID", "\u6d41\u6c34\u9879\u76ee", "\u6d41\u6c34\u91d1\u989d", "\u652f\u4ed8\u72b6\u6001", "\u8ba2\u5355ID", "\u6d41\u6c34\u65f6\u95f4", "\u590d\u6838\u72b6\u6001"};
        String[] fieldNams = new String[]{"sd_cash_id", "sr_cashflow_item_exp", "sr_cashflow_money", "sr_company_pay_desc", "sr_cashflow_remark", "sr_cashflow_time", "sr_checked_desc"};
        ArrayList<String> cashflowItemFieldList = new ArrayList<String>();
        cashflowItemFieldList.add("sr_cashflow_item_exp");
        new ExportToExcel().exportExcel(filedisplay, title, titleCode, headers, fieldNams, dataList, response, null, cashflowItemFieldList);
    }
}

