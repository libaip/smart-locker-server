/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_deposit_share
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_deposit_share;
import com.jcg.agent.service.DepositShareServiceImpl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/share"})
public class DepositShareController
extends BaseController {
    @Autowired
    DepositShareServiceImpl depositShareService;

    @RequestMapping(value={"/findDepositShareByParam"})
    @ResponseBody
    public Map<String, Object> findDepositShareByParam(HttpServletRequest request, Tb_deposit_share share, Page page) throws Exception {
        this.log.debug("DepositShare================\u62bc\u91d1\u590d\u6838");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.depositShareService.findDepositShareByParam(identifier, share, page);
        return result_map;
    }

    @RequestMapping(value={"/updateDepositShare"})
    @ResponseBody
    public Map<String, Object> updateDepositShare(HttpServletRequest request, Tb_deposit_share share) throws Exception {
        this.log.debug("DepositShare================\u62bc\u91d1\u590d\u6838");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.depositShareService.updateDepositShare(identifier, share);
        return result_map;
    }
}

