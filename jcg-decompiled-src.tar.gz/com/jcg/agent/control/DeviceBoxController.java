/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.Identifier
 *  javax.servlet.http.HttpServletRequest
 *  net.sf.json.JSONArray
 *  net.sf.json.JsonConfig
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.service.DeviceBoxServiceImpl;
import com.jcg.agent.service.DeviceCloudServiceImpl;
import com.jcg.common.model.Identifier;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/deviceBox"})
public class DeviceBoxController
extends BaseController {
    @Autowired
    private DeviceBoxServiceImpl deviceBoxService;
    @Autowired
    private DeviceCloudServiceImpl deviceCloudService;

    @RequestMapping(value={"/findDeviceBoxByDeviceId"})
    @ResponseBody
    public Map<String, Object> findDeviceBoxByDeviceId(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.deviceBoxService.findDeviceBoxByDeviceId(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/batchUpdateDeviceBoxById"})
    @ResponseBody
    public Map<String, Object> batchUpdateDeviceBoxById(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        String sr_way = "SHOP";
        if ("1".equals(agent_user.getSr_role())) {
            sr_way = "AGENT";
        }
        Map<String, Object> result_map = this.deviceBoxService.batchUpdateDeviceBoxById(identifier, deviceBox, sr_way);
        this.deviceCloudService.refreshLock(identifier, deviceBox.getSw_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/updateDeviceBoxById"})
    @ResponseBody
    public Map<String, Object> updateDeviceBoxById(HttpServletRequest request, String deviceBoxStrs) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u5957\u9910\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        deviceBoxStrs = deviceBoxStrs.replaceAll("&quot;", "\"");
        JSONArray array = JSONArray.fromObject((Object)deviceBoxStrs);
        List deviceBoxs = JSONArray.toList((JSONArray)array, (Object)new Tb_device_box(), (JsonConfig)new JsonConfig());
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.deviceBoxService.updateDeviceBoxById(identifier, deviceBoxs);
        this.deviceCloudService.refreshLock(identifier, ((Tb_device_box)deviceBoxs.get(0)).getSw_mainboard_id());
        return result_map;
    }
}

