/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.Identifier
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.service.DeviceCloudServiceImpl;
import com.jcg.common.model.Identifier;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/cloud"})
public class DeviceCloudController
extends BaseController {
    @Autowired
    private DeviceCloudServiceImpl deviceCloudService;

    @RequestMapping(value={"/openLock"})
    @ResponseBody
    public Map<String, Object> openLock(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        result_map = this.deviceCloudService.openLock(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/openAllLock"})
    @ResponseBody
    public Map<String, Object> openAllLock(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        result_map = this.deviceCloudService.openAllLock(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/getState"})
    @ResponseBody
    public Map<String, Object> getState(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        result_map = this.deviceCloudService.getState(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/updateApp"})
    @ResponseBody
    public Map<String, Object> updateApp(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        result_map = this.deviceCloudService.updateApp(identifier, device);
        return result_map;
    }
}

