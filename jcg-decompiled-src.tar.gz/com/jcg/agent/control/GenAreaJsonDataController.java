/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.Identifier
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.service.GenAreaJsonDataServiceImpl;
import com.jcg.common.model.Identifier;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/genAreaJsonData"})
public class GenAreaJsonDataController
extends BaseController {
    @Autowired
    private GenAreaJsonDataServiceImpl genAreaJsonDataService;

    @RequestMapping(value={"/findAreaJsonDataByParam"})
    @ResponseBody
    public Map<String, Object> findAreaJsonDataByParam(HttpServletRequest request, String sd_code) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_user_name());
        Map<String, Object> result_map = this.genAreaJsonDataService.findAreaJsonDataByParam(identifier, sd_code);
        return result_map;
    }
}

