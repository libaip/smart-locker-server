/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.authentication.AuthenticationManager
 *  org.springframework.security.authentication.UsernamePasswordAuthenticationToken
 *  org.springframework.security.core.Authentication
 *  org.springframework.security.core.authority.SimpleGrantedAuthority
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.security.core.userdetails.UserDetails
 *  org.springframework.security.core.userdetails.UserDetailsService
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RequestMethod
 *  org.springframework.web.bind.annotation.RestController
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.security.JwtTokenUtil;
import com.jcg.agent.service.AgentServiceImpl;
import com.jcg.agent.vo.LoginUser;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value={"/auth"}, method={RequestMethod.POST})
public class LoginController
extends BaseController {
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private AgentServiceImpl agentService;

    @RequestMapping(value={"/login"}, method={RequestMethod.POST})
    public Map<String, Object> login(LoginUser loginUser, HttpServletRequest request) throws Exception {
        this.log.info("in login...");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        HashMap<String, Object> userInfodataMap = new HashMap<String, Object>();
        Map<String, Object> resMp = this.agentService.login(identifier, loginUser);
        int status = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
        if (status > XcbConstantValue.OPERA_INT_ZERO) {
            Authentication authentication = this.authenticationManager.authenticate((Authentication)new UsernamePasswordAuthenticationToken((Object)loginUser.getUsername(), (Object)loginUser.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            Tb_agent agent = (Tb_agent)this.userDetailsService.loadUserByUsername(loginUser.getUsername());
            Collection authList = agent.getAuthorities();
            ArrayList authList2 = (ArrayList)agent.getUserInfoRoles();
            if ("1".equals(agent.getSr_role())) {
                authList2.add(new SimpleGrantedAuthority("ROLE_SHOP"));
                authList2.add(new SimpleGrantedAuthority("ROLE_SHOP_INDEX"));
                authList2.add(new SimpleGrantedAuthority("ROLE_ORDER_DEPOSIT_SHARE"));
            } else if ("2".equals(agent.getSr_role())) {
                authList2.add(new SimpleGrantedAuthority("ROLE_ROLE"));
            }
            String loginType = XcbConstantValue.DEVICE_TYPE_YPJCG;
            authList2.add(new SimpleGrantedAuthority("ROLE_ORDER"));
            ArrayList<String> accessCodeList = new ArrayList<String>();
            String[] accessArr = new String[authList2.size()];
            Iterator iter = authList2.iterator();
            while (iter.hasNext()) {
                accessCodeList.add(((SimpleGrantedAuthority)iter.next()).getAuthority());
            }
            accessCodeList.toArray(accessArr);
            String show_check = "N";
            if ("Y".equals(agent.getSr_is_show_fh()) && "1".equals(agent.getSr_role())) {
                show_check = "Y";
            }
            String token = this.jwtTokenUtil.generateToken((UserDetails)agent, authList);
            dataMap.put("token", token);
            userInfodataMap.put("name", agent.getSr_agent_name());
            userInfodataMap.put("avatar", XcbConstantValue.AGENT_AVATAR_DEFAULT);
            userInfodataMap.put("access", accessArr);
            userInfodataMap.put("userid", agent.getSd_agent_id());
            userInfodataMap.put("companyid", agent.getSw_company_id());
            userInfodataMap.put("role", agent.getSr_role());
            userInfodataMap.put("sex", agent.getSr_sex());
            userInfodataMap.put("show_ad", agent.getSr_is_ad());
            userInfodataMap.put("netArr", agent.getNetArr());
            userInfodataMap.put("show_check", show_check);
            userInfodataMap.put("loginType", loginType);
            userInfodataMap.put("adminid", XcbStringUtils.getObjtoString((Object)agent.getSr_admin_id()));
            userInfodataMap.put("nikename", agent.getSr_agent_petname());
            dataMap.put("info", userInfodataMap);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        ret.put(XcbConstantValue.MSG, XcbStringUtils.getObjtoString((Object)resMp.get(XcbConstantValue.MSG)));
        return ret;
    }

    private List<String> getJCGAccessList(List<String> accessCodeList) {
        ArrayList<String> list = new ArrayList<String>();
        List<String> resultList = LoginController.listrem(accessCodeList, list);
        return resultList;
    }

    public static List<String> listrem(List<String> listA, List<String> listB) {
        Iterator<String> itA = listA.iterator();
        while (itA.hasNext()) {
            String temp = itA.next();
            for (int i = 0; i < listB.size(); ++i) {
                if (!temp.equals(listB.get(i))) continue;
                itA.remove();
            }
        }
        return listA;
    }
}

