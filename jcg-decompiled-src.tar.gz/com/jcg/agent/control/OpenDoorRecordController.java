/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_opendoor_record
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_opendoor_record;
import com.jcg.agent.service.OpenDoorRecordServiceImpl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/opendoor"})
public class OpenDoorRecordController
extends BaseController {
    @Autowired
    private OpenDoorRecordServiceImpl OpenDoorRecordService;

    @RequestMapping(value={"/findOpenDoorRecordByParam"})
    @ResponseBody
    public Map<String, Object> findOpenDoorRecordByParam(HttpServletRequest request, Tb_opendoor_record openDoorRecord, Page page) throws Exception {
        this.log.debug("OpenDoorRecordInfo================\u67e5\u8be2\u626b\u7801\u8bb0\u5f55\u5217\u8868");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.OpenDoorRecordService.findOpenDoorRecordByParam(identifier, openDoorRecord, page);
        return result_map;
    }
}

