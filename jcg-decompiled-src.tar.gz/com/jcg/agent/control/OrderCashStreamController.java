/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_ordercash_stream
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_ordercash_stream;
import com.jcg.agent.service.OrderCashStreamServiceImpl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/orderCashStream"})
public class OrderCashStreamController
extends BaseController {
    @Autowired
    private OrderCashStreamServiceImpl orderCashStreamService;

    @RequestMapping(value={"/findOrderCashStreamByParam"})
    @ResponseBody
    public Map<String, Object> findOrderCashStreamByParam(HttpServletRequest request, Tb_ordercash_stream orderCashStream, Page page) throws Exception {
        this.log.debug("OrderCashStreamInfo================\u67e5\u8be2\u7ed3\u7b97\u6d41\u6c34\u5217\u8868");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.orderCashStreamService.findOrderCashStreamByParam(identifier, orderCashStream, page);
        return result_map;
    }
}

