/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_sys_param
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.common.ExportToExcel;
import com.jcg.agent.common.RedisUtil;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.service.OrderServiceImpl;
import com.jcg.agent.service.SysParamServiceImpl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_sys_param;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/order"})
public class OrderController
extends BaseController {
    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private SysParamServiceImpl sysParamService;
    @Autowired
    private RedisUtil redis;

    @RequestMapping(value={"/findOrderByParam"})
    @ResponseBody
    public Map<String, Object> findOrderByParam(HttpServletRequest request, Tb_order order, Page page) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u5217\u8868");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.orderService.findOrderByParam(identifier, order, page);
        return result_map;
    }

    @RequestMapping(value={"/findOrderById"})
    @ResponseBody
    public Map<String, Object> findOrderById(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.orderService.findOrderById(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/updateOrderById"})
    @ResponseBody
    public Map<String, Object> updateOrderById(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u66f4\u65b0\u8ba2\u5355\u4fe1\u606f");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.orderService.updateOrderById(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/closeOrder"})
    @ResponseBody
    public Map<String, Object> closeOrder(HttpServletRequest request, String sd_order_id) throws Exception {
        String order_redis;
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Map<String, Object> result_map = new HashMap<String, Object>();
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        String sr_way = "SHOP";
        if ("1".equals(agent_user.getSr_role())) {
            sr_way = "AGENT";
        }
        if (XcbStringUtils.isNullOrBlank((Object)(order_redis = XcbStringUtils.getObjtoString((Object)this.redis.get(sd_order_id))))) {
            this.redis.setForTimeMS(sd_order_id, XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"), 10000L);
            result_map = this.orderService.closeOrder(identifier, sd_order_id, sr_way);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u8bf7\u52ff\u91cd\u590d\u64cd\u4f5c");
        }
        return result_map;
    }

    @RequestMapping(value={"/checkRefund"})
    @ResponseBody
    public Map<String, Object> checkRefund(HttpServletRequest request, String sd_ordercash_id, String sr_refund_money) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.orderService.checkRefund(identifier, sd_ordercash_id, sr_refund_money);
        return result_map;
    }

    @RequestMapping(value={"/zhRefund"})
    @ResponseBody
    public Map<String, Object> zhRefund(HttpServletRequest request, String sd_ordercash_id, String sr_refund_money) throws Exception {
        this.log.debug("OrderInfo================\u8d26\u6237\u4f59\u989d\u9000\u6b3e");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.orderService.zhRefund(identifier, sd_ordercash_id, sr_refund_money);
        return result_map;
    }

    @RequestMapping(value={"/depositRefund"})
    @ResponseBody
    public Map<String, Object> depositRefund(HttpServletRequest request, String sd_order_id, String sr_refund_money) throws Exception {
        this.log.debug("OrderInfo================\u8ba2\u5355\u62bc\u91d1\u9000\u6b3e");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.orderService.depositRefund(identifier, sd_order_id, sr_refund_money);
        return result_map;
    }

    @RequestMapping(value={"/expExcelOrder"})
    @ResponseBody
    public Map<String, Object> expExcelOrder(HttpServletRequest request, HttpServletResponse response, Tb_order order) throws Exception {
        this.log.debug("cashflowInfo================\u8fdb\u5165\u8d44\u91d1\u6d41\u6c34\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> maxExpMap = this.sysParamService.findSysParamByKeyCode(identifier, XcbConstantValue.XTCL, XcbConstantValue.EXPMAX);
        Tb_sys_param sysparam = (Tb_sys_param)maxExpMap.get("sysParam");
        Integer maxExpCnt = Integer.valueOf(sysparam.getSr_param_value());
        Page page = new Page();
        page.setStart(0);
        page.setPageSize(maxExpCnt.intValue());
        Map<String, Object> result_map = this.orderService.findOrderForExcel(identifier, order, page);
        Map dataMap = (Map)result_map.get(XcbConstantValue.DATA);
        List orders = (List)dataMap.get("orders");
        this.genTransExcelFile(request, response, agent_user, orders);
        return null;
    }

    private void genTransExcelFile(HttpServletRequest request, HttpServletResponse response, Tb_agent agent, List dataList) throws Exception {
        this.log.debug("orderInfo================\u5bfc\u51fa");
        Date currentDt = new Date();
        String StrCurrentDt = XcbDateUtil.formatDate((Date)currentDt, (String)"yyyyMMddHHmmss");
        String filedisplay = StrCurrentDt + "\u5728\u7ebf\u8ba2\u5355.xlsx";
        String title = "\u8ba2\u5355";
        String titleCode = XcbConstantValue.EXPORT_DD;
        String[] headers = new String[]{"\u8ba2\u5355ID", "\u5546\u5bb6\u540d\u79f0", "\u7f51\u70b9\u540d\u79f0", "\u8bbe\u5907ID", "\u67dc\u5b50\u7f16\u53f7", "\u7528\u6237\u624b\u673a\u53f7\u7801", "\u5fae\u4fe1\u6635\u79f0", "\u8ba2\u5355\u6765\u6e90", "\u8ba1\u8d39\u65b9\u5f0f", "\u8ba2\u5355\u91d1\u989d", "\u5b9e\u9645\u91d1\u989d", "\u8ba2\u5355\u9000\u6b3e\u91d1\u989d", "\u5f00\u59cb\u65f6\u95f4", "\u7ed3\u675f\u65f6\u95f4", "\u8ba2\u5355\u72b6\u6001"};
        String[] fieldNams = new String[]{"sd_order_id", "sr_agent_name", "sr_net_name", "si_mainboard_id", "sr_alias_desc", "sr_user_name", "sr_user_petname", "sr_order_way_desc", "sr_charging_type_desc", "dc_order_money", "dc_actual_income", "dc_refund_money", "sr_order_starttime", "sr_order_endtime", "sr_order_status_desc"};
        new ExportToExcel().exportExcel(filedisplay, title, titleCode, headers, fieldNams, dataList, response, null, null);
    }
}

