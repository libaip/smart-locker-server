/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_statistics;
import com.jcg.agent.service.StatisticsServiceImpl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/statistics"})
public class StatisticsController
extends BaseController {
    @Autowired
    private StatisticsServiceImpl statisticsService;

    @RequestMapping(value={"/findStatisticsByParam"})
    @ResponseBody
    public Map<String, Object> findStatisticsByParam(HttpServletRequest request, Tb_statistics statistics, Page page) throws Exception {
        this.log.debug("StatisticsInfo================\u67e5\u8be2\u5546\u54c1\u5217\u8868");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.statisticsService.findStatisticsByParam(identifier, statistics, page);
        return result_map;
    }

    @RequestMapping(value={"/findLineChartGroupByParam"})
    @ResponseBody
    public Map<String, Object> findLineChartGroupByParam(HttpServletRequest request, Tb_statistics statistics) throws Exception {
        this.log.debug("StatisticsInfo================\u67e5\u8be2\u5546\u54c1\u5217\u8868");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.statisticsService.findLineChartGroupByParam(identifier, statistics);
        return result_map;
    }

    @RequestMapping(value={"/findLineChartDataByParam"})
    @ResponseBody
    public Map<String, Object> findLineChartDataByParam(HttpServletRequest request, Tb_statistics statistics) throws Exception {
        this.log.debug("StatisticsInfo================\u67e5\u8be2\u5546\u54c1\u5217\u8868");
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.statisticsService.findLineChartDataByParam(identifier, statistics);
        return result_map;
    }
}

