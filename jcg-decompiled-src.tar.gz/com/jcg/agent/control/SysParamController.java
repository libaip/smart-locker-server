/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.Identifier
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 *  org.springframework.web.servlet.ModelAndView
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.service.SysParamServiceImpl;
import com.jcg.common.model.Identifier;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value={"/sysParam"})
public class SysParamController
extends BaseController {
    @Autowired
    private SysParamServiceImpl sysParamService;

    @RequestMapping(value={"/findSysParamById"})
    public ModelAndView findSysParamById(HttpServletRequest request) throws Exception {
        ModelAndView mv = new ModelAndView();
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        String sr_category_code = request.getParameter("sr_category_code");
        Map<String, Object> ret = this.sysParamService.findSysParamByCate(identifier, sr_category_code);
        mv.addAllObjects(ret);
        mv.setViewName("");
        return mv;
    }

    @RequestMapping(value={"/findDropDownInfos"})
    @ResponseBody
    public Map<String, Object> findDropDownInfos(HttpServletRequest request, String sr_login_type) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        String categoryCodes = request.getParameter("categoryCodes") == null ? "" : request.getParameter("categoryCodes");
        Map<String, Object> ret = this.sysParamService.findDropDownInfos(identifier, categoryCodes, sr_login_type);
        return ret;
    }
}

