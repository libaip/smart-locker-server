/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.service.UserServiceImpl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.user.model.Tb_user;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@RequestMapping(value={"/user"})
@Controller
public class UserController
extends BaseController {
    @Autowired
    private UserServiceImpl userService;
    private Map<String, Object> ret;

    @RequestMapping(value={"/updateUserById"})
    @ResponseBody
    public Map<String, Object> updateUserById(HttpServletResponse reponse, HttpServletRequest request, Tb_user user) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        this.ret = this.userService.updateUserById(identifier, user);
        return this.ret;
    }

    @RequestMapping(value={"/findUserByParam"})
    @ResponseBody
    public Map<String, Object> findUserByParam(HttpServletResponse reponse, HttpServletRequest request, Tb_user user, Page page) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        this.ret = this.userService.findUserByParam(identifier, user, page);
        return this.ret;
    }
}

