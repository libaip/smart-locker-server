/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent_way
 *  com.jcg.common.model.Identifier
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.model.Tb_agent_way;
import com.jcg.agent.service.WebServiceImpl;
import com.jcg.common.model.Identifier;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/webapi"})
public class WebApiController
extends BaseController {
    @Autowired
    private WebServiceImpl webService;

    @RequestMapping(value={"/findUserName"})
    @ResponseBody
    public Map<String, Object> findUserName(HttpServletRequest request, Tb_agent_way agent) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u5217\u8868");
        HashMap<String, Object> result_map = new HashMap();
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        result_map = this.webService.findUserName(identifier, agent);
        return result_map;
    }
}

