/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_withdrawal_appl
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.control;

import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_withdrawal_appl;
import com.jcg.agent.service.WithdrawalApplServiceImpl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/withdrawal"})
public class WithdrawalApplController {
    @Autowired
    private WithdrawalApplServiceImpl withdrawalApplService;

    @RequestMapping(value={"/createWithdrawalAppl"})
    @ResponseBody
    public Map<String, Object> createWithdrawalAppl(HttpServletRequest request, Tb_withdrawal_appl withdrawalAppl) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.withdrawalApplService.createWithdrawalAppl(identifier, withdrawalAppl);
        return result_map;
    }

    @RequestMapping(value={"/createWithdrawalAppl_staff"})
    @ResponseBody
    public Map<String, Object> createWithdrawalAppl_staff(HttpServletRequest request, Tb_withdrawal_appl withdrawalAppl) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.withdrawalApplService.createWithdrawalAppl_staff(identifier, withdrawalAppl);
        return result_map;
    }

    @RequestMapping(value={"/findWithdrawalApplByParam"})
    @ResponseBody
    public Map<String, Object> findWithdrawalApplByParam(HttpServletRequest request, Tb_withdrawal_appl withdrawalAppl, Page page) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.withdrawalApplService.findWithdrawalApplByParam(identifier, withdrawalAppl, page);
        return result_map;
    }

    @RequestMapping(value={"/findWithdrawalApplAgentInfoByParam"})
    @ResponseBody
    public Map<String, Object> findWithdrawalApplAgentInfoByParam(HttpServletRequest request, Tb_withdrawal_appl withdrawalAppl) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        Map<String, Object> result_map = this.withdrawalApplService.findWithdrawalApplAgentInfoByParam(identifier, withdrawalAppl);
        return result_map;
    }
}

