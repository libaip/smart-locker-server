/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.agent.idao;

public interface ADPlayDao {
}

