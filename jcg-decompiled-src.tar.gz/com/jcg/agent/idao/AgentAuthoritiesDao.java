/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent_authorities
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_agent_authorities;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface AgentAuthoritiesDao {
    public int createCompanyAuth(Tb_agent_authorities var1);

    public int deleteById(int var1);

    public int deleteByPId(int var1);

    public int batchDeleteById(@Param(value="authArr") String[] var1);

    public int updateById(Tb_agent_authorities var1);

    public List<Map<String, Object>> findAll(String var1);

    public List<Tb_agent_authorities> findAuthsByCuserId(@Param(value="sw_agent_id") Integer var1);
}

