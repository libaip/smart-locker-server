/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_agent;
import com.jcg.common.model.Page;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface AgentDao {
    public int createAgent(Tb_agent var1);

    public Tb_agent findAgentByUserName_agent(String var1);

    public int updateAgentById_agent(Tb_agent var1);

    public Tb_agent findAgentById_agent(Integer var1);

    public int updateStsById_agent(Tb_agent var1);

    public int updateAgentSettingById_agent(Tb_agent var1);

    public int updatePassword_agent(Tb_agent var1);

    public int updateSmsById(Tb_agent var1);

    public int createAgent_cpy(Tb_agent var1);

    public List<Map<String, Object>> findAgentByAreaCode(Tb_agent var1);

    public List<Map<String, Object>> findAgentByAreaCode_cpy(Tb_agent var1);

    public List<Tb_agent> findAgentByParam_cpy(@Param(value="fi") Tb_agent var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(Tb_agent var1);

    public List<Tb_agent> findAgentMoneyByParam_cpy(@Param(value="fi") Tb_agent var1, @Param(value="page") Page var2);

    public int findCountMoneyByParam_cpy(Tb_agent var1);

    public List<Tb_agent> findStaffByParam_cpy(@Param(value="fi") Tb_agent var1, @Param(value="page") Page var2);

    public int findStaffCountByParam_cpy(Tb_agent var1);

    public List<Map<String, Object>> findAllAgentById_cpy(Tb_agent var1);

    public List<Map<String, Object>> findUpAgentByParam_cpy(Tb_agent var1);

    public int updateStsById_cpy(Tb_agent var1);

    public int resetPasswordById_cpy(Tb_agent var1);

    public List<Tb_agent> findByAgentRegion_cpy(Tb_agent var1);

    public List<Tb_agent> findAllUserByAgentId(@Param(value="fi") Tb_agent var1, @Param(value="page") Page var2);

    public int findAllUserCount(Tb_agent var1);

    public Tb_agent findAgentMoneyById_user(Integer var1);

    public int updateAgentMoneyById(Tb_agent var1);

    public int updateAdMoneyById(Tb_agent var1);

    public int updateAgentCbMoneyById(Tb_agent var1);

    public int updateMaxMoneyById(Tb_agent var1);

    public int updateAgentTxMoneyById(Tb_agent var1);

    public Map<String, Object> findSumAgentMoney_agent(Tb_agent var1);

    public Tb_agent findAgentByIdForBusinessTask(Integer var1);

    public int deleteAgentById(Integer var1);

    public List<String> findSubAgentList(Integer var1);

    public List<Tb_agent> findAgentByParam(@Param(value="fi") Tb_agent var1, @Param(value="page") Page var2);

    public int findCountByParam(Tb_agent var1);

    public List<Tb_agent> findAgentForShare(@Param(value="fi") Tb_agent var1, @Param(value="page") Page var2);

    public int findCountForShare(@Param(value="fi") Tb_agent var1);

    public List<Tb_agent> findBusinessAgent();

    public Tb_agent findAgentById(Integer var1);

    public Tb_agent findUpAgentById(Integer var1);

    public List<Tb_agent> findAgentForTask();

    public List<Tb_agent> findAdAgentForTask();

    public List<Tb_agent> findUpAdAgentForTask();

    public List<String> findShopList(Integer var1);

    public int updateAgentWay(Tb_agent var1);

    public List<String> findAdAgentList(Integer var1);

    public List<String> findUpAdAgentList(Integer var1);

    public List<String> findDefaultAgentList(Integer var1);
}

