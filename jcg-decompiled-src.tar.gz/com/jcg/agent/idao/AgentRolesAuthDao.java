/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent_roles_auth
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_agent_roles_auth;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AgentRolesAuthDao {
    public List<Tb_agent_roles_auth> findByRoleId(@Param(value="sw_roles_id") Integer var1);

    public List<Tb_agent_roles_auth> findByAuthId(@Param(value="sw_authority_id") Integer var1);

    public int deleteRoleAuthsByRoleId(@Param(value="sw_roles_id") Integer var1);

    public int deleteRoleAuthsByAuthId(@Param(value="sw_authority_id") Integer var1);

    public int batchDeleteRoleAuthsByAuthId(@Param(value="authArr") String[] var1);

    public int createRoleAuth(Tb_agent_roles_auth var1);

    public int insertRoleAuthByBatch(@Param(value="roleAuths") List<Tb_agent_roles_auth> var1);
}

