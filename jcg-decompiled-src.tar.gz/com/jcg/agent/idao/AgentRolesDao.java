/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent_roles
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_agent_roles;
import com.jcg.common.model.Page;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AgentRolesDao {
    public int createAgentRoles(Tb_agent_roles var1);

    public int deleteById(Integer var1);

    public int updateById(Tb_agent_roles var1);

    public Tb_agent_roles findById(Integer var1);

    public List<Tb_agent_roles> findByParam(@Param(value="fi") Tb_agent_roles var1, @Param(value="page") Page var2);

    public int findCntByParam(@Param(value="fi") Tb_agent_roles var1);

    public List<Tb_agent_roles> findAll(Integer var1);
}

