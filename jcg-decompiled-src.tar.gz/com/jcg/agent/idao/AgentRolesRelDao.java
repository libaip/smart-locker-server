/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent_roles_rel
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_agent_roles_rel;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AgentRolesRelDao {
    public int createCompanyRolesRel(Tb_agent_roles_rel var1);

    public int deleteById(Integer var1);

    public int updateById(Tb_agent_roles_rel var1);

    public Tb_agent_roles_rel findById(Integer var1);

    public List<Tb_agent_roles_rel> findByParam(Tb_agent_roles_rel var1);

    public List<Tb_agent_roles_rel> findByCuserId(@Param(value="sw_agent_id") Integer var1);

    public int deleteByCuserId(@Param(value="sw_agent_id") Integer var1);

    public List<Tb_agent_roles_rel> findByRoleId(@Param(value="sw_roles_id") Integer var1);

    public int insertUserRoleByBatch(@Param(value="userRoles") List<Tb_agent_roles_rel> var1);

    public List<String> findNetArrByAgentId(Integer var1);
}

