/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent_way
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_agent_way;

public interface AgentWayDao {
    public int createAgentWay(Tb_agent_way var1);

    public Tb_agent_way findUserName(String var1);

    public int updateAgentWay(Tb_agent_way var1);
}

