/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_cash_stream
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_cash_stream;
import com.jcg.common.model.Page;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface CashStreamDao {
    public int createCashStream(Tb_cash_stream var1);

    public List<Tb_cash_stream> findCashStreamByCash_agent(@Param(value="cs") Tb_cash_stream var1, @Param(value="page") Page var2);

    public int findCountCashStreamByCash_agent(Tb_cash_stream var1);

    public int updateCashStreamByCash_agent(Tb_cash_stream var1);

    public Map<String, Object> findAgentForBusiness(Integer var1);

    public Map<String, Object> findAgentForBusinessTk(Integer var1);

    public List<Tb_cash_stream> findCashStreamByCash_cpy(@Param(value="cs") Tb_cash_stream var1, @Param(value="page") Page var2);

    public int findCountCashStreamByCash_cpy(Tb_cash_stream var1);

    public List<Tb_cash_stream> findCashStreamByParam_Agentmb(@Param(value="fi") Tb_cash_stream var1, @Param(value="page") Page var2);

    public int findCountByParam_Agentmb(@Param(value="fi") Tb_cash_stream var1);

    public List<Tb_cash_stream> findCashStreamByNetArr_Agentmb(@Param(value="fi") Tb_cash_stream var1, @Param(value="page") Page var2);

    public int findCountByNetArr_Agentmb(@Param(value="fi") Tb_cash_stream var1);

    public List<Tb_cash_stream> findCashStreamByParam_Cpymb(@Param(value="fi") Tb_cash_stream var1, @Param(value="page") Page var2);

    public int findCountByParam_Cpymb(@Param(value="fi") Tb_cash_stream var1);

    public int deleteByDeviceId(String var1);

    public Map<String, Object> findCashStreamByParam_task(Tb_cash_stream var1);

    public List<String> findCashStreamListByParam(Tb_cash_stream var1);

    public int updateCash_task(@Param(value="arr") String[] var1);

    public BigDecimal findOrderIncome(Integer var1);

    public BigDecimal findOrderTk(Integer var1);
}

