/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_deposit_share
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_deposit_share;
import com.jcg.common.model.Page;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DepositShareDao {
    public int createDepositShare(Tb_deposit_share var1);

    public List<Tb_deposit_share> findDepositShareByAgent(Tb_deposit_share var1);

    public List<Tb_deposit_share> findDepositShareByParam_cpy(@Param(value="fi") Tb_deposit_share var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(Tb_deposit_share var1);

    public int updateStatus(Tb_deposit_share var1);

    public Tb_deposit_share findById(Integer var1);

    public List<Tb_deposit_share> findDepositShareByParam(@Param(value="fi") Tb_deposit_share var1, @Param(value="page") Page var2);

    public int findCountByParam(Tb_deposit_share var1);
}

