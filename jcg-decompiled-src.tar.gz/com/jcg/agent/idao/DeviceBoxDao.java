/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_device_fittings
 *  com.jcg.agent.model.Tb_statistics
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_device_fittings;
import com.jcg.agent.model.Tb_statistics;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface DeviceBoxDao {
    public int createDeviceBox(List<Tb_device_box> var1);

    public int updateDeviceBoxById(Tb_device_box var1);

    public int batchUpdateDeviceBoxById_agent(Tb_device_box var1);

    public int updateDeviceBoxRelSlots_cpy(Tb_device_box var1);

    public int deleteDeviceBox(Integer var1);

    public int batchDeleteDeviceBox(@Param(value="boxArr") String[] var1);

    public List<Tb_device_box> findDeviceBoxByDeviceId_agent(Tb_device_box var1);

    public List<Tb_device_box> findDeviceBoxByArrId_agent(Tb_device_box var1);

    public int findCountByParam_agent(Tb_device_box var1);

    public Tb_device_box findBoxMaxBoxNumByDeviceId(@Param(value="sw_device_id") String var1);

    public List<Tb_device_box> findAllBoxNum(Tb_device_box var1);

    public Tb_device_box findDeviceBoxByBoxNum(@Param(value="sw_device_id") String var1, @Param(value="si_box_num") Integer var2);

    public Tb_device_box findDeviceBoxById_user(Integer var1);

    public int findKYCountByMidAndType(@Param(value="sw_device_id") String var1, @Param(value="sr_box_type") String var2);

    public List<Tb_device_box> findDeviceBoxByDeviceIdForDefault(@Param(value="sw_device_id") String var1, @Param(value="sr_box_type") String var2);

    public List<Tb_device_box> findDeviceBoxByParam_user(@Param(value="sw_device_id") String var1, @Param(value="sr_box_type") String var2);

    public List<String> findBoardListByDeviceId(Tb_device_box var1);

    public List<Tb_device_box> findMaxAliasByBoardNo(Tb_device_box var1);

    public List<Tb_device_box> findMaxLockByBoardNo(Tb_device_box var1);

    public List<Tb_device_box> findMaxAliasByDeviceId(Tb_device_box var1);

    public int findCountByDeviceId(String var1);

    public int findCountByBoardAndLock(Tb_device_fittings var1);

    public Map<String, Object> findCountDeviceBoxByAgentId(Tb_device_box var1);

    public Map<String, Object> findCountDeviceBoxByNetArr(Tb_device_box var1);

    public List<Map<String, Object>> findListByAgentId(Tb_device_box var1);

    public List<Map<String, Object>> findListByNetArr(Tb_device_box var1);

    public int findCountDeviceBox(@Param(value="fi") Tb_statistics var1, @Param(value="sr_box_status") String var2);

    public List<Tb_device_box> findBoxListByWeb(Tb_device_box var1);
}

