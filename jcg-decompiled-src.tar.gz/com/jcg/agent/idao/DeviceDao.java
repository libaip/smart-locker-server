/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_device;
import com.jcg.common.model.Page;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface DeviceDao {
    public List<Tb_device> findDeviceByParam_agent(@Param(value="dev") Tb_device var1, @Param(value="page") Page var2);

    public int findCountByParam_agent(@Param(value="dev") Tb_device var1);

    public List<Tb_device> findDeviceByAgentId_agent(Integer var1);

    public Map<String, Object> findCountDeviceByAgentId_agent(Tb_device var1);

    public Map<String, Object> findCountDeviceOffLineByAgentId_agent(Tb_device var1);

    public int updateDeviceById_agent(@Param(value="up") Tb_device var1);

    public int updateDeviceInfoById_agent(@Param(value="up") Tb_device var1);

    public int updateDeviceInfoById_device(@Param(value="up") Tb_device var1);

    public int updateDeviceByStsId_agent(@Param(value="up") Tb_device var1);

    public Tb_device findDeviceDetailById_agent(String var1);

    public int updateAdSysnSign_agent(Tb_device var1);

    public List<Tb_device> findDeviceByArr_agent(@Param(value="deviceArr") String[] var1, @Param(value="si_goods_way") Integer var2, @Param(value="sw_agent_id") Integer var3, @Param(value="sr_is_ad") String var4, @Param(value="isConcatTemplate") String var5);

    public List<Tb_device> findDeviceListByAgentId_agent(Integer var1);

    public List<Map<String, Object>> findDropDownDeviceByAgentId_agent(Tb_device var1);

    public List<Tb_device> findDeviceByNetpoint_user(Integer var1);

    public int createDevice_cpy(@Param(value="dev") Tb_device var1);

    public Tb_device findDeviceMaxShortCodeByAgentId_cpy(@Param(value="sd_agent_id") Integer var1);

    public List<Tb_device> findAllDeviceMainboard_cpy();

    public List<Tb_device> findDeviceByNetArr_cpy(@Param(value="dev") Tb_device var1, @Param(value="page") Page var2);

    public int findCountByNetArr_cpy(@Param(value="dev") Tb_device var1);

    public List<Tb_device> findDeviceByParam_cpy(@Param(value="dev") Tb_device var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(@Param(value="dev") Tb_device var1);

    public List<Tb_device> findDeviceByPricesyncSign(Integer var1);

    public int updatePriceSyncSign(Tb_device var1);

    public List<Tb_device> getDevice_task(String var1);

    public Tb_device findDeviceByMid_app(String var1);

    public Tb_device findDeviceByMid(String var1);

    public List<String> findBoxTypeByDeviceId(String var1);

    public int findBoxCountByDeviceId(String var1);

    public Map<String, Object> findCountDeviceByNetArr_agent(Tb_device var1);

    public Map<String, Object> findCountDeviceOffLineByNetArr_agent(Tb_device var1);

    public List<Tb_device> findDeviceByNetArr_agent(@Param(value="dev") Tb_device var1, @Param(value="page") Page var2);

    public int findCountByNetArr_agent(@Param(value="dev") Tb_device var1);

    public Tb_device findDeviceByQrCode(String var1);

    public List<Tb_device> findDeviceByTask();

    public List<Tb_device> findDeviceByUserTask();

    public int updateDeviceTaskTime(String var1);

    public int updateDeviceUserTaskTime(String var1);

    public int updateStatusByTask(String var1);

    public Tb_device findDeviceDetailById_user(String var1);
}

