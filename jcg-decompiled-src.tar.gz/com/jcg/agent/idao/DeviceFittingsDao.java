/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_fittings
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_device_fittings;
import java.util.List;

public interface DeviceFittingsDao {
    public int findCountByBoardAndLock(Tb_device_fittings var1);

    public int createFittings(Tb_device_fittings var1);

    public List<Tb_device_fittings> findFittingsByBoxId(Tb_device_fittings var1);

    public int updateFittingsById(Tb_device_fittings var1);

    public int deleteFittingsById(Tb_device_fittings var1);

    public int selectMaxBoradNo(Tb_device_fittings var1);

    public int selectMaxLockNo(Tb_device_fittings var1);
}

