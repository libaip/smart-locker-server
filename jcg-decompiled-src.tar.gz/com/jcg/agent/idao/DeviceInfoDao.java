/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import org.apache.ibatis.annotations.Param;

public interface DeviceInfoDao {
    public int findDeviceInfo(@Param(value="sw_mid") String var1, @Param(value="si_door") Integer var2);
}

