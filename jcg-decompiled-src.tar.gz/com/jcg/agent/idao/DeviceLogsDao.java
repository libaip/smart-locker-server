/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_devicelogs
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_devicelogs;
import com.jcg.common.model.Page;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface DeviceLogsDao {
    public int createDeviceLogs(Tb_devicelogs var1);

    public Tb_devicelogs selectByPrimaryKey(String var1);

    public List<Tb_devicelogs> findDeviceLogsByParam(Tb_devicelogs var1);

    public List<Tb_devicelogs> findDeviceLogsByParam_agent(@Param(value="fi") Tb_devicelogs var1, @Param(value="page") Page var2);

    public int findCountByParam_agent(Tb_devicelogs var1);

    public List<Tb_devicelogs> findDeviceLogsByParam_agentmb(@Param(value="fi") Tb_devicelogs var1, @Param(value="page") Page var2);

    public int findCountByParam_agentmb(Tb_devicelogs var1);

    public int deleteDeviceLogs(String var1);

    public int findCountByNetArr_agent(Tb_devicelogs var1);

    public List<Tb_devicelogs> findDeviceLogsByNetArr_agentmb(@Param(value="fi") Tb_devicelogs var1, @Param(value="page") Page var2);

    public int findCountByNetArr_agentmb(Tb_devicelogs var1);

    public List<Tb_devicelogs> findNewDeviceLogsByParam_agentmb(@Param(value="fi") Tb_devicelogs var1, @Param(value="page") Page var2);

    public int findNewCountByParam_agentmb(Tb_devicelogs var1);

    public List<Tb_devicelogs> findNewDeviceLogsByNetArr_agentmb(@Param(value="fi") Tb_devicelogs var1, @Param(value="page") Page var2);

    public int findNewCountByNetArr_agentmb(Tb_devicelogs var1);

    public List<Map<String, Object>> findOfflineDevice(@Param(value="fi") Tb_devicelogs var1, @Param(value="page") Page var2);

    public int findCountOfflineDevice(@Param(value="fi") Tb_devicelogs var1);
}

