/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_package
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_device_package;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface DevicePackageDao {
    public int createDevicePackage(@Param(value="set") LinkedHashSet<Tb_device_package> var1);

    public List<Tb_device_package> findDevicePackageByDeviceId(Tb_device_package var1);

    public int findCountByParam(Tb_device_package var1);

    public int updateDevicePackageById(@Param(value="up") Tb_device_package var1);

    public int updateDevicePackageByBatch(@Param(value="up") Tb_device_package var1);

    public Tb_device_package findDevicePackageById(Integer var1);

    public List<Map<String, Object>> findDevicePackage_device(Tb_device_package var1);
}

