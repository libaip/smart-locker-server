/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_device_param;

public interface DeviceParamDao {
    public int createDeviceParam(Tb_device_param var1);

    public int findCountDeviceParam(Tb_device_param var1);
}

