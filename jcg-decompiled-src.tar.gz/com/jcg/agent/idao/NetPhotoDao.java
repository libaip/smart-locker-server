/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_net_photo
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_net_photo;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NetPhotoDao {
    public int createNetPhoto(@Param(value="ct") Tb_net_photo var1);

    public List<Tb_net_photo> findNetPhotoByNetId(@Param(value="sw_netpoint_id") Integer var1);

    public int updateNetPhotoById(@Param(value="up") Tb_net_photo var1);

    public int deleteNetPhotoById(@Param(value="sd_net_photo_id") String var1);

    public int createNetPhoto_cpy(Tb_net_photo var1);

    public List<Tb_net_photo> findNetPhotoByNetId_cpy(Integer var1);

    public int deleteNetPhotoById_cpy(String var1);
}

