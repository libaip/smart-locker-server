/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_netpoint
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_netpoint;
import com.jcg.common.model.Page;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface NetPointDao {
    public List<Tb_netpoint> findNetPointByParam_agent(@Param(value="np") Tb_netpoint var1, @Param(value="page") Page var2);

    public int findCountByParam_agent(@Param(value="np") Tb_netpoint var1);

    public Map<String, Object> findCountNetPointByAgentId_agent(Tb_netpoint var1);

    public Tb_netpoint findNetPointById_agent(Integer var1);

    public int updateNetPointById_agent(Tb_netpoint var1);

    public List<Map<String, Object>> findDropDownNetpointByAgentId_agent(Integer var1);

    public List<Map<String, Object>> findDropDownNetpointByAgentArr_agent(@Param(value="agentArr") String[] var1);

    public List<Tb_netpoint> findNetNameByArr(String[] var1);

    public int createNetPoint_cpy(Tb_netpoint var1);

    public List<Map<String, Object>> findAllNetpointByAreaCode_cpy(@Param(value="np") Tb_netpoint var1, @Param(value="sw_company_id") String var2);

    public List<Tb_netpoint> findNetPointByParam_cpy(@Param(value="np") Tb_netpoint var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(@Param(value="np") Tb_netpoint var1);

    public Tb_netpoint findNetPointById_user(Tb_netpoint var1);

    public List<Tb_netpoint> findNetpointByProv_user(@Param(value="np") Tb_netpoint var1, @Param(value="page") Page var2);

    public int findCountByProv_user(Tb_netpoint var1);

    public List<Tb_netpoint> findNetpointByAgentId_user(Integer var1);

    public Map<String, Object> findCountNetPointByNetArr_agent(Tb_netpoint var1);

    public List<Tb_netpoint> findNetPointByNetArr_agent(@Param(value="np") Tb_netpoint var1, @Param(value="page") Page var2);

    public int findCountByNetArr_agent(@Param(value="np") Tb_netpoint var1);

    public List<Map<String, Object>> findDropDownNetpointByNetArr_agent(@Param(value="netArr") String[] var1);

    public List<Map<String, Object>> findAllNetpointByAreaCode(@Param(value="np") Tb_netpoint var1, @Param(value="si_up_agent") Integer var2);

    public int updateModeTaskTime(Tb_netpoint var1);

    public List<Tb_netpoint> findNetpointByTask();
}

