/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_opendoor_record
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_opendoor_record;
import com.jcg.common.model.Page;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OpenDoorRecordDao {
    public List<Tb_opendoor_record> findOpenDoorRecordByParam_agent(@Param(value="fi") Tb_opendoor_record var1, @Param(value="page") Page var2);

    public int findCountByParam_agent(@Param(value="fi") Tb_opendoor_record var1);

    public int createOpenDoorRecord(Tb_opendoor_record var1);

    public List<Tb_opendoor_record> findOpenDoorRecordByOrder(String var1);

    public int deleteByDeviceId(String var1);
}

