/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_ordercash_stream
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_ordercash_stream;
import com.jcg.common.model.Page;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface OrderCashStreamDao {
    public int createOrderCashStream(Tb_ordercash_stream var1);

    public List<Tb_ordercash_stream> findOrderCashStreamByParam_agent(@Param(value="ocs") Tb_ordercash_stream var1, @Param(value="page") Page var2);

    public int findCountByParam_agent(@Param(value="ocs") Tb_ordercash_stream var1);

    public List<Tb_ordercash_stream> findShowOrderCashStreamByParam_agent(@Param(value="ocs") Tb_ordercash_stream var1, @Param(value="page") Page var2);

    public int findShowCountByParam_agent(@Param(value="ocs") Tb_ordercash_stream var1);

    public List<Tb_ordercash_stream> findOrderCashStreamByNetArr_agent(@Param(value="ocs") Tb_ordercash_stream var1, @Param(value="page") Page var2);

    public int findCountByNetArr_agent(@Param(value="ocs") Tb_ordercash_stream var1);

    public Tb_ordercash_stream findOrderCashStreamById(String var1);

    public int updateOrderCashStream(Tb_ordercash_stream var1);

    public List<Tb_ordercash_stream> findOrderCashStreamByParam_cpy(@Param(value="ocs") Tb_ordercash_stream var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(@Param(value="ocs") Tb_ordercash_stream var1);

    public List<Tb_ordercash_stream> findOrderCashStreamByOrderId(String var1);

    public Map<String, Object> findPayInfoGroupByParam(@Param(value="ocs") Tb_ordercash_stream var1);

    public int deleteByDeviceId(String var1);

    public List<Tb_ordercash_stream> findOrderCashStreamByParam(@Param(value="ocs") Tb_ordercash_stream var1, @Param(value="page") Page var2);

    public Tb_ordercash_stream findCashTypeByOrderId(String var1);

    public List<Tb_ordercash_stream> findOrderCashStreamByOrder_cpy(String var1);

    public Tb_ordercash_stream findOrderCashStreamByWxOrder(String var1);
}

