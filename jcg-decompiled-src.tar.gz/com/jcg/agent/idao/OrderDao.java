/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_netpoint
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_netpoint;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.model.Tb_statistics;
import com.jcg.common.model.Page;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface OrderDao {
    public Map<String, Object> findCountShopUserByAgentId_agent(@Param(value="order") Tb_order var1, @Param(value="todayZero") String var2, @Param(value="todayEnd") String var3);

    public Map<String, Object> findCountOrderByAgentId_agent(@Param(value="order") Tb_order var1, @Param(value="cashType") String var2, @Param(value="todayZero") String var3, @Param(value="todayEnd") String var4);

    public Map<String, Object> findOrderMoneyByAgentId_agent(@Param(value="order") Tb_order var1, @Param(value="cashType") String var2, @Param(value="todayZero") String var3, @Param(value="todayEnd") String var4);

    public List<Tb_order> findOrderByParam_agent(@Param(value="order") Tb_order var1, @Param(value="page") Page var2);

    public int findCountByParam_agent(@Param(value="order") Tb_order var1);

    public List<Tb_order> findShowOrderByParam_agent(@Param(value="order") Tb_order var1, @Param(value="page") Page var2);

    public int findShowCountByParam_agent(@Param(value="order") Tb_order var1);

    public Tb_order findOrderById_agent(String var1);

    public Map<String, Object> findOrderGroupByParam(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findAdOrderGroupByParam(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findShowOrderGroupByParam(@Param(value="fi") Tb_order var1);

    public List<Tb_order> findPayInfoGroupByParam(@Param(value="fi") Tb_order var1);

    public int updateOrder(Tb_order var1);

    public int updateOrder_agent(Tb_order var1);

    public List<Tb_order> findOrderByParam_cpy(@Param(value="order") Tb_order var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(@Param(value="order") Tb_order var1);

    public int updateDepositRefund(Tb_order var1);

    public int createOrder(Tb_order var1);

    public List<Tb_order> findOrderByParam_user(@Param(value="fi") Tb_order var1, @Param(value="page") Page var2);

    public int findCountByParam_user(Tb_order var1);

    public Tb_order findOrderById_user(String var1);

    public Tb_order findOrderById_finish(String var1);

    public List<Tb_order> findOrderByPwd(Tb_order var1);

    public List<Tb_agent> getAllAgent_task();

    public List<Map<String, String>> getOnlineOrder_task(String var1);

    public List<Map<String, String>> getuserCount_task(String var1);

    public List<Map<String, String>> getuserRegcount_task(String var1);

    public List<Map<String, String>> getTkMoney_task(String var1);

    public int updateStatus_task(Map<String, String> var1);

    public Tb_order findNewestOrderByBox(Integer var1);

    public List<Tb_order> findOrderByUser(Tb_order var1);

    public Map<String, Object> findOrderGroupByNetArr(@Param(value="fi") Tb_order var1);

    public List<Tb_order> findOrderByNetArr_agent(@Param(value="order") Tb_order var1, @Param(value="page") Page var2);

    public int findCountByNetArr_agent(@Param(value="order") Tb_order var1);

    public List<Map<String, String>> getOnlineOrderByParam_task(@Param(value="sr_date_start") String var1, @Param(value="sr_date_end") String var2, @Param(value="sw_agent_id") Integer var3);

    public List<Map<String, String>> getCountOrderByParam_task(@Param(value="sr_date_start") String var1, @Param(value="sr_date_end") String var2, @Param(value="sw_agent_id") Integer var3);

    public List<Map<String, String>> getUserRegcountByParam_task(@Param(value="sr_date_start") String var1, @Param(value="sr_date_end") String var2, @Param(value="sw_agent_id") Integer var3);

    public List<Tb_order> findStealOrderByParam(Tb_order var1);

    public Map<String, Object> findOrderByNetId(@Param(value="sd_netpoint_id") Integer var1, @Param(value="today") String var2);

    public int findCountOrderByNetId(@Param(value="sd_netpoint_id") Integer var1, @Param(value="today") String var2);

    public Tb_order findOrderByLast(Tb_order var1);

    public Tb_order findLastOrderByUser(Integer var1);

    public Map<String, Object> findSumDepositRefund(String var1);

    public List<Tb_order> findDepositRefundByUserId(Integer var1);

    public List<Tb_order> findDepositRefundByUserId_New(Integer var1);

    public int deleteByDeviceId(String var1);

    public int updatePizhuById(String var1);

    public int updateLastPizhu(Integer var1);

    public List<Tb_order> findPizhuOrderByUser(Tb_order var1);

    public Tb_order findPizhuOrderByUserId(Integer var1);

    public List<Map<String, Object>> findDateApplMoneyByParam(Tb_statistics var1);

    public List<Map<String, Object>> findDateAdMoneyByParam(Tb_statistics var1);

    public List<Map<String, Object>> findDateUpAdMoneyByParam(Tb_statistics var1);

    public List<Tb_order> findOrderByTask(String var1);

    public List<Tb_order> findOrderByUserTask(String var1);

    public BigDecimal findSumMoneyByArr(@Param(value="orderArr") String[] var1);

    public Map<String, Object> findAllDepositByAgentId(@Param(value="sw_agent_id") Integer var1, @Param(value="nowDate") String var2);

    public int findAllCountDepositByAgentId(@Param(value="sw_agent_id") Integer var1, @Param(value="nowDate") String var2);

    public Map<String, Object> findDepositByAgentId(@Param(value="sw_agent_id") Integer var1, @Param(value="sr_checked") String var2, @Param(value="nowDate") String var3);

    public Tb_order findStartOrderByX(@Param(value="sw_agent_id") Integer var1, @Param(value="sr_checked") String var2, @Param(value="nowDate") String var3);

    public Tb_order findEndOrderByX(@Param(value="sw_agent_id") Integer var1, @Param(value="sr_checked") String var2, @Param(value="nowDate") String var3);

    public List<String> findDepositListByAgentId(@Param(value="sw_agent_id") Integer var1, @Param(value="sr_checked") String var2, @Param(value="nowDate") String var3);

    public int updateChecked(@Param(value="arr") String[] var1, @Param(value="old_status") String var2, @Param(value="new_status") String var3);

    public List<Tb_order> findOrderByPass(Tb_order var1);

    public List<Tb_order> findOrderByMid(Tb_order var1);

    public int findCountStealByParam(Tb_order var1);

    public int findCountByToday(Tb_order var1);

    public int findTodayCountByNetId(Tb_order var1);

    public int findTodayAdCountByNetId(Tb_order var1);

    public int findTodayUpAdCountByNetId(Tb_order var1);

    public List<Tb_order> findOrderByParam_web(@Param(value="order") Tb_order var1);

    public Map<String, Object> findAdCashByAgentId(@Param(value="sw_agent_id") Integer var1, @Param(value="sr_date") String var2);

    public Map<String, Object> findUpAdCashByAgentId(@Param(value="sw_agent_id") Integer var1, @Param(value="sr_is_show") String var2, @Param(value="sr_date") String var3);

    public List<Tb_order> checkTodayOrder(Tb_order var1);

    public int findCountOrderByAd(Tb_order var1);

    public BigDecimal findNowMonthAdMoney(@Param(value="sw_agent_id") Integer var1, @Param(value="start_day") String var2, @Param(value="end_day") String var3);

    public BigDecimal findShowNowMonthAdMoney(@Param(value="agentArr") String[] var1, @Param(value="start_day") String var2, @Param(value="end_day") String var3);

    public int updateDeviceBoxByWeb(Tb_order var1);

    public int updateGoOrder(Tb_order var1);

    public int updateOrderPhone(Tb_order var1);

    public List<String> findAdOrderByTask(Integer var1);

    public int updateAdMoneyByIdArr(@Param(value="dc_ad_money") BigDecimal var1, @Param(value="idArr") String[] var2);

    public int findCountDeposit(@Param(value="sw_agent_id") Integer var1, @Param(value="start_day") String var2, @Param(value="end_day") String var3);

    public Tb_order findLastOrderByUser_wtx(Integer var1);

    public Tb_order findLastOrderByUser_wtx2(Integer var1);

    public Tb_order findMaxClickOrderByUser_wtx(Integer var1);

    public Tb_order findMaxClickOrderByUser_wtx2(Integer var1);

    public int findCountOrderByUser_wtx(Integer var1);

    public int findCountOrderByUser_wtx2(Integer var1);

    public int findCountOrderByNetParam(Tb_order var1);

    public int findAllOrderByNetId(Tb_order var1);

    public int findSuccessOrderByNetId(Tb_order var1);

    public int findAllOrderByNetId_task(Tb_order var1);

    public int findSuccessOrderByNetId_task(Tb_order var1);

    public int findMoreClickSuccessOrderByNetId(Tb_order var1);

    public int updateOrderClick(Tb_order var1);

    public List<Integer> findUserListByModeTask(Integer var1);

    public Tb_netpoint findNewOrderForNetpoint(@Param(value="orderArr") String[] var1);

    public Tb_netpoint findNewOrderForNetpoint_user(Integer var1);

    public List<Tb_order> findOrderByArr(@Param(value="orderArr") String[] var1);

    public int findCountDepositRefundByOrderArr(@Param(value="orderArr") String[] var1);

    public Map<String, Object> findAdCountByParam(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findUpAdCountByParam(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findAdCountByParam_cpy(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findCountRefundByParam(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findAdCountByNetArr(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findUpAdCountByNetArr(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findCountRefundByArr(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findAdCountByAgentArr(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findUpAdCountByAgentArr(@Param(value="fi") Tb_order var1);

    public Map<String, Object> findDefaultCountByAgentArr(@Param(value="fi") Tb_order var1);

    public List<Map<String, Object>> findNetListByNetArr(Tb_order var1);

    public List<Map<String, Object>> findNetListByAgentId(Tb_order var1);

    public String findLastStealByDevice(Tb_order var1);

    public List<Map<String, Object>> findDateAdCountByParam(Tb_statistics var1);

    public List<Map<String, Object>> findUserCntByParam(Tb_statistics var1);

    public Map<String, Object> findUserSumByParam(@Param(value="fi") Tb_order var1);
}

