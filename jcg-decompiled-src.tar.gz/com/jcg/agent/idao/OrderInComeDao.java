/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.agent.model.Tb_order_income
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_order;
import com.jcg.agent.model.Tb_order_income;
import java.math.BigDecimal;
import org.apache.ibatis.annotations.Param;

public interface OrderInComeDao {
    public int createOrderIncome(Tb_order_income var1);

    public Tb_order_income findIncomeByOrderId(String var1);

    public int updateById(Tb_order_income var1);

    public int deleteByDeviceId(String var1);

    public BigDecimal findAgentMoneySum(@Param(value="fi") Tb_order var1);

    public BigDecimal findShopMoneySum(@Param(value="fi") Tb_order var1);

    public BigDecimal findShopMoneySumByNetArr(@Param(value="fi") Tb_order var1);
}

