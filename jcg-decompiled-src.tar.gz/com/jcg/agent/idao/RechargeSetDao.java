/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_recharge_set
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_recharge_set;
import java.util.List;

public interface RechargeSetDao {
    public List<Tb_recharge_set> findRechargeSetByParam(Tb_recharge_set var1);

    public int updateRechargeSet(Tb_recharge_set var1);

    public List<Tb_recharge_set> findZsRechargeSetByAgentId(Tb_recharge_set var1);

    public int createRechargeSet_agent(Tb_recharge_set var1);

    public int deleteRechargeSet(Integer var1);

    public Tb_recharge_set findCBJRechargeSetByAgentId(Integer var1);

    public List<Tb_recharge_set> findRechargeSetByAgentId_user(Tb_recharge_set var1);

    public List<Tb_recharge_set> findTaskRechargeSet(String var1);

    public Tb_recharge_set findUserTaskRechargeSet(String var1);
}

