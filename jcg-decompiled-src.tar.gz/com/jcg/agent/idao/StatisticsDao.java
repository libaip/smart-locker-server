/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_statistics;
import com.jcg.common.model.Page;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface StatisticsDao {
    public Map<String, Object> findSumStatisticsByParam_agent(Tb_statistics var1);

    public Map<String, Object> findSumStatisticsByNetArr_agent(Tb_statistics var1);

    public Map<String, Object> findSumStatisticsByArr_agent(Tb_statistics var1);

    public void createStatistics(Tb_statistics var1);

    public List<Tb_statistics> findOnlineOrderDataByParam(Tb_statistics var1);

    public List<Tb_statistics> findOnlineOrderDataByParam_cpy(Tb_statistics var1);

    public List<Tb_statistics> findShowOnlineOrderDataByParam(Tb_statistics var1);

    public Map<String, Object> findCountOrderUserByParam(Tb_statistics var1);

    public List<Tb_statistics> findUserRegistRptByParam_agent(@Param(value="fi") Tb_statistics var1);

    public int deleteByParam(Tb_statistics var1);

    public int createStatisticsList(List<Tb_statistics> var1);

    public List<Map<String, Object>> findDepositRateByNet(@Param(value="fi") Tb_statistics var1, @Param(value="page") Page var2);

    public int findCountDepositRateByNet(@Param(value="fi") Tb_statistics var1);

    public Map<String, Object> findAdCountByParam(@Param(value="fi") Tb_statistics var1);

    public Map<String, Object> findCountRefundByParam(@Param(value="fi") Tb_statistics var1);

    public List<Tb_statistics> findAdOrderDataByParam(Tb_statistics var1);

    public List<Tb_statistics> findRefundOrderDataByParam(Tb_statistics var1);

    public List<Tb_statistics> findUserCntByParam(Tb_statistics var1);

    public Map<String, Object> findUserSumByParam(Tb_statistics var1);
}

