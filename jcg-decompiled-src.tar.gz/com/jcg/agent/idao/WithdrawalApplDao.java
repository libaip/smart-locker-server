/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_withdrawal_appl
 *  com.jcg.common.model.Page
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.agent.idao;

import com.jcg.agent.model.Tb_withdrawal_appl;
import com.jcg.common.model.Page;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface WithdrawalApplDao {
    public int createWithdrawalAppl(Tb_withdrawal_appl var1);

    public List<Tb_withdrawal_appl> findWithdrawalApplByParam_agent(@Param(value="fi") Tb_withdrawal_appl var1, @Param(value="page") Page var2);

    public int findCountByParam_agent(Tb_withdrawal_appl var1);

    public List<Tb_withdrawal_appl> findWithdrawalApplByParam(Tb_withdrawal_appl var1);

    public Tb_withdrawal_appl findWithdrawalApplById(Integer var1);

    public List<Tb_withdrawal_appl> findWithdrawalApplByParam_cpy(@Param(value="fi") Tb_withdrawal_appl var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(Tb_withdrawal_appl var1);

    public int updateWithdrawalAppl_cpy(Tb_withdrawal_appl var1);

    public List<Tb_withdrawal_appl> findTodayWithdrawalAppl(Tb_withdrawal_appl var1);

    public Tb_withdrawal_appl findLastWXWithdrawalAppl(Tb_withdrawal_appl var1);

    public List<Tb_withdrawal_appl> findAllWithdrawalApplByParam_cpy(@Param(value="fi") Tb_withdrawal_appl var1);
}

