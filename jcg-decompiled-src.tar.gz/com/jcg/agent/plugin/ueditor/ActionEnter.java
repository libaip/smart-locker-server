/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.servlet.http.HttpServletRequest
 */
package com.jcg.agent.plugin.ueditor;

import com.jcg.agent.plugin.ueditor.ConfigManager;
import com.jcg.agent.plugin.ueditor.define.ActionMap;
import com.jcg.agent.plugin.ueditor.define.BaseState;
import com.jcg.agent.plugin.ueditor.define.State;
import com.jcg.agent.plugin.ueditor.hunter.FileManager;
import com.jcg.agent.plugin.ueditor.hunter.ImageHunter;
import com.jcg.agent.plugin.ueditor.upload.Uploader;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public class ActionEnter {
    private HttpServletRequest request = null;
    private String rootPath = null;
    private String realPath = null;
    private String contextPath = null;
    private String actionType = null;
    private int agentId;
    private ConfigManager configManager = null;

    public ActionEnter(HttpServletRequest request, String rootPath, String realPath) {
        this.request = request;
        this.rootPath = rootPath;
        this.realPath = realPath;
        this.actionType = request.getParameter("action");
        if (request.getParameter("agentId") != null) {
            this.agentId = Integer.valueOf(request.getParameter("agentId"));
        }
        this.contextPath = request.getContextPath();
        this.configManager = ConfigManager.getInstance(this.rootPath, this.realPath, this.contextPath, request.getRequestURI());
    }

    public String exec() {
        String callbackName = this.request.getParameter("callback");
        if (callbackName != null) {
            if (!this.validCallbackName(callbackName)) {
                return new BaseState(false, 401).toJSONString();
            }
            return callbackName + "(" + this.invoke() + ");";
        }
        return this.invoke();
    }

    public String invoke() {
        if (this.actionType == null || !ActionMap.mapping.containsKey(this.actionType)) {
            return new BaseState(false, 101).toJSONString();
        }
        if (this.configManager == null || !this.configManager.valid()) {
            return new BaseState(false, 102).toJSONString();
        }
        State state = null;
        int actionCode = ActionMap.getType(this.actionType);
        int agentId = this.agentId;
        Map<String, Object> conf = null;
        switch (actionCode) {
            case 0: {
                return this.configManager.getAllConfig().toString();
            }
            case 1: 
            case 2: 
            case 3: 
            case 4: {
                conf = this.configManager.getConfig(actionCode, agentId);
                state = new Uploader(this.request, conf).doExec();
                break;
            }
            case 5: {
                conf = this.configManager.getConfig(actionCode, agentId);
                String[] list = this.request.getParameterValues((String)conf.get("fieldName"));
                state = new ImageHunter(conf).capture(list);
                break;
            }
            case 6: 
            case 7: {
                conf = this.configManager.getConfig(actionCode, agentId);
                int start = this.getStartIndex();
                state = new FileManager(conf).listFile(start);
            }
        }
        return state.toJSONString();
    }

    public int getStartIndex() {
        String start = this.request.getParameter("start");
        try {
            return Integer.parseInt(start);
        }
        catch (Exception e) {
            return 0;
        }
    }

    public boolean validCallbackName(String name) {
        return name.matches("^[a-zA-Z_]+[\\w0-9_]*$");
    }
}

