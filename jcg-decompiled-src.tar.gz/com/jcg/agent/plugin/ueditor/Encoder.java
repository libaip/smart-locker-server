/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.agent.plugin.ueditor;

public class Encoder {
    public static String toUnicode(String input) {
        char[] chars;
        StringBuilder builder = new StringBuilder();
        for (char ch : chars = input.toCharArray()) {
            if (ch < '\u0100') {
                builder.append(ch);
                continue;
            }
            builder.append("\\u" + Integer.toHexString(ch & 0xFFFF));
        }
        return builder.toString();
    }
}

