/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.agent.plugin.ueditor.define;

public enum ActionState {
    UNKNOW_ERROR;

}

