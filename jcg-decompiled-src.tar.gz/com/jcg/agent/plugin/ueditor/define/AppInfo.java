/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.agent.plugin.ueditor.define;

import java.util.HashMap;
import java.util.Map;

public final class AppInfo {
    public static final int SUCCESS = 0;
    public static final int MAX_SIZE = 1;
    public static final int PERMISSION_DENIED = 2;
    public static final int FAILED_CREATE_FILE = 3;
    public static final int IO_ERROR = 4;
    public static final int NOT_MULTIPART_CONTENT = 5;
    public static final int PARSE_REQUEST_ERROR = 6;
    public static final int NOTFOUND_UPLOAD_DATA = 7;
    public static final int NOT_ALLOW_FILE_TYPE = 8;
    public static final int INVALID_ACTION = 101;
    public static final int CONFIG_ERROR = 102;
    public static final int PREVENT_HOST = 201;
    public static final int CONNECTION_ERROR = 202;
    public static final int REMOTE_FAIL = 203;
    public static final int NOT_DIRECTORY = 301;
    public static final int NOT_EXIST = 302;
    public static final int ILLEGAL = 401;
    public static Map<Integer, String> info = new HashMap<Integer, String>(){
        {
            this.put(0, "SUCCESS");
            this.put(101, "\u65e0\u6548\u7684Action");
            this.put(102, "\u914d\u7f6e\u6587\u4ef6\u521d\u59cb\u5316\u5931\u8d25");
            this.put(203, "\u6293\u53d6\u8fdc\u7a0b\u56fe\u7247\u5931\u8d25");
            this.put(201, "\u88ab\u963b\u6b62\u7684\u8fdc\u7a0b\u4e3b\u673a");
            this.put(202, "\u8fdc\u7a0b\u8fde\u63a5\u51fa\u9519");
            this.put(1, "\u6587\u4ef6\u5927\u5c0f\u8d85\u51fa\u9650\u5236");
            this.put(2, "\u6743\u9650\u4e0d\u8db3");
            this.put(3, "\u521b\u5efa\u6587\u4ef6\u5931\u8d25");
            this.put(4, "IO\u9519\u8bef");
            this.put(5, "\u4e0a\u4f20\u8868\u5355\u4e0d\u662fmultipart/form-data\u7c7b\u578b");
            this.put(6, "\u89e3\u6790\u4e0a\u4f20\u8868\u5355\u9519\u8bef");
            this.put(7, "\u672a\u627e\u5230\u4e0a\u4f20\u6570\u636e");
            this.put(8, "\u4e0d\u5141\u8bb8\u7684\u6587\u4ef6\u7c7b\u578b");
            this.put(301, "\u6307\u5b9a\u8def\u5f84\u4e0d\u662f\u76ee\u5f55");
            this.put(302, "\u6307\u5b9a\u8def\u5f84\u5e76\u4e0d\u5b58\u5728");
            this.put(401, "Callback\u53c2\u6570\u540d\u4e0d\u5408\u6cd5");
        }
    };

    public static String getStateInfo(int key) {
        return info.get(key);
    }
}

