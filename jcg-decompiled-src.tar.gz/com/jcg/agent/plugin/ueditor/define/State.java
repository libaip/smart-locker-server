/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.agent.plugin.ueditor.define;

public interface State {
    public boolean isSuccess();

    public void putInfo(String var1, String var2);

    public void putInfo(String var1, long var2);

    public String toJSONString();
}

