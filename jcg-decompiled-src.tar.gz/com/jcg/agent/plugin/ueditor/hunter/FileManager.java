/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.agent.plugin.ueditor.hunter;

import com.jcg.agent.common.OSSClient;
import com.jcg.agent.plugin.ueditor.PathFormat;
import com.jcg.agent.plugin.ueditor.define.BaseState;
import com.jcg.agent.plugin.ueditor.define.MultiState;
import com.jcg.agent.plugin.ueditor.define.State;
import java.io.File;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;

public class FileManager {
    private String dir = null;
    private String rootPath = null;
    private String realPath = null;
    private String[] allowFiles = null;
    private int count = 0;

    public FileManager(Map<String, Object> conf) {
        this.realPath = (String)conf.get("realPath");
        this.dir = (String)conf.get("dir");
        this.allowFiles = this.getAllowFiles(conf.get("allowFiles"));
        this.count = (Integer)conf.get("count");
    }

    public State listFile(int index) {
        File dir = new File(this.dir);
        State state = null;
        Collection<File> list = OSSClient.listFile(this.dir);
        if (index < 0 || index > list.size()) {
            state = new MultiState(true);
        } else {
            Object[] fileList = Arrays.copyOfRange(list.toArray(), index, index + this.count);
            state = this.getState(fileList);
        }
        state.putInfo("start", index);
        state.putInfo("total", list.size());
        return state;
    }

    private State getState(Object[] files) {
        MultiState state = new MultiState(true);
        BaseState fileState = null;
        File file = null;
        for (Object obj : files) {
            if (obj == null) break;
            file = (File)obj;
            fileState = new BaseState(true);
            fileState.putInfo("url", PathFormat.format(this.getPath(file)));
            state.addState(fileState);
        }
        return state;
    }

    private String getPath(File file) {
        String path = file.getPath();
        return path;
    }

    private String[] getAllowFiles(Object fileExt) {
        String[] exts = null;
        String ext = null;
        if (fileExt == null) {
            return new String[0];
        }
        exts = (String[])fileExt;
        int len = exts.length;
        for (int i = 0; i < len; ++i) {
            ext = exts[i];
            exts[i] = ext.replace(".", "");
        }
        return exts;
    }
}

