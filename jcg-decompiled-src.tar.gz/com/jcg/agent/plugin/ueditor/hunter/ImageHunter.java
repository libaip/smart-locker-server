/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.XcbConstantValue
 */
package com.jcg.agent.plugin.ueditor.hunter;

import com.jcg.agent.plugin.ueditor.PathFormat;
import com.jcg.agent.plugin.ueditor.define.BaseState;
import com.jcg.agent.plugin.ueditor.define.MIMEType;
import com.jcg.agent.plugin.ueditor.define.MultiState;
import com.jcg.agent.plugin.ueditor.define.State;
import com.jcg.agent.plugin.ueditor.upload.StorageManager;
import com.jcg.common.model.XcbConstantValue;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ImageHunter {
    private String filename = null;
    private String savePath = null;
    private String rootPath = null;
    private String realPath = null;
    private List<String> allowTypes = null;
    private long maxSize = -1L;
    private List<String> filters = null;

    public ImageHunter(Map<String, Object> conf) {
        this.filename = (String)conf.get("filename");
        this.savePath = (String)conf.get("savePath");
        this.rootPath = (String)conf.get("rootPath");
        this.realPath = (String)conf.get("realPath");
        this.maxSize = (Long)conf.get("maxSize");
        this.allowTypes = Arrays.asList((String[])conf.get("allowFiles"));
        this.filters = Arrays.asList((String[])conf.get("filter"));
    }

    public State capture(String[] list) {
        MultiState state = new MultiState(true);
        for (String source : list) {
            state.addState(this.captureRemoteData(source));
        }
        return state;
    }

    public State captureRemoteData(String urlStr) {
        HttpURLConnection connection = null;
        URL url = null;
        String suffix = null;
        try {
            url = new URL(urlStr);
            if (!this.validHost(url.getHost())) {
                return new BaseState(false, 201);
            }
            connection = (HttpURLConnection)url.openConnection();
            connection.setInstanceFollowRedirects(true);
            connection.setUseCaches(true);
            if (!this.validContentState(connection.getResponseCode())) {
                return new BaseState(false, 202);
            }
            suffix = MIMEType.getSuffix(connection.getContentType());
            if (!this.validFileType(suffix)) {
                return new BaseState(false, 8);
            }
            if (!this.validFileSize(connection.getContentLength())) {
                return new BaseState(false, 1);
            }
            suffix = UUID.randomUUID() + suffix;
            String savePath = this.getPath(this.savePath, this.filename, suffix);
            String physicalPath = this.realPath + savePath;
            State state = StorageManager.saveFileByInputStream(connection.getInputStream(), physicalPath);
            if (state.isSuccess()) {
                state.putInfo("url", PathFormat.format(XcbConstantValue.server_host + savePath));
                state.putInfo("source", urlStr);
            }
            return state;
        }
        catch (Exception e) {
            return new BaseState(false, 203);
        }
    }

    private String getPath(String savePath, String filename, String suffix) {
        return PathFormat.parse(savePath + suffix, filename);
    }

    private boolean validHost(String hostname) {
        try {
            InetAddress ip = InetAddress.getByName(hostname);
            if (ip.isSiteLocalAddress()) {
                return false;
            }
        }
        catch (UnknownHostException e) {
            return false;
        }
        return !this.filters.contains(hostname);
    }

    private boolean validContentState(int code) {
        return 200 == code;
    }

    private boolean validFileType(String type) {
        return this.allowTypes.contains(type);
    }

    private boolean validFileSize(int size) {
        return (long)size < this.maxSize;
    }
}

