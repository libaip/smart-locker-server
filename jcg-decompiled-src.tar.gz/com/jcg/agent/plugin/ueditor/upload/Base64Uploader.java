/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.codec.binary.Base64
 */
package com.jcg.agent.plugin.ueditor.upload;

import com.jcg.agent.plugin.ueditor.PathFormat;
import com.jcg.agent.plugin.ueditor.define.BaseState;
import com.jcg.agent.plugin.ueditor.define.FileType;
import com.jcg.agent.plugin.ueditor.define.State;
import com.jcg.agent.plugin.ueditor.upload.StorageManager;
import java.util.Map;
import org.apache.commons.codec.binary.Base64;

public final class Base64Uploader {
    public static State save(String content, Map<String, Object> conf) {
        long maxSize;
        byte[] data = Base64Uploader.decode(content);
        if (!Base64Uploader.validSize(data, maxSize = ((Long)conf.get("maxSize")).longValue())) {
            return new BaseState(false, 1);
        }
        String suffix = FileType.getSuffix("JPG");
        String savePath = PathFormat.parse((String)conf.get("savePath"), (String)conf.get("filename"));
        savePath = savePath + suffix;
        String physicalPath = (String)conf.get("rootPath") + savePath;
        State storageState = StorageManager.saveBinaryFile(data, physicalPath);
        if (storageState.isSuccess()) {
            storageState.putInfo("url", PathFormat.format(savePath));
            storageState.putInfo("type", suffix);
            storageState.putInfo("original", "");
        }
        return storageState;
    }

    private static byte[] decode(String content) {
        return Base64.decodeBase64((String)content);
    }

    private static boolean validSize(byte[] data, long length) {
        return (long)data.length <= length;
    }
}

