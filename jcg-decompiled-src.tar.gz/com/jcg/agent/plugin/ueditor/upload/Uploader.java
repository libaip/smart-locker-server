/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.servlet.http.HttpServletRequest
 */
package com.jcg.agent.plugin.ueditor.upload;

import com.jcg.agent.plugin.ueditor.define.State;
import com.jcg.agent.plugin.ueditor.upload.Base64Uploader;
import com.jcg.agent.plugin.ueditor.upload.BinaryUploader;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public class Uploader {
    private HttpServletRequest request = null;
    private Map<String, Object> conf = null;

    public Uploader(HttpServletRequest request, Map<String, Object> conf) {
        this.request = request;
        this.conf = conf;
    }

    public final State doExec() {
        String filedName = (String)this.conf.get("fieldName");
        State state = null;
        state = "true".equals(this.conf.get("isBase64")) ? Base64Uploader.save(this.request.getParameter(filedName), this.conf) : BinaryUploader.save(this.request, this.conf);
        return state;
    }
}

