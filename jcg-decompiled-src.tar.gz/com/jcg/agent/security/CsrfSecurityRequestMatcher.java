/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.security.web.util.matcher.RequestMatcher
 */
package com.jcg.agent.security;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import org.springframework.security.web.util.matcher.RequestMatcher;

public class CsrfSecurityRequestMatcher
implements RequestMatcher {
    private Pattern allowedMethods = Pattern.compile("^(GET|HEAD|TRACE|OPTIONS)$");
    private List<String> execludeUrls = new ArrayList<String>();

    public boolean matches(HttpServletRequest request) {
        if (this.execludeUrls != null && this.execludeUrls.size() > 0) {
            String servletPath = request.getServletPath();
            for (String url : this.execludeUrls) {
                if (!servletPath.contains(url)) continue;
                return false;
            }
        }
        return !this.allowedMethods.matcher(request.getMethod()).matches();
    }

    public List<String> getExecludeUrls() {
        return this.execludeUrls;
    }

    public void setExecludeUrls(List<String> execludeUrls) {
        this.execludeUrls = execludeUrls;
    }
}

