/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.security.core.authority.SimpleGrantedAuthority
 *  org.springframework.security.core.userdetails.UserDetailsService
 *  org.springframework.security.core.userdetails.UsernameNotFoundException
 */
package com.jcg.agent.security.service;

import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.service.AgentServiceImpl;
import com.jcg.common.model.XcbConstantValue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class JwtUserDetailsServiceImpl
implements UserDetailsService {
    AgentServiceImpl agentService = new AgentServiceImpl();

    public Tb_agent loadUserByUsername(String username) throws UsernameNotFoundException {
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("username", username);
        Tb_agent agent = null;
        try {
            Map<String, Object> resMap = this.agentService.findbyUserName(username);
            if (XcbConstantValue.OPERA_SUCCESS.equals(resMap.get(XcbConstantValue.STATUS))) {
                agent = (Tb_agent)resMap.get(XcbConstantValue.DATA);
            }
            if (agent != null) {
                ArrayList<SimpleGrantedAuthority> authList = new ArrayList<SimpleGrantedAuthority>();
                authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
                agent.setUserInfoRoles(authList);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return agent;
    }
}

