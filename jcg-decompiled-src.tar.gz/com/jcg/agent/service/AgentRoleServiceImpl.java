/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent_authorities
 *  com.jcg.agent.model.Tb_agent_roles
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.agent.model.Tb_agent_authorities;
import com.jcg.agent.model.Tb_agent_roles;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class AgentRoleServiceImpl
extends BaseService {
    public Map<String, Object> createRole(Identifier identifier, Tb_agent_roles role) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_ROLE_CREATE);
        HashMap<String, Tb_agent_roles> param = new HashMap<String, Tb_agent_roles>();
        param.put("role", role);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findRoleByParam(Identifier identifier, Tb_agent_roles role, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_ROLE_FIND_BYPARAM);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("role", role);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findRoleById(Identifier identifier, String sd_roles_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_ROLE_FIND_BYID);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_roles_id", sd_roles_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateRoleById(Identifier identifier, Tb_agent_roles role) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_ROLE_UPDATE_BYID);
        HashMap<String, Tb_agent_roles> param = new HashMap<String, Tb_agent_roles>();
        param.put("role", role);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> deleteRoleById(Identifier identifier, String sd_roles_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_ROLE_DELETE_BYID);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_roles_id", sd_roles_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findRoleAuthById(Identifier identifier, String sd_roles_id, String sr_is_app) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_ROLE_AUTH_FIND_BYID);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_roles_id", sd_roles_id);
        param.put("sr_is_app", sr_is_app);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateRoleAuthById(Identifier identifier, String sd_roles_id, String[] authArr, String[] netArr) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_ROLE_AUTH_UPDATE_BYROLEID);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("sd_roles_id", sd_roles_id);
        param.put("authArr", authArr);
        param.put("netArr", netArr);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createAuth(Identifier identifier, Tb_agent_authorities auth) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_AUTH_CREATE);
        HashMap<String, Tb_agent_authorities> param = new HashMap<String, Tb_agent_authorities>();
        param.put("auth", auth);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAuthById(Identifier identifier, Tb_agent_authorities auth) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_AUTH_UPDATE);
        HashMap<String, Tb_agent_authorities> param = new HashMap<String, Tb_agent_authorities>();
        param.put("auth", auth);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> delAuthById(Identifier identifier, Integer sd_authority_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_AUTH_DELETE);
        HashMap<String, Integer> param = new HashMap<String, Integer>();
        param.put("sd_authority_id", sd_authority_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> batchDeleteById(Identifier identifier, String[] authArr) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_AUTH_BATCH_DELETE);
        HashMap<String, String[]> param = new HashMap<String, String[]>();
        param.put("authArr", authArr);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

