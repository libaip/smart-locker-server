/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.vo.LoginUser;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AgentServiceImpl
extends BaseService {
    public Map<String, Object> createShop(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_CREATE_SHOP);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createRole(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_CREATE_ROLE);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAgentByParam(Identifier identifier, Tb_agent agent, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_BYPARAM);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("agent", agent);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> deleteAgentById(Identifier identifier, String sd_agent_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_DELETE);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_agent_id", sd_agent_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllUserByAgentId(Identifier identifier, Tb_agent agent, Page page) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_ALL_USER_BYAGENT);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("agent", agent);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> login(Identifier identifier, LoginUser loginUser) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_LOGIN);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sr_user_name", loginUser.getUsername());
        param.put("sr_password", loginUser.getPassword());
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findbyUserName(String sr_user_name) throws Exception {
        Identifier identifier = new Identifier();
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_BY_USERNAME);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sr_user_name", sr_user_name);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    @Transactional
    public Map<String, Object> updateAgentById(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_UPDATE);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAgentStatusById(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_UPDATE_STS_BYID_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAgentSettingById(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_SETTING_UPDATE);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updatePassword(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_UPDATE_PASSWORD);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> resetAgentPasswordById(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_RESET_PASSWORD_BYID_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAgentStsById(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_UPDATE_STS_BYID);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAgentById(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_BYID);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> validateAgentUsername(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_VALIDATE_USERNAME_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> genCode(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_GENCODE);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> sendSms(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_SEND_SMS);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> genWxCode(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_WX_GENCODE);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAgentByMid(Identifier identifier, String si_mainboard_id) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_BYMID_USER);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("si_mainboard_id", si_mainboard_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findUserRolesByUserId(Identifier identifier, String sd_agent_id) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_ROLE_FIND_BYUSERID);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_agent_id", sd_agent_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateUserRolesByUserId(Identifier identifier, String sd_agent_id, String[] roleArr) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_ROLE_UPDATE_BYUSERID);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("sd_agent_id", sd_agent_id);
        param.put("roleArr", roleArr);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAgentByAreaCode(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_BYAREACODE);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

