/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_cash_stream
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.agent.model.Tb_cash_stream;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class CashStreamServiceImpl
extends BaseService {
    public Map<String, Object> findCashStreamByCash(Identifier identifier, Tb_cash_stream cashstream, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.CASH_FIND_BYCASH);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("cashstream", cashstream);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findCashStreamByAgentId(Identifier identifier, Integer sw_agent_id) {
        identifier.setFunctionCode(XcbConstantValue.CASH_FIND_BYAGENTID);
        HashMap<String, Integer> param = new HashMap<String, Integer>();
        param.put("sw_agent_id", sw_agent_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

