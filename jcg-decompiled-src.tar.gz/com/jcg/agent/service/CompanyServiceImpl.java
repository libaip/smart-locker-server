/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class CompanyServiceImpl
extends BaseService {
    public Map<String, Object> findComanyParamCache(Identifier identifier, String sd_company_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_PARAM_CACHE);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sd_company_id", sd_company_id);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Map<String, Object> findCompanyPayIn(Identifier identifier, String sd_company_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_FIND_PAYIN);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sd_company_id", sd_company_id);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Map<String, Object> findCompanyByMerId(Identifier identifier, String sr_wx_mer_id) {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_FIND_BYMERID);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_wx_mer_id", sr_wx_mer_id);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }
}

