/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_devicelogs
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.agent.model.Tb_devicelogs;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DeviceLogsServiceImpl
extends BaseService {
    public Map<String, Object> findDeviceLogsByParam(Identifier identifier, Tb_devicelogs deviceLogs, String dateRange, Page page) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_LOGS_FIND_BYPARAM);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("deviceLogs", deviceLogs);
        param.put("dateRange", dateRange);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

