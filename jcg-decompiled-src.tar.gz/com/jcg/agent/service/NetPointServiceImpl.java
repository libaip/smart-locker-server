/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_netpoint
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.agent.model.Tb_netpoint;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class NetPointServiceImpl
extends BaseService {
    public Map<String, Object> createNetPoint(Identifier identifier, Tb_netpoint netpoint) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_CREATE);
        HashMap<String, Tb_netpoint> param = new HashMap<String, Tb_netpoint>();
        param.put("netpoint", netpoint);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findNetPointByParam(Identifier identifier, Tb_netpoint netpoint, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_FIND_BYPARAM);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("netpoint", netpoint);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDropDownNetpointByAgentId(Identifier identifier, Integer sd_agent_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_FIND_BYAGENTID);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_agent_id", sd_agent_id.toString());
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findNetPointById(Identifier identifier, Tb_netpoint netpoint) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_FIND_BYID);
        HashMap<String, Tb_netpoint> param = new HashMap<String, Tb_netpoint>();
        param.put("netpoint", netpoint);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateNetPointById(Identifier identifier, Tb_netpoint netpoint) {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_UPDATE_BYID);
        HashMap<String, Tb_netpoint> param = new HashMap<String, Tb_netpoint>();
        param.put("netpoint", netpoint);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllNetpointByAreaCode(Identifier identifier, Tb_netpoint netpoint, Integer si_up_agent) {
        identifier.setFunctionCode(XcbConstantValue.NETPOINTDROPDOWN_FIND_BYAREACODE);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("netpoint", netpoint);
        param.put("si_up_agent", si_up_agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

