/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl
extends BaseService {
    public Map<String, Object> findOrderByParam(Identifier identifier, Tb_order order, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYPARAM);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderById(Identifier identifier, Tb_order order) {
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYID_AGENTMB);
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateOrderById(Identifier identifier, Tb_order order) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.ORDER_UPDATE);
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderById(Identifier identifier, String sd_order_id) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYID);
        param.put("sd_order_id", sd_order_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> checkRefund(Identifier identifier, String sd_ordercash_id, String sr_refund_money) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_TK_CHECK_AGENT);
        param.put("sd_ordercash_id", sd_ordercash_id);
        param.put("sr_refund_money", sr_refund_money);
        if (identifier.getUserId() == 1124) {
            param.put("sr_way", "CPY");
        } else {
            param.put("sr_way", "AGENT");
        }
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> tkNotify(Identifier identifier, String out_trade_no, String refund_fee, String sd_cash_id) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_TKNOTIFY);
        param.put("sd_ordercash_id", out_trade_no);
        param.put("refund_fee", refund_fee);
        param.put("sd_cash_id", sd_cash_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> zhRefund(Identifier identifier, String sd_ordercash_id, String sr_refund_money) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_REFUND);
        param.put("sd_ordercash_id", sd_ordercash_id);
        param.put("sr_refund_money", sr_refund_money);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> closeOrder(Identifier identifier, String sd_order_id, String sr_way) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_CLOSE);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_order_id", sd_order_id);
        param.put("sr_type", "");
        param.put("sr_way", sr_way);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderForExcel(Identifier identifier, Tb_order order, Page page) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_FOREXCEL_AGENT);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> depositRefund(Identifier identifier, String sd_order_id, String sr_refund_money) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_DEPOSIT_REFUND);
        param.put("sd_order_id", sd_order_id);
        param.put("sr_refund_money", sr_refund_money);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

