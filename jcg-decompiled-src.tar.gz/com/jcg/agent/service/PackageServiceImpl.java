/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_package
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.model.Tb_package;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class PackageServiceImpl
extends BaseService {
    public Map<String, Object> findPackageParam(Identifier identifier, Tb_package msgPackage) {
        identifier.setFunctionCode(XcbConstantValue.PACKAGE_FIND_BYPARAM);
        HashMap<String, Tb_package> param = new HashMap<String, Tb_package>();
        param.put("msgPackage", msgPackage);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

