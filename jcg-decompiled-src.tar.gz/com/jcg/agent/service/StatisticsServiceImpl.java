/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.agent.model.Tb_statistics;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class StatisticsServiceImpl
extends BaseService {
    public Map<String, Object> findStatisticsByParam(Identifier identifier, Tb_statistics statistics, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.STATISTICS_FIND_BYPARAM);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("statistics", statistics);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findLineChartGroupByParam(Identifier identifier, Tb_statistics statistics) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.STATISTICS_LINE_CHART_FIND_BYDAYTYPE);
        HashMap<String, Tb_statistics> param = new HashMap<String, Tb_statistics>();
        param.put("statistics", statistics);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findLineChartDataByParam(Identifier identifier, Tb_statistics statistics) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.STATISTICS_LINE_CHART_FIND_DATA_BYDAYTYPE);
        HashMap<String, Tb_statistics> param = new HashMap<String, Tb_statistics>();
        param.put("statistics", statistics);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

