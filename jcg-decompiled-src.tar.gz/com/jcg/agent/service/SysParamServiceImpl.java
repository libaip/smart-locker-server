/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class SysParamServiceImpl
extends BaseService {
    public Map<String, Object> updateParamForId(Identifier identifier, Map<String, Object> paraMap) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_WEIHU_ID);
        Map ret = this.genericCaller.genericCall(identifier, paraMap);
        return ret;
    }

    public Map<String, Object> findSysParamByKeyCode(Identifier identifier, String sr_category_code, String sr_key_code) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_BYKEYCODE);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_category_code", sr_category_code);
        param_map.put("sr_key_code", sr_key_code);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Map<String, Object> findDropDownInfos(Identifier identifier, String categoryCodes, String sr_login_type) {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_BYCATES);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("categoryCodes", categoryCodes);
        param_map.put("sr_login_type", sr_login_type);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Map<String, Object> findSysParamByCate(Identifier identifier, String sr_category_code) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_BYKEYCODE);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_category_code", sr_category_code);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }
}

