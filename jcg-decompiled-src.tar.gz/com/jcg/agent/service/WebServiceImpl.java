/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.agent.model.Tb_agent_way
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.client.utils.URIBuilder
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 *  org.apache.http.util.EntityUtils
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.alibaba.fastjson.JSONObject;
import com.jcg.agent.common.BaseService;
import com.jcg.agent.model.Tb_agent_way;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

@Service
public class WebServiceImpl
extends BaseService {
    public Map<String, Object> findUserName(Identifier identifier, Tb_agent_way agentWay) {
        HashMap<String, Tb_agent_way> param = new HashMap<String, Tb_agent_way>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.AGENT_WAY_FIND_BYNAME);
        param.put("agentWay", agentWay);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createAgentWay(Identifier identifier, Tb_agent_way agentWay) throws Exception {
        String url = "https://platform2.cqdyxl.com/jcgweb-company/webapi/createAgentWay";
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        HashMap<String, String> paramMap = new HashMap<String, String>();
        HashMap dataMap = new HashMap();
        JSONObject json = null;
        paramMap = new HashMap();
        paramMap.put("sr_user_name", agentWay.getSr_user_name());
        paramMap.put("sr_old_user_name", agentWay.getSr_old_user_name());
        paramMap.put("sr_way", agentWay.getSr_way());
        paramMap.put("sr_remark", agentWay.getSr_remark());
        String reqdata = JSONObject.toJSONString(paramMap);
        CloseableHttpResponse response = this.sendPost(url, reqdata, "");
        int statusCode = response.getStatusLine().getStatusCode();
        String msg = "";
        int result = 0;
        String str = EntityUtils.toString((HttpEntity)response.getEntity());
        if (!XcbStringUtils.isNullOrBlank((Object)str)) {
            json = JSONObject.parseObject((String)str);
            result = XcbStringUtils.getObjtoint((Object)json.get((Object)XcbConstantValue.STATUS));
        }
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            result_map.put(XcbConstantValue.MSG, msg);
        } else {
            msg = XcbStringUtils.getObjtoString((Object)json.get((Object)XcbConstantValue.MSG));
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, msg);
        }
        return result_map;
    }

    private CloseableHttpResponse sendPost(String url, String reqdata, String token) throws Exception {
        CloseableHttpResponse response = null;
        CloseableHttpClient httpClient = HttpClients.createDefault();
        try {
            URIBuilder uriBuilder = new URIBuilder(url);
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, XcbConstantValue.ENCODING_UTF8);
            entity.setContentType("application/json");
            httpPost.setEntity((HttpEntity)entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Authorization", token);
            response = httpClient.execute((HttpUriRequest)httpPost);
        }
        catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }
}

