/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_withdrawal_appl
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.service;

import com.jcg.agent.common.BaseService;
import com.jcg.agent.model.Tb_withdrawal_appl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class WithdrawalApplServiceImpl
extends BaseService {
    public Map<String, Object> createWithdrawalAppl(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        identifier.setFunctionCode(XcbConstantValue.WITHDRAWAL_APPL_CREATE);
        HashMap<String, Tb_withdrawal_appl> param = new HashMap<String, Tb_withdrawal_appl>();
        param.put("withdrawalAppl", withdrawalAppl);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createWithdrawalAppl_staff(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        identifier.setFunctionCode(XcbConstantValue.WITHDRAWAL_APPL_CREATE);
        HashMap<String, Tb_withdrawal_appl> param = new HashMap<String, Tb_withdrawal_appl>();
        withdrawalAppl.setSr_role("4");
        param.put("withdrawalAppl", withdrawalAppl);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findWithdrawalApplByParam(Identifier identifier, Tb_withdrawal_appl withdrawalAppl, Page page) {
        identifier.setFunctionCode(XcbConstantValue.WITHDRAWAL_APPL_FIND_BYPARAM);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("withdrawalAppl", withdrawalAppl);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findWithdrawalApplAgentInfoByParam(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        identifier.setFunctionCode(XcbConstantValue.WITHDRAWAL_APPL_FIND_AGENTINFO_BYPARAM);
        HashMap<String, Tb_withdrawal_appl> param = new HashMap<String, Tb_withdrawal_appl>();
        param.put("withdrawalAppl", withdrawalAppl);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

