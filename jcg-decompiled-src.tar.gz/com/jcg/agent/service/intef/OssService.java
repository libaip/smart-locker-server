/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.OssCallbackResult
 *  javax.servlet.http.HttpServletRequest
 */
package com.jcg.agent.service.intef;

import com.jcg.common.model.OssCallbackResult;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public interface OssService {
    public Map<String, Object> policy();

    public OssCallbackResult callback(HttpServletRequest var1);
}

