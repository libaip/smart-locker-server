/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.serviceimpl;

import org.springframework.stereotype.Service;

@Service
public class AdPlayServiceImpl {
}

