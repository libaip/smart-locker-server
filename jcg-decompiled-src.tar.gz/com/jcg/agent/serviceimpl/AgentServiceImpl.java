/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cn.hutool.core.util.ObjectUtil
 *  cn.hutool.core.util.StrUtil
 *  com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_agent_authorities
 *  com.jcg.agent.model.Tb_agent_roles_rel
 *  com.jcg.agent.model.Tb_deposit_share
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.company.model.Tb_sys_param
 *  com.jcg.company.model.Tb_wx_pay_info
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.crypto.password.StandardPasswordEncoder
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.agent.serviceimpl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.jcg.agent.idao.AgentAuthoritiesDao;
import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentRolesRelDao;
import com.jcg.agent.idao.DepositShareDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_agent_authorities;
import com.jcg.agent.model.Tb_agent_roles_rel;
import com.jcg.agent.model.Tb_deposit_share;
import com.jcg.agent.model.Tb_device;
import com.jcg.cache.SystemParamCache;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.DateUtil;
import com.jcg.common.PromptProperties;
import com.jcg.common.SmsUtils;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.CompanyDao;
import com.jcg.company.idao.CuserDao;
import com.jcg.company.idao.WxPayInfoDao;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.company.serviceimpl.SysParamServiceImpl;
import com.jcg.zf.wx.WxSdjAPICommon;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class AgentServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private HttpServletRequest request;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private CuserDao cuserDao;
    @Autowired
    private CompanyDao companyDao;
    @Autowired
    private DeviceDao deviceDao;
    @Autowired
    private StandardPasswordEncoder standardPasswordEncoder;
    @Autowired
    private SystemParamCache systemParamCache;
    @Autowired
    private SysParamServiceImpl sysParamService;
    @Autowired
    private AgentRolesRelDao roleRelDao;
    @Autowired
    private AgentAuthoritiesDao authDao;
    @Autowired
    private DepositShareDao depositShareDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private WxPayInfoDao wxPayInfoDao;
    @Autowired
    private WxSdjAPICommon wxSdjAPICommon;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=========AgentServiceImpl======== ");
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_agent agent = new Tb_agent();
        Integer sd_agent_id = null;
        String si_mainboard_id = null;
        Page page = new Page();
        if (param != null) {
            sd_agent_id = XcbStringUtils.getObjtoint((Object)param.get("sd_agent_id"));
            si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
            agent = (Tb_agent)param.get("agent");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.AGENT_LOGIN.equals(functionCode)) {
                String sr_user_name = XcbStringUtils.getObjtoString((Object)param.get("sr_user_name"));
                String sr_password = XcbStringUtils.getObjtoString((Object)param.get("sr_password"));
                String sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                ret = this.login(sr_user_name, sr_password, sr_way);
            } else if (XcbConstantValue.AGENT_CREATE_SHOP.equalsIgnoreCase(functionCode)) {
                ret = this.createShop(identifier, agent);
            } else if (XcbConstantValue.AGENT_CREATE_ROLE.equalsIgnoreCase(functionCode)) {
                ret = this.createRole(identifier, agent);
            } else if (XcbConstantValue.AGENT_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findAgentByParam(identifier, agent, page);
            } else if (XcbConstantValue.AGENT_FIND_FOR_SHARE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findAgentForShare(identifier, agent, page);
            } else if (XcbConstantValue.AGENT_DELETE.equalsIgnoreCase(functionCode)) {
                ret = this.deleteAgentById(identifier, sd_agent_id);
            } else if (XcbConstantValue.AGENT_FIND_BYMID.equalsIgnoreCase(functionCode)) {
                ret = this.findAgentByMid_user(si_mainboard_id);
            } else if (XcbConstantValue.AGENT_FIND_BY_USERNAME.equals(functionCode)) {
                String sr_user_name = XcbStringUtils.getObjtoString((Object)param.get("sr_user_name"));
                ret = this.findAgentByUserName(sr_user_name);
            } else if (XcbConstantValue.AGENT_UPDATE.equalsIgnoreCase(functionCode)) {
                ret = this.updateAgent_agent(identifier, agent);
            } else if (XcbConstantValue.AGENT_SETTING_UPDATE.equalsIgnoreCase(functionCode)) {
                ret = this.updateSettingAgent_agent(identifier, agent);
            } else if (XcbConstantValue.AGENT_UPDATE_STS_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.updateAgentStatusById_agent(identifier, agent);
            } else if (XcbConstantValue.AGENT_UPDATE_PASSWORD.equalsIgnoreCase(functionCode)) {
                ret = this.updatePassword(identifier, agent);
            } else if (XcbConstantValue.AGENT_FIND_BYID.equalsIgnoreCase(functionCode)) {
                String type = XcbStringUtils.getObjtoString((Object)param.get("type"));
                ret = this.findAgentById_agent(identifier, agent.getSd_agent_id(), type);
            } else if (XcbConstantValue.AGENT_WX_GENCODE.equalsIgnoreCase(functionCode)) {
                ret = this.genWxCode(agent);
            } else if (XcbConstantValue.AGENT_SEND_SMS.equalsIgnoreCase(functionCode)) {
                ret = this.sendSms(identifier, agent);
            } else if (XcbConstantValue.AGENT_ROLE_FIND_BYUSERID.equalsIgnoreCase(functionCode)) {
                ret = this.findUserRolesByUserId(identifier, sd_agent_id);
            } else if (XcbConstantValue.AGENT_ROLE_UPDATE_BYUSERID.equalsIgnoreCase(functionCode)) {
                String[] roleArr = (String[])param.get("roleArr");
                ret = this.updateUserRolesByUserId(identifier, sd_agent_id, roleArr);
            } else if (XcbConstantValue.AGENT_FIND_ALL_USER_BYAGENT.equalsIgnoreCase(functionCode)) {
                ret = this.findAllUserByAgentId(identifier, agent, page);
            } else if (XcbConstantValue.AGENT_FIND_BYAREACODE.equalsIgnoreCase(functionCode)) {
                ret = this.findAgentByAreaCode(identifier, agent);
            } else if (XcbConstantValue.AGENT_CREATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.createAgent_cpy(identifier, agent);
            } else if (XcbConstantValue.AGENT_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findAgentByParam_cpy(identifier, agent, page);
            } else if (XcbConstantValue.AGENT_FIND_MONEY_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findAgentMoneyByParam(identifier, agent, page);
            } else if (XcbConstantValue.AGENT_FIND_STAFF_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findStaffByParam_cpy(identifier, agent, page);
            } else if (XcbConstantValue.AGENT_FIND_BYID_CPY.equalsIgnoreCase(functionCode)) {
                String type = XcbStringUtils.getObjtoString((Object)param.get("type"));
                ret = this.findAgentById_agent(identifier, agent.getSd_agent_id(), type);
            } else if (XcbConstantValue.AGENT_FIND_BYAREACODE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findAgentByAreaCode_cpy(identifier, agent);
            } else if (XcbConstantValue.AGENT_FIND_BYUPAGENT_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findAllAgentById_cpy(identifier, agent);
            } else if (XcbConstantValue.AGENT_FIND_UPAGENT_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findUpAgentByParam_cpy(identifier, agent);
            } else if (XcbConstantValue.AGENT_UPDATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateAgent_agent(identifier, agent);
            } else if (XcbConstantValue.AGENT_UPDATE_STS_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateAgentStatusById_cpy(identifier, agent);
            } else if (XcbConstantValue.AGENT_RESET_PASSWORD_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.resetAgentPasswordById_cpy(identifier, agent);
            } else if (XcbConstantValue.AGENT_VALIDATE_USERNAME_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.validateAgentUsername_cpy(agent);
            } else if (XcbConstantValue.AGENT_VALIDATE_AGENTEXIST_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.validateDistinctAgent_cpy(agent);
            } else if (XcbConstantValue.AGENT_UPDATE_AD_MONEY.equalsIgnoreCase(functionCode)) {
                ret = this.updateAgentAd(identifier, agent);
            } else if (XcbConstantValue.AGENT_UPDATE_AGENT_WAY.equalsIgnoreCase(functionCode)) {
                ret = this.updateAgentWay(identifier, agent);
            } else if (XcbConstantValue.AGENT_IDENTITY_CERTIFICATE.equalsIgnoreCase(functionCode)) {
                ret = this.identity_certificate(identifier, agent);
            } else if (XcbConstantValue.AGENT_IDENTITY_BINDING.equalsIgnoreCase(functionCode)) {
                ret = this.binding(identifier, agent);
            } else if (XcbConstantValue.AGENT_IDENTITY_BINDING_OPEN.equalsIgnoreCase(functionCode)) {
                ret = this.bindingCpy(identifier, agent);
            } else if (XcbConstantValue.AGENT_IDENTITY_UNBINDING.equalsIgnoreCase(functionCode)) {
                ret = this.binding_terminate(identifier, agent);
            } else if (XcbConstantValue.AGENT_FIND_BYMID_USER.equalsIgnoreCase(functionCode)) {
                ret = this.findAgentByMid_user(si_mainboard_id);
            } else if (XcbConstantValue.AGENT_AUTH_FIND_BYUSERID.equalsIgnoreCase(functionCode)) {
                ret = this.findUserAuthsByUserId(identifier, sd_agent_id);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> createShop(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        ArrayList<String> keyCodelist = new ArrayList<String>();
        try {
            int result = 0;
            agent.setSr_user_name(agent.getSr_phone());
            Tb_agent upAgent = this.agentDao.findAgentById_agent(XcbStringUtils.getObjtoint((Object)agent.getSi_up_agent()));
            Tb_agent agent_same = this.agentDao.findAgentByUserName_agent(agent.getSr_user_name());
            if (agent_same != null) {
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.user.duplicate_name"));
                map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                return map;
            }
            Map<String, Integer> mapid = this.sysParamService.getNewId(XcbConstantValue.TA_CATECODE_MAINTENANCE_ID, XcbConstantValue.TA_KEYCODE_AGENTID);
            int sd_agent_id = mapid.get("sr_param_value");
            int count = this.sysParamDao.updateParamForId(mapid);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                Tb_sys_param sysParam = new Tb_sys_param();
                sysParam.setSr_category_code(XcbConstantValue.XTCL);
                keyCodelist.add(XcbConstantValue.AGENTPASS);
                sysParam.setSr_key_code_list(keyCodelist);
                List<Tb_sys_param> sysParamList = this.sysParamDao.findSysParamByKeyCode_cpy(sysParam);
                String password = null;
                for (Tb_sys_param tb_sys_param : sysParamList) {
                    if (!XcbConstantValue.AGENTPASS.equals(tb_sys_param.getSr_key_code())) continue;
                    password = tb_sys_param.getSr_param_value();
                }
                String role = XcbConstantValue.AGENT_ROLE_2;
                String password_md5 = this.standardPasswordEncoder.encode(password);
                agent.setSr_password(password_md5);
                agent.setSr_password_mw(password);
                agent.setSd_agent_id(Integer.valueOf(sd_agent_id));
                agent.setSw_company_id(upAgent.getSw_company_id());
                agent.setSi_up_agent(upAgent.getSd_agent_id());
                agent.setSr_agent_region_province(upAgent.getSr_agent_region_province());
                agent.setSr_agent_region_city(upAgent.getSr_agent_region_city());
                agent.setSr_agent_region_district(upAgent.getSr_agent_region_district());
                agent.setDc_bonus(upAgent.getDc_bonus());
                agent.setSr_agent_type(upAgent.getSr_agent_type());
                agent.setSr_pay_type(upAgent.getSr_pay_type());
                agent.setDc_agent_money(BigDecimal.ZERO);
                agent.setDc_cb_money(BigDecimal.ZERO);
                agent.setDc_tx_money(BigDecimal.ZERO);
                agent.setDc_ad_money(BigDecimal.ZERO);
                agent.setSr_way(XcbConstantValue.LOGIN_WAY);
                agent.setSr_status(XcbConstantValue.AGENT_STATUS_ZC);
                agent.setSr_account_status(XcbConstantValue.AGENT_STATUS_ZC);
                agent.setSi_create_person(upAgent.getSd_agent_id());
                agent.setTm_create_time(new Date());
                agent.setSr_role(role);
                result = this.agentDao.createAgent_cpy(agent);
                String opera_sign = "";
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.user.success"));
                    opera_sign = XcbConstantValue.OPEAR_SUCCESS_STR;
                    map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                } else {
                    map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.user.fail"));
                    opera_sign = XcbConstantValue.OPEAR_FAIL_STR;
                    map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_COMPANY, XcbConstantValue.AGENT_CREATE_SHOP, identifier.getUserId(), opera_sign, "CREATE", "\u521b\u5efa\u4ee3\u7406\u5546", identifier.getUrl(), identifier.getIp());
                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                operationLogs.setSr_operate_primarykey(String.valueOf(sd_agent_id));
                operationLogs.setSr_operate_result("");
                operationLogs.setSr_operate_table("Tb_agent");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
            } else {
                map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.user.duplicate_name"));
            }
            this.initResultMap(map);
            return map;
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_CREATE_SHOP, PromptProperties.getProperty("agent.create.user.fail"), (Throwable)e);
        }
    }

    private Map<String, Object> createRole(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        ArrayList<String> keyCodelist = new ArrayList<String>();
        try {
            int result = 0;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(XcbStringUtils.getObjtoint((Object)agent.getSr_admin_id()));
            Tb_agent agent_same = this.agentDao.findAgentByUserName_agent(agent.getSr_user_name());
            if (agent_same != null) {
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.user.duplicate_name"));
                map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                return map;
            }
            Map<String, Integer> mapid = this.sysParamService.getNewId(XcbConstantValue.TA_CATECODE_MAINTENANCE_ID, XcbConstantValue.TA_KEYCODE_AGENTID);
            int sd_agent_id = mapid.get("sr_param_value");
            int count = this.sysParamDao.updateParamForId(mapid);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                Tb_sys_param sysParam = new Tb_sys_param();
                sysParam.setSr_category_code(XcbConstantValue.XTCL);
                keyCodelist.add(XcbConstantValue.AGENTPASS);
                sysParam.setSr_key_code_list(keyCodelist);
                List<Tb_sys_param> sysParamList = this.sysParamDao.findSysParamByKeyCode_cpy(sysParam);
                String password = null;
                for (Tb_sys_param tb_sys_param : sysParamList) {
                    if (!XcbConstantValue.AGENTPASS.equals(tb_sys_param.getSr_key_code())) continue;
                    password = tb_sys_param.getSr_param_value();
                }
                String role = XcbConstantValue.AGENT_ROLE_3;
                if (adminAgent != null && "2".equals(adminAgent.getSr_role())) {
                    role = XcbConstantValue.AGENT_ROLE_4;
                }
                String password_md5 = this.standardPasswordEncoder.encode(password);
                agent.setSr_password(password_md5);
                agent.setSr_password_mw(password);
                agent.setSd_agent_id(Integer.valueOf(sd_agent_id));
                agent.setSr_phone(agent.getSr_user_name());
                agent.setSw_company_id(adminAgent.getSw_company_id());
                agent.setDc_bonus(BigDecimal.ZERO);
                agent.setDc_fisrt_bonus(BigDecimal.ZERO);
                agent.setDc_second_bonus(BigDecimal.ZERO);
                agent.setTm_start_time(XcbDateUtil.parseDate((String)XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"), (String)"yyyy-MM-dd"));
                agent.setSr_status(XcbConstantValue.AGENT_STATUS_ZC);
                agent.setSr_account_status(XcbConstantValue.AGENT_STATUS_ZC);
                agent.setSi_create_person(adminAgent.getSd_agent_id());
                agent.setSr_agent_type(adminAgent.getSr_agent_type());
                agent.setSr_province(adminAgent.getSr_province());
                agent.setSr_city(adminAgent.getSr_city());
                agent.setSr_district(adminAgent.getSr_district());
                agent.setSr_street(adminAgent.getSr_street());
                agent.setSr_detail_address(adminAgent.getSr_detail_address());
                agent.setSr_agent_region_province(adminAgent.getSr_agent_region_province());
                agent.setSr_agent_region_city(adminAgent.getSr_agent_region_city());
                agent.setSr_agent_region_district(adminAgent.getSr_agent_region_district());
                agent.setDc_agent_money(BigDecimal.ZERO);
                agent.setDc_cb_money(BigDecimal.ZERO);
                agent.setDc_tx_money(BigDecimal.ZERO);
                agent.setDc_ad_money(BigDecimal.ZERO);
                agent.setSr_recharge_platform("Y");
                agent.setSr_force_recharge("GB");
                agent.setSr_pay_type("WX_DK");
                agent.setSr_pay_way("WX");
                agent.setSr_is_ad("N");
                agent.setSr_ad_show("N");
                agent.setSr_is_appl("N");
                agent.setSr_is_month("N");
                agent.setDc_max_money(BigDecimal.ZERO);
                agent.setSr_is_show_fh("N");
                agent.setSr_ad_mode("2");
                agent.setSr_ad_is_appl("N");
                agent.setSr_ad_type("2");
                agent.setDc_ad_setting(BigDecimal.ZERO);
                agent.setSr_ad_date_type(adminAgent.getSr_ad_date_type());
                agent.setSr_ad_income_date(adminAgent.getSr_ad_income_date());
                agent.setSr_is_tx("Y");
                agent.setSi_mark(Integer.valueOf(0));
                agent.setSr_is_show("N");
                agent.setSr_show_door("N");
                agent.setSr_show_box("N");
                agent.setSr_is_show_steal("Y");
                agent.setTm_create_time(new Date());
                agent.setSr_role(role);
                agent.setSr_way(XcbConstantValue.LOGIN_WAY);
                result = this.agentDao.createAgent(agent);
                String opera_sign = "";
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.user.success"));
                    opera_sign = XcbConstantValue.OPEAR_SUCCESS_STR;
                    map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                } else {
                    map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.user.fail"));
                    opera_sign = XcbConstantValue.OPEAR_FAIL_STR;
                    map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_COMPANY, XcbConstantValue.AGENT_CREATE_ROLE, identifier.getUserId(), opera_sign, "CREATE", "\u521b\u5efa\u4ee3\u7406\u5546", identifier.getUrl(), identifier.getIp());
                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                operationLogs.setSr_operate_primarykey(String.valueOf(sd_agent_id));
                operationLogs.setSr_operate_result("");
                operationLogs.setSr_operate_table("Tb_agent");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
            } else {
                map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.user.duplicate_name"));
            }
            this.initResultMap(map);
            return map;
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_CREATE_ROLE, PromptProperties.getProperty("agent.create.user.fail"), (Throwable)e);
        }
    }

    public Map<String, Object> findAgentByParam(Identifier identifier, Tb_agent agent, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            agent.setSr_way(XcbConstantValue.LOGIN_WAY);
            List<Tb_agent> agents = this.agentDao.findAgentByParam(agent, page);
            int totalCount = this.agentDao.findCountByParam(agent);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("agents", agents);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_BYPARAM, PromptProperties.getProperty("agent.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findAgentForShare(Identifier identifier, Tb_agent agent, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_agent> agents = this.agentDao.findAgentForShare(agent, page);
            int totalCount = this.agentDao.findCountForShare(agent);
            String startDate = XcbDateUtil.getCurrentMonthFirst();
            String endDate = XcbDateUtil.getCurrentMonthLast();
            for (Tb_agent a : agents) {
                Tb_deposit_share share = new Tb_deposit_share();
                share.setSr_create_time_start(startDate);
                share.setSr_create_time_end(endDate);
                share.setSw_agent_id(a.getSd_agent_id());
                List<Tb_deposit_share> list = this.depositShareDao.findDepositShareByAgent(share);
                if (list != null && list.size() > 0) {
                    a.setSr_is_share("N");
                    continue;
                }
                a.setSr_is_share("Y");
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("agents", agents);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_FOR_SHARE_CPY, PromptProperties.getProperty("agent.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findAgentByMid_user(String si_mainboard_id) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Tb_agent> dataMap = new HashMap<String, Tb_agent>();
        try {
            Tb_device device = this.deviceDao.findDeviceByMid(si_mainboard_id);
            if (device != null) {
                Integer sw_agent_id = device.getSw_agent_id();
                Tb_agent agent = this.agentDao.findAgentById_agent(sw_agent_id);
                dataMap.put("agent", agent);
                ret.put(XcbConstantValue.DATA, dataMap);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.find.fail"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_BYMID_USER, PromptProperties.getProperty("agent.login.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> login(String sr_user_name, String sr_password, String sr_way) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        boolean isSuccess = false;
        boolean isPass = false;
        String msg = "";
        try {
            Tb_agent agent = this.agentDao.findAgentByUserName_agent(sr_user_name);
            if (agent != null) {
                Date today = new Date();
                String lastLogin = agent.getTm_last_logintime() == null ? "" : XcbDateUtil.formatDate((Date)agent.getTm_last_logintime(), (String)"yyyy-MM-dd");
                String todayStr = XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd");
                isPass = this.standardPasswordEncoder.matches((CharSequence)sr_password, agent.getPassword());
                if (isPass) {
                    if (!"WX_APP".equals(sr_way) && !XcbStringUtils.isNullOrBlank((Object)agent.getSr_admin_id())) {
                        msg = PromptProperties.getProperty("agent.login.admin.fail");
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, msg);
                        return ret;
                    }
                    if (agent.getSr_status().equals(XcbConstantValue.CUSER_STATUS_ZX)) {
                        msg = PromptProperties.getProperty("agent.login.error.zx");
                    } else if (agent.getSr_status().equals(XcbConstantValue.CUSER_STATUS_DJ)) {
                        msg = PromptProperties.getProperty("agent.login.error.dj");
                    } else if (agent.getSr_status().equals(XcbConstantValue.CUSER_STATUS_SD)) {
                        msg = PromptProperties.getProperty("agent.login.error.sd");
                    } else if (agent.getSr_status().equals(XcbConstantValue.CUSER_STATUS_ZC)) {
                        agent.setSi_errorpass_count(new Integer(0));
                        agent.setTm_last_logintime(today);
                        this.agentDao.updateAgentById_agent(agent);
                        isSuccess = true;
                    } else {
                        msg = PromptProperties.getProperty("agent.login.fail");
                    }
                } else {
                    agent.setTm_modify_time(today);
                    Integer errCnt = agent.getSi_errorpass_count() == null ? new Integer(0) : agent.getSi_errorpass_count();
                    errCnt = errCnt + 1;
                    Integer maxPassCnt = this.getMaxPassCnt();
                    if (!lastLogin.equals(todayStr)) {
                        errCnt = new Integer(1);
                    }
                    Integer remainCnt = maxPassCnt - errCnt;
                    msg = PromptProperties.getProperty("agent.login.error.pwd", remainCnt);
                    agent.setSi_errorpass_count(errCnt);
                    if (errCnt.compareTo(maxPassCnt - 1) > 0) {
                        agent.setSr_status(XcbConstantValue.AGENT_STATUS_SD);
                        this.agentDao.updateStsById_agent(agent);
                        msg = PromptProperties.getProperty("agent.login.error.lock", remainCnt);
                    } else {
                        this.agentDao.updateAgentById_agent(agent);
                    }
                }
            } else {
                msg = PromptProperties.getProperty("agent.login.error.non-existent");
            }
            if (isSuccess) {
                ret.put(XcbConstantValue.DATA, agent);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.login.success"));
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, msg);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_LOGIN, PromptProperties.getProperty("agent.login.error"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> updateSettingAgent_agent(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_agent a = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
            if (StrUtil.isNotEmpty((CharSequence)agent.getSr_verifycode()) && ObjectUtil.isNotEmpty((Object)a.getTm_verifycode_time()) && System.currentTimeMillis() - a.getTm_verifycode_time().getTime() > 300000L) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.setting.verifycode.expire"));
                this.initResultMap(ret);
                return ret;
            }
            if (StrUtil.isNotBlank((CharSequence)agent.getSr_verifycode()) && !agent.getSr_verifycode().equals(a.getSr_verifycode())) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.verify.captcha.fail"));
                this.initResultMap(ret);
                return ret;
            }
            int result = this.agentDao.updateAgentSettingById_agent(agent);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.success"));
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.fail"));
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.AGENT_UPDATE, PromptProperties.getProperty("agent.update.fail"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> updateAgent_agent(Identifier identifier, Tb_agent agent) {
        Map<Object, Object> ret = new HashMap();
        int result = 0;
        try {
            Tb_agent oldAgent = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
            agent.setSr_old_user_name(oldAgent.getSr_user_name());
            if (!XcbStringUtils.isNullOrBlank((Object)agent.getSr_user_name())) {
                ret = this.validateAgentUsername_cpy(agent);
                result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Map dataMap = (Map)ret.get(XcbConstantValue.DATA);
                    boolean isExistName = (Boolean)dataMap.get("isExistName");
                    if (isExistName) {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.username.isExist"));
                        return ret;
                    }
                } else {
                    return ret;
                }
            }
            if ("N".equals(agent.getSr_is_month())) {
                agent.setDc_max_money(BigDecimal.ZERO);
            }
            if ((result = this.agentDao.updateAgentById_agent(agent)) > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.DATA, agent);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.success"));
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.fail"));
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.AGENT_UPDATE, PromptProperties.getProperty("agent.update.fail"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> updateAgentAd(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        try {
            Tb_agent o_agent = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
            Tb_agent n_agent = new Tb_agent();
            n_agent.setSd_agent_id(agent.getSd_agent_id());
            n_agent.setDc_old_ad_money(o_agent.getDc_ad_money());
            n_agent.setDc_ad_money(agent.getDc_ad_money());
            result = this.agentDao.updateAdMoneyById(agent);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, "\u51b2\u6b63\u6210\u529f");
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u51b2\u6b63\u5931\u8d25");
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.AGENT_UPDATE_AD_MONEY, PromptProperties.getProperty("agent.update.fail"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> updateAgentWay(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        try {
            Tb_agent o_agent = this.agentDao.findAgentByUserName_agent(agent.getSr_user_name());
            if (o_agent != null) {
                Tb_agent n_agent = new Tb_agent();
                n_agent.setSd_agent_id(o_agent.getSd_agent_id());
                n_agent.setSr_way(agent.getSr_way());
                result = this.agentDao.updateAgentWay(n_agent);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.MSG, "\u66f4\u65b0\u6210\u529f");
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, "\u66f4\u65b0\u5931\u8d25");
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u7528\u6237\u4e0d\u5b58\u5728");
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.AGENT_UPDATE_AGENT_WAY, PromptProperties.getProperty("agent.update.fail"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> findAgentByUserName(String sr_user_name) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_agent agent = this.agentDao.findAgentByUserName_agent(sr_user_name);
            ret.put(XcbConstantValue.DATA, agent);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_BY_USERNAME, PromptProperties.getProperty("agent.find.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> updateAgentStatusById_agent(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result;
            String opt = agent.getOptStr();
            if (opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_LOCK)) {
                agent.setSr_status(XcbConstantValue.AGENT_STATUS_SD);
            }
            if ((result = this.agentDao.updateStsById_agent(agent)) > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.AGENT_UPDATE_STS_BYID, PromptProperties.getProperty("agent.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updatePassword(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        int result = 0;
        try {
            Tb_agent agentInDB = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
            String password = agent.getSr_password();
            String password_md5 = this.standardPasswordEncoder.encode((CharSequence)password);
            agent.setSr_password(password_md5);
            agent.setSr_password_mw(password);
            result = this.agentDao.updatePassword_agent(agent);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                agentInDB.setSr_password_mw(password);
                map.put(XcbConstantValue.DATA, agentInDB);
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.updatepassword.success"));
            } else {
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.updatepassword.fail"));
            }
            map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(map);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_UPDATE_PASSWORD, PromptProperties.getProperty("agent.updatepassword.error"), (Throwable)e);
        }
        return map;
    }

    public Map<String, Object> findAgentById_agent(Identifier identifier, Integer sd_agent_id, String type) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            Tb_agent adminAgent;
            if (!XcbStringUtils.isNullOrBlank((Object)type) && (adminAgent = this.agentDao.findAgentById_agent(sd_agent_id)) != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                sd_agent_id = XcbStringUtils.getObjtoint((Object)adminAgent.getSr_admin_id());
            }
            Tb_agent agent = this.agentDao.findAgentById_agent(sd_agent_id);
            BigDecimal dc_ad_max_money = BigDecimal.ZERO;
            if ("2".equals(agent.getSr_ad_income_date())) {
                String start_day = XcbDateUtil.getCurrentMonthFirst();
                String end_day = XcbDateUtil.getEndDay((String)XcbDateUtil.getBeforeDay((Date)new Date(), (int)1, (String)"yyyy-MM-dd"));
                BigDecimal this_month = BigDecimal.ZERO;
                if ("1".equals(agent.getSr_role())) {
                    List<String> subList = this.agentDao.findSubAgentList(agent.getSd_agent_id());
                    String[] subArr = new String[subList.size()];
                    subList.toArray(subArr);
                    if (subList.size() > 0) {
                        this_month = this.orderDao.findShowNowMonthAdMoney(subArr, start_day, end_day);
                    }
                } else if ("2".equals(agent.getSr_role())) {
                    this_month = this.orderDao.findNowMonthAdMoney(agent.getSd_agent_id(), start_day, end_day);
                }
                dc_ad_max_money = BigDecimalUtil.sub((BigDecimal)agent.getDc_ad_money(), (BigDecimal)this_month);
                if (dc_ad_max_money.compareTo(BigDecimal.ZERO) <= 0) {
                    dc_ad_max_money = BigDecimal.ZERO;
                }
                agent.setDc_ad_max_money(dc_ad_max_money);
            }
            map.put(XcbConstantValue.DATA, agent);
            map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(map);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_BYID, PromptProperties.getProperty("agent.find.error"), (Throwable)e);
        }
        return map;
    }

    private Map<String, Object> genWxCode(Tb_agent agent) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        CommonLogic commonLogic = new CommonLogic();
        Tb_agent a = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
        Tb_company company = this.companyDao.findCompanyById(a.getSw_company_id());
        commonLogic.genWxCode(ret_method, agent, company, this.request);
        int result = this.agentDao.updateAgentSettingById_agent(agent);
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.DATA, agent);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.qrcode.success"));
        } else {
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.qrcode.fail"));
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> findAgentByAreaCode(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> agents = this.agentDao.findAgentByAreaCode(agent);
            map.put(XcbConstantValue.DATA, agents);
            map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(map);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_BYAREACODE, PromptProperties.getProperty("agent.find.byareacode.error"), (Throwable)e);
        }
        return map;
    }

    public Map<String, Object> findAgentByAreaCode_cpy(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> agents = this.agentDao.findAgentByAreaCode_cpy(agent);
            map.put(XcbConstantValue.DATA, agents);
            map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(map);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_BYAREACODE_CPY, PromptProperties.getProperty("agent.find.byareacode.error"), (Throwable)e);
        }
        return map;
    }

    public Map<String, Object> createAgent_cpy(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        ArrayList<String> keyCodelist = new ArrayList<String>();
        try {
            int result = 0;
            boolean isSuccess = false;
            agent.setSr_user_name(agent.getSr_phone());
            Tb_agent agent_same = this.agentDao.findAgentByUserName_agent(agent.getSr_user_name());
            if (agent_same != null) {
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.duplicate_name"));
                map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                return map;
            }
            Map<String, Integer> mapid = this.sysParamService.getNewId(XcbConstantValue.TA_CATECODE_MAINTENANCE_ID, XcbConstantValue.TA_KEYCODE_AGENTID);
            int sd_agent_id = mapid.get("sr_param_value");
            int count = this.sysParamDao.updateParamForId(mapid);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                Tb_sys_param sysParam = new Tb_sys_param();
                sysParam.setSr_category_code(XcbConstantValue.XTCL);
                keyCodelist.add(XcbConstantValue.AGENTPASS);
                sysParam.setSr_key_code_list(keyCodelist);
                List<Tb_sys_param> sysParamList = this.sysParamDao.findSysParamByKeyCode_cpy(sysParam);
                String password = null;
                for (Tb_sys_param tb_sys_param : sysParamList) {
                    if (!XcbConstantValue.AGENTPASS.equals(tb_sys_param.getSr_key_code())) continue;
                    password = tb_sys_param.getSr_param_value();
                }
                String password_md5 = this.standardPasswordEncoder.encode(password);
                agent.setSr_password_mw(password);
                agent.setSr_password(password_md5);
                agent.setSd_agent_id(Integer.valueOf(sd_agent_id));
                agent.setTm_create_time(new Date());
                agent.setSi_create_person(identifier.getUserId());
                agent.setSr_pay_type("WX_DK");
                agent.setSr_user_name(agent.getSr_phone());
                agent.setSr_account_status(XcbConstantValue.AGENT_ACCOUNT_STATUS_ZC);
                agent.setSr_status(XcbConstantValue.AGENT_STATUS_ZC);
                agent.setSi_errorpass_count(new Integer(0));
                agent.setDc_tx_money(BigDecimal.ZERO);
                agent.setDc_agent_money(BigDecimal.ZERO);
                agent.setDc_cb_money(BigDecimal.ZERO);
                agent.setSr_way(XcbConstantValue.LOGIN_WAY);
                Tb_cuser cuser = this.cuserDao.findCuserById(agent.getSd_cuser_id());
                agent.setSw_company_id(cuser.getSw_company_id());
                if (!XcbStringUtils.isNullOrBlank((Object)agent.getSi_up_agent())) {
                    Tb_agent upAgent = this.agentDao.findAgentById_agent(agent.getSi_up_agent());
                    agent.setSr_agent_type(upAgent.getSr_agent_type());
                }
                if ((result = this.agentDao.createAgent_cpy(agent)) > XcbConstantValue.OPERA_INT_ZERO) {
                    isSuccess = true;
                }
                String opera_sign = XcbConstantValue.OPERATION_SUCCESS;
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_COMPANY, XcbConstantValue.AGENT_CREATE_CPY, identifier.getUserId(), opera_sign, "CREATE", "\u521b\u5efa\u4ee3\u7406\u5546", identifier.getUrl(), identifier.getIp());
                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                operationLogs.setSr_operate_primarykey(String.valueOf(sd_agent_id));
                operationLogs.setSr_operate_result("");
                operationLogs.setSr_operate_table("Tb_agent");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
            } else {
                map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.duplicate_name"));
            }
            if (!isSuccess) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            } else {
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.create.success"));
            }
            this.initResultMap(map);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.AGENT_CREATE_CPY, PromptProperties.getProperty("agent.create.fail"), (Throwable)e);
        }
        return map;
    }

    public Map<String, Object> findAllAgentById_cpy(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> agents = this.agentDao.findAllAgentById_cpy(agent);
            map.put(XcbConstantValue.DATA, agents);
            map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(map);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_BYUPAGENT_CPY, PromptProperties.getProperty("agent.findbyparam.fail"), (Throwable)e);
        }
        return map;
    }

    public Map<String, Object> findUpAgentByParam_cpy(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> agents = this.agentDao.findUpAgentByParam_cpy(agent);
            map.put(XcbConstantValue.DATA, agents);
            map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(map);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_UPAGENT_CPY, PromptProperties.getProperty("agent.findbyparam.fail"), (Throwable)e);
        }
        return map;
    }

    private Map<String, Object> updateAgentStatusById_cpy(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            String opt = agent.getOptStr();
            Tb_agent a = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
            agent.setSr_user_name(a.getSr_user_name());
            String srStatus = a.getSr_status();
            if (srStatus.equalsIgnoreCase(XcbConstantValue.AGENT_STATUS_ZX)) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.sts.zx.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                return ret_method;
            }
            if (srStatus.equalsIgnoreCase(XcbConstantValue.AGENT_STATUS_DJ)) {
                if (!opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_DISABLE) && !opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_UNFROZEN)) {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.sts.dj.fail"));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    return ret_method;
                }
                if (opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_UNFROZEN)) {
                    agent.setSi_errorpass_count(new Integer(0));
                }
            }
            if (srStatus.equalsIgnoreCase(XcbConstantValue.AGENT_STATUS_SD)) {
                if (!(opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_DISABLE) || opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_FROZEN) || opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_UNLOCK))) {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.sts.sd.fail"));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    return ret_method;
                }
                if (opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_UNLOCK)) {
                    agent.setSi_errorpass_count(new Integer(0));
                }
            }
            if (opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_UNLOCK) || opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_UNFROZEN)) {
                agent.setSr_status(XcbConstantValue.AGENT_STATUS_ZC);
            } else if (opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_LOCK)) {
                agent.setSr_status(XcbConstantValue.AGENT_STATUS_SD);
            } else if (opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_FROZEN)) {
                agent.setSr_status(XcbConstantValue.AGENT_STATUS_DJ);
            } else if (opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_DISABLE)) {
                agent.setSr_status(XcbConstantValue.AGENT_STATUS_ZX);
                agent.setSr_end_time(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            }
            int result = this.agentDao.updateStsById_cpy(agent);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_UPDATE_STS_BYID_CPY, PromptProperties.getProperty("agent.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> resetAgentPasswordById_cpy(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        ArrayList<String> keyCodelist = new ArrayList<String>();
        try {
            String opt = agent.getOptStr();
            if (opt.equalsIgnoreCase(XcbConstantValue.AGENT_OPT_RESETPASWD)) {
                Tb_sys_param sysParam = new Tb_sys_param();
                sysParam.setSr_category_code(XcbConstantValue.XTCL);
                keyCodelist.add(XcbConstantValue.AGENTPASS);
                sysParam.setSr_key_code_list(keyCodelist);
                List<Tb_sys_param> sysParamList = this.sysParamDao.findSysParamByKeyCode_cpy(sysParam);
                String password = sysParamList.get(0).getSr_param_value();
                String password_md5 = this.standardPasswordEncoder.encode((CharSequence)password);
                agent.setSr_password(password_md5);
                agent.setSr_password_mw(password);
                agent.setTm_modify_time(new Date());
                agent.setSi_modify_person(identifier.getUserId());
            }
            int count = this.agentDao.resetPasswordById_cpy(agent);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.success"));
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_RESET_PASSWORD_BYID_CPY, PromptProperties.getProperty("agent.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> validateAgentUsername_cpy(Tb_agent agent) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Boolean> dataMap = new HashMap<String, Boolean>();
        boolean isExistName = false;
        String phone = agent.getSr_phone();
        Integer agentId = agent.getSd_agent_id();
        try {
            Tb_agent agent_same = this.agentDao.findAgentByUserName_agent(phone);
            if (agent_same != null) {
                String sr_user_name = agent_same.getSr_user_name();
                Integer sd_agent_id = agent_same.getSd_agent_id();
                if (!XcbStringUtils.isNullOrBlank((Object)sr_user_name)) {
                    if (XcbStringUtils.isNullOrBlank((Object)agentId)) {
                        if (phone.equals(sr_user_name)) {
                            isExistName = true;
                        }
                    } else if (phone.equals(sr_user_name) && !agentId.equals(sd_agent_id)) {
                        isExistName = true;
                    }
                }
            }
            dataMap.put("isExistName", isExistName);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_VALIDATE_USERNAME_CPY, PromptProperties.getProperty("agent.validate.username.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> validateDistinctAgent_cpy(Tb_agent agent) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            boolean existAgent = this.validateExistAgent_cpy(agent);
            if (existAgent) {
                dataMap.put(XcbConstantValue.MSG, "\u6b64\u533a\u57df\u5df2\u6709\u533a\u57df\u4ee3\u7406\u5546");
                dataMap.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            dataMap.put("existAgent", existAgent);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_VALIDATE_AGENTEXIST_CPY, "\u67e5\u8be2\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }

    private boolean validateExistAgent_cpy(Tb_agent agent) {
        boolean existAgent = true;
        boolean existSjAgent = false;
        boolean isSjdls = false;
        try {
            if (agent != null) {
                String city = agent.getSr_agent_region_city();
                String province = agent.getSr_agent_region_province();
                String district = agent.getSr_agent_region_district();
                Integer agentId = agent.getSd_agent_id();
                if (XcbStringUtils.isNotBlank((CharSequence)city) && XcbStringUtils.isNotBlank((CharSequence)province)) {
                    Tb_agent queryAgent = new Tb_agent();
                    queryAgent.setSr_agent_region_city(city);
                    queryAgent.setSr_agent_region_province(province);
                    queryAgent.setSr_agent_region_district(district);
                    queryAgent.setSd_agent_id(agentId);
                    queryAgent.setSr_role(agent.getSr_role());
                    Tb_agent queryAgent2 = new Tb_agent();
                    queryAgent2.setSr_agent_region_city(city);
                    queryAgent2.setSr_agent_region_province(province);
                    queryAgent2.setSr_agent_type(agent.getSr_agent_type());
                    queryAgent2.setSd_agent_id(agentId);
                    List<Tb_agent> dbAgent = this.agentDao.findByAgentRegion_cpy(queryAgent);
                    List<Tb_agent> dbAgent2 = this.agentDao.findByAgentRegion_cpy(queryAgent2);
                    if ("SJDLS".equals(agent.getSr_agent_type())) {
                        isSjdls = true;
                    }
                    if (dbAgent.size() == 0 || isSjdls && dbAgent2.size() == 0) {
                        existAgent = false;
                    }
                }
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_VALIDATE_AGENTEXIST_CPY, "\u67e5\u8be2\u5931\u8d25", (Throwable)e);
        }
        return existAgent;
    }

    public Map<String, Object> findAgentByParam_cpy(Identifier identifier, Tb_agent agent, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            agent.setSr_way(XcbConstantValue.LOGIN_WAY);
            List<Tb_agent> agents = this.agentDao.findAgentByParam_cpy(agent, page);
            int totalCount = this.agentDao.findCountByParam_cpy(agent);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("agents", agents);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_BYPARAM_CPY, PromptProperties.getProperty("agent.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findAgentMoneyByParam(Identifier identifier, Tb_agent agent, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            agent.setSr_way(XcbConstantValue.LOGIN_WAY);
            List<Tb_agent> agents = this.agentDao.findAgentMoneyByParam_cpy(agent, page);
            int totalCount = this.agentDao.findCountMoneyByParam_cpy(agent);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("agents", agents);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_MONEY_BYPARAM_CPY, PromptProperties.getProperty("agent.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findStaffByParam_cpy(Identifier identifier, Tb_agent agent, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_agent> agents = this.agentDao.findStaffByParam_cpy(agent, page);
            int totalCount = this.agentDao.findStaffCountByParam_cpy(agent);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("agents", agents);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_STAFF_BYPARAM_CPY, PromptProperties.getProperty("agent.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Integer getMaxPassCnt() {
        Integer cnt = 6;
        try {
            Map<String, Object> sysParam = this.systemParamCache.getSysParamByType(XcbConstantValue.XTCL, XcbConstantValue.MMCS);
            String passCntStr = XcbStringUtils.getObjtoString((Object)sysParam.get("label"));
            if (passCntStr != null) {
                cnt = XcbStringUtils.getObjtoint((Object)passCntStr);
            }
        }
        catch (Exception e) {
            this.log.info("Error Msg: \u83b7\u5f97\u7cfb\u7edf\u8bbe\u7f6e\u6700\u5927\u5bc6\u7801\u8f93\u9519\u6b21\u6570 \u5f02\u5e38");
        }
        return cnt;
    }

    private Map<String, Object> sendSms(Identifier identifier, Tb_agent agent) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Map<String, Object> sysMap = this.systemParamCache.getSysParamByType(XcbConstantValue.XTCL, XcbConstantValue.YZMCS);
            String maxCount = (String)sysMap.get("label");
            boolean isSuccess = true;
            Tb_agent oldAgent = this.agentDao.findAgentByUserName_agent(agent.getSr_user_name());
            Tb_agent newAgent = new Tb_agent();
            boolean flag = true;
            flag = oldAgent.getTm_verifycode_time() != null ? DateUtil.isSameDate(oldAgent.getTm_verifycode_time(), new Date()) : false;
            int verifycode_count = 0;
            if (flag) {
                verifycode_count = oldAgent.getSi_verifycode_count();
            }
            if (verifycode_count >= Integer.valueOf(maxCount)) {
                isSuccess = false;
                ret.put(XcbConstantValue.MSG, "\u5f53\u65e5\u77ed\u4fe1\u53d1\u9001\u6b21\u6570\u6700\u591a\u4e3a3\u6b21,\u8bf7\u660e\u5929\u518d\u8bd5\uff01!");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            if (isSuccess) {
                String verifyCode = String.valueOf(new Random().nextInt(8999) + 1000);
                Tb_company company = this.companyDao.findCompanyById(oldAgent.getSw_company_id());
                String signName = company.getSr_sms_signName();
                String templateCode = company.getSr_sms_mould_other();
                SendSmsResponse sendSmsResponse = SmsUtils.getloginSms(verifyCode, signName, agent.getSr_user_name(), templateCode);
                if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
                    newAgent.setSr_user_name(agent.getSr_user_name());
                    newAgent.setSd_agent_id(oldAgent.getSd_agent_id());
                    newAgent.setTm_verifycode_time(new Date());
                    newAgent.setSi_verifycode_count(verifycode_count + 1);
                    newAgent.setSr_verifycode(verifyCode);
                    int result = this.agentDao.updateSmsById(newAgent);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        ret.put(XcbConstantValue.MSG, "\u77ed\u4fe1\u9a8c\u8bc1\u7801\u8bf7\u6c42\u6210\u529f!");
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, "\u66f4\u65b0\u7528\u6237\u6570\u636e\u5f02\u5e38");
                    }
                } else {
                    String message = sendSmsResponse.getMessage();
                    if (message != null) {
                        String[] msgArr = message.split(":");
                        Integer msgCode = Integer.valueOf(msgArr[1]);
                        if (XcbConstantValue.ALI_FAIL_1.equals(msgCode)) {
                            ret.put(XcbConstantValue.MSG, "\u4e00\u5206\u949f\u5185\u53ea\u80fd\u53d1\u9001\u4e00\u6761\u77ed\u4fe1\u9a8c\u8bc1\u7801,\u8bf7\u52ff\u9891\u7e41\u64cd\u4f5c!");
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        } else if (XcbConstantValue.ALI_FAIL_5.equals(msgCode)) {
                            ret.put(XcbConstantValue.MSG, "\u4e00\u5c0f\u65f6\u5185\u77ed\u4fe1\u53d1\u9001\u6761\u6570\u4e0d\u8d85\u8fc75\u6761,\u8bf7\u7a0d\u540e\u518d\u8bd5!");
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        } else if (XcbConstantValue.ALI_FAIL_10.equals(msgCode)) {
                            ret.put(XcbConstantValue.MSG, "\u5f53\u5929\u77ed\u4fe1\u53d1\u9001\u6761\u6570\u4e0d\u8d85\u8fc710\u6761!,\u8bf7\u660e\u65e5\u518d\u8bd5");
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        } else {
                            ret.put(XcbConstantValue.MSG, "\u77ed\u4fe1\u9a8c\u8bc1\u7801\u8bf7\u6c42\u5931\u8d25!");
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        }
                    } else {
                        ret.put(XcbConstantValue.MSG, "\u77ed\u4fe1\u9a8c\u8bc1\u7801\u8bf7\u6c42\u5931\u8d25!");
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    }
                }
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_SEND_SMS, "\u77ed\u4fe1\u9a8c\u8bc1\u7801\u8bf7\u6c42\u5931\u8d25", (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> findUserRolesByUserId(Identifier identifier, Integer sd_agent_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Tb_agent_roles_rel> cuserRoles = this.roleRelDao.findByCuserId(sd_agent_id);
            ret_method.put(XcbConstantValue.DATA, cuserRoles);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_ROLE_FIND_BYUSERID, PromptProperties.getProperty("cuser.find.role.error"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    Map<String, Object> updateUserRolesByUserId(Identifier identifier, Integer sd_agent_id, String[] roleArr) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            this.roleRelDao.deleteByCuserId(sd_agent_id);
            ArrayList<Tb_agent_roles_rel> userRoles = new ArrayList<Tb_agent_roles_rel>();
            Date current = new Date();
            for (int i = 0; i < roleArr.length; ++i) {
                Tb_agent_roles_rel userRole = new Tb_agent_roles_rel();
                userRole.setSw_agent_id(sd_agent_id);
                userRole.setSw_roles_id(Integer.valueOf(roleArr[i]));
                userRole.setTm_createdate(current);
                userRole.setSi_createuser(identifier.getUserId());
                userRoles.add(userRole);
            }
            if (userRoles.size() > 0) {
                this.roleRelDao.insertUserRoleByBatch(userRoles);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_ROLE_UPDATE_BYUSERID, PromptProperties.getProperty("cuser.update.auth.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findAllUserByAgentId(Identifier identifier, Tb_agent agent, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_agent> agents = this.agentDao.findAllUserByAgentId(agent, page);
            int totalCount = this.agentDao.findAllUserCount(agent);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("agents", agents);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_FIND_ALL_USER_BYAGENT, PromptProperties.getProperty("agent.user.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    public Map<String, Object> deleteAgentById(Identifier identifier, Integer sd_agent_id) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            int result = this.agentDao.deleteAgentById(sd_agent_id);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                this.roleRelDao.deleteByCuserId(sd_agent_id);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.delete.success"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("agent.delete.fail"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_DELETE, PromptProperties.getProperty("agent.delete.fail"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> findUserAuthsByUserId(Identifier identifier, Integer sd_agent_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Object>> dataMap = new HashMap<String, List<Object>>();
        try {
            List<Tb_agent_authorities> cuserAuths = this.authDao.findAuthsByCuserId(sd_agent_id);
            List<String> netList = this.roleRelDao.findNetArrByAgentId(sd_agent_id);
            dataMap.put("cuserAuths", cuserAuths);
            dataMap.put("netList", netList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_AUTH_FIND_BYUSERID, "\u67e5\u627e\u7528\u6237\u89d2\u8272\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> identity_certificate(Identifier identifier, Tb_agent a) {
        Map<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_agent agent = this.agentDao.findAgentById(a.getSd_agent_id());
            if (XcbStringUtils.isNullOrBlank((Object)agent.getSr_account()) || XcbStringUtils.isNullOrBlank((Object)agent.getSr_account_name()) || XcbStringUtils.isNullOrBlank((Object)agent.getSr_accounter_id()) || XcbStringUtils.isNullOrBlank((Object)agent.getSr_bank())) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u94f6\u884c\u5361\u6216\u8eab\u4efd\u8bc1\u4fe1\u606f\u4e0d\u80fd\u4e3a\u7a7a");
            } else {
                Tb_wx_pay_info info = this.wxPayInfoDao.findDefaultPayOut(agent.getSw_company_id());
                ret_method = this.wxSdjAPICommon.identity_certificate(identifier, info, agent);
                int result = XcbStringUtils.getObjtoint((Object)ret_method.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Map dataMap = (Map)ret_method.get(XcbConstantValue.DATA);
                    agent.setSr_txn_order(XcbStringUtils.getObjtoString(dataMap.get("txnOrderNo")));
                    agent.setSr_txn_order_time(XcbStringUtils.getObjtoString(dataMap.get("txnOrderTime")));
                    agent.setSr_txn_org_order(XcbStringUtils.getObjtoString(dataMap.get("txnOrgOrder")));
                    agent.setSr_txn_org_order_time(XcbStringUtils.getObjtoString(dataMap.get("txnOrgOrderTime")));
                    result = this.agentDao.updateAgentById_agent(agent);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret_method.put(XcbConstantValue.DATA, agent);
                        ret_method.put(XcbConstantValue.MSG, "\u8eab\u4efd\u8ba4\u8bc1\u6210\u529f");
                    } else {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u8ba4\u8bc1\u4fe1\u606f\u66f4\u65b0\u5931\u8d25");
                    }
                }
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_IDENTITY_CERTIFICATE, "\u8eab\u4efd\u8ba4\u8bc1\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> binding(Identifier identifier, Tb_agent a) {
        Map<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_agent agent = this.agentDao.findAgentById(a.getSd_agent_id());
            if (XcbStringUtils.isNullOrBlank((Object)agent.getSr_txn_order()) || XcbStringUtils.isNullOrBlank((Object)agent.getSr_txn_order_time())) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u8bf7\u5148\u8fdb\u884c\u8eab\u4efd\u8ba4\u8bc1\uff0c\u8ba4\u8bc1\u8ba2\u5355\u53f7\u4ee5\u53ca\u8ba4\u8bc1\u65f6\u95f4\u4e3a\u7a7a");
            } else {
                Tb_wx_pay_info info = this.wxPayInfoDao.findDefaultPayOut(agent.getSw_company_id());
                ret_method = this.wxSdjAPICommon.binding(identifier, info, agent);
                int result = XcbStringUtils.getObjtoint((Object)ret_method.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Map dataMap = (Map)ret_method.get(XcbConstantValue.DATA);
                    agent.setSr_txn_bindno(XcbStringUtils.getObjtoString(dataMap.get("bindingNo")));
                    result = this.agentDao.updateAgentById_agent(agent);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret_method.put(XcbConstantValue.DATA, agent);
                        ret_method.put(XcbConstantValue.MSG, "\u8eab\u4efd\u7ed1\u5b9a\u6210\u529f");
                    } else {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u7ed1\u5b9a\u4fe1\u606f\u66f4\u65b0\u5931\u8d25");
                    }
                }
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_IDENTITY_BINDING, "\u8eab\u4efd\u7ed1\u5b9a\u5efa\u7acb\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> bindingCpy(Identifier identifier, Tb_agent a) {
        Map<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_agent agent = this.agentDao.findAgentById(a.getSd_agent_id());
            if (XcbStringUtils.isNullOrBlank((Object)agent.getSr_bank()) || XcbStringUtils.isNullOrBlank((Object)agent.getSr_accounter_id()) || XcbStringUtils.isNullOrBlank((Object)agent.getSr_account()) || XcbStringUtils.isNullOrBlank((Object)agent.getSr_account_name()) || XcbStringUtils.isNullOrBlank((Object)agent.getSr_bank_cnapsno())) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u8bf7\u586b\u5199\u5bf9\u516c\u94f6\u884c\u4ee5\u53ca\u516c\u53f8\u4fe1\u606f");
            } else {
                Tb_wx_pay_info info = this.wxPayInfoDao.findDefaultPayOut(agent.getSw_company_id());
                ret_method = this.wxSdjAPICommon.binding_cpy(identifier, info, agent);
                int result = XcbStringUtils.getObjtoint((Object)ret_method.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Map dataMap = (Map)ret_method.get(XcbConstantValue.DATA);
                    agent.setSr_txn_bindno(XcbStringUtils.getObjtoString(dataMap.get("bindingNo")));
                    result = this.agentDao.updateAgentById_agent(agent);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret_method.put(XcbConstantValue.DATA, agent);
                        ret_method.put(XcbConstantValue.MSG, "\u8eab\u4efd\u7ed1\u5b9a\u6210\u529f");
                    } else {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u7ed1\u5b9a\u4fe1\u606f\u66f4\u65b0\u5931\u8d25");
                    }
                }
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_IDENTITY_BINDING, "\u8eab\u4efd\u7ed1\u5b9a\u5efa\u7acb\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> binding_terminate(Identifier identifier, Tb_agent a) {
        Map<String, Object> ret_method = new HashMap<String, String>();
        try {
            Tb_agent agent = this.agentDao.findAgentById(a.getSd_agent_id());
            if (XcbStringUtils.isNullOrBlank((Object)agent.getSr_txn_bindno())) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u5148\u5f55\u5165\u7ed1\u5b9a\u53f7");
            } else {
                Tb_wx_pay_info info = this.wxPayInfoDao.findDefaultPayOut(agent.getSw_company_id());
                ret_method = this.wxSdjAPICommon.binding_terminate(identifier, info, agent);
                int result = XcbStringUtils.getObjtoint(ret_method.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Map dataMap = (Map)ret_method.get(XcbConstantValue.DATA);
                    agent.setSr_txn_bindno("");
                    result = this.agentDao.updateAgentById_agent(agent);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        ret_method.put(XcbConstantValue.STATUS, (String)((Object)XcbConstantValue.OPERA_SUCCESS));
                        ret_method.put(XcbConstantValue.DATA, (String)agent);
                        ret_method.put(XcbConstantValue.MSG, (String)((Object)"\u89e3\u7ed1\u6210\u529f"));
                    } else {
                        ret_method.put(XcbConstantValue.STATUS, (String)((Object)XcbConstantValue.OPERA_FAIL));
                        ret_method.put(XcbConstantValue.MSG, (String)((Object)"\u7ed1\u5b9a\u4fe1\u606f\u66f4\u65b0\u5931\u8d25"));
                    }
                }
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_IDENTITY_UNBINDING, "\u8eab\u4efd\u7ed1\u5b9a\u5efa\u7acb\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }
}

