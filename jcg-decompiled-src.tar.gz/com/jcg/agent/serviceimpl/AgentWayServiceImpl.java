/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_agent_way
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentWayDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_agent_way;
import com.jcg.common.BaseService;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AgentWayServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private AgentWayDao agentWayDao;
    @Autowired
    private AgentDao agentDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_agent_way agentWay = new Tb_agent_way();
        if (param != null) {
            agentWay = (Tb_agent_way)param.get("agentWay");
        }
        try {
            if (XcbConstantValue.AGENT_WAY_CREATE.equals(functionCode)) {
                ret = this.createAgentWay(identifier, agentWay);
            } else if (XcbConstantValue.AGENT_WAY_FIND_BYNAME.equals(functionCode)) {
                ret = this.findUserName(identifier, agentWay.getSr_user_name());
            } else if (XcbConstantValue.AGENT_WAY_UPDATE_BYNAME.equals(functionCode)) {
                ret = this.updateAgentWay(identifier, agentWay);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> createAgentWay(Identifier identifier, Tb_agent_way agentWay) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        try {
            Tb_agent_way agent = this.agentWayDao.findUserName(agentWay.getSr_old_user_name());
            if (agent != null) {
                agentWay.setSr_way(agent.getSr_way());
                result = this.agentWayDao.updateAgentWay(agentWay);
            } else {
                result = this.agentWayDao.createAgentWay(agentWay);
            }
            if (result > 0) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, "\u64cd\u4f5c\u6210\u529f");
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.STATUS, "\u64cd\u4f5c\u5931\u8d25");
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_WAY_CREATE, "\u65b0\u589e\u6216\u66f4\u65b0\u4fe1\u606f\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> updateAgentWay(Identifier identifier, Tb_agent_way agentWay) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        try {
            result = this.agentWayDao.updateAgentWay(agentWay);
            if (result > 0) {
                Tb_agent agent = this.agentDao.findAgentByUserName_agent(agentWay.getSr_old_user_name());
                if (agent != null) {
                    List<String> shopList = this.agentDao.findShopList(agent.getSd_agent_id());
                    for (String sr_user_name : shopList) {
                        Tb_agent_way way = new Tb_agent_way();
                        way.setSr_old_user_name(sr_user_name);
                        way.setSr_way(agentWay.getSr_way());
                        way.setSr_remark(agentWay.getSr_remark());
                        this.agentWayDao.updateAgentWay(way);
                    }
                }
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, "\u66f4\u65b0\u6210\u529f");
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.STATUS, "\u66f4\u65b0\u5931\u8d25");
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_WAY_UPDATE_BYNAME, "\u66f4\u65b0\u4fe1\u606f\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findUserName(Identifier identifier, String sr_user_name) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_agent_way> dataMap = new HashMap<String, Tb_agent_way>();
        try {
            Tb_agent_way agentWay = this.agentWayDao.findUserName(sr_user_name);
            dataMap.put("agentWay", agentWay);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_WAY_FIND_BYNAME, "\u67e5\u8be2\u4fe1\u606f\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }
}

