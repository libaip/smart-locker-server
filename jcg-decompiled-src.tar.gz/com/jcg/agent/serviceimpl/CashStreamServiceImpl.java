/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_cash_stream
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentRolesRelDao;
import com.jcg.agent.idao.CashStreamDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_cash_stream;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CashStreamServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private CashStreamDao cashStreamDao;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private AgentRolesRelDao roleRelDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=========CashStreamServiceImpl========start " + identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_cash_stream cashstream = new Tb_cash_stream();
        Page page = new Page();
        if (param != null) {
            cashstream = (Tb_cash_stream)param.get("cashstream");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.CASH_FIND_BYCASH.equals(functionCode)) {
                ret = this.findCashStreamByCash_agent(identifier, cashstream, page);
            } else if (XcbConstantValue.CASH_UPDATE.equals(functionCode)) {
                cashstream.setTm_modify_time(new Date());
                ret = this.updateCashStreamById_agent(identifier, cashstream);
            } else if (XcbConstantValue.CASH_FIND_BYCASH_CPY.equals(functionCode)) {
                ret = this.findCashStreamByCash_cpy(identifier, cashstream, page);
            } else if (XcbConstantValue.CASH_FIND_BYAGENTMB.equals(functionCode)) {
                String dateRange = XcbStringUtils.getObjtoString((Object)param.get("dateRange"));
                ret = this.findMbAgentCashStream(cashstream, dateRange, page);
            } else if (XcbConstantValue.CASH_FIND_BYAPP_CPY.equals(functionCode)) {
                String dateRange = XcbStringUtils.getObjtoString((Object)param.get("dateRange"));
                ret = this.findMbCpyCashStream(cashstream, dateRange, page);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findCashStreamByCash_agent(Identifier identifier, Tb_cash_stream cashStream, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(cashStream.getSw_agent_id());
            Object subArr = null;
            List<Tb_cash_stream> cashstreams = this.cashStreamDao.findCashStreamByCash_agent(cashStream, page);
            int totalCount = this.cashStreamDao.findCountCashStreamByCash_agent(cashStream);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("cashstreams", cashstreams);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CASH_FIND_BYCASH, PromptProperties.getProperty("cash.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateCashStreamById_agent(Identifier identifier, Tb_cash_stream tb_cash_stream) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = this.cashStreamDao.updateCashStreamByCash_agent(tb_cash_stream);
            if (result > 0) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("cash.update.success"));
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("cash.update.fail"));
            }
            ret_method.put(XcbConstantValue.STATUS, result);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CASH_UPDATE, PromptProperties.getProperty("cash.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findCashStreamByCash_cpy(Identifier identifier, Tb_cash_stream cashStream, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_cash_stream> cashstreams = this.cashStreamDao.findCashStreamByCash_cpy(cashStream, page);
            int totalCount = this.cashStreamDao.findCountCashStreamByCash_cpy(cashStream);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("cashstreams", cashstreams);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CASH_FIND_BYCASH_CPY, PromptProperties.getProperty("cash.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findMbAgentCashStream(Tb_cash_stream cashStream, String dateRange, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            if (XcbStringUtils.isNullOrBlank((Object)dateRange) || "today".equals(dateRange)) {
                cashStream.setSr_cashflow_time_start(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                cashStream.setSr_cashflow_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else if ("yesterday".equals(dateRange)) {
                cashStream.setSr_cashflow_time(XcbDateUtil.getBeforeDay((Date)new Date(), (int)1, (String)"yyyy-MM-dd"));
            } else if ("week".equals(dateRange)) {
                cashStream.setSr_cashflow_time_start(XcbDateUtil.getBeforeDay((Date)new Date(), (int)7, (String)"yyyy-MM-dd"));
                cashStream.setSr_cashflow_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else if ("month".equals(dateRange)) {
                cashStream.setSr_cashflow_time_start(XcbDateUtil.getBeforeDay((Date)new Date(), (int)30, (String)"yyyy-MM-dd"));
                cashStream.setSr_cashflow_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else {
                cashStream.setSr_cashflow_time_start(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                cashStream.setSr_cashflow_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            }
            List<Tb_cash_stream> cashStreams = null;
            int totalCount = 0;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(cashStream.getSw_agent_id());
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                String[] netArr = netList.get(0).split(",");
                cashStream.setNetArr(netArr);
                cashStreams = this.cashStreamDao.findCashStreamByNetArr_Agentmb(cashStream, page);
                totalCount = this.cashStreamDao.findCountByNetArr_Agentmb(cashStream);
            } else {
                cashStreams = this.cashStreamDao.findCashStreamByParam_Agentmb(cashStream, page);
                totalCount = this.cashStreamDao.findCountByParam_Agentmb(cashStream);
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("cashStreams", cashStreams);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CASH_FIND_BYAGENTMB, PromptProperties.getProperty("cash.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findMbCpyCashStream(Tb_cash_stream cashStream, String dateRange, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            if (XcbStringUtils.isNullOrBlank((Object)dateRange) || "today".equals(dateRange)) {
                cashStream.setSr_cashflow_time_start(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                cashStream.setSr_cashflow_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else if ("yesterday".equals(dateRange)) {
                cashStream.setSr_cashflow_time(XcbDateUtil.getBeforeDay((Date)new Date(), (int)1, (String)"yyyy-MM-dd"));
            } else if ("week".equals(dateRange)) {
                cashStream.setSr_cashflow_time_start(XcbDateUtil.getBeforeDay((Date)new Date(), (int)7, (String)"yyyy-MM-dd"));
                cashStream.setSr_cashflow_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else if ("month".equals(dateRange)) {
                cashStream.setSr_cashflow_time_start(XcbDateUtil.getBeforeDay((Date)new Date(), (int)30, (String)"yyyy-MM-dd"));
                cashStream.setSr_cashflow_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else {
                cashStream.setSr_cashflow_time_start(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                cashStream.setSr_cashflow_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            }
            List<Tb_cash_stream> cashStreams = null;
            int totalCount = 0;
            cashStreams = this.cashStreamDao.findCashStreamByParam_Cpymb(cashStream, page);
            totalCount = this.cashStreamDao.findCountByParam_Cpymb(cashStream);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("cashStreams", cashStreams);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CASH_FIND_BYAPP_CPY, PromptProperties.getProperty("cash.find.error"), (Throwable)e);
        }
        return ret_method;
    }
}

