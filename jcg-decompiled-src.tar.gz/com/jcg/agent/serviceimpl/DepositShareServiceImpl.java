/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_deposit_share
 *  com.jcg.agent.model.Tb_withdrawal_appl
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  org.apache.commons.lang.StringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.DepositShareDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.idao.WithdrawalApplDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_deposit_share;
import com.jcg.agent.model.Tb_withdrawal_appl;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class DepositShareServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private DepositShareDao depositShareDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private WithdrawalApplDao withdrawalApplDao;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private CommonLogic commonLogic;

    @Transactional(rollbackFor={Exception.class})
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========DepositShareServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_deposit_share share = new Tb_deposit_share();
        Page page = new Page();
        if (param != null) {
            share = (Tb_deposit_share)param.get("share");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.DEPOSIT_SHARE_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createDepositShare(identifier, share);
            } else if (XcbConstantValue.DEPOSIT_SHARE_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findDepositShareByParam_cpy(identifier, share, page);
            } else if (XcbConstantValue.DEPOSIT_SHARE_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findDepositShareByParam(identifier, share, page);
            } else if (XcbConstantValue.DEPOSIT_SHARE_UPDATE.equalsIgnoreCase(functionCode)) {
                ret = this.updateDepositShare(identifier, share);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    @Transactional(rollbackFor={Exception.class})
    public Map<String, Object> createDepositShare(Identifier identifier, Tb_deposit_share share) {
        this.log.info("############\u590d\u6838\u64cd\u4f5c Start############");
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        String msg = "";
        try {
            if (XcbStringUtils.getObjToBigDecimal((Object)share.getDc_money()).compareTo(BigDecimal.ZERO) <= 0) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u5e94\u5f97\u8fd4\u73b0\u91d1\u989d\u4e0d\u80fd\u4e3a0");
                return ret_method;
            }
            if (XcbStringUtils.getObjToBigDecimal((Object)share.getDc_money()).compareTo(share.getDc_save_money()) > 0) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u5e94\u5f97\u8fd4\u73b0\u91d1\u989d\u4e0d\u80fd\u8d85\u8fc7\u7559\u5b58\u91d1\u989d");
                return ret_method;
            }
            String lastMaxMonthDate = XcbDateUtil.getLastMaxMonthDate();
            String startDate = XcbDateUtil.getCurrentMonthFirst();
            String endDate = XcbDateUtil.getCurrentMonthLast();
            Tb_agent agent = this.agentDao.findAgentById_agent(share.getSw_agent_id());
            Tb_agent agentUp = this.agentDao.findAgentById_agent(agent.getSi_up_agent());
            share.setSi_up_agent(agent.getSi_up_agent());
            share.setSr_create_time_start(startDate);
            share.setSr_create_time_end(endDate);
            share.setSr_date(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            List<Tb_deposit_share> list = this.depositShareDao.findDepositShareByAgent(share);
            if (list != null && list.size() > 0) {
                msg = PromptProperties.getProperty("share.isExist.warn");
                this.log.info(msg);
            } else {
                share.setSr_status(XcbConstantValue.SHARE_STATUS_YTX);
                result = this.depositShareDao.createDepositShare(share);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        String str;
                        Object[] arr;
                        List<String> orderList_X = this.orderDao.findDepositListByAgentId(share.getSw_agent_id(), XcbConstantValue.ORDER_X, lastMaxMonthDate);
                        List<String> orderList_T = this.orderDao.findDepositListByAgentId(share.getSw_agent_id(), XcbConstantValue.ORDER_T, lastMaxMonthDate);
                        if (orderList_X != null && orderList_X.size() > 0) {
                            arr = orderList_X.toArray(new String[0]);
                            str = StringUtils.join((Object[])arr, (String)",");
                            this.log.info("############X\u4fee\u6539\u4e3aF Start############");
                            this.log.info(str);
                            result = this.orderDao.updateChecked((String[])arr, XcbConstantValue.ORDER_X, XcbConstantValue.ORDER_F);
                            if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                                msg = PromptProperties.getProperty("share.update.x.fail");
                                this.log.info(msg);
                            }
                            this.log.info("############X\u4fee\u6539\u4e3aF End############");
                        }
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            if (orderList_T != null && orderList_T.size() > 0) {
                                arr = orderList_T.toArray(new String[0]);
                                str = StringUtils.join((Object[])arr, (String)",");
                                this.log.info("############T\u4fee\u6539\u4e3aL Start############");
                                this.log.info(str);
                                result = this.orderDao.updateChecked((String[])arr, XcbConstantValue.ORDER_T, XcbConstantValue.ORDER_L);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    isSuccess = true;
                                } else {
                                    msg = PromptProperties.getProperty("share.update.t.fail");
                                    this.log.info(msg);
                                }
                                this.log.info("############T\u4fee\u6539\u4e3aL End############");
                            } else {
                                isSuccess = true;
                            }
                        }
                    }
                } else {
                    msg = PromptProperties.getProperty("share.create.fail");
                    this.log.info(msg);
                }
            }
            if (isSuccess) {
                result = this.commonLogic.updateAgent_admoney(share.getDc_money(), agentUp, XcbConstantValue.TB_TYPE_ADD);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("share.create.success"));
                } else {
                    msg = "\u66f4\u65b0\u5546\u5bb6\u8fd4\u73b0\u4f59\u989d\u5f02\u5e38";
                    TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, msg);
                }
            } else {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, msg);
            }
        }
        catch (Exception e) {
            this.log.info(XcbStringUtils.exceptionToString((Exception)e));
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.DEPOSIT_SHARE_CREATE, msg, (Throwable)e);
        }
        this.log.info("############\u590d\u6838\u64cd\u4f5c End############");
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> findDepositShareByParam_cpy(Identifier identifier, Tb_deposit_share share, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_deposit_share> list = this.depositShareDao.findDepositShareByParam_cpy(share, page);
            int totalCount = this.depositShareDao.findCountByParam_cpy(share);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("list", list);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.info(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.DEPOSIT_SHARE_FIND_BYPARAM_CPY, PromptProperties.getProperty("share.findbyparam.fail"), (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    @Transactional
    public Map<String, Object> updateDepositShare(Identifier identifier, Tb_deposit_share vo) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_deposit_share share = this.depositShareDao.findById(vo.getSd_id());
            Tb_agent agent = this.agentDao.findAgentById_agent(share.getSi_up_agent());
            BigDecimal dc_bonus = agent.getDc_bonus();
            share.setSr_status(XcbConstantValue.SHARE_STATUS_YTX);
            int result = this.depositShareDao.updateStatus(share);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                BigDecimal income = BigDecimalUtil.sub((BigDecimal)share.getDc_money(), (BigDecimal)BigDecimalUtil.mul((BigDecimal)share.getDc_money(), (BigDecimal)BigDecimalUtil.div((BigDecimal)dc_bonus, (BigDecimal)new BigDecimal(100))));
                Tb_withdrawal_appl withdrawalAppl = new Tb_withdrawal_appl();
                withdrawalAppl.setSw_agent_id(share.getSi_up_agent());
                withdrawalAppl.setDc_appl_money(share.getDc_money());
                withdrawalAppl.setDc_income_money(income);
                withdrawalAppl.setSr_type(XcbConstantValue.WITHDRAWAL_APPL_SF);
                withdrawalAppl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_DSP);
                withdrawalAppl.setSi_create_person(share.getSw_agent_id());
                withdrawalAppl.setTm_create_time(new Date());
                withdrawalAppl.setSr_way("3");
                result = this.withdrawalApplDao.createWithdrawalAppl(withdrawalAppl);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("share.update.success"));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                } else {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("share.update.fail"));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("share.update.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        }
        catch (Exception e) {
            this.log.info(XcbStringUtils.exceptionToString((Exception)e));
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.DEPOSIT_SHARE_UPDATE, PromptProperties.getProperty("share.update.fail"), (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> findDepositShareByParam(Identifier identifier, Tb_deposit_share share, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_deposit_share> list = this.depositShareDao.findDepositShareByParam(share, page);
            int totalCount = this.depositShareDao.findCountByParam(share);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("list", list);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.info(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.DEPOSIT_SHARE_FIND_BYPARAM, PromptProperties.getProperty("share.findbyparam.fail"), (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }
}

