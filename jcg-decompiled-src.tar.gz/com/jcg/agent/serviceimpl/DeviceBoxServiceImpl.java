/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.serviceimpl.OrderServiceImpl;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.RedisUtil;
import com.jcg.common.SortUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Transactional
@Service
public class DeviceBoxServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private DeviceDao deviceDao;
    @Autowired
    private DeviceBoxDao deviceBoxDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private RedisUtil redis;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=========DeviceBoxServiceImpl========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_device_box deviceBox = new Tb_device_box();
        Integer sd_box_id = null;
        List deviceBoxList = null;
        if (param != null) {
            deviceBox = (Tb_device_box)param.get("deviceBox");
            sd_box_id = XcbStringUtils.getObjtoint((Object)param.get("sd_box_id"));
            deviceBoxList = (List)param.get("deviceBoxList");
        }
        try {
            if (XcbConstantValue.DEVICE_BOX_FIND_BYDEVICEID.equals(functionCode)) {
                ret = this.findDeviceBoxByDeviceId(identifier, deviceBox);
            } else if (XcbConstantValue.DEVICE_BOX_UPDATE_BATCH.equals(functionCode)) {
                String sr_device_type = XcbStringUtils.getObjtoString((Object)param.get("sr_device_type"));
                String sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                ret = this.batchUpdateDeviceBoxById(identifier, sr_device_type, deviceBox, "", sr_way);
            } else if (XcbConstantValue.DEVICE_BOX_UPDATE_BYID.equals(functionCode)) {
                ret = this.updateDeviceBoxById(identifier, deviceBoxList);
            } else if (XcbConstantValue.DEVICE_BOX_FIND_BYARRID.equals(functionCode)) {
                ret = this.findDeviceBoxByArrId(identifier, deviceBox);
            } else if (XcbConstantValue.DEVICE_BOX_CREATE.equals(functionCode)) {
                ret = this.createDeviceBox_cpy(identifier, deviceBox);
            } else if (XcbConstantValue.DEVICE_BOX_BATCH_CREATE.equals(functionCode)) {
                ret = this.createBatchDeviceBox_cpy(identifier, deviceBox);
            } else if (XcbConstantValue.DEVICE_BOX_DELETE.equals(functionCode)) {
                ret = this.deleteDeviceBox_cpy(identifier, deviceBox);
            } else if (XcbConstantValue.DEVICE_BOX_BATCH_DELETE.equals(functionCode)) {
                ret = this.batchDeleteDeviceBox_cpy(identifier, deviceBox);
            } else if (XcbConstantValue.DEVICE_BOX_FIND_BYMID_DEFAULT.equals(functionCode)) {
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                String sr_box_type = XcbStringUtils.getObjtoString((Object)param.get("sr_box_type"));
                ret = this.findDeviceBoxDefault(identifier, si_mainboard_id, sr_box_type);
            } else if (XcbConstantValue.DEVICE_BOX_FIND_BYPARAM_USER.equals(functionCode)) {
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                String sr_box_type = XcbStringUtils.getObjtoString((Object)param.get("sr_box_type"));
                ret = this.findDeviceBoxByParam_user(identifier, si_mainboard_id, sr_box_type);
            } else if (XcbConstantValue.DEVICE_BOX_UPDATE_BYID_USER.equals(functionCode)) {
                ret = this.updateDeviceBoxById_user(identifier, deviceBox);
            } else if (XcbConstantValue.DEVICE_BOX_FIND_BYID_USER.equals(functionCode)) {
                ret = this.findDeviceBoxById(identifier, sd_box_id);
            } else if (XcbConstantValue.DEVICE_BOX_FIND_BOARD_LIST.equals(functionCode)) {
                ret = this.findBoardList(identifier, deviceBox);
            } else if (XcbConstantValue.DEVICE_BOX_FIND_LIST_WEB.equals(functionCode)) {
                ret = this.findBoxListByWeb(identifier, deviceBox);
            } else if (XcbConstantValue.DEVICE_BOX_UPDATE_BYID_AGENTMB.equals(functionCode)) {
                ret = this.updateDeviceBoxById_agentmb(identifier, deviceBox);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> createDeviceBox_cpy(Identifier identifier, Tb_device_box boxs) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        try {
            Tb_device deviceInDB = this.deviceDao.findDeviceDetailById_agent(boxs.getSw_device_id());
            ArrayList<Tb_device_box> boxsList = new ArrayList<Tb_device_box>();
            boxs.setSi_create_person(identifier.getUserId());
            boxs.setTm_create_time(new Date());
            boxs.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_KY);
            boxs.setSr_box_type(deviceInDB.getSr_default_box_type());
            boxs.setSi_board_number(new Integer(1));
            boxs.setSr_open_type(XcbConstantValue.DEVICE_BOX_OPEN_TYPE_DKS);
            Tb_device_box deviceBox = this.deviceBoxDao.findBoxMaxBoxNumByDeviceId(boxs.getSw_device_id());
            if (deviceBox != null) {
                Integer maxLockNum = deviceBox.getSi_lock_number();
                boxs.setSi_lock_number(Integer.valueOf(maxLockNum + 1));
                boxs.setSr_alias_number(String.format("%02d", maxLockNum + 1));
            } else {
                boxs.setSi_lock_number(new Integer(1));
                boxs.setSr_alias_number(String.format("%02d", 1));
            }
            boxsList.add(boxs);
            result = this.deviceBoxDao.createDeviceBox(boxsList);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                Tb_device device = this.deviceDao.findDeviceDetailById_agent(boxs.getSw_device_id());
                int count = this.deviceBoxDao.findCountByDeviceId(boxs.getSw_device_id());
                Tb_device n_device = new Tb_device();
                n_device.setSi_box_count(Integer.valueOf(count));
                n_device.setSd_device_id(device.getSd_device_id());
                n_device.setSr_cj_function(device.getSr_cj_function());
                result = this.deviceDao.updateDeviceById_agent(n_device);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.create.success"));
                    isSuccess = true;
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.create.fail"));
            }
            if (!isSuccess) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_CREATE, PromptProperties.getProperty("devicebox.create.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> createBatchDeviceBox_cpy(Identifier identifier, Tb_device_box box) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        boolean isSuccess = false;
        int result = 0;
        try {
            Integer si_board_number = box.getSi_board_number();
            Integer si_number = box.getSi_number();
            String sr_box_type = box.getSr_box_type();
            String sw_device_id = box.getSw_device_id();
            if (XcbStringUtils.isNullOrBlank((Object)si_board_number)) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u8bf7\u8f93\u5165\u677f\u53f7");
                return ret;
            }
            if (XcbStringUtils.isNullOrBlank((Object)si_number)) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u8bf7\u8f93\u5165\u683c\u5b50\u6570\u91cf");
                return ret;
            }
            if (XcbStringUtils.isNullOrBlank((Object)sr_box_type)) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u8bf7\u9009\u62e9\u683c\u5b50\u7c7b\u578b");
                return ret;
            }
            if (XcbStringUtils.isNullOrBlank((Object)sw_device_id)) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u4f20\u5165\u53c2\u6570\u5f02\u5e38\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
                return ret;
            }
            Tb_device device = this.deviceDao.findDeviceDetailById_agent(sw_device_id);
            ArrayList<Tb_device_box> boxList = new ArrayList<Tb_device_box>();
            List<Tb_device_box> a_boxList = this.deviceBoxDao.findMaxAliasByDeviceId(box);
            List<Tb_device_box> l_boxList = this.deviceBoxDao.findMaxLockByBoardNo(box);
            if (l_boxList != null && l_boxList.size() > 0) {
                Tb_device_box a_box = a_boxList.get(0);
                Tb_device_box l_box = l_boxList.get(0);
                Integer max_alias = XcbStringUtils.getObjtoint((Object)a_box.getSr_alias_number());
                Integer max_lock = XcbStringUtils.getObjtoint((Object)l_box.getSi_lock_number());
                for (int i = 0; i < si_number; ++i) {
                    Tb_device_box deviceBox = new Tb_device_box();
                    deviceBox.setSw_device_id(sw_device_id);
                    deviceBox.setSr_box_type(sr_box_type);
                    deviceBox.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_KY);
                    deviceBox.setSi_board_number(si_board_number);
                    deviceBox.setSi_lock_number(Integer.valueOf(max_lock + i + 1));
                    deviceBox.setSr_alias_number(String.format("%02d", max_alias + i + 1));
                    deviceBox.setSr_open_type(XcbConstantValue.DEVICE_BOX_OPEN_TYPE_DKS);
                    deviceBox.setSi_create_person(identifier.getUserId());
                    boxList.add(deviceBox);
                }
                result = this.deviceBoxDao.createDeviceBox(boxList);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    isSuccess = true;
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.create.success"));
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.create.fail"));
                }
            } else {
                l_boxList = this.deviceBoxDao.findMaxAliasByDeviceId(box);
                if (l_boxList != null && l_boxList.size() > 0) {
                    Tb_device_box l_box = l_boxList.get(0);
                    Integer max_alias = XcbStringUtils.getObjtoint((Object)l_box.getSr_alias_number());
                    for (int i = 0; i < si_number; ++i) {
                        Tb_device_box deviceBox = new Tb_device_box();
                        deviceBox.setSw_device_id(sw_device_id);
                        deviceBox.setSr_box_type(sr_box_type);
                        deviceBox.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_KY);
                        deviceBox.setSi_board_number(si_board_number);
                        deviceBox.setSi_lock_number(Integer.valueOf(i + 1));
                        deviceBox.setSr_alias_number(String.format("%02d", max_alias + i + 1));
                        deviceBox.setSr_open_type(XcbConstantValue.DEVICE_BOX_OPEN_TYPE_DKS);
                        deviceBox.setSi_create_person(identifier.getUserId());
                        boxList.add(deviceBox);
                    }
                } else {
                    for (int i = 0; i < si_number; ++i) {
                        Tb_device_box deviceBox = new Tb_device_box();
                        deviceBox.setSw_device_id(sw_device_id);
                        deviceBox.setSr_box_type(sr_box_type);
                        deviceBox.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_KY);
                        deviceBox.setSi_board_number(si_board_number);
                        deviceBox.setSi_lock_number(Integer.valueOf(i + 1));
                        deviceBox.setSr_alias_number(String.format("%02d", i + 1));
                        deviceBox.setSr_open_type(XcbConstantValue.DEVICE_BOX_OPEN_TYPE_DKS);
                        deviceBox.setSi_create_person(identifier.getUserId());
                        boxList.add(deviceBox);
                    }
                }
                if ((result = this.deviceBoxDao.createDeviceBox(boxList)) > XcbConstantValue.OPERA_INT_ZERO) {
                    isSuccess = true;
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.create.success"));
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.create.fail"));
                }
            }
            if (isSuccess) {
                int count = this.deviceBoxDao.findCountByDeviceId(sw_device_id);
                Tb_device n_device = new Tb_device();
                n_device.setSi_box_count(Integer.valueOf(count));
                n_device.setSd_device_id(device.getSd_device_id());
                n_device.setSr_cj_function(device.getSr_cj_function());
                this.deviceDao.updateDeviceById_agent(n_device);
            } else {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_BATCH_CREATE, PromptProperties.getProperty("devicebox.create.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> deleteDeviceBox_cpy(Identifier identifier, Tb_device_box box) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        try {
            result = this.deviceBoxDao.deleteDeviceBox(box.getSd_box_id());
            if (result >= XcbConstantValue.OPERA_INT_ZERO) {
                Tb_device device = this.deviceDao.findDeviceDetailById_agent(box.getSw_device_id());
                int count = this.deviceBoxDao.findCountByDeviceId(box.getSw_device_id());
                Tb_device n_device = new Tb_device();
                n_device.setSi_box_count(Integer.valueOf(count));
                n_device.setSd_device_id(device.getSd_device_id());
                n_device.setSr_cj_function(device.getSr_cj_function());
                result = this.deviceDao.updateDeviceById_agent(n_device);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.delete.success"));
                    isSuccess = true;
                }
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.delete.fail"));
            }
            if (!isSuccess) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_DELETE, PromptProperties.getProperty("devicebox.delete.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> batchDeleteDeviceBox_cpy(Identifier identifier, Tb_device_box box) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        try {
            String[] boxArr = box.getBoxArr();
            result = this.deviceBoxDao.batchDeleteDeviceBox(boxArr);
            if (result >= XcbConstantValue.OPERA_INT_ZERO) {
                Tb_device device = this.deviceDao.findDeviceDetailById_agent(box.getSw_device_id());
                int count = this.deviceBoxDao.findCountByDeviceId(box.getSw_device_id());
                Tb_device n_device = new Tb_device();
                n_device.setSi_box_count(Integer.valueOf(count));
                n_device.setSd_device_id(device.getSd_device_id());
                n_device.setSr_cj_function(device.getSr_cj_function());
                result = this.deviceDao.updateDeviceById_agent(n_device);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.batchdelete.success"));
                    isSuccess = true;
                }
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.batchdelete.fail"));
            }
            if (!isSuccess) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_BATCH_DELETE, PromptProperties.getProperty("devicebox.batchdelete.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findBoardList(Identifier identifier, Tb_device_box deviceBox) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<String>> dataMap = new HashMap<String, List<String>>();
        try {
            List<String> boardList = this.deviceBoxDao.findBoardListByDeviceId(deviceBox);
            dataMap.put("boardList", boardList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_FIND_BOARD_LIST, PromptProperties.getProperty("devicebox.findbyid.error"), (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> findBoxListByWeb(Identifier identifier, Tb_device_box deviceBox) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_device_box>> dataMap = new HashMap<String, List<Tb_device_box>>();
        try {
            List<Tb_device_box> boxList = this.deviceBoxDao.findBoxListByWeb(deviceBox);
            dataMap.put("boxList", boxList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_FIND_LIST_WEB, PromptProperties.getProperty("devicebox.findbyid.error"), (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> findDeviceBoxById(Identifier identifier, Integer sd_box_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_device_box> dataMap = new HashMap<String, Tb_device_box>();
        try {
            Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(sd_box_id);
            dataMap.put("deviceBox", deviceBox);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_FIND_BYID_USER, PromptProperties.getProperty("devicebox.findbyid.error"), (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> updateDeviceBoxById_user(Identifier identifier, Tb_device_box deviceBox) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            this.redis.set("DEVICE_BOX_" + deviceBox.getSd_box_id(), XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebyid.success"));
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_UPDATE_BYID_USER, PromptProperties.getProperty("devicebox.updatebyid.error"), (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> findDeviceBoxByDeviceId(Identifier identifier, Tb_device_box deviceBox) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_device_box>> dataMap = new HashMap<String, List<Tb_device_box>>();
        try {
            List<Tb_device_box> deviceBoxList = this.deviceBoxDao.findDeviceBoxByDeviceId_agent(deviceBox);
            for (Tb_device_box box : deviceBoxList) {
                if (!XcbConstantValue.DEVICE_BOX_STATUS_ZY.equals(box.getSr_box_status())) continue;
                Tb_order order = this.orderDao.findNewestOrderByBox(box.getSd_box_id());
                box.setOrder(order);
            }
            dataMap.put("deviceBoxList", deviceBoxList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_FIND_BYDEVICEID, PromptProperties.getProperty("devicebox.findbydeviceid.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findDeviceBoxByArrId(Identifier identifier, Tb_device_box deviceBox) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_device_box>> dataMap = new HashMap<String, List<Tb_device_box>>();
        try {
            List<Tb_device_box> deviceBoxList = this.deviceBoxDao.findDeviceBoxByArrId_agent(deviceBox);
            dataMap.put("deviceBoxList", deviceBoxList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_FIND_BYARRID, PromptProperties.getProperty("devicebox.findbyid.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> batchUpdateDeviceBoxById(Identifier identifier, String sr_device_type, Tb_device_box deviceBox, String type, String sr_way) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = 0;
            String[] strArr = deviceBox.getBoxArr();
            if (strArr != null && strArr.length > 0) {
                for (int i = 0; i < strArr.length; ++i) {
                    Integer sd_box_id = XcbStringUtils.getObjtoint((Object)strArr[i]);
                    Tb_order order = this.orderDao.findNewestOrderByBox(sd_box_id);
                    if (order != null) {
                        Map<String, Object> retMap = this.orderService.finishOrderById(identifier, order.getSd_order_id(), type, sr_way);
                        result = XcbStringUtils.getObjtoint((Object)retMap.get(XcbConstantValue.STATUS));
                        if (result > XcbConstantValue.OPERA_INT_ZERO) continue;
                        TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                        ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebatch.error", order.getSd_order_id()));
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        break;
                    }
                    result = 1;
                }
            }
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebatch.success"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebatch.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_UPDATE_BATCH, PromptProperties.getProperty("devicebox.updatebatch.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateDeviceBoxById(Identifier identifier, List<Tb_device_box> deviceBoxList) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        try {
            for (int i = 0; i < deviceBoxList.size(); ++i) {
                Tb_device_box deviceBox = deviceBoxList.get(i);
                result = this.deviceBoxDao.updateDeviceBoxById(deviceBox);
                if (result != XcbConstantValue.OPERA_INT_ZERO) continue;
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebyid.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebyid.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            ret_method.put(XcbConstantValue.DATA, result);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebyid.success"));
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_PACKAGE_UPDATE, PromptProperties.getProperty("devicebox.updatebyid.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findDeviceBoxDefault(Identifier identifier, String si_mainboard_id, String sr_box_type) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_device_box> dataMap = new HashMap<String, Tb_device_box>();
        boolean isExist = false;
        try {
            Tb_device device = this.deviceDao.findDeviceByMid(si_mainboard_id);
            if (device != null) {
                List<Tb_device_box> deviceBoxList = this.deviceBoxDao.findDeviceBoxByDeviceIdForDefault(device.getSd_device_id(), sr_box_type);
                if (deviceBoxList != null && deviceBoxList.size() > 0) {
                    for (Tb_device_box box : deviceBoxList) {
                        Integer sd_box_id = box.getSd_box_id();
                        String sr_recommend_time = XcbStringUtils.getObjtoString((Object)this.redis.get("DEVICE_BOX_" + sd_box_id));
                        if (!XcbStringUtils.isNullOrBlank((Object)sr_recommend_time)) {
                            isExist = true;
                            box.setSr_recommend_time(sr_recommend_time);
                            continue;
                        }
                        box.setSr_recommend_time("");
                    }
                    if (isExist) {
                        SortUtil.SortDeviceBox(deviceBoxList);
                    }
                    Tb_device_box deviceBox = deviceBoxList.get(0);
                    this.redis.set("DEVICE_BOX_" + deviceBox.getSd_box_id(), XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
                    dataMap.put("deviceBox", deviceBox);
                } else {
                    dataMap.put("deviceBox", null);
                }
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.find.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_FIND_BYMID_DEFAULT, PromptProperties.getProperty("devicebox.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private Map<String, Object> findDeviceBoxByParam_user(Identifier identifier, String si_mainboard_id, String sr_box_type) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_device_box>> dataMap = new HashMap<String, List<Tb_device_box>>();
        try {
            DeviceBoxServiceImpl deviceBoxServiceImpl = this;
            synchronized (deviceBoxServiceImpl) {
                Tb_device device = this.deviceDao.findDeviceByMid(si_mainboard_id);
                if (device != null) {
                    List<Tb_device_box> deviceBoxList = this.deviceBoxDao.findDeviceBoxByParam_user(device.getSd_device_id(), sr_box_type);
                    dataMap.put("deviceBoxList", deviceBoxList);
                    ret_method.put(XcbConstantValue.DATA, dataMap);
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                } else {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.find.fail"));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_FIND_BYPARAM_USER, PromptProperties.getProperty("devicebox.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> updateDeviceBoxById_agentmb(Identifier identifier, Tb_device_box deviceBox) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = this.deviceBoxDao.updateDeviceBoxById(deviceBox);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebyid.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebyid.fail"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_BOX_UPDATE_BYID_AGENTMB, PromptProperties.getProperty("devicebox.updatebyid.error"), (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> updateDeviceBoxByTask(Identifier identifier, Tb_order tb_order) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        if (tb_order != null) {
            Map<String, Object> retMap = this.orderService.finishOrderById(identifier, tb_order.getSd_order_id(), "", "SYSTEM");
            result = XcbStringUtils.getObjtoint((Object)retMap.get(XcbConstantValue.STATUS));
            if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebatch.error", tb_order.getSd_order_id()));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        } else {
            result = 1;
        }
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebatch.success"));
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        } else {
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebatch.fail"));
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        return ret_method;
    }
}

