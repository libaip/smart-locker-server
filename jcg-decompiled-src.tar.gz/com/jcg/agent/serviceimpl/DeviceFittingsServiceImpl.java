/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_fittings
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceFittingsDao;
import com.jcg.agent.model.Tb_device_fittings;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DeviceFittingsServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private DeviceFittingsDao deviceFittingsDao;
    @Autowired
    private DeviceBoxDao deviceBoxDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_device_fittings fittings = new Tb_device_fittings();
        if (param != null) {
            fittings = (Tb_device_fittings)param.get("fittings");
        }
        try {
            if (XcbConstantValue.DEVICE_FITTINGS_CREATE.equals(functionCode)) {
                ret = this.createFittings(identifier, fittings);
            } else if (XcbConstantValue.DEVICE_FITTINGS_FIND_BYBOXID.equals(functionCode)) {
                ret = this.findFittingsByBoxId(identifier, fittings);
            } else if (XcbConstantValue.DEVICE_FITTINGS_FIND_MAX.equals(functionCode)) {
                ret = this.findMaxFittings(identifier, fittings);
            } else if (XcbConstantValue.DEVICE_FITTINGS_UPDATE_BYID.equals(functionCode)) {
                ret = this.updateFittingsById(identifier, fittings);
            } else if (XcbConstantValue.DEVICE_FITTINGS_DELETE_BYID.equals(functionCode)) {
                ret = this.deleteFittingsById(identifier, fittings);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> createFittings(Identifier identifier, Tb_device_fittings fittings) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        try {
            result = this.deviceBoxDao.findCountByBoardAndLock(fittings);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("fittings.check.warn2"));
                this.initResultMap(ret);
                return ret;
            }
            result = this.deviceFittingsDao.findCountByBoardAndLock(fittings);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("fittings.check.warn"));
                this.initResultMap(ret);
                return ret;
            }
            fittings.setTm_create_time(new Date());
            fittings.setSr_create_person(identifier.getUserName());
            result = this.deviceFittingsDao.createFittings(fittings);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("fittings.create.success"));
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("fittings.create.fail"));
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.DEVICE_FITTINGS_CREATE, PromptProperties.getProperty("fittings.create.fail"), (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> findFittingsByBoxId(Identifier identifier, Tb_device_fittings fittings) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, List<Tb_device_fittings>> dataMap = new HashMap<String, List<Tb_device_fittings>>();
        try {
            List<Tb_device_fittings> fittingsList = this.deviceFittingsDao.findFittingsByBoxId(fittings);
            dataMap.put("fittingsList", fittingsList);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.DATA, dataMap);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.DEVICE_FITTINGS_FIND_BYBOXID, PromptProperties.getProperty("fittings.find.fail"), (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> findMaxFittings(Identifier identifier, Tb_device_fittings fittings) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Integer> dataMap = new HashMap<String, Integer>();
        try {
            Integer si_lock_number;
            Integer si_board_number = this.deviceFittingsDao.selectMaxBoradNo(fittings);
            if (si_board_number == 0) {
                si_board_number = 2;
            }
            si_lock_number = (si_lock_number = Integer.valueOf(this.deviceFittingsDao.selectMaxLockNo(fittings))) == 0 ? Integer.valueOf(1) : Integer.valueOf(si_lock_number + 1);
            dataMap.put("si_board_number", si_board_number);
            dataMap.put("si_lock_number", si_lock_number);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.DATA, dataMap);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.DEVICE_FITTINGS_FIND_MAX, PromptProperties.getProperty("fittings.find.fail"), (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> updateFittingsById(Identifier identifier, Tb_device_fittings fittings) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        try {
            fittings.setTm_modify_time(new Date());
            fittings.setSr_modify_person(identifier.getUserName());
            result = this.deviceFittingsDao.updateFittingsById(fittings);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.DATA, PromptProperties.getProperty("fittings.update.success"));
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("fittings.update.fail"));
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.DEVICE_FITTINGS_UPDATE_BYID, PromptProperties.getProperty("fittings.update.fail"), (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> deleteFittingsById(Identifier identifier, Tb_device_fittings fittings) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            int result = this.deviceFittingsDao.deleteFittingsById(fittings);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.DATA, PromptProperties.getProperty("fittings.delete.success"));
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("fittings.delete.fail"));
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.DEVICE_FITTINGS_DELETE_BYID, PromptProperties.getProperty("fittings.delete.fail"), (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }
}

