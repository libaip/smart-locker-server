/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_devicelogs
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentRolesRelDao;
import com.jcg.agent.idao.DeviceLogsDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_devicelogs;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class DeviceLogsServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private DeviceLogsDao deviceLogsDao;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private AgentRolesRelDao roleRelDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=========DeviceLogsServiceImpl========");
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_devicelogs deviceLogs = new Tb_devicelogs();
        Page page = new Page();
        if (param != null) {
            deviceLogs = (Tb_devicelogs)param.get("deviceLogs");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.DEVICE_LOGS_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findDeviceLogsByParam_agent(identifier, deviceLogs, page);
            } else if (XcbConstantValue.DEVICE_LOGS_CHECK.equalsIgnoreCase(functionCode)) {
                ret = this.checkDeviceLogs(deviceLogs);
            } else if (XcbConstantValue.DEVICE_LOGS_FIND_BYPARAM_AGENTMB.equalsIgnoreCase(functionCode)) {
                String dateRange = XcbStringUtils.getObjtoString((Object)param.get("dateRange"));
                ret = this.findDeviceLogsByParam_agentmb(identifier, deviceLogs, dateRange, page);
            } else if (XcbConstantValue.DEVICE_LOGS_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                String dateRange = XcbStringUtils.getObjtoString((Object)param.get("dateRange"));
                ret = this.findDeviceLogsByParam_cpy(identifier, deviceLogs, dateRange, page);
            } else if (XcbConstantValue.DEVICE_LOGS_FIND_OFFONLINE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findOffOnlineByNet(identifier, deviceLogs, page);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findDeviceLogsByParam_agent(Identifier identifier, Tb_devicelogs deviceLogs, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_agent agent = this.agentDao.findAgentById_agent(deviceLogs.getSw_agent_id());
            if (agent != null && "1".equals(agent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(agent.getSd_agent_id());
                subList.add(XcbStringUtils.getObjtoString((Object)deviceLogs.getSw_agent_id()));
                String[] subArr = new String[subList.size()];
                subList.toArray(subArr);
                deviceLogs.setAgentArr(subArr);
                deviceLogs.setSw_agent_id(null);
            }
            List<Tb_devicelogs> deviceLogsList = this.deviceLogsDao.findDeviceLogsByParam_agent(deviceLogs, page);
            int totalCount = this.deviceLogsDao.findCountByParam_agent(deviceLogs);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("deviceLogsList", deviceLogsList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_LOGS_FIND_BYPARAM, PromptProperties.getProperty("device.Logs.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> checkDeviceLogs(Tb_devicelogs deviceLogs) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        boolean isSuccess = false;
        String msg = "";
        try {
            deviceLogs = this.deviceLogsDao.selectByPrimaryKey(deviceLogs.getSw_mid());
            if (deviceLogs != null) {
                if (XcbStringUtils.getObjtoint((Object)deviceLogs.getSi_online()) > XcbConstantValue.OPERA_INT_ZERO) {
                    isSuccess = true;
                    msg = PromptProperties.getProperty("device.logs.check.success");
                } else {
                    msg = PromptProperties.getProperty("device.logs.check.fail");
                }
            } else {
                msg = PromptProperties.getProperty("device.logs.check.fail");
            }
            if (isSuccess) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            ret.put(XcbConstantValue.MSG, msg);
            ret.put(XcbConstantValue.DATA, deviceLogs);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_LOGS_CHECK, PromptProperties.getProperty("device.logs.check.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> findDeviceLogsByParam_agentmb(Identifier identifier, Tb_devicelogs deviceLogs, String dateRange, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_devicelogs> deviceLogsList = null;
            int totalCount = 0;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(deviceLogs.getSw_agent_id());
            if (XcbStringUtils.isNullOrBlank((Object)dateRange) || "today".equals(dateRange)) {
                deviceLogs.setSr_lasttime_start(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                deviceLogs.setSr_lasttime_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                    List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                    if (netList.size() > 0) {
                        String[] netArr = netList.get(0).split(",");
                        deviceLogs.setNetArr(netArr);
                        deviceLogsList = this.deviceLogsDao.findNewDeviceLogsByNetArr_agentmb(deviceLogs, page);
                        totalCount = this.deviceLogsDao.findNewCountByNetArr_agentmb(deviceLogs);
                    }
                } else {
                    deviceLogsList = this.deviceLogsDao.findNewDeviceLogsByParam_agentmb(deviceLogs, page);
                    totalCount = this.deviceLogsDao.findNewCountByParam_agentmb(deviceLogs);
                }
            } else {
                deviceLogs.setSr_lasttime_start(XcbDateUtil.getBeforeDay((Date)new Date(), (int)30, (String)"yyyy-MM-dd"));
                deviceLogs.setSr_lasttime_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                    List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                    if (netList.size() > 0) {
                        String[] netArr = netList.get(0).split(",");
                        deviceLogs.setNetArr(netArr);
                        deviceLogsList = this.deviceLogsDao.findDeviceLogsByNetArr_agentmb(deviceLogs, page);
                        totalCount = this.deviceLogsDao.findCountByNetArr_agentmb(deviceLogs);
                    }
                } else {
                    deviceLogsList = this.deviceLogsDao.findDeviceLogsByParam_agentmb(deviceLogs, page);
                    totalCount = this.deviceLogsDao.findCountByParam_agentmb(deviceLogs);
                }
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("deviceLogs", deviceLogsList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_LOGS_FIND_BYPARAM_AGENTMB, PromptProperties.getProperty("device.Logs.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findDeviceLogsByParam_cpy(Identifier identifier, Tb_devicelogs deviceLogs, String dateRange, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_devicelogs> deviceLogsList = null;
            int totalCount = 0;
            if ("today".equals(dateRange)) {
                deviceLogs.setSr_lasttime_start(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                deviceLogs.setSr_lasttime_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                deviceLogsList = this.deviceLogsDao.findNewDeviceLogsByParam_agentmb(deviceLogs, page);
                totalCount = this.deviceLogsDao.findNewCountByParam_agentmb(deviceLogs);
            } else {
                deviceLogs.setSr_lasttime_start(XcbDateUtil.getBeforeDay((Date)new Date(), (int)30, (String)"yyyy-MM-dd"));
                deviceLogs.setSr_lasttime_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                deviceLogsList = this.deviceLogsDao.findDeviceLogsByParam_agentmb(deviceLogs, page);
                totalCount = this.deviceLogsDao.findCountByParam_agentmb(deviceLogs);
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("deviceLogsList", deviceLogsList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_LOGS_FIND_BYPARAM_CPY, PromptProperties.getProperty("device.Logs.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findOffOnlineByNet(Identifier identifier, Tb_devicelogs deviceLogs, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            deviceLogs.setSr_login_type(XcbConstantValue.LOGIN_WAY);
            List<Map<String, Object>> deviceLogsList = this.deviceLogsDao.findOfflineDevice(deviceLogs, page);
            int totalCount = this.deviceLogsDao.findCountOfflineDevice(deviceLogs);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("deviceLogsList", deviceLogsList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_LOGS_FIND_BYPARAM_CPY, PromptProperties.getProperty("device.Logs.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }
}

