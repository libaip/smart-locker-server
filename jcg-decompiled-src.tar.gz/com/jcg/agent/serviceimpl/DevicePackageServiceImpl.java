/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.DevicePackageDao;
import com.jcg.agent.model.Tb_device_package;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class DevicePackageServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private DevicePackageDao devicePackageDao;
    @Autowired
    private DeviceDao deviceDao;

    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========DevicePackageServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_device_package devicePackage = new Tb_device_package();
        List devicePackageList = null;
        LinkedHashSet devicePackageSet = null;
        Page page = new Page();
        if (param != null) {
            devicePackage = (Tb_device_package)param.get("devicePackage");
            devicePackageList = (List)param.get("devicePackageList");
            devicePackageSet = (LinkedHashSet)param.get("devicePackageSet");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.DEVICE_PACKAGE_CREATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.createDevicePackage(identifier, devicePackageSet);
            } else if (XcbConstantValue.DEVICE_PACKAGE_UPDATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateDevicePackageById(identifier, devicePackageList);
            } else if (XcbConstantValue.DEVICE_PACKAGE_UPDATE_BATCH_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateDevicePackageByBatch(identifier, devicePackageList);
            } else if (XcbConstantValue.DEVICE_PACKAGE_FIND_BYDEVICEID.equalsIgnoreCase(functionCode)) {
                ret = this.findDevicePackageByDeviceId(identifier, devicePackage);
            } else if (XcbConstantValue.DEVICE_PACKAGE_UPDATE.equalsIgnoreCase(functionCode)) {
                ret = this.updateDevicePackageById(identifier, devicePackageList);
            } else if (XcbConstantValue.DEVICE_PACKAGE_UPDATE_BATCH.equalsIgnoreCase(functionCode)) {
                ret = this.updateDevicePackageByBatch(identifier, devicePackageList);
            } else if (XcbConstantValue.DEVICE_PACKAGE_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findDevicePackageById_user(devicePackage.getSd_id());
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findDevicePackageById_user(Integer sd_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_device_package> dataMap = new HashMap<String, Tb_device_package>();
        try {
            Tb_device_package devicePackage = this.devicePackageDao.findDevicePackageById(sd_id);
            dataMap.put("devicePackage", devicePackage);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_PACKAGE_FIND_BYDEVICEID, PromptProperties.getProperty("devicepackage.findbydeviceid.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> createDevicePackage(Identifier identifier, LinkedHashSet<Tb_device_package> devicePackageSet) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = 0;
            result = this.devicePackageDao.createDevicePackage(devicePackageSet);
            if (result > 0) {
                ret_method.put(XcbConstantValue.DATA, result);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicepackage.create.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicepackage.create.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_PACKAGE_CREATE, PromptProperties.getProperty("devicepackage.create.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateDevicePackageById(Identifier identifier, List<Tb_device_package> devicePackageList) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        boolean isAmendLlPkg = false;
        try {
            for (int i = 0; i < devicePackageList.size(); ++i) {
                Tb_device_package devicePackage = new Tb_device_package();
                devicePackage = devicePackageList.get(i);
                result = this.devicePackageDao.updateDevicePackageById(devicePackage);
                if (result != XcbConstantValue.OPERA_INT_ZERO) continue;
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicepackage.updatebyid.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicepackage.updatebyid.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            ret_method.put(XcbConstantValue.DATA, result);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicepackage.updatebyid.success"));
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_PACKAGE_UPDATE, PromptProperties.getProperty("devicepackage.updatebyid.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateDevicePackageByBatch(Identifier identifier, List<Tb_device_package> devicePackageList) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        try {
            for (int i = 0; i < devicePackageList.size(); ++i) {
                Tb_device_package devicePackage = new Tb_device_package();
                devicePackage = devicePackageList.get(i);
                result = this.devicePackageDao.updateDevicePackageByBatch(devicePackage);
                if (result != XcbConstantValue.OPERA_INT_ZERO) continue;
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicepackage.updatebyid.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.DATA, result);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicepackage.updatebybath.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicepackage.updatebybath.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_PACKAGE_UPDATE_BATCH, PromptProperties.getProperty("devicepackage.updatebybath.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findDevicePackageByDeviceId(Identifier identifier, Tb_device_package devicePackage) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_device_package>> dataMap = new HashMap<String, List<Tb_device_package>>();
        try {
            List<Tb_device_package> devicePackageList = this.devicePackageDao.findDevicePackageByDeviceId(devicePackage);
            dataMap.put("devicePackageList", devicePackageList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_PACKAGE_FIND_BYDEVICEID, PromptProperties.getProperty("devicepackage.findbydeviceid.error"), (Throwable)e);
        }
        return ret_method;
    }
}

