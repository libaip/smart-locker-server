/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.agent.model.Tb_device_param
 *  com.jcg.agent.model.Tb_devicelogs
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.company.model.Tb_package
 *  com.jcg.company.model.Tb_sys_param
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  net.sf.json.JSONArray
 *  net.sf.json.JSONObject
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Propagation
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentRolesRelDao;
import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.DeviceLogsDao;
import com.jcg.agent.idao.DevicePackageDao;
import com.jcg.agent.idao.DeviceParamDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_device_package;
import com.jcg.agent.model.Tb_device_param;
import com.jcg.agent.model.Tb_devicelogs;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.serviceimpl.DeviceBoxServiceImpl;
import com.jcg.agent.serviceimpl.NetPointServiceImpl;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.HttpClientUtil;
import com.jcg.common.PromptProperties;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.CompanyDao;
import com.jcg.company.idao.PackageDao;
import com.jcg.company.idao.WxInfoDao;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.company.model.Tb_package;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.user.idao.UserDao;
import com.jcg.user.model.Tb_user;
import com.jcg.wxmsg.serviceimpl.WxMessageServiceImpl;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class DeviceServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private HttpServletRequest request;
    @Autowired
    private DeviceDao deviceDao;
    @Autowired
    private CompanyDao companyDao;
    @Autowired
    private WxInfoDao wxInfoDao;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private PackageDao packageDao;
    @Autowired
    private DevicePackageDao devicePackageDao;
    @Autowired
    private AgentRolesRelDao roleRelDao;
    @Autowired
    private CommonLogic commonLogic;
    @Autowired
    private UserDao userDao;
    @Autowired
    private NetPointServiceImpl netPointServiceImpl;
    @Autowired
    private WxMessageServiceImpl wxMessageService;
    @Autowired
    private RedisUtil redis;
    @Autowired
    private DeviceLogsDao deviceLogsDao;
    @Autowired
    private DeviceParamDao deviceParamDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private DeviceBoxDao deviceBoxDao;
    @Autowired
    private DeviceBoxServiceImpl deviceBoxService;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=========DeviceServiceImpl========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_device device = new Tb_device();
        Tb_device_param deviceParam = new Tb_device_param();
        Page page = new Page();
        if (param != null) {
            device = (Tb_device)param.get("device");
            deviceParam = (Tb_device_param)param.get("deviceParam");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.DEVICE_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findDeviceByParam_agent(identifier, device, page);
            } else if (XcbConstantValue.DEVICE_FIND_BYAGENTID.equalsIgnoreCase(functionCode)) {
                ret = this.findDropDownDeviceByAgentId_agent(identifier, device);
            } else if (XcbConstantValue.DEVICE_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findDeviceDetailById_agent(identifier, device);
            } else if (XcbConstantValue.DEVICE_FIND_BYMID.equalsIgnoreCase(functionCode)) {
                ret = this.findDeviceDetailByMid_agent(identifier, device);
            } else if (XcbConstantValue.DEVICE_UPDATE_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.updateDeviceById_agent(identifier, device);
            } else if (XcbConstantValue.DEVICE_UPDATE_STS_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.updateDeviceByStsId_agent(identifier, device);
            } else if (XcbConstantValue.DEVICE_GENCODE.equalsIgnoreCase(functionCode)) {
                ret = this.genCodeSingle(device);
            } else if (XcbConstantValue.DEVICE_CREATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.createDevice_cpy(identifier, device);
            } else if (XcbConstantValue.DEVICE_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findDeviceByParam_cpy(identifier, device, page);
            } else if (XcbConstantValue.DEVICE_FIND_BYAGENTID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findDropDownDeviceByAgentId_agent(identifier, device);
            } else if (XcbConstantValue.DEVICE_FIND_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findDeviceDetailById_agent(identifier, device);
            } else if (XcbConstantValue.DEVICE_UPDATE_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateDeviceById_agent(identifier, device);
            } else if (XcbConstantValue.DEVICE_UPDATE_STS_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateDeviceByStsId_agent(identifier, device);
            } else if (XcbConstantValue.DEVICE_GENCODE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.genCodeSingle(device);
            } else if (XcbConstantValue.DEVICE_VALIDATE_MAINBOARD.equalsIgnoreCase(functionCode)) {
                ret = this.validateDeviceMainboard(device);
            } else if (XcbConstantValue.DEVICE_FIND_BYNETID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findDropDeviceByNetId(device);
            } else if (XcbConstantValue.DEVICE_FIND_BYMID_USER.equalsIgnoreCase(functionCode)) {
                String sw_user_id = XcbStringUtils.getObjtoString((Object)param.get("sw_user_id"));
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                String sw_device_id = XcbStringUtils.getObjtoString((Object)param.get("sw_device_id"));
                String sr_type = XcbStringUtils.getObjtoString((Object)param.get("sr_type"));
                ret = this.findDeviceByMid_user(identifier, sw_user_id, si_mainboard_id, sw_device_id, sr_type);
            } else if (XcbConstantValue.DEVICE_FIND_BYDEVICE_USER.equalsIgnoreCase(functionCode)) {
                String sr_open_id = XcbStringUtils.getObjtoString((Object)param.get("sr_open_id"));
                String sw_device_id = XcbStringUtils.getObjtoString((Object)param.get("sw_device_id"));
                ret = this.findDeviceByDevice_user(identifier, sr_open_id, sw_device_id);
            } else if (XcbConstantValue.DEVICE_FIND_BYQRCODE_USER.equalsIgnoreCase(functionCode)) {
                String sw_user_id = XcbStringUtils.getObjtoString((Object)param.get("sw_user_id"));
                String sr_wx_qr_code = XcbStringUtils.getObjtoString((Object)param.get("sr_wx_qr_code"));
                ret = this.findDeviceByQrCode_user(identifier, sr_wx_qr_code, sw_user_id);
            } else if (XcbConstantValue.DEVICE_FIND_BYID_USER.equalsIgnoreCase(functionCode)) {
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                ret = this.findDeviceDetailById_user(identifier, si_mainboard_id);
            } else if (XcbConstantValue.DEVICE_REGISTER.equalsIgnoreCase(functionCode)) {
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                ret = this.registerDevice(si_mainboard_id);
            } else if (XcbConstantValue.DEVICE_UPDATE_BYMID_DEVICE.equalsIgnoreCase(functionCode)) {
                ret = this.updateDeviceInfo_device(device);
            } else if (XcbConstantValue.DEVICE_UPDATE_APP_BYMID_DEVICE.equalsIgnoreCase(functionCode)) {
                ret = this.updateAppByMid(device);
            } else if (XcbConstantValue.DEVICE_CREATE_MCUID.equalsIgnoreCase(functionCode)) {
                ret = this.createMcuid(deviceParam);
            } else if (XcbConstantValue.DEVICE_FIND_MCUID.equalsIgnoreCase(functionCode)) {
                ret = this.findDeviceMcuid(deviceParam);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> updateDeviceInfo_device(Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        device.setTm_modify_time(new Date());
        try {
            result = this.deviceDao.updateDeviceInfoById_device(device);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.DEVICE_UPDATE_BYMID_DEVICE, PromptProperties.getProperty("device.update.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findDropDeviceByNetId(Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_device>> dataMap = new HashMap<String, List<Tb_device>>();
        try {
            List<Tb_device> devicList = this.deviceDao.findDeviceByNetpoint_user(device.getSw_netpoint_id());
            dataMap.put("devices", devicList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYNETID_CPY, PromptProperties.getProperty("device.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findDeviceDetailByMid_user(Identifier identifier, String si_mainboard_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_device> dataMap = new HashMap<String, Tb_device>();
        try {
            Tb_device deviceDB = this.deviceDao.findDeviceByMid(si_mainboard_id);
            dataMap.put("device", deviceDB);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYMID_USER, PromptProperties.getProperty("device.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findDeviceByParam_agent(Identifier identifier, Tb_device device, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)device.getSd_agent_id())) {
                device.setSw_agent_id(device.getSd_agent_id());
            }
            List<Tb_device> devices = null;
            int totalCount = 0;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(device.getSw_agent_id());
            String[] subArr = null;
            if (adminAgent != null && "1".equals(adminAgent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                subList.add(XcbStringUtils.getObjtoString((Object)device.getSd_agent_id()));
                subArr = new String[subList.size()];
                subList.toArray(subArr);
                device.setAgentArr(subArr);
                device.setSd_agent_id(null);
            }
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                if (netList.size() > 0) {
                    String[] netArr = netList.get(0).split(",");
                    device.setNetArr(netArr);
                    devices = this.deviceDao.findDeviceByNetArr_agent(device, page);
                    totalCount = this.deviceDao.findCountByNetArr_agent(device);
                }
            } else {
                devices = this.deviceDao.findDeviceByParam_agent(device, page);
                totalCount = this.deviceDao.findCountByParam_agent(device);
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("devices", devices);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYPARAM, PromptProperties.getProperty("device.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findDeviceByParam_cpy(Identifier identifier, Tb_device device, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)device.getSd_agent_id())) {
                device.setSw_agent_id(device.getSd_agent_id());
            }
            List<Tb_device> devices = this.deviceDao.findDeviceByParam_cpy(device, page);
            int totalCount = this.deviceDao.findCountByParam_cpy(device);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("devices", devices);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYPARAM_CPY, PromptProperties.getProperty("device.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findDeviceDetailById_agent(Identifier identifier, Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_device> dataMap = new HashMap<String, Tb_device>();
        try {
            Tb_device deviceDB = this.deviceDao.findDeviceDetailById_agent(device.getSd_device_id());
            dataMap.put("device", deviceDB);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYID, PromptProperties.getProperty("device.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findDeviceDetailById_user(Identifier identifier, String si_mainboard_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_device deviceDB = this.deviceDao.findDeviceDetailById_user(si_mainboard_id);
            dataMap.put("device", deviceDB);
            if (deviceDB != null) {
                Tb_devicelogs logs = this.deviceLogsDao.selectByPrimaryKey(deviceDB.getSi_mainboard_id());
                dataMap.put("logs", logs);
            }
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYID_USER, PromptProperties.getProperty("device.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findDeviceDetailByMid_agent(Identifier identifier, Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_device> dataMap = new HashMap<String, Tb_device>();
        try {
            Tb_device deviceDB = this.deviceDao.findDeviceByMid(device.getSi_mainboard_id());
            dataMap.put("device", deviceDB);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYMID, PromptProperties.getProperty("device.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateDeviceById_agent(Identifier identifier, Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        device.setSr_modify_time(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
        device.setSi_modify_person(identifier.getUserId());
        try {
            result = this.deviceDao.updateDeviceById_agent(device);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.DEVICE_UPDATE_BYID, PromptProperties.getProperty("device.update.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateDeviceByStsId_agent(Identifier identifier, Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        device.setSr_modify_time(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
        device.setSi_modify_person(identifier.getUserId());
        try {
            result = this.deviceDao.updateDeviceByStsId_agent(device);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.DEVICE_UPDATE_BYID, PromptProperties.getProperty("device.update.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> genCodeSingle(Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        CommonLogic commonLogic = new CommonLogic();
        int result = 1;
        Tb_device deviceInDB = this.deviceDao.findDeviceDetailById_agent(device.getSd_device_id());
        if (deviceInDB != null) {
            device.setSw_agent_id(deviceInDB.getSw_agent_id());
            device.setSw_netpoint_id(deviceInDB.getSw_netpoint_id());
            device.setSi_mainboard_id(deviceInDB.getSi_mainboard_id());
            device.setSr_qr_code(deviceInDB.getSr_qr_code());
        }
        if (XcbConstantValue.DEVICE_QR_O.equals(deviceInDB.getSr_qr_type())) {
            String wxResult = this.wxMessageService.GenOtherWxCode(device.getSr_appid(), deviceInDB.getSr_appsecret(), deviceInDB.getSd_device_id());
            commonLogic.genWxGzhCode(ret_method, device, wxResult, this.request);
        } else if (XcbConstantValue.DEVICE_QR_N.equals(deviceInDB.getSr_qr_type())) {
            Tb_company company = this.companyDao.findCompanyById(deviceInDB.getSw_company_id());
            commonLogic.genQrNCode(ret_method, device, company, this.request);
        } else if (XcbConstantValue.DEVICE_QR_A.equals(deviceInDB.getSr_qr_type())) {
            commonLogic.genCode(ret_method, device, this.request);
        } else {
            Tb_wx_info info = this.wxInfoDao.findInfoByCode(deviceInDB.getSr_way());
            String wxResult = this.wxMessageService.GenWxCode(info, deviceInDB.getSd_device_id());
            commonLogic.genWxGzhCode(ret_method, device, wxResult, this.request);
        }
        result = this.deviceDao.updateDeviceById_agent(device);
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.DATA, device);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.update.success"));
        } else {
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.update.fail"));
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> validateDeviceMainboard(Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Boolean> dataMap = new HashMap<String, Boolean>();
        boolean isExistMid = false;
        String si_mainboard_id = device.getSi_mainboard_id();
        String sd_device_id = device.getSd_device_id();
        try {
            List<Tb_device> devices = this.deviceDao.findAllDeviceMainboard_cpy();
            for (Tb_device deviceInfo : devices) {
                String mainboardId = deviceInfo.getSi_mainboard_id();
                String deviceId = deviceInfo.getSd_device_id();
                if (XcbStringUtils.isNullOrBlank((Object)mainboardId)) continue;
                if (XcbStringUtils.isNullOrBlank((Object)sd_device_id)) {
                    if (!si_mainboard_id.equals(mainboardId)) continue;
                    isExistMid = true;
                    break;
                }
                if (!si_mainboard_id.equals(mainboardId) || sd_device_id.equals(deviceId)) continue;
                isExistMid = true;
                break;
            }
            dataMap.put("isExistMid", isExistMid);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_VALIDATE_MAINBOARD, PromptProperties.getProperty("device.validate.mid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findDropDownDeviceByAgentId_agent(Identifier identifier, Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Map<String, Object>>> dataMap = new HashMap<String, List<Map<String, Object>>>();
        try {
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(device.getSw_agent_id());
            String[] subArr = null;
            if (adminAgent != null && "1".equals(adminAgent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                subList.add(XcbStringUtils.getObjtoString((Object)device.getSw_agent_id()));
                subArr = new String[subList.size()];
                subList.toArray(subArr);
                device.setAgentArr(subArr);
                device.setSw_agent_id(null);
            }
            List<Map<String, Object>> devices = this.deviceDao.findDropDownDeviceByAgentId_agent(device);
            dataMap.put("devices", devices);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYAGENTID, PromptProperties.getProperty("device.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> createDevice_cpy(Identifier identifier, Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            String sd_device_id = CommonFunction.getVoucherNum((String)CommonFunction.jqsb_id);
            StringBuffer stringBuffer = new StringBuffer(sd_device_id);
            String sr_rev_device = stringBuffer.reverse().toString();
            Tb_agent agent = this.agentDao.findAgentById_agent(device.getSw_agent_id());
            device.setSi_create_person(identifier.getUserId());
            device.setTm_create_time(new Date());
            device.setSd_device_id(sd_device_id);
            device.setSr_rev_device(sr_rev_device);
            Tb_device device_shortCode = this.deviceDao.findDeviceMaxShortCodeByAgentId_cpy(device.getSw_agent_id());
            String maxShortCode = "";
            if (device_shortCode != null) {
                maxShortCode = device_shortCode.getSr_short_code();
                device.setSr_short_code(CommonFunction.addOne((String)maxShortCode));
            }
            if (XcbConstantValue.DEVICE_QR_O.equals(device.getSr_qr_type())) {
                String wxResult = this.wxMessageService.GenOtherWxCode(device.getSr_appid(), device.getSr_appsecret(), device.getSd_device_id());
                this.commonLogic.genWxGzhCode(ret_method, device, wxResult, this.request);
            } else if (XcbConstantValue.DEVICE_QR_N.equals(device.getSr_qr_type())) {
                Tb_company company = this.companyDao.findCompanyById(agent.getSw_company_id());
                this.commonLogic.genQrNCode(ret_method, device, company, this.request);
            } else if (XcbConstantValue.DEVICE_QR_A.equals(device.getSr_qr_type())) {
                this.commonLogic.genCode(ret_method, device, this.request);
            } else {
                Tb_wx_info info = this.wxInfoDao.findInfoByCode(device.getSr_way());
                String wxResult = this.wxMessageService.GenWxCode(info, device.getSd_device_id());
                this.commonLogic.genWxGzhCode(ret_method, device, wxResult, this.request);
            }
            int result = this.deviceDao.createDevice_cpy(device);
            if (result < XcbConstantValue.OPERA_INT_ZERO) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.create.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            ArrayList boxList = new ArrayList();
            if (result < XcbConstantValue.OPERA_INT_ZERO) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.create.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            Tb_package pkg = new Tb_package();
            pkg.setSr_type(XcbConstantValue.PACKAGE_TYPE_JGSZ);
            List<Tb_package> pkgList = this.packageDao.findPackageParam(pkg);
            LinkedHashSet<Tb_device_package> dpList = new LinkedHashSet<Tb_device_package>();
            for (Tb_package p : pkgList) {
                Tb_device_package dp = new Tb_device_package();
                dp.setSw_package_id(p.getSd_package_id());
                dp.setSw_device_id(device.getSd_device_id());
                dp.setSr_box_type(p.getSr_box_type());
                dp.setDc_once_price(p.getDc_once_price());
                dp.setSi_fee_time(p.getSi_fee_time());
                dp.setSi_max_hour(p.getSi_max_hour());
                dp.setDc_advance_price(p.getDc_advance_price());
                dp.setDc_hour_price(p.getDc_hour_price());
                dp.setSi_time_slot(p.getSi_time_slot());
                dp.setDc_max_xf(p.getDc_max_xf());
                dp.setSr_maxservice_time(p.getSr_maxservice_time());
                dp.setSr_remarks(p.getSr_remarks());
                dp.setSr_wx_remarks(p.getSr_wx_remarks());
                dp.setSr_app_remarks(p.getSr_app_remarks());
                dp.setSi_create_person(identifier.getUserId());
                dpList.add(dp);
            }
            result = this.devicePackageDao.createDevicePackage(dpList);
            if (result < XcbConstantValue.OPERA_INT_ZERO) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicepackage.create.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            dataMap.put("device", device);
            dataMap.put("boxList", boxList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.create.success"));
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CREATE_CPY, PromptProperties.getProperty("device.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findDeviceByMid_user(Identifier identifier, String sw_user_id, String si_mainboard_id, String sw_device_id, String sr_type) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        Map dataMap = new HashMap();
        try {
            this.log.info("\u4e3b\u677f\u53f7:" + si_mainboard_id + ",\u7528\u6237id:" + sw_user_id + ",\u8bbe\u5907\u7f16\u53f7:" + sw_device_id + ",\u7c7b\u578b:" + sr_type);
            Map<String, Object> rtnMap = this.netPointServiceImpl.findNetPointByMid_user(identifier, sw_user_id, si_mainboard_id, sw_device_id, sr_type);
            int result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                dataMap = (Map)rtnMap.get(XcbConstantValue.DATA);
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, rtnMap.get(XcbConstantValue.MSG));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.info("\u5f02\u5e38\u8bbe\u5907:" + si_mainboard_id + "," + sw_device_id + "," + sw_user_id);
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYMID_USER, PromptProperties.getProperty("device.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findDeviceByQrCode_user(Identifier identifier, String sr_wx_qr_code, String sw_user_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        Map<String, Tb_devicelogs> dataMap = new HashMap();
        try {
            Tb_device device = this.deviceDao.findDeviceByQrCode(sr_wx_qr_code);
            if (device != null) {
                Tb_wx_info wx_info = this.wxInfoDao.findInfoByCode(device.getSr_way());
                Tb_user user = new Tb_user();
                if (!XcbStringUtils.isNullOrBlank((Object)sw_user_id)) {
                    user = this.userDao.findUserById(XcbStringUtils.getObjtoint((Object)sw_user_id));
                }
                Map<String, Object> rtnMap = this.netPointServiceImpl.findNetPointByMid_user(identifier, sw_user_id, "", device.getSd_device_id(), "");
                dataMap = (Map)rtnMap.get(XcbConstantValue.DATA);
                if (!XcbStringUtils.isNullOrBlank((Object)sw_user_id)) {
                    HashMap<String, String> pathMap = new HashMap<String, String>();
                    List list = (List)dataMap.get("list");
                    Tb_devicelogs logs = this.deviceLogsDao.selectByPrimaryKey(device.getSi_mainboard_id());
                    dataMap.put("logs", logs);
                    pathMap.put("boxtype", "");
                    String query = "";
                    if ("Y".equals(device.getSr_cj_function())) {
                        pathMap.put("path", "/setting");
                        query = "type=1&mid=" + device.getSi_mainboard_id();
                        pathMap.put("url", "/pages/my/scan/setting?" + query);
                    } else if (list.size() == 1) {
                        pathMap.put("path", "/payinfo");
                        pathMap.put("boxtype", (String)list.get(0));
                        query = "type=2&mid=" + device.getSi_mainboard_id() + "&boxtype=" + (String)list.get(0);
                        pathMap.put("url", "/pages/my/scan/payinfo?" + query);
                    } else {
                        pathMap.put("path", "/choose");
                        query = "type=2&mid=" + device.getSi_mainboard_id();
                        pathMap.put("url", "/pages/my/scan/choose?" + query);
                    }
                    pathMap.put("mid", device.getSi_mainboard_id());
                    pathMap.put("cj", device.getSr_cj_function());
                    String jsonStr = JSONObject.fromObject(pathMap).toString();
                    if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type())) {
                        this.redis.setForTimeMIN(user.getSr_unionid(), jsonStr, 10L);
                    } else if (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type())) {
                        this.redis.setForTimeMIN(user.getSr_app_open_id(), jsonStr, 10L);
                    } else {
                        this.redis.setForTimeMIN(user.getSr_open_id(), jsonStr, 10L);
                    }
                }
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.find.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYQRCODE_USER, PromptProperties.getProperty("device.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findDeviceByDevice_user(Identifier identifier, String sr_open_id, String sw_device_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        Map<String, String> dataMap = new HashMap();
        try {
            String sr_unionid = "";
            Tb_device device = this.deviceDao.findDeviceDetailById_agent(sw_device_id);
            Tb_wx_info wx_info = this.wxInfoDao.findInfoByCode(device.getSr_way());
            this.log.info("\u626b\u7801\u7684\u8bbe\u5907:" + sw_device_id);
            this.log.info("\u626b\u7801\u7684\u7528\u6237openid:" + sr_open_id);
            System.out.println("\u626b\u7801\u7684\u8bbe\u5907:" + sw_device_id);
            System.out.println("\u626b\u7801\u7684\u7528\u6237openid:" + sr_open_id);
            if (!XcbStringUtils.isNullOrBlank((Object)sr_open_id)) {
                Tb_user user = this.userDao.findUserByWxOpenId(sr_open_id);
                if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type())) {
                    sr_unionid = user.getSr_unionid();
                }
            }
            Map<String, Object> rtnMap = this.netPointServiceImpl.findNetInfoByDevice_user(identifier, sw_device_id);
            dataMap = (Map)rtnMap.get(XcbConstantValue.DATA);
            Tb_sys_param sysParam = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.SCAN_TIME);
            if (sysParam != null) {
                int sr_scan_time = XcbStringUtils.getObjtoint((Object)sysParam.getSr_param_value());
                dataMap.put("sr_scan_time", (String)((Object)Integer.valueOf(sr_scan_time)));
            } else {
                dataMap.put("sr_scan_time", (String)((Object)Integer.valueOf(5)));
            }
            if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type())) {
                if (!XcbStringUtils.isNullOrBlank((Object)sr_unionid)) {
                    dataMap.put("sr_unionid", sr_unionid);
                } else {
                    dataMap.put("sr_unionid", "");
                }
            } else if (!XcbStringUtils.isNullOrBlank((Object)sr_open_id)) {
                dataMap.put("sr_open_id", sr_open_id);
            } else {
                dataMap.put("sr_open_id", "");
            }
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_BYDEVICE_USER, PromptProperties.getProperty("device.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> registerDevice(String si_mainboard_id) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_device device = this.deviceDao.findDeviceByMid(si_mainboard_id);
            if (device != null) {
                String status = device.getSr_device_status();
                if (XcbConstantValue.DEVICE_STATUS_WJH.equals(status) || XcbStringUtils.isNullOrBlank((Object)status)) {
                    Tb_agent agent = this.agentDao.findAgentById_agent(device.getSw_agent_id());
                    if (agent != null) {
                        device.setSr_device_status(XcbConstantValue.DEVICE_STATUS_YY);
                        device.setTm_modify_time(new Date());
                        int result = this.deviceDao.updateDeviceByStsId_agent(device);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            ret.put(XcbConstantValue.DATA, device);
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.register.success"));
                        } else {
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.register.fail"));
                        }
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.check.isNoExist2"));
                    }
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.check.IS_JH"));
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.check.isNoExist"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_REGISTER, PromptProperties.getProperty("device.find.fail"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> updateAppByMid(Tb_device device) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        String msg = "";
        try {
            Tb_device o_device = this.deviceDao.findDeviceByMid(device.getSi_mainboard_id());
            String outPutJsonPath = XcbConstantValue.server_host + "/" + device.getSw_company_id() + "/android_app/output.json";
            String str = HttpClientUtil.getUrlData(outPutJsonPath);
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                JSONArray jsonArr = JSONArray.fromObject((Object)str);
                JSONObject json = (JSONObject)jsonArr.get(0);
                JSONObject apkInfo = json.getJSONObject("apkInfo");
                String versionCode = apkInfo.getString("versionCode");
                String versionName = apkInfo.getString("versionName");
                if (!versionName.equals(device.getSr_version())) {
                    msg = "\u7248\u672c\u4e0d\u4e00\u81f4\uff0c\u9700\u8981\u66f4\u65b0";
                    Tb_device n_device = new Tb_device();
                    n_device.setSd_device_id(o_device.getSd_device_id());
                    n_device.setSr_version(versionName);
                    int result = this.deviceDao.updateDeviceByStsId_agent(n_device);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret_method.put(XcbConstantValue.MSG, msg);
                    } else {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.update.apk.fail"));
                    }
                } else {
                    msg = "\u7248\u672c\u4e00\u81f4\uff0c\u4e0d\u9700\u8981\u66f4\u65b0";
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, msg);
                }
            }
        }
        catch (Exception e) {
            this.log.info(XcbStringUtils.exceptionToString((Exception)e));
        }
        return ret_method;
    }

    public Map<String, Object> createMcuid(Tb_device_param deviceParam) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int reuslt = 0;
        try {
            reuslt = this.deviceParamDao.findCountDeviceParam(deviceParam);
            if (reuslt == 0) {
                reuslt = this.deviceParamDao.createDeviceParam(deviceParam);
                if (reuslt > 0) {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret_method.put(XcbConstantValue.MSG, "\u5df2\u6210\u529f\u8bb0\u5f55mcuid");
                } else {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u8bb0\u5f55mcuid\u5f02\u5e38");
                }
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, "mcuid\u5df2\u5b58\u5728\uff0c\u65e0\u9700\u91cd\u590d\u8bb0\u5f55");
            }
        }
        catch (Exception e) {
            this.log.info(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.DEVICE_CREATE_MCUID, "\u8bb0\u5f55mcuid\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findDeviceMcuid(Tb_device_param deviceParam) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int reuslt = 0;
        try {
            reuslt = this.deviceParamDao.findCountDeviceParam(deviceParam);
            if (reuslt > 0) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, "\u8bfb\u53d6\u786c\u4ef6\u6210\u529f");
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u786c\u4ef6\u8bfb\u53d6\u5931\u8d25");
            }
        }
        catch (Exception e) {
            this.log.info(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.DEVICE_FIND_MCUID, "\u786c\u4ef6\u8bfb\u53d6\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }

    @Transactional(rollbackFor={Exception.class}, propagation=Propagation.REQUIRES_NEW)
    public void dealDeviceBoxTask(Date afterDate, Tb_device device) {
        Map<Object, Object> ret = new HashMap();
        int result = 0;
        String msg = "";
        try {
            String sr_task_cycle = device.getSr_task_cycle();
            String sr_task_time = device.getSr_task_time();
            String nowTime = XcbDateUtil.getHour((Date)afterDate);
            if (sr_task_time.equals(nowTime)) {
                List<Tb_order> orderList = this.orderDao.findOrderByTask(device.getSd_device_id());
                for (Tb_order order : orderList) {
                    int diff = XcbDateUtil.daysBetween((Date)order.getTm_create_time(), (Date)afterDate);
                    if (diff < XcbStringUtils.getObjtoint((Object)sr_task_cycle)) continue;
                    Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(order.getSw_box_id());
                    String[] boxArr = new String[]{XcbStringUtils.getObjtoString((Object)order.getSw_box_id())};
                    deviceBox.setBoxArr(boxArr);
                    this.log.info("########################\u7cfb\u7edf\u6e05\u7bb1\u4efb\u52a1: \u8bbe\u5907:" + device.getSi_mainboard_id() + "\uff0c\u6e05\u7bb1\u8ba2\u5355: " + order.getSd_order_id() + "########################");
                    ret = this.deviceBoxService.updateDeviceBoxByTask(new Identifier(), order);
                    result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                    if (result >= XcbConstantValue.OPERA_INT_ZERO) continue;
                    msg = XcbStringUtils.getObjtoString((Object)ret.get(XcbConstantValue.MSG));
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_TASK, XcbConstantValue.ORDER_PAYNOTIFY, Integer.valueOf(XcbStringUtils.getObjtoint((Object)device.getSi_mainboard_id())), XcbConstantValue.OPERATION_FAIL, "UPDATE", msg, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.PC);
                    operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)device.getSd_device_id()));
                    operationLogs.setSr_operate_table("tb_device_box");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
                this.deviceDao.updateStatusByTask(device.getSd_device_id());
                this.deviceDao.updateDeviceTaskTime(device.getSd_device_id());
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
    }
}

