/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_net_photo
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.NetPhotoDao;
import com.jcg.agent.model.Tb_net_photo;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class NetPhotoServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private NetPhotoDao netPhotoDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=======NetPhotoServiceImpl==========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        String sd_net_photo_id = null;
        Integer sw_netpoint_id = null;
        String sr_photo_addreess = null;
        Tb_net_photo netPhoto = new Tb_net_photo();
        if (param != null) {
            String sd_net_photo_id_str;
            String sw_netpoint_id_str = (String)param.get("sw_netpoint_id");
            if (!XcbStringUtils.isNullOrBlank((Object)sw_netpoint_id_str)) {
                sw_netpoint_id = Integer.parseInt(sw_netpoint_id_str);
            }
            if (!XcbStringUtils.isNullOrBlank((Object)(sd_net_photo_id_str = (String)param.get("sd_net_photo_id")))) {
                sd_net_photo_id = String.valueOf(sd_net_photo_id_str);
            }
            netPhoto = (Tb_net_photo)param.get("netPhoto");
            sr_photo_addreess = XcbStringUtils.getObjtoString((Object)param.get("sr_photo_addreess"));
        }
        try {
            if (XcbConstantValue.NETPHOTO_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createNetPhoto(identifier, netPhoto);
            } else if (XcbConstantValue.NETPHOTO_FIND_BYNETID.equalsIgnoreCase(functionCode)) {
                ret = this.findNetPhotoByNetId(identifier, sw_netpoint_id);
            } else if (XcbConstantValue.NETPHOTO_UPDATE.equalsIgnoreCase(functionCode)) {
                ret = this.updateNetPhoto(identifier, netPhoto);
            } else if (XcbConstantValue.NETPHOTO_DELETE.equalsIgnoreCase(functionCode)) {
                ret = this.deleteNetPhotoById(identifier, sd_net_photo_id, sr_photo_addreess);
            } else if (XcbConstantValue.NETPHOTO_CREATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.createNetPhoto_cpy(identifier, netPhoto);
            } else if (XcbConstantValue.NETPHOTO_FIND_BYNETID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findNetPhotoByNetId_cpy(identifier, sw_netpoint_id);
            } else if (XcbConstantValue.NETPHOTO_DELETE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.deleteNetPhotoById_cpy(identifier, sd_net_photo_id, sr_photo_addreess);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    public Map<String, Object> createNetPhoto(Identifier identifier, Tb_net_photo netPhoto) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = 0;
            String id = CommonFunction.getVoucherNum((String)CommonFunction.wdtp_id);
            netPhoto.setSd_net_photo_id(id);
            result = this.netPhotoDao.createNetPhoto(netPhoto);
            if (result > 0) {
                ret_method.put(XcbConstantValue.DATA, netPhoto);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("netphoto.create.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("netphoto.create.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPHOTO_CREATE, PromptProperties.getProperty("netphoto.create.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findNetPhotoByNetId(Identifier identifier, Integer sw_netpoint_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Tb_net_photo> netPhotos = this.netPhotoDao.findNetPhotoByNetId(sw_netpoint_id);
            ret_method.put(XcbConstantValue.DATA, netPhotos);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPHOTO_FIND_BYNETID, PromptProperties.getProperty("netphoto.findNetPhotoByNetId.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateNetPhoto(Identifier identifier, Tb_net_photo netPhoto) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        netPhoto.setSr_modify_person(identifier.getUserName());
        netPhoto.setSr_modify_time(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
        try {
            result = this.netPhotoDao.updateNetPhotoById(netPhoto);
            if (result > 0) {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("netphoto.update.success"));
            } else {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("netphoto.update.fail"));
            }
            ret.put(XcbConstantValue.STATUS, XcbStringUtils.getObjtoString((Object)result));
            ret.put(XcbConstantValue.DATA, XcbConstantValue.DEFAULT_STR);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPHOTO_UPDATE, PromptProperties.getProperty("netphoto.update.fail"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> deleteNetPhotoById(Identifier identifier, String sd_net_photo_id, String sr_photo_addreess) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            int result = this.netPhotoDao.deleteNetPhotoById(sd_net_photo_id);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                CommonLogic commonLogic = new CommonLogic();
                commonLogic.deleteSourceFile(sr_photo_addreess);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("netphoto.delete.success"));
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("netphoto.delete.fail"));
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPHOTO_DELETE, PromptProperties.getProperty("netphoto.delete.fail"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> createNetPhoto_cpy(Identifier identifier, Tb_net_photo netPhoto) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = 0;
            String id = CommonFunction.getVoucherNum((String)CommonFunction.wdtp_id);
            netPhoto.setSd_net_photo_id(id);
            result = this.netPhotoDao.createNetPhoto_cpy(netPhoto);
            if (result > 0) {
                ret_method.put(XcbConstantValue.DATA, netPhoto);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("netphoto.create.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("netphoto.create.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPHOTO_CREATE_CPY, PromptProperties.getProperty("netphoto.create.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findNetPhotoByNetId_cpy(Identifier identifier, Integer sw_netpoint_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Tb_net_photo> netPhotos = this.netPhotoDao.findNetPhotoByNetId_cpy(sw_netpoint_id);
            ret_method.put(XcbConstantValue.DATA, netPhotos);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPHOTO_FIND_BYNETID_CPY, PromptProperties.getProperty("netphoto.findNetPhotoByNetId.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> deleteNetPhotoById_cpy(Identifier identifier, String sd_net_photo_id, String sr_photo_addreess) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            int result = this.netPhotoDao.deleteNetPhotoById_cpy(sd_net_photo_id);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                CommonLogic commonLogic = new CommonLogic();
                commonLogic.deleteSourceFile(sr_photo_addreess);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("netphoto.delete.success"));
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("netphoto.delete.fail"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPHOTO_DELETE_CPY, PromptProperties.getProperty("netphoto.delete.fail"), (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }
}

