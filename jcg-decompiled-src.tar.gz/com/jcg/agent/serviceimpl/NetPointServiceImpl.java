/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.wxpay.sdk.WXPayUtil
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_cash_stream
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.agent.model.Tb_devicelogs
 *  com.jcg.agent.model.Tb_net_photo
 *  com.jcg.agent.model.Tb_netpoint
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.agent.model.Tb_ordercash_stream
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.company.model.Tb_sys_param
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.user.model.Tb_user
 *  com.jcg.user.model.Tb_user_withdrawal_appl
 *  net.sf.json.JSONObject
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.agent.serviceimpl;

import com.github.wxpay.sdk.WXPayUtil;
import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentRolesRelDao;
import com.jcg.agent.idao.CashStreamDao;
import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.DeviceInfoDao;
import com.jcg.agent.idao.DeviceLogsDao;
import com.jcg.agent.idao.DevicePackageDao;
import com.jcg.agent.idao.NetPhotoDao;
import com.jcg.agent.idao.NetPointDao;
import com.jcg.agent.idao.OrderCashStreamDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.idao.OrderInComeDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_cash_stream;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_device_package;
import com.jcg.agent.model.Tb_devicelogs;
import com.jcg.agent.model.Tb_net_photo;
import com.jcg.agent.model.Tb_netpoint;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.model.Tb_ordercash_stream;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.SysParamDao;
import com.jcg.company.idao.WxInfoDao;
import com.jcg.company.idao.WxPayInfoDao;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.company.serviceimpl.SysParamServiceImpl;
import com.jcg.user.idao.UserDao;
import com.jcg.user.idao.UserWithdrawalApplDao;
import com.jcg.user.model.Tb_user;
import com.jcg.user.model.Tb_user_withdrawal_appl;
import com.jcg.user.serviceimpl.UserWithdrawalApplServiceImpl;
import com.jcg.wxmsg.serviceimpl.WxMessageServiceImpl;
import com.jcg.wxmsg.vo.WxMessage;
import com.jcg.zf.wx.EnterprisesPayment;
import com.jcg.zf.wx.Signature;
import com.jcg.zf.wx.UUidUtils;
import com.jcg.zf.wx.WXWithdrawTools;
import com.jcg.zf.wx.WxAPIV3Common;
import com.jcg.zf.wx.WxSdjAPICommon;
import com.jcg.zf.wx.WxSpAPIV3Common;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class NetPointServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private NetPointDao netpointDao;
    @Autowired
    private NetPhotoDao netPhotoDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private OrderInComeDao orderInComeDao;
    @Autowired
    private DeviceDao deviceDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private DeviceLogsDao deviceLogsDao;
    @Autowired
    private DevicePackageDao devicePackageDao;
    @Autowired
    private DeviceBoxDao deviceBoxDao;
    @Autowired
    private SysParamDao sysParamDao;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private AgentRolesRelDao roleRelDao;
    @Autowired
    private SysParamServiceImpl sysParamService;
    @Autowired
    private RedisUtil redis;
    @Autowired
    private UserWithdrawalApplDao userWithdrawalApplDao;
    @Autowired
    private WXWithdrawTools wxWithdrawTools;
    @Autowired
    private UserWithdrawalApplServiceImpl userWithdrawalApplService;
    @Autowired
    private CashStreamDao cashStreamDao;
    @Autowired
    private OrderCashStreamDao orderCashStreamDao;
    @Autowired
    public WxAPIV3Common wxAPIV3Common;
    @Autowired
    private WxSdjAPICommon wxSdjAPICommon;
    @Autowired
    private WxSpAPIV3Common wxSpAPIV3Common;
    @Autowired
    private WxMessageServiceImpl wxMessageService;
    @Autowired
    private WxPayInfoDao wxPayInfoDao;
    @Autowired
    private DeviceInfoDao deviceInfoDao;
    @Autowired
    private WxInfoDao wxInfoDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========NetPointServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        Integer sd_netpoint_id = null;
        Integer sd_agent_id = null;
        String companyId = null;
        Tb_netpoint netpoint = new Tb_netpoint();
        Page page = new Page();
        if (param != null) {
            sd_netpoint_id = XcbStringUtils.getObjtoint((Object)param.get("sd_netpoint_id"));
            sd_agent_id = XcbStringUtils.getObjtoint((Object)param.get("sd_agent_id"));
            companyId = (String)param.get("companyId");
            netpoint = (Tb_netpoint)param.get("netpoint");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.NETPOINT_CREATE.equals(functionCode)) {
                ret = this.createNetPoint(identifier, netpoint);
            } else if (XcbConstantValue.NETPOINT_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findNetPointByParam_agent(identifier, netpoint, page);
            } else if (XcbConstantValue.NETPOINT_FIND_BYAGENTID.equalsIgnoreCase(functionCode)) {
                ret = this.findDropDownNetpointByAgentId_agent(identifier, sd_agent_id);
            } else if (XcbConstantValue.NETPOINT_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findNetPointById_agent(identifier, netpoint);
            } else if (XcbConstantValue.NETPOINT_FIND_ORDER.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderByNetId(identifier, sd_netpoint_id);
            } else if (XcbConstantValue.NETPOINTDROPDOWN_FIND_BYAREACODE.equals(functionCode)) {
                Integer si_up_agent = XcbStringUtils.getObjtoint((Object)param.get("si_up_agent"));
                ret = this.findAllNetpointByAreaCode(identifier, netpoint, si_up_agent);
            } else if (XcbConstantValue.NETPOINT_UPDATE_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.updateNetPointById_agent(identifier, netpoint);
            } else if (XcbConstantValue.NETPOINT_CREATE_CPY.equals(functionCode)) {
                ret = this.createNetPoint_cpy(identifier, netpoint);
            } else if (XcbConstantValue.NETPOINTDROPDOWN_FIND_BYAREACODE_CPY.equals(functionCode)) {
                ret = this.findAllNetpointByAreaCode_cpy(identifier, netpoint, companyId);
            } else if (XcbConstantValue.NETPOINT_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findNetPointByParam_cpy(identifier, netpoint, page);
            } else if (XcbConstantValue.NETPOINT_FIND_BYAGENTID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findDropDownNetpointByAgentId_agent(identifier, sd_agent_id);
            } else if (XcbConstantValue.NETPOINT_FIND_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findNetPointById_agent(identifier, netpoint);
            } else if (XcbConstantValue.NETPOINT_UPDATE_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateNetPointById_agent(identifier, netpoint);
            } else if (XcbConstantValue.NETPOINT_TASK.equalsIgnoreCase(functionCode)) {
                ret = this.netpointTask(sd_netpoint_id);
            } else if (XcbConstantValue.NETPOINT_FIND_BYMID_USER.equalsIgnoreCase(functionCode)) {
                String sw_user_id = XcbStringUtils.getObjtoString((Object)param.get("sw_user_id"));
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                String sw_device_id = XcbStringUtils.getObjtoString((Object)param.get("sw_device_id"));
                String sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                ret = this.findNetPointByMid_user(identifier, sw_user_id, si_mainboard_id, sw_device_id, sr_way);
            } else if (XcbConstantValue.NETPOINT_FIND_INFO_BYMID_USER.equalsIgnoreCase(functionCode)) {
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                ret = this.findNetInfoByMid_user(identifier, si_mainboard_id);
            } else if (XcbConstantValue.NETPOINT_FIND_BYMID_DEVICE.equalsIgnoreCase(functionCode)) {
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                ret = this.findNetPointByMid_device(identifier, si_mainboard_id);
            } else if (XcbConstantValue.NETPOINT_FIND_DEVICE_KYNUM.equalsIgnoreCase(functionCode)) {
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                ret = this.refreshNetInfo(identifier, si_mainboard_id);
            } else if (XcbConstantValue.NETPOINT_FIND_DEVICE_INFO.equalsIgnoreCase(functionCode)) {
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                ret = this.findDeviceInfo(identifier, si_mainboard_id);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private Map<String, Object> findOrderByNetId(Identifier identifier, Integer sd_netpoint_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_netpoint netpoint = this.netpointDao.findNetPointById_agent(sd_netpoint_id);
            Integer sw_agent_id = netpoint.getSw_agent_id();
            Tb_agent agent = this.agentDao.findAgentById_agent(sw_agent_id);
            String nowDate = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd");
            Map<String, Object> orderMap = this.orderDao.findOrderByNetId(sd_netpoint_id, nowDate);
            String todayZero = XcbDateUtil.getTodayZero((Date)new Date());
            String todayEnd = XcbDateUtil.getTodayEnd((Date)new Date());
            Tb_order o = new Tb_order();
            o.setSr_order_time_start(todayZero);
            o.setSr_order_time_end(todayEnd);
            o.setSw_netpoint_id(sd_netpoint_id);
            BigDecimal dc_order_money = XcbStringUtils.getObjToBigDecimal((Object)this.orderInComeDao.findAgentMoneySum(o));
            orderMap.put("dc_actual_income_sum", dc_order_money);
            Tb_order order = new Tb_order();
            order.setSw_netpoint_id(sd_netpoint_id);
            order.setSr_create_time(nowDate);
            int count = 0;
            count = this.orderDao.findCountOrderByNetId(sd_netpoint_id, nowDate);
            orderMap.put("order_cnt", count);
            dataMap.put("order_cnt", count);
            dataMap.put("order", orderMap);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_ORDER, PromptProperties.getProperty("order.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findNetPointByParam_agent(Identifier identifier, Tb_netpoint netpoint, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)netpoint.getSd_agent_id())) {
                netpoint.setSw_agent_id(netpoint.getSd_agent_id());
            }
            List<Tb_netpoint> netpoints = null;
            int totalCount = 0;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(netpoint.getSw_agent_id());
            String[] subArr = null;
            if (adminAgent != null && "1".equals(adminAgent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                subList.add(XcbStringUtils.getObjtoString((Object)netpoint.getSd_agent_id()));
                subArr = new String[subList.size()];
                subList.toArray(subArr);
                netpoint.setAgentArr(subArr);
                netpoint.setSd_agent_id(null);
            }
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                if (netList.size() > 0) {
                    String[] netArr = netList.get(0).split(",");
                    netpoint.setNetArr(netArr);
                    netpoints = this.netpointDao.findNetPointByNetArr_agent(netpoint, page);
                    totalCount = this.netpointDao.findCountByNetArr_agent(netpoint);
                }
            } else {
                netpoints = this.netpointDao.findNetPointByParam_agent(netpoint, page);
                totalCount = this.netpointDao.findCountByParam_agent(netpoint);
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("netpoints", netpoints);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_BYPARAM, PromptProperties.getProperty("netpoint.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findNetPointByParam_cpy(Identifier identifier, Tb_netpoint netpoint, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)netpoint.getSd_agent_id())) {
                netpoint.setSw_agent_id(netpoint.getSd_agent_id());
            }
            List<Tb_netpoint> netpoints = this.netpointDao.findNetPointByParam_cpy(netpoint, page);
            int totalCount = this.netpointDao.findCountByParam_cpy(netpoint);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("netpoints", netpoints);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_BYPARAM_CPY, PromptProperties.getProperty("netpoint.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findNetPointById_agent(Identifier identifier, Tb_netpoint netpoint) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_netpoint np = this.netpointDao.findNetPointById_agent(netpoint.getSd_netpoint_id());
            ret_method.put(XcbConstantValue.DATA, np);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_BYID, PromptProperties.getProperty("netpoint.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateNetPointById_agent(Identifier identifier, Tb_netpoint netpoint) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        netpoint.setSi_modify_person(identifier.getUserId());
        netpoint.setTm_modify_time(new Date());
        try {
            result = this.netpointDao.updateNetPointById_agent(netpoint);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.DATA, result);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("netpoint.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("netpoint.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_UPDATE_BYID, PromptProperties.getProperty("netpoint.update.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findDropDownNetpointByAgentId_agent(Identifier identifier, Integer sd_agent_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Map<String, Object>>> dataMap = new HashMap<String, List<Map<String, Object>>>();
        try {
            List<Map<String, Object>> netpoints = null;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(sd_agent_id);
            String[] subArr = null;
            if (adminAgent != null && "1".equals(adminAgent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                subList.add(XcbStringUtils.getObjtoString((Object)sd_agent_id));
                subArr = new String[subList.size()];
                subList.toArray(subArr);
            }
            if (!XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                if (netList.size() > 0) {
                    String[] netArr = netList.get(0).split(",");
                    netpoints = this.netpointDao.findDropDownNetpointByNetArr_agent(netArr);
                }
            } else {
                netpoints = adminAgent != null && "1".equals(adminAgent.getSr_role()) ? this.netpointDao.findDropDownNetpointByAgentArr_agent(subArr) : this.netpointDao.findDropDownNetpointByAgentId_agent(sd_agent_id);
            }
            dataMap.put("netpoints", netpoints);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_BYAGENTID, PromptProperties.getProperty("netpoint.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findAllNetpointByAreaCode(Identifier identifier, Tb_netpoint netpoint, Integer si_up_agent) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> netpoints = this.netpointDao.findAllNetpointByAreaCode(netpoint, si_up_agent);
            ret_method.put(XcbConstantValue.DATA, netpoints);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINTDROPDOWN_FIND_BYAREACODE, PromptProperties.getProperty("netpointdropdown.findbyareacode.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findAllNetpointByAreaCode_cpy(Identifier identifier, Tb_netpoint netpoint, String companyId) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> netpoints = this.netpointDao.findAllNetpointByAreaCode_cpy(netpoint, companyId);
            ret_method.put(XcbConstantValue.DATA, netpoints);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINTDROPDOWN_FIND_BYAREACODE_CPY, PromptProperties.getProperty("netpointdropdown.findbyareacode.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> createNetPoint(Identifier identifier, Tb_netpoint netpoint) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = 0;
            Map<String, Integer> mapid = this.sysParamService.getNewId(XcbConstantValue.TA_CATECODE_MAINTENANCE_ID, XcbConstantValue.TA_KEYCODE_NETPOINTID);
            int sd_netpoint_id = mapid.get("sr_param_value");
            int count = this.sysParamDao.updateParamForId(mapid);
            netpoint.setSd_netpoint_id(Integer.valueOf(sd_netpoint_id));
            netpoint.setSr_net_status(XcbConstantValue.NETPOINT_ZC);
            netpoint.setTm_create_time(new Date());
            netpoint.setSi_create_person(identifier.getUserId());
            result = this.netpointDao.createNetPoint_cpy(netpoint);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.DATA, netpoint);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("netpoint.create.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("netpoint.create.fail"));
            }
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_COMPANY, XcbConstantValue.NETPOINT_CREATE, identifier.getUserId(), XcbConstantValue.OPERATION_SUCCESS, "CREATE", "\u521b\u5efa\u7f51\u70b9", identifier.getUrl(), identifier.getIp());
            operationLogs.setSr_operate_from("PC");
            operationLogs.setSr_operate_primarykey(String.valueOf(sd_netpoint_id));
            operationLogs.setSr_operate_result("");
            operationLogs.setSr_operate_table("Tb_netpoint");
            this.operationLogServiceImpl.createOperaLog(operationLogs);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_CREATE, PromptProperties.getProperty("netpoint.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> createNetPoint_cpy(Identifier identifier, Tb_netpoint netpoint) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = 0;
            Map<String, Integer> mapid = this.sysParamService.getNewId(XcbConstantValue.TA_CATECODE_MAINTENANCE_ID, XcbConstantValue.TA_KEYCODE_NETPOINTID);
            int sd_netpoint_id = mapid.get("sr_param_value");
            int count = this.sysParamDao.updateParamForId(mapid);
            netpoint.setSd_netpoint_id(Integer.valueOf(sd_netpoint_id));
            netpoint.setSr_net_status(XcbConstantValue.NETPOINT_ZC);
            netpoint.setTm_create_time(new Date());
            netpoint.setSi_create_person(identifier.getUserId());
            result = this.netpointDao.createNetPoint_cpy(netpoint);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.DATA, netpoint);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("netpoint.create.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("netpoint.create.fail"));
            }
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_COMPANY, XcbConstantValue.NETPOINT_CREATE_CPY, identifier.getUserId(), XcbConstantValue.OPERATION_SUCCESS, "CREATE", "\u521b\u5efa\u7f51\u70b9", identifier.getUrl(), identifier.getIp());
            operationLogs.setSr_operate_from("PC");
            operationLogs.setSr_operate_primarykey(String.valueOf(sd_netpoint_id));
            operationLogs.setSr_operate_result("");
            operationLogs.setSr_operate_table("Tb_netpoint");
            this.operationLogServiceImpl.createOperaLog(operationLogs);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_CREATE_CPY, PromptProperties.getProperty("netpoint.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findNetpointByAgentId_user(Identifier identifier, Integer sw_agent_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_netpoint>> dataMap = new HashMap<String, List<Tb_netpoint>>();
        List<Tb_netpoint> netpoints = null;
        try {
            netpoints = this.netpointDao.findNetpointByAgentId_user(sw_agent_id);
            dataMap.put("netpoints", netpoints);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_BYAGENTID_USER, PromptProperties.getProperty("netpoint.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findNetPointByMid_user(Identifier identifier, String sw_user_id, String si_mainboard_id, String sw_device_id, String sr_type) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_device device = new Tb_device();
            if (!XcbStringUtils.isNullOrBlank((Object)si_mainboard_id)) {
                device = this.deviceDao.findDeviceByMid(si_mainboard_id);
            } else if (!XcbStringUtils.isNullOrBlank((Object)sw_device_id)) {
                device = this.deviceDao.findDeviceDetailById_agent(sw_device_id);
            }
            int count = this.deviceInfoDao.findDeviceInfo(device.getSi_mainboard_id(), device.getSi_box_count());
            if (count == 0) {
                ret_method.put(XcbConstantValue.MSG, "\u8bbe\u5907\u672a\u8fde\u63a5\uff0c\u8bf7\u8fde\u63a5\u8bbe\u5907");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                this.initResultMap(ret_method);
                return ret_method;
            }
            Tb_user user = new Tb_user();
            if (!XcbStringUtils.isNullOrBlank((Object)sw_user_id)) {
                user = this.userDao.findUserById(XcbStringUtils.getObjtoint((Object)sw_user_id));
            }
            if (device != null) {
                Tb_wx_info wx_info = this.wxInfoDao.findInfoByCode(device.getSr_way());
                Tb_netpoint netpoint = this.netpointDao.findNetPointById_agent(device.getSw_netpoint_id());
                List<Tb_net_photo> photoList = this.netPhotoDao.findNetPhotoByNetId(device.getSw_netpoint_id());
                if (photoList != null && photoList.size() > 0) {
                    dataMap.put("photo", photoList.get(0));
                } else {
                    dataMap.put("photo", new Tb_net_photo());
                }
                Tb_devicelogs logs = this.deviceLogsDao.selectByPrimaryKey(device.getSi_mainboard_id());
                List<String> boxTypeList = this.deviceDao.findBoxTypeByDeviceId(device.getSd_device_id());
                int sub_cnt = this.deviceDao.findBoxCountByDeviceId(device.getSd_device_id());
                device.setSi_box_type_count(Integer.valueOf(sub_cnt));
                LinkedHashMap<String, Tb_device_package> devicePackAgeMap = new LinkedHashMap<String, Tb_device_package>();
                Tb_device_package d_package = new Tb_device_package();
                d_package.setSw_device_id(device.getSd_device_id());
                List<Tb_device_package> devicePackAgeList = this.devicePackageDao.findDevicePackageByDeviceId(d_package);
                for (Tb_device_package devicePackage : devicePackAgeList) {
                    List<String> remarksList;
                    if (XcbConstantValue.DEVICE_BOX_XG.equals(devicePackage.getSr_box_type())) {
                        devicePackage.setSi_order(Integer.valueOf(1));
                        devicePackage.setSr_img_path("/static/images/my/xg.png");
                        devicePackage.setSr_wx_img_path("../../assets/img/my/xg.png");
                    }
                    if (XcbConstantValue.DEVICE_BOX_ZG.equals(devicePackage.getSr_box_type())) {
                        devicePackage.setSi_order(Integer.valueOf(2));
                        devicePackage.setSr_img_path("/static/images/my/zg.png");
                        devicePackage.setSr_wx_img_path("../../assets/img/my/zg.png");
                    }
                    if (XcbConstantValue.DEVICE_BOX_DG.equals(devicePackage.getSr_box_type())) {
                        devicePackage.setSi_order(Integer.valueOf(3));
                        devicePackage.setSr_img_path("/static/images/my/dg.png");
                        devicePackage.setSr_wx_img_path("../../assets/img/my/dg.png");
                    }
                    if (XcbConstantValue.DEVICE_BOX_TDG.equals(devicePackage.getSr_box_type())) {
                        devicePackage.setSi_order(Integer.valueOf(4));
                        devicePackage.setSr_img_path("/static/images/my/tdg.png");
                        devicePackage.setSr_wx_img_path("../../assets/img/my/tdg.png");
                    }
                    if (!XcbStringUtils.isNullOrBlank((Object)devicePackage.getSr_app_remarks())) {
                        remarksList = this.dealAppRemarks(devicePackage, device.getSr_charging_type(), devicePackage.getSr_app_remarks().trim());
                        devicePackage.setRemarksList((List)remarksList);
                    }
                    if (XcbStringUtils.isNullOrBlank((Object)devicePackage.getSr_wx_remarks())) continue;
                    remarksList = this.dealAppRemarks(devicePackage, device.getSr_charging_type(), devicePackage.getSr_wx_remarks().trim());
                    devicePackage.setWx_remarksList(remarksList);
                }
                List newdevicePackAgeList = devicePackAgeList.stream().sorted((e1, e2) -> -e2.getSi_order().compareTo(e1.getSi_order())).collect(Collectors.toList());
                ArrayList<String> newList = new ArrayList<String>();
                for (Tb_device_package devicePackage : newdevicePackAgeList) {
                    for (String boxType : boxTypeList) {
                        if (!boxType.equals(devicePackage.getSr_box_type())) continue;
                        int si_ky_count = this.deviceBoxDao.findKYCountByMidAndType(device.getSd_device_id(), boxType);
                        devicePackage.setSi_ky_count(Integer.valueOf(si_ky_count));
                        devicePackAgeMap.put(boxType, devicePackage);
                        newList.add(boxType);
                    }
                }
                if (user != null && "scan".equals(sr_type)) {
                    int sr_scan_time = 5;
                    Tb_sys_param sysParam = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.SCAN_TIME);
                    if (sysParam != null) {
                        sr_scan_time = XcbStringUtils.getObjtoint((Object)sysParam.getSr_param_value());
                    }
                    HashMap<String, String> pathMap = new HashMap<String, String>();
                    String query = "";
                    pathMap.put("boxtype", "");
                    if ("Y".equals(device.getSr_cj_function())) {
                        pathMap.put("path", "/setting");
                        query = "type=1&mid=" + device.getSi_mainboard_id();
                        pathMap.put("url", "/pages/my/scan/setting?" + query);
                    } else if (newList.size() == 1) {
                        pathMap.put("path", "/payinfo");
                        pathMap.put("boxtype", (String)newList.get(0));
                        query = "type=2&mid=" + device.getSi_mainboard_id() + "&boxtype=" + (String)newList.get(0);
                        pathMap.put("url", "/pages/my/scan/payinfo?" + query);
                    } else {
                        pathMap.put("path", "/choose");
                        query = "type=2&mid=" + device.getSi_mainboard_id();
                        pathMap.put("url", "/pages/my/scan/choose?" + query);
                    }
                    pathMap.put("mid", device.getSi_mainboard_id());
                    pathMap.put("cj", device.getSr_cj_function());
                    String jsonStr = JSONObject.fromObject(pathMap).toString();
                    if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type())) {
                        if (!XcbStringUtils.isNullOrBlank((Object)user.getSr_unionid())) {
                            this.redis.setForTimeMIN(user.getSr_unionid(), jsonStr, sr_scan_time);
                        }
                    } else if (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type())) {
                        if (!XcbStringUtils.isNullOrBlank((Object)user.getSr_app_open_id())) {
                            this.redis.setForTimeMIN(user.getSr_app_open_id(), jsonStr, sr_scan_time);
                        }
                    } else if (!XcbStringUtils.isNullOrBlank((Object)user.getSr_open_id())) {
                        this.redis.setForTimeMIN(user.getSr_open_id(), jsonStr, sr_scan_time);
                    }
                }
                dataMap.put("list", newList);
                dataMap.put("info", devicePackAgeMap);
                dataMap.put("netpoint", netpoint);
                dataMap.put("device", device);
                dataMap.put("logs", logs);
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u4e8c\u7ef4\u7801\u5931\u6548\uff0c\u8bf7\u626b\u7801\u5c4f\u5e55\u4e8c\u7ef4\u7801");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_BYMID_USER, PromptProperties.getProperty("netpoint.findbyid.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findNetInfoByMid_user(Identifier identifier, String si_mainboard_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<String>> dataMap = new HashMap<String, List<String>>();
        try {
            Tb_device device = this.deviceDao.findDeviceByMid(si_mainboard_id);
            if (device != null) {
                Tb_netpoint netpoint = this.netpointDao.findNetPointById_agent(device.getSw_netpoint_id());
                List<String> boxTypeList = this.deviceDao.findBoxTypeByDeviceId(device.getSd_device_id());
                dataMap.put("list", boxTypeList);
                dataMap.put("netpoint", (List<String>)netpoint);
                dataMap.put("device", (List<String>)device);
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.find.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_INFO_BYMID_USER, PromptProperties.getProperty("netpoint.findbyid.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findNetInfoByDevice_user(Identifier identifier, String sw_device_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<String>> dataMap = new HashMap<String, List<String>>();
        try {
            Tb_device device = this.deviceDao.findDeviceDetailById_agent(sw_device_id);
            if (device != null) {
                Tb_netpoint netpoint = this.netpointDao.findNetPointById_agent(device.getSw_netpoint_id());
                List<String> boxTypeList = this.deviceDao.findBoxTypeByDeviceId(device.getSd_device_id());
                dataMap.put("list", boxTypeList);
                dataMap.put("netpoint", (List<String>)netpoint);
                dataMap.put("device", (List<String>)device);
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.find.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_INFO_BYMID_USER, PromptProperties.getProperty("netpoint.findbyid.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findNetPointByMid_device(Identifier identifier, String si_mainboard_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_device device = new Tb_device();
            if (!XcbStringUtils.isNullOrBlank((Object)si_mainboard_id)) {
                device = this.deviceDao.findDeviceByMid(si_mainboard_id);
            }
            if (device != null) {
                Tb_netpoint netpoint = this.netpointDao.findNetPointById_agent(device.getSw_netpoint_id());
                List<Tb_net_photo> photoList = this.netPhotoDao.findNetPhotoByNetId(device.getSw_netpoint_id());
                if (photoList != null && photoList.size() > 0) {
                    dataMap.put("photo", photoList.get(0).getSr_photo_addreess());
                } else {
                    dataMap.put("photo", "");
                }
                List<String> boxTypeList = this.deviceDao.findBoxTypeByDeviceId(device.getSd_device_id());
                int sub_cnt = this.deviceDao.findBoxCountByDeviceId(device.getSd_device_id());
                device.setSi_box_type_count(Integer.valueOf(sub_cnt));
                LinkedHashMap<String, Map> devicePackAgeMap = new LinkedHashMap<String, Map>();
                Tb_device_package d_package = new Tb_device_package();
                d_package.setSw_device_id(device.getSd_device_id());
                List<Map<String, Object>> devicePackAgeList = this.devicePackageDao.findDevicePackage_device(d_package);
                for (Map<String, Object> devicePackage : devicePackAgeList) {
                    String sr_box_type = XcbStringUtils.getObjtoString((Object)devicePackage.get("sr_box_type"));
                    String sr_wx_remarks = XcbStringUtils.getObjtoString((Object)devicePackage.get("sr_wx_remarks"));
                    String sr_app_remarks = XcbStringUtils.getObjtoString((Object)devicePackage.get("sr_app_remarks"));
                    if (XcbConstantValue.DEVICE_BOX_XG.equals(sr_box_type)) {
                        devicePackage.put("si_order", 1);
                    }
                    if (XcbConstantValue.DEVICE_BOX_ZG.equals(sr_box_type)) {
                        devicePackage.put("si_order", 2);
                    }
                    if (XcbConstantValue.DEVICE_BOX_DG.equals(sr_box_type)) {
                        devicePackage.put("si_order", 3);
                    }
                    if (XcbConstantValue.DEVICE_BOX_TDG.equals(sr_box_type)) {
                        devicePackage.put("si_order", 4);
                    }
                    if (!XcbStringUtils.isNullOrBlank((Object)sr_wx_remarks)) {
                        List<String> wx_remarksList = this.dealAppRemarks(devicePackage, device.getSr_charging_type(), sr_wx_remarks.trim());
                        devicePackage.put("wx_remarksList", wx_remarksList);
                    }
                    if (XcbStringUtils.isNullOrBlank((Object)sr_app_remarks)) continue;
                    List<String> remarksList = this.dealAppRemarks(devicePackage, device.getSr_charging_type(), sr_app_remarks.trim());
                    devicePackage.put("remarksList", remarksList);
                }
                List newdevicePackAgeList = devicePackAgeList.stream().sorted((e1, e2) -> -XcbStringUtils.getObjtoString(e2.get("si_order")).compareTo(XcbStringUtils.getObjtoString(e1.get("si_order")))).collect(Collectors.toList());
                ArrayList<String> newList = new ArrayList<String>();
                for (Map devicePackage : newdevicePackAgeList) {
                    for (String boxType : boxTypeList) {
                        String sr_box_type;
                        if (!boxType.equals(sr_box_type = XcbStringUtils.getObjtoString(devicePackage.get("sr_box_type")))) continue;
                        int si_ky_count = this.deviceBoxDao.findKYCountByMidAndType(device.getSd_device_id(), boxType);
                        devicePackage.put("si_ky_count", si_ky_count);
                        devicePackage.remove("sr_app_remarks");
                        devicePackage.remove("sr_remarks");
                        devicePackage.remove("sr_wx_remarks");
                        devicePackAgeMap.put(boxType, devicePackage);
                        newList.add(boxType);
                    }
                }
                dataMap.put("list", newList);
                dataMap.put("info", devicePackAgeMap);
                dataMap.put("sd_netpoint_id", netpoint.getSd_netpoint_id());
                dataMap.put("sr_net_name", netpoint.getSr_net_name());
                dataMap.put("sr_maintain_phone", netpoint.getSr_maintain_phone());
                dataMap.put("sr_service_time", netpoint.getSr_service_time());
                dataMap.put("si_ky_cnt", device.getSi_ky_cnt());
                dataMap.put("sr_qr_code", device.getSr_qr_code());
                dataMap.put("sr_charging_type", device.getSr_charging_type());
                dataMap.put("sr_device_name", XcbStringUtils.getObjtoString((Object)device.getSr_device_name()));
                dataMap.put("sr_device_type", device.getSr_device_type());
                dataMap.put("sr_cj_function", device.getSr_cj_function());
                dataMap.put("sr_is_temp", device.getSr_is_temp());
                dataMap.put("sr_alias", device.getSr_alias());
                dataMap.put("si_box_type_count", device.getSi_box_type_count());
                dataMap.put("sr_device_status", device.getSr_device_status());
                dataMap.put("version", device.getSr_version());
                dataMap.put("sr_is_reboot", device.getSr_is_reboot());
                dataMap.put("sr_reboot_task_hour", device.getSr_reboot_task_hour());
                dataMap.put("sr_is_lock", device.getSr_is_lock());
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.find.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_BYMID_USER, PromptProperties.getProperty("device.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> refreshNetInfo(Identifier identifier, String si_mainboard_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_device device = this.deviceDao.findDeviceByMid(si_mainboard_id);
            if (device != null) {
                int sub_cnt = this.deviceDao.findBoxCountByDeviceId(device.getSd_device_id());
                device.setSi_box_type_count(Integer.valueOf(sub_cnt));
                dataMap.put("si_ky_cnt", device.getSi_ky_cnt());
                dataMap.put("sr_charging_type", device.getSr_charging_type());
                dataMap.put("si_box_type_count", device.getSi_box_type_count());
                dataMap.put("sr_device_type", device.getSr_device_type());
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.find.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_DEVICE_KYNUM, PromptProperties.getProperty("netpoint.findbyid.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findDeviceInfo(Identifier identifier, String si_mainboard_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_device device = this.deviceDao.findDeviceByMid(si_mainboard_id);
            if (device != null) {
                Tb_netpoint netpoint = this.netpointDao.findNetPointById_agent(device.getSw_netpoint_id());
                int sub_cnt = this.deviceDao.findBoxCountByDeviceId(device.getSd_device_id());
                device.setSi_box_type_count(Integer.valueOf(sub_cnt));
                dataMap.put("sr_device_status", device.getSr_device_status());
                dataMap.put("sr_maintain_phone", device.getSr_maintain_phone());
                dataMap.put("sr_service_time", netpoint.getSr_service_time());
                dataMap.put("sr_device_type", device.getSr_device_type());
                dataMap.put("sr_serial_port", device.getSr_serial_port());
                dataMap.put("sr_baudrate", device.getSr_baudrate());
                dataMap.put("sr_mid_way", device.getSr_mid_way());
                dataMap.put("si_warn_time", XcbStringUtils.getObjtoint((Object)device.getSi_warn_time()));
                dataMap.put("sr_net_name", device.getSr_net_name());
                dataMap.put("sr_device_name", XcbStringUtils.getObjtoString((Object)device.getSr_device_name()));
                dataMap.put("sr_alias", device.getSr_alias());
                dataMap.put("sr_is_reboot", device.getSr_is_reboot());
                dataMap.put("sr_is_lock", device.getSr_is_lock());
                dataMap.put("sr_reboot_task_hour", device.getSr_reboot_task_hour());
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.find.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.NETPOINT_FIND_DEVICE_KYNUM, PromptProperties.getProperty("netpoint.findbyid.error"), (Throwable)e);
        }
        return ret_method;
    }

    private List<String> dealAppRemarks(Map<String, Object> devicePackage, String sr_charging_type, String remarks) {
        String[] remarksArr;
        List<String> appRemarks = new ArrayList<String>();
        if (remarks.contains("{0}")) {
            remarks = remarks.replace("{0}", XcbStringUtils.getObjtoString((Object)devicePackage.get("dc_once_price")));
        }
        if (remarks.contains("{1}")) {
            remarks = remarks.replace("{1}", XcbStringUtils.getObjtoString((Object)devicePackage.get("dc_hour_price")));
        }
        if (remarks.contains("{2}")) {
            remarks = remarks.replace("{2}", XcbDateUtil.toHourMin((int)XcbStringUtils.getObjtoint((Object)devicePackage.get("si_time_slot"))));
        }
        if (remarks.contains("{3}")) {
            remarks = remarks.replace("{3}", XcbStringUtils.getObjtoString((Object)devicePackage.get("dc_advance_price")));
        }
        if (remarks.contains("{4}")) {
            remarks = remarks.replace("{4}", XcbDateUtil.toHourMin((int)XcbStringUtils.getObjtoint((Object)devicePackage.get("si_fee_time"))));
        }
        if (remarks.contains("{5}")) {
            remarks = remarks.replace("{5}", XcbStringUtils.getObjtoString((Object)devicePackage.get("dc_max_xf")));
        }
        if (remarks.contains("{6}")) {
            remarks = remarks.replace("{6}", XcbStringUtils.getObjtoString((Object)devicePackage.get("si_max_hour")));
        }
        if (remarks.contains("{7}")) {
            remarks = remarks.replace("{7}", XcbStringUtils.getObjtoString((Object)devicePackage.get("sr_maxservice_time")));
        }
        if ((remarksArr = remarks.split("#")) != null && remarksArr.length > 0) {
            String str = "";
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(sr_charging_type)) {
                str = remarksArr[0];
            }
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(sr_charging_type)) {
                str = remarksArr[1];
            }
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(sr_charging_type)) {
                str = remarksArr[2];
            }
            String[] strArr = str.split("@");
            appRemarks = Arrays.asList(strArr);
        }
        return appRemarks;
    }

    private List<String> dealAppRemarks(Tb_device_package devicePackage, String sr_charging_type, String remarks) {
        String[] remarksArr;
        List<String> appRemarks = new ArrayList<String>();
        if (remarks.contains("{0}")) {
            remarks = remarks.replace("{0}", XcbStringUtils.getObjtoString((Object)devicePackage.getDc_once_price()));
        }
        if (remarks.contains("{1}")) {
            remarks = remarks.replace("{1}", XcbStringUtils.getObjtoString((Object)devicePackage.getDc_hour_price()));
        }
        if (remarks.contains("{2}")) {
            remarks = remarks.replace("{2}", XcbDateUtil.toHourMin((int)XcbStringUtils.getObjtoint((Object)devicePackage.getSi_time_slot())));
        }
        if (remarks.contains("{3}")) {
            remarks = remarks.replace("{3}", XcbStringUtils.getObjtoString((Object)devicePackage.getDc_advance_price()));
        }
        if (remarks.contains("{4}")) {
            remarks = remarks.replace("{4}", XcbDateUtil.toHourMin((int)XcbStringUtils.getObjtoint((Object)devicePackage.getSi_fee_time())));
        }
        if (remarks.contains("{5}")) {
            remarks = remarks.replace("{5}", XcbStringUtils.getObjtoString((Object)devicePackage.getDc_max_xf()));
        }
        if (remarks.contains("{6}")) {
            remarks = remarks.replace("{6}", XcbStringUtils.getObjtoString((Object)devicePackage.getSi_max_hour()));
        }
        if (remarks.contains("{7}")) {
            remarks = remarks.replace("{7}", XcbStringUtils.getObjtoString((Object)devicePackage.getSr_maxservice_time()));
        }
        if ((remarksArr = remarks.split("#")) != null && remarksArr.length > 0) {
            String str = "";
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(sr_charging_type)) {
                str = remarksArr[0];
            }
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(sr_charging_type)) {
                str = remarksArr[1];
            }
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(sr_charging_type)) {
                str = remarksArr[2];
            }
            String[] strArr = str.split("@");
            appRemarks = Arrays.asList(strArr);
        }
        return appRemarks;
    }

    public Map<String, Object> netpointTask(Integer sd_netpoint_id) throws Exception {
        this.log.info("###############\u4efb\u52a1\u9000\u6b3e\u5f00\u59cb###############");
        Map<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        String msg = "";
        Date nowDate = new Date();
        this.log.info("##########\u7cfb\u7edf\u65f6\u95f4:" + nowDate + "###########");
        List<Tb_user_withdrawal_appl> dsp_appl = this.userWithdrawalApplDao.findDSPUserWithdrawalAppl_task();
        for (Tb_user_withdrawal_appl appl : dsp_appl) {
            boolean isSuccess = false;
            Tb_user user = this.userDao.findUserById(appl.getSw_user_id());
            String sr_order_arr = XcbStringUtils.getObjtoString((Object)appl.getSr_order_arr());
            if (!XcbStringUtils.isNullOrBlank((Object)sr_order_arr)) {
                String[] orderArr = sr_order_arr.split(",");
                Tb_netpoint netpoint = this.orderDao.findNewOrderForNetpoint(orderArr);
                if (sd_netpoint_id != 0 && !netpoint.getSd_netpoint_id().equals(sd_netpoint_id)) break;
                int tk_cnt = this.orderDao.findCountDepositRefundByOrderArr(orderArr);
                boolean isCanAppl = false;
                Integer si_click = XcbStringUtils.getObjtoint((Object)user.getSi_click());
                this.log.info("########################\u7cfb\u7edf\u4efb\u52a1: \u63d0\u73b0\u7533\u8bf7ID:" + appl.getSd_id() + "\uff0c\u5ba1\u6279\u7f51\u70b9: " + netpoint.getSr_net_name() + "\u5f00\u59cb########################");
                if (tk_cnt == 0) {
                    BigDecimal dc_temp;
                    BigDecimal dc_temp_rate;
                    BigDecimal dc_rate = XcbStringUtils.getObjToBigDecimal((Object)netpoint.getDc_rate());
                    String[] si_max_click = Integer.valueOf(XcbStringUtils.getObjtoint((Object)netpoint.getSi_max_click()));
                    Integer si_max_appl = XcbStringUtils.getObjtoint((Object)netpoint.getSi_max_appl());
                    Integer si_wtx_cnt = 0;
                    Tb_order o_order = new Tb_order();
                    o_order.setSw_netpoint_id(netpoint.getSd_netpoint_id());
                    o_order.setSr_order_starttime(XcbDateUtil.getStartDay((String)XcbDateUtil.getBeforeDay((Date)new Date(), (int)90, (String)"yyyy-MM-dd")));
                    o_order.setSr_order_endtime(XcbDateUtil.getTodayEnd((Date)new Date()));
                    Integer all_cnt = this.orderDao.findAllOrderByNetId_task(o_order);
                    Integer success_cnt = this.orderDao.findSuccessOrderByNetId_task(o_order);
                    if (all_cnt == 0) {
                        all_cnt = 1;
                    }
                    if ((dc_temp_rate = BigDecimalUtil.mul((BigDecimal)(dc_temp = BigDecimalUtil.div3((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)success_cnt), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)all_cnt))), (BigDecimal)new BigDecimal(100))).compareTo(dc_rate) == 1) {
                        List<Tb_user_withdrawal_appl> list = this.userWithdrawalApplDao.findDSPUserWithdrawalAppl(appl.getSw_user_id());
                        if (list != null && list.size() > 0) {
                            si_wtx_cnt = list.size();
                            isCanAppl = si_wtx_cnt < si_max_appl ? si_click >= si_max_click.intValue() : true;
                        } else {
                            isCanAppl = false;
                            this.log.error("\u5f02\u5e38\u63d0\u73b0\u7533\u8bf7\uff0c\u627e\u4e0d\u5230\u5f53\u524d\u7528\u6237\u5f85\u5ba1\u6279\u7684\u63d0\u73b0\u8bb0\u5f55\uff0c\u63d0\u73b0ID:" + appl.getSd_id() + "\uff0c\u63d0\u73b0\u7528\u6237ID" + appl.getSw_user_id());
                        }
                    } else {
                        isCanAppl = true;
                    }
                } else {
                    isCanAppl = true;
                }
                Identifier identifier = new Identifier();
                identifier.setUserName("\u7cfb\u7edf\u5ba1\u6279");
                if (isCanAppl) {
                    for (String sd_order_id : orderArr) {
                        Tb_order order = this.orderDao.findOrderById_user(sd_order_id);
                        BigDecimal dc_deposit_refund = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_refund());
                        if (dc_deposit_refund.compareTo(BigDecimal.ZERO) == 0) {
                            BigDecimal dc_deposit_money = order.getDc_deposit_money();
                            String sr_checked = XcbStringUtils.getObjtoString((Object)order.getSr_checked());
                            this.log.info("\u4fee\u6539\u8ba2\u5355" + order.getSd_order_id() + "\u62bc\u91d1\u9000\u6b3e\u91d1\u989d:" + dc_deposit_money + "\u5143");
                            if (XcbConstantValue.ORDER_F.equals(sr_checked)) {
                                order.setSr_checked(XcbConstantValue.ORDER_T);
                            }
                            order.setDc_deposit_refund(dc_deposit_money);
                            result = this.orderDao.updateDepositRefund(order);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                Tb_wx_pay_info pay_info;
                                List<Tb_ordercash_stream> ordercashList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                Tb_ordercash_stream orderCash = ordercashList.get(0);
                                String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                                Date tm_create_time = orderCash.getTm_create_time();
                                int si_diff = XcbDateUtil.daysBetween((Date)tm_create_time, (Date)nowDate);
                                if (si_diff < 180) {
                                    int refund_fee;
                                    pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
                                    if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                                        refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                        int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                        pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                        this.wxAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                    } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                                        String refund_fee2 = XcbStringUtils.getObjtoString((Object)dc_deposit_money);
                                        String total_fee = XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money());
                                        pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                        this.wxSdjAPICommon.xcrefund(orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee2, pay_info);
                                    } else {
                                        refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                        int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                        pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                        this.wxSpAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                    }
                                } else {
                                    pay_info = this.wxPayInfoDao.findUserDefaultPayOut(user.getSr_way());
                                    if (XcbConstantValue.PAY_QY.equals(pay_info.getSr_pay_type())) {
                                        String zf_money_fen = CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money));
                                        String zf_desc = pay_info.getSr_payment_desc();
                                        String cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                                        EnterprisesPayment enterprisesPayment = new EnterprisesPayment();
                                        enterprisesPayment.setMch_appid(pay_info.getSub_appid());
                                        enterprisesPayment.setMchid(pay_info.getSub_mchid());
                                        enterprisesPayment.setNonce_str(UUidUtils.getUUid());
                                        enterprisesPayment.setPartner_trade_no(cash_trade_no);
                                        enterprisesPayment.setOpenid(user.getSr_app_open_id());
                                        enterprisesPayment.setCheck_name("NO_CHECK");
                                        enterprisesPayment.setAmount(XcbStringUtils.getObjtoint((Object)zf_money_fen));
                                        enterprisesPayment.setDesc(zf_desc);
                                        enterprisesPayment.setSpbill_create_ip(pay_info.getSr_payserver_ip());
                                        String apiKey = pay_info.getSub_merkey_v2();
                                        this.log.info("sign key ============{}", (Object)apiKey);
                                        String sign = Signature.getSign(apiKey, enterprisesPayment);
                                        enterprisesPayment.setSign(sign);
                                        this.log.info("sign====={}", (Object)sign);
                                        System.out.println("sign====={}" + sign);
                                        String xmlWithdrawInfo = this.wxWithdrawTools.getXMLStringForObj(enterprisesPayment);
                                        this.log.info("\u63d0\u73b0\u53c2\u6570\u4e3a======{}", (Object)xmlWithdrawInfo);
                                        System.out.println("\u63d0\u73b0\u53c2\u6570\u4e3a======{}" + xmlWithdrawInfo);
                                        String response = this.wxWithdrawTools.postParamesForUrl(xmlWithdrawInfo, "https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers", pay_info);
                                        this.log.info("\u63d0\u73b0\u7ed3\u679c\u4e3a==={}", (Object)response);
                                        System.out.println("\u63d0\u73b0\u7ed3\u679c\u4e3a======{}" + response);
                                        Map return_data = null;
                                        try {
                                            return_data = WXPayUtil.xmlToMap((String)response);
                                        }
                                        catch (Exception e) {
                                            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                                            this.log.error("\u4f01\u4e1a\u6253\u6b3e-\u7528\u6237\u4ed8\u6b3e-\u652f\u4ed8\u8fd4\u56de\u7ed3\u679c\u89e3\u6790\u5931\u8d25:" + XcbStringUtils.exceptionToString((Exception)e));
                                        }
                                        String return_code = (String)return_data.get("return_code");
                                        String result_code = (String)return_data.get("result_code");
                                        try {
                                            if ("SUCCESS".equals(return_code)) {
                                                Tb_cash_stream cashflow = new Tb_cash_stream();
                                                cashflow.setSd_cash_id(cash_trade_no);
                                                cashflow.setSw_company_id(user.getSw_company_id());
                                                cashflow.setSr_cashflow_remark(orderCash.getSd_ordercash_id());
                                                cashflow.setDc_cashflow_money(dc_deposit_money);
                                                cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
                                                cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                                cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                                cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                                                cashflow.setSr_remarks("\u7528\u6237" + user.getSd_user_id() + "\u4f59\u989d\u63d0\u73b0\u5230\u96f6\u94b1");
                                                this.cashStreamDao.createCashStream(cashflow);
                                            }
                                        }
                                        catch (Exception e) {
                                            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4f01\u4e1a\u6253\u6b3e-\u7528\u6237\u4f59\u989d\u63d0\u73b0\u5931\u8d25\uff0ccash_trade_no\uff1a" + cash_trade_no, "", "");
                                            operationLogs.setSr_operate_from(XcbConstantValue.PC);
                                            operationLogs.setSr_operate_primarykey(orderCash.getSd_ordercash_id());
                                            operationLogs.setSr_operate_table("tb_ordercash_stream");
                                            this.operationLogServiceImpl.createOperaLog(operationLogs);
                                        }
                                    } else {
                                        String cash_trade_no;
                                        int zf_money_fen = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                        ret = this.wxAPIV3Common.wx_pay_user(pay_info, zf_money_fen, user, cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id));
                                        result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                            Tb_cash_stream cashflow = new Tb_cash_stream();
                                            cashflow.setSd_cash_id(cash_trade_no);
                                            cashflow.setSw_company_id(user.getSw_company_id());
                                            cashflow.setSr_cashflow_remark(orderCash.getSd_ordercash_id());
                                            cashflow.setDc_cashflow_money(dc_deposit_money);
                                            cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
                                            cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                            cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                            cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                                            cashflow.setSr_remarks("\u7528\u6237" + user.getSd_user_id() + "\u4f59\u989d\u63d0\u73b0\u5230\u96f6\u94b1");
                                            result = this.cashStreamDao.createCashStream(cashflow);
                                        } else {
                                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.wx.error"));
                                        }
                                    }
                                }
                                Tb_user n_user = new Tb_user();
                                if (XcbStringUtils.isNullOrBlank((Object)user.getSi_click())) {
                                    n_user.setSi_click(Integer.valueOf(0));
                                    n_user.setTm_click_time(new Date());
                                    n_user.setSd_user_id(user.getSd_user_id());
                                    this.userDao.updateClick(n_user);
                                }
                                isSuccess = true;
                                continue;
                            }
                            this.log.error("\u8ba2\u5355\u4fee\u6539\u590d\u6838\u5f02\u5e38:" + order.getSd_order_id());
                            continue;
                        }
                        this.log.info("\u8ba2\u5355\u5df2\u9000\u6b3e:" + order.getSd_order_id());
                    }
                    appl.setTm_appl_time(new Date());
                    appl.setSr_appl_person("\u7cfb\u7edf\u5ba1\u6279");
                    appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                    this.userWithdrawalApplDao.updateUserWithdrawalAppl(appl);
                    if (isSuccess) {
                        this.wxMessageService.sendMessage(appl.getSw_user_id(), null, XcbStringUtils.getObjtoString((Object)appl.getDc_appl_money()), WxMessage.model_tx, null);
                    }
                } else {
                    Tb_user n_user = new Tb_user();
                    n_user.setSi_click(Integer.valueOf(si_click + 1));
                    n_user.setTm_click_time(new Date());
                    n_user.setSd_user_id(user.getSd_user_id());
                    this.userDao.updateClick(n_user);
                    this.userWithdrawalApplService.refuseAppl(identifier, appl, "\u7cfb\u7edf\u5ba1\u6279\uff0c\u539f\u8def\u9000\u56de");
                }
                this.log.info("########################\u7cfb\u7edf\u4efb\u52a1: \u63d0\u73b0\u7533\u8bf7ID:" + appl.getSd_id() + "\uff0c\u5ba1\u6279\u7f51\u70b9: " + netpoint.getSr_net_name() + "\u7ed3\u675f########################");
                continue;
            }
            this.log.error("\u5f02\u5e38\u63d0\u73b0\u7533\u8bf7\uff0c\u627e\u4e0d\u5230\u63d0\u73b0\u5bf9\u5e94\u7684\u8ba2\u5355\u53f7\uff0c\u63d0\u73b0ID:" + appl.getSd_id() + "\uff0c\u63d0\u73b0\u7528\u6237ID" + appl.getSw_user_id());
        }
        this.log.info("###############\u4efb\u52a1\u9000\u6b3e\u7ed3\u675f###############");
        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        ret.put(XcbConstantValue.MSG, "\u6267\u884c\u6210\u529f");
        this.initResultMap(ret);
        return ret;
    }
}

