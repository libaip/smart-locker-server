/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_opendoor_record
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.OpenDoorRecordDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_opendoor_record;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OpenDoorRecordServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private OpenDoorRecordDao openDoorRecordDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private DeviceBoxDao deviceBoxDao;
    @Autowired
    private DeviceDao deviceDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=========OpenDoorDataServiceImpl========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_opendoor_record openDoorRecord = new Tb_opendoor_record();
        String sd_openid_id = "";
        Page page = new Page();
        if (param != null) {
            openDoorRecord = (Tb_opendoor_record)param.get("openDoorRecord");
            sd_openid_id = XcbStringUtils.getObjtoString((Object)param.get("sd_openid_id"));
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.OPEN_DOOR_RECORD_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createOpenDoorRecord(openDoorRecord);
            } else if (XcbConstantValue.OPEN_DOOR_RECORD_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findOpenDoorRecordByParam_agent(identifier, openDoorRecord, page);
            } else if (XcbConstantValue.OPEN_DOOR_RECORD_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findOpenDoorRecordByParam_agent(identifier, openDoorRecord, page);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    public Map<String, Object> createOpenDoorRecord(Tb_opendoor_record openDoorData) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        try {
            result = this.openDoorRecordDao.createOpenDoorRecord(openDoorData);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                Tb_order order = this.orderDao.findOrderById_agent(openDoorData.getSw_order_id());
                if (order != null) {
                    Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(order.getSw_box_id());
                    if (XcbConstantValue.DEVICE_BOX_STATUS_JY.equals(deviceBox.getSr_box_status())) {
                        ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("opendoor.data.create.success"));
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    } else {
                        Tb_device_box n_box = new Tb_device_box();
                        n_box.setSd_box_id(order.getSw_box_id());
                        n_box.setTm_use_time(new Date());
                        if (XcbConstantValue.OPEN_DOOR_TYPE_DDJS.equals(openDoorData.getSr_type())) {
                            if (XcbConstantValue.DEVICE_BOX_STATUS_ZY.equals(deviceBox.getSr_box_status())) {
                                n_box.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_KY);
                                result = this.deviceBoxDao.updateDeviceBoxById(n_box);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("opendoor.data.create.success"));
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                                } else {
                                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebyid.fail"));
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                }
                            } else {
                                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("opendoor.data.create.success"));
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            }
                        } else if (XcbConstantValue.OPEN_DOOR_TYPE_CJDD.equals(openDoorData.getSr_type())) {
                            n_box.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_ZY);
                            result = this.deviceBoxDao.updateDeviceBoxById(n_box);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("opendoor.data.create.success"));
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            } else {
                                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("devicebox.updatebyid.fail"));
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            }
                        }
                    }
                } else {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("opendoor.data.create.success"));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                }
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("opendoor.data.create.error"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.OPEN_DOOR_RECORD_CREATE, PromptProperties.getProperty("opendoor.data.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findOpenDoorRecordByParam_agent(Identifier identifier, Tb_opendoor_record openDoorRecord, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_opendoor_record> openDoorRecordList = this.openDoorRecordDao.findOpenDoorRecordByParam_agent(openDoorRecord, page);
            int totalCount = this.openDoorRecordDao.findCountByParam_agent(openDoorRecord);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("openDoorRecordList", openDoorRecordList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.OPEN_DOOR_RECORD_FIND_BYPARAM, PromptProperties.getProperty("opendoor.record.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }
}

