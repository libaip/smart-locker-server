/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_ordercash_stream
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentRolesRelDao;
import com.jcg.agent.idao.OrderCashStreamDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_ordercash_stream;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class OrderCashStreamServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private OrderCashStreamDao orderCashStreamDao;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private AgentRolesRelDao roleRelDao;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========OrderServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_ordercash_stream orderCashStream = new Tb_ordercash_stream();
        Page page = new Page();
        if (param != null) {
            orderCashStream = (Tb_ordercash_stream)param.get("orderCashStream");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.ORDERCASHSTREAM_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderCashStreamByParam_agent(identifier, orderCashStream, page);
            } else if (XcbConstantValue.ORDERCASHSTREAM_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderCashStreamByParam_cpy(identifier, orderCashStream, page);
            } else if (XcbConstantValue.ORDERCASHSTREAM_FIND_BYORDER_CPY.equalsIgnoreCase(functionCode)) {
                String sw_order_id = XcbStringUtils.getObjtoString((Object)param.get("sw_order_id"));
                ret = this.findOrderCashStreamByOrder_cpy(identifier, sw_order_id);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findOrderCashStreamByOrder_cpy(Identifier identifier, String sw_order_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_ordercash_stream>> dataMap = new HashMap<String, List<Tb_ordercash_stream>>();
        try {
            List<Tb_ordercash_stream> orderCashStreamList = this.orderCashStreamDao.findOrderCashStreamByOrder_cpy(sw_order_id);
            for (Tb_ordercash_stream steam : orderCashStreamList) {
                steam.setSr_path(XcbConstantValue.server_host + "/jcgweb-company");
            }
            dataMap.put("orderCashStreamList", orderCashStreamList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ORDERCASHSTREAM_FIND_BYORDER_CPY, PromptProperties.getProperty("ordercashstream.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findOrderCashStreamByParam_agent(Identifier identifier, Tb_ordercash_stream orderCashStream, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_ordercash_stream> orderCashStreamList = null;
            int totalCount = 0;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(orderCashStream.getSw_agent_id());
            if ("1".equals(adminAgent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                String[] subArr = new String[subList.size()];
                subList.toArray(subArr);
                orderCashStream.setAgentArr(subArr);
                orderCashStream.setSw_agent_id(null);
                orderCashStreamList = this.orderCashStreamDao.findShowOrderCashStreamByParam_agent(orderCashStream, page);
                totalCount = this.orderCashStreamDao.findShowCountByParam_agent(orderCashStream);
            } else if ("2".equals(adminAgent.getSr_role())) {
                orderCashStream.setSr_is_steal("N");
                orderCashStreamList = this.orderCashStreamDao.findOrderCashStreamByParam_agent(orderCashStream, page);
                totalCount = this.orderCashStreamDao.findCountByParam_agent(orderCashStream);
            } else if (!"3".equals(adminAgent.getSr_role()) && "4".equals(adminAgent.getSr_role())) {
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                String[] netArr = netList.get(0).split(",");
                if (netList.size() > 0) {
                    orderCashStream.setNetArr(netArr);
                    orderCashStreamList = this.orderCashStreamDao.findOrderCashStreamByNetArr_agent(orderCashStream, page);
                    totalCount = this.orderCashStreamDao.findCountByNetArr_agent(orderCashStream);
                }
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("orderCashStreamList", orderCashStreamList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ORDERCASHSTREAM_FIND_BYPARAM, PromptProperties.getProperty("ordercashstream.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findOrderCashStreamByParam_cpy(Identifier identifier, Tb_ordercash_stream orderCashStream, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            CompletableFuture<List> orderListFuture = CompletableFuture.supplyAsync(() -> this.orderCashStreamDao.findOrderCashStreamByParam_cpy(orderCashStream, page));
            CompletableFuture<Integer> totalCountFuture = CompletableFuture.supplyAsync(() -> this.orderCashStreamDao.findCountByParam_cpy(orderCashStream));
            int totalCount = totalCountFuture.get();
            List orderCashStreamList = orderListFuture.get();
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("orderCashStreamList", orderCashStreamList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ORDERCASHSTREAM_FIND_BYPARAM_CPY, PromptProperties.getProperty("ordercashstream.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }
}

