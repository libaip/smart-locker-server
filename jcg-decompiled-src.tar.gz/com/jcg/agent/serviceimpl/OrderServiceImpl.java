/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_cash_stream
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.agent.model.Tb_netpoint
 *  com.jcg.agent.model.Tb_opendoor_record
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.agent.model.Tb_order_income
 *  com.jcg.agent.model.Tb_ordercash_stream
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.company.model.Tb_sys_param
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.user.model.Tb_user
 *  com.jcg.user.model.Tb_user_account
 *  com.jcg.user.model.Tb_user_recharge
 *  com.jcg.user.model.Tb_user_withdrawal_appl
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.agent.serviceimpl;

import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentRolesRelDao;
import com.jcg.agent.idao.CashStreamDao;
import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.DevicePackageDao;
import com.jcg.agent.idao.NetPointDao;
import com.jcg.agent.idao.OpenDoorRecordDao;
import com.jcg.agent.idao.OrderCashStreamDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.idao.OrderInComeDao;
import com.jcg.agent.idao.RechargeSetDao;
import com.jcg.agent.idao.StatisticsDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_cash_stream;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_device_package;
import com.jcg.agent.model.Tb_netpoint;
import com.jcg.agent.model.Tb_opendoor_record;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.model.Tb_order_income;
import com.jcg.agent.model.Tb_ordercash_stream;
import com.jcg.agent.model.Tb_statistics;
import com.jcg.cache.SystemParamCache;
import com.jcg.cloud.DeviceCloudServiceImpl;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.DateUtil;
import com.jcg.common.PromptProperties;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.SysParamDao;
import com.jcg.company.idao.WxPayInfoDao;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.company.serviceimpl.SysParamServiceImpl;
import com.jcg.user.idao.UserAccountDao;
import com.jcg.user.idao.UserDao;
import com.jcg.user.idao.UserRechargeDao;
import com.jcg.user.idao.UserWithdrawalApplDao;
import com.jcg.user.model.Tb_user;
import com.jcg.user.model.Tb_user_account;
import com.jcg.user.model.Tb_user_recharge;
import com.jcg.user.model.Tb_user_withdrawal_appl;
import com.jcg.wxmsg.serviceimpl.WxMessageServiceImpl;
import com.jcg.wxmsg.vo.WxAppMessage;
import com.jcg.wxmsg.vo.WxMessage;
import com.jcg.zf.wx.WxAPIV3Common;
import com.jcg.zf.wx.WxSdjAPICommon;
import com.jcg.zf.wx.WxSpAPIV3Common;
import com.jcg.zf.zfb.ZFBzfCommon;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class OrderServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private OrderCashStreamDao orderCashStreamDao;
    @Autowired
    private OpenDoorRecordDao openDoorRecordDao;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private CashStreamDao cashStreamDao;
    @Autowired
    private DeviceBoxDao deviceBoxDao;
    @Autowired
    private DeviceDao deviceDao;
    @Autowired
    private NetPointDao netPointDao;
    @Autowired
    private UserAccountDao userAccountDao;
    @Autowired
    private UserRechargeDao userRechargeDao;
    @Autowired
    private CommonLogic commonLogic;
    @Autowired
    private DevicePackageDao devicePackageDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private AgentRolesRelDao roleRelDao;
    @Autowired
    private StatisticsDao statisticsDao;
    @Autowired
    private WxAPIV3Common wxAPIV3Common;
    @Autowired
    private WxSpAPIV3Common wxSpAPIV3Common;
    @Autowired
    private WxSdjAPICommon wxSdjAPICommon;
    @Autowired
    private ZFBzfCommon zfbzfCommon;
    @Autowired
    private DeviceCloudServiceImpl deviceCloudService;
    @Autowired
    private WxMessageServiceImpl wxMessageService;
    @Autowired
    private SysParamDao sysParamDao;
    @Autowired
    private OrderInComeDao orderInComeDao;
    @Autowired
    private RedisUtil redis;
    @Autowired
    private UserWithdrawalApplDao userWithdrawalApplDao;
    @Autowired
    private SystemParamCache systemParamCache;
    @Autowired
    private RechargeSetDao rechargeSetDao;
    @Autowired
    private SysParamServiceImpl sysParamService;
    @Autowired
    private WxPayInfoDao wxPayInfoDao;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========OrderServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        String sd_order_id = null;
        Tb_order order = new Tb_order();
        Page page = new Page();
        if (param != null) {
            sd_order_id = XcbStringUtils.getObjtoString((Object)param.get("sd_order_id"));
            order = (Tb_order)param.get("order");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.ORDER_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderByParam_agent(identifier, order, page);
            } else if (XcbConstantValue.ORDER_FIND_FOREXCEL_AGENT.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderForExcel_agent(identifier, order, page);
            } else if (XcbConstantValue.ORDER_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderById_agent(identifier, sd_order_id);
            } else if (XcbConstantValue.ORDER_UPDATE.equalsIgnoreCase(functionCode)) {
                ret = this.updateOrder(identifier, order);
            } else if (XcbConstantValue.ORDER_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderByParam_cpy(identifier, order, page);
            } else if (XcbConstantValue.ORDER_FIND_FOREXCEL.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderForExcel(identifier, order, page);
            } else if (XcbConstantValue.ORDER_FIND_DEPOSIT_BYAGENT.equalsIgnoreCase(functionCode)) {
                ret = this.findDepositByAgentId(identifier, order);
            } else if (XcbConstantValue.ORDER_FIND_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderById_agent(identifier, sd_order_id);
            } else if (XcbConstantValue.ORDER_FIND_RECORD_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderRecordById_cpy(identifier, sd_order_id);
            } else if (XcbConstantValue.ORDER_UPDATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateOrder(identifier, order);
            } else if (XcbConstantValue.ORDER_BATCH_UPDATE_AD.equalsIgnoreCase(functionCode)) {
                ret = this.updateOrderAd(identifier, order);
            } else if (XcbConstantValue.ORDER_DEPOSIT_REFUND.equalsIgnoreCase(functionCode)) {
                String sr_refund_money = XcbStringUtils.getObjtoString((Object)param.get("sr_refund_money"));
                ret = this.depositRefund(identifier, sd_order_id, sr_refund_money);
            } else if (XcbConstantValue.ORDER_DATA_RESET.equalsIgnoreCase(functionCode)) {
                String[] deviceArr = (String[])param.get("deviceArr");
                String sr_password = XcbStringUtils.getObjtoString((Object)param.get("sr_password"));
                ret = this.resetData(deviceArr, sr_password);
            } else if (XcbConstantValue.ORDER_FIND_PIZHU_BYUSER.equalsIgnoreCase(functionCode)) {
                ret = this.findPizhuOrderByUser(identifier, order);
            } else if (XcbConstantValue.ORDER_UPDATE_PHONE.equalsIgnoreCase(functionCode)) {
                ret = this.updatePhone(identifier, order);
            } else if (XcbConstantValue.ORDER_FIND_ALL_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findAllOrderByParam(identifier, order, page);
            } else if (XcbConstantValue.ORDER_UPDATE_BOX_WEB.equalsIgnoreCase(functionCode)) {
                ret = this.updateBoxByWeb(identifier, order);
            } else if (XcbConstantValue.ORDER_REUSE_BYWEB.equalsIgnoreCase(functionCode)) {
                ret = this.reUseBoxByWeb(identifier, order);
            } else if (XcbConstantValue.ORDER_FIND_BYPARAM_CPYMB.equalsIgnoreCase(functionCode)) {
                String dateRange = XcbStringUtils.getObjtoString((Object)param.get("dateRange"));
                ret = this.findOrderByParam_cpymb(identifier, order, dateRange, page);
            } else if (XcbConstantValue.ORDER_FIND_ALL_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderById_agentmb(identifier, order);
            } else if (XcbConstantValue.ORDER_PAYNOTIFY.equalsIgnoreCase(functionCode)) {
                ret = this.orderPayNotify(identifier, param);
            } else if (XcbConstantValue.ORDER_TEMPORARY_PAYNOTIFY.equalsIgnoreCase(functionCode)) {
                ret = this.orderTemporaryPayNotify(identifier, param);
            } else if (XcbConstantValue.ORDER_FINISH_PAYNOTIFY.equalsIgnoreCase(functionCode)) {
                ret = this.orderFinishPayNotify(identifier, param);
            } else if (XcbConstantValue.ORDER_ZHPAYEVENT.equalsIgnoreCase(functionCode)) {
                Integer sd_id = XcbStringUtils.getObjtoint((Object)param.get("sd_id"));
                ret = this.zhPayEvent(identifier, order, sd_id);
            } else if (XcbConstantValue.ORDER_FIND_BYPARAM_USER.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderByParam_user(identifier, order, page);
            } else if (XcbConstantValue.ORDER_FIND_BYID_USER.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderById_user(identifier, sd_order_id);
            } else if (XcbConstantValue.ORDER_FIND_BYID_USER_FINISH.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderById_finish(identifier, sd_order_id);
            } else if (XcbConstantValue.ORDER_CLOSE.equalsIgnoreCase(functionCode)) {
                String sr_type = XcbStringUtils.getObjtoString((Object)param.get("sr_type"));
                String sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                ret = this.finishOrderById(identifier, sd_order_id, sr_type, sr_way);
            } else if (XcbConstantValue.ORDER_FOR_ACCOUNT.equalsIgnoreCase(functionCode)) {
                BigDecimal totalMoney = XcbStringUtils.getObjToBigDecimal((Object)param.get("totalMoney"));
                ret = this.finishOrderForAccount(identifier, order, totalMoney);
            } else if (XcbConstantValue.ORDER_TEMPORARY_FOR_ACCOUNT.equalsIgnoreCase(functionCode)) {
                BigDecimal totalMoney = XcbStringUtils.getObjToBigDecimal((Object)param.get("totalMoney"));
                ret = this.temporaryOrderForAccount(identifier, order, totalMoney);
            } else if (XcbConstantValue.ORDER_FOR_RECHARGE.equalsIgnoreCase(functionCode)) {
                BigDecimal totalMoney = XcbStringUtils.getObjToBigDecimal((Object)param.get("totalMoney"));
                ret = this.finishOrderForRecharge(identifier, order, totalMoney);
            } else if (XcbConstantValue.ORDER_FIND_BYPWD.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderByPwd(identifier, order);
            } else if (XcbConstantValue.ORDER_FINISH.equalsIgnoreCase(functionCode)) {
                String sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                ret = this.finishOrder(identifier, order, sr_way);
            } else if (XcbConstantValue.ORDER_TKNOTIFY.equalsIgnoreCase(functionCode)) {
                String sd_ordercash_id = XcbStringUtils.getObjtoString((Object)param.get("sd_ordercash_id"));
                String sd_cash_id = XcbStringUtils.getObjtoString((Object)param.get("sd_cash_id"));
                String refund_fee = XcbStringUtils.getObjtoString((Object)param.get("refund_fee"));
                ret = this.tkNotify(identifier, sd_ordercash_id, refund_fee, sd_cash_id);
            } else if (XcbConstantValue.ORDER_AUTO_TKNOTIFY.equalsIgnoreCase(functionCode)) {
                String sd_ordercash_id = XcbStringUtils.getObjtoString((Object)param.get("sd_ordercash_id"));
                String sd_cash_id = XcbStringUtils.getObjtoString((Object)param.get("sd_cash_id"));
                String refund_fee = XcbStringUtils.getObjtoString((Object)param.get("refund_fee"));
                ret = this.autoTkNotify(identifier, sd_ordercash_id, refund_fee, sd_cash_id);
            } else if (XcbConstantValue.ORDER_CHECK_PAYNOTIFY.equalsIgnoreCase(functionCode)) {
                String sd_ordercash_id = XcbStringUtils.getObjtoString((Object)param.get("sd_ordercash_id"));
                ret = this.checkPayNotifyInfo(sd_ordercash_id, sd_order_id);
            } else if (XcbConstantValue.ORDER_FIND_BYUSER.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderByUser(order);
            } else if (XcbConstantValue.ORDER_FIND_BYLAST.equalsIgnoreCase(functionCode)) {
                String type = XcbStringUtils.getObjtoString((Object)param.get("type"));
                ret = this.findOrderByLast(order, type);
            } else if (XcbConstantValue.ORDER_FIND_BYPARAM_AGENTMB.equalsIgnoreCase(functionCode)) {
                String dateRange = XcbStringUtils.getObjtoString((Object)param.get("dateRange"));
                ret = this.findOrderByParam_agentmb(identifier, order, dateRange, page);
            } else if (XcbConstantValue.ORDER_FIND_BYID_AGENTMB.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderById_agentmb(identifier, order);
            } else if (XcbConstantValue.ORDER_TK_CHECK_AGENT.equalsIgnoreCase(functionCode)) {
                String sd_ordercash_id = XcbStringUtils.getObjtoString((Object)param.get("sd_ordercash_id"));
                String sr_refund_money = XcbStringUtils.getObjtoString((Object)param.get("sr_refund_money"));
                String sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                ret = this.checkRefund(identifier, sd_ordercash_id, sr_refund_money, sr_way);
            } else if (XcbConstantValue.ORDER_REFUND.equalsIgnoreCase(functionCode)) {
                String sd_ordercash_id = XcbStringUtils.getObjtoString((Object)param.get("sd_ordercash_id"));
                String sr_refund_money = XcbStringUtils.getObjtoString((Object)param.get("sr_refund_money"));
                ret = this.refund(identifier, sd_ordercash_id, sr_refund_money);
            } else if (XcbConstantValue.ORDER_FIND_BYUSER.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderByUser(order);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> updatePhone(Identifier identifier, Tb_order order) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_iphone_num())) {
                Tb_order o_order = this.orderDao.findOrderById_user(order.getSd_order_id());
                if (o_order != null) {
                    Tb_order n_order = new Tb_order();
                    n_order.setSd_order_id(o_order.getSd_order_id());
                    n_order.setSr_iphone_num(order.getSr_iphone_num());
                    int result = this.orderDao.updateOrderPhone(n_order);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        Tb_user user = this.userDao.findUserById(o_order.getSw_user_id());
                        user.setSr_user_name(order.getSr_iphone_num());
                        this.userDao.updateUserForName(user);
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret_method.put(XcbConstantValue.MSG, "\u4fee\u6539\u6210\u529f");
                    } else {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u4fee\u6539\u624b\u673a\u53f7\u7801\u5f02\u5e38");
                    }
                } else {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u8ba2\u5355\u4e0d\u5b58\u5728\uff0c\u8bf7\u6838\u5bf9\u8ba2\u5355\u53f7");
                }
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u8bf7\u8f93\u5165\u8981\u4fee\u6539\u7684\u624b\u673a\u53f7\u7801");
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ORDER_UPDATE_PHONE, "\u4fee\u6539\u624b\u673a\u53f7\u7801\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> reUseBoxByWeb(Identifier identifier, Tb_order order) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_order o_order = this.orderDao.findOrderById_user(order.getSd_order_id());
            Tb_device_box box = this.deviceBoxDao.findDeviceBoxById_user(o_order.getSw_box_id());
            if (XcbConstantValue.DEVICE_BOX_STATUS_KY.equals(box.getSr_box_status())) {
                Tb_order n_order = new Tb_order();
                n_order.setSd_order_id(o_order.getSd_order_id());
                n_order.setSr_order_status(XcbConstantValue.ORDER_GO);
                n_order.setTm_order_endtime(null);
                n_order.setTm_modify_time(new Date());
                n_order.setSr_is_reuse("Y");
                int result = this.orderDao.updateGoOrder(n_order);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    box.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_ZY);
                    this.deviceBoxDao.updateDeviceBoxById(box);
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret_method.put(XcbConstantValue.MSG, "\u91cd\u65b0\u5360\u7528\u6210\u529f");
                } else {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u66f4\u65b0\u8ba2\u5355\u5f02\u5e38\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
                }
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u67dc\u95e8\u5df2\u88ab" + box.getSr_box_status_desc() + "\uff0c\u8bf7\u6838\u5b9e");
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_REUSE_BYWEB, "\u66f4\u65b0\u8ba2\u5355\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> updateBoxByWeb(Identifier identifier, Tb_order order) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_order o_order = this.orderDao.findOrderById_user(order.getSd_order_id());
            if (XcbConstantValue.ORDER_GO.equals(o_order.getSr_order_status())) {
                Integer sw_box_id = order.getSw_box_id();
                if (!sw_box_id.equals(o_order.getSw_box_id())) {
                    Tb_device_box box_new = this.deviceBoxDao.findDeviceBoxById_user(sw_box_id);
                    Tb_order n_order = new Tb_order();
                    n_order.setSd_order_id(o_order.getSd_order_id());
                    n_order.setSw_box_id(sw_box_id);
                    n_order.setSr_alias_desc(box_new.getSr_alias() + box_new.getSr_alias_number() + "\u53f7");
                    int result = this.orderDao.updateDeviceBoxByWeb(n_order);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        box_new.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_ZY);
                        this.deviceBoxDao.updateDeviceBoxById(box_new);
                        Tb_device_box box_old = this.deviceBoxDao.findDeviceBoxById_user(o_order.getSw_box_id());
                        box_old.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_JY);
                        this.deviceBoxDao.updateDeviceBoxById(box_old);
                        n_order = this.orderDao.findOrderById_user(o_order.getSd_order_id());
                        Tb_user user = this.userDao.findUserById(n_order.getSw_user_id());
                        if (user != null) {
                            if ("Y".equals(user.getSr_is_subscribe())) {
                                this.sendWXMessage(n_order, n_order.getDc_actual_income(), "CREATE");
                            } else if ("Y".equals(user.getSr_subscribe_create())) {
                                this.sendWXAppMessage(n_order, n_order.getDc_actual_income(), "CREATE");
                            }
                        }
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret_method.put(XcbConstantValue.MSG, "\u66f4\u6362\u6210\u529f");
                    } else {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u66f4\u6362\u67dc\u95e8\u5f02\u5e38\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
                    }
                } else {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u67dc\u95e8\u53f7\u76f8\u540c\uff0c\u65e0\u9700\u91cd\u590d\u66f4\u6362");
                }
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u8ba2\u5355\u5df2\u7ecf\u7ed3\u675f\uff0c\u4e0d\u53ef\u66f4\u6362\u67dc\u95e8");
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_UPDATE_BOX_WEB, "\u66f4\u6362\u8ba2\u5355\u67dc\u95e8\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findAllOrderByParam(Identifier identifier, Tb_order order, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            page = new Page();
            String sr_order_time_start = "";
            String sr_order_time_end = "";
            Tb_sys_param sys1 = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.AD_REN_START_DATE);
            Tb_sys_param sys2 = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.AD_REN_END_DATE);
            if (sys1 != null && sys2 != null) {
                sr_order_time_start = XcbDateUtil.getStartDay((String)sys1.getSr_param_value());
                sr_order_time_end = XcbDateUtil.getEndDay((String)sys2.getSr_param_value());
            }
            if (!XcbStringUtils.isNullOrBlank((Object)order.getSw_bus_order_id())) {
                Tb_ordercash_stream os = this.orderCashStreamDao.findOrderCashStreamByWxOrder(order.getSw_bus_order_id());
                order.setSd_order_id(os.getSw_order_id());
            }
            order.setSr_order_time_start(sr_order_time_start);
            order.setSr_order_time_end(sr_order_time_end);
            List<Tb_order> orders = this.orderDao.findOrderByParam_web(order);
            int totalCount = orders.size();
            for (int i = 0; i < orders.size(); ++i) {
                Tb_order o = orders.get(i);
                if (XcbConstantValue.ORDER_CASH_TYPE_WX.equals(o.getSr_cash_type())) {
                    o.setSr_is_show_deposit_refund(true);
                } else {
                    o.setSr_is_show_deposit_refund(false);
                }
                o.setSr_path(XcbConstantValue.server_host + "/jcgweb-company");
                o.setSr_path_name(o.getSr_way_desc());
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("orders", orders);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_ALL_BYPARAM, PromptProperties.getProperty("order.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findDepositByAgentId(Identifier identifier, Tb_order order) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_agent agent = this.agentDao.findAgentById_agent(order.getSw_agent_id());
            if (!XcbConstantValue.Y_STRING.equals(agent.getSr_is_deposit())) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.deposit.warn"));
                return ret_method;
            }
            BigDecimal bonus = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_second_bonus());
            if (bonus.compareTo(BigDecimal.ZERO) <= 0) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.deposit.warn2"));
                return ret_method;
            }
            String lastMaxMonthDate = XcbDateUtil.getLastMaxMonthDate();
            Map orderAllMap = CommonFunction.null2HashMap(this.orderDao.findAllDepositByAgentId(order.getSw_agent_id(), lastMaxMonthDate));
            BigDecimal depositAll = XcbStringUtils.getObjToBigDecimal(orderAllMap.get("dc_deposit_money_sum"));
            int cnt = this.orderDao.findAllCountDepositByAgentId(order.getSw_agent_id(), lastMaxMonthDate);
            Map orderMap_X = CommonFunction.null2HashMap(this.orderDao.findDepositByAgentId(order.getSw_agent_id(), XcbConstantValue.ORDER_X, lastMaxMonthDate));
            BigDecimal depositX = XcbStringUtils.getObjToBigDecimal(orderMap_X.get("dc_deposit_money_sum"));
            Tb_order start_order = this.orderDao.findStartOrderByX(order.getSw_agent_id(), XcbConstantValue.ORDER_X, lastMaxMonthDate);
            String sr_start_date = start_order.getSr_create_time();
            String sr_create_time_start = start_order.getSr_create_time_start();
            Tb_order end_order = this.orderDao.findEndOrderByX(order.getSw_agent_id(), XcbConstantValue.ORDER_X, lastMaxMonthDate);
            String sr_end_date = end_order.getSr_create_time();
            String sr_create_time_end = XcbDateUtil.getEndDay((String)lastMaxMonthDate);
            int si_cnt = this.orderDao.findCountDeposit(order.getSw_agent_id(), sr_create_time_start, sr_create_time_end);
            Map orderMap_T = CommonFunction.null2HashMap(this.orderDao.findDepositByAgentId(order.getSw_agent_id(), XcbConstantValue.ORDER_T, lastMaxMonthDate));
            BigDecimal depositT = XcbStringUtils.getObjToBigDecimal(orderMap_T.get("dc_deposit_money_sum"));
            BigDecimal dc_deposit_money_sum = BigDecimalUtil.sub((BigDecimal)depositX, (BigDecimal)depositT);
            BigDecimal temp = XcbStringUtils.getObjToBigDecimal((Object)BigDecimalUtil.div3((BigDecimal)dc_deposit_money_sum, (BigDecimal)depositAll));
            BigDecimal dc_save_rate = BigDecimalUtil.mul((BigDecimal)temp, (BigDecimal)new BigDecimal(100));
            BigDecimal dc_up_money = BigDecimalUtil.mul((BigDecimal)dc_deposit_money_sum, (BigDecimal)BigDecimalUtil.div((BigDecimal)bonus, (BigDecimal)new BigDecimal(100)));
            dataMap.put("dc_up_money", dc_up_money);
            BigDecimal dc_price = BigDecimalUtil.div((BigDecimal)dc_deposit_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)cnt));
            dataMap.put("agent", agent);
            dataMap.put("depositX", depositX);
            dataMap.put("depositT", depositT);
            dataMap.put("cnt", cnt);
            dataMap.put("dc_save_rate", dc_save_rate);
            dataMap.put("depositAll", depositAll);
            dataMap.put("si_cnt", si_cnt);
            dataMap.put("dc_save_money", dc_deposit_money_sum);
            dataMap.put("dc_price", dc_price);
            dataMap.put("sr_start_date", sr_start_date);
            dataMap.put("sr_end_date", sr_end_date);
            dataMap.put("dc_deposit_money_sum", dc_deposit_money_sum);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.DATA, dataMap);
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_FIND_DEPOSIT_BYAGENT + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            throw new BusinessException(XcbConstantValue.ORDER_FIND_DEPOSIT_BYAGENT, PromptProperties.getProperty("agent.findbyparam.fail"), (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> findPizhuOrderByUser(Identifier identifier, Tb_order order) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_order>> dataMap = new HashMap<String, List<Tb_order>>();
        try {
            List<Tb_order> orderList = this.orderDao.findPizhuOrderByUser(order);
            dataMap.put("orderList", orderList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_FIND_PIZHU_BYUSER + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            throw new BusinessException(XcbConstantValue.ORDER_FIND_PIZHU_BYUSER, PromptProperties.getProperty("order.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    Map<String, Object> depositRefund(Identifier identifier, String sd_order_id, String sr_refund_money) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        String msg = "";
        try {
            String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
            Tb_order order = this.orderDao.findOrderById_agent(sd_order_id);
            if ("GO".equals(order.getSr_order_status())) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u8ba2\u5355\u672a\u7ed3\u675f\uff0c\u4e0d\u53ef\u64cd\u4f5c");
                this.initResultMap(ret_method);
                return ret_method;
            }
            Tb_user user = this.userDao.findUserById(order.getSw_user_id());
            Tb_wx_pay_info pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
            BigDecimal dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
            BigDecimal dc_deposit_refund = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_refund());
            BigDecimal dc_refund_money = XcbStringUtils.getObjToBigDecimal((Object)sr_refund_money);
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
            BigDecimal dc_account_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money());
            BigDecimal totalMoney = BigDecimalUtil.add((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money()), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_remark_money()));
            List<Tb_user_withdrawal_appl> list = this.userWithdrawalApplDao.findDSPUserWithdrawalAppl(order.getSw_user_id());
            if (list != null && list.size() > 0) {
                if (dc_deposit_money.compareTo(BigDecimal.ZERO) == 1) {
                    BigDecimal dc_appl_money;
                    if (XcbStringUtils.isNullOrBlank((Object)sr_refund_money)) {
                        sr_refund_money = XcbStringUtils.getObjtoString((Object)dc_deposit_money);
                        dc_refund_money = XcbStringUtils.getObjToBigDecimal((Object)sr_refund_money);
                    }
                    Tb_user_withdrawal_appl tk_appl = new Tb_user_withdrawal_appl();
                    for (Tb_user_withdrawal_appl appl : list) {
                        String sr_order_arr = XcbStringUtils.getObjtoString((Object)appl.getSr_order_arr());
                        if (!XcbStringUtils.isNullOrBlank((Object)sr_order_arr)) {
                            String[] orderArr = sr_order_arr.split(",");
                            List<String> order_list = Arrays.asList(orderArr);
                            if (!order_list.contains(order.getSd_order_id())) continue;
                            tk_appl = appl;
                            break;
                        }
                        msg = "\u8ba2\u5355\u53c2\u6570\u7f3a\u5931\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458";
                        break;
                    }
                    if ((dc_appl_money = XcbStringUtils.getObjToBigDecimal((Object)tk_appl.getDc_appl_money())).compareTo(BigDecimal.ZERO) == 1) {
                        Tb_user_withdrawal_appl new_appl = new Tb_user_withdrawal_appl();
                        String sr_arr = tk_appl.getSr_order_arr();
                        if (!XcbStringUtils.isNullOrBlank((Object)sr_arr)) {
                            String[] arr = sr_arr.split(",");
                            StringBuffer sb = new StringBuffer();
                            for (int i = 0; i < arr.length; ++i) {
                                String id = arr[i];
                                if (order.getSd_order_id().equals(id)) continue;
                                sb.append(id).append(",");
                            }
                            BigDecimal dc_appl_money_new = BigDecimalUtil.sub((BigDecimal)dc_appl_money, (BigDecimal)dc_refund_money);
                            String sr_order_arr = "";
                            if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
                                sr_order_arr = sb.deleteCharAt(sb.length() - 1).toString();
                            }
                            if (dc_appl_money_new.compareTo(BigDecimal.ZERO) == 0) {
                                new_appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                                new_appl.setSr_appl_person(identifier.getUserName());
                                new_appl.setTm_appl_time(new Date());
                            }
                            new_appl.setSr_order_arr(sr_order_arr);
                            new_appl.setSd_id(tk_appl.getSd_id());
                            new_appl.setDc_appl_money(dc_appl_money_new);
                            new_appl.setTm_modify_time(new Date());
                            int reuslt = this.userWithdrawalApplDao.updateUserWithdrawalAppl_cpy(new_appl);
                            if (reuslt > XcbConstantValue.OPERA_INT_ZERO) {
                                List<Tb_ordercash_stream> cashList = this.orderCashStreamDao.findOrderCashStreamByOrderId(sd_order_id);
                                if (cashList != null && cashList.size() > 0) {
                                    Tb_ordercash_stream orderCash = cashList.get(0);
                                    if (!XcbStringUtils.isNullOrBlank((Object)orderCash.getSw_bus_order_id())) {
                                        BigDecimal n_deposit_refund = BigDecimalUtil.add((BigDecimal)dc_deposit_refund, (BigDecimal)dc_refund_money);
                                        String sr_checked = XcbStringUtils.getObjtoString((Object)order.getSr_checked());
                                        Tb_order n_order = new Tb_order();
                                        if (XcbConstantValue.ORDER_F.equals(sr_checked)) {
                                            n_order.setSr_checked(XcbConstantValue.ORDER_T);
                                        }
                                        n_order.setSd_order_id(sd_order_id);
                                        n_order.setDc_deposit_refund(n_deposit_refund);
                                        result = this.orderDao.updateDepositRefund(n_order);
                                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                            Tb_user_withdrawal_appl userWithdrawalAppl = new Tb_user_withdrawal_appl();
                                            userWithdrawalAppl.setSi_create_person(order.getSw_user_id());
                                            userWithdrawalAppl.setTm_create_time(new Date());
                                            userWithdrawalAppl.setSi_modify_person(order.getSw_user_id());
                                            userWithdrawalAppl.setTm_modify_time(new Date());
                                            userWithdrawalAppl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                                            userWithdrawalAppl.setSr_type(XcbConstantValue.WITHDRAWAL_APPL_WX);
                                            userWithdrawalAppl.setTm_appl_time(new Date());
                                            userWithdrawalAppl.setSr_appl_person(identifier.getUserName());
                                            userWithdrawalAppl.setDc_appl_money(dc_refund_money);
                                            userWithdrawalAppl.setSw_user_id(order.getSw_user_id());
                                            userWithdrawalAppl.setSr_order_arr(order.getSd_order_id());
                                            result = this.userWithdrawalApplDao.createUserWithdrawalAppl(userWithdrawalAppl);
                                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                                Map<Object, Object> rtnMap = new HashMap();
                                                if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                                                    int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund_money)));
                                                    int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                                    pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                                    rtnMap = this.wxAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                                } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                                                    String refund_fee = XcbStringUtils.getObjtoString((Object)dc_refund_money);
                                                    String total_fee = XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money());
                                                    pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                                    rtnMap = this.wxSdjAPICommon.xcrefund(orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                                } else {
                                                    int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund_money)));
                                                    int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                                    pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                                    rtnMap = this.wxSpAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                                }
                                                result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                                                msg = result > XcbConstantValue.OPERA_INT_ZERO ? "\u62bc\u91d1\u9000\u6b3e\u6210\u529f" : XcbStringUtils.getObjtoString((Object)rtnMap.get(XcbConstantValue.MSG));
                                            } else {
                                                msg = "\u521b\u5efa\u63d0\u73b0\u8bb0\u5f55\u5f02\u5e38";
                                            }
                                        } else {
                                            msg = "\u66f4\u65b0\u5931\u8d25\uff0c\u5fae\u4fe1\u9000\u6b3e\u5f02\u5e38";
                                        }
                                    } else {
                                        msg = "\u67e5\u65e0\u8ba2\u5355\u652f\u4ed8\u6d41\u6c34\uff0c\u4e0d\u53ef\u9000\u6b3e\u3002";
                                    }
                                } else {
                                    msg = "\u67e5\u65e0\u8ba2\u5355\u652f\u4ed8\u6d41\u6c34\uff0c\u4e0d\u53ef\u9000\u6b3e\u3002";
                                }
                            } else {
                                msg = "\u66f4\u65b0\u63d0\u73b0\u7533\u8bf7\u8bb0\u5f55\u5f02\u5e38\uff0c\u4e0d\u53ef\u9000\u6b3e\u3002";
                            }
                        } else {
                            msg = "\u67e5\u65e0\u7533\u8bf7\u8bb0\u5f55\u5bf9\u5e94\u7684\u8ba2\u5355\u5217\u8868\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458";
                        }
                    } else {
                        msg = "\u7533\u8bf7\u8bb0\u5f55\u91d1\u989d\u4e3a0\uff0c\u4e0d\u53ef\u9000\u6b3e";
                    }
                } else {
                    msg = "\u8ba2\u5355\u65e0\u62bc\u91d1\uff0c\u4e0d\u53ef\u62bc\u91d1\u9000\u6b3e\u3002";
                }
            } else if (dc_deposit_money.compareTo(BigDecimal.ZERO) == 1) {
                BigDecimal tmpMoney;
                if (XcbStringUtils.isNullOrBlank((Object)sr_refund_money)) {
                    sr_refund_money = XcbStringUtils.getObjtoString((Object)dc_deposit_money);
                    dc_refund_money = XcbStringUtils.getObjToBigDecimal((Object)sr_refund_money);
                }
                if ((tmpMoney = BigDecimalUtil.sub((BigDecimal)dc_deposit_money, (BigDecimal)dc_deposit_refund)).compareTo(dc_refund_money) >= 0) {
                    if (totalMoney.compareTo(dc_refund_money) >= 0) {
                        if (dc_account_money.compareTo(dc_refund_money) >= 0) {
                            result = this.commonLogic.updateUser_account(identifier, dc_refund_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_CZ);
                        } else {
                            result = this.commonLogic.updateUser_account(identifier, dc_account_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_CZ);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                BigDecimal money = BigDecimalUtil.sub((BigDecimal)dc_refund_money, (BigDecimal)dc_account_money);
                                result = this.commonLogic.updateRemarkUser_account(identifier, money, userAccount, XcbConstantValue.TB_TYPE_MINUS);
                            }
                        }
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            List<Tb_ordercash_stream> cashList = this.orderCashStreamDao.findOrderCashStreamByOrderId(sd_order_id);
                            if (cashList != null && cashList.size() > 0) {
                                Tb_ordercash_stream orderCash = cashList.get(0);
                                if (!XcbStringUtils.isNullOrBlank((Object)orderCash.getSw_bus_order_id())) {
                                    BigDecimal n_deposit_refund = BigDecimalUtil.add((BigDecimal)dc_deposit_refund, (BigDecimal)dc_refund_money);
                                    String sr_checked = XcbStringUtils.getObjtoString((Object)order.getSr_checked());
                                    Tb_order n_order = new Tb_order();
                                    if (XcbConstantValue.ORDER_F.equals(sr_checked)) {
                                        n_order.setSr_checked(XcbConstantValue.ORDER_T);
                                    }
                                    n_order.setSd_order_id(sd_order_id);
                                    n_order.setDc_deposit_refund(n_deposit_refund);
                                    result = this.orderDao.updateDepositRefund(n_order);
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        Tb_user_withdrawal_appl userWithdrawalAppl = new Tb_user_withdrawal_appl();
                                        userWithdrawalAppl.setSi_create_person(order.getSw_user_id());
                                        userWithdrawalAppl.setTm_create_time(new Date());
                                        userWithdrawalAppl.setSi_modify_person(order.getSw_user_id());
                                        userWithdrawalAppl.setTm_modify_time(new Date());
                                        userWithdrawalAppl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                                        userWithdrawalAppl.setSr_type(XcbConstantValue.WITHDRAWAL_APPL_WX);
                                        userWithdrawalAppl.setTm_appl_time(new Date());
                                        userWithdrawalAppl.setSr_appl_person(identifier.getUserName());
                                        userWithdrawalAppl.setDc_appl_money(dc_refund_money);
                                        userWithdrawalAppl.setSw_user_id(order.getSw_user_id());
                                        result = this.userWithdrawalApplDao.createUserWithdrawalAppl(userWithdrawalAppl);
                                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                            Map<Object, Object> rtnMap = new HashMap();
                                            if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                                                int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund_money)));
                                                int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                                pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                                rtnMap = this.wxAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                            } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                                                String refund_fee = XcbStringUtils.getObjtoString((Object)dc_refund_money);
                                                String total_fee = XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money());
                                                pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                                rtnMap = this.wxSdjAPICommon.xcrefund(orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                            } else {
                                                int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund_money)));
                                                int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                                pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                                rtnMap = this.wxSpAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                            }
                                            result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                                            msg = result > XcbConstantValue.OPERA_INT_ZERO ? "\u62bc\u91d1\u9000\u6b3e\u6210\u529f" : XcbStringUtils.getObjtoString((Object)rtnMap.get(XcbConstantValue.MSG));
                                        } else {
                                            msg = "\u521b\u5efa\u63d0\u73b0\u8bb0\u5f55\u5f02\u5e38";
                                        }
                                    } else {
                                        msg = "\u66f4\u65b0\u5931\u8d25\uff0c\u5fae\u4fe1\u9000\u6b3e\u5f02\u5e38";
                                    }
                                } else {
                                    msg = "\u67e5\u65e0\u8ba2\u5355\u652f\u4ed8\u6d41\u6c34\uff0c\u4e0d\u53ef\u9000\u6b3e\u3002";
                                }
                            } else {
                                msg = "\u67e5\u65e0\u8ba2\u5355\u652f\u4ed8\u6d41\u6c34\uff0c\u4e0d\u53ef\u9000\u6b3e\u3002";
                            }
                        } else {
                            msg = "\u7528\u6237\u4f59\u989d\u66f4\u65b0\u5f02\u5e38";
                        }
                    } else {
                        msg = "\u7528\u6237\u4f59\u989d\u4e0d\u8db3\uff0c\u4e0d\u53ef\u62bc\u91d1\u9000\u6b3e\u3002";
                    }
                } else {
                    msg = "\u5269\u4f59\u53ef\u9000\u62bc\u91d1\u7684\u4f59\u989d\u4e0d\u8db3\u3002";
                }
            } else {
                msg = "\u8ba2\u5355\u65e0\u62bc\u91d1\uff0c\u4e0d\u53ef\u62bc\u91d1\u9000\u6b3e\u3002";
            }
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
            ret_method.put(XcbConstantValue.MSG, msg);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_DEPOSIT_REFUND + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        return ret_method;
    }

    private Map<String, Object> findOrderByUser(Tb_order order) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_order>> dataMap = new HashMap<String, List<Tb_order>>();
        try {
            List<Tb_order> orders = this.orderDao.findOrderByUser(order);
            for (int i = 0; i < orders.size(); ++i) {
                Tb_order o_order = orders.get(i);
                Integer sw_box_id = o_order.getSw_box_id();
                Tb_device_box box = this.deviceBoxDao.findDeviceBoxById_user(sw_box_id);
                o_order.setDeviceBox(box);
            }
            dataMap.put("orders", orders);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYUSER, PromptProperties.getProperty("order.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findOrderByLast(Tb_order order, String type) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_order n_order = new Tb_order();
            boolean isWarn = true;
            if (!XcbStringUtils.isNullOrBlank((Object)type) && "appl".equals(type)) {
                n_order = this.orderDao.findLastOrderByUser_wtx(order.getSw_user_id());
                if (n_order == null) {
                    n_order = this.orderDao.findLastOrderByUser_wtx2(order.getSw_user_id());
                }
                if (n_order != null) {
                    Map<String, Object> rtnMap;
                    String msg;
                    Tb_device_box box = this.deviceBoxDao.findDeviceBoxById_user(n_order.getSw_box_id());
                    if (box != null && "\u5173\u95ed".equals(msg = XcbStringUtils.getObjtoString((Object)(rtnMap = this.deviceCloudService.getState_agent(box)).get(XcbConstantValue.MSG)))) {
                        isWarn = false;
                    }
                } else {
                    isWarn = false;
                }
            } else {
                n_order = this.orderDao.findOrderByLast(order);
            }
            dataMap.put("order", n_order);
            dataMap.put("isWarn", isWarn);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYLAST, PromptProperties.getProperty("order.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findOrderById_user(Identifier identifier, String sd_order_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            String sr_remarks;
            if (XcbStringUtils.isNullOrBlank((Object)sd_order_id)) {
                ret_method.put(XcbConstantValue.MSG, "\u8ba2\u5355\u53f7\u4e0d\u80fd\u4e3a\u7a7a");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                return ret_method;
            }
            Tb_order order = this.orderDao.findOrderById_user(sd_order_id);
            List<Tb_ordercash_stream> list = this.orderCashStreamDao.findOrderCashStreamByOrderId(sd_order_id);
            if (list != null && list.size() > 0) {
                order.setSw_ordercash_id(list.get(0).getSd_ordercash_id());
            }
            Tb_device_box box = this.deviceBoxDao.findDeviceBoxById_user(order.getSw_box_id());
            order.setDeviceBox(box);
            Date nowDate = new Date();
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                sr_remarks = "";
                Integer si_fee_time = XcbStringUtils.getObjtoint((Object)order.getSi_fee_time());
                Integer si_time_slot = XcbStringUtils.getObjtoint((Object)order.getSi_time_slot());
                String msg = "\u591a\u9000\u5c11\u8865";
                if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_iphone_num())) {
                    msg = "\u591a\u9000\u5c11\u4e0d\u8865";
                }
                String fee_time = XcbDateUtil.toHourMin((int)si_fee_time);
                String time_slot = XcbDateUtil.toHourMin((int)si_time_slot);
                sr_remarks = PromptProperties.getProperty("order.remarks.asjf3", fee_time, order.getDc_advance_price(), order.getDc_hour_price(), order.getSi_max_hour(), order.getDc_max_xf(), order.getSr_maxservice_time(), msg, time_slot);
                order.setSr_remarks(sr_remarks);
                this.calculateTime(order, nowDate);
                order.setTm_order_endtime(nowDate);
            } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
                sr_remarks = "";
                sr_remarks = order.getDc_deposit_money().compareTo(BigDecimal.ZERO) == 1 ? PromptProperties.getProperty("order.remarks.acjf2", order.getDc_once_price(), order.getDc_deposit_money(), order.getSr_maxservice_time()) : PromptProperties.getProperty("order.remarks.acjf", order.getDc_once_price(), order.getSr_maxservice_time());
                order.setSr_remarks(sr_remarks);
                this.calculateTime(order, nowDate);
                order.setTm_order_endtime(nowDate);
            } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
                sr_remarks = "";
                sr_remarks = order.getDc_deposit_money().compareTo(BigDecimal.ZERO) == 1 ? PromptProperties.getProperty("order.remarks.mf2", order.getDc_deposit_money(), order.getSr_maxservice_time()) : PromptProperties.getProperty("order.remarks.mf", order.getSr_maxservice_time());
                order.setSr_remarks(sr_remarks);
                this.calculateTime(order, nowDate);
                order.setTm_order_endtime(nowDate);
            }
            List<Tb_opendoor_record> recordList = this.openDoorRecordDao.findOpenDoorRecordByOrder(sd_order_id);
            dataMap.put("order", order);
            dataMap.put("recordList", recordList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYID_USER, PromptProperties.getProperty("order.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findOrderById_finish(Identifier identifier, String sd_order_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_order> dataMap = new HashMap<String, Tb_order>();
        try {
            Tb_order order = this.orderDao.findOrderById_finish(sd_order_id);
            Date nowDate = new Date();
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                this.calculateTime(order, nowDate);
                order.setTm_order_endtime(nowDate);
            } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
                this.calculateTime(order, nowDate);
                order.setTm_order_endtime(nowDate);
            } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
                this.calculateTime(order, nowDate);
                order.setTm_order_endtime(nowDate);
            }
            dataMap.put("order", order);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYID_USER, PromptProperties.getProperty("order.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findOrderByParam_user(Identifier identifier, Tb_order order, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            String sr_order_time_start = "";
            String sr_order_time_end = "";
            Tb_order o_pizhu = this.orderDao.findPizhuOrderByUserId(order.getSw_user_id());
            if (o_pizhu != null) {
                sr_order_time_start = o_pizhu.getSr_create_time();
                sr_order_time_end = XcbDateUtil.getEndDay((String)XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            }
            order.setSr_order_time_start(sr_order_time_start);
            order.setSr_order_time_end(sr_order_time_end);
            List<Tb_order> orders = this.orderDao.findOrderByParam_user(order, page);
            int totalCount = this.orderDao.findCountByParam_user(order);
            if (orders != null && orders.size() > 0) {
                Date nowDate = new Date();
                for (Tb_order o : orders) {
                    String sr_remarks;
                    Tb_device_box box = this.deviceBoxDao.findDeviceBoxById_user(o.getSw_box_id());
                    o.setDeviceBox(box);
                    if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(o.getSr_charging_type())) {
                        sr_remarks = PromptProperties.getProperty("order.remarks.asjf", o.getDc_advance_price(), o.getDc_hour_price(), o.getDc_max_xf(), o.getSr_maxservice_time());
                        o.setSr_remarks(sr_remarks);
                        this.calculateTime(o, nowDate);
                        continue;
                    }
                    if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(o.getSr_charging_type())) {
                        sr_remarks = PromptProperties.getProperty("order.remarks.acjf", o.getDc_once_price(), o.getSr_maxservice_time());
                        o.setSr_remarks(sr_remarks);
                        this.calculateTime(o, nowDate);
                        o.setTm_order_endtime(nowDate);
                        continue;
                    }
                    if (!XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(o.getSr_charging_type())) continue;
                    sr_remarks = PromptProperties.getProperty("order.remarks.mf", o.getSr_maxservice_time());
                    o.setSr_remarks(sr_remarks);
                    this.calculateTime(o, nowDate);
                    o.setTm_order_endtime(nowDate);
                }
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("orders", orders);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYPARAM_USER, PromptProperties.getProperty("order.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public void calculateTime(Tb_order order, Date nowDate) {
        StringBuffer sb = new StringBuffer();
        StringBuffer total_sb = new StringBuffer();
        Date tm_order_starttime = order.getTm_order_starttime();
        Date tm_order_endtime = order.getTm_order_endtime();
        if (tm_order_endtime == null) {
            tm_order_endtime = new Date();
        }
        if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
            BigDecimal dc_once_price = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_once_price());
            BigDecimal dc_actual_income = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_actual_income());
            Integer si_fee_time = XcbStringUtils.getObjtoint((Object)order.getSi_fee_time());
            Integer si_time_slot = XcbStringUtils.getObjtoint((Object)order.getSi_time_slot());
            BigDecimal dc_hour_price = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_hour_price());
            BigDecimal dc_max_xf = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_max_xf());
            Integer si_max_hour = XcbStringUtils.getObjtoint((Object)order.getSi_max_hour());
            if (XcbConstantValue.ORDER_GO.equals(order.getSr_order_status())) {
                long between = nowDate.getTime() - tm_order_starttime.getTime();
                long day = between / 86400000L;
                long hour = between / 3600000L - day * 24L;
                long min = between / 60000L - day * 24L * 60L - hour * 60L;
                long s = between / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                long totaltime = between / 3600000L;
                long fee_time = si_fee_time * 60 * 1000;
                long time_slot = si_time_slot * 60 * 1000;
                BigDecimal dc_order_money = BigDecimal.ZERO;
                if (between > fee_time) {
                    int cnt = (int)(between / time_slot);
                    int cnt2 = (int)(between % time_slot);
                    int over_min = cnt2 / 1000 / 60;
                    if (cnt > 0 && over_min > 0) {
                        ++cnt;
                    } else if (cnt == 0) {
                        if (si_fee_time > 0) {
                            if (day == 0L && hour == 0L && min > (long)si_fee_time.intValue()) {
                                ++cnt;
                            }
                        } else {
                            ++cnt;
                        }
                    }
                    BigDecimal dc_arrears = BigDecimal.ZERO;
                    BigDecimal dc_return = BigDecimal.ZERO;
                    BigDecimal pay_money = BigDecimalUtil.mul((BigDecimal)dc_hour_price, (BigDecimal)new BigDecimal(cnt));
                    if (pay_money.compareTo(dc_actual_income) >= 0) {
                        dc_order_money = dc_actual_income;
                        dc_arrears = BigDecimalUtil.sub((BigDecimal)pay_money, (BigDecimal)dc_actual_income);
                        int pay_cnt = BigDecimalUtil.div((BigDecimal)dc_actual_income, (BigDecimal)dc_hour_price).intValue();
                        int pay_time = pay_cnt * si_time_slot * 60 * 1000;
                        if (between < (long)pay_time) {
                            order.setSr_is_overtime("N");
                            day = between / 86400000L;
                            hour = between / 3600000L - day * 24L;
                            min = between / 60000L - day * 24L * 60L - hour * 60L;
                            s = between / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                            sb.append("\u5df2\u4f7f\u7528");
                            if (day > 0L) {
                                sb.append(day).append("\u5929");
                            }
                            if (hour > 0L) {
                                sb.append(hour).append("\u5c0f\u65f6");
                            }
                            if (min > 0L) {
                                sb.append(min).append("\u5206\u949f");
                            }
                            if (day == 0L && hour == 0L && min == 0L && s > 0L && s < 60L) {
                                sb.append(1).append("\u5206\u949f");
                            }
                        } else {
                            long diff = between - (long)(pay_cnt * si_time_slot * 60 * 1000);
                            day = diff / 86400000L;
                            hour = diff / 3600000L - day * 24L;
                            min = diff / 60000L - day * 24L * 60L - hour * 60L;
                            s = diff / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                            if (day == 0L && hour == 0L && min == 0L) {
                                order.setSr_is_overtime("N");
                                day = between / 86400000L;
                                hour = between / 3600000L - day * 24L;
                                min = between / 60000L - day * 24L * 60L - hour * 60L;
                                s = between / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                                sb.append("\u5df2\u4f7f\u7528");
                                if (day > 0L) {
                                    sb.append(day).append("\u5929");
                                }
                                if (hour > 0L) {
                                    sb.append(hour).append("\u5c0f\u65f6");
                                }
                                if (min > 0L) {
                                    sb.append(min).append("\u5206\u949f");
                                }
                            } else {
                                order.setSr_is_overtime("Y");
                                sb.append("\u5df2\u8d85\u65f6");
                                if (day > 0L) {
                                    sb.append(day).append("\u5929");
                                }
                                if (hour > 0L) {
                                    sb.append(hour).append("\u5c0f\u65f6");
                                }
                                if (min > 0L) {
                                    sb.append(min).append("\u5206\u949f");
                                }
                            }
                        }
                    } else {
                        dc_order_money = pay_money;
                        dc_return = BigDecimalUtil.sub((BigDecimal)dc_actual_income, (BigDecimal)pay_money);
                        order.setSr_is_overtime("N");
                        sb.append("\u5df2\u4f7f\u7528");
                        if (day > 0L) {
                            sb.append(day).append("\u5929");
                        }
                        if (hour > 0L) {
                            sb.append(hour).append("\u5c0f\u65f6");
                        }
                        if (min > 0L) {
                            sb.append(min).append("\u5206\u949f");
                        }
                        if (day == 0L && hour == 0L && min == 0L && s > 0L && s < 60L) {
                            sb.append(1).append("\u5206\u949f");
                        }
                    }
                    order.setDc_arrears(dc_arrears);
                    order.setDc_return(dc_return);
                    order.setSr_is_fee(false);
                    day = between / 86400000L;
                    hour = between / 3600000L - day * 24L;
                    min = between / 60000L - day * 24L * 60L - hour * 60L;
                    s = between / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                    if (day > 0L) {
                        total_sb.append(day).append("\u5929");
                    }
                    if (hour > 0L) {
                        total_sb.append(hour).append("\u5c0f\u65f6");
                    }
                    if (min > 0L) {
                        total_sb.append(min).append("\u5206\u949f");
                    }
                    if (day == 0L && hour == 0L && min == 0L && s > 0L && s < 60L) {
                        total_sb.append(1).append("\u5206\u949f");
                    }
                    order.setSr_total_user_time(total_sb.toString());
                } else {
                    order.setSr_is_fee(true);
                    day = between / 86400000L;
                    hour = between / 3600000L - day * 24L;
                    min = between / 60000L - day * 24L * 60L - hour * 60L;
                    s = between / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                    if (day > 0L) {
                        total_sb.append(day).append("\u5929");
                    }
                    if (hour > 0L) {
                        total_sb.append(hour).append("\u5c0f\u65f6");
                    }
                    if (min > 0L) {
                        total_sb.append(min).append("\u5206\u949f");
                    }
                    if (day == 0L && hour == 0L && min == 0L && s > 0L && s < 60L) {
                        total_sb.append(1).append("\u5206\u949f");
                    }
                    order.setSr_total_user_time(total_sb.toString());
                    sb.append("\u5df2\u4f7f\u7528");
                    if (day > 0L) {
                        sb.append(day).append("\u5929");
                    }
                    if (hour > 0L) {
                        sb.append(hour).append("\u5c0f\u65f6");
                    }
                    if (min > 0L) {
                        sb.append(min).append("\u5206\u949f");
                    }
                    if (day == 0L && hour == 0L && min == 0L && s > 0L && s < 60L) {
                        sb.append(1).append("\u5206\u949f");
                    }
                    order.setSr_is_overtime("N");
                }
                order.setSr_temp_user_time(sb.toString());
                order.setDc_order_money(dc_order_money);
            } else {
                long between = tm_order_endtime.getTime() - tm_order_starttime.getTime();
                long day = between / 86400000L;
                long hour = between / 3600000L - day * 24L;
                long min = between / 60000L - day * 24L * 60L - hour * 60L;
                long s = between / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                sb.append("\u5171\u4f7f\u7528");
                if (day > 0L) {
                    sb.append(day).append("\u5929");
                    total_sb.append(day).append("\u5929");
                }
                if (hour > 0L) {
                    sb.append(hour).append("\u5c0f\u65f6");
                    total_sb.append(hour).append("\u5c0f\u65f6");
                }
                if (min > 0L) {
                    sb.append(min).append("\u5206\u949f");
                    total_sb.append(min).append("\u5206\u949f");
                }
                if (day == 0L && hour == 0L && min == 0L && s > 0L && s < 60L) {
                    sb.append(1).append("\u5206\u949f");
                    total_sb.append(1).append("\u5206\u949f");
                }
                order.setSr_is_overtime("N");
                order.setSr_temp_user_time(sb.toString());
                order.setSr_total_user_time(total_sb.toString());
            }
        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
            if (XcbConstantValue.ORDER_GO.equals(order.getSr_order_status())) {
                long between = nowDate.getTime() - tm_order_starttime.getTime();
                long day = between / 86400000L;
                long hour = between / 3600000L - day * 24L;
                long min = between / 60000L - day * 24L * 60L - hour * 60L;
                long s = between / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                sb.append("\u5df2\u4f7f\u7528");
                if (day > 0L) {
                    sb.append(day).append("\u5929");
                    total_sb.append(day).append("\u5929");
                }
                if (hour > 0L) {
                    sb.append(hour).append("\u5c0f\u65f6");
                    total_sb.append(hour).append("\u5c0f\u65f6");
                }
                if (min > 0L) {
                    sb.append(min).append("\u5206\u949f");
                    total_sb.append(min).append("\u5206\u949f");
                }
                if (day == 0L && hour == 0L && min == 0L && s > 0L && s < 60L) {
                    sb.append(1).append("\u5206\u949f");
                    total_sb.append(1).append("\u5206\u949f");
                }
                order.setSr_is_overtime("N");
                order.setSr_temp_user_time(sb.toString());
                order.setSr_total_user_time(total_sb.toString());
            } else {
                long between = tm_order_endtime.getTime() - tm_order_starttime.getTime();
                long day = between / 86400000L;
                long hour = between / 3600000L - day * 24L;
                long min = between / 60000L - day * 24L * 60L - hour * 60L;
                long s = between / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                sb.append("\u5171\u4f7f\u7528");
                if (day > 0L) {
                    sb.append(day).append("\u5929");
                    total_sb.append(day).append("\u5929");
                }
                if (hour > 0L) {
                    sb.append(hour).append("\u5c0f\u65f6");
                    total_sb.append(hour).append("\u5c0f\u65f6");
                }
                if (min > 0L) {
                    sb.append(min).append("\u5206\u949f");
                    total_sb.append(min).append("\u5206\u949f");
                }
                if (day == 0L && hour == 0L && min == 0L && s > 0L && s < 60L) {
                    sb.append(1).append("\u5206\u949f");
                    total_sb.append(1).append("\u5206\u949f");
                }
                order.setSr_is_overtime("N");
                order.setSr_temp_user_time(sb.toString());
                order.setSr_total_user_time(total_sb.toString());
            }
        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
            if (XcbConstantValue.ORDER_GO.equals(order.getSr_order_status())) {
                long between = nowDate.getTime() - tm_order_starttime.getTime();
                long day = between / 86400000L;
                long hour = between / 3600000L - day * 24L;
                long min = between / 60000L - day * 24L * 60L - hour * 60L;
                long s = between / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                sb.append("\u5df2\u4f7f\u7528");
                if (day > 0L) {
                    sb.append(day).append("\u5929");
                    total_sb.append(day).append("\u5929");
                }
                if (hour > 0L) {
                    sb.append(hour).append("\u5c0f\u65f6");
                    total_sb.append(hour).append("\u5c0f\u65f6");
                }
                if (min > 0L) {
                    sb.append(min).append("\u5206\u949f");
                    total_sb.append(min).append("\u5206\u949f");
                }
                if (day == 0L && hour == 0L && min == 0L && s > 0L && s < 60L) {
                    sb.append(1).append("\u5206\u949f");
                    total_sb.append(1).append("\u5206\u949f");
                }
                order.setSr_is_overtime("N");
                order.setSr_temp_user_time(sb.toString());
                order.setSr_total_user_time(total_sb.toString());
            } else {
                long between = tm_order_endtime.getTime() - tm_order_starttime.getTime();
                long day = between / 86400000L;
                long hour = between / 3600000L - day * 24L;
                long min = between / 60000L - day * 24L * 60L - hour * 60L;
                long s = between / 1000L - day * 24L * 60L * 60L - hour * 60L * 60L - min * 60L;
                sb.append("\u5171\u4f7f\u7528");
                if (day > 0L) {
                    sb.append(day).append("\u5929");
                    total_sb.append(day).append("\u5929");
                }
                if (hour > 0L) {
                    sb.append(hour).append("\u5c0f\u65f6");
                    total_sb.append(hour).append("\u5c0f\u65f6");
                }
                if (min > 0L) {
                    sb.append(min).append("\u5206\u949f");
                    total_sb.append(min).append("\u5206\u949f");
                }
                if (day == 0L && hour == 0L && min == 0L && s > 0L && s < 60L) {
                    sb.append(1).append("\u5206\u949f");
                    total_sb.append(1).append("\u5206\u949f");
                }
                order.setSr_is_overtime("N");
                order.setSr_temp_user_time(sb.toString());
                order.setSr_total_user_time(total_sb.toString());
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Transactional
    Map<String, Object> zhPayEvent(Identifier identifier, Tb_order order, Integer sd_id) {
        Integer sw_user_id;
        String table;
        String msg;
        HashMap<String, String> dataMap;
        HashMap<String, Object> ret;
        boolean isSuccess;
        block23: {
            int result = 0;
            isSuccess = false;
            ret = new HashMap<String, Object>();
            dataMap = new HashMap<String, String>();
            msg = "";
            table = "tb_order";
            String sd_order_id = CommonFunction.getVoucherNum((String)CommonFunction.dd_id);
            String sd_ordercash_id = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
            sw_user_id = order.getSw_user_id();
            Integer sw_box_id = order.getSw_box_id();
            String sr_cash_type = XcbConstantValue.ORDER_CASH_TYPE_PTYE;
            BigDecimal dc_actual_income = BigDecimal.ZERO;
            BigDecimal dc_order_money = BigDecimal.ZERO;
            BigDecimal dc_deposit_money = BigDecimal.ZERO;
            Tb_user user = this.userDao.findUserById(sw_user_id);
            try {
                Tb_wx_pay_info info = this.wxPayInfoDao.findNewDefaultPayIn(user.getSr_way());
                Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(sw_box_id);
                if (XcbConstantValue.DEVICE_BOX_STATUS_KY.equals(deviceBox.getSr_box_status())) {
                    Tb_device_package devicePackage = this.devicePackageDao.findDevicePackageById(sd_id);
                    if (devicePackage != null) {
                        if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
                            dc_order_money = devicePackage.getDc_once_price();
                            dc_deposit_money = devicePackage.getDc_advance_price();
                        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                            dc_order_money = devicePackage.getDc_advance_price();
                        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
                            dc_deposit_money = devicePackage.getDc_advance_price();
                        }
                        dc_actual_income = BigDecimalUtil.add((BigDecimal)dc_order_money, (BigDecimal)dc_deposit_money);
                        Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(sw_user_id);
                        BigDecimal dc_account_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money());
                        BigDecimal dc_present_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_present_money());
                        BigDecimal totalMoney = BigDecimalUtil.add((BigDecimal)dc_account_money, (BigDecimal)dc_present_money);
                        if (totalMoney.compareTo(dc_actual_income) < 0) {
                            msg = PromptProperties.getProperty("order.pay.useraccount.pay.fail");
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                            ret.put(XcbConstantValue.MSG, msg);
                            this.log.error(msg);
                            return ret;
                        }
                        StringBuffer sb_attach = new StringBuffer();
                        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSw_user_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_agent_id())).append(",").append(XcbStringUtils.getObjtoString((Object)devicePackage.getSd_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_device_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_box_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_order_way())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_charging_type())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_cj_function())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_iphone_num())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_password())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_PTYE)).append(",").append(XcbStringUtils.getObjtoString((Object)dc_order_money)).append(",").append(XcbStringUtils.getObjtoString((Object)dc_deposit_money)).append(",").append(XcbStringUtils.getObjtoString((Object)info.getSub_mchid()));
                        String attach = sb_attach.toString();
                        result = this.createOrder(sd_order_id, attach, devicePackage);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            result = this.createOrderCash(sd_ordercash_id, sw_user_id, sd_order_id, "", "", sr_cash_type, dc_order_money, dc_actual_income);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                result = this.updateUserAccount(identifier, order, dc_actual_income);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    dataMap.put("sw_order_id", sd_order_id);
                                    Map<String, Object> resMap = this.deviceCloudService.openLock(sw_user_id, deviceBox, sd_order_id, XcbConstantValue.OPEN_DOOR_TYPE_CJDD, "");
                                    result = XcbStringUtils.getObjtoint((Object)resMap.get(XcbConstantValue.STATUS));
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        isSuccess = true;
                                        Tb_order n_order = this.orderDao.findOrderById_user(sd_order_id);
                                        if (user == null) break block23;
                                        if ("Y".equals(user.getSr_is_subscribe())) {
                                            this.sendWXMessage(n_order, n_order.getDc_actual_income(), "CREATE");
                                            break block23;
                                        }
                                        if ("Y".equals(user.getSr_subscribe_create())) {
                                            this.sendWXAppMessage(n_order, n_order.getDc_actual_income(), "CREATE");
                                        }
                                        break block23;
                                    }
                                    table = "openlock";
                                    String message = XcbStringUtils.getObjtoString(ret.get(XcbConstantValue.MSG));
                                    msg = PromptProperties.getProperty("order.pay.openlock.fail", sd_order_id, message);
                                    this.log.error(msg);
                                    break block23;
                                }
                                table = "tb_user_account";
                                msg = PromptProperties.getProperty("order.pay.updateuser.fail", XcbConstantValue.ORDER_ZHPAYEVENT, sd_order_id);
                                this.log.error(msg);
                                break block23;
                            }
                            table = "tb_ordercash_stream";
                            msg = PromptProperties.getProperty("order.pay.create.ordercash.fail", sd_order_id);
                            this.log.error(msg);
                            break block23;
                        }
                        table = "tb_order";
                        msg = PromptProperties.getProperty("order.pay.create.fail", sd_order_id, "\u521b\u5efa\u8ba2\u5355\u5f02\u5e38");
                        this.log.error(msg);
                        break block23;
                    }
                    msg = PromptProperties.getProperty("order.pay.device.package.find.fail", XcbConstantValue.ORDER_ZHPAYEVENT, sd_id);
                    this.log.error(msg);
                    break block23;
                }
                if (XcbConstantValue.DEVICE_BOX_STATUS_JQ.equals(deviceBox.getSr_box_status())) {
                    msg = PromptProperties.getProperty("devicebox.JQ");
                } else if (XcbConstantValue.DEVICE_BOX_STATUS_JY.equals(deviceBox.getSr_box_status())) {
                    msg = PromptProperties.getProperty("devicebox.JY");
                } else if (XcbConstantValue.DEVICE_BOX_STATUS_ZY.equals(deviceBox.getSr_box_status())) {
                    msg = PromptProperties.getProperty("devicebox.ZY");
                }
                table = "tb_device_box";
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                ret.put(XcbConstantValue.MSG, msg);
                this.log.error(msg);
                return ret;
            }
            catch (Exception e) {
                this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_ZHPAYEVENT + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
                msg = PromptProperties.getProperty("order.pay.fail", XcbConstantValue.ORDER_ZHPAYEVENT, sd_order_id);
                this.log.error(msg);
            }
        }
        if (isSuccess) {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.DATA, dataMap);
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, msg);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_USER, XcbConstantValue.ORDER_ZHPAYEVENT, sw_user_id, XcbConstantValue.OPERATION_FAIL, "CREATE", msg, "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)sw_user_id));
            operationLogs.setSr_operate_table(table);
            this.operationLogServiceImpl.createOperaLog(operationLogs);
        }
        this.initResultMap(ret);
        return ret;
    }

    @Transactional
    Map<String, Object> orderPayNotify(Identifier identifier, Map<String, Object> param) {
        int result = 0;
        boolean isSuccess = false;
        Map<String, Object> ret = new HashMap<String, Object>();
        String msg = "";
        String sr_reason = "";
        String sd_ordercash_id = XcbStringUtils.getObjtoString((Object)param.get("out_trade_no"));
        BigDecimal dc_actual_income = XcbStringUtils.getObjToBigDecimal((Object)param.get("dc_actual_income"));
        String transaction_id = XcbStringUtils.getObjtoString((Object)param.get("transaction_id"));
        String channelTransNo = XcbStringUtils.getObjtoString((Object)param.get("channelTransNo"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)param.get("attach"));
        String[] attachArr = sr_attach.split(",");
        Integer sw_user_id = XcbStringUtils.getObjtoint((Object)attachArr[0]);
        Integer sd_id = XcbStringUtils.getObjtoint((Object)attachArr[2]);
        Integer sw_box_id = XcbStringUtils.getObjtoint((Object)attachArr[4]);
        String sd_order_id = XcbStringUtils.getObjtoString((Object)attachArr[10]);
        String sr_cash_type = XcbStringUtils.getObjtoString((Object)attachArr[11]);
        BigDecimal dc_order_money = XcbStringUtils.getObjToBigDecimal((Object)attachArr[12]);
        BigDecimal dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)attachArr[13]);
        String table = "tb_order";
        try {
            Tb_order o_order = this.orderDao.findOrderById_user(sd_order_id);
            if (o_order != null) {
                msg = PromptProperties.getProperty("order.paynotify.isExist", XcbConstantValue.ORDER_PAYNOTIFY, sd_order_id);
                this.log.error(msg);
            } else {
                Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(sw_box_id);
                if (XcbConstantValue.DEVICE_BOX_STATUS_KY.equals(deviceBox.getSr_box_status())) {
                    Tb_device_package devicePackage = this.devicePackageDao.findDevicePackageById(sd_id);
                    if (devicePackage != null) {
                        result = this.createOrder(sd_order_id, sr_attach, devicePackage);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            result = this.createOrderCash(sd_ordercash_id, sw_user_id, sd_order_id, transaction_id, channelTransNo, sr_cash_type, dc_order_money, dc_actual_income);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                ret = this.deviceCloudService.openLock(sw_user_id, deviceBox, sd_order_id, XcbConstantValue.OPEN_DOOR_TYPE_CJDD, "");
                                result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    isSuccess = true;
                                    Tb_order order = this.orderDao.findOrderById_user(sd_order_id);
                                    Tb_user user = this.userDao.findUserById(order.getSw_user_id());
                                    if (user != null) {
                                        if ("Y".equals(user.getSr_is_subscribe())) {
                                            this.sendWXMessage(order, order.getDc_actual_income(), "CREATE");
                                        } else if ("Y".equals(user.getSr_subscribe_create())) {
                                            this.sendWXAppMessage(order, order.getDc_actual_income(), "CREATE");
                                        }
                                    }
                                } else {
                                    table = "openlock";
                                    sr_reason = "\u5f00\u95e8\u5931\u8d25,\u8bbe\u5907\u79bb\u7ebf";
                                    msg = XcbStringUtils.getObjtoString((Object)ret.get(XcbConstantValue.MSG));
                                }
                            } else {
                                table = "tb_ordercash_stream";
                                msg = PromptProperties.getProperty("order.paynotify.create.ordercash.fail", sd_order_id);
                            }
                        } else {
                            table = "tb_order";
                            msg = PromptProperties.getProperty("order.paynotify.create.fail", sd_order_id, "\u521b\u5efa\u8ba2\u5355\u5f02\u5e38");
                        }
                    } else {
                        table = "tb_device_package";
                        msg = PromptProperties.getProperty("order.paynotify.device.package.find.fail", XcbConstantValue.ORDER_PAYNOTIFY, sd_id);
                    }
                } else {
                    sr_reason = "\u5f00\u95e8\u5931\u8d25,\u67dc\u5b50\u5df2\u88ab\u4f7f\u7528";
                    table = "tb_device_box";
                    msg = PromptProperties.getProperty("order.paynotify.device.box.open.fail", XcbConstantValue.ORDER_PAYNOTIFY, sd_order_id, sw_box_id, deviceBox.getSr_box_status_desc());
                }
            }
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_PAYNOTIFY + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            msg = PromptProperties.getProperty("order.paynotify.fail", XcbConstantValue.ORDER_PAYNOTIFY, sd_order_id);
        }
        if (isSuccess) {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, msg);
            ret.put("sr_reason", sr_reason);
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, XcbConstantValue.ORDER_PAYNOTIFY, sw_user_id, XcbConstantValue.OPERATION_FAIL, "CREATE", msg, "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)sd_order_id));
            operationLogs.setSr_operate_table(table);
            this.operationLogServiceImpl.createOperaLog(operationLogs);
        }
        this.initResultMap(ret);
        return ret;
    }

    private void sendWXMessage(Tb_order order, BigDecimal dc_money, String sr_type) {
        BigDecimal money = BigDecimal.ZERO;
        String type = "";
        if ("CREATE".equals(sr_type)) {
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                money = BigDecimalUtil.add((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)order.getDc_actual_income()), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money()));
                type = WxMessage.model_asjf;
            } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
                money = BigDecimalUtil.add((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)order.getDc_actual_income()), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money()));
                type = WxMessage.model_asjf;
            } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
                money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                type = WxMessage.model_asjf;
            }
            this.wxMessageService.sendMessage(order.getSw_user_id(), order, XcbStringUtils.getObjtoString((Object)money), type, null);
        } else if ("FINISH".equals(sr_type)) {
            type = WxMessage.model_finish;
            this.wxMessageService.sendMessage(order.getSw_user_id(), order, XcbStringUtils.getObjtoString((Object)dc_money), type, null);
        } else if ("DEPOSIT".equals(sr_type)) {
            type = WxMessage.model_return;
            this.wxMessageService.sendMessage(order.getSw_user_id(), order, XcbStringUtils.getObjtoString((Object)dc_money), type, null);
        } else if ("REFUND".equals(sr_type)) {
            type = WxMessage.model_refund;
            this.wxMessageService.sendMessage(order.getSw_user_id(), order, XcbStringUtils.getObjtoString((Object)dc_money), type, null);
        }
    }

    private void sendWXAppMessage(Tb_order order, BigDecimal dc_money, String sr_type) {
        BigDecimal money = BigDecimal.ZERO;
        String type = "";
        if ("CREATE".equals(sr_type)) {
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                money = BigDecimalUtil.add((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)order.getDc_actual_income()), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money()));
                type = WxAppMessage.model_create;
            } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
                money = BigDecimalUtil.add((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)order.getDc_actual_income()), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money()));
                type = WxAppMessage.model_create;
            } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
                money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                type = WxAppMessage.model_create;
            }
            this.wxMessageService.sendAppMessage(order.getSw_user_id(), order, XcbStringUtils.getObjtoString((Object)money), type);
        } else if ("FINISH".equals(sr_type)) {
            type = WxAppMessage.model_finish;
            this.wxMessageService.sendAppMessage(order.getSw_user_id(), order, XcbStringUtils.getObjtoString((Object)dc_money), type);
        } else if ("DEPOSIT".equals(sr_type)) {
            type = WxAppMessage.model_return;
            this.wxMessageService.sendAppMessage(order.getSw_user_id(), order, XcbStringUtils.getObjtoString((Object)dc_money), type);
        } else if ("REFUND".equals(sr_type)) {
            type = WxAppMessage.model_refund;
            this.wxMessageService.sendAppMessage(order.getSw_user_id(), order, XcbStringUtils.getObjtoString((Object)dc_money), type);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Transactional
    Map<String, Object> orderTemporaryPayNotify(Identifier identifier, Map<String, Object> param) {
        int result = 0;
        boolean isSuccess = false;
        Map<String, Object> ret = new HashMap<String, Object>();
        String msg = "";
        String sd_ordercash_id = XcbStringUtils.getObjtoString((Object)param.get("out_trade_no"));
        BigDecimal totalMoney = XcbStringUtils.getObjToBigDecimal((Object)param.get("dc_actual_income"));
        String transaction_id = XcbStringUtils.getObjtoString((Object)param.get("transaction_id"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)param.get("attach"));
        String[] attachArr = sr_attach.split(",");
        String sd_order_id = XcbStringUtils.getObjtoString((Object)attachArr[0]);
        String sr_cash_type = XcbStringUtils.getObjtoString((Object)attachArr[1]);
        Tb_order o_order = new Tb_order();
        String table = "tb_order";
        try {
            Class<OrderServiceImpl> clazz = OrderServiceImpl.class;
            synchronized (OrderServiceImpl.class) {
                o_order = this.orderDao.findOrderById_user(sd_order_id);
                if (o_order != null) {
                    if (XcbConstantValue.ORDER_GO.equals(o_order.getSr_order_status()) || XcbConstantValue.ORDER_BFTK.equals(o_order.getSr_order_status())) {
                        BigDecimal dc_actual_income = BigDecimalUtil.add((BigDecimal)totalMoney, (BigDecimal)o_order.getDc_actual_income());
                        Tb_order o_new = new Tb_order();
                        o_new.setSd_order_id(o_order.getSd_order_id());
                        o_new.setDc_actual_income(dc_actual_income);
                        o_new.setTm_modify_time(new Date());
                        o_new.setSi_modify_person(o_order.getSw_user_id());
                        result = this.orderDao.updateOrder(o_new);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            result = this.createOrderCash(sd_ordercash_id, o_order.getSw_user_id(), sd_order_id, transaction_id, "", sr_cash_type, totalMoney, totalMoney);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(o_order.getSw_box_id());
                                ret = this.deviceCloudService.openLock(o_order.getSw_user_id(), deviceBox, sd_order_id, XcbConstantValue.OPEN_DOOR_TYPE_DDXF, "");
                                result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    isSuccess = true;
                                } else {
                                    table = "openlock";
                                    String message = XcbStringUtils.getObjtoString((Object)ret.get(XcbConstantValue.MSG));
                                    msg = PromptProperties.getProperty("order.paynotify.openlock.fail", sd_order_id, message);
                                }
                            } else {
                                table = "tb_ordercash_stream";
                                msg = PromptProperties.getProperty("order.paynotify.create.ordercash.fail", XcbConstantValue.ORDER_TEMPORARY_PAYNOTIFY, o_order.getSd_order_id());
                            }
                        } else {
                            table = "tb_order";
                            msg = PromptProperties.getProperty("order.paynotify.update.fail", XcbConstantValue.ORDER_TEMPORARY_PAYNOTIFY, o_order.getSd_order_id());
                        }
                    } else {
                        isSuccess = true;
                    }
                } else {
                    msg = PromptProperties.getProperty("order.paynotify.isExist", XcbConstantValue.ORDER_TEMPORARY_PAYNOTIFY, sd_order_id);
                }
                // ** MonitorExit[var16_16] (shouldn't be in output)
            }
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_TEMPORARY_PAYNOTIFY + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            msg = PromptProperties.getProperty("order.paynotify.fail", XcbConstantValue.ORDER_TEMPORARY_PAYNOTIFY, sd_order_id);
        }
        {
            if (isSuccess) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                this.log.error("\u5f02\u5e38\u4fe1\u606f:" + msg);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, msg);
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, XcbConstantValue.ORDER_TEMPORARY_PAYNOTIFY, o_order.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "CREATE", msg, "", "");
                operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                operationLogs.setSr_operate_primarykey(sd_order_id);
                operationLogs.setSr_operate_table(table);
                this.operationLogServiceImpl.createOperaLog(operationLogs);
            }
            this.initResultMap(ret);
            return ret;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Transactional
    Map<String, Object> orderFinishPayNotify(Identifier identifier, Map<String, Object> param) {
        int result = 0;
        boolean isSuccess = false;
        Map<String, Object> ret = new HashMap<String, Object>();
        String msg = "";
        String sd_ordercash_id = XcbStringUtils.getObjtoString((Object)param.get("out_trade_no"));
        BigDecimal totalMoney = XcbStringUtils.getObjToBigDecimal((Object)param.get("dc_actual_income"));
        String transaction_id = XcbStringUtils.getObjtoString((Object)param.get("transaction_id"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)param.get("attach"));
        String[] attachArr = sr_attach.split(",");
        String sd_order_id = XcbStringUtils.getObjtoString((Object)attachArr[0]);
        String sr_cash_type = XcbStringUtils.getObjtoString((Object)attachArr[1]);
        Tb_order o_order = new Tb_order();
        String table = "tb_order";
        try {
            Class<OrderServiceImpl> clazz = OrderServiceImpl.class;
            synchronized (OrderServiceImpl.class) {
                o_order = this.orderDao.findOrderById_user(sd_order_id);
                if (o_order != null) {
                    if (XcbConstantValue.ORDER_GO.equals(o_order.getSr_order_status()) || XcbConstantValue.ORDER_BFTK.equals(o_order.getSr_order_status())) {
                        BigDecimal dc_actual_income = BigDecimalUtil.add((BigDecimal)totalMoney, (BigDecimal)o_order.getDc_actual_income());
                        Tb_order o_new = new Tb_order();
                        o_new.setSd_order_id(o_order.getSd_order_id());
                        o_new.setSr_order_status(XcbConstantValue.ORDER_YWC);
                        o_new.setTm_order_endtime(new Date());
                        o_new.setDc_order_money(dc_actual_income);
                        o_new.setDc_actual_income(dc_actual_income);
                        o_new.setTm_modify_time(new Date());
                        o_new.setSi_modify_person(o_order.getSw_user_id());
                        result = this.orderDao.updateOrder(o_new);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            result = this.createOrderCash(sd_ordercash_id, o_order.getSw_user_id(), sd_order_id, transaction_id, "", sr_cash_type, totalMoney, totalMoney);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(o_order.getSr_charging_type()) || XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(o_order.getSr_charging_type())) {
                                    Tb_agent agent = this.agentDao.findAgentById(o_order.getSw_agent_id());
                                    Map<String, Object> resMap = this.updateAgentAccount(agent, dc_actual_income);
                                    result = XcbStringUtils.getObjtoint((Object)resMap.get(XcbConstantValue.STATUS));
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        String flowItem = XcbStringUtils.getObjtoString((Object)resMap.get("flowItem"));
                                        String payType = XcbStringUtils.getObjtoString((Object)resMap.get("payType"));
                                        String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                                        result = this.createCashStream(o_order.getSw_user_id(), o_order.getSw_agent_id(), sd_order_id, sd_cash_id, flowItem, payType, dc_actual_income, "", XcbConstantValue.CASH_STREAM_WFH);
                                    } else {
                                        table = "tb_agent";
                                        msg = PromptProperties.getProperty("order.paynotify.updateagent.fail", XcbConstantValue.ORDER_FINISH_PAYNOTIFY, sd_order_id);
                                    }
                                } else {
                                    result = XcbConstantValue.OPERA_INT_ONE;
                                }
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    BigDecimal dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)o_order.getDc_deposit_money());
                                    if (dc_deposit_money.compareTo(BigDecimal.ZERO) == 1) {
                                        Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(o_order.getSw_user_id());
                                        result = this.commonLogic.updateUser_account(identifier, dc_deposit_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                            result = this.createUserRecharge(o_order, dc_deposit_money, "Y");
                                        } else {
                                            table = "tb_user_account";
                                            msg = PromptProperties.getProperty("order.paynotify.updateuser.fail", XcbConstantValue.ORDER_FINISH_PAYNOTIFY, sd_order_id);
                                        }
                                    } else {
                                        result = XcbConstantValue.OPERA_INT_ONE;
                                    }
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(o_order.getSw_box_id());
                                        ret = this.deviceCloudService.openLock(o_order.getSw_user_id(), deviceBox, sd_order_id, XcbConstantValue.OPEN_DOOR_TYPE_DDJS, "");
                                        result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                            isSuccess = true;
                                        } else {
                                            table = "openlock";
                                            String message = XcbStringUtils.getObjtoString((Object)ret.get(XcbConstantValue.MSG));
                                            msg = PromptProperties.getProperty("order.paynotify.openlock.fail", sd_order_id, message);
                                        }
                                    } else {
                                        table = "tb_user_recharge";
                                        msg = PromptProperties.getProperty("order.paynotify.create.recharge.fail", XcbConstantValue.ORDER_FINISH_PAYNOTIFY, sd_order_id);
                                    }
                                } else {
                                    table = "tb_cash_stream";
                                    msg = PromptProperties.getProperty("order.paynotify.create.cashstream.fail", sd_order_id);
                                }
                            } else {
                                table = "tb_ordercash_stream";
                                msg = PromptProperties.getProperty("order.paynotify.create.ordercash.fail", XcbConstantValue.ORDER_FINISH_PAYNOTIFY, o_order.getSd_order_id());
                            }
                        } else {
                            table = "tb_order";
                            msg = PromptProperties.getProperty("order.paynotify.update.fail", XcbConstantValue.ORDER_FINISH_PAYNOTIFY, o_order.getSd_order_id());
                        }
                    } else {
                        isSuccess = true;
                    }
                } else {
                    msg = PromptProperties.getProperty("order.paynotify.isNotExist", XcbConstantValue.ORDER_FINISH_PAYNOTIFY, sd_order_id);
                }
                // ** MonitorExit[var16_16] (shouldn't be in output)
            }
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_FINISH_PAYNOTIFY + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            msg = PromptProperties.getProperty("order.paynotify.fail", XcbConstantValue.ORDER_FINISH_PAYNOTIFY, sd_order_id);
        }
        {
            if (isSuccess) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, msg);
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, XcbConstantValue.ORDER_FINISH_PAYNOTIFY, o_order.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "CREATE", msg, "", "");
                operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)o_order.getSd_order_id()));
                operationLogs.setSr_operate_table(table);
                this.operationLogServiceImpl.createOperaLog(operationLogs);
            }
            this.initResultMap(ret);
            return ret;
        }
    }

    private int createOrder(String sd_order_id, String sr_attach, Tb_device_package devicePackage) {
        int result = 0;
        try {
            Tb_order o;
            Tb_order adO;
            String[] attachArr = sr_attach.split(",");
            Integer sw_user_id = XcbStringUtils.getObjtoint((Object)attachArr[0]);
            Integer sw_agent_id = XcbStringUtils.getObjtoint((Object)attachArr[1]);
            String sw_device_id = XcbStringUtils.getObjtoString((Object)attachArr[3]);
            StringBuffer stringBuffer = new StringBuffer(sw_device_id);
            String rev_id = stringBuffer.reverse().toString();
            Integer sw_box_id = XcbStringUtils.getObjtoint((Object)attachArr[4]);
            String sr_order_way = XcbStringUtils.getObjtoString((Object)attachArr[5]);
            String sr_charging_type = XcbStringUtils.getObjtoString((Object)attachArr[6]);
            String sr_cj_function = XcbStringUtils.getObjtoString((Object)attachArr[7]);
            String sr_iphone_num = "";
            String sr_password = "";
            Tb_device device = this.deviceDao.findDeviceDetailById_agent(sw_device_id);
            Tb_netpoint netpoint = this.netPointDao.findNetPointById_agent(device.getSw_netpoint_id());
            Tb_device_box box = this.deviceBoxDao.findDeviceBoxById_user(sw_box_id);
            Tb_agent agent = this.agentDao.findAgentById_agent(sw_agent_id);
            if (XcbConstantValue.Y_STRING.equals(sr_cj_function)) {
                sr_iphone_num = XcbStringUtils.getObjtoString((Object)attachArr[8]);
                sr_password = XcbStringUtils.getObjtoString((Object)attachArr[9]);
                Tb_user user = this.userDao.findUserById(sw_user_id);
                if (!XcbStringUtils.isNullOrBlank((Object)sr_iphone_num) && XcbStringUtils.isNullOrBlank((Object)user.getSr_user_name())) {
                    user.setSr_user_name(sr_iphone_num);
                }
                user.setSr_check_appl(device.getSr_check_appl());
                user.setSr_is_scan(device.getSr_is_scan());
                user.setSr_mode(netpoint.getSr_mode());
                user.setSr_scan_cycle(netpoint.getSr_scan_cycle());
                this.userDao.updateUserForName(user);
            }
            BigDecimal dc_order_money = XcbStringUtils.getObjToBigDecimal((Object)attachArr[12]);
            BigDecimal dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)attachArr[13]);
            String sr_mchid = XcbStringUtils.getObjtoString((Object)attachArr[14]);
            Tb_order order = new Tb_order();
            order.setSr_is_show_repeat("Y");
            if ("Y".equals(device.getSr_is_steal())) {
                Integer si_max_order = XcbStringUtils.getObjtoint((Object)agent.getSi_max_order());
                Integer si_min_order = XcbStringUtils.getObjtoint((Object)agent.getSi_min_order());
                if (XcbConstantValue.DEVICE_STEAL_MODEL_A.equals(device.getSr_steal_model())) {
                    String sr_steal_time = XcbStringUtils.getObjtoString((Object)device.getSr_steal_time());
                    String si_steal_count = XcbStringUtils.getObjtoString((Object)device.getSi_steal_count());
                    if (!XcbStringUtils.isNullOrBlank((Object)sr_steal_time) && !XcbStringUtils.isNullOrBlank((Object)si_steal_count)) {
                        String nowDate_str = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss");
                        String preDate_str = XcbDateUtil.dealDate((Date)new Date(), (Integer)XcbStringUtils.getObjtoint((Object)sr_steal_time), (String)"\u5206\u949f");
                        Tb_order s_order = new Tb_order();
                        s_order.setSw_device_id(sw_device_id);
                        s_order.setSr_create_time_start(preDate_str);
                        s_order.setSr_create_time_end(nowDate_str);
                        System.out.println("\u8bbe\u5907ID:" + sw_device_id);
                        System.out.println("\u5f00\u59cb\u65f6\u95f4:" + preDate_str);
                        System.out.println("\u7ed3\u675f\u65f6\u95f4:" + nowDate_str);
                        List<Tb_order> oList = this.orderDao.findStealOrderByParam(s_order);
                        if (oList != null) {
                            this.log.info("\u67e5\u8be2\u51fa\u7684\u903b\u8f91\u5355\u6570:" + oList.size());
                            this.log.info("\u8bbe\u7f6e\u7684\u903b\u8f91\u5355\u6570:" + si_steal_count);
                            System.out.println("\u67e5\u8be2\u51fa\u7684\u903b\u8f91\u5355\u6570:" + oList.size());
                            System.out.println("\u8bbe\u7f6e\u7684\u903b\u8f91\u5355\u6570:" + si_steal_count);
                        }
                        if (oList != null && oList.size() >= XcbStringUtils.getObjtoint((Object)si_steal_count)) {
                            if (si_min_order == 0 && si_max_order == 0) {
                                order.setSr_is_steal("Y");
                            } else {
                                nowDate_str = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd");
                                Tb_order a_o = new Tb_order();
                                a_o.setSw_agent_id(sw_agent_id);
                                a_o.setSr_create_time(nowDate_str);
                                Integer count = this.orderDao.findCountStealByParam(a_o);
                                Integer todayCnt = this.orderDao.findCountByToday(a_o);
                                this.log.info("\u4eca\u65e5\u5df2\u9690\u85cf\u8ba2\u5355\u6570" + count);
                                System.out.println("\u4eca\u65e5\u5df2\u9690\u85cf\u8ba2\u5355\u6570:" + count);
                                if (todayCnt >= XcbStringUtils.getObjtoint((Object)si_min_order) && count <= XcbStringUtils.getObjtoint((Object)si_max_order)) {
                                    order.setSr_is_steal("Y");
                                } else {
                                    order.setSr_is_steal("N");
                                }
                            }
                        } else {
                            order.setSr_is_steal("N");
                        }
                    } else {
                        order.setSr_is_steal("N");
                    }
                } else if (XcbConstantValue.DEVICE_STEAL_MODEL_B.equals(device.getSr_steal_model())) {
                    String si_steal_count = XcbStringUtils.getObjtoString((Object)device.getSi_steal_count());
                    if (!XcbStringUtils.isNullOrBlank((Object)si_steal_count)) {
                        String nowDate_str = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss");
                        String preDate_str = XcbDateUtil.getTodayZero((Date)new Date());
                        Tb_order b_order = new Tb_order();
                        b_order.setSw_device_id(sw_device_id);
                        b_order.setSr_create_time_start(preDate_str);
                        b_order.setSr_create_time_end(nowDate_str);
                        String newStealDate = this.orderDao.findLastStealByDevice(b_order);
                        if (XcbStringUtils.isNullOrBlank((Object)newStealDate)) {
                            newStealDate = preDate_str;
                        }
                        Tb_order s_order = new Tb_order();
                        s_order.setSw_device_id(sw_device_id);
                        s_order.setSr_create_time_start(newStealDate);
                        s_order.setSr_create_time_end(nowDate_str);
                        System.out.println("\u8bbe\u5907ID:" + sw_device_id);
                        System.out.println("\u5f00\u59cb\u65f6\u95f4:" + preDate_str);
                        System.out.println("\u7ed3\u675f\u65f6\u95f4:" + nowDate_str);
                        List<Tb_order> oList = this.orderDao.findStealOrderByParam(s_order);
                        if (oList != null) {
                            this.log.info("\u67e5\u8be2\u51fa\u7684\u903b\u8f91\u5355\u6570:" + oList.size());
                            this.log.info("\u8bbe\u7f6e\u7684\u903b\u8f91\u5355\u6570:" + si_steal_count);
                            System.out.println("\u67e5\u8be2\u51fa\u7684\u903b\u8f91\u5355\u6570:" + oList.size());
                            System.out.println("\u8bbe\u7f6e\u7684\u903b\u8f91\u5355\u6570:" + si_steal_count);
                        }
                        if (oList != null && oList.size() >= XcbStringUtils.getObjtoint((Object)si_steal_count)) {
                            if (si_min_order == 0 && si_max_order == 0) {
                                order.setSr_is_steal("Y");
                            } else {
                                nowDate_str = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd");
                                Tb_order a_o = new Tb_order();
                                a_o.setSw_agent_id(sw_agent_id);
                                a_o.setSr_create_time(nowDate_str);
                                Integer count = this.orderDao.findCountStealByParam(a_o);
                                Integer todayCnt = this.orderDao.findCountByToday(a_o);
                                this.log.info("\u4eca\u65e5\u5df2\u9690\u85cf\u8ba2\u5355\u6570" + count);
                                System.out.println("\u4eca\u65e5\u5df2\u9690\u85cf\u8ba2\u5355\u6570:" + count);
                                if (todayCnt >= XcbStringUtils.getObjtoint((Object)si_min_order) && count <= XcbStringUtils.getObjtoint((Object)si_max_order)) {
                                    order.setSr_is_steal("Y");
                                } else {
                                    order.setSr_is_steal("N");
                                }
                            }
                        } else {
                            order.setSr_is_steal("N");
                        }
                    } else {
                        order.setSr_is_steal("N");
                    }
                } else {
                    order.setSr_is_steal("N");
                }
            } else {
                order.setSr_is_steal("N");
            }
            this.log.info("\u8ba2\u5355:" + sd_order_id + "\u662f\u5426\u9690\u85cf:" + order.getSr_is_steal());
            BigDecimal dc_ad_setting = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_ad_setting());
            BigDecimal dc_up_ad_setting = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_up_ad_setting());
            BigDecimal dc_ad_rate = XcbStringUtils.getObjToBigDecimal((Object)netpoint.getDc_ad_rate());
            int si_max_ad_count = XcbStringUtils.getObjtoint((Object)agent.getSi_max_ad_count());
            if (si_max_ad_count == 0) {
                si_max_ad_count = 1;
            }
            String sr_ad_start_date = "";
            String sr_ad_end_date = "";
            if ("DAY".equals(agent.getSr_ad_date_type())) {
                int sr_ad_cycle = XcbStringUtils.getObjtoint((Object)agent.getSr_ad_cycle());
                sr_ad_start_date = XcbDateUtil.getStartDay((String)XcbDateUtil.getBeforeDay((Date)new Date(), (int)sr_ad_cycle, (String)"yyyy-MM-dd"));
                sr_ad_end_date = XcbDateUtil.getTodayEnd((Date)new Date());
            } else if ("MONTH".equals(agent.getSr_ad_date_type())) {
                sr_ad_start_date = XcbDateUtil.getCurrentMonthFirst();
                sr_ad_end_date = XcbDateUtil.getCurrentMonthLast();
            } else if ("YEAR".equals(agent.getSr_ad_date_type())) {
                sr_ad_start_date = XcbDateUtil.getStartDay((String)XcbDateUtil.getYearStart());
                sr_ad_end_date = XcbDateUtil.getEndDay((String)XcbDateUtil.getYearEnd());
            }
            if ("1".equals(agent.getSr_ad_type())) {
                adO = new Tb_order();
                adO.setSw_user_id(sw_user_id);
                adO.setSw_agent_id(netpoint.getSw_agent_id());
                adO.setSr_order_time_start(sr_ad_start_date);
                adO.setSr_order_time_end(sr_ad_end_date);
                int count = this.orderDao.findCountOrderByAd(adO);
                if (count < si_max_ad_count) {
                    if ("1".equals(agent.getSr_ad_mode())) {
                        order.setDc_ad_money(dc_ad_setting);
                        order.setDc_up_ad_money(dc_up_ad_setting);
                    } else {
                        boolean isAdRate = false;
                        boolean isUpAdRate = false;
                        if (dc_ad_setting.compareTo(BigDecimal.ZERO) == 0) {
                            order.setDc_ad_money(dc_ad_setting);
                        } else {
                            isAdRate = true;
                        }
                        if (dc_up_ad_setting.compareTo(BigDecimal.ZERO) == 0) {
                            order.setDc_up_ad_money(dc_up_ad_setting);
                        } else {
                            isUpAdRate = true;
                        }
                        if (isAdRate || isUpAdRate) {
                            BigDecimal dc_temp;
                            BigDecimal dc_temp_rate;
                            o = new Tb_order();
                            o.setSw_netpoint_id(netpoint.getSd_netpoint_id());
                            o.setSr_create_time(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                            int all_cnt = this.orderDao.findTodayCountByNetId(o);
                            int ad_cnt = 0;
                            ad_cnt = isAdRate ? this.orderDao.findTodayAdCountByNetId(o) : this.orderDao.findTodayUpAdCountByNetId(o);
                            if (all_cnt == 0) {
                                all_cnt = 1;
                            }
                            if ((dc_temp_rate = BigDecimalUtil.mul((BigDecimal)(dc_temp = BigDecimalUtil.div((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)ad_cnt), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)all_cnt))), (BigDecimal)new BigDecimal(100))).compareTo(dc_ad_rate) == 1) {
                                order.setDc_ad_money(BigDecimal.ZERO);
                                order.setDc_up_ad_money(BigDecimal.ZERO);
                                if ("N".equals(device.getSr_is_show_repeat())) {
                                    if (XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_ad_setting()).compareTo(BigDecimal.ZERO) == 1) {
                                        order.setSr_is_steal("Y");
                                        order.setSr_is_show_repeat("N");
                                    } else if (XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_up_ad_setting()).compareTo(BigDecimal.ZERO) == 1) {
                                        order.setSr_is_steal("Y");
                                        order.setSr_is_show_repeat("N");
                                    }
                                }
                            } else {
                                order.setDc_ad_money(dc_ad_setting);
                                order.setDc_up_ad_money(dc_up_ad_setting);
                            }
                        }
                    }
                } else {
                    order.setDc_ad_money(BigDecimal.ZERO);
                    order.setDc_up_ad_money(BigDecimal.ZERO);
                    if ("N".equals(device.getSr_is_show_repeat())) {
                        if (XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_ad_setting()).compareTo(BigDecimal.ZERO) == 1) {
                            order.setSr_is_steal("Y");
                            order.setSr_is_show_repeat("N");
                        } else if (XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_up_ad_setting()).compareTo(BigDecimal.ZERO) == 1) {
                            order.setSr_is_steal("Y");
                            order.setSr_is_show_repeat("N");
                        }
                    }
                }
            } else {
                adO = new Tb_order();
                adO.setSw_user_id(sw_user_id);
                adO.setSw_agent_id(netpoint.getSw_agent_id());
                adO.setSr_order_time_start(sr_ad_start_date);
                adO.setSr_order_time_end(sr_ad_end_date);
                int count = this.orderDao.findCountOrderByAd(adO);
                if (count > 0) {
                    order.setDc_ad_money(BigDecimal.ZERO);
                    order.setDc_up_ad_money(BigDecimal.ZERO);
                    if ("N".equals(device.getSr_is_show_repeat())) {
                        if (XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_ad_setting()).compareTo(BigDecimal.ZERO) == 1) {
                            order.setSr_is_steal("Y");
                            order.setSr_is_show_repeat("N");
                        } else if (XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_up_ad_setting()).compareTo(BigDecimal.ZERO) == 1) {
                            order.setSr_is_steal("Y");
                            order.setSr_is_show_repeat("N");
                        }
                    }
                } else if ("1".equals(agent.getSr_ad_mode())) {
                    order.setDc_ad_money(dc_ad_setting);
                    order.setDc_up_ad_money(dc_up_ad_setting);
                } else {
                    boolean isAdRate = false;
                    boolean isUpAdRate = false;
                    if (dc_ad_setting.compareTo(BigDecimal.ZERO) == 0) {
                        order.setDc_ad_money(dc_ad_setting);
                    } else {
                        isAdRate = true;
                    }
                    if (dc_up_ad_setting.compareTo(BigDecimal.ZERO) == 0) {
                        order.setDc_up_ad_money(dc_up_ad_setting);
                    } else {
                        isUpAdRate = true;
                    }
                    if (isAdRate || isUpAdRate) {
                        BigDecimal dc_temp;
                        BigDecimal dc_temp_rate;
                        o = new Tb_order();
                        o.setSw_netpoint_id(netpoint.getSd_netpoint_id());
                        o.setSr_create_time(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                        int all_cnt = this.orderDao.findTodayCountByNetId(o);
                        int ad_cnt = 0;
                        ad_cnt = isAdRate ? this.orderDao.findTodayAdCountByNetId(o) : this.orderDao.findTodayUpAdCountByNetId(o);
                        if (all_cnt == 0) {
                            all_cnt = 1;
                        }
                        if ((dc_temp_rate = BigDecimalUtil.mul((BigDecimal)(dc_temp = BigDecimalUtil.div((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)ad_cnt), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)all_cnt))), (BigDecimal)new BigDecimal(100))).compareTo(dc_ad_rate) == 1) {
                            order.setDc_ad_money(BigDecimal.ZERO);
                            order.setDc_up_ad_money(BigDecimal.ZERO);
                            if ("N".equals(device.getSr_is_show_repeat())) {
                                if (XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_ad_setting()).compareTo(BigDecimal.ZERO) == 1) {
                                    order.setSr_is_steal("Y");
                                    order.setSr_is_show_repeat("N");
                                } else if (XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_up_ad_setting()).compareTo(BigDecimal.ZERO) == 1) {
                                    order.setSr_is_steal("Y");
                                    order.setSr_is_show_repeat("N");
                                }
                            }
                        } else {
                            order.setDc_ad_money(dc_ad_setting);
                            order.setDc_up_ad_money(dc_up_ad_setting);
                        }
                    }
                }
            }
            order.setSd_order_id(sd_order_id);
            order.setSw_agent_id(agent.getSd_agent_id());
            order.setSi_up_agent_id(agent.getSi_up_agent());
            order.setSw_company_id(agent.getSw_company_id());
            order.setSw_device_id(sw_device_id);
            order.setSr_rev_device(rev_id);
            order.setSw_box_id(sw_box_id);
            order.setSr_alias_desc(XcbStringUtils.getObjtoString((Object)device.getSr_alias()) + XcbStringUtils.getObjtoString((Object)box.getSr_alias_number()));
            order.setSw_user_id(sw_user_id);
            order.setTm_dead_time(new Date());
            order.setDc_actual_income(dc_order_money);
            order.setDc_deposit_money(dc_deposit_money);
            order.setSr_order_way(sr_order_way);
            order.setSr_order_status(XcbConstantValue.ORDER_GO);
            order.setSr_charging_type(sr_charging_type);
            order.setSr_iphone_num(sr_iphone_num);
            order.setSr_password(sr_password);
            order.setTm_order_time(new Date());
            order.setDc_once_price(devicePackage.getDc_once_price());
            order.setSi_fee_time(devicePackage.getSi_fee_time());
            order.setSi_max_hour(devicePackage.getSi_max_hour());
            order.setDc_advance_price(devicePackage.getDc_advance_price());
            order.setDc_hour_price(devicePackage.getDc_hour_price());
            order.setSi_time_slot(devicePackage.getSi_time_slot());
            order.setDc_max_xf(devicePackage.getDc_max_xf());
            order.setSr_maxservice_time(devicePackage.getSr_maxservice_time());
            order.setTm_order_starttime(new Date());
            order.setTm_create_time(new Date());
            order.setSi_create_person(sw_user_id);
            order.setTm_modify_time(new Date());
            order.setSi_modify_person(sw_user_id);
            order.setSr_checked(XcbConstantValue.ORDER_X);
            order.setDc_order_money(dc_order_money);
            order.setSr_mchid(sr_mchid);
            Tb_order o2 = this.orderDao.findOrderById_user(sd_order_id);
            result = o2 != null ? 1 : this.orderDao.createOrder(order);
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5: createOrder\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            this.log.error(PromptProperties.getProperty("order.paynotify.create.fail", sd_order_id));
        }
        return result;
    }

    private int createOrderCash(String sd_ordercash_id, Integer sw_user_id, String sd_order_id, String transaction_id, String channelTransNo, String sr_cash_type, BigDecimal dc_actual_income, BigDecimal dc_order_money) {
        int result = 0;
        try {
            Tb_user user = this.userDao.findUserById(sw_user_id);
            Tb_ordercash_stream orderCash = new Tb_ordercash_stream();
            orderCash.setSd_ordercash_id(sd_ordercash_id);
            orderCash.setSw_company_id(user.getSw_company_id());
            orderCash.setSw_order_id(sd_order_id);
            orderCash.setSr_pay_order_id(channelTransNo);
            orderCash.setSw_bus_order_id(transaction_id);
            orderCash.setSr_cash_type(sr_cash_type);
            orderCash.setSr_order_status(XcbConstantValue.ORDER_CASH_ZFCG);
            orderCash.setDc_actual_pay(dc_actual_income);
            orderCash.setDc_order_money(dc_order_money);
            orderCash.setTm_pay_time(new Date());
            orderCash.setTm_create_time(new Date());
            orderCash.setSi_create_person(sw_user_id);
            orderCash.setTm_modify_time(new Date());
            orderCash.setSi_modify_person(sw_user_id);
            Tb_ordercash_stream os = this.orderCashStreamDao.findOrderCashStreamById(sd_ordercash_id);
            result = os != null ? 1 : this.orderCashStreamDao.createOrderCashStream(orderCash);
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5: createOrderCash\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            this.log.error(PromptProperties.getProperty("order.paynotify.create.ordercash.fail", sd_ordercash_id));
        }
        return result;
    }

    public int updateUserAccount(Identifier identifier, Tb_order order, BigDecimal zfMoney) throws Exception {
        int result = 0;
        try {
            Tb_user_account userAccountPlatform = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
            if (userAccountPlatform != null) {
                result = this.commonLogic.updateUser_account(identifier, zfMoney, new BigDecimal(0), userAccountPlatform, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_XF);
            } else {
                result = -1;
                this.log.error(PromptProperties.getProperty("userAccount.update.error1", identifier.getUserId(), order.getDc_actual_income()));
            }
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5: updateUserAccount\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            throw new Exception(e);
        }
        return result;
    }

    public int createUserRecharge(Tb_order order, BigDecimal recharge_money, String sr_is_show) throws Exception {
        int result = 0;
        try {
            Tb_user_recharge userRecharge = new Tb_user_recharge();
            userRecharge.setSd_recharge_id(CommonFunction.getVoucherNum((String)CommonFunction.cz_id));
            userRecharge.setSw_user_id(order.getSw_user_id());
            userRecharge.setDc_recharge_money(recharge_money);
            userRecharge.setSr_payorder_number(order.getSd_order_id());
            userRecharge.setDc_present_award(new BigDecimal(0));
            userRecharge.setSr_pay_type(order.getSr_order_way());
            userRecharge.setTm_recharge_time(new Date());
            userRecharge.setTm_pay_time(new Date());
            userRecharge.setSr_order_source(XcbConstantValue.USERRECHARGE_PAYWAY_SJ);
            userRecharge.setSr_order_status(XcbConstantValue.USERRECHARGE_ZFCG);
            userRecharge.setSi_create_person(order.getSw_user_id());
            userRecharge.setTm_create_time(new Date());
            userRecharge.setSi_modify_person(order.getSw_user_id());
            userRecharge.setTm_modify_time(new Date());
            userRecharge.setSr_is_show(sr_is_show);
            result = this.userRechargeDao.createRecharge(userRecharge);
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5: createUserRecharge\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            throw new Exception(e);
        }
        return result;
    }

    private Map<String, Object> updateAgentAccount(Tb_agent agent, BigDecimal dc_actual_income) {
        BigDecimal cbMoney;
        boolean result = false;
        String flowItem = "";
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        String payType = "";
        BigDecimal maxCbMoney = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_cb_single());
        if (maxCbMoney.compareTo(cbMoney = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_cb_money())) > 0) {
            payType = XcbConstantValue.CASH_STREAM_YFK;
            flowItem = XcbConstantValue.CASH_STREAM_CBJCZ;
        } else {
            payType = XcbConstantValue.CASH_STREAM_WFK;
            flowItem = XcbConstantValue.CASH_STREAM_JCGDD;
        }
        dataMap.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        dataMap.put("flowItem", flowItem);
        dataMap.put("payType", payType);
        return dataMap;
    }

    public int createCashStream(Integer sw_user_id, Integer sw_agent_id, String sd_order_id, String sd_cash_id, String sr_cashflow_item, String payType, BigDecimal zfMoney, String sr_remarks, String sr_checked) {
        int result = 0;
        try {
            Tb_cash_stream cashStream = new Tb_cash_stream();
            cashStream.setSd_cash_id(sd_cash_id);
            cashStream.setSw_agent_id(sw_agent_id);
            cashStream.setDc_cashflow_money(zfMoney);
            cashStream.setSr_cashflow_item(sr_cashflow_item);
            cashStream.setSr_cashflow_remark(sd_order_id);
            cashStream.setSr_company_pay(payType);
            cashStream.setSi_create_person(sw_user_id);
            cashStream.setSi_modify_person(sw_user_id);
            cashStream.setSr_remarks(sr_remarks);
            cashStream.setSr_checked(sr_checked);
            result = this.cashStreamDao.createCashStream(cashStream);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(PromptProperties.getProperty("cash.create.fail"), (Throwable)e);
        }
        return result;
    }

    @Transactional
    public Map<String, Object> finishOrderById(Identifier identifier, String sd_order_id, String sr_type, String sr_way) {
        Map<String, Object> ret;
        block89: {
            ret = new HashMap<String, Object>();
            int result = 0;
            BigDecimal sendMoney = BigDecimal.ZERO;
            String sendType = "";
            boolean isSend = false;
            String sw_ordercash_id = "";
            try {
                Map<String, Object> orderMap = this.findOrderById_user(identifier, sd_order_id);
                Map dataMap = (Map)orderMap.get(XcbConstantValue.DATA);
                Tb_order order = (Tb_order)dataMap.get("order");
                System.out.println("\u7ed3\u675f\u8ba2\u5355:" + order.getSd_order_id() + "," + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss") + "\uff0csr_type" + sr_type + "\uff0csr_way: " + sr_way);
                this.log.info("\u7ed3\u675f\u8ba2\u5355:" + order.getSd_order_id() + "," + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss") + "\uff0csr_type" + sr_type + "\uff0csr_way: " + sr_way);
                if (XcbConstantValue.ORDER_GO.equals(order.getSr_order_status())) {
                    List<Tb_ordercash_stream> osList;
                    Tb_user_account n_userAccount;
                    Tb_order n_order;
                    boolean isExist = false;
                    String sr_is_reuse = order.getSr_is_reuse();
                    if ("Y".equals(sr_is_reuse)) {
                        isExist = true;
                    }
                    Tb_user user = this.userDao.findUserById(order.getSw_user_id());
                    if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                        Tb_order o_new;
                        Tb_user_account userAccount;
                        BigDecimal dc_deposit_money;
                        if (!XcbStringUtils.isNullOrBlank((Object)order.getDc_arrears()) && order.getDc_arrears().compareTo(BigDecimal.ZERO) == 1) {
                            dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                            userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
                            result = "business".equals(sr_type) ? this.commonLogic.updateRemarkUser_account(identifier, dc_deposit_money, userAccount, XcbConstantValue.TB_TYPE_ADD) : this.commonLogic.updateUser_account(identifier, dc_deposit_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                Tb_order n_order2 = new Tb_order();
                                n_order2.setSd_order_id(sd_order_id);
                                n_order2.setSr_order_status(XcbConstantValue.ORDER_YWC);
                                n_order2.setTm_order_endtime(new Date());
                                n_order2.setDc_order_money(order.getDc_order_money());
                                n_order2.setSi_modify_person(identifier.getUserId());
                                n_order2.setTm_modify_time(new Date());
                                result = this.orderDao.updateOrder(n_order2);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    List<Tb_ordercash_stream> osList2 = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                    Tb_ordercash_stream orderCash = osList2.get(0);
                                    sw_ordercash_id = orderCash.getSd_ordercash_id();
                                    if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type())) {
                                        result = this.createUserRecharge(order, dc_deposit_money, "Y");
                                    }
                                    if (order.getDc_actual_income().compareTo(BigDecimal.ZERO) == 1) {
                                        if (!"Y".equals(order.getSr_is_steal())) {
                                            ret = this.calculationOrderIncome(identifier, order, order.getDc_actual_income());
                                            result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                        } else {
                                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                                            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.success"));
                                        }
                                    }
                                }
                            }
                        } else if (!XcbStringUtils.isNullOrBlank((Object)order.getDc_return()) && order.getDc_return().compareTo(BigDecimal.ZERO) == 1) {
                            dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                            dc_deposit_money = BigDecimalUtil.add((BigDecimal)dc_deposit_money, (BigDecimal)order.getDc_return());
                            userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
                            result = "business".equals(sr_type) ? this.commonLogic.updateRemarkUser_account(identifier, dc_deposit_money, userAccount, XcbConstantValue.TB_TYPE_ADD) : this.commonLogic.updateUser_account(identifier, dc_deposit_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                o_new = new Tb_order();
                                o_new.setSd_order_id(order.getSd_order_id());
                                o_new.setSr_order_status(XcbConstantValue.ORDER_YWC);
                                o_new.setTm_order_endtime(order.getTm_order_endtime());
                                o_new.setDc_order_money(order.getDc_order_money());
                                o_new.setDc_actual_income(order.getDc_order_money());
                                o_new.setTm_modify_time(new Date());
                                o_new.setSi_modify_person(order.getSw_user_id());
                                o_new.setDc_deposit_money(dc_deposit_money);
                                result = this.orderDao.updateOrder(o_new);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    List<Tb_ordercash_stream> osList3 = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                    Tb_ordercash_stream orderCash = osList3.get(0);
                                    sw_ordercash_id = orderCash.getSd_ordercash_id();
                                    if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type())) {
                                        String sr_is_show = "Y";
                                        if ("business".equals(sr_type)) {
                                            sr_is_show = "N";
                                        }
                                        result = this.createUserRecharge(order, dc_deposit_money, sr_is_show);
                                    }
                                    if (result > XcbConstantValue.OPERA_INT_ZERO && !"Y".equals(order.getSr_is_steal())) {
                                        ret = this.calculationOrderIncome(identifier, order, order.getDc_order_money());
                                        result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                    }
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        orderCash.setDc_actual_pay(order.getDc_order_money());
                                        result = this.orderCashStreamDao.updateOrderCashStream(orderCash);
                                        sendMoney = order.getDc_return();
                                        sendType = "DEPOSIT";
                                        isSend = true;
                                    }
                                }
                            }
                        } else if (order.isSr_is_fee()) {
                            dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                            dc_deposit_money = BigDecimalUtil.add((BigDecimal)order.getDc_actual_income(), (BigDecimal)dc_deposit_money);
                            userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
                            result = "business".equals(sr_type) ? this.commonLogic.updateRemarkUser_account(identifier, dc_deposit_money, userAccount, XcbConstantValue.TB_TYPE_ADD) : this.commonLogic.updateUser_account(identifier, dc_deposit_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                o_new = new Tb_order();
                                o_new.setSd_order_id(order.getSd_order_id());
                                o_new.setSr_order_status(XcbConstantValue.ORDER_YWC);
                                o_new.setTm_order_endtime(order.getTm_order_endtime());
                                o_new.setDc_order_money(order.getDc_order_money());
                                o_new.setDc_actual_income(order.getDc_order_money());
                                o_new.setTm_modify_time(new Date());
                                o_new.setDc_deposit_money(dc_deposit_money);
                                o_new.setSi_modify_person(order.getSw_user_id());
                                result = this.orderDao.updateOrder(o_new);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    List<Tb_ordercash_stream> osList4 = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                    Tb_ordercash_stream orderCash = osList4.get(0);
                                    sw_ordercash_id = orderCash.getSd_ordercash_id();
                                    if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type())) {
                                        String sr_is_show = "Y";
                                        if ("business".equals(sr_type)) {
                                            sr_is_show = "N";
                                        }
                                        result = this.createUserRecharge(order, dc_deposit_money, sr_is_show);
                                    }
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        orderCash.setDc_actual_pay(order.getDc_order_money());
                                        result = this.orderCashStreamDao.updateOrderCashStream(orderCash);
                                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                            sendMoney = dc_deposit_money;
                                            sendType = "DEPOSIT";
                                            isSend = true;
                                        }
                                    }
                                }
                            }
                        } else {
                            dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                            result = this.commonLogic.updateUser_account(identifier, dc_deposit_money, new BigDecimal(0), userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id()), XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                o_new = new Tb_order();
                                o_new.setSd_order_id(order.getSd_order_id());
                                o_new.setSr_order_status(XcbConstantValue.ORDER_YWC);
                                o_new.setTm_order_endtime(order.getTm_order_endtime());
                                o_new.setDc_order_money(order.getDc_order_money());
                                o_new.setDc_actual_income(order.getDc_order_money());
                                o_new.setTm_modify_time(new Date());
                                o_new.setSi_modify_person(order.getSw_user_id());
                                result = this.orderDao.updateOrder(o_new);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    List<Tb_ordercash_stream> osList5 = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                    Tb_ordercash_stream orderCash = osList5.get(0);
                                    sw_ordercash_id = orderCash.getSd_ordercash_id();
                                    if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type())) {
                                        result = this.createUserRecharge(order, dc_deposit_money, "Y");
                                    }
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        orderCash.setDc_actual_pay(order.getDc_order_money());
                                        result = this.orderCashStreamDao.updateOrderCashStream(orderCash);
                                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                            if (!"Y".equals(order.getSr_is_steal())) {
                                                ret = this.calculationOrderIncome(identifier, order, order.getDc_actual_income());
                                                result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                                    sendMoney = dc_deposit_money;
                                                    sendType = "DEPOSIT";
                                                    isSend = true;
                                                }
                                            } else {
                                                sendMoney = dc_deposit_money;
                                                sendType = "DEPOSIT";
                                                isSend = true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
                        n_order = new Tb_order();
                        n_order.setSd_order_id(sd_order_id);
                        n_order.setSr_order_status(XcbConstantValue.ORDER_YWC);
                        n_order.setTm_order_endtime(new Date());
                        n_order.setSi_modify_person(identifier.getUserId());
                        n_order.setTm_modify_time(new Date());
                        result = this.orderDao.updateOrder(n_order);
                        if (result > XcbConstantValue.OPERA_INT_ZERO && !isExist) {
                            if (order.getDc_deposit_money().compareTo(BigDecimal.ZERO) == 1) {
                                n_userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
                                result = "business".equals(sr_type) ? this.commonLogic.updateRemarkUser_account(identifier, order.getDc_deposit_money(), n_userAccount, XcbConstantValue.TB_TYPE_ADD) : this.commonLogic.updateUser_account(identifier, order.getDc_deposit_money(), new BigDecimal(0), n_userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    osList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                    if (osList != null && osList.size() > 0) {
                                        Tb_ordercash_stream orderCash = osList.get(0);
                                        sw_ordercash_id = orderCash.getSd_ordercash_id();
                                        if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type())) {
                                            String sr_is_show = "Y";
                                            if ("business".equals(sr_type)) {
                                                sr_is_show = "N";
                                            }
                                            result = this.createUserRecharge(order, order.getDc_deposit_money(), sr_is_show);
                                        } else {
                                            result = XcbConstantValue.OPERA_INT_ONE;
                                        }
                                    }
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        if (!"Y".equals(order.getSr_is_steal())) {
                                            ret = this.calculationOrderIncome(identifier, order, order.getDc_actual_income());
                                            result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                                sendMoney = order.getDc_deposit_money();
                                                sendType = "DEPOSIT";
                                                isSend = true;
                                            }
                                        } else {
                                            sendMoney = order.getDc_deposit_money();
                                            sendType = "DEPOSIT";
                                            isSend = true;
                                        }
                                    }
                                }
                            } else if (!"Y".equals(order.getSr_is_steal()) && (result = XcbStringUtils.getObjtoint((Object)(ret = this.calculationOrderIncome(identifier, order, order.getDc_actual_income())).get(XcbConstantValue.STATUS))) > XcbConstantValue.OPERA_INT_ZERO) {
                                sendMoney = order.getDc_deposit_money();
                                sendType = "DEPOSIT";
                                isSend = true;
                            }
                        }
                    } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
                        n_order = new Tb_order();
                        n_order.setSd_order_id(sd_order_id);
                        n_order.setSr_order_status(XcbConstantValue.ORDER_YWC);
                        n_order.setTm_order_endtime(new Date());
                        n_order.setSi_modify_person(identifier.getUserId());
                        n_order.setTm_modify_time(new Date());
                        result = this.orderDao.updateOrder(n_order);
                        if (result > XcbConstantValue.OPERA_INT_ZERO && !isExist) {
                            if (order.getDc_deposit_money().compareTo(BigDecimal.ZERO) == 1) {
                                n_userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
                                result = "business".equals(sr_type) ? this.commonLogic.updateRemarkUser_account(identifier, order.getDc_deposit_money(), n_userAccount, XcbConstantValue.TB_TYPE_ADD) : this.commonLogic.updateUser_account(identifier, order.getDc_deposit_money(), new BigDecimal(0), n_userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    osList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                    if (osList != null && osList.size() > 0) {
                                        Tb_ordercash_stream orderCash = osList.get(0);
                                        sw_ordercash_id = orderCash.getSd_ordercash_id();
                                        if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type())) {
                                            String sr_is_show = "Y";
                                            if ("business".equals(sr_type)) {
                                                sr_is_show = "N";
                                            }
                                            result = this.createUserRecharge(order, order.getDc_deposit_money(), sr_is_show);
                                        } else {
                                            result = XcbConstantValue.OPERA_INT_ONE;
                                        }
                                    }
                                    if (result > XcbConstantValue.OPERA_INT_ZERO && !"Y".equals(order.getSr_is_steal()) && (result = XcbStringUtils.getObjtoint((Object)(ret = this.calculationOrderIncome(identifier, order, order.getDc_actual_income())).get(XcbConstantValue.STATUS))) > XcbConstantValue.OPERA_INT_ZERO) {
                                        sendMoney = order.getDc_deposit_money();
                                        sendType = "DEPOSIT";
                                        isSend = true;
                                    }
                                }
                            } else if (!"Y".equals(order.getSr_is_steal()) && (result = XcbStringUtils.getObjtoint((Object)(ret = this.calculationOrderIncome(identifier, order, order.getDc_actual_income())).get(XcbConstantValue.STATUS))) > XcbConstantValue.OPERA_INT_ZERO) {
                                sendMoney = order.getDc_deposit_money();
                                sendType = "DEPOSIT";
                                isSend = true;
                            }
                        }
                    }
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(order.getSw_box_id());
                        if (!XcbStringUtils.isNullOrBlank((Object)sr_way)) {
                            Tb_opendoor_record record = new Tb_opendoor_record();
                            String sd_openid_id = CommonFunction.getVoucherNum((String)CommonFunction.op_id);
                            record.setSd_openid_id(sd_openid_id);
                            record.setSw_order_id(order.getSd_order_id());
                            record.setTm_create_time(new Date());
                            record.setTm_modify_time(new Date());
                            record.setSr_create_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                            record.setSr_modify_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                            if ("USER".equals(sr_way)) {
                                record.setSw_user_id(order.getSw_user_id());
                                record.setSr_type(XcbConstantValue.OPEN_DOOR_TYPE_USER_GB);
                                record.setSr_remarks("\u7528\u6237\u5173\u95ed");
                            } else if ("AGENT".equals(sr_way)) {
                                record.setSr_type(XcbConstantValue.OPEN_DOOR_TYPE_AGENT_GB);
                                record.setSr_remarks("\u4ee3\u7406\u5546\u5173\u95ed");
                            } else if ("SHOP".equals(sr_way)) {
                                record.setSr_type(XcbConstantValue.OPEN_DOOR_TYPE_AGENT_GB);
                                record.setSr_remarks("\u5546\u5bb6\u5173\u95ed");
                            } else if ("CPY".equals(sr_way)) {
                                record.setSr_type(XcbConstantValue.OPEN_DOOR_TYPE_CPY_GB);
                                record.setSr_remarks("\u516c\u53f8\u5173\u95ed");
                            } else if ("SYSTEM".equals(sr_way)) {
                                record.setSr_type(XcbConstantValue.OPEN_DOOR_TYPE_QG);
                                record.setSr_remarks("\u7cfb\u7edf\u5173\u95ed");
                            }
                            this.openDoorRecordDao.createOpenDoorRecord(record);
                        }
                        if (deviceBox != null && XcbConstantValue.DEVICE_BOX_STATUS_ZY.equals(deviceBox.getSr_box_status())) {
                            Tb_device_box n_box = new Tb_device_box();
                            n_box.setSd_box_id(order.getSw_box_id());
                            n_box.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_KY);
                            n_box.setTm_use_time(new Date());
                            result = this.deviceBoxDao.updateDeviceBoxById(n_box);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                if (!"SYSTEM".equals(sr_way)) {
                                    order = this.orderDao.findOrderById_user(order.getSd_order_id());
                                    order.setSw_ordercash_id(sw_ordercash_id);
                                    if (user != null) {
                                        if ("Y".equals(user.getSr_is_subscribe())) {
                                            this.sendWXMessage(order, order.getDc_actual_income(), "FINISH");
                                            if (isSend) {
                                                this.sendWXMessage(order, sendMoney, sendType);
                                            }
                                        } else if ("Y".equals(user.getSr_subscribe_finish())) {
                                            this.sendWXAppMessage(order, order.getDc_actual_income(), "FINISH");
                                            if (isSend) {
                                                this.sendWXAppMessage(order, sendMoney, sendType);
                                            }
                                        }
                                    }
                                }
                                if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(deviceBox.getSr_device_type())) {
                                    this.deviceCloudService.refreshDoor(deviceBox.getSw_mainboard_id());
                                }
                                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.success"));
                                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            } else {
                                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.fail"));
                                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            }
                        } else {
                            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.success"));
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        }
                    } else {
                        ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.fail"));
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    }
                    break block89;
                }
                ret.put(XcbConstantValue.MSG, "\u8ba2\u5355\u5df2\u7ed3\u675f");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            catch (Exception e) {
                this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_CLOSE + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
        }
        this.initResultMap(ret);
        return ret;
    }

    public Map<String, Object> calculationOrderIncome(Identifier identifier, Tb_order order, BigDecimal dc_actual_income) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        try {
            String sd_cash_id;
            String payType;
            String flowItem;
            Map<String, Object> resMap;
            Integer sw_agent_id = order.getSw_agent_id();
            Tb_agent agent = this.agentDao.findAgentById(sw_agent_id);
            Tb_agent upAgent = new Tb_agent();
            if (!XcbStringUtils.isNullOrBlank((Object)agent.getSi_up_agent())) {
                upAgent = this.agentDao.findAgentById(agent.getSi_up_agent());
            }
            BigDecimal agentbonus = XcbStringUtils.getObjToBigDecimal((Object)upAgent.getDc_fisrt_bonus());
            BigDecimal shopbonus = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_fisrt_bonus());
            BigDecimal cpybonus = BigDecimalUtil.sub((BigDecimal)new BigDecimal(100), (BigDecimal)BigDecimalUtil.add((BigDecimal)agentbonus, (BigDecimal)shopbonus));
            BigDecimal agentmoney = BigDecimalUtil.mul((BigDecimal)dc_actual_income, (BigDecimal)BigDecimalUtil.div((BigDecimal)agentbonus, (BigDecimal)new BigDecimal(100)));
            BigDecimal shopmoney = BigDecimalUtil.mul((BigDecimal)dc_actual_income, (BigDecimal)BigDecimalUtil.div((BigDecimal)shopbonus, (BigDecimal)new BigDecimal(100)));
            BigDecimal cpymoney = BigDecimalUtil.sub((BigDecimal)dc_actual_income, (BigDecimal)BigDecimalUtil.add((BigDecimal)shopmoney, (BigDecimal)agentmoney));
            if (cpymoney.compareTo(BigDecimal.ZERO) == -1) {
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_USER, XcbConstantValue.ORDER_FOR_ACCOUNT, order.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "CREATE", "\u516c\u53f8\u5206\u6210\u91d1\u989d\u5f02\u5e38:" + cpymoney, "", "");
                operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                operationLogs.setSr_operate_primarykey(order.getSd_order_id());
                operationLogs.setSr_operate_table("Tb_order_income");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
            }
            Tb_order_income income = new Tb_order_income();
            income.setSw_order_id(order.getSd_order_id());
            income.setSw_company_id(agent.getSw_company_id());
            income.setDc_company_rate(cpybonus);
            income.setDc_company_money(cpymoney);
            income.setSw_agent_id(agent.getSi_up_agent());
            income.setDc_agent_rate(agentbonus);
            income.setDc_agent_money(agentmoney);
            income.setSw_shop_id(agent.getSd_agent_id());
            income.setDc_shop_rate(shopbonus);
            income.setDc_shop_money(shopmoney);
            income.setSr_status("1");
            income.setTm_create_time(new Date());
            try {
                this.orderInComeDao.createOrderIncome(income);
            }
            catch (Exception e) {
                this.log.error("\u5f02\u5e38\u65b9\u6cd5: calculationOrderIncome\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
                System.out.println(e.getMessage());
            }
            if (agentmoney.compareTo(BigDecimal.ZERO) == 1) {
                resMap = this.updateAgentAccount(upAgent, agentmoney);
                result = XcbStringUtils.getObjtoint((Object)resMap.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    flowItem = XcbStringUtils.getObjtoString((Object)resMap.get("flowItem"));
                    payType = XcbStringUtils.getObjtoString((Object)resMap.get("payType"));
                    sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                    result = this.createCashStream(order.getSw_user_id(), upAgent.getSd_agent_id(), order.getSd_order_id(), sd_cash_id, flowItem, payType, agentmoney, "", XcbConstantValue.CASH_STREAM_WFH);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.finish.create.cash.fail", XcbConstantValue.ORDER_FINISH, order.getSd_order_id()));
                    }
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.finish.updateagent.fail", XcbConstantValue.ORDER_FINISH, order.getSd_order_id()));
                }
            } else {
                result = 1;
            }
            if (shopmoney.compareTo(BigDecimal.ZERO) == 1) {
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    resMap = this.updateAgentAccount(agent, shopmoney);
                    result = XcbStringUtils.getObjtoint((Object)resMap.get(XcbConstantValue.STATUS));
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        flowItem = XcbStringUtils.getObjtoString((Object)resMap.get("flowItem"));
                        payType = XcbStringUtils.getObjtoString((Object)resMap.get("payType"));
                        sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                        result = this.createCashStream(order.getSw_user_id(), order.getSw_agent_id(), order.getSd_order_id(), sd_cash_id, flowItem, payType, shopmoney, "", XcbConstantValue.CASH_STREAM_WFH);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.success"));
                        } else {
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.finish.create.cash.fail", XcbConstantValue.ORDER_FINISH, order.getSd_order_id()));
                        }
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.finish.updateagent.fail", XcbConstantValue.ORDER_FINISH, order.getSd_order_id()));
                    }
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.success"));
            }
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_FINISH + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            throw new BusinessException(XcbConstantValue.ORDER_FINISH, PromptProperties.getProperty("order.finish.fail", XcbConstantValue.ORDER_FINISH, order.getSd_order_id(), e.getMessage()), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> findOrderByPwd(Identifier identifier, Tb_order order) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        List<Tb_order> orderList = null;
        try {
            Tb_sys_param sysParam = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.FINISH_TIME);
            long min = XcbStringUtils.getObjtoLong((Object)sysParam.getSr_param_value());
            orderList = this.orderDao.findOrderByPwd(order);
            if (orderList != null && orderList.size() > 0) {
                if (orderList.size() == 1) {
                    if (order.getSr_password().equals(orderList.get(0).getSr_password())) {
                        Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(orderList.get(0).getSw_box_id());
                        orderList.get(0).setDeviceBox(deviceBox);
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret.put(XcbConstantValue.DATA, orderList);
                        ret.put(XcbConstantValue.FINISH_TIME, min);
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, "\u8f93\u5165\u7684\u5b58\u5305\u5bc6\u7801\u6709\u8bef!");
                    }
                } else {
                    ArrayList<Tb_order> list = new ArrayList<Tb_order>();
                    for (Tb_order o : orderList) {
                        if (!order.getSr_password().equals(o.getSr_password())) continue;
                        Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(o.getSw_box_id());
                        o.setDeviceBox(deviceBox);
                        list.add(o);
                    }
                    if (list.size() > 0) {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret.put(XcbConstantValue.DATA, list);
                        ret.put(XcbConstantValue.FINISH_TIME, min);
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, "\u8f93\u5165\u7684\u5b58\u5305\u5bc6\u7801\u6709\u8bef!");
                    }
                }
            } else {
                orderList = this.orderDao.findOrderByPass(order);
                if (orderList != null && orderList.size() > 0) {
                    Tb_order o = orderList.get(0);
                    String title = "";
                    String sr_alias = XcbStringUtils.getObjtoString((Object)o.getSr_alias());
                    if (!XcbStringUtils.isNullOrBlank((Object)sr_alias)) {
                        title = sr_alias.matches(".*[a-zA-Z].*") ? title + sr_alias + "\u533a" : title + sr_alias;
                    }
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, "\u8bf7\u79fb\u6b65" + title + "\uff0c\u60a8\u628a\u7269\u54c1\u5b58\u5728\u4e86" + o.getSr_alias_desc() + "\u3002");
                } else {
                    order.setSr_create_time(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                    List<Tb_order> todayOrderList = this.orderDao.checkTodayOrder(order);
                    if (todayOrderList != null && todayOrderList.size() > 0) {
                        Tb_order todayOrder = todayOrderList.get(0);
                        order.setSw_box_id(todayOrder.getSw_box_id());
                        orderList = this.orderDao.findOrderByMid(order);
                        if (orderList != null && orderList.size() > 0) {
                            if (order.getSr_iphone_num().equals(orderList.get(0).getSr_iphone_num())) {
                                Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(orderList.get(0).getSw_box_id());
                                orderList.get(0).setDeviceBox(deviceBox);
                                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                                ret.put(XcbConstantValue.DATA, orderList);
                            } else {
                                ret.put(XcbConstantValue.MSG, "\u8ba2\u5355\u5df2\u7ecf\u7ed3\u675f\uff0c\u9700\u8981\u5f00\u95e8\u8bf7\u62e8\u6253\u5ba2\u670d\u70ed\u7ebf400-698-1080");
                                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            }
                        } else {
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            ret.put(XcbConstantValue.MSG, "\u6ca1\u6709\u627e\u5230\u8ba2\u5355\uff0c\u8bf7\u786e\u8ba4\u624b\u673a\u53f7\u6216\u5bc6\u7801\u662f\u5426\u6b63\u786e\uff1f");
                        }
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, "\u6ca1\u6709\u627e\u5230\u8ba2\u5355\uff0c\u8bf7\u786e\u8ba4\u624b\u673a\u53f7\u6216\u5bc6\u7801\u662f\u5426\u6b63\u786e\uff1f");
                    }
                }
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYPWD, PromptProperties.getProperty("order.findbyid.fail"), (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    @Transactional
    Map<String, Object> finishOrder(Identifier identifier, Tb_order order, String sr_way) {
        Map<String, Object> ret = new HashMap<String, Object>();
        boolean isSuccess = false;
        boolean isExist = false;
        int result = 0;
        String msg = "";
        BigDecimal sendMoney = BigDecimal.ZERO;
        String sendType = "";
        boolean isSend = false;
        String sw_ordercash_id = "";
        try {
            Tb_sys_param sysParam = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.FINISH_TIME);
            long nowTime = XcbDateUtil.getCurrentTimestamp();
            Map<String, Object> orderMap = this.findOrderById_finish(identifier, order.getSd_order_id());
            Map dataMap = (Map)orderMap.get(XcbConstantValue.DATA);
            order = (Tb_order)dataMap.get("order");
            System.out.println("\u5c4f\u5e55\u7ed3\u675f\u5bc4\u5b58:" + order.getSd_order_id() + "," + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
            this.log.info("\u5c4f\u5e55\u7ed3\u675f\u5bc4\u5b58:" + order.getSd_order_id() + "," + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
            if (XcbConstantValue.ORDER_GO.equals(order.getSr_order_status())) {
                String sr_is_reuse = order.getSr_is_reuse();
                if ("Y".equals(sr_is_reuse)) {
                    isExist = true;
                }
                if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type()) || XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
                    Tb_order n_order = new Tb_order();
                    n_order.setSd_order_id(order.getSd_order_id());
                    n_order.setSr_order_status(XcbConstantValue.ORDER_YWC);
                    n_order.setTm_order_endtime(new Date());
                    n_order.setSi_modify_person(identifier.getUserId());
                    n_order.setTm_modify_time(new Date());
                    result = this.orderDao.updateOrder(n_order);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        if (!isExist) {
                            if (!"Y".equals(order.getSr_is_steal())) {
                                ret = this.calculationOrderIncome(identifier, order, order.getDc_actual_income());
                                result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                            }
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                if (order.getDc_deposit_money().compareTo(BigDecimal.ZERO) == 1) {
                                    Tb_user_account n_userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
                                    result = this.commonLogic.updateUser_account(identifier, order.getDc_deposit_money(), new BigDecimal(0), n_userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                                    List<Tb_ordercash_stream> osList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                    if (osList != null && osList.size() > 0) {
                                        Tb_ordercash_stream orderCash = osList.get(0);
                                        sw_ordercash_id = orderCash.getSd_ordercash_id();
                                        result = !XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type()) ? this.createUserRecharge(order, order.getDc_deposit_money(), "Y") : XcbConstantValue.OPERA_INT_ONE.intValue();
                                    }
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        isSuccess = true;
                                        sendMoney = order.getDc_deposit_money();
                                        sendType = "DEPOSIT";
                                        isSend = true;
                                    }
                                } else {
                                    isSuccess = true;
                                }
                            } else {
                                msg = PromptProperties.getProperty("order.finish.create.cash.fail", XcbConstantValue.ORDER_FINISH, order.getSd_order_id());
                                this.log.error(msg);
                            }
                        } else {
                            isSuccess = true;
                        }
                    } else {
                        msg = PromptProperties.getProperty("order.update.fail");
                        this.log.error(msg);
                    }
                } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                    BigDecimal dc_deposit_money;
                    if (!XcbStringUtils.isNullOrBlank((Object)order.getDc_arrears()) && order.getDc_arrears().compareTo(BigDecimal.ZERO) == 1) {
                        Tb_user_account userAccount;
                        BigDecimal orderMoney = BigDecimal.ZERO;
                        String remark = "";
                        BigDecimal dc_deposit_money2 = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                        result = this.commonLogic.updateUser_account(identifier, dc_deposit_money2, new BigDecimal(0), userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id()), XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            orderMoney = order.getDc_actual_income();
                            Tb_order n_order = new Tb_order();
                            n_order.setSd_order_id(order.getSd_order_id());
                            n_order.setSr_order_status(XcbConstantValue.ORDER_YWC);
                            n_order.setTm_order_endtime(new Date());
                            n_order.setDc_order_money(order.getDc_order_money());
                            n_order.setSi_modify_person(identifier.getUserId());
                            n_order.setTm_modify_time(new Date());
                            result = this.orderDao.updateOrder(n_order);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                List<Tb_ordercash_stream> osList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                Tb_ordercash_stream orderCash = osList.get(0);
                                sw_ordercash_id = orderCash.getSd_ordercash_id();
                                if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type())) {
                                    result = this.createUserRecharge(order, dc_deposit_money2, "Y");
                                }
                                if (!"Y".equals(order.getSr_is_steal())) {
                                    ret = this.calculationOrderIncome(identifier, order, orderMoney);
                                    result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                }
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    if ("uniapp".equals(sr_way)) {
                                        String sr_type = XcbConstantValue.OPEN_DOOR_TYPE_DDJS;
                                        Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(order.getSw_box_id());
                                        ret = this.deviceCloudService.openLock(order.getSw_user_id(), deviceBox, order.getSd_order_id(), sr_type, "");
                                        result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                            isSuccess = true;
                                        } else {
                                            String message = XcbStringUtils.getObjtoString((Object)ret.get(XcbConstantValue.MSG));
                                            msg = PromptProperties.getProperty("order.finish.openlock.fail", order.getSd_order_id(), message);
                                            this.log.error(msg);
                                        }
                                    } else {
                                        isSuccess = true;
                                    }
                                } else {
                                    msg = PromptProperties.getProperty("order.finish.create.cash.fail", XcbConstantValue.ORDER_FINISH, order.getSd_order_id());
                                    this.log.error(msg);
                                }
                            }
                        }
                    } else if (!XcbStringUtils.isNullOrBlank((Object)order.getDc_return()) && order.getDc_return().compareTo(BigDecimal.ZERO) == 1) {
                        Tb_user_account userAccount;
                        dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                        result = this.commonLogic.updateUser_account(identifier, dc_deposit_money = BigDecimalUtil.add((BigDecimal)dc_deposit_money, (BigDecimal)order.getDc_return()), new BigDecimal(0), userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id()), XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            Tb_order o_new = new Tb_order();
                            o_new.setSd_order_id(order.getSd_order_id());
                            o_new.setSr_order_status(XcbConstantValue.ORDER_YWC);
                            o_new.setTm_order_endtime(order.getTm_order_endtime());
                            o_new.setDc_order_money(order.getDc_order_money());
                            o_new.setDc_actual_income(order.getDc_order_money());
                            o_new.setTm_modify_time(new Date());
                            o_new.setSi_modify_person(order.getSw_user_id());
                            o_new.setDc_deposit_money(dc_deposit_money);
                            result = this.orderDao.updateOrder(o_new);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                List<Tb_ordercash_stream> osList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                Tb_ordercash_stream orderCash = osList.get(0);
                                sw_ordercash_id = orderCash.getSd_ordercash_id();
                                if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type())) {
                                    result = this.createUserRecharge(order, dc_deposit_money, "Y");
                                }
                                if (result > XcbConstantValue.OPERA_INT_ZERO && !"Y".equals(order.getSr_is_steal())) {
                                    ret = this.calculationOrderIncome(identifier, order, order.getDc_order_money());
                                    result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                }
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    orderCash.setDc_actual_pay(order.getDc_order_money());
                                    result = this.orderCashStreamDao.updateOrderCashStream(orderCash);
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        sendMoney = dc_deposit_money;
                                        sendType = "DEPOSIT";
                                        isSend = true;
                                    }
                                }
                            }
                        }
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            isSuccess = true;
                        }
                    } else if (order.isSr_is_fee()) {
                        Tb_user_account userAccount;
                        dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                        dc_deposit_money = BigDecimalUtil.add((BigDecimal)order.getDc_actual_income(), (BigDecimal)dc_deposit_money);
                        result = this.commonLogic.updateUser_account(identifier, dc_deposit_money, new BigDecimal(0), userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id()), XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            Tb_order o_new = new Tb_order();
                            o_new.setSd_order_id(order.getSd_order_id());
                            o_new.setSr_order_status(XcbConstantValue.ORDER_YWC);
                            o_new.setTm_order_endtime(order.getTm_order_endtime());
                            o_new.setDc_order_money(order.getDc_order_money());
                            o_new.setDc_actual_income(order.getDc_order_money());
                            o_new.setTm_modify_time(new Date());
                            o_new.setSi_modify_person(order.getSw_user_id());
                            o_new.setDc_deposit_money(dc_deposit_money);
                            result = this.orderDao.updateOrder(o_new);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                List<Tb_ordercash_stream> osList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                Tb_ordercash_stream orderCash = osList.get(0);
                                sw_ordercash_id = orderCash.getSd_ordercash_id();
                                if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type())) {
                                    result = this.createUserRecharge(order, dc_deposit_money, "Y");
                                }
                                orderCash.setDc_actual_pay(order.getDc_order_money());
                                result = this.orderCashStreamDao.updateOrderCashStream(orderCash);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    sendMoney = dc_deposit_money;
                                    sendType = "DEPOSIT";
                                    isSend = true;
                                }
                            }
                        }
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            isSuccess = true;
                        }
                    } else {
                        Tb_user_account userAccount;
                        dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                        result = this.commonLogic.updateUser_account(identifier, dc_deposit_money, new BigDecimal(0), userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id()), XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            Tb_order o_new = new Tb_order();
                            o_new.setSd_order_id(order.getSd_order_id());
                            o_new.setSr_order_status(XcbConstantValue.ORDER_YWC);
                            o_new.setTm_order_endtime(order.getTm_order_endtime());
                            o_new.setDc_order_money(order.getDc_order_money());
                            o_new.setDc_actual_income(order.getDc_order_money());
                            o_new.setTm_modify_time(new Date());
                            o_new.setSi_modify_person(order.getSw_user_id());
                            result = this.orderDao.updateOrder(o_new);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                List<Tb_ordercash_stream> osList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                Tb_ordercash_stream orderCash = osList.get(0);
                                sw_ordercash_id = orderCash.getSd_ordercash_id();
                                if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type())) {
                                    result = this.createUserRecharge(order, dc_deposit_money, "Y");
                                }
                                orderCash.setDc_actual_pay(order.getDc_order_money());
                                result = this.orderCashStreamDao.updateOrderCashStream(orderCash);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    if (!"Y".equals(order.getSr_is_steal())) {
                                        ret = this.calculationOrderIncome(identifier, order, order.getDc_actual_income());
                                        result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                            isSuccess = true;
                                            sendMoney = dc_deposit_money;
                                            sendType = "DEPOSIT";
                                            isSend = true;
                                        }
                                    } else {
                                        isSuccess = true;
                                        sendMoney = dc_deposit_money;
                                        sendType = "DEPOSIT";
                                        isSend = true;
                                    }
                                }
                            }
                        }
                    }
                }
                if (isSuccess) {
                    if (!isExist) {
                        order = this.orderDao.findOrderById_user(order.getSd_order_id());
                        order.setSw_ordercash_id(sw_ordercash_id);
                        Tb_user user = this.userDao.findUserById(order.getSw_user_id());
                        if (user != null) {
                            if ("Y".equals(user.getSr_is_subscribe())) {
                                this.sendWXMessage(order, order.getDc_actual_income(), "FINISH");
                                if (isSend) {
                                    this.sendWXMessage(order, sendMoney, sendType);
                                }
                            } else if ("Y".equals(user.getSr_subscribe_finish())) {
                                this.sendWXAppMessage(order, order.getDc_actual_income(), "FINISH");
                                if (isSend) {
                                    this.sendWXAppMessage(order, sendMoney, sendType);
                                }
                            }
                        }
                    }
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.success"));
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.fail"));
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u8ba2\u5355\u5df2\u5b8c\u6210");
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        this.initResultMap(ret);
        return ret;
    }

    @Transactional
    Map<String, Object> finishOrderForAccount(Identifier identifier, Tb_order order, BigDecimal totalMoney) {
        int result = 0;
        boolean isSuccess = false;
        Map<String, Object> ret = new HashMap<String, Object>();
        HashMap dataMap = new HashMap();
        String table = "tb_order";
        String msg = "";
        BigDecimal sendMoney = BigDecimal.ZERO;
        String sendType = "";
        boolean isSend = false;
        boolean isExist = false;
        String sw_ordercash_id = "";
        try {
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
            if (userAccount != null) {
                Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(order.getSw_box_id());
                if (XcbConstantValue.DEVICE_BOX_STATUS_JQ.equals(deviceBox.getSr_box_status())) {
                    msg = PromptProperties.getProperty("devicebox.JQ");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                    ret.put(XcbConstantValue.MSG, msg);
                    return ret;
                }
                result = totalMoney.compareTo(BigDecimal.ZERO) == 1 ? this.commonLogic.updateUser_account(identifier, totalMoney, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_XF) : 1;
                String sr_is_reuse = order.getSr_is_reuse();
                if ("Y".equals(sr_is_reuse)) {
                    isExist = true;
                }
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    BigDecimal dc_actual_income = BigDecimalUtil.add((BigDecimal)totalMoney, (BigDecimal)order.getDc_actual_income());
                    Tb_order o_new = new Tb_order();
                    o_new.setSd_order_id(order.getSd_order_id());
                    o_new.setSr_order_status(XcbConstantValue.ORDER_YWC);
                    o_new.setTm_order_endtime(new Date());
                    o_new.setDc_order_money(order.getDc_order_money());
                    o_new.setDc_actual_income(dc_actual_income);
                    o_new.setTm_modify_time(new Date());
                    o_new.setSi_modify_person(order.getSw_user_id());
                    result = this.orderDao.updateOrder(o_new);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        String sr_type = XcbConstantValue.OPEN_DOOR_TYPE_DDJS;
                        if (!isExist) {
                            if (totalMoney.compareTo(new BigDecimal(0)) == 0) {
                                result = XcbConstantValue.OPERA_INT_ONE;
                            } else {
                                String sd_ordercash_id = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
                                result = this.createOrderCash(sd_ordercash_id, order.getSw_user_id(), order.getSd_order_id(), "", "", XcbConstantValue.ORDER_CASH_TYPE_PTYE, totalMoney, totalMoney);
                                if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                                    table = "tb_ordercash_stream";
                                    msg = PromptProperties.getProperty("order.finish.create.ordercash.fail", XcbConstantValue.ORDER_FOR_ACCOUNT, order.getSd_order_id());
                                }
                            }
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type()) || XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                                    if (!"Y".equals(order.getSr_is_steal())) {
                                        ret = this.calculationOrderIncome(identifier, order, dc_actual_income);
                                        result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                    }
                                } else {
                                    result = XcbConstantValue.OPERA_INT_ONE;
                                    if (!"Y".equals(order.getSr_is_steal())) {
                                        ret = this.calculationOrderIncome(identifier, order, dc_actual_income);
                                        result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                    }
                                }
                            }
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                if (order.getDc_deposit_money().compareTo(BigDecimal.ZERO) == 1) {
                                    Tb_user_account n_userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
                                    result = this.commonLogic.updateUser_account(identifier, order.getDc_deposit_money(), new BigDecimal(0), n_userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                                    if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type()) || XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
                                        List<Tb_ordercash_stream> osList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                        if (osList != null && osList.size() > 0) {
                                            Tb_ordercash_stream orderCash = osList.get(0);
                                            sw_ordercash_id = orderCash.getSd_ordercash_id();
                                            result = !XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type()) ? this.createUserRecharge(order, order.getDc_deposit_money(), "Y") : XcbConstantValue.OPERA_INT_ONE.intValue();
                                        }
                                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                            sendMoney = order.getDc_deposit_money();
                                            sendType = "DEPOSIT";
                                            isSend = true;
                                        }
                                    }
                                }
                            } else {
                                table = "tb_cash_stream";
                                msg = PromptProperties.getProperty("order.finish.create.cash.fail", XcbConstantValue.ORDER_FOR_ACCOUNT, order.getSd_order_id());
                            }
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                ret = this.deviceCloudService.openLock(order.getSw_user_id(), deviceBox, order.getSd_order_id(), sr_type, "");
                                result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    isSuccess = true;
                                } else {
                                    table = "openlock";
                                    String message = XcbStringUtils.getObjtoString((Object)ret.get(XcbConstantValue.MSG));
                                    msg = PromptProperties.getProperty("order.finish.openlock.fail", order.getSd_order_id(), message);
                                }
                            } else {
                                table = "tb_user_recharge";
                                msg = PromptProperties.getProperty("order.finish.recharge.fail", XcbConstantValue.ORDER_FOR_ACCOUNT, order.getSd_order_id());
                            }
                        } else if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            ret = this.deviceCloudService.openLock(order.getSw_user_id(), deviceBox, order.getSd_order_id(), sr_type, "");
                            result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                isSuccess = true;
                            } else {
                                table = "openlock";
                                String message = XcbStringUtils.getObjtoString((Object)ret.get(XcbConstantValue.MSG));
                                msg = PromptProperties.getProperty("order.finish.openlock.fail", order.getSd_order_id(), message);
                            }
                        } else {
                            table = "tb_user_recharge";
                            msg = PromptProperties.getProperty("order.finish.recharge.fail", XcbConstantValue.ORDER_FOR_ACCOUNT, order.getSd_order_id());
                        }
                    } else {
                        table = "tb_order";
                        msg = PromptProperties.getProperty("order.finish.update.fail", XcbConstantValue.ORDER_FOR_ACCOUNT, order.getSd_order_id());
                    }
                } else {
                    table = "tb_user_account";
                    msg = PromptProperties.getProperty("userAccount.update.fail", XcbConstantValue.ORDER_FOR_ACCOUNT, order.getSd_order_id());
                }
            } else {
                table = "tb_user_account";
                msg = PromptProperties.getProperty("userAccount.find.fail");
            }
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_FOR_ACCOUNT + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            msg = PromptProperties.getProperty("order.finish.fail", XcbConstantValue.ORDER_FOR_ACCOUNT, order.getSd_order_id(), "\u7cfb\u7edf\u5f02\u5e38");
        }
        if (isSuccess) {
            if (!isExist) {
                order = this.orderDao.findOrderById_user(order.getSd_order_id());
                order.setSw_ordercash_id(sw_ordercash_id);
                Tb_user user = this.userDao.findUserById(order.getSw_user_id());
                if (user != null) {
                    if ("Y".equals(user.getSr_is_subscribe())) {
                        this.sendWXMessage(order, order.getDc_actual_income(), "FINISH");
                        if (isSend) {
                            this.sendWXMessage(order, sendMoney, sendType);
                        }
                    } else if ("Y".equals(user.getSr_subscribe_finish())) {
                        this.sendWXAppMessage(order, order.getDc_actual_income(), "FINISH");
                        if (isSend) {
                            this.sendWXAppMessage(order, sendMoney, sendType);
                        }
                    }
                }
            }
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.DATA, dataMap);
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, "\u7cfb\u7edf\u5f02\u5e38");
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_USER, XcbConstantValue.ORDER_FOR_ACCOUNT, order.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "CREATE", msg, "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
            operationLogs.setSr_operate_table(table);
            this.operationLogServiceImpl.createOperaLog(operationLogs);
        }
        this.initResultMap(ret);
        return ret;
    }

    @Transactional
    Map<String, Object> temporaryOrderForAccount(Identifier identifier, Tb_order order, BigDecimal totalMoney) {
        int result = 0;
        boolean isSuccess = false;
        Map<String, Object> ret = new HashMap<String, Object>();
        HashMap dataMap = new HashMap();
        String table = "tb_order";
        String msg = "";
        try {
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
            if (userAccount != null) {
                Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(order.getSw_box_id());
                if (XcbConstantValue.DEVICE_BOX_STATUS_JQ.equals(deviceBox.getSr_box_status())) {
                    msg = PromptProperties.getProperty("devicebox.JQ");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                    ret.put(XcbConstantValue.MSG, msg);
                    return ret;
                }
                result = this.commonLogic.updateUser_account(identifier, totalMoney, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_XF);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    BigDecimal dc_actual_income = BigDecimalUtil.add((BigDecimal)totalMoney, (BigDecimal)order.getDc_actual_income());
                    Tb_order o_new = new Tb_order();
                    o_new.setSd_order_id(order.getSd_order_id());
                    o_new.setDc_actual_income(dc_actual_income);
                    o_new.setDc_order_money(dc_actual_income);
                    o_new.setTm_modify_time(new Date());
                    o_new.setSi_modify_person(order.getSw_user_id());
                    result = this.orderDao.updateOrder(o_new);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        String sr_type = XcbConstantValue.OPEN_DOOR_TYPE_DDXF;
                        if (totalMoney.compareTo(new BigDecimal(0)) == 0) {
                            sr_type = XcbConstantValue.OPEN_DOOR_TYPE_KMCG;
                            result = XcbConstantValue.OPERA_INT_ONE;
                        } else {
                            String sd_ordercash_id = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
                            result = this.createOrderCash(sd_ordercash_id, order.getSw_user_id(), order.getSd_order_id(), "", "", XcbConstantValue.ORDER_CASH_TYPE_PTYE, totalMoney, totalMoney);
                        }
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            ret = this.deviceCloudService.openLock(order.getSw_user_id(), deviceBox, order.getSd_order_id(), sr_type, "");
                            result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                isSuccess = true;
                            } else {
                                table = "openlock";
                                String message = XcbStringUtils.getObjtoString((Object)ret.get(XcbConstantValue.MSG));
                                msg = PromptProperties.getProperty("order.temp.finish.openlock.fail", order.getSd_order_id(), message);
                            }
                        } else {
                            table = "tb_ordercash_stream";
                            msg = PromptProperties.getProperty("order.temp.finish.create.ordercash.fail", XcbConstantValue.ORDER_TEMPORARY_FOR_ACCOUNT, order.getSd_order_id());
                        }
                    } else {
                        table = "tb_order";
                        msg = PromptProperties.getProperty("order.temp.finish.update.fail", XcbConstantValue.ORDER_TEMPORARY_FOR_ACCOUNT, order.getSd_order_id());
                    }
                } else {
                    table = "tb_user_account";
                    msg = PromptProperties.getProperty("userAccount.update.fail", XcbConstantValue.ORDER_TEMPORARY_FOR_ACCOUNT, order.getSd_order_id());
                }
            } else {
                table = "tb_user_account";
                msg = PromptProperties.getProperty("userAccount.find.fail");
            }
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_TEMPORARY_FOR_ACCOUNT + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            msg = PromptProperties.getProperty("order.temp.finish.fail", XcbConstantValue.ORDER_TEMPORARY_FOR_ACCOUNT, order.getSd_order_id());
        }
        if (isSuccess) {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.DATA, dataMap);
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, msg);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_USER, XcbConstantValue.ORDER_TEMPORARY_FOR_ACCOUNT, order.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "CREATE", msg, "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
            operationLogs.setSr_operate_table(table);
            this.operationLogServiceImpl.createOperaLog(operationLogs);
        }
        this.initResultMap(ret);
        return ret;
    }

    @Transactional
    Map<String, Object> finishOrderForRecharge(Identifier identifier, Tb_order order, BigDecimal totalMoney) {
        int result = 0;
        boolean isSuccess = false;
        Map<String, Object> ret = new HashMap<String, Object>();
        HashMap dataMap = new HashMap();
        String msg = "";
        String table = "tb_order";
        BigDecimal sendMoney = BigDecimal.ZERO;
        String sendType = "";
        boolean isSend = false;
        String sw_ordercash_id = "";
        try {
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
            if (userAccount != null) {
                Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(order.getSw_box_id());
                if (XcbConstantValue.DEVICE_BOX_STATUS_JQ.equals(deviceBox.getSr_box_status())) {
                    msg = PromptProperties.getProperty("devicebox.JQ");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                    ret.put(XcbConstantValue.MSG, msg);
                    return ret;
                }
                BigDecimal dc_deposit_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_money());
                result = this.commonLogic.updateUser_account(identifier, dc_deposit_money = BigDecimalUtil.add((BigDecimal)totalMoney, (BigDecimal)dc_deposit_money), new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Tb_order o_new = new Tb_order();
                    o_new.setSd_order_id(order.getSd_order_id());
                    o_new.setSr_order_status(XcbConstantValue.ORDER_YWC);
                    o_new.setTm_order_endtime(order.getTm_order_endtime());
                    o_new.setDc_order_money(order.getDc_order_money());
                    o_new.setDc_actual_income(order.getDc_order_money());
                    o_new.setTm_modify_time(new Date());
                    o_new.setSi_modify_person(order.getSw_user_id());
                    o_new.setDc_deposit_money(dc_deposit_money);
                    result = this.orderDao.updateOrder(o_new);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        if (dc_deposit_money.compareTo(new BigDecimal(0)) == 1) {
                            List<Tb_ordercash_stream> osList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                            Tb_ordercash_stream orderCash = osList.get(0);
                            sw_ordercash_id = orderCash.getSd_ordercash_id();
                            result = !XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCash.getSr_cash_type()) ? this.createUserRecharge(order, dc_deposit_money, "Y") : XcbConstantValue.OPERA_INT_ONE.intValue();
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                                    if (!"Y".equals(order.getSr_is_steal())) {
                                        ret = this.calculationOrderIncome(identifier, order, order.getDc_order_money());
                                        result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                    }
                                } else {
                                    result = XcbConstantValue.OPERA_INT_ONE;
                                    if (!"Y".equals(order.getSr_is_steal())) {
                                        ret = this.calculationOrderIncome(identifier, order, order.getDc_order_money());
                                        result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                    }
                                }
                            }
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                orderCash.setDc_actual_pay(order.getDc_order_money());
                                result = this.orderCashStreamDao.updateOrderCashStream(orderCash);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    sendMoney = dc_deposit_money;
                                    sendType = "DEPOSIT";
                                    isSend = true;
                                }
                            }
                        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                            if (!"Y".equals(order.getSr_is_steal())) {
                                ret = this.calculationOrderIncome(identifier, order, order.getDc_order_money());
                                result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                            } else {
                                result = XcbConstantValue.OPERA_INT_ONE;
                            }
                        } else {
                            result = XcbConstantValue.OPERA_INT_ONE;
                            if (!"Y".equals(order.getSr_is_steal())) {
                                ret = this.calculationOrderIncome(identifier, order, order.getDc_order_money());
                                result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                            }
                        }
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            ret = this.deviceCloudService.openLock(order.getSw_user_id(), deviceBox, order.getSd_order_id(), XcbConstantValue.OPEN_DOOR_TYPE_DDJS, "");
                            result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                isSuccess = true;
                            } else {
                                table = "openlock";
                                String message = XcbStringUtils.getObjtoString((Object)ret.get(XcbConstantValue.MSG));
                                msg = PromptProperties.getProperty("order.finish.openlock.fail", order.getSd_order_id(), message);
                            }
                        } else {
                            table = "tb_user_recharge";
                            msg = PromptProperties.getProperty("order.finish.recharge.fail", XcbConstantValue.ORDER_FOR_RECHARGE, order.getSd_order_id());
                        }
                    } else {
                        table = "tb_order";
                        msg = PromptProperties.getProperty("order.finish.update.fail", XcbConstantValue.ORDER_FOR_RECHARGE, order.getSd_order_id());
                    }
                } else {
                    table = "tb_user_account";
                    msg = PromptProperties.getProperty("userAccount.update.fail", XcbConstantValue.ORDER_FOR_RECHARGE, order.getSd_order_id());
                }
            } else {
                table = "tb_user_account";
                msg = PromptProperties.getProperty("userAccount.find.fail");
            }
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_FOR_RECHARGE + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            msg = PromptProperties.getProperty("order.finish.fail", XcbConstantValue.ORDER_FOR_RECHARGE, order.getSd_order_id());
        }
        if (isSuccess) {
            order = this.orderDao.findOrderById_user(order.getSd_order_id());
            order.setSw_ordercash_id(sw_ordercash_id);
            Tb_user user = this.userDao.findUserById(order.getSw_user_id());
            if (user != null) {
                if ("Y".equals(user.getSr_is_subscribe())) {
                    this.sendWXMessage(order, order.getDc_actual_income(), "FINISH");
                    if (isSend) {
                        this.sendWXMessage(order, sendMoney, sendType);
                    }
                } else if ("Y".equals(user.getSr_subscribe_finish())) {
                    this.sendWXAppMessage(order, order.getDc_actual_income(), "FINISH");
                    if (isSend) {
                        this.sendWXAppMessage(order, sendMoney, sendType);
                    }
                }
            }
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.DATA, dataMap);
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, msg);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_USER, XcbConstantValue.ORDER_FOR_RECHARGE, order.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "CREATE", msg, "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
            operationLogs.setSr_operate_table(table);
            this.operationLogServiceImpl.createOperaLog(operationLogs);
        }
        this.initResultMap(ret);
        return ret;
    }

    public Map<String, Object> findOrderByParam_agent(Identifier identifier, Tb_order order, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_order> orders = null;
            int totalCount = 0;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(order.getSw_agent_id());
            if (adminAgent != null) {
                if ("1".equals(adminAgent.getSr_role())) {
                    List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                    String[] subArr = new String[subList.size()];
                    subList.toArray(subArr);
                    order.setAgentArr(subArr);
                    order.setSw_agent_id(null);
                    orders = this.orderDao.findShowOrderByParam_agent(order, page);
                    totalCount = this.orderDao.findShowCountByParam_agent(order);
                } else if ("2".equals(adminAgent.getSr_role())) {
                    order.setSr_is_steal("N");
                    orders = this.orderDao.findOrderByParam_agent(order, page);
                    totalCount = this.orderDao.findCountByParam_agent(order);
                } else if ("3".equals(adminAgent.getSr_role())) {
                    order.setSr_is_steal("N");
                    List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                    if (netList.size() > 0) {
                        String[] netArr = netList.get(0).split(",");
                        order.setNetArr(netArr);
                        orders = this.orderDao.findOrderByNetArr_agent(order, page);
                        totalCount = this.orderDao.findCountByNetArr_agent(order);
                    }
                } else if ("4".equals(adminAgent.getSr_role())) {
                    order.setSr_is_steal("N");
                    List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                    if (netList.size() > 0) {
                        String[] netArr = netList.get(0).split(",");
                        order.setNetArr(netArr);
                        orders = this.orderDao.findOrderByNetArr_agent(order, page);
                        totalCount = this.orderDao.findCountByNetArr_agent(order);
                    }
                }
                page.setTotal(totalCount);
                dataMap.put("page", page);
                dataMap.put("orders", orders);
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u67e5\u65e0\u5546\u5bb6");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYPARAM, PromptProperties.getProperty("order.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findOrderForExcel_agent(Identifier identifier, Tb_order order, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_order> orders = null;
            int totalCount = 0;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(order.getSw_agent_id());
            if (adminAgent != null) {
                if ("1".equals(adminAgent.getSr_role())) {
                    List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                    String[] subArr = new String[subList.size()];
                    subList.toArray(subArr);
                    order.setAgentArr(subArr);
                    order.setSw_agent_id(null);
                    orders = this.orderDao.findShowOrderByParam_agent(order, page);
                    totalCount = this.orderDao.findShowCountByParam_agent(order);
                } else if ("2".equals(adminAgent.getSr_role())) {
                    order.setSr_is_steal("N");
                    orders = this.orderDao.findOrderByParam_agent(order, page);
                    totalCount = this.orderDao.findCountByParam_agent(order);
                } else if ("3".equals(adminAgent.getSr_role())) {
                    order.setSr_is_steal("N");
                    List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                    if (netList.size() > 0) {
                        String[] netArr = netList.get(0).split(",");
                        order.setNetArr(netArr);
                        orders = this.orderDao.findOrderByNetArr_agent(order, page);
                        totalCount = this.orderDao.findCountByNetArr_agent(order);
                    }
                } else if ("4".equals(adminAgent.getSr_role())) {
                    order.setSr_is_steal("N");
                    List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                    if (netList.size() > 0) {
                        String[] netArr = netList.get(0).split(",");
                        order.setNetArr(netArr);
                        orders = this.orderDao.findOrderByNetArr_agent(order, page);
                        totalCount = this.orderDao.findCountByNetArr_agent(order);
                    }
                }
                page.setTotal(totalCount);
                dataMap.put("page", page);
                dataMap.put("orders", orders);
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u67e5\u65e0\u5546\u5bb6");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_FOREXCEL_AGENT, PromptProperties.getProperty("order.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findOrderById_agent(Identifier identifier, String sd_order_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_order order = this.orderDao.findOrderById_agent(sd_order_id);
            Tb_order_income income = this.orderInComeDao.findIncomeByOrderId(sd_order_id);
            order.setIncome(income);
            ret_method.put(XcbConstantValue.DATA, order);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYID, PromptProperties.getProperty("order.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findOrderRecordById_cpy(Identifier identifier, String sd_order_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_opendoor_record>> dataMap = new HashMap<String, List<Tb_opendoor_record>>();
        try {
            List<Tb_opendoor_record> recordList = this.openDoorRecordDao.findOpenDoorRecordByOrder(sd_order_id);
            dataMap.put("recordList", recordList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_RECORD_BYID_CPY, PromptProperties.getProperty("opendoor.record.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    public Map<String, Object> updateOrder(Identifier identifier, Tb_order order) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        try {
            result = this.orderDao.updateOrder_agent(order);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.success"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.update.fail"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        return ret;
    }

    @Transactional
    public Map<String, Object> updateOrderAd(Identifier identifier, Tb_order order) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            List<String> idList = this.orderDao.findAdOrderByTask(order.getSw_agent_id());
            if (idList != null && idList.size() > 0) {
                String[] idArr = idList.toArray(new String[idList.size()]);
                this.orderDao.updateAdMoneyByIdArr(order.getDc_ad_money(), idArr);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        return ret;
    }

    public Map<String, Object> findOrderByParam_cpy(Identifier identifier, Tb_order order, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            CompletableFuture<List> orderListFuture = CompletableFuture.supplyAsync(() -> this.orderDao.findOrderByParam_cpy(order, page));
            CompletableFuture<Integer> totalCountFuture = CompletableFuture.supplyAsync(() -> this.orderDao.findCountByParam_cpy(order));
            int totalCount = totalCountFuture.get();
            List orders = orderListFuture.get();
            for (int i = 0; i < orders.size(); ++i) {
                Tb_order o = (Tb_order)orders.get(i);
                if (XcbConstantValue.ORDER_CASH_TYPE_WX.equals(o.getSr_cash_type())) {
                    o.setSr_is_show_deposit_refund(true);
                    continue;
                }
                o.setSr_is_show_deposit_refund(false);
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("orders", orders);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYPARAM, PromptProperties.getProperty("order.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findOrderForExcel(Identifier identifier, Tb_order order, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_order> orders = this.orderDao.findOrderByParam_cpy(order, page);
            int totalCount = this.orderDao.findCountByParam_cpy(order);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("orders", orders);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_FOREXCEL, PromptProperties.getProperty("order.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    Map<String, Object> tkNotify(Identifier identifier, String sd_ordercash_id, String sr_refund_money, String sd_cash_id) {
        Tb_user user;
        Map<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        String table = "";
        String error_log = "";
        Tb_order order = new Tb_order();
        BigDecimal dc_refund_money = BigDecimal.ZERO;
        Tb_ordercash_stream orderCash = this.orderCashStreamDao.findOrderCashStreamById(sd_ordercash_id);
        try {
            if (orderCash != null) {
                order = this.orderDao.findOrderById_agent(orderCash.getSw_order_id());
                user = this.userDao.findUserById(order.getSw_user_id());
                Tb_wx_pay_info pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
                BigDecimal dc_actual_income = orderCash.getDc_order_money();
                BigDecimal total_refund_money = orderCash.getDc_actual_pay();
                dc_refund_money = orderCash.getDc_actual_pay();
                String sr_order_status = XcbConstantValue.ORDER_CASH_YTK;
                if (!XcbStringUtils.isNullOrBlank((Object)sr_refund_money)) {
                    BigDecimal dc_old_refund_money;
                    dc_refund_money = XcbStringUtils.getObjToBigDecimal((Object)sr_refund_money);
                    total_refund_money = BigDecimalUtil.add((BigDecimal)dc_refund_money, (BigDecimal)(dc_old_refund_money = XcbStringUtils.getObjToBigDecimal((Object)orderCash.getDc_refund_money())));
                    sr_order_status = total_refund_money.compareTo(orderCash.getDc_actual_pay()) == 0 ? XcbConstantValue.ORDER_CASH_YTK : XcbConstantValue.ORDER_CASH_BFTK;
                }
                Tb_order n_order = new Tb_order();
                n_order.setSd_order_id(order.getSd_order_id());
                BigDecimal refund_money = order.getDc_refund_money();
                refund_money = BigDecimalUtil.add((BigDecimal)refund_money, (BigDecimal)dc_refund_money);
                if (refund_money.compareTo(order.getDc_actual_income()) == 0) {
                    n_order.setSr_order_status(XcbConstantValue.ORDER_YTK);
                } else {
                    n_order.setSr_order_status(XcbConstantValue.ORDER_BFTK);
                }
                n_order.setDc_refund_money(refund_money);
                result = this.orderDao.updateOrder(n_order);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Tb_ordercash_stream newOrderCash = new Tb_ordercash_stream();
                    newOrderCash.setSd_ordercash_id(sd_ordercash_id);
                    newOrderCash.setSr_order_status(sr_order_status);
                    newOrderCash.setDc_refund_money(total_refund_money);
                    result = this.orderCashStreamDao.updateOrderCashStream(newOrderCash);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        if (!"Y".equals(order.getSr_is_steal())) {
                            BigDecimal incomeMoney = BigDecimalUtil.sub((BigDecimal)order.getDc_actual_income(), (BigDecimal)refund_money);
                            Tb_order_income income = this.orderInComeDao.findIncomeByOrderId(order.getSd_order_id());
                            ret_method = this.tkCalculationIncome(orderCash, sd_cash_id, income, incomeMoney, error_log);
                            result = XcbStringUtils.getObjtoint((Object)ret_method.get(XcbConstantValue.STATUS));
                            error_log = XcbStringUtils.getObjtoString((Object)ret_method.get(XcbConstantValue.MSG));
                        }
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            if (XcbConstantValue.ORDER_CASH_TYPE_WX.equals(orderCash.getSr_cash_type())) {
                                Map<Object, Object> rtnMap = new HashMap();
                                if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                                    int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund_money)));
                                    int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_actual_income)));
                                    pay_info.setSr_refund_desc("\u5546\u5bb6\u9000\u6b3e");
                                    rtnMap = this.wxAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                                    String refund_fee = XcbStringUtils.getObjtoString((Object)dc_refund_money);
                                    String total_fee = XcbStringUtils.getObjtoString((Object)dc_actual_income);
                                    pay_info.setSr_refund_desc("\u5546\u5bb6\u9000\u6b3e");
                                    rtnMap = this.wxSdjAPICommon.xcrefund(orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                } else {
                                    int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund_money)));
                                    int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_actual_income)));
                                    pay_info.setSr_refund_desc("\u5546\u5bb6\u9000\u6b3e");
                                    rtnMap = this.wxSpAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                }
                                result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    isSuccess = true;
                                } else {
                                    table = "wechatRefundV3";
                                    error_log = XcbStringUtils.getObjtoString((Object)rtnMap.get(XcbConstantValue.MSG));
                                    this.log.error(error_log);
                                }
                            } else if (XcbConstantValue.ORDER_CASH_TYPE_ZFB.equals(orderCash.getSr_cash_type())) {
                                // empty if block
                            }
                        }
                    } else {
                        table = "tb_ordercash_stream";
                        error_log = PromptProperties.getProperty("order.tknotify.error.updateorder", XcbConstantValue.ORDER_TKNOTIFY, sd_ordercash_id, orderCash.getSw_agent_id());
                        this.log.error(error_log);
                    }
                } else {
                    table = "tb_order";
                    error_log = PromptProperties.getProperty("order.tknotify.error.updateorder", XcbConstantValue.ORDER_TKNOTIFY, orderCash.getSw_order_id(), orderCash.getSw_agent_id());
                    this.log.error(error_log);
                }
            } else {
                isSuccess = true;
            }
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_TKNOTIFY + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            isSuccess = false;
            error_log = "\u7cfb\u7edf\u5f02\u5e38";
        }
        if (isSuccess) {
            user = this.userDao.findUserById(order.getSw_user_id());
            if (user != null) {
                if ("Y".equals(user.getSr_is_subscribe())) {
                    this.sendWXMessage(order, XcbStringUtils.getObjToBigDecimal((Object)dc_refund_money), "REFUND");
                } else if ("Y".equals(user.getSr_subscribe_refund())) {
                    this.sendWXAppMessage(order, XcbStringUtils.getObjToBigDecimal((Object)dc_refund_money), "REFUND");
                }
            }
            error_log = PromptProperties.getProperty("order.tknotify.success");
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, error_log);
        } else {
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, error_log);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, XcbConstantValue.ORDER_TKNOTIFY, identifier.getUserId(), XcbConstantValue.OPERATION_FAIL, "CREATE", "\u8ba2\u5355\u9000\u6b3e\u56de\u8c03\uff08\u7528\u6237\u7aef\uff09:\u94b1\u5df2\u7ecf\u9000\u4e86\uff0c\u4f46\u6570\u636e\u4fee\u6539\u9519\u8bef " + error_log, identifier.getUrl(), identifier.getIp());
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(String.valueOf(orderCash.getSw_user_id()));
            operationLogs.setSr_operate_table(table);
            this.operationLogServiceImpl.createOperaLog(operationLogs);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> tkCalculationIncome(Tb_ordercash_stream orderCash, String sd_cash_id, Tb_order_income income, BigDecimal incomeMoney, String error_log) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        try {
            BigDecimal cpybonus = BigDecimalUtil.div((BigDecimal)income.getDc_company_rate(), (BigDecimal)new BigDecimal(100));
            BigDecimal agentbonus = BigDecimalUtil.div((BigDecimal)income.getDc_agent_rate(), (BigDecimal)new BigDecimal(100));
            BigDecimal shopbonus = BigDecimalUtil.div((BigDecimal)income.getDc_shop_rate(), (BigDecimal)new BigDecimal(100));
            BigDecimal oldcpymoney = income.getDc_company_money();
            BigDecimal oldagentmoney = income.getDc_agent_money();
            BigDecimal oldshopmoney = income.getDc_shop_money();
            BigDecimal cpymoney = BigDecimalUtil.mul((BigDecimal)incomeMoney, (BigDecimal)cpybonus);
            BigDecimal agentmoney = BigDecimalUtil.mul((BigDecimal)incomeMoney, (BigDecimal)agentbonus);
            BigDecimal shopmoney = BigDecimalUtil.sub((BigDecimal)incomeMoney, (BigDecimal)BigDecimalUtil.add((BigDecimal)cpymoney, (BigDecimal)agentmoney));
            BigDecimal cpytkmoney = BigDecimalUtil.sub((BigDecimal)oldcpymoney, (BigDecimal)cpymoney);
            BigDecimal agenttkmoney = BigDecimalUtil.sub((BigDecimal)oldagentmoney, (BigDecimal)agentmoney);
            BigDecimal shoptkmoney = BigDecimalUtil.sub((BigDecimal)oldshopmoney, (BigDecimal)shopmoney);
            String sd_ordercash_id = orderCash.getSd_ordercash_id();
            String sr_cashflow_item = XcbConstantValue.CASH_STREAM_JCGDDTK;
            String payType = XcbConstantValue.CASH_STREAM_YFK;
            result = !XcbStringUtils.isNullOrBlank((Object)income.getSw_agent_id()) ? (agenttkmoney.compareTo(BigDecimal.ZERO) == 1 ? this.createCashStream(orderCash.getSw_user_id(), income.getSw_agent_id(), orderCash.getSw_order_id(), CommonFunction.getVoucherNum((String)CommonFunction.zj_id), sr_cashflow_item, payType, agenttkmoney, "", XcbConstantValue.CASH_STREAM_WFH) : 1) : 1;
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                result = shoptkmoney.compareTo(BigDecimal.ZERO) == 1 ? this.createCashStream(orderCash.getSw_user_id(), income.getSw_shop_id(), orderCash.getSw_order_id(), sd_cash_id, sr_cashflow_item, payType, shoptkmoney, "", XcbConstantValue.CASH_STREAM_WFH) : 1;
                income.setDc_company_money(cpymoney);
                income.setDc_agent_money(agentmoney);
                income.setDc_shop_money(shopmoney);
                income.setSr_status("2");
                result = this.orderInComeDao.updateById(income);
                if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                    error_log = PromptProperties.getProperty("order.tknotify.error.updateincome", XcbConstantValue.ORDER_TKNOTIFY, sd_ordercash_id, income.getSw_shop_id());
                    this.log.error(error_log);
                }
            }
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_TKNOTIFY + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            throw new BusinessException(XcbConstantValue.ORDER_TKNOTIFY, "\u9000\u6b3e\u5f02\u5e38");
        }
        ret.put(XcbConstantValue.STATUS, XcbStringUtils.getObjtoString((Object)result));
        ret.put(XcbConstantValue.MSG, error_log);
        return ret;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Transactional
    Map<String, Object> autoTkNotify(Identifier identifier, String sd_ordercash_id, String sr_refund_money, String sd_cash_id) {
        Tb_user user;
        Tb_ordercash_stream orderCash;
        BigDecimal dc_refund_money;
        Tb_order order;
        String error_log;
        String table;
        boolean isSuccess;
        HashMap<String, Object> ret_method;
        block20: {
            ret_method = new HashMap<String, Object>();
            int result = 0;
            isSuccess = false;
            table = "";
            error_log = "";
            order = new Tb_order();
            dc_refund_money = XcbStringUtils.getObjToBigDecimal((Object)sr_refund_money);
            orderCash = this.orderCashStreamDao.findOrderCashStreamById(sd_ordercash_id);
            try {
                if (orderCash != null) {
                    order = this.orderDao.findOrderById_agent(orderCash.getSw_order_id());
                    user = this.userDao.findUserById(orderCash.getSw_user_id());
                    Tb_wx_pay_info pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
                    Tb_order n_order = new Tb_order();
                    n_order.setSd_order_id(order.getSd_order_id());
                    if (!XcbStringUtils.isNullOrBlank((Object)order.getDc_deposit_money())) {
                        n_order.setDc_deposit_refund(order.getDc_deposit_money());
                    }
                    n_order.setDc_refund_money(order.getDc_actual_income());
                    n_order.setSr_order_status(XcbConstantValue.ORDER_KMSB);
                    n_order.setTm_order_endtime(new Date());
                    result = this.orderDao.updateOrder(n_order);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, XcbConstantValue.ORDER_TKNOTIFY, identifier.getUserId(), XcbConstantValue.OPERATION_FAIL, "CREATE", "\u8ba2\u5355\u9000\u6b3e\u56de\u8c03\uff08\u7528\u6237\u7aef\uff09:\u94b1\u5df2\u7ecf\u9000\u4e86\uff0c\u4fee\u6539\u8ba2\u5355\u5f02\u5e38", identifier.getUrl(), identifier.getIp());
                        operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                        operationLogs.setSr_operate_primarykey(order.getSd_order_id());
                        operationLogs.setSr_operate_table(table);
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                    Tb_ordercash_stream n_orderCash = new Tb_ordercash_stream();
                    n_orderCash.setSd_ordercash_id(sd_ordercash_id);
                    n_orderCash.setDc_refund_money(order.getDc_actual_income());
                    n_orderCash.setSr_order_status(XcbConstantValue.ORDER_CASH_KMSB);
                    result = this.orderCashStreamDao.updateOrderCashStream(n_orderCash);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, XcbConstantValue.ORDER_TKNOTIFY, identifier.getUserId(), XcbConstantValue.OPERATION_FAIL, "CREATE", "\u8ba2\u5355\u9000\u6b3e\u56de\u8c03\uff08\u7528\u6237\u7aef\uff09:\u94b1\u5df2\u7ecf\u9000\u4e86\uff0c\u4fee\u6539\u7ed3\u7b97\u6d41\u6c34\u5f02\u5e38", identifier.getUrl(), identifier.getIp());
                        operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                        operationLogs.setSr_operate_primarykey(String.valueOf(orderCash.getSd_ordercash_id()));
                        operationLogs.setSr_operate_table(table);
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                    if (XcbConstantValue.ORDER_CASH_TYPE_WX.equals(orderCash.getSr_cash_type())) {
                        Map<Object, Object> rtnMap = new HashMap();
                        if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                            int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund_money)));
                            int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund_money)));
                            pay_info.setSr_refund_desc("\u5546\u5bb6\u9000\u6b3e");
                            rtnMap = this.wxAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                        } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                            String refund_fee = XcbStringUtils.getObjtoString((Object)dc_refund_money);
                            String total_fee = XcbStringUtils.getObjtoString((Object)dc_refund_money);
                            pay_info.setSr_refund_desc("\u5546\u5bb6\u9000\u6b3e");
                            rtnMap = this.wxSdjAPICommon.xcrefund(orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                        } else {
                            int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund_money)));
                            int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund_money)));
                            pay_info.setSr_refund_desc("\u5546\u5bb6\u9000\u6b3e");
                            rtnMap = this.wxSpAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                        }
                        result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            isSuccess = true;
                            break block20;
                        } else {
                            table = "wechatRefundV3";
                            error_log = XcbStringUtils.getObjtoString((Object)rtnMap.get(XcbConstantValue.MSG));
                            this.log.error(error_log);
                        }
                        break block20;
                    }
                    if (!XcbConstantValue.ORDER_CASH_TYPE_ZFB.equals(orderCash.getSr_cash_type())) {
                        // empty if block
                    }
                    break block20;
                }
                isSuccess = true;
            }
            catch (Exception e) {
                this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_AUTO_TKNOTIFY + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
                isSuccess = false;
                error_log = e.getMessage();
            }
        }
        if (isSuccess) {
            if (!XcbStringUtils.isNullOrBlank((Object)order.getSw_user_id()) && (user = this.userDao.findUserById(order.getSw_user_id())) != null) {
                if ("Y".equals(user.getSr_is_subscribe())) {
                    this.sendWXMessage(order, XcbStringUtils.getObjToBigDecimal((Object)dc_refund_money), "REFUND");
                } else if ("Y".equals(user.getSr_subscribe_refund())) {
                    this.sendWXAppMessage(order, XcbStringUtils.getObjToBigDecimal((Object)dc_refund_money), "REFUND");
                }
            }
            error_log = PromptProperties.getProperty("order.tknotify.success");
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, error_log);
        } else {
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, error_log);
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, XcbConstantValue.ORDER_AUTO_TKNOTIFY, identifier.getUserId(), XcbConstantValue.OPERATION_FAIL, "CREATE", "\u8ba2\u5355\u9000\u6b3e\u56de\u8c03\uff08\u7528\u6237\u7aef\uff09:\u94b1\u5df2\u7ecf\u9000\u4e86\uff0c\u4f46\u6570\u636e\u4fee\u6539\u9519\u8bef " + error_log, identifier.getUrl(), identifier.getIp());
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(String.valueOf(orderCash.getSw_user_id()));
            operationLogs.setSr_operate_table(table);
            this.operationLogServiceImpl.createOperaLog(operationLogs);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> checkPayNotifyInfo(String sd_ordercash_id, String sw_order_id) {
        this.log.info("###############\u5fae\u4fe1\u652f\u4ed8\u56de\u8c03\u68c0\u67e5\u5f00\u59cb###############");
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        boolean flag = true;
        String msg = "";
        String sign_type = sw_order_id.substring(0, 2);
        String code = XcbConstantValue.OPERA_FAIL;
        if (CommonFunction.dd_id.equals(sign_type)) {
            Tb_order order = this.orderDao.findOrderById_user(sw_order_id);
            if (order != null) {
                Tb_ordercash_stream orderCash = this.orderCashStreamDao.findOrderCashStreamById(sd_ordercash_id);
                if (orderCash != null) {
                    if (XcbConstantValue.ORDER_CASH_ZFCG.equals(orderCash.getSr_order_status())) {
                        flag = false;
                        msg = PromptProperties.getProperty("order.check.paynotify.warn", sw_order_id);
                        this.log.info(msg);
                        code = XcbConstantValue.OPERA_WARN;
                    } else {
                        flag = false;
                        msg = PromptProperties.getProperty("order.check.paynotify.fail", sw_order_id, orderCash.getSr_order_status());
                        this.log.info(msg);
                    }
                } else {
                    flag = true;
                }
            } else {
                Tb_ordercash_stream orderCash = this.orderCashStreamDao.findOrderCashStreamById(sd_ordercash_id);
                if (orderCash != null) {
                    flag = false;
                    msg = PromptProperties.getProperty("order.check.paynotify.error", sw_order_id);
                    this.log.info(msg);
                } else {
                    flag = true;
                }
            }
        }
        if (flag) {
            this.log.info("###############\u5fae\u4fe1\u652f\u4ed8\u56de\u8c03\u68c0\u67e5\u901a\u8fc7###############");
            this.log.info("###############\u8ba2\u5355\u53f7:" + sw_order_id + "###############");
            this.log.info("###############\u8ba2\u5355\u7ed3\u7b97\u6d41\u6c34\u53f7:" + sd_ordercash_id + "###############");
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.check.paynotify.success", sw_order_id));
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        } else {
            ret_method.put(XcbConstantValue.MSG, msg);
            ret_method.put(XcbConstantValue.STATUS, code);
        }
        this.initResultMap(ret_method);
        this.log.info("###############\u5fae\u4fe1\u652f\u4ed8\u56de\u8c03\u68c0\u67e5\u7ed3\u675f###############");
        return ret_method;
    }

    private Map<String, Object> findOrderByParam_agentmb(Identifier identifier, Tb_order order, String dateRange, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(order.getSw_agent_id());
            if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_iphone_num())) {
                if ("Y".equals(adminAgent.getSr_is_show_steal())) {
                    order.setSr_is_steal("");
                } else {
                    order.setSr_is_steal("N");
                }
            } else {
                order.setSr_is_steal("N");
            }
            if (XcbStringUtils.isNullOrBlank((Object)dateRange) || "today".equals(dateRange)) {
                order.setSr_create_time_start(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                order.setSr_create_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else if ("yesterday".equals(dateRange)) {
                order.setSr_create_time(XcbDateUtil.getBeforeDay((Date)new Date(), (int)1, (String)"yyyy-MM-dd"));
            } else if ("week".equals(dateRange)) {
                order.setSr_create_time_start(XcbDateUtil.getBeforeDay((Date)new Date(), (int)7, (String)"yyyy-MM-dd"));
                order.setSr_create_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else if (!"month".equals(dateRange)) {
                order.setSr_create_time_start(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                order.setSr_create_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            }
            List<Tb_order> orders = null;
            int totalCount = 0;
            if (adminAgent != null) {
                List<String> netList;
                if ("1".equals(adminAgent.getSr_role())) {
                    List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                    String[] subArr = new String[subList.size()];
                    subList.toArray(subArr);
                    order.setAgentArr(subArr);
                    order.setSw_agent_id(null);
                    orders = this.orderDao.findShowOrderByParam_agent(order, page);
                    totalCount = this.orderDao.findShowCountByParam_agent(order);
                } else if ("2".equals(adminAgent.getSr_role())) {
                    orders = this.orderDao.findOrderByParam_agent(order, page);
                    totalCount = this.orderDao.findCountByParam_agent(order);
                } else if ("3".equals(adminAgent.getSr_role())) {
                    List<String> netList2 = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                    if (netList2.size() > 0) {
                        String[] netArr = netList2.get(0).split(",");
                        order.setNetArr(netArr);
                        orders = this.orderDao.findOrderByNetArr_agent(order, page);
                        totalCount = this.orderDao.findCountByNetArr_agent(order);
                    }
                } else if ("4".equals(adminAgent.getSr_role()) && (netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id())).size() > 0) {
                    String[] netArr = netList.get(0).split(",");
                    order.setNetArr(netArr);
                    orders = this.orderDao.findOrderByNetArr_agent(order, page);
                    totalCount = this.orderDao.findCountByNetArr_agent(order);
                }
                page.setTotal(totalCount);
                dataMap.put("page", page);
                dataMap.put("orders", orders);
                ret_method.put(XcbConstantValue.DATA, dataMap);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u67e5\u65e0\u5546\u5bb6");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYPARAM_AGENTMB, PromptProperties.getProperty("order.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findOrderByParam_cpymb(Identifier identifier, Tb_order order, String dateRange, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            if (XcbStringUtils.isNullOrBlank((Object)dateRange) || "today".equals(dateRange)) {
                order.setSr_create_time_start(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                order.setSr_create_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else if ("yesterday".equals(dateRange)) {
                order.setSr_create_time(XcbDateUtil.getBeforeDay((Date)new Date(), (int)1, (String)"yyyy-MM-dd"));
            } else if ("week".equals(dateRange)) {
                order.setSr_create_time_start(XcbDateUtil.getBeforeDay((Date)new Date(), (int)7, (String)"yyyy-MM-dd"));
                order.setSr_create_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else if ("month".equals(dateRange)) {
                order.setSr_create_time_start(XcbDateUtil.getBeforeDay((Date)new Date(), (int)30, (String)"yyyy-MM-dd"));
                order.setSr_create_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            } else {
                order.setSr_create_time_start(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                order.setSr_create_time_end(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
            }
            List<Tb_order> orders = null;
            int totalCount = 0;
            orders = this.orderDao.findOrderByParam_cpy(order, page);
            totalCount = this.orderDao.findCountByParam_cpy(order);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("orders", orders);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYPARAM_CPYMB, PromptProperties.getProperty("order.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findOrderById_agentmb(Identifier identifier, Tb_order order) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            order = this.orderDao.findOrderById_agent(order.getSd_order_id());
            Tb_order_income income = this.orderInComeDao.findIncomeByOrderId(order.getSd_order_id());
            order.setIncome(income);
            Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(order.getSw_box_id());
            order.setDeviceBox(deviceBox);
            Tb_ordercash_stream ocs = new Tb_ordercash_stream();
            ocs.setSw_order_id(order.getSd_order_id());
            ocs.setSw_agent_id(order.getSw_agent_id());
            Page page = new Page();
            page.setStart(0);
            page.setPageSize(20);
            List<Tb_ordercash_stream> orderCashList = this.orderCashStreamDao.findOrderCashStreamByParam(ocs, page);
            List<Tb_opendoor_record> recordList = this.openDoorRecordDao.findOpenDoorRecordByOrder(order.getSd_order_id());
            dataMap.put("order", order);
            dataMap.put("orderCashList", orderCashList);
            dataMap.put("recordList", recordList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_FIND_BYID_AGENTMB, PromptProperties.getProperty("order.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> checkRefund(Identifier identifier, String sd_ordercash_id, String sr_refund_money, String sr_way) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        Tb_ordercash_stream orderCashStream = this.orderCashStreamDao.findOrderCashStreamById(sd_ordercash_id);
        if (orderCashStream != null) {
            Tb_order order = this.orderDao.findOrderById_agent(orderCashStream.getSw_order_id());
            Tb_order_income income = this.orderInComeDao.findIncomeByOrderId(order.getSd_order_id());
            if (XcbConstantValue.ORDER_GO.equals(order.getSr_order_status())) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.checkRefund.fail4"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                return ret_method;
            }
            BigDecimal dc_refund_money = orderCashStream.getDc_actual_pay();
            if (!XcbStringUtils.isNullOrBlank((Object)sr_refund_money)) {
                dc_refund_money = XcbStringUtils.getObjToBigDecimal((Object)sr_refund_money);
            }
            if (XcbConstantValue.ORDER_CASH_ZFCG.equals(orderCashStream.getSr_order_status())) {
                if (dc_refund_money.compareTo(orderCashStream.getDc_actual_pay()) == 1) {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.checkRefund.fail2"));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                } else if (!XcbConstantValue.ORDER_CASH_TYPE_PTYE.equals(orderCashStream.getSr_cash_type())) {
                    if (!"Y".equals(order.getSr_is_steal())) {
                        if (income != null) {
                            if (!"CPY".equals(sr_way)) {
                                BigDecimal i_agentMoney;
                                BigDecimal sum_tk;
                                BigDecimal sum_income;
                                Tb_agent agent = this.agentDao.findAgentMoneyById_user(orderCashStream.getSw_agent_id());
                                BigDecimal maxCbMoney = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_cb_single());
                                BigDecimal dc_agent_rate = BigDecimalUtil.div((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)income.getDc_agent_rate()), (BigDecimal)new BigDecimal(100));
                                BigDecimal dc_shop_rate = BigDecimalUtil.div((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)income.getDc_shop_rate()), (BigDecimal)new BigDecimal(100));
                                BigDecimal dc_refund_agent_money = BigDecimalUtil.mul((BigDecimal)dc_refund_money, (BigDecimal)dc_agent_rate);
                                BigDecimal dc_refund_shop_money = BigDecimalUtil.mul((BigDecimal)dc_refund_money, (BigDecimal)dc_shop_rate);
                                this.log.info("###############\u8ba2\u5355\u9000\u6b3e\u68c0\u67e5###############");
                                this.log.info("###############\u8ba2\u5355\u6d41\u6c34\u53f7:" + orderCashStream.getSd_ordercash_id() + "###############");
                                this.log.info("###############\u8ba2\u5355\u9000\u6b3e\u91d1\u989d:" + dc_refund_money + "\u5143###############");
                                Tb_agent upAgent = this.agentDao.findAgentById_agent(income.getSw_agent_id());
                                BigDecimal maxUpCbMoney = XcbStringUtils.getObjToBigDecimal((Object)upAgent.getDc_cb_single());
                                BigDecimal cbUpMoney = XcbStringUtils.getObjToBigDecimal((Object)upAgent.getDc_cb_money());
                                BigDecimal agentUpMoney = XcbStringUtils.getObjToBigDecimal((Object)upAgent.getDc_agent_money());
                                this.log.info("###############\u4ee3\u7406\u5546:" + upAgent.getSd_agent_id() + "###############");
                                this.log.info("###############\u4ee3\u7406\u5546\u5e94\u9000\u91d1\u989d:" + dc_refund_agent_money + "\u5143###############");
                                this.log.info("###############\u4ee3\u7406\u5546\u50a8\u5907\u91d1:" + cbUpMoney + "\u5143###############");
                                this.log.info("###############\u4ee3\u7406\u5546\u4f59\u989d:" + agentUpMoney + "\u5143###############");
                                BigDecimal cbMoney = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_cb_money());
                                BigDecimal agentMoney = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_agent_money());
                                this.log.info("###############\u5546\u5bb6\u50a8\u5907\u91d1:" + cbMoney + "\u5143###############");
                                this.log.info("###############\u5546\u5bb6\u4f59\u989d:" + agentMoney + "\u5143###############");
                                this.log.info("###############\u5546\u5bb6:" + agent.getSd_agent_id() + "###############");
                                this.log.info("###############\u5546\u5bb6\u5e94\u9000\u91d1\u989d:" + dc_refund_shop_money + "\u5143###############");
                                boolean ischeckAgent = false;
                                boolean ischeckShop = false;
                                if (maxCbMoney.compareTo(BigDecimal.ZERO) == 0) {
                                    sum_income = XcbStringUtils.getObjToBigDecimal((Object)this.cashStreamDao.findOrderIncome(agent.getSd_agent_id()));
                                    sum_tk = XcbStringUtils.getObjToBigDecimal((Object)this.cashStreamDao.findOrderTk(agent.getSd_agent_id()));
                                    i_agentMoney = BigDecimalUtil.add((BigDecimal)(sum_income = BigDecimalUtil.sub((BigDecimal)sum_income, (BigDecimal)sum_tk)), (BigDecimal)agentMoney);
                                    if (i_agentMoney.compareTo(dc_refund_shop_money) >= 0) {
                                        ischeckShop = true;
                                    } else {
                                        ret_method.put(XcbConstantValue.MSG, "\u5546\u5bb6\u4f59\u989d\u4e0d\u8db3\uff0c\u4e0d\u53ef\u9000\u6b3e\uff01");
                                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                    }
                                } else if (cbMoney.compareTo(dc_refund_shop_money) >= 0) {
                                    ischeckShop = true;
                                } else {
                                    ret_method.put(XcbConstantValue.MSG, "\u5546\u5bb6\u50a8\u5907\u91d1\u4e0d\u8db3\uff0c\u4e0d\u53ef\u9000\u6b3e\uff01");
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                }
                                if (maxUpCbMoney.compareTo(BigDecimal.ZERO) == 0) {
                                    sum_income = XcbStringUtils.getObjToBigDecimal((Object)this.cashStreamDao.findOrderIncome(upAgent.getSd_agent_id()));
                                    sum_tk = XcbStringUtils.getObjToBigDecimal((Object)this.cashStreamDao.findOrderTk(upAgent.getSd_agent_id()));
                                    i_agentMoney = BigDecimalUtil.add((BigDecimal)(sum_income = BigDecimalUtil.sub((BigDecimal)sum_income, (BigDecimal)sum_tk)), (BigDecimal)agentUpMoney);
                                    if (i_agentMoney.compareTo(dc_refund_agent_money) >= 0) {
                                        ischeckAgent = true;
                                    } else {
                                        ret_method.put(XcbConstantValue.MSG, "\u4ee3\u7406\u5546\u4f59\u989d\u4e0d\u8db3\uff0c\u4e0d\u53ef\u9000\u6b3e\uff01");
                                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                    }
                                } else if (cbUpMoney.compareTo(dc_refund_agent_money) >= 0) {
                                    ischeckAgent = true;
                                } else {
                                    ret_method.put(XcbConstantValue.MSG, "\u4ee3\u7406\u5546\u50a8\u5907\u91d1\u4e0d\u8db3\uff0c\u4e0d\u53ef\u9000\u6b3e\uff01");
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                }
                                if (ischeckAgent && ischeckShop) {
                                    ret_method.put(XcbConstantValue.DATA, orderCashStream);
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                                }
                            } else {
                                ret_method.put(XcbConstantValue.DATA, orderCashStream);
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            }
                        } else {
                            ret_method.put(XcbConstantValue.MSG, "\u8ba2\u5355\u4fe1\u606f\u5f02\u5e38\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
                            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        }
                    } else {
                        ret_method.put(XcbConstantValue.DATA, orderCashStream);
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    }
                } else {
                    ret_method.put(XcbConstantValue.DATA, orderCashStream);
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                }
            } else if (XcbConstantValue.ORDER_CASH_BFTK.equals(orderCashStream.getSr_order_status())) {
                BigDecimal dc_old_refund_money = orderCashStream.getDc_refund_money();
                BigDecimal tmpMoney = BigDecimalUtil.add((BigDecimal)dc_refund_money, (BigDecimal)dc_old_refund_money);
                if (tmpMoney.compareTo(orderCashStream.getDc_actual_pay()) <= 0) {
                    if (!"Y".equals(order.getSr_is_steal())) {
                        if (income != null) {
                            if (!"CPY".equals(sr_way)) {
                                Tb_agent agent = this.agentDao.findAgentMoneyById_user(income.getSw_agent_id());
                                BigDecimal maxCbMoney = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_cb_single());
                                BigDecimal dc_agent_rate = BigDecimalUtil.div((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)income.getDc_agent_rate()), (BigDecimal)new BigDecimal(100));
                                BigDecimal dc_shop_rate = BigDecimalUtil.div((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)income.getDc_shop_rate()), (BigDecimal)new BigDecimal(100));
                                BigDecimal dc_refund_agent_money = BigDecimalUtil.mul((BigDecimal)dc_refund_money, (BigDecimal)dc_agent_rate);
                                BigDecimal dc_refund_shop_money = BigDecimalUtil.mul((BigDecimal)dc_refund_money, (BigDecimal)dc_shop_rate);
                                this.log.info("###############\u8ba2\u5355\u9000\u6b3e\u68c0\u67e5###############");
                                this.log.info("###############\u8ba2\u5355\u6d41\u6c34\u53f7:" + orderCashStream.getSd_ordercash_id() + "###############");
                                this.log.info("###############\u8ba2\u5355\u9000\u6b3e\u91d1\u989d:" + dc_refund_money + "\u5143###############");
                                Tb_agent upAgent = this.agentDao.findAgentById_agent(income.getSw_agent_id());
                                BigDecimal maxUpCbMoney = XcbStringUtils.getObjToBigDecimal((Object)upAgent.getDc_cb_single());
                                BigDecimal cbUpMoney = XcbStringUtils.getObjToBigDecimal((Object)upAgent.getDc_cb_money());
                                BigDecimal agentUpMoney = XcbStringUtils.getObjToBigDecimal((Object)upAgent.getDc_agent_money());
                                this.log.info("###############\u4ee3\u7406\u5546:" + upAgent.getSd_agent_id() + "###############");
                                this.log.info("###############\u4ee3\u7406\u5546\u5e94\u9000\u91d1\u989d:" + dc_refund_agent_money + "\u5143###############");
                                this.log.info("###############\u4ee3\u7406\u5546\u50a8\u5907\u91d1:" + cbUpMoney + "\u5143###############");
                                this.log.info("###############\u4ee3\u7406\u5546\u4f59\u989d:" + agentUpMoney + "\u5143###############");
                                BigDecimal cbMoney = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_cb_money());
                                BigDecimal agentMoney = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_agent_money());
                                this.log.info("###############\u5546\u5bb6\u50a8\u5907\u91d1:" + cbMoney + "\u5143###############");
                                this.log.info("###############\u5546\u5bb6\u4f59\u989d:" + agentMoney + "\u5143###############");
                                this.log.info("###############\u5546\u5bb6:" + agent.getSd_agent_id() + "###############");
                                this.log.info("###############\u5546\u5bb6\u5e94\u9000\u91d1\u989d:" + dc_refund_shop_money + "\u5143###############");
                                boolean ischeckAgent = false;
                                boolean ischeckShop = false;
                                if (maxCbMoney.compareTo(BigDecimal.ZERO) == 0) {
                                    if (agentMoney.compareTo(dc_refund_shop_money) >= 0) {
                                        ischeckShop = true;
                                    } else {
                                        ret_method.put(XcbConstantValue.MSG, "\u5546\u5bb6\u4f59\u989d\u4e0d\u8db3\uff0c\u4e0d\u53ef\u9000\u6b3e\uff01");
                                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                    }
                                } else if (cbMoney.compareTo(dc_refund_shop_money) >= 0) {
                                    ischeckShop = true;
                                } else {
                                    ret_method.put(XcbConstantValue.MSG, "\u5546\u5bb6\u50a8\u5907\u91d1\u4e0d\u8db3\uff0c\u4e0d\u53ef\u9000\u6b3e\uff01");
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                }
                                if (maxUpCbMoney.compareTo(BigDecimal.ZERO) == 0) {
                                    if (agentUpMoney.compareTo(dc_refund_agent_money) >= 0) {
                                        ischeckAgent = true;
                                    } else {
                                        ret_method.put(XcbConstantValue.MSG, "\u4ee3\u7406\u5546\u4f59\u989d\u4e0d\u8db3\uff0c\u4e0d\u53ef\u9000\u6b3e\uff01");
                                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                    }
                                } else if (cbUpMoney.compareTo(dc_refund_agent_money) >= 0) {
                                    ischeckAgent = true;
                                } else {
                                    ret_method.put(XcbConstantValue.MSG, "\u4ee3\u7406\u5546\u50a8\u5907\u91d1\u4e0d\u8db3\uff0c\u4e0d\u53ef\u9000\u6b3e\uff01");
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                }
                                if (ischeckAgent && ischeckShop) {
                                    ret_method.put(XcbConstantValue.DATA, orderCashStream);
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                                }
                            } else {
                                ret_method.put(XcbConstantValue.DATA, orderCashStream);
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            }
                        } else {
                            ret_method.put(XcbConstantValue.MSG, "\u8ba2\u5355\u4fe1\u606f\u5f02\u5e38\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
                            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        }
                    } else {
                        ret_method.put(XcbConstantValue.DATA, orderCashStream);
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    }
                } else {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.checkRefund.fail3"));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.checkRefund.error2"));
            }
        } else {
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.checkRefund.error"));
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    @Transactional
    Map<String, Object> refund(Identifier identifier, String sd_ordercash_id, String sr_refund_money) {
        Map<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        String table = "";
        String error_log = "";
        Tb_order order = new Tb_order();
        BigDecimal dc_refund_money = BigDecimal.ZERO;
        Tb_ordercash_stream orderCash = this.orderCashStreamDao.findOrderCashStreamById(sd_ordercash_id);
        try {
            if (orderCash != null) {
                order = this.orderDao.findOrderById_agent(orderCash.getSw_order_id());
                BigDecimal total_refund_money = orderCash.getDc_actual_pay();
                dc_refund_money = orderCash.getDc_actual_pay();
                String sr_order_status = XcbConstantValue.ORDER_CASH_YTK;
                if (!XcbStringUtils.isNullOrBlank((Object)sr_refund_money)) {
                    BigDecimal dc_old_refund_money;
                    dc_refund_money = XcbStringUtils.getObjToBigDecimal((Object)sr_refund_money);
                    total_refund_money = BigDecimalUtil.add((BigDecimal)dc_refund_money, (BigDecimal)(dc_old_refund_money = XcbStringUtils.getObjToBigDecimal((Object)orderCash.getDc_refund_money())));
                    sr_order_status = total_refund_money.compareTo(orderCash.getDc_actual_pay()) == 0 ? XcbConstantValue.ORDER_CASH_YTK : XcbConstantValue.ORDER_CASH_BFTK;
                }
                BigDecimal refund_money = order.getDc_refund_money();
                if ((refund_money = BigDecimalUtil.add((BigDecimal)refund_money, (BigDecimal)total_refund_money)).compareTo(order.getDc_actual_income()) == 0) {
                    order.setSr_order_status(XcbConstantValue.ORDER_YTK);
                } else {
                    order.setSr_order_status(XcbConstantValue.ORDER_BFTK);
                }
                order.setDc_refund_money(refund_money);
                result = this.orderDao.updateOrder(order);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Tb_ordercash_stream newOrderCash = new Tb_ordercash_stream();
                    newOrderCash.setSd_ordercash_id(sd_ordercash_id);
                    newOrderCash.setSr_order_status(sr_order_status);
                    newOrderCash.setDc_refund_money(total_refund_money);
                    result = this.orderCashStreamDao.updateOrderCashStream(newOrderCash);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
                        result = this.commonLogic.updateUser_account(identifier, dc_refund_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_DSTK);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            if (!"Y".equals(order.getSr_is_steal())) {
                                String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                                BigDecimal incomeMoney = BigDecimalUtil.sub((BigDecimal)order.getDc_actual_income(), (BigDecimal)refund_money);
                                Tb_order_income income = this.orderInComeDao.findIncomeByOrderId(order.getSd_order_id());
                                ret_method = this.tkCalculationIncome(orderCash, sd_cash_id, income, incomeMoney, error_log);
                                result = XcbStringUtils.getObjtoint((Object)ret_method.get(XcbConstantValue.STATUS));
                                error_log = XcbStringUtils.getObjtoString((Object)ret_method.get(XcbConstantValue.MSG));
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    isSuccess = true;
                                }
                            } else {
                                isSuccess = true;
                            }
                        } else {
                            table = "tb_user_account";
                            error_log = PromptProperties.getProperty("order.tknotify.error.updateuseraccount", XcbConstantValue.ORDER_REFUND, order.getSd_order_id(), order.getSw_agent_id());
                            this.log.error(error_log);
                        }
                    } else {
                        table = "tb_ordercash_stream";
                        error_log = PromptProperties.getProperty("order.tknotify.error.updateorder", XcbConstantValue.ORDER_REFUND, order.getSd_order_id(), order.getSw_agent_id());
                        this.log.error(error_log);
                    }
                } else {
                    table = "tb_order";
                    error_log = PromptProperties.getProperty("order.tknotify.error.updateorder", XcbConstantValue.ORDER_REFUND, order.getSd_order_id(), order.getSw_agent_id());
                    this.log.error(error_log);
                }
            }
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5:" + XcbConstantValue.ORDER_REFUND + "\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            error_log = "\u7cfb\u7edf\u5f02\u5e38";
        }
        if (isSuccess) {
            Tb_user user = this.userDao.findUserById(order.getSw_user_id());
            if (user != null) {
                if ("Y".equals(user.getSr_is_subscribe())) {
                    this.sendWXMessage(order, XcbStringUtils.getObjToBigDecimal((Object)dc_refund_money), "REFUND");
                } else if ("Y".equals(user.getSr_subscribe_refund())) {
                    this.sendWXAppMessage(order, XcbStringUtils.getObjToBigDecimal((Object)dc_refund_money), "REFUND");
                }
            }
            error_log = PromptProperties.getProperty("order.tknotify.success");
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, error_log);
        } else {
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, error_log);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, XcbConstantValue.ORDER_REFUND, identifier.getUserId(), XcbConstantValue.OPERATION_FAIL, "CREATE", "\u8ba2\u5355\u9000\u6b3e\u56de\u8c03\uff08\u7528\u6237\u7aef\uff09:\u94b1\u5df2\u7ecf\u9000\u4e86\uff0c\u4f46\u6570\u636e\u4fee\u6539\u9519\u8bef " + error_log, identifier.getUrl(), identifier.getIp());
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(sd_ordercash_id);
            operationLogs.setSr_operate_table(table);
            this.operationLogServiceImpl.createOperaLog(operationLogs);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public void createStatistics(String statistics_date, Integer sw_agent_id) throws Exception {
        try {
            Identifier identifier = new Identifier();
            this.createStatisticsByDate(identifier, statistics_date, statistics_date, sw_agent_id);
        }
        catch (Exception ex) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)ex));
            this.log.error("\u7edf\u8ba1\u4ee3\u7406\u5546\u6570\u636e\u62a5\u9519,\u4ee3\u7406\u5546ID:" + sw_agent_id + " \u9519\u8bef\u4fe1\u606f:" + XcbStringUtils.exceptionToString((Exception)ex));
        }
    }

    public int createStatisticsByDate(Identifier identifier, String sr_date_start, String sr_date_end, Integer sw_agent_id) throws Exception {
        int result = 0;
        try {
            Date startDate = DateUtil.StringToDate(sr_date_start, "yyyy-MM-dd");
            Date endDate = DateUtil.StringToDate(sr_date_end, "yyyy-MM-dd");
            this.log.info("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210:\u5f00\u59cb\u65f6\u95f4:" + startDate + "#################");
            this.log.info("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210:\u7ed3\u675f\u65f6\u95f4:" + endDate + "#################");
            int diff = DateUtil.getDays(endDate, startDate);
            List<Map<String, String>> list_onlineOrder = this.orderDao.getOnlineOrderByParam_task(sr_date_start, sr_date_end, sw_agent_id);
            List<Map<String, String>> list_countOrder = this.orderDao.getCountOrderByParam_task(sr_date_start, sr_date_end, sw_agent_id);
            List<Map<String, String>> list_userRegcount = this.orderDao.getUserRegcountByParam_task(sr_date_start, sr_date_end, sw_agent_id);
            Date date = startDate;
            ArrayList<Tb_statistics> list = new ArrayList<Tb_statistics>();
            if (diff > 0) {
                for (int i = 0; i <= diff; ++i) {
                    Tb_statistics vo = new Tb_statistics();
                    vo.setSi_online_order_count(Integer.valueOf(0));
                    vo.setDc_online_order_money(BigDecimal.ZERO);
                    vo.setSw_agent_id(sw_agent_id);
                    vo.setDc_online_tk_money(BigDecimal.ZERO);
                    vo.setSi_user_person(Integer.valueOf(0));
                    vo.setSi_register_person(Integer.valueOf(0));
                    vo.setDc_ad_money(BigDecimal.ZERO);
                    vo.setTm_date(date);
                    list.add(vo);
                    date = DateUtil.addDay(date, 1);
                }
            } else if (diff == 0) {
                Tb_statistics vo = new Tb_statistics();
                vo.setSi_online_order_count(Integer.valueOf(0));
                vo.setDc_online_order_money(BigDecimal.ZERO);
                vo.setSw_agent_id(sw_agent_id);
                vo.setDc_online_tk_money(BigDecimal.ZERO);
                vo.setSi_user_person(Integer.valueOf(0));
                vo.setDc_ad_money(BigDecimal.ZERO);
                vo.setSi_register_person(Integer.valueOf(0));
                vo.setTm_date(date);
                list.add(vo);
            }
            if (list.size() > 0) {
                for (Tb_statistics statistics : list) {
                    String sr_order_time;
                    Date tm_date = statistics.getTm_date();
                    for (Map<String, String> map : list_onlineOrder) {
                        sr_order_time = XcbStringUtils.getObjtoString((Object)map.get("sr_order_time"));
                        BigDecimal dc_actual_income_sum = XcbStringUtils.getObjToBigDecimal((Object)map.get("dc_actual_income_sum"));
                        BigDecimal dc_refund_money_sum = XcbStringUtils.getObjToBigDecimal((Object)map.get("dc_refund_money_sum"));
                        BigDecimal dc_ad_money_sum = XcbStringUtils.getObjToBigDecimal((Object)map.get("dc_ad_money_sum"));
                        Integer user_count = XcbStringUtils.getObjtoint((Object)map.get("user_count"));
                        Date ordertime = XcbDateUtil.parseDate((String)sr_order_time, (String)"yyyy-MM-dd");
                        if (!DateUtil.isSameDate(tm_date, ordertime)) continue;
                        statistics.setDc_online_order_money(dc_actual_income_sum);
                        statistics.setDc_online_tk_money(dc_refund_money_sum);
                        statistics.setSi_user_person(user_count);
                        statistics.setDc_ad_money(dc_ad_money_sum);
                        this.log.info("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210:\u65f6\u95f4:" + tm_date + "#################");
                        this.log.info("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210:\u5728\u7ebf\u8ba2\u5355\u91d1\u989d:" + dc_actual_income_sum + "#################");
                        this.log.info("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210:\u5728\u7ebf\u8ba2\u5355\u9000\u6b3e\u91d1\u989d:" + dc_refund_money_sum + "#################");
                        this.log.info("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210:\u8ba2\u5355\u7528\u6237\u6570\u91cf:" + user_count + "#################");
                        this.log.info("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210:\u8ba2\u5355\u5e7f\u544a\u8d39:" + dc_ad_money_sum + "#################");
                    }
                    for (Map<String, String> map : list_countOrder) {
                        sr_order_time = XcbStringUtils.getObjtoString((Object)map.get("sr_order_time"));
                        Integer zx_ordercount = XcbStringUtils.getObjtoint((Object)map.get("zx_ordercount"));
                        Date ordertime = XcbDateUtil.parseDate((String)sr_order_time, (String)"yyyy-MM-dd");
                        if (!DateUtil.isSameDate(tm_date, ordertime)) continue;
                        statistics.setSi_online_order_count(zx_ordercount);
                        this.log.info("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210:\u65f6\u95f4:" + tm_date + "#################");
                        this.log.info("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210:\u5728\u7ebf\u8ba2\u5355\u6570\u91cf:" + zx_ordercount + "#################");
                    }
                    for (Map<String, String> map : list_userRegcount) {
                        String sr_create_time = XcbStringUtils.getObjtoString((Object)map.get("sr_create_time"));
                        Integer regcount = XcbStringUtils.getObjtoint((Object)map.get("regcount"));
                        Date createtime = XcbDateUtil.parseDate((String)sr_create_time, (String)"yyyy-MM-dd");
                        if (DateUtil.isSameDate(tm_date, createtime)) {
                            statistics.setSi_register_person(regcount);
                        }
                        this.log.info("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210:\u6ce8\u518c\u7528\u6237\u6570\u91cf:" + regcount + "#################");
                    }
                }
            }
            if (list.size() > 0) {
                Tb_statistics d_statistics = new Tb_statistics();
                d_statistics.setSw_agent_id(sw_agent_id);
                d_statistics.setSr_date_start(sr_date_start);
                d_statistics.setSr_date_end(sr_date_end);
                this.statisticsDao.deleteByParam(d_statistics);
                result = this.statisticsDao.createStatisticsList(list);
                if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                    this.log.error("#################\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210\u5f02\u5e38\uff0c\u8bf7\u67e5\u51fa\u65e5\u5fd7#################");
                    TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                    String msg = "\u4ee3\u7406\u5546" + sw_agent_id + "\u5728\u65e5\u671f:" + sr_date_start + "-" + sr_date_end + "\u751f\u6210\u7ecf\u8425\u7edf\u8ba1\u6570\u636e\u5f02\u5e38";
                    this.log.error(msg);
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_AGENT, XcbConstantValue.STATISTICS_RESET_DATA, identifier.getUserId(), XcbConstantValue.OPERATION_FAIL, "CREATE", msg, identifier.getUrl(), identifier.getIp());
                    operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                    operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)sw_agent_id));
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
            }
        }
        catch (Exception ex) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)ex));
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            this.log.error("\u7edf\u8ba1\u4ee3\u7406\u5546\u6570\u636e\u62a5\u9519,\u4ee3\u7406\u5546ID:" + sw_agent_id + " \u9519\u8bef\u4fe1\u606f:" + XcbStringUtils.exceptionToString((Exception)ex));
        }
        return result;
    }

    @Transactional
    Map<String, Object> resetData(String[] deviceArr, String sr_password) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)sr_password)) {
                Tb_sys_param sysParam = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.O_PASS);
                if (sr_password.equals(sysParam.getSr_param_value())) {
                    if (deviceArr != null && deviceArr.length > 0) {
                        for (String deviceid : deviceArr) {
                            Tb_device device = this.deviceDao.findDeviceDetailById_agent(deviceid);
                            this.orderCashStreamDao.deleteByDeviceId(device.getSd_device_id());
                            this.openDoorRecordDao.deleteByDeviceId(device.getSd_device_id());
                            this.cashStreamDao.deleteByDeviceId(device.getSd_device_id());
                            this.userRechargeDao.deleteByDeviceId(device.getSd_device_id());
                            this.orderInComeDao.deleteByDeviceId(device.getSd_device_id());
                            this.orderDao.deleteByDeviceId(device.getSd_device_id());
                        }
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret_method.put(XcbConstantValue.MSG, "\u6e05\u9664\u4e1a\u52a1\u6570\u636e\u6210\u529f");
                    } else {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u53c2\u6570\u5f02\u5e38,\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
                    }
                } else {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u64cd\u4f5c\u5bc6\u7801\u9519\u8bef");
                }
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u8bf7\u8f93\u5165\u64cd\u4f5c\u5bc6\u7801");
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            this.log.error("\u5f02\u5e38\u65b9\u6cd5: resetData\u5f02\u5e38\u4fe1\u606f:" + e.getMessage());
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        return ret_method;
    }
}

