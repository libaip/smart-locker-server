/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cn.hutool.core.date.TimeInterval
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.agent.model.Tb_recharge_set
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.user.model.Tb_user_account
 *  com.jcg.user.model.Tb_user_withdrawal_appl
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.agent.serviceimpl;

import cn.hutool.core.date.TimeInterval;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.idao.RechargeSetDao;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.model.Tb_recharge_set;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.user.idao.UserAccountDao;
import com.jcg.user.idao.UserWithdrawalApplDao;
import com.jcg.user.model.Tb_user_account;
import com.jcg.user.model.Tb_user_withdrawal_appl;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RechargeSetServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private RechargeSetDao rechargeSetDao;
    @Autowired
    private UserAccountDao userAccountDao;
    @Autowired
    private UserWithdrawalApplDao userWithdrawalApplDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private CommonLogic commonLogic;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=========RechargeSetServiceImpl========");
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_recharge_set rechargeSet = new Tb_recharge_set();
        Page page = new Page();
        if (param != null) {
            rechargeSet = (Tb_recharge_set)param.get("rechargeSet");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.RECHARGESET_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findRechargeSetByParam(rechargeSet);
            } else if (XcbConstantValue.RECHARGESET_FIND_BYAGENTID.equalsIgnoreCase(functionCode)) {
                ret = this.findRechargeSetByAgentId_user(rechargeSet);
            } else if (XcbConstantValue.RECHARGESET_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findRechargeSetByParam_cpy(rechargeSet);
            } else if (XcbConstantValue.RECHARGESET_FIND_UPDATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateRechargeSetByParam_cpy(rechargeSet);
            } else if (XcbConstantValue.RECHARGESET_UPDATE_TASK_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.executeUpdateUserTask();
            } else if (XcbConstantValue.RECHARGESET_FIND_COUNT_TASK_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findUserTaskCount();
            } else if (XcbConstantValue.RECHARGESET_FIND_COUNT_APPL_TASK_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findUserApplTaskCount();
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> updateRechargeSetByParam_cpy(Tb_recharge_set rechargeSet) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        try {
            List<Tb_recharge_set> rechargeSetList;
            if (!XcbStringUtils.isNullOrBlank((Object)rechargeSet.getSw_company_id())) {
                rechargeSet.setSw_agent_id(rechargeSet.getSw_company_id());
            }
            if ((rechargeSetList = this.rechargeSetDao.findRechargeSetByParam(rechargeSet)) != null && rechargeSetList.size() > 0) {
                result = this.rechargeSetDao.updateRechargeSet(rechargeSet);
            } else {
                String nowDate_str = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd");
                rechargeSet.setSw_coupon_id(nowDate_str);
                if (!XcbStringUtils.isNullOrBlank((Object)rechargeSet.getSw_company_id())) {
                    rechargeSet.setSw_agent_id(rechargeSet.getSw_company_id());
                }
                result = this.rechargeSetDao.createRechargeSet_agent(rechargeSet);
            }
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("rechargeset.update.success"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("rechargeset.update.error"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.RECHARGESET_FIND_UPDATE_CPY, PromptProperties.getProperty("rechargeset.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findRechargeSetByParam(Tb_recharge_set rechargeSet) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_recharge_set>> dataMap = new HashMap<String, List<Tb_recharge_set>>();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)rechargeSet.getSw_company_id())) {
                rechargeSet.setSw_agent_id(rechargeSet.getSw_company_id());
            }
            List<Tb_recharge_set> rechargeSets = this.rechargeSetDao.findRechargeSetByParam(rechargeSet);
            dataMap.put("rechargeSets", rechargeSets);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.RECHARGESET_FIND_BYPARAM, PromptProperties.getProperty("rechargeset.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findRechargeSetByParam_cpy(Tb_recharge_set rechargeSet) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_recharge_set>> dataMap = new HashMap<String, List<Tb_recharge_set>>();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)rechargeSet.getSw_company_id())) {
                rechargeSet.setSw_agent_id(rechargeSet.getSw_company_id());
            }
            List<Tb_recharge_set> rechargeSets = this.rechargeSetDao.findRechargeSetByParam(rechargeSet);
            dataMap.put("rechargeSets", rechargeSets);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.RECHARGESET_FIND_BYPARAM_CPY, PromptProperties.getProperty("rechargeset.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> updateRechargeSetByID(Tb_recharge_set rechargeSet) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int count = 0;
        try {
            count = this.rechargeSetDao.updateRechargeSet(rechargeSet);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("rechargeset.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("rechargeset.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.RECHARGESET_UPDATE_BYID, PromptProperties.getProperty("rechargeset.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findRechargeSetByAgentId_user(Tb_recharge_set rechargeSet) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_recharge_set>> dataMap = new HashMap<String, List<Tb_recharge_set>>();
        try {
            List<Tb_recharge_set> rechargeSets = this.rechargeSetDao.findRechargeSetByAgentId_user(rechargeSet);
            dataMap.put("rechargeSets", rechargeSets);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.RECHARGESET_FIND_BYAGENTID, PromptProperties.getProperty("rechargeset.findbyparam.error"), (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> executeUpdateUserTask() {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u7528\u6237\u8d26\u6237 START #################");
            int result = 0;
            String sr_type = "TASK_USER_ACCOUNT";
            String nowDate_str = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd");
            List<Tb_recharge_set> list = this.rechargeSetDao.findTaskRechargeSet(sr_type);
            if (list != null && list.size() > 0) {
                for (Tb_recharge_set rechargeSet : list) {
                    rechargeSet.setExcute(false);
                    String sw_company_id = rechargeSet.getSw_agent_id();
                    int taskDiff = XcbStringUtils.getObjToBigDecimal((Object)rechargeSet.getDc_recharge_money()).intValue();
                    int taskHour = XcbStringUtils.getObjtoint((Object)rechargeSet.getSi_coupon_count());
                    int total = rechargeSet.getDc_present_award().intValue();
                    try {
                        List<Tb_user_account> userAccountList = this.userAccountDao.findTaskUserAccount(sw_company_id, total);
                        if (userAccountList == null || userAccountList.size() <= 0) break;
                        TimeInterval queryTime = new TimeInterval();
                        queryTime.start();
                        System.out.println("#########\u6267\u884c\u4efb\u52a1\u5f00\u59cb##########" + queryTime.intervalPretty());
                        this.log.info("#########\u6267\u884c\u4efb\u52a1\u5f00\u59cb##########" + queryTime.intervalPretty());
                        for (Tb_user_account userAccount : userAccountList) {
                            int diff = XcbStringUtils.getObjtoint((Object)userAccount.getDatediff());
                            if (diff < taskDiff) continue;
                            BigDecimal dc_account_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money());
                            BigDecimal dc_present_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_present_money());
                            BigDecimal dc_remark_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_remark_money());
                            BigDecimal dc_account_money_sum = BigDecimalUtil.add((BigDecimal)dc_account_money, (BigDecimal)dc_present_money);
                            if (dc_account_money_sum.compareTo(BigDecimal.ZERO) != 1) continue;
                            rechargeSet.setExcute(true);
                            result = this.commonLogic.updateUser_account_task(dc_account_money, dc_present_money, dc_remark_money, userAccount);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                this.orderDao.updateLastPizhu(userAccount.getSw_user_id());
                                Tb_order order = this.orderDao.findLastOrderByUser(userAccount.getSw_user_id());
                                result = this.orderDao.updatePizhuById(order.getSd_order_id());
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    this.log.info("#########\u66f4\u65b0\u7528\u6237" + userAccount.getSw_user_id() + "\u66f4\u65b0\u6210\u529f##########");
                                    continue;
                                }
                                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_TASK, XcbConstantValue.ORDER_PAYNOTIFY, userAccount.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u66f4\u65b0\u8ba2\u5355" + order.getSd_order_id() + "\u5f02\u5e38", "", "");
                                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                                operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)order.getSd_order_id()));
                                operationLogs.setSr_operate_table("tb_order");
                                this.operationLogServiceImpl.createOperaLog(operationLogs);
                                continue;
                            }
                            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_TASK, XcbConstantValue.ORDER_PAYNOTIFY, userAccount.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u66f4\u65b0\u7528\u6237\u8d26\u6237" + userAccount.getSd_account_id() + "\u7d2f\u8ba1\u91d1\u989d\u5f02\u5e38", "", "");
                            operationLogs.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)userAccount.getSd_account_id()));
                            operationLogs.setSr_operate_table("tb_user_account");
                            this.operationLogServiceImpl.createOperaLog(operationLogs);
                        }
                        System.out.println("#########\u6267\u884c\u4efb\u52a1\u7ed3\u675f##########" + queryTime.intervalPretty());
                        this.log.info("#########\u6267\u884c\u4efb\u52a1\u7ed3\u675f##########" + queryTime.intervalPretty());
                    }
                    catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                }
                for (Tb_recharge_set rechargeSet : list) {
                    boolean isExcute = rechargeSet.isExcute();
                    if (!isExcute) continue;
                    Tb_recharge_set n_set = new Tb_recharge_set();
                    n_set.setSd_setrecharge_id(rechargeSet.getSd_setrecharge_id());
                    n_set.setSw_coupon_id(nowDate_str);
                    this.rechargeSetDao.updateRechargeSet(n_set);
                }
            }
            this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u7528\u6237\u8d26\u6237 END #################");
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.RECHARGESET_UPDATE_TASK_CPY, "\u5b9a\u65f6\u4efb\u52a1\u6267\u884c\u5f02\u5e38", (Throwable)e);
        }
        ret_method.put(XcbConstantValue.MSG, "\u4efb\u52a1\u6b63\u5728\u6267\u884c\uff0c\u8bf7\u52ff\u91cd\u590d\u64cd\u4f5c\u3002");
        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        return ret_method;
    }

    public Map<String, Object> findUserTaskCount() {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Integer> dataMap = new HashMap<String, Integer>();
        try {
            String sr_type = "TASK_USER_ACCOUNT";
            List<Tb_recharge_set> list = this.rechargeSetDao.findTaskRechargeSet(sr_type);
            if (list != null && list.size() > 0) {
                String sw_company_id = list.get(0).getSw_agent_id();
                int count = this.userAccountDao.findCountTaskUserAccount(sw_company_id);
                dataMap.put("task_cnt", count);
            }
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.RECHARGESET_FIND_COUNT_TASK_CPY, "\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> findUserApplTaskCount() {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Integer> dataMap = new HashMap<String, Integer>();
        try {
            String sr_type = "TASK_USER_APPL";
            List<Tb_recharge_set> list = this.rechargeSetDao.findTaskRechargeSet(sr_type);
            if (list != null && list.size() > 0) {
                List<Tb_user_withdrawal_appl> applList = this.userWithdrawalApplDao.findDSPUserWithdrawalAppl_task();
                if (applList != null && applList.size() > 0) {
                    dataMap.put("task_cnt", applList.size());
                } else {
                    dataMap.put("task_cnt", 0);
                }
            }
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.RECHARGESET_FIND_COUNT_APPL_TASK_CPY, "\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }
}

