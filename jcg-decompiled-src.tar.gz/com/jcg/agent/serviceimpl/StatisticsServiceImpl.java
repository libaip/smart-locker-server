/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cn.hutool.core.date.TimeInterval
 *  cn.hutool.core.util.ObjectUtil
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_cash_stream
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_netpoint
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.user.model.Tb_user
 *  com.jcg.user.model.Tb_user_account
 *  com.jcg.user.model.Tb_user_recharge
 *  com.jcg.user.model.Tb_user_withdrawal_appl
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.agent.serviceimpl;

import cn.hutool.core.date.TimeInterval;
import cn.hutool.core.util.ObjectUtil;
import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentRolesRelDao;
import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.DeviceLogsDao;
import com.jcg.agent.idao.NetPointDao;
import com.jcg.agent.idao.OrderCashStreamDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.idao.OrderInComeDao;
import com.jcg.agent.idao.StatisticsDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_cash_stream;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_netpoint;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.model.Tb_statistics;
import com.jcg.agent.serviceimpl.OrderServiceImpl;
import com.jcg.common.BaseService;
import com.jcg.common.DateUtil;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.user.idao.UserAccountDao;
import com.jcg.user.idao.UserDao;
import com.jcg.user.idao.UserRechargeDao;
import com.jcg.user.idao.UserWithdrawalApplDao;
import com.jcg.user.model.Tb_user;
import com.jcg.user.model.Tb_user_account;
import com.jcg.user.model.Tb_user_recharge;
import com.jcg.user.model.Tb_user_withdrawal_appl;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class StatisticsServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private StatisticsDao statisticsDao;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private UserAccountDao userAccountDao;
    @Autowired
    private NetPointDao netpointDao;
    @Autowired
    private DeviceDao deviceDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private OrderInComeDao orderInComeDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private DeviceLogsDao deviceLogsDao;
    @Autowired
    private AgentRolesRelDao roleRelDao;
    @Autowired
    private UserWithdrawalApplDao userWithdrawalApplDao;
    @Autowired
    private UserRechargeDao userRechargeDao;
    @Autowired
    private OrderCashStreamDao orderCashStreamDao;
    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private DeviceBoxDao deviceBoxDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========StatisticsServiceImpl=========");
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_statistics statistics = new Tb_statistics();
        Page page = new Page();
        if (param != null) {
            statistics = (Tb_statistics)param.get("statistics");
            page = (Page)param.get("page");
        }
        try {
            String sr_way;
            if (XcbConstantValue.STATISTICS_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findStatisticsByParam_agent(identifier, statistics);
            } else if (XcbConstantValue.STATISTICS_LINE_CHART_FIND_BYDAYTYPE.equalsIgnoreCase(functionCode)) {
                sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                ret = this.findLineChartDataByParam(statistics, sr_way);
            } else if (XcbConstantValue.STATISTICS_LINE_CHART_FIND_DATA_BYDAYTYPE.equalsIgnoreCase(functionCode)) {
                sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                ret = this.findLineChartDataByParam(statistics, sr_way);
            }
            if (XcbConstantValue.STATISTICS_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                ret = this.findStatisticsByParam_cpy(identifier, statistics, sr_way);
            } else if (XcbConstantValue.STATISTICS_LINE_CHART_FIND_BYDAYTYPE_CPY.equalsIgnoreCase(functionCode)) {
                sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                ret = this.findLineChartDataByParam_cpy(statistics, sr_way);
            } else if (XcbConstantValue.STATISTICS_RESET_DATA.equalsIgnoreCase(functionCode)) {
                ret = this.reSetData(identifier, statistics);
            } else if (XcbConstantValue.STATISTICS_FIND_DEPOSIT_RATE_BYNET.equalsIgnoreCase(functionCode)) {
                ret = this.findDepositRateByNet(identifier, statistics, page);
            } else if (XcbConstantValue.STATISTICS_FIND_BYPARAM_AGENTMB.equalsIgnoreCase(functionCode)) {
                ret = this.findStatisticsByParam_agentmb(identifier, statistics);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findDepositRateByNet(Identifier identifier, Tb_statistics statistics, Page page) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSr_date_start())) {
                statistics.setSr_date_start(XcbDateUtil.getStartDay((String)statistics.getSr_date_start()));
            }
            if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSr_date_end())) {
                statistics.setSr_date_end(XcbDateUtil.getEndDay((String)statistics.getSr_date_end()));
            }
            List<Map<String, Object>> list = this.statisticsDao.findDepositRateByNet(statistics, page);
            int totalCount = this.statisticsDao.findCountDepositRateByNet(statistics);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("list", list);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.STATISTICS_FIND_DEPOSIT_RATE_BYNET, "\u7f51\u70b9\u6392\u540d\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> reSetData(Identifier identifier, Tb_statistics statistics) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        Integer sw_agent_id = null;
        String sr_agent_name = "";
        try {
            String sr_data_start = statistics.getSr_date_start();
            String sr_data_end = statistics.getSr_date_end();
            if (XcbStringUtils.isNullOrBlank((Object)statistics.getSw_agent_id())) {
                List<Tb_agent> list_agent = this.orderDao.getAllAgent_task();
                if (list_agent != null && list_agent.size() > 0) {
                    for (int i = 0; i < list_agent.size(); ++i) {
                        Tb_agent agent = list_agent.get(i);
                        sw_agent_id = agent.getSd_agent_id();
                        sr_agent_name = agent.getSr_agent_name();
                        result = this.orderService.createStatisticsByDate(identifier, sr_data_start, sr_data_end, sw_agent_id);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) continue;
                        TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                        break;
                    }
                }
            } else {
                Tb_agent agent = this.agentDao.findAgentById_agent(statistics.getSw_agent_id());
                result = this.orderService.createStatisticsByDate(identifier, sr_data_start, sr_data_end, statistics.getSw_agent_id());
            }
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("statistics.reset.success"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("statistics.reset.error"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        }
        catch (Exception e) {
            System.out.println("\u6570\u636e\u5f02\u5e38\u7684\u4ee3\u7406\u5546:" + sw_agent_id + "," + sr_agent_name);
            throw new BusinessException(XcbConstantValue.STATISTICS_RESET_DATA, PromptProperties.getProperty("statistics.reset.error"), (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    public Map<String, Object> findStatisticsByParam_agent(Identifier identifier, Tb_statistics statistics) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            String sr_login_type = statistics.getSr_login_type();
            boolean isNetArr = false;
            Integer sw_agent_id = statistics.getSw_agent_id();
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(statistics.getSw_agent_id());
            if (adminAgent != null && "1".equals(adminAgent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                String[] subArr = new String[subList.size()];
                subList.toArray(subArr);
                statistics.setAgentArr(subArr);
                statistics.setSi_up_agent_id(statistics.getSw_agent_id());
                statistics.setSw_agent_id(null);
                sw_agent_id = adminAgent.getSd_agent_id();
            }
            Map<String, Object> statisticsMap = new HashMap();
            if (adminAgent != null && statistics.getAgentArr() != null && statistics.getAgentArr().length > 0) {
                statisticsMap = CommonFunction.null2HashMap(this.statisticsDao.findSumStatisticsByArr_agent(statistics));
                Tb_order o = new Tb_order();
                o.setAgentArr(statistics.getAgentArr());
                BigDecimal dc_agent_money = XcbStringUtils.getObjToBigDecimal((Object)this.orderInComeDao.findAgentMoneySum(o));
                statisticsMap.put("dc_online_order_money_sum", dc_agent_money);
                Map userSumMap = CommonFunction.null2HashMap(this.statisticsDao.findUserSumByParam(statistics));
                statisticsMap.put("si_shop_person_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                Map refundMap = CommonFunction.null2HashMap(this.statisticsDao.findCountRefundByParam(statistics));
                statisticsMap.put("sr_refund_cnt", XcbStringUtils.getObjtoint(refundMap.get("sr_refund_cnt")));
            } else {
                statisticsMap = CommonFunction.null2HashMap(this.statisticsDao.findSumStatisticsByParam_agent(statistics));
                Map userSumMap = CommonFunction.null2HashMap(this.statisticsDao.findUserSumByParam(statistics));
                statisticsMap.put("si_shop_person_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                Map refundMap = CommonFunction.null2HashMap(this.statisticsDao.findCountRefundByParam(statistics));
                statisticsMap.put("sr_refund_cnt", XcbStringUtils.getObjtoint(refundMap.get("sr_refund_cnt")));
            }
            this.getAgentMoney(sr_login_type, statistics.getSw_company_id(), sw_agent_id, dataMap);
            this.getDeviceInfo(statistics, adminAgent, dataMap);
            this.todayStatistics(statistics, adminAgent, dataMap);
            this.statisticsInfo(statistics, statisticsMap, adminAgent, dataMap, isNetArr);
            this.getBoxCount(statistics, dataMap);
            dataMap.put("statisticsList", statisticsMap);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.STATISTICS_FIND_BYPARAM, PromptProperties.getProperty("statistics.findbyparam.error"), (Throwable)e);
        }
        return ret;
    }

    private void getBoxCount(Tb_statistics statistics, Map<String, Object> dataMap) {
        try {
            Integer ky_cnt = 0;
            Integer zy_cnt = 0;
            Integer jy_cnt = 0;
            Integer jq_cnt = 0;
            ky_cnt = this.deviceBoxDao.findCountDeviceBox(statistics, XcbConstantValue.DEVICE_BOX_STATUS_KY);
            zy_cnt = this.deviceBoxDao.findCountDeviceBox(statistics, XcbConstantValue.DEVICE_BOX_STATUS_ZY);
            jy_cnt = this.deviceBoxDao.findCountDeviceBox(statistics, XcbConstantValue.DEVICE_BOX_STATUS_JY);
            jq_cnt = this.deviceBoxDao.findCountDeviceBox(statistics, XcbConstantValue.DEVICE_BOX_STATUS_JQ);
            dataMap.put("ky_cnt", ky_cnt);
            dataMap.put("zy_cnt", zy_cnt);
            dataMap.put("jy_cnt", jy_cnt);
            dataMap.put("jq_cnt", jq_cnt);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Map<String, Object> findStatisticsByParam_cpy(Identifier identifier, Tb_statistics statistics, String sr_way) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            boolean isNetArr = false;
            String sr_login_type = statistics.getSr_login_type();
            Integer sw_agent_id = statistics.getSw_agent_id();
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(statistics.getSw_agent_id());
            if (adminAgent != null && "1".equals(adminAgent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                subList.add(XcbStringUtils.getObjtoString((Object)statistics.getSw_agent_id()));
                String[] subArr = new String[subList.size()];
                subList.toArray(subArr);
                statistics.setAgentArr(subArr);
                statistics.setSw_agent_id(null);
                sw_agent_id = adminAgent.getSd_agent_id();
            }
            Map statisticsMap = new HashMap();
            statisticsMap = adminAgent != null && statistics.getAgentArr() != null && statistics.getAgentArr().length > 0 ? CommonFunction.null2HashMap(this.statisticsDao.findSumStatisticsByArr_agent(statistics)) : CommonFunction.null2HashMap(this.statisticsDao.findSumStatisticsByParam_agent(statistics));
            TimeInterval queryTime = new TimeInterval();
            queryTime.start();
            this.getAgentMoney(sr_login_type, statistics.getSw_company_id(), sw_agent_id, dataMap);
            System.out.println("\u8d44\u4ea7\u4fe1\u606f:" + queryTime.intervalPretty());
            queryTime = new TimeInterval();
            queryTime.start();
            this.getDeviceInfo(statistics, adminAgent, dataMap);
            System.out.println("\u8bbe\u5907\u4fe1\u606f:" + queryTime.intervalPretty());
            queryTime = new TimeInterval();
            queryTime.start();
            this.todayStatistics(statistics, adminAgent, dataMap);
            System.out.println("\u4eca\u65e5\u4fe1\u606f:" + queryTime.intervalPretty());
            queryTime = new TimeInterval();
            queryTime.start();
            if (!"PC".equals(sr_way)) {
                this.monthStatistics(statistics, adminAgent, dataMap);
                System.out.println("\u5f53\u6708\u4fe1\u606f:" + queryTime.intervalPretty());
                queryTime = new TimeInterval();
                queryTime.start();
            }
            this.statisticsInfo(statistics, statisticsMap, adminAgent, dataMap, isNetArr);
            System.out.println("\u5168\u666f\u4fe1\u606f:" + queryTime.intervalPretty());
            queryTime = new TimeInterval();
            queryTime.start();
            this.getBoxCount(statistics, dataMap);
            System.out.println("\u67dc\u95e8\u4fe1\u606f\u7edf\u8ba1:" + queryTime.intervalPretty());
            dataMap.put("statisticsList", statisticsMap);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.STATISTICS_FIND_BYPARAM, PromptProperties.getProperty("statistics.findbyparam.error"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> findStatisticsByParam_agentmb(Identifier identifier, Tb_statistics statistics) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Map userSumMap;
            String sr_login_type = statistics.getSr_login_type();
            boolean isNetArr = false;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(statistics.getSw_agent_id());
            if (adminAgent != null && "1".equals(adminAgent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                String[] subArr = new String[subList.size()];
                subList.toArray(subArr);
                statistics.setAgentArr(subArr);
                statistics.setSi_up_agent_id(statistics.getSw_agent_id());
                statistics.setSw_agent_id(null);
            }
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                statistics.setSw_agent_id(Integer.valueOf(XcbStringUtils.getObjtoint((Object)adminAgent.getSr_admin_id())));
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                if (netList.size() > 0) {
                    String[] netArr = netList.get(0).split(",");
                    statistics.setNetArr(netArr);
                }
            }
            Map<String, Object> statisticsMap = new HashMap();
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                statisticsMap = CommonFunction.null2HashMap(this.statisticsDao.findSumStatisticsByNetArr_agent(statistics));
                userSumMap = CommonFunction.null2HashMap(this.statisticsDao.findUserSumByParam(statistics));
                statisticsMap.put("si_shop_person_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                Tb_order o = new Tb_order();
                o.setNetArr(statistics.getNetArr());
                BigDecimal dc_agent_money = XcbStringUtils.getObjToBigDecimal((Object)this.orderInComeDao.findShopMoneySumByNetArr(o));
                statisticsMap.put("dc_agent_income_sum", dc_agent_money);
            } else if (adminAgent != null && statistics.getAgentArr() != null && statistics.getAgentArr().length > 0 && "1".equals(adminAgent.getSr_role())) {
                statisticsMap = CommonFunction.null2HashMap(this.statisticsDao.findSumStatisticsByArr_agent(statistics));
                userSumMap = CommonFunction.null2HashMap(this.statisticsDao.findUserSumByParam(statistics));
                statisticsMap.put("si_shop_person_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                Map refundMap = CommonFunction.null2HashMap(this.statisticsDao.findCountRefundByParam(statistics));
                statisticsMap.put("sr_refund_cnt", XcbStringUtils.getObjtoint(refundMap.get("sr_refund_cnt")));
                Tb_order o = new Tb_order();
                o.setAgentArr(statistics.getAgentArr());
                BigDecimal dc_agent_money = XcbStringUtils.getObjToBigDecimal((Object)this.orderInComeDao.findAgentMoneySum(o));
                statisticsMap.put("dc_agent_income_sum", dc_agent_money);
            } else {
                statisticsMap = CommonFunction.null2HashMap(this.statisticsDao.findSumStatisticsByParam_agent(statistics));
                userSumMap = CommonFunction.null2HashMap(this.statisticsDao.findUserSumByParam(statistics));
                statisticsMap.put("si_shop_person_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                Tb_order o = new Tb_order();
                o.setSw_agent_id(statistics.getSw_agent_id());
                BigDecimal dc_agent_money = XcbStringUtils.getObjToBigDecimal((Object)this.orderInComeDao.findShopMoneySum(o));
                statisticsMap.put("dc_agent_income_sum", dc_agent_money);
            }
            Map refundMap = CommonFunction.null2HashMap(this.statisticsDao.findCountRefundByParam(statistics));
            statisticsMap.put("sr_refund_cnt", XcbStringUtils.getObjtoint(refundMap.get("sr_refund_cnt")));
            this.getAgentMoney(sr_login_type, statistics.getSw_company_id(), statistics.getSw_agent_id(), dataMap);
            this.getDeviceInfo(statistics, adminAgent, dataMap);
            this.todayStatistics(statistics, adminAgent, dataMap);
            this.monthStatistics(statistics, adminAgent, dataMap);
            this.statisticsInfo(statistics, statisticsMap, adminAgent, dataMap, isNetArr);
            dataMap.put("statisticsList", statisticsMap);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.STATISTICS_FIND_BYPARAM_AGENTMB, PromptProperties.getProperty("statistics.findbyparam.error"), (Throwable)e);
        }
        return ret;
    }

    public void getAgentMoney(String sr_login_type, String sw_company_id, Integer sw_agent_id, Map<String, Object> dataMap) throws Exception {
        try {
            Tb_agent a = new Tb_agent();
            a.setSw_company_id(sw_company_id);
            a.setSd_agent_id(sw_agent_id);
            String sr_is_ad = "N";
            String sr_ad_income_date = "2";
            BigDecimal dc_ad_max_money = BigDecimal.ZERO;
            Map agentMap = CommonFunction.null2HashMap(this.agentDao.findSumAgentMoney_agent(a));
            if (!XcbStringUtils.isNullOrBlank((Object)sw_agent_id)) {
                Tb_agent agent = this.agentDao.findAgentById_agent(sw_agent_id);
                sr_is_ad = agent.getSr_is_ad();
                sr_ad_income_date = agent.getSr_ad_income_date();
                dataMap.put("agent", agent);
                String start_day = XcbDateUtil.getCurrentMonthFirst();
                String end_day = XcbDateUtil.getEndDay((String)XcbDateUtil.getBeforeDay((Date)new Date(), (int)1, (String)"yyyy-MM-dd"));
                BigDecimal this_month = BigDecimal.ZERO;
                if ("1".equals(agent.getSr_role())) {
                    List<String> subList = this.agentDao.findSubAgentList(agent.getSd_agent_id());
                    String[] subArr = new String[subList.size()];
                    subList.toArray(subArr);
                    this_month = this.orderDao.findShowNowMonthAdMoney(subArr, start_day, end_day);
                } else if ("2".equals(agent.getSr_role())) {
                    this_month = this.orderDao.findNowMonthAdMoney(agent.getSd_agent_id(), start_day, end_day);
                }
                dc_ad_max_money = BigDecimalUtil.sub((BigDecimal)agent.getDc_ad_money(), (BigDecimal)this_month);
            } else {
                sr_is_ad = "Y";
            }
            BigDecimal txMoney = XcbStringUtils.getObjToBigDecimal(agentMap.get("dc_tx_money_sum"));
            BigDecimal agentMoney = XcbStringUtils.getObjToBigDecimal(agentMap.get("dc_agent_money_sum"));
            BigDecimal cbMoney = XcbStringUtils.getObjToBigDecimal(agentMap.get("dc_cb_money_sum"));
            BigDecimal adMoney = XcbStringUtils.getObjToBigDecimal(agentMap.get("dc_ad_money_sum"));
            BigDecimal maxMoney = XcbStringUtils.getObjToBigDecimal(agentMap.get("dc_max_money_sum"));
            dataMap.put("txMoney", XcbStringUtils.getObjtoString((Object)txMoney));
            dataMap.put("cbMoney", XcbStringUtils.getObjtoString((Object)cbMoney));
            dataMap.put("adMoney", XcbStringUtils.getObjtoString((Object)adMoney));
            dataMap.put("agentMoney", XcbStringUtils.getObjtoString((Object)agentMoney));
            dataMap.put("maxMoney", XcbStringUtils.getObjtoString((Object)maxMoney));
            dataMap.put("adMaxMoney", XcbStringUtils.getObjtoString((Object)dc_ad_max_money));
            dataMap.put("sumMoney", agentMoney.add(adMoney).toString());
            if ("Y".equals(sr_is_ad)) {
                dataMap.put("onlineInCome", txMoney.add(cbMoney).add(agentMoney).add(adMoney).toString());
            } else {
                dataMap.put("onlineInCome", txMoney.add(cbMoney).add(agentMoney).toString());
            }
        }
        catch (Exception e) {
            throw new Exception(e);
        }
    }

    /*
     * WARNING - void declaration
     */
    private void getDeviceInfo(Tb_statistics statistics, Tb_agent adminAgent, Map<String, Object> dataMap) throws Exception {
        try {
            Integer devCnt;
            Integer netCnt;
            Tb_netpoint n = new Tb_netpoint();
            n.setSw_company_id(statistics.getSw_company_id());
            n.setSw_agent_id(statistics.getSw_agent_id());
            n.setAgentArr(statistics.getAgentArr());
            Tb_device d = new Tb_device();
            d.setSw_company_id(statistics.getSw_company_id());
            d.setSw_agent_id(statistics.getSw_agent_id());
            d.setAgentArr(statistics.getAgentArr());
            Tb_device_box b = new Tb_device_box();
            b.setSw_agent_id(statistics.getSw_agent_id());
            Map obj10 = new HashMap();
            Map obj11 = new HashMap();
            Map today_dev = new HashMap();
            List<Object> list_net = new ArrayList();
            List<Object> list_net_JY = new ArrayList();
            List<Object> list_net_ZY = new ArrayList();
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                String[] netArr = netList.get(0).split(",");
                n.setNetArr(netArr);
                d.setNetArr(netArr);
                b.setNetArr(netArr);
                obj10 = CommonFunction.null2HashMap(this.netpointDao.findCountNetPointByNetArr_agent(n));
                obj11 = CommonFunction.null2HashMap(this.deviceDao.findCountDeviceByNetArr_agent(d));
                today_dev = CommonFunction.null2HashMap(this.deviceDao.findCountDeviceOffLineByNetArr_agent(d));
                list_net = this.deviceBoxDao.findListByNetArr(b);
                b.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_JY);
                list_net_JY = this.deviceBoxDao.findListByNetArr(b);
                Tb_order tb_order = new Tb_order();
                tb_order.setNetArr(netArr);
                tb_order.setSr_order_starttime(XcbDateUtil.getTodayZero((Date)new Date()));
                tb_order.setSr_order_endtime(XcbDateUtil.getTodayEnd((Date)new Date()));
                list_net_ZY = this.orderDao.findNetListByNetArr(tb_order);
                for (Map map : list_net) {
                    void var19_29;
                    Integer netid;
                    Integer sw_netpoint_id = XcbStringUtils.getObjtoint(map.get("sw_netpoint_id"));
                    Integer n2 = XcbStringUtils.getObjtoint(map.get("cnt"));
                    for (Map map2 : list_net_JY) {
                        void var19_31;
                        netid = XcbStringUtils.getObjtoint(map2.get("sw_netpoint_id"));
                        Integer cnt_jy = XcbStringUtils.getObjtoint(map2.get("cnt"));
                        if (!sw_netpoint_id.equals(netid)) continue;
                        Integer n3 = var19_31.intValue() - cnt_jy;
                    }
                    for (Map map3 : list_net_ZY) {
                        netid = XcbStringUtils.getObjtoint(map3.get("sw_netpoint_id"));
                        Integer cnt_zy = XcbStringUtils.getObjtoint(map3.get("cnt"));
                        if (!sw_netpoint_id.equals(netid)) continue;
                        Integer n4 = var19_29.intValue() - cnt_zy;
                    }
                    map.put("cnt", var19_29);
                }
            } else {
                obj10 = CommonFunction.null2HashMap(this.netpointDao.findCountNetPointByAgentId_agent(n));
                obj11 = CommonFunction.null2HashMap(this.deviceDao.findCountDeviceByAgentId_agent(d));
                today_dev = CommonFunction.null2HashMap(this.deviceDao.findCountDeviceOffLineByAgentId_agent(d));
                list_net = this.deviceBoxDao.findListByAgentId(b);
                b.setSr_box_status(XcbConstantValue.DEVICE_BOX_STATUS_JY);
                list_net_JY = this.deviceBoxDao.findListByAgentId(b);
                Tb_order o = new Tb_order();
                o.setSw_agent_id(statistics.getSw_agent_id());
                o.setSr_order_starttime(XcbDateUtil.getTodayZero((Date)new Date()));
                o.setSr_order_endtime(XcbDateUtil.getTodayEnd((Date)new Date()));
                list_net_ZY = this.orderDao.findNetListByAgentId(o);
                for (Map map : list_net) {
                    void var17_22;
                    Integer netid;
                    Integer sw_netpoint_id = XcbStringUtils.getObjtoint(map.get("sw_netpoint_id"));
                    Integer n5 = XcbStringUtils.getObjtoint(map.get("cnt"));
                    for (Map map4 : list_net_JY) {
                        void var17_24;
                        netid = XcbStringUtils.getObjtoint(map4.get("sw_netpoint_id"));
                        Integer n6 = XcbStringUtils.getObjtoint(map4.get("cnt"));
                        if (!sw_netpoint_id.equals(netid)) continue;
                        Integer n7 = var17_24.intValue() - n6;
                    }
                    for (Map map5 : list_net_ZY) {
                        netid = XcbStringUtils.getObjtoint(map5.get("sw_netpoint_id"));
                        Integer n8 = XcbStringUtils.getObjtoint(map5.get("cnt"));
                        if (!sw_netpoint_id.equals(netid)) continue;
                        Integer n9 = var17_22.intValue() - n8;
                    }
                    map.put("cnt", var17_22);
                }
            }
            Integer n10 = ObjectUtil.isNotEmpty(obj10) ? (obj10.get("net_cnt") == null ? new Integer(0) : Integer.valueOf(obj10.get("net_cnt").toString())) : (netCnt = new Integer(0));
            Integer n11 = ObjectUtil.isNotEmpty(obj11) ? (obj11.get("dev_cnt") == null ? new Integer(0) : Integer.valueOf(obj11.get("dev_cnt").toString())) : (devCnt = new Integer(0));
            Integer n12 = ObjectUtil.isNotEmpty(today_dev) ? (today_dev.get("dev_offline_cnt") == null ? new Integer(0) : Integer.valueOf(today_dev.get("dev_offline_cnt").toString())) : new Integer(0);
            Integer today_dev_on_cnt = devCnt - n12;
            dataMap.put("list_net", list_net);
            dataMap.put("netCnt", netCnt);
            dataMap.put("devCnt", devCnt);
            dataMap.put("today_dev_off_cnt", n12);
            dataMap.put("today_dev_on_cnt", today_dev_on_cnt);
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    private void todayStatistics(Tb_statistics statistics, Tb_agent adminAgent, Map<String, Object> dataMap) throws Exception {
        try {
            String[] netArr = null;
            String todayZero = XcbDateUtil.getTodayZero((Date)new Date());
            String todayEnd = XcbDateUtil.getTodayEnd((Date)new Date());
            Map<String, Integer> orderMap = new HashMap();
            Map adMoneyMap = new HashMap();
            Tb_order o = new Tb_order();
            if (statistics.getAgentArr() != null && statistics.getAgentArr().length > 0) {
                o.setAgentArr(statistics.getAgentArr());
            } else {
                o.setSw_agent_id(statistics.getSw_agent_id());
            }
            o.setSw_company_id(statistics.getSw_company_id());
            o.setSw_netpoint_id(statistics.getSw_netpoint_id());
            o.setSw_device_id(statistics.getSw_device_id());
            o.setSr_order_time_start(todayZero);
            o.setSr_order_time_end(todayEnd);
            o.setSr_date_type(statistics.getSr_date_type());
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                Tb_agent a = this.agentDao.findAgentById_agent(XcbStringUtils.getObjtoint((Object)adminAgent.getSr_admin_id()));
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                netArr = netList.get(0).split(",");
                o.setNetArr(netArr);
                orderMap = CommonFunction.null2HashMap(this.orderDao.findOrderGroupByNetArr(o));
                Map userSumMap = CommonFunction.null2HashMap(this.orderDao.findUserSumByParam(o));
                orderMap.put("sr_user_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                Map refundMap = CommonFunction.null2HashMap(this.orderDao.findCountRefundByArr(o));
                orderMap.put("sr_refund_cnt", XcbStringUtils.getObjtoint(refundMap.get("sr_refund_cnt")));
            } else {
                BigDecimal dc_order_money;
                Map refundMap;
                Map userSumMap;
                if (adminAgent != null && "1".equals(adminAgent.getSr_role())) {
                    orderMap = CommonFunction.null2HashMap(this.orderDao.findShowOrderGroupByParam(o));
                    userSumMap = CommonFunction.null2HashMap(this.orderDao.findUserSumByParam(o));
                    orderMap.put("sr_user_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                    refundMap = CommonFunction.null2HashMap(this.orderDao.findCountRefundByParam(o));
                    orderMap.put("sr_refund_cnt", XcbStringUtils.getObjtoint(refundMap.get("sr_refund_cnt")));
                } else if (adminAgent != null && "2".equals(adminAgent.getSr_role())) {
                    orderMap = CommonFunction.null2HashMap(this.orderDao.findOrderGroupByParam(o));
                    userSumMap = CommonFunction.null2HashMap(this.orderDao.findUserSumByParam(o));
                    orderMap.put("sr_user_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                    refundMap = CommonFunction.null2HashMap(this.orderDao.findCountRefundByParam(o));
                    orderMap.put("sr_refund_cnt", XcbStringUtils.getObjtoint(refundMap.get("sr_refund_cnt")));
                } else {
                    orderMap = CommonFunction.null2HashMap(this.orderDao.findOrderGroupByParam(o));
                    if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSw_company_id())) {
                        userSumMap = CommonFunction.null2HashMap(this.orderDao.findUserSumByParam(o));
                        orderMap.put("sr_user_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                        adMoneyMap = CommonFunction.null2HashMap(this.orderDao.findAdOrderGroupByParam(o));
                        BigDecimal dc_ad_money_sum = XcbStringUtils.getObjToBigDecimal(adMoneyMap.get("dc_ad_money_sum"));
                        BigDecimal dc_up_ad_money_sum = XcbStringUtils.getObjToBigDecimal(adMoneyMap.get("dc_up_ad_money_sum"));
                        orderMap.put("dc_ad_money_sum", (Integer)((Object)dc_ad_money_sum));
                        orderMap.put("dc_up_ad_money_sum", (Integer)((Object)dc_up_ad_money_sum));
                    }
                }
                if (statistics.getAgentArr() != null && statistics.getAgentArr().length > 0) {
                    dc_order_money = XcbStringUtils.getObjToBigDecimal((Object)this.orderInComeDao.findAgentMoneySum(o));
                    orderMap.put("dc_agent_income_sum", (Integer)((Object)dc_order_money));
                } else {
                    dc_order_money = XcbStringUtils.getObjToBigDecimal((Object)this.orderInComeDao.findShopMoneySum(o));
                    orderMap.put("dc_agent_income_sum", (Integer)((Object)dc_order_money));
                }
            }
            Integer today_shopUserCnt = XcbStringUtils.getObjtoint(orderMap.get("sr_user_sum"));
            Integer today_refundCnt = XcbStringUtils.getObjtoint(orderMap.get("sr_refund_cnt"));
            Integer today_onlineOrderCnt = XcbStringUtils.getObjtoint(orderMap.get("cnt"));
            BigDecimal today_onlineOrderMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_actual_income_sum"));
            BigDecimal today_orderIncomeMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_agent_income_sum"));
            BigDecimal today_refundOrderMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_refund_money_sum"));
            BigDecimal today_depositRefundMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_deposit_refund_sum"));
            BigDecimal today_adMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_ad_money_sum"));
            BigDecimal today_upAdMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_up_ad_money_sum"));
            if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSw_company_id())) {
                Map userApplMap = CommonFunction.null2HashMap(this.userWithdrawalApplDao.findSumUserWithdrawalAppl(statistics.getSw_company_id(), todayZero, todayEnd));
                BigDecimal today_userTxSum = XcbStringUtils.getObjToBigDecimal(userApplMap.get("dc_appl_money_sum"));
                dataMap.put("today_userTxSum", today_userTxSum);
                Map userRechargeMap = CommonFunction.null2HashMap(this.userRechargeDao.findSumUserRecharge(statistics.getSw_company_id(), todayZero, todayEnd));
                BigDecimal today_userRechargeSum = XcbStringUtils.getObjToBigDecimal(userRechargeMap.get("dc_recharge_money_sum"));
                dataMap.put("today_userRechargeSum", today_userRechargeSum);
                Integer today_registUserCnt = XcbStringUtils.getObjtoint(orderMap.get("reg_cnt"));
                dataMap.put("today_registUserCnt", today_registUserCnt);
            }
            dataMap.put("today_shopUserCnt", today_shopUserCnt);
            dataMap.put("today_refundCnt", today_refundCnt);
            dataMap.put("today_onlineOrderCnt", today_onlineOrderCnt);
            dataMap.put("today_onlineOrderMoney", XcbStringUtils.getObjtoString((Object)today_onlineOrderMoney));
            dataMap.put("today_orderIncomeMoney", XcbStringUtils.getObjtoString((Object)today_orderIncomeMoney));
            dataMap.put("today_refundOrderMoney", XcbStringUtils.getObjtoString((Object)today_refundOrderMoney));
            dataMap.put("today_depositRefundMoney", XcbStringUtils.getObjtoString((Object)today_depositRefundMoney));
            dataMap.put("today_adMoney", XcbStringUtils.getObjtoString((Object)today_adMoney));
            dataMap.put("today_upAdMoney", XcbStringUtils.getObjtoString((Object)today_upAdMoney));
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    private void monthStatistics(Tb_statistics statistics, Tb_agent adminAgent, Map<String, Object> dataMap) throws Exception {
        try {
            String[] netArr = null;
            String startDays = XcbDateUtil.getYear() + "-" + XcbDateUtil.getMonth() + "-01 00:00:00";
            String endDays = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss");
            Map<String, Integer> orderMap = new HashMap();
            Map adMoneyMap = new HashMap();
            Tb_order o = new Tb_order();
            if (statistics.getAgentArr() != null && statistics.getAgentArr().length > 0) {
                o.setAgentArr(statistics.getAgentArr());
            } else {
                o.setSw_agent_id(statistics.getSw_agent_id());
            }
            o.setSw_company_id(statistics.getSw_company_id());
            o.setSw_netpoint_id(statistics.getSw_netpoint_id());
            o.setSw_device_id(statistics.getSw_device_id());
            o.setSr_order_time_start(startDays);
            o.setSr_order_time_end(endDays);
            o.setSr_date_type(statistics.getSr_date_type());
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                Tb_agent a = this.agentDao.findAgentById_agent(XcbStringUtils.getObjtoint((Object)adminAgent.getSr_admin_id()));
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                netArr = netList.get(0).split(",");
                o.setNetArr(netArr);
                orderMap = CommonFunction.null2HashMap(this.orderDao.findOrderGroupByNetArr(o));
                Map userSumMap = CommonFunction.null2HashMap(this.orderDao.findUserSumByParam(o));
                orderMap.put("sr_user_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                Map refundMap = CommonFunction.null2HashMap(this.orderDao.findCountRefundByArr(o));
                orderMap.put("sr_refund_cnt", XcbStringUtils.getObjtoint(refundMap.get("sr_refund_cnt")));
            } else {
                BigDecimal dc_order_money;
                Map userSumMap;
                if (adminAgent != null && "1".equals(adminAgent.getSr_role())) {
                    orderMap = CommonFunction.null2HashMap(this.orderDao.findShowOrderGroupByParam(o));
                    userSumMap = CommonFunction.null2HashMap(this.orderDao.findUserSumByParam(o));
                    orderMap.put("sr_user_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                    Map refundMap = CommonFunction.null2HashMap(this.orderDao.findCountRefundByParam(o));
                    orderMap.put("sr_refund_cnt", XcbStringUtils.getObjtoint(refundMap.get("sr_refund_cnt")));
                } else if (adminAgent != null && "2".equals(adminAgent.getSr_role())) {
                    orderMap = CommonFunction.null2HashMap(this.orderDao.findOrderGroupByParam(o));
                    userSumMap = CommonFunction.null2HashMap(this.orderDao.findUserSumByParam(o));
                    orderMap.put("sr_user_sum", XcbStringUtils.getObjtoint(userSumMap.get("sr_user_sum")));
                    Map refundMap = CommonFunction.null2HashMap(this.orderDao.findCountRefundByParam(o));
                    orderMap.put("sr_refund_cnt", XcbStringUtils.getObjtoint(refundMap.get("sr_refund_cnt")));
                } else {
                    orderMap = CommonFunction.null2HashMap(this.orderDao.findOrderGroupByParam(o));
                    if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSw_company_id())) {
                        Map tempMap = CommonFunction.null2HashMap(this.orderDao.findAdCountByParam_cpy(o));
                        int sr_user_sum = XcbStringUtils.getObjtoint(tempMap.get("sr_user_sum"));
                        orderMap.put("reg_cnt", sr_user_sum);
                        adMoneyMap = CommonFunction.null2HashMap(this.orderDao.findAdOrderGroupByParam(o));
                        BigDecimal dc_ad_money_sum = XcbStringUtils.getObjToBigDecimal(adMoneyMap.get("dc_ad_money_sum"));
                        BigDecimal dc_up_ad_money_sum = XcbStringUtils.getObjToBigDecimal(adMoneyMap.get("dc_up_ad_money_sum"));
                        orderMap.put("dc_ad_money_sum", (Integer)((Object)dc_ad_money_sum));
                        orderMap.put("dc_up_ad_money_sum", (Integer)((Object)dc_up_ad_money_sum));
                    }
                }
                if (statistics.getAgentArr() != null && statistics.getAgentArr().length > 0) {
                    dc_order_money = XcbStringUtils.getObjToBigDecimal((Object)this.orderInComeDao.findAgentMoneySum(o));
                    orderMap.put("dc_agent_income_sum", (Integer)((Object)dc_order_money));
                } else {
                    dc_order_money = XcbStringUtils.getObjToBigDecimal((Object)this.orderInComeDao.findShopMoneySum(o));
                    orderMap.put("dc_agent_income_sum", (Integer)((Object)dc_order_money));
                }
            }
            Integer month_shopUserCnt = XcbStringUtils.getObjtoint(orderMap.get("sr_user_sum"));
            Integer month_refundCnt = XcbStringUtils.getObjtoint(orderMap.get("sr_refund_cnt"));
            Integer month_onlineOrderCnt = XcbStringUtils.getObjtoint(orderMap.get("cnt"));
            BigDecimal month_onlineOrderMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_actual_income_sum"));
            BigDecimal month_orderIncomeMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_agent_income_sum"));
            BigDecimal month_refundOrderMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_refund_money_sum"));
            BigDecimal month_depositRefundMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_deposit_refund_sum"));
            BigDecimal month_adMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_ad_money_sum"));
            BigDecimal month_upAdMoney = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_up_ad_money_sum"));
            if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSw_company_id())) {
                Map userApplMap = CommonFunction.null2HashMap(this.userWithdrawalApplDao.findSumUserWithdrawalAppl(statistics.getSw_company_id(), startDays, endDays));
                BigDecimal month_userTxSum = XcbStringUtils.getObjToBigDecimal(userApplMap.get("dc_appl_money_sum"));
                dataMap.put("month_userTxSum", month_userTxSum);
                Map userRechargeMap = CommonFunction.null2HashMap(this.userRechargeDao.findSumUserRecharge(statistics.getSw_company_id(), startDays, endDays));
                BigDecimal month_userRechargeSum = XcbStringUtils.getObjToBigDecimal(userRechargeMap.get("dc_recharge_money_sum"));
                dataMap.put("month_userRechargeSum", month_userRechargeSum);
                Integer month_registUserCnt = XcbStringUtils.getObjtoint(orderMap.get("reg_cnt"));
                dataMap.put("month_registUserCnt", month_registUserCnt);
            }
            dataMap.put("month_refundCnt", month_refundCnt);
            dataMap.put("month_shopUserCnt", month_shopUserCnt);
            dataMap.put("month_onlineOrderCnt", month_onlineOrderCnt);
            dataMap.put("month_onlineOrderMoney", XcbStringUtils.getObjtoString((Object)month_onlineOrderMoney));
            dataMap.put("month_orderIncomeMoney", XcbStringUtils.getObjToBigDecimal((Object)month_orderIncomeMoney));
            dataMap.put("month_refundOrderMoney", XcbStringUtils.getObjtoString((Object)month_refundOrderMoney));
            dataMap.put("month_depositRefundMoney", XcbStringUtils.getObjtoString((Object)month_depositRefundMoney));
            dataMap.put("month_adMoney", XcbStringUtils.getObjtoString((Object)month_adMoney));
            dataMap.put("month_upAdMoney", XcbStringUtils.getObjtoString((Object)month_upAdMoney));
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
            this.log.info(e.getMessage());
        }
    }

    private void statisticsInfo(Tb_statistics statistics, Map<String, Object> statisticsMap, Tb_agent adminAgent, Map<String, Object> dataMap, boolean isNetArr) throws Exception {
        try {
            Integer registerUserCount = 0;
            if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSw_company_id())) {
                Map userAccountMap = new HashMap();
                Tb_user_account ua = new Tb_user_account();
                ua.setSw_company_id(statistics.getSw_company_id());
                ua.setSw_agent_id(statistics.getSw_agent_id());
                CompletableFuture<Map> userAccountMapFuture = CompletableFuture.supplyAsync(() -> CommonFunction.null2HashMap(this.userAccountDao.findAccountMoneyByCompanyId(ua)));
                registerUserCount = this.userDao.findCountByCompanyId(statistics.getSw_company_id());
                CompletableFuture<Integer> registerUserCountFuture = CompletableFuture.supplyAsync(() -> this.userDao.findCountByCompanyId(statistics.getSw_company_id()));
                userAccountMap = userAccountMapFuture.get();
                registerUserCount = registerUserCountFuture.get();
                BigDecimal userAccountSum = XcbStringUtils.getObjToBigDecimal(userAccountMap.get("dc_account_money_sum"));
                BigDecimal onlineAwardSum = XcbStringUtils.getObjToBigDecimal(userAccountMap.get("dc_present_money_sum"));
                BigDecimal remarkAccountSum = XcbStringUtils.getObjToBigDecimal(userAccountMap.get("dc_remark_money_sum"));
                BigDecimal userTxSum = BigDecimal.ZERO;
                BigDecimal userDSPTxSum = BigDecimal.ZERO;
                BigDecimal depositRefundSum = BigDecimal.ZERO;
                BigDecimal rechargeSum = BigDecimal.ZERO;
                Map userApplMap = new HashMap();
                CompletableFuture<Map> userApplMapFuture = CompletableFuture.supplyAsync(() -> CommonFunction.null2HashMap(this.userWithdrawalApplDao.findSumUserWithdrawalAppl(statistics.getSw_company_id(), null, null)));
                userApplMap = userApplMapFuture.get();
                userTxSum = XcbStringUtils.getObjToBigDecimal(userApplMap.get("dc_appl_money_sum"));
                Map userDSPApplMap = new HashMap();
                CompletableFuture<Map> userDSPApplMapFuture = CompletableFuture.supplyAsync(() -> CommonFunction.null2HashMap(this.userWithdrawalApplDao.findSumDSPUserWithdrawalAppl(statistics.getSw_company_id(), null, null)));
                userDSPApplMap = userDSPApplMapFuture.get();
                userDSPTxSum = XcbStringUtils.getObjToBigDecimal(userDSPApplMap.get("dc_appl_money_sum"));
                Map orderMap = new HashMap();
                CompletableFuture<Map> orderMapFuture = CompletableFuture.supplyAsync(() -> CommonFunction.null2HashMap(this.orderDao.findSumDepositRefund(statistics.getSw_company_id())));
                orderMap = orderMapFuture.get();
                depositRefundSum = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_deposit_refund_sum"));
                Map userRechargeMap = new HashMap();
                CompletableFuture<Map> userRechargeMapFuture = CompletableFuture.supplyAsync(() -> CommonFunction.null2HashMap(this.userRechargeDao.findSumUserRechargeByCompany(statistics.getSw_company_id())));
                userRechargeMap = userRechargeMapFuture.get();
                rechargeSum = XcbStringUtils.getObjToBigDecimal(userRechargeMap.get("dc_recharge_money_sum"));
                dataMap.put("userAccountSum", XcbStringUtils.getObjtoString((Object)userAccountSum));
                dataMap.put("onlineAwardSum", XcbStringUtils.getObjtoString((Object)onlineAwardSum));
                dataMap.put("remarkAccountSum", XcbStringUtils.getObjtoString((Object)remarkAccountSum));
                dataMap.put("userTxSum", XcbStringUtils.getObjtoString((Object)userTxSum));
                dataMap.put("userDSPTxSum", XcbStringUtils.getObjtoString((Object)userDSPTxSum));
                dataMap.put("rechargeSum", XcbStringUtils.getObjtoString((Object)rechargeSum));
                dataMap.put("depositRefundSum", XcbStringUtils.getObjtoString((Object)depositRefundSum));
            } else {
                registerUserCount = XcbStringUtils.getObjtoint((Object)statisticsMap.get("si_register_person_sum"));
            }
            Integer onlineOrderCount = XcbStringUtils.getObjtoint((Object)statisticsMap.get("si_online_order_count_sum"));
            BigDecimal onlineOrderMoney = XcbStringUtils.getObjToBigDecimal((Object)statisticsMap.get("dc_online_order_money_sum"));
            BigDecimal orderIncomeMoney = XcbStringUtils.getObjToBigDecimal((Object)statisticsMap.get("dc_agent_income_sum"));
            BigDecimal onlineTkMoney = XcbStringUtils.getObjToBigDecimal((Object)statisticsMap.get("dc_online_tk_money_sum"));
            Integer onlineTkCnt = XcbStringUtils.getObjtoint((Object)statisticsMap.get("sr_refund_cnt"));
            Integer userCount = XcbStringUtils.getObjtoint((Object)statisticsMap.get("si_shop_person_sum"));
            BigDecimal adMoneySum = XcbStringUtils.getObjToBigDecimal((Object)statisticsMap.get("dc_ad_money_sum"));
            BigDecimal upAdMoneySum = XcbStringUtils.getObjToBigDecimal((Object)statisticsMap.get("dc_up_ad_money_sum"));
            dataMap.put("onlineTkMoney", XcbStringUtils.getObjtoString((Object)onlineTkMoney));
            dataMap.put("onlineTkCnt", XcbStringUtils.getObjtoString((Object)onlineTkCnt));
            dataMap.put("userCount", XcbStringUtils.getObjtoString((Object)userCount));
            dataMap.put("registerUserCount", XcbStringUtils.getObjtoString((Object)registerUserCount));
            dataMap.put("onlineOrderCount", XcbStringUtils.getObjtoString((Object)onlineOrderCount));
            dataMap.put("onlineOrderMoney", XcbStringUtils.getObjtoString((Object)onlineOrderMoney));
            dataMap.put("orderIncomeMoney", XcbStringUtils.getObjtoString((Object)orderIncomeMoney));
            dataMap.put("adMoneySum", XcbStringUtils.getObjtoString((Object)adMoneySum));
            dataMap.put("upAdMoneySum", XcbStringUtils.getObjtoString((Object)upAdMoneySum));
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    private Map<String, Object> findLineChartDataByParam(Tb_statistics statistics, String sr_way) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(statistics.getSw_agent_id());
            if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSr_date_start())) {
                statistics.setSr_date_start(XcbDateUtil.getStartDay((String)statistics.getSr_date_start()));
            }
            if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSr_date_end())) {
                statistics.setSr_date_end(XcbDateUtil.getEndDay((String)statistics.getSr_date_end()));
            }
            if (adminAgent != null && "1".equals(adminAgent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                subList.add(XcbStringUtils.getObjtoString((Object)statistics.getSw_agent_id()));
                String[] subArr = new String[subList.size()];
                subList.toArray(subArr);
                statistics.setAgentArr(subArr);
                statistics.setSi_up_agent_id(statistics.getSw_agent_id());
                statistics.setSw_agent_id(null);
            }
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                String[] netArr = netList.get(0).split(",");
                statistics.setNetArr(netArr);
            }
            List<Object> orderList = new ArrayList();
            ArrayList<Tb_statistics> adList = new ArrayList();
            ArrayList<Tb_statistics> refundList = new ArrayList();
            ArrayList<Tb_statistics> userList = new ArrayList();
            orderList = adminAgent != null && "1".equals(adminAgent.getSr_role()) ? this.statisticsDao.findShowOnlineOrderDataByParam(statistics) : (adminAgent != null && "2".equals(adminAgent.getSr_role()) ? this.statisticsDao.findOnlineOrderDataByParam(statistics) : (adminAgent != null && "4".equals(adminAgent.getSr_role()) ? this.statisticsDao.findOnlineOrderDataByParam(statistics) : this.statisticsDao.findOnlineOrderDataByParam(statistics)));
            adList = this.statisticsDao.findAdOrderDataByParam(statistics);
            refundList = this.statisticsDao.findRefundOrderDataByParam(statistics);
            userList = this.statisticsDao.findUserCntByParam(statistics);
            boolean isSort = false;
            if ("AGENTMB".equals(sr_way)) {
                isSort = true;
            }
            this.DateCommend(adminAgent, statistics, orderList, adList, refundList, userList, dataMap, isSort);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.STATISTICS_LINE_CHART_FIND_DATA_BYDAYTYPE, PromptProperties.getProperty("statistics.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findLineChartDataByParam_cpy(Tb_statistics statistics, String sr_way) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        ArrayList<Tb_statistics> orderList = new ArrayList();
        List<Object> registUserList = new ArrayList();
        try {
            Tb_agent adminAgent;
            if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSr_date_start())) {
                statistics.setSr_date_start(XcbDateUtil.getStartDay((String)statistics.getSr_date_start()));
            }
            if (!XcbStringUtils.isNullOrBlank((Object)statistics.getSr_date_end())) {
                statistics.setSr_date_end(XcbDateUtil.getEndDay((String)statistics.getSr_date_end()));
            }
            if ((adminAgent = this.agentDao.findAgentById_agent(statistics.getSw_agent_id())) != null && "1".equals(adminAgent.getSr_role())) {
                List<String> subList = this.agentDao.findSubAgentList(adminAgent.getSd_agent_id());
                subList.add(XcbStringUtils.getObjtoString((Object)statistics.getSw_agent_id()));
                String[] subArr = new String[subList.size()];
                subList.toArray(subArr);
                statistics.setAgentArr(subArr);
                statistics.setSw_agent_id(null);
            }
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                String[] netArr = netList.get(0).split(",");
                statistics.setNetArr(netArr);
            }
            orderList = this.statisticsDao.findOnlineOrderDataByParam_cpy(statistics);
            registUserList = this.statisticsDao.findUserRegistRptByParam_agent(statistics);
            dataMap.put("registUserList", registUserList);
            int registUserSum = 0;
            Tb_user user = new Tb_user();
            user.setSw_agent_id(statistics.getSw_agent_id());
            user.setSw_netpoint_id(statistics.getSw_netpoint_id());
            user.setSr_register_device(statistics.getSw_device_id());
            user.setSr_date_start(statistics.getSr_date_start());
            user.setSr_date_end(statistics.getSr_date_end());
            user.setSr_date_type(statistics.getSr_date_type());
            registUserSum = this.userDao.findSumUserRegistRptByParam_agent(user);
            dataMap.put("registUserSum", registUserSum);
            List<Tb_user_recharge> sumRechargeList = null;
            List<Tb_user_withdrawal_appl> sumApplList = null;
            List<Tb_order> sumAdList = null;
            List<Tb_order> sumUpAdList = null;
            List<Tb_order> sumUserList = null;
            List<Map<String, Object>> userRechargeList = this.userRechargeDao.findDateRechargeMoneyByParam(statistics);
            sumRechargeList = this.getDateRangeSumRechargeList(userRechargeList, statistics.getSr_date_type());
            List<Map<String, Object>> userApplList = this.orderDao.findDateApplMoneyByParam(statistics);
            sumApplList = this.getDateRangeSumUserApplList(userApplList, statistics.getSr_date_type());
            List<Map<String, Object>> adMoneyList = this.orderDao.findDateAdMoneyByParam(statistics);
            sumAdList = this.getDateRangeSumAdMoneyList(adMoneyList, statistics.getSr_date_type());
            List<Map<String, Object>> upAdMoneyList = this.orderDao.findDateUpAdMoneyByParam(statistics);
            sumUpAdList = this.getDateRangeSumUpAdMoneyList(upAdMoneyList, statistics.getSr_date_type());
            List<Map<String, Object>> userCntList = this.orderDao.findUserCntByParam(statistics);
            sumUserList = this.getDateRangeSumUserList(userCntList, statistics.getSr_date_type());
            boolean isSort = false;
            if ("CPYMB".equals(sr_way)) {
                isSort = true;
            }
            this.DateCommend2(statistics, orderList, sumRechargeList, sumApplList, sumAdList, sumUpAdList, sumUserList, dataMap, isSort);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.STATISTICS_LINE_CHART_FIND_DATA_BYDAYTYPE, PromptProperties.getProperty("statistics.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }

    private List<Tb_user_recharge> getDateRangeSumRechargeList(List<Map<String, Object>> userRechargeList, String dateType) {
        ArrayList<Tb_user_recharge> sumRechargeList = new ArrayList<Tb_user_recharge>();
        HashMap<String, BigDecimal> rechargeMap = new HashMap<String, BigDecimal>();
        if (userRechargeList != null) {
            for (Map<String, Object> userMap : userRechargeList) {
                if (rechargeMap.containsKey(userMap.get("date"))) {
                    BigDecimal sumRecharge = BigDecimalUtil.add((BigDecimal)XcbStringUtils.getObjToBigDecimal(rechargeMap.get(userMap.get("date"))), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)userMap.get("sr_recharge_money_sum")));
                    rechargeMap.put((String)userMap.get("date"), sumRecharge);
                    continue;
                }
                rechargeMap.put((String)userMap.get("date"), XcbStringUtils.getObjToBigDecimal((Object)userMap.get("sr_recharge_money_sum")));
            }
        }
        Set key = rechargeMap.keySet();
        for (String date : key) {
            Tb_user_recharge recharge = new Tb_user_recharge();
            if ("days".equals(dateType)) {
                recharge.setDays(date);
            } else if ("weeks".equals(dateType)) {
                recharge.setWeeks(date);
            } else if ("months".equals(dateType)) {
                recharge.setMonths(date);
            }
            recharge.setSumRechargeMoney(XcbStringUtils.getObjToBigDecimal(rechargeMap.get(date)));
            sumRechargeList.add(recharge);
        }
        return sumRechargeList;
    }

    private List<Tb_user_withdrawal_appl> getDateRangeSumUserApplList(List<Map<String, Object>> userApplList, String dateType) {
        ArrayList<Tb_user_withdrawal_appl> sumUserApplList = new ArrayList<Tb_user_withdrawal_appl>();
        HashMap<String, BigDecimal> applMap = new HashMap<String, BigDecimal>();
        if (userApplList != null) {
            for (Map<String, Object> userMap : userApplList) {
                if (applMap.containsKey(userMap.get("date"))) {
                    BigDecimal sumAppl = BigDecimalUtil.add((BigDecimal)XcbStringUtils.getObjToBigDecimal(applMap.get(userMap.get("date"))), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)userMap.get("sr_appl_money_sum")));
                    applMap.put((String)userMap.get("date"), sumAppl);
                    continue;
                }
                applMap.put((String)userMap.get("date"), XcbStringUtils.getObjToBigDecimal((Object)userMap.get("sr_appl_money_sum")));
            }
        }
        Set key = applMap.keySet();
        for (String date : key) {
            Tb_user_withdrawal_appl appl = new Tb_user_withdrawal_appl();
            if ("days".equals(dateType)) {
                appl.setDays(date);
            } else if ("weeks".equals(dateType)) {
                appl.setWeeks(date);
            } else if ("months".equals(dateType)) {
                appl.setMonths(date);
            }
            appl.setSumApplMoney(XcbStringUtils.getObjToBigDecimal(applMap.get(date)));
            sumUserApplList.add(appl);
        }
        return sumUserApplList;
    }

    private List<Tb_order> getDateRangeSumAdMoneyList(List<Map<String, Object>> adMoneylList, String dateType) {
        ArrayList<Tb_order> sumAdMoneyList = new ArrayList<Tb_order>();
        HashMap<String, BigDecimal> dataMap = new HashMap<String, BigDecimal>();
        if (adMoneylList != null) {
            for (Map<String, Object> userMap : adMoneylList) {
                if (dataMap.containsKey(userMap.get("date"))) {
                    BigDecimal sumAdMoney = BigDecimalUtil.add((BigDecimal)XcbStringUtils.getObjToBigDecimal(dataMap.get(userMap.get("date"))), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)userMap.get("dc_ad_money_sum")));
                    dataMap.put((String)userMap.get("date"), sumAdMoney);
                    continue;
                }
                dataMap.put((String)userMap.get("date"), XcbStringUtils.getObjToBigDecimal((Object)userMap.get("dc_ad_money_sum")));
            }
        }
        Set key = dataMap.keySet();
        for (String date : key) {
            Tb_order order = new Tb_order();
            if ("days".equals(dateType)) {
                order.setDays(date);
            } else if ("weeks".equals(dateType)) {
                order.setWeeks(date);
            } else if ("months".equals(dateType)) {
                order.setMonths(date);
            }
            order.setDc_ad_money_sum(XcbStringUtils.getObjToBigDecimal(dataMap.get(date)));
            sumAdMoneyList.add(order);
        }
        return sumAdMoneyList;
    }

    private List<Tb_order> getDateRangeSumUpAdMoneyList(List<Map<String, Object>> adMoneylList, String dateType) {
        ArrayList<Tb_order> sumAdMoneyList = new ArrayList<Tb_order>();
        HashMap<String, BigDecimal> dataMap = new HashMap<String, BigDecimal>();
        if (adMoneylList != null) {
            for (Map<String, Object> userMap : adMoneylList) {
                if (dataMap.containsKey(userMap.get("date"))) {
                    BigDecimal sumAdMoney = BigDecimalUtil.add((BigDecimal)XcbStringUtils.getObjToBigDecimal(dataMap.get(userMap.get("date"))), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)userMap.get("dc_up_ad_money_sum")));
                    dataMap.put((String)userMap.get("date"), sumAdMoney);
                    continue;
                }
                dataMap.put((String)userMap.get("date"), XcbStringUtils.getObjToBigDecimal((Object)userMap.get("dc_up_ad_money_sum")));
            }
        }
        Set key = dataMap.keySet();
        for (String date : key) {
            Tb_order order = new Tb_order();
            if ("days".equals(dateType)) {
                order.setDays(date);
            } else if ("weeks".equals(dateType)) {
                order.setWeeks(date);
            } else if ("months".equals(dateType)) {
                order.setMonths(date);
            }
            order.setDc_up_ad_money_sum(XcbStringUtils.getObjToBigDecimal(dataMap.get(date)));
            sumAdMoneyList.add(order);
        }
        return sumAdMoneyList;
    }

    private List<Tb_order> getDateRangeSumUserList(List<Map<String, Object>> userList, String dateType) {
        ArrayList<Tb_order> sumAdMoneyList = new ArrayList<Tb_order>();
        HashMap<String, Integer> dataMap = new HashMap<String, Integer>();
        if (userList != null) {
            for (Map<String, Object> userMap : userList) {
                if (dataMap.containsKey(userMap.get("date"))) {
                    int sumUserCnt = XcbStringUtils.getObjtoint(dataMap.get(userMap.get("date"))) + XcbStringUtils.getObjtoint((Object)userMap.get("sr_user_sum"));
                    dataMap.put((String)userMap.get("date"), sumUserCnt);
                    continue;
                }
                dataMap.put((String)userMap.get("date"), XcbStringUtils.getObjtoint((Object)userMap.get("sr_user_sum")));
            }
        }
        Set key = dataMap.keySet();
        for (String date : key) {
            Tb_order order = new Tb_order();
            if ("days".equals(dateType)) {
                order.setDays(date);
            } else if ("weeks".equals(dateType)) {
                order.setWeeks(date);
            } else if ("months".equals(dateType)) {
                order.setMonths(date);
            }
            order.setSr_user_sum(Integer.valueOf(XcbStringUtils.getObjtoint(dataMap.get(date))));
            sumAdMoneyList.add(order);
        }
        return sumAdMoneyList;
    }

    /*
     * WARNING - void declaration
     */
    private void DateCommend(Tb_agent agent, Tb_statistics statistics, List<Tb_statistics> orderList, List<Tb_statistics> adList, List<Tb_statistics> refundList, List<Tb_statistics> userList, Map<String, Object> dataMap, boolean isSort) throws Exception {
        ArrayList<Map> resDataList = new ArrayList<Map>();
        HashSet<String> onlineOrderSet = new HashSet<String>();
        try {
            Object diffVo;
            void var21_29;
            Date startDate = DateUtil.StringToDate(statistics.getSr_date_start(), "yyyy-MM-dd");
            Date endDate = DateUtil.StringToDate(statistics.getSr_date_end(), "yyyy-MM-dd");
            int diff = DateUtil.getDays(endDate, startDate);
            String sr_date_type = statistics.getSr_date_type();
            String days = null;
            String weeks = null;
            String months = null;
            for (Tb_statistics tb_statistics : orderList) {
                if ("days".equals(sr_date_type)) {
                    days = tb_statistics.getDays();
                    onlineOrderSet.add(days);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    weeks = tb_statistics.getWeeks();
                    onlineOrderSet.add(weeks);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                months = tb_statistics.getMonths();
                onlineOrderSet.add(months);
            }
            HashSet<String> adSet = new HashSet<String>();
            if (adList == null) {
                adList = new ArrayList<Tb_statistics>();
            }
            for (Tb_statistics tb_statistics : adList) {
                if ("days".equals(sr_date_type)) {
                    days = tb_statistics.getDays();
                    adSet.add(days);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    weeks = tb_statistics.getWeeks();
                    adSet.add(weeks);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                months = tb_statistics.getMonths();
                adSet.add(months);
            }
            HashSet<String> hashSet = new HashSet<String>();
            if (refundList == null) {
                refundList = new ArrayList<Tb_statistics>();
            }
            for (Tb_statistics tb_statistics : refundList) {
                if ("days".equals(sr_date_type)) {
                    days = tb_statistics.getDays();
                    hashSet.add(days);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    weeks = tb_statistics.getWeeks();
                    hashSet.add(weeks);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                months = tb_statistics.getMonths();
                hashSet.add(months);
            }
            HashSet<String> hashSet2 = new HashSet<String>();
            if (userList == null) {
                userList = new ArrayList<Tb_statistics>();
            }
            for (Tb_statistics obj : userList) {
                if ("days".equals(sr_date_type)) {
                    days = obj.getDays();
                    hashSet2.add(days);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    weeks = obj.getWeeks();
                    hashSet2.add(weeks);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                months = obj.getMonths();
                hashSet2.add(months);
            }
            ArrayList arrayList = new ArrayList();
            List adOrderDiffList = new ArrayList();
            List refundOrderDiffList = new ArrayList();
            List userDiffList = new ArrayList();
            for (int i = 0; i <= diff; ++i) {
                List list = DateUtil.isSameDate((List)var21_29, startDate, onlineOrderSet, sr_date_type);
                adOrderDiffList = DateUtil.isSameDate(adOrderDiffList, startDate, adSet, sr_date_type);
                refundOrderDiffList = DateUtil.isSameDate(refundOrderDiffList, startDate, hashSet, sr_date_type);
                userDiffList = DateUtil.isSameDate(userDiffList, startDate, hashSet2, sr_date_type);
                startDate = DateUtil.addDay(startDate, 1);
            }
            for (String diffDate : var21_29) {
                diffVo = new Tb_statistics();
                if ("days".equals(sr_date_type)) {
                    diffVo.setDays(diffDate);
                } else if ("weeks".equals(sr_date_type)) {
                    diffVo.setWeeks(diffDate);
                } else if ("months".equals(sr_date_type)) {
                    diffVo.setMonths(diffDate);
                }
                diffVo.setCnt(Integer.valueOf(0));
                diffVo.setDc_actual_income_sum(new BigDecimal(0));
                diffVo.setDc_online_tk_money_sum(new BigDecimal(0));
                diffVo.setDc_agent_money_sum(new BigDecimal(0));
                diffVo.setDc_shop_money_sum(new BigDecimal(0));
                diffVo.setDc_ad_money_sum(new BigDecimal(0));
                diffVo.setDc_up_ad_money_sum(new BigDecimal(0));
                orderList.add((Tb_statistics)diffVo);
            }
            for (String diffDate : adOrderDiffList) {
                diffVo = new Tb_statistics();
                if ("days".equals(sr_date_type)) {
                    diffVo.setDays(diffDate);
                } else if ("weeks".equals(sr_date_type)) {
                    diffVo.setWeeks(diffDate);
                } else if ("months".equals(sr_date_type)) {
                    diffVo.setMonths(diffDate);
                }
                diffVo.setCnt(Integer.valueOf(0));
                adList.add((Tb_statistics)diffVo);
            }
            for (String diffDate : refundOrderDiffList) {
                diffVo = new Tb_statistics();
                if ("days".equals(sr_date_type)) {
                    diffVo.setDays(diffDate);
                } else if ("weeks".equals(sr_date_type)) {
                    diffVo.setWeeks(diffDate);
                } else if ("months".equals(sr_date_type)) {
                    diffVo.setMonths(diffDate);
                }
                diffVo.setCnt(Integer.valueOf(0));
                refundList.add((Tb_statistics)diffVo);
            }
            for (String diffDate : userDiffList) {
                diffVo = new Tb_statistics();
                if ("days".equals(sr_date_type)) {
                    diffVo.setDays(diffDate);
                } else if ("weeks".equals(sr_date_type)) {
                    diffVo.setWeeks(diffDate);
                } else if ("months".equals(sr_date_type)) {
                    diffVo.setMonths(diffDate);
                }
                diffVo.setSr_user_sum(Integer.valueOf(0));
                userList.add((Tb_statistics)diffVo);
            }
            HashMap objMap = new HashMap();
            ArrayList<String> cycleKeys = new ArrayList<String>();
            for (Tb_statistics orderOnline : orderList) {
                HashMap<String, Object> tempObjOnlineOrder = new HashMap<String, Object>();
                tempObjOnlineOrder.put("cnt", orderOnline.getCnt());
                tempObjOnlineOrder.put("sr_actual_income_sum", orderOnline.getDc_actual_income_sum());
                tempObjOnlineOrder.put("dc_shop_money_sum", orderOnline.getDc_shop_money_sum());
                tempObjOnlineOrder.put("dc_agent_money_sum", orderOnline.getDc_agent_money_sum());
                tempObjOnlineOrder.put("dc_online_tk_money_sum", orderOnline.getDc_online_tk_money_sum());
                tempObjOnlineOrder.put("dc_ad_money_sum", orderOnline.getDc_ad_money_sum());
                tempObjOnlineOrder.put("dc_up_ad_money_sum", orderOnline.getDc_up_ad_money_sum());
                if ("days".equals(sr_date_type)) {
                    cycleKeys.add(orderOnline.getDays());
                    tempObjOnlineOrder.put("cycleKey", orderOnline.getDays());
                    objMap.put(orderOnline.getDays(), tempObjOnlineOrder);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    cycleKeys.add(orderOnline.getWeeks());
                    tempObjOnlineOrder.put("cycleKey", orderOnline.getWeeks());
                    objMap.put(orderOnline.getWeeks(), tempObjOnlineOrder);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                cycleKeys.add(orderOnline.getMonths());
                tempObjOnlineOrder.put("cycleKey", orderOnline.getMonths());
                objMap.put(orderOnline.getMonths(), tempObjOnlineOrder);
            }
            for (Tb_statistics refund : refundList) {
                if ("days".equals(sr_date_type)) {
                    ((Map)objMap.get(refund.getDays())).put("sr_refund_cnt", refund.getCnt());
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    ((Map)objMap.get(refund.getWeeks())).put("sr_refund_cnt", refund.getCnt());
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                ((Map)objMap.get(refund.getMonths())).put("sr_refund_cnt", refund.getCnt());
            }
            for (Tb_statistics user : userList) {
                if ("days".equals(sr_date_type)) {
                    ((Map)objMap.get(user.getDays())).put("sr_user_sum", user.getSr_user_sum());
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    ((Map)objMap.get(user.getWeeks())).put("sr_user_sum", user.getSr_user_sum());
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                ((Map)objMap.get(user.getMonths())).put("sr_user_sum", user.getSr_user_sum());
            }
            HashMap<String, Object> sumRow = new HashMap<String, Object>();
            Long hj_sr_user_sum = new Long(0L);
            Integer hj_cnt = new Integer(0);
            BigDecimal hj_sr_actual_income_sum = BigDecimal.ZERO;
            BigDecimal hj_dc_shop_money_sum = BigDecimal.ZERO;
            BigDecimal hj_dc_agent_money_sum = BigDecimal.ZERO;
            Integer hj_online_tk_cnt = new Integer(0);
            BigDecimal hj_online_tk_money_sum = BigDecimal.ZERO;
            BigDecimal hj_ad_money_sum = BigDecimal.ZERO;
            BigDecimal hj_up_ad_money_sum = BigDecimal.ZERO;
            ArrayList<Integer> sr_user_sum_Lst = new ArrayList<Integer>();
            ArrayList<Integer> cnt_Lst = new ArrayList<Integer>();
            ArrayList<Integer> online_tk_cnt_Lst = new ArrayList<Integer>();
            ArrayList<BigDecimal> sr_actual_income_sum_Lst = new ArrayList<BigDecimal>();
            ArrayList<BigDecimal> dc_shop_money_sum_Lst = new ArrayList<BigDecimal>();
            ArrayList<BigDecimal> dc_agent_money_sum_Lst = new ArrayList<BigDecimal>();
            ArrayList<BigDecimal> dc_online_tk_money_sum_Lst = new ArrayList<BigDecimal>();
            ArrayList<BigDecimal> dc_ad_money_sum_Lst = new ArrayList<BigDecimal>();
            ArrayList<BigDecimal> dc_up_ad_money_sum_Lst = new ArrayList<BigDecimal>();
            Collections.sort(cycleKeys);
            for (String cycle : cycleKeys) {
                Map tmpObj = (Map)objMap.get(cycle);
                sr_user_sum_Lst.add(XcbStringUtils.getObjtoint((Object)(tmpObj.get("sr_user_sum") == null ? Integer.valueOf(0) : tmpObj.get("sr_user_sum"))));
                cnt_Lst.add(XcbStringUtils.getObjtoint(tmpObj.get("cnt")));
                sr_actual_income_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("sr_actual_income_sum")));
                dc_shop_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_shop_money_sum")));
                dc_agent_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_agent_money_sum")));
                online_tk_cnt_Lst.add(XcbStringUtils.getObjtoint(tmpObj.get("sr_refund_cnt")));
                dc_online_tk_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_online_tk_money_sum")));
                hj_sr_user_sum = hj_sr_user_sum + (long)XcbStringUtils.getObjtoint(tmpObj.get("sr_user_sum"));
                hj_cnt = hj_cnt + XcbStringUtils.getObjtoint(tmpObj.get("cnt"));
                hj_sr_actual_income_sum = BigDecimalUtil.add((BigDecimal)hj_sr_actual_income_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("sr_actual_income_sum")));
                hj_dc_shop_money_sum = BigDecimalUtil.add((BigDecimal)hj_dc_shop_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_shop_money_sum")));
                hj_dc_agent_money_sum = BigDecimalUtil.add((BigDecimal)hj_dc_agent_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_agent_money_sum")));
                hj_online_tk_cnt = hj_online_tk_cnt + XcbStringUtils.getObjtoint(tmpObj.get("sr_refund_cnt"));
                hj_online_tk_money_sum = BigDecimalUtil.add((BigDecimal)hj_online_tk_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_online_tk_money_sum")));
                if ("2".equals(agent.getSr_ad_mode()) || "1".equals(agent.getSr_role()) || "3".equals(agent.getSr_role())) {
                    if (cycle.equals(XcbDateUtil.getCurrentDate((String)"yyyyMMdd"))) {
                        dc_ad_money_sum_Lst.add(BigDecimal.ZERO);
                        dc_up_ad_money_sum_Lst.add(BigDecimal.ZERO);
                        hj_ad_money_sum = BigDecimalUtil.add((BigDecimal)hj_ad_money_sum, (BigDecimal)BigDecimal.ZERO);
                        hj_up_ad_money_sum = BigDecimalUtil.add((BigDecimal)hj_up_ad_money_sum, (BigDecimal)BigDecimal.ZERO);
                        tmpObj.put("dc_ad_money_sum", BigDecimal.ZERO);
                        tmpObj.put("dc_up_ad_money_sum", BigDecimal.ZERO);
                    } else {
                        dc_ad_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_ad_money_sum")));
                        dc_up_ad_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_up_ad_money_sum")));
                        hj_ad_money_sum = BigDecimalUtil.add((BigDecimal)hj_ad_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_ad_money_sum")));
                        hj_up_ad_money_sum = BigDecimalUtil.add((BigDecimal)hj_up_ad_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_up_ad_money_sum")));
                    }
                } else {
                    dc_ad_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_ad_money_sum")));
                    dc_up_ad_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_up_ad_money_sum")));
                    hj_ad_money_sum = BigDecimalUtil.add((BigDecimal)hj_ad_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_ad_money_sum")));
                    hj_up_ad_money_sum = BigDecimalUtil.add((BigDecimal)hj_up_ad_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_up_ad_money_sum")));
                }
                resDataList.add(tmpObj);
            }
            dataMap.remove("sr_user_sum");
            sumRow.put("hj_ad_money_sum", XcbStringUtils.getObjtoString((Object)hj_ad_money_sum));
            sumRow.put("hj_up_ad_money_sum", XcbStringUtils.getObjtoString((Object)hj_up_ad_money_sum));
            sumRow.put("hj_sr_user_sum", hj_sr_user_sum);
            sumRow.put("hj_cnt", hj_cnt);
            sumRow.put("hj_online_tk_cnt", hj_online_tk_cnt);
            sumRow.put("hj_sr_actual_income_sum", XcbStringUtils.getObjtoString((Object)hj_sr_actual_income_sum));
            sumRow.put("hj_dc_agent_money_sum", XcbStringUtils.getObjtoString((Object)hj_dc_agent_money_sum));
            sumRow.put("hj_dc_shop_money_sum", XcbStringUtils.getObjtoString((Object)hj_dc_shop_money_sum));
            sumRow.put("hj_online_tk_money_sum", XcbStringUtils.getObjtoString((Object)hj_online_tk_money_sum));
            if (isSort) {
                Collections.reverse(resDataList);
                Collections.reverse(cycleKeys);
                Collections.reverse(sr_user_sum_Lst);
                Collections.reverse(cnt_Lst);
                Collections.reverse(sr_actual_income_sum_Lst);
                Collections.reverse(dc_shop_money_sum_Lst);
                Collections.reverse(dc_agent_money_sum_Lst);
                Collections.reverse(online_tk_cnt_Lst);
                Collections.reverse(dc_online_tk_money_sum_Lst);
                Collections.reverse(dc_ad_money_sum_Lst);
                Collections.reverse(dc_up_ad_money_sum_Lst);
            }
            dataMap.put("operateRptList", resDataList);
            dataMap.put("dataXList", cycleKeys);
            dataMap.put("sr_user_sum_Lst", sr_user_sum_Lst);
            dataMap.put("cnt_Lst", cnt_Lst);
            dataMap.put("sr_actual_income_sum_Lst", sr_actual_income_sum_Lst);
            dataMap.put("dc_shop_money_sum_Lst", dc_shop_money_sum_Lst);
            dataMap.put("dc_agent_money_sum_Lst", dc_agent_money_sum_Lst);
            dataMap.put("online_tk_cnt_Lst", online_tk_cnt_Lst);
            dataMap.put("dc_online_tk_money_sum_Lst", dc_online_tk_money_sum_Lst);
            dataMap.put("dc_ad_money_sum_Lst", dc_ad_money_sum_Lst);
            dataMap.put("dc_up_ad_money_sum_Lst", dc_up_ad_money_sum_Lst);
            dataMap.put("sumRow", sumRow);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * WARNING - void declaration
     */
    private void DateCommend2(Tb_statistics statistics, List<Tb_statistics> orderList, List<Tb_user_recharge> sumRechargeList, List<Tb_user_withdrawal_appl> sumUserApplList, List<Tb_order> sumAdList, List<Tb_order> sumUpAdList, List<Tb_order> sumUserList, Map<String, Object> dataMap, boolean isSort) throws Exception {
        ArrayList<Map> resDataList = new ArrayList<Map>();
        HashSet<String> onlineOrderSet = new HashSet<String>();
        try {
            Object diffVo;
            void var24_36;
            Date startDate = DateUtil.StringToDate(statistics.getSr_date_start(), "yyyy-MM-dd");
            Date endDate = DateUtil.StringToDate(statistics.getSr_date_end(), "yyyy-MM-dd");
            int diff = DateUtil.getDays(endDate, startDate);
            String sr_date_type = statistics.getSr_date_type();
            String days = null;
            String weeks = null;
            String months = null;
            for (Tb_statistics tb_statistics : orderList) {
                if ("days".equals(sr_date_type)) {
                    days = tb_statistics.getDays();
                    onlineOrderSet.add(days);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    weeks = tb_statistics.getWeeks();
                    onlineOrderSet.add(weeks);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                months = tb_statistics.getMonths();
                onlineOrderSet.add(months);
            }
            HashSet<String> rechargeSet = new HashSet<String>();
            if (sumRechargeList == null) {
                sumRechargeList = new ArrayList<Tb_user_recharge>();
            }
            for (Tb_user_recharge tb_user_recharge : sumRechargeList) {
                if ("days".equals(sr_date_type)) {
                    days = tb_user_recharge.getDays();
                    rechargeSet.add(days);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    weeks = tb_user_recharge.getWeeks();
                    rechargeSet.add(weeks);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                months = tb_user_recharge.getMonths();
                rechargeSet.add(months);
            }
            HashSet<String> hashSet = new HashSet<String>();
            if (sumUserApplList == null) {
                sumUserApplList = new ArrayList<Tb_user_withdrawal_appl>();
            }
            for (Tb_user_withdrawal_appl tb_user_withdrawal_appl : sumUserApplList) {
                if ("days".equals(sr_date_type)) {
                    days = tb_user_withdrawal_appl.getDays();
                    hashSet.add(days);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    weeks = tb_user_withdrawal_appl.getWeeks();
                    hashSet.add(weeks);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                months = tb_user_withdrawal_appl.getMonths();
                hashSet.add(months);
            }
            HashSet<String> hashSet2 = new HashSet<String>();
            if (sumAdList == null) {
                sumAdList = new ArrayList<Tb_order>();
            }
            for (Tb_order tb_order : sumAdList) {
                if ("days".equals(sr_date_type)) {
                    days = tb_order.getDays();
                    hashSet2.add(days);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    weeks = tb_order.getWeeks();
                    hashSet2.add(weeks);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                months = tb_order.getMonths();
                hashSet2.add(months);
            }
            HashSet<String> hashSet3 = new HashSet<String>();
            if (sumUpAdList == null) {
                sumUpAdList = new ArrayList<Tb_order>();
            }
            for (Tb_order tb_order : sumUpAdList) {
                if ("days".equals(sr_date_type)) {
                    days = tb_order.getDays();
                    hashSet3.add(days);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    weeks = tb_order.getWeeks();
                    hashSet3.add(weeks);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                months = tb_order.getMonths();
                hashSet3.add(months);
            }
            HashSet<String> hashSet4 = new HashSet<String>();
            if (sumUserList == null) {
                sumUserList = new ArrayList<Tb_order>();
            }
            for (Tb_order obj : sumUserList) {
                if ("days".equals(sr_date_type)) {
                    days = obj.getDays();
                    hashSet4.add(days);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    weeks = obj.getWeeks();
                    hashSet4.add(weeks);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                months = obj.getMonths();
                hashSet4.add(months);
            }
            ArrayList arrayList = new ArrayList();
            List rechargeDiffList = new ArrayList();
            List userApplDiffList = new ArrayList();
            List adMoneyDiffList = new ArrayList();
            List upAdMoneyDiffList = new ArrayList();
            List userCntDiffList = new ArrayList();
            for (int i = 0; i <= diff; ++i) {
                List list = DateUtil.isSameDate((List)var24_36, startDate, onlineOrderSet, sr_date_type);
                rechargeDiffList = DateUtil.isSameDate(rechargeDiffList, startDate, rechargeSet, sr_date_type);
                userApplDiffList = DateUtil.isSameDate(userApplDiffList, startDate, hashSet, sr_date_type);
                adMoneyDiffList = DateUtil.isSameDate(adMoneyDiffList, startDate, hashSet2, sr_date_type);
                upAdMoneyDiffList = DateUtil.isSameDate(upAdMoneyDiffList, startDate, hashSet3, sr_date_type);
                userCntDiffList = DateUtil.isSameDate(userCntDiffList, startDate, hashSet4, sr_date_type);
                startDate = DateUtil.addDay(startDate, 1);
            }
            for (String diffDate : var24_36) {
                diffVo = new Tb_statistics();
                if ("days".equals(sr_date_type)) {
                    diffVo.setDays(diffDate);
                } else if ("weeks".equals(sr_date_type)) {
                    diffVo.setWeeks(diffDate);
                } else if ("months".equals(sr_date_type)) {
                    diffVo.setMonths(diffDate);
                }
                diffVo.setCnt(Integer.valueOf(0));
                diffVo.setDc_actual_income_sum(new BigDecimal(0));
                diffVo.setDc_online_tk_money_sum(new BigDecimal(0));
                diffVo.setDc_agent_money_sum(new BigDecimal(0));
                diffVo.setDc_deposit_money_sum(new BigDecimal(0));
                diffVo.setDc_deposit_refund_sum(new BigDecimal(0));
                orderList.add((Tb_statistics)diffVo);
            }
            for (String diffDate : rechargeDiffList) {
                diffVo = new Tb_user_recharge();
                if ("days".equals(sr_date_type)) {
                    diffVo.setDays(diffDate);
                } else if ("weeks".equals(sr_date_type)) {
                    diffVo.setWeeks(diffDate);
                } else if ("months".equals(sr_date_type)) {
                    diffVo.setMonths(diffDate);
                }
                diffVo.setSumRechargeMoney(new BigDecimal(0));
                sumRechargeList.add((Tb_user_recharge)diffVo);
            }
            for (String diffDate : userApplDiffList) {
                diffVo = new Tb_user_withdrawal_appl();
                if ("days".equals(sr_date_type)) {
                    diffVo.setDays(diffDate);
                } else if ("weeks".equals(sr_date_type)) {
                    diffVo.setWeeks(diffDate);
                } else if ("months".equals(sr_date_type)) {
                    diffVo.setMonths(diffDate);
                }
                diffVo.setSumApplMoney(new BigDecimal(0));
                sumUserApplList.add((Tb_user_withdrawal_appl)diffVo);
            }
            for (String diffDate : adMoneyDiffList) {
                diffVo = new Tb_order();
                if ("days".equals(sr_date_type)) {
                    diffVo.setDays(diffDate);
                } else if ("weeks".equals(sr_date_type)) {
                    diffVo.setWeeks(diffDate);
                } else if ("months".equals(sr_date_type)) {
                    diffVo.setMonths(diffDate);
                }
                diffVo.setDc_ad_money_sum(new BigDecimal(0));
                sumAdList.add((Tb_order)diffVo);
            }
            for (String diffDate : upAdMoneyDiffList) {
                diffVo = new Tb_order();
                if ("days".equals(sr_date_type)) {
                    diffVo.setDays(diffDate);
                } else if ("weeks".equals(sr_date_type)) {
                    diffVo.setWeeks(diffDate);
                } else if ("months".equals(sr_date_type)) {
                    diffVo.setMonths(diffDate);
                }
                diffVo.setDc_up_ad_money_sum(new BigDecimal(0));
                sumUpAdList.add((Tb_order)diffVo);
            }
            for (String diffDate : userCntDiffList) {
                diffVo = new Tb_order();
                if ("days".equals(sr_date_type)) {
                    diffVo.setDays(diffDate);
                } else if ("weeks".equals(sr_date_type)) {
                    diffVo.setWeeks(diffDate);
                } else if ("months".equals(sr_date_type)) {
                    diffVo.setMonths(diffDate);
                }
                diffVo.setSr_user_sum(Integer.valueOf(0));
                sumUserList.add((Tb_order)diffVo);
            }
            HashMap objMap = new HashMap();
            ArrayList<String> cycleKeys = new ArrayList<String>();
            for (Tb_statistics orderOnline : orderList) {
                HashMap<String, Object> tempObjOnlineOrder = new HashMap<String, Object>();
                tempObjOnlineOrder.put("cnt", orderOnline.getCnt());
                tempObjOnlineOrder.put("sr_actual_income_sum", orderOnline.getDc_actual_income_sum());
                tempObjOnlineOrder.put("dc_agent_money_sum", orderOnline.getDc_agent_money_sum());
                tempObjOnlineOrder.put("dc_deposit_money_sum", orderOnline.getDc_deposit_money_sum());
                tempObjOnlineOrder.put("dc_deposit_refund_sum", orderOnline.getDc_deposit_refund_sum());
                tempObjOnlineOrder.put("dc_online_tk_money_sum", orderOnline.getDc_online_tk_money_sum());
                if ("days".equals(sr_date_type)) {
                    cycleKeys.add(orderOnline.getDays());
                    tempObjOnlineOrder.put("cycleKey", orderOnline.getDays());
                    objMap.put(orderOnline.getDays(), tempObjOnlineOrder);
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    cycleKeys.add(orderOnline.getWeeks());
                    tempObjOnlineOrder.put("cycleKey", orderOnline.getWeeks());
                    objMap.put(orderOnline.getWeeks(), tempObjOnlineOrder);
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                cycleKeys.add(orderOnline.getMonths());
                tempObjOnlineOrder.put("cycleKey", orderOnline.getMonths());
                objMap.put(orderOnline.getMonths(), tempObjOnlineOrder);
            }
            for (Tb_user_recharge recharge : sumRechargeList) {
                if ("days".equals(sr_date_type)) {
                    ((Map)objMap.get(recharge.getDays())).put("recharge_money_sum", recharge.getSumRechargeMoney());
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    ((Map)objMap.get(recharge.getWeeks())).put("recharge_money_sum", recharge.getSumRechargeMoney());
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                ((Map)objMap.get(recharge.getMonths())).put("recharge_money_sum", recharge.getSumRechargeMoney());
            }
            for (Tb_user_withdrawal_appl userAppl : sumUserApplList) {
                if ("days".equals(sr_date_type)) {
                    ((Map)objMap.get(userAppl.getDays())).put("appl_money_sum", userAppl.getSumApplMoney());
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    ((Map)objMap.get(userAppl.getWeeks())).put("appl_money_sum", userAppl.getSumApplMoney());
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                ((Map)objMap.get(userAppl.getMonths())).put("appl_money_sum", userAppl.getSumApplMoney());
            }
            for (Tb_order adMoney : sumAdList) {
                if ("days".equals(sr_date_type)) {
                    ((Map)objMap.get(adMoney.getDays())).put("dc_ad_money_sum", adMoney.getDc_ad_money_sum());
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    ((Map)objMap.get(adMoney.getWeeks())).put("dc_ad_money_sum", adMoney.getDc_ad_money_sum());
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                ((Map)objMap.get(adMoney.getMonths())).put("dc_ad_money_sum", adMoney.getDc_ad_money_sum());
            }
            for (Tb_order adMoney : sumUpAdList) {
                if ("days".equals(sr_date_type)) {
                    ((Map)objMap.get(adMoney.getDays())).put("dc_up_ad_money_sum", adMoney.getDc_up_ad_money_sum());
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    ((Map)objMap.get(adMoney.getWeeks())).put("dc_up_ad_money_sum", adMoney.getDc_up_ad_money_sum());
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                ((Map)objMap.get(adMoney.getMonths())).put("dc_up_ad_money_sum", adMoney.getDc_up_ad_money_sum());
            }
            for (Tb_order userCnt : sumUserList) {
                if ("days".equals(sr_date_type)) {
                    ((Map)objMap.get(userCnt.getDays())).put("sr_user_sum", userCnt.getSr_user_sum());
                    continue;
                }
                if ("weeks".equals(sr_date_type)) {
                    ((Map)objMap.get(userCnt.getWeeks())).put("sr_user_sum", userCnt.getSr_user_sum());
                    continue;
                }
                if (!"months".equals(sr_date_type)) continue;
                ((Map)objMap.get(userCnt.getMonths())).put("sr_user_sum", userCnt.getSr_user_sum());
            }
            if (dataMap.get("registUserList") != null) {
                for (Tb_statistics user : (List)dataMap.get("registUserList")) {
                    if ("days".equals(sr_date_type)) {
                        ((Map)objMap.get(user.getDays())).put("reg_user_cnt", user.getReg_cnt());
                        continue;
                    }
                    if ("weeks".equals(sr_date_type)) {
                        ((Map)objMap.get(user.getWeeks())).put("reg_user_cnt", user.getReg_cnt());
                        continue;
                    }
                    if (!"months".equals(sr_date_type)) continue;
                    ((Map)objMap.get(user.getMonths())).put("reg_user_cnt", user.getReg_cnt());
                }
                dataMap.remove("registUserList");
            }
            HashMap<String, Object> sumRow = new HashMap<String, Object>();
            Long hj_sr_user_sum = new Long(0L);
            Integer hj_cnt = new Integer(0);
            BigDecimal hj_sr_actual_income_sum = BigDecimal.ZERO;
            BigDecimal hj_dc_agent_money_sum = BigDecimal.ZERO;
            BigDecimal hj_online_tk_money_sum = BigDecimal.ZERO;
            BigDecimal hj_deposit_money_sum = BigDecimal.ZERO;
            BigDecimal hj_deposit_refund_sum = BigDecimal.ZERO;
            int hj_sr_regist_user_sum = 0;
            ArrayList<Integer> regist_user_Lst = new ArrayList<Integer>();
            BigDecimal hj_recharge_money_sum = BigDecimal.ZERO;
            ArrayList<BigDecimal> recharge_money_Lst = new ArrayList<BigDecimal>();
            BigDecimal hj_user_appl_money_sum = BigDecimal.ZERO;
            ArrayList<BigDecimal> user_appl_money_Lst = new ArrayList<BigDecimal>();
            BigDecimal hj_ad_money_sum = BigDecimal.ZERO;
            ArrayList<BigDecimal> dc_ad_money_sum_Lst = new ArrayList<BigDecimal>();
            BigDecimal hj_up_ad_money_sum = BigDecimal.ZERO;
            ArrayList<BigDecimal> dc_up_ad_money_sum_Lst = new ArrayList<BigDecimal>();
            ArrayList<Integer> sr_user_sum_Lst = new ArrayList<Integer>();
            ArrayList<Integer> cnt_Lst = new ArrayList<Integer>();
            ArrayList<BigDecimal> sr_actual_income_sum_Lst = new ArrayList<BigDecimal>();
            ArrayList<BigDecimal> dc_agent_money_sum_Lst = new ArrayList<BigDecimal>();
            ArrayList<BigDecimal> dc_online_tk_money_sum_Lst = new ArrayList<BigDecimal>();
            ArrayList<BigDecimal> dc_deposit_money_sum_Lst = new ArrayList<BigDecimal>();
            ArrayList<BigDecimal> dc_deposit_refund_sum_Lst = new ArrayList<BigDecimal>();
            Collections.sort(cycleKeys);
            for (String cycle : cycleKeys) {
                Map tmpObj = (Map)objMap.get(cycle);
                sr_user_sum_Lst.add(XcbStringUtils.getObjtoint((Object)(tmpObj.get("sr_user_sum") == null ? Integer.valueOf(0) : tmpObj.get("sr_user_sum"))));
                cnt_Lst.add(XcbStringUtils.getObjtoint(tmpObj.get("cnt")));
                sr_actual_income_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("sr_actual_income_sum")));
                dc_agent_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_agent_money_sum")));
                dc_online_tk_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_online_tk_money_sum")));
                dc_deposit_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_deposit_money_sum")));
                dc_deposit_refund_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_deposit_refund_sum")));
                dc_ad_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_ad_money_sum")));
                dc_up_ad_money_sum_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_up_ad_money_sum")));
                hj_sr_user_sum = hj_sr_user_sum + (long)XcbStringUtils.getObjtoint(tmpObj.get("sr_user_sum"));
                hj_cnt = hj_cnt + XcbStringUtils.getObjtoint(tmpObj.get("cnt"));
                hj_sr_actual_income_sum = BigDecimalUtil.add((BigDecimal)hj_sr_actual_income_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("sr_actual_income_sum")));
                hj_dc_agent_money_sum = BigDecimalUtil.add((BigDecimal)hj_dc_agent_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_agent_money_sum")));
                hj_online_tk_money_sum = BigDecimalUtil.add((BigDecimal)hj_online_tk_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_online_tk_money_sum")));
                hj_deposit_money_sum = BigDecimalUtil.add((BigDecimal)hj_deposit_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_deposit_money_sum")));
                hj_deposit_refund_sum = BigDecimalUtil.add((BigDecimal)hj_deposit_refund_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_deposit_refund_sum")));
                hj_ad_money_sum = BigDecimalUtil.add((BigDecimal)hj_ad_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_ad_money_sum")));
                hj_up_ad_money_sum = BigDecimalUtil.add((BigDecimal)hj_up_ad_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("dc_up_ad_money_sum")));
                recharge_money_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("recharge_money_sum")));
                hj_recharge_money_sum = BigDecimalUtil.add((BigDecimal)hj_recharge_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("recharge_money_sum")));
                user_appl_money_Lst.add(XcbStringUtils.getObjToBigDecimal(tmpObj.get("appl_money_sum")));
                hj_user_appl_money_sum = BigDecimalUtil.add((BigDecimal)hj_user_appl_money_sum, (BigDecimal)XcbStringUtils.getObjToBigDecimal(tmpObj.get("appl_money_sum")));
                if (tmpObj.get("reg_user_cnt") == null) {
                    tmpObj.put("reg_user_cnt", 0);
                }
                regist_user_Lst.add(XcbStringUtils.getObjtoint(tmpObj.get("reg_user_cnt")));
                resDataList.add(tmpObj);
            }
            hj_sr_regist_user_sum = XcbStringUtils.getObjtoint((Object)dataMap.get("registUserSum"));
            dataMap.remove("registUserSum");
            sumRow.put("hj_reg_user_cnt", hj_sr_regist_user_sum);
            sumRow.put("hj_recharge_money_sum", XcbStringUtils.getObjtoString((Object)hj_recharge_money_sum));
            sumRow.put("hj_user_appl_money_sum", XcbStringUtils.getObjtoString((Object)hj_user_appl_money_sum));
            sumRow.put("hj_ad_money_sum", XcbStringUtils.getObjtoString((Object)hj_ad_money_sum));
            sumRow.put("hj_up_ad_money_sum", XcbStringUtils.getObjtoString((Object)hj_up_ad_money_sum));
            sumRow.put("hj_sr_user_sum", hj_sr_user_sum);
            sumRow.put("hj_cnt", hj_cnt);
            sumRow.put("hj_sr_actual_income_sum", XcbStringUtils.getObjtoString((Object)hj_sr_actual_income_sum));
            sumRow.put("hj_dc_agent_money_sum", XcbStringUtils.getObjtoString((Object)hj_dc_agent_money_sum));
            sumRow.put("hj_online_tk_money_sum", XcbStringUtils.getObjtoString((Object)hj_online_tk_money_sum));
            sumRow.put("hj_deposit_money_sum", XcbStringUtils.getObjtoString((Object)hj_deposit_money_sum));
            sumRow.put("hj_deposit_refund_sum", XcbStringUtils.getObjtoString((Object)hj_deposit_refund_sum));
            if (isSort) {
                Collections.reverse(regist_user_Lst);
                Collections.reverse(resDataList);
                Collections.reverse(cycleKeys);
                Collections.reverse(sr_user_sum_Lst);
                Collections.reverse(cnt_Lst);
                Collections.reverse(sr_actual_income_sum_Lst);
                Collections.reverse(dc_agent_money_sum_Lst);
                Collections.reverse(dc_online_tk_money_sum_Lst);
                Collections.reverse(dc_deposit_money_sum_Lst);
                Collections.reverse(dc_deposit_refund_sum_Lst);
                Collections.reverse(recharge_money_Lst);
                Collections.reverse(user_appl_money_Lst);
                Collections.reverse(dc_ad_money_sum_Lst);
                Collections.reverse(dc_up_ad_money_sum_Lst);
            }
            dataMap.put("reg_user_cnt_Lst", regist_user_Lst);
            dataMap.put("operateRptList", resDataList);
            dataMap.put("dataXList", cycleKeys);
            dataMap.put("sr_user_sum_Lst", sr_user_sum_Lst);
            dataMap.put("cnt_Lst", cnt_Lst);
            dataMap.put("sr_actual_income_sum_Lst", sr_actual_income_sum_Lst);
            dataMap.put("dc_agent_money_sum_Lst", dc_agent_money_sum_Lst);
            dataMap.put("dc_online_tk_money_sum_Lst", dc_online_tk_money_sum_Lst);
            dataMap.put("dc_deposit_money_sum_Lst", dc_deposit_money_sum_Lst);
            dataMap.put("dc_deposit_refund_sum_Lst", dc_deposit_refund_sum_Lst);
            dataMap.put("recharge_money_Lst", recharge_money_Lst);
            dataMap.put("user_appl_money_Lst", user_appl_money_Lst);
            dataMap.put("dc_ad_money_sum_Lst", dc_ad_money_sum_Lst);
            dataMap.put("dc_up_ad_money_sum_Lst", dc_up_ad_money_sum_Lst);
            dataMap.put("sumRow", sumRow);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Map<String, Object>> assembleRechargeDataList(List<Map<String, Object>> list1, List<Map<String, Object>> list2) {
        boolean isExists;
        ArrayList<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        for (Map<String, Object> cs1 : list1) {
            isExists = false;
            for (Map<String, Object> cs2 : list2) {
                if (!cs1.get("days").equals(cs2.get("days"))) continue;
                HashMap<String, Object> m = new HashMap<String, Object>();
                m.put("days", cs1.get("days"));
                BigDecimal cs1d = cs1.get("dc_cashflow_money_sum") != null ? (BigDecimal)cs1.get("dc_cashflow_money_sum") : null;
                BigDecimal cs2d = cs2.get("dc_cashflow_money_sum") != null ? (BigDecimal)cs2.get("dc_cashflow_money_sum") : null;
                m.put("dc_cashflow_money_sum", BigDecimalUtil.add((BigDecimal)cs1d, (BigDecimal)cs2d));
                isExists = true;
                list.add(m);
                break;
            }
            if (isExists) continue;
            list.add(cs1);
        }
        for (Map<String, Object> cs2 : list2) {
            isExists = false;
            for (Map<String, Object> cs1 : list1) {
                if (!cs1.get("days").equals(cs2.get("days"))) continue;
                isExists = true;
                break;
            }
            if (isExists) continue;
            list.add(cs2);
        }
        Comparator comparator = (s1, s2) -> ((String)s1.get("days")).compareTo((String)s2.get("days"));
        list.sort(comparator);
        return list;
    }

    public List<Tb_cash_stream> assembleIncomeDataList(List<Tb_cash_stream> list1, List<Tb_cash_stream> list2) {
        boolean isExists;
        ArrayList<Tb_cash_stream> list = new ArrayList<Tb_cash_stream>();
        for (Tb_cash_stream cs1 : list1) {
            isExists = false;
            for (Tb_cash_stream cs2 : list2) {
                if (!cs1.getDays().equals(cs2.getDays())) continue;
                Tb_cash_stream o = new Tb_cash_stream();
                o.setDays(cs1.getDays());
                BigDecimal cs1d = cs1.getDc_cashflow_money_sum() != null ? new BigDecimal(cs1.getDc_cashflow_money_sum()) : null;
                BigDecimal cs2d = cs2.getDc_cashflow_money_sum() != null ? new BigDecimal(cs2.getDc_cashflow_money_sum()) : null;
                o.setDc_cashflow_money_sum(BigDecimalUtil.add((BigDecimal)cs1d, (BigDecimal)cs2d).toString());
                isExists = true;
                list.add(o);
                break;
            }
            if (isExists) continue;
            list.add(cs1);
        }
        for (Tb_cash_stream cs2 : list2) {
            isExists = false;
            for (Tb_cash_stream cs1 : list1) {
                if (!cs2.getDays().equals(cs1.getDays())) continue;
                isExists = true;
                break;
            }
            if (isExists) continue;
            list.add(cs2);
        }
        Comparator comparator = (s1, s2) -> s1.getDays().compareTo(s2.getDays());
        list.sort(comparator);
        return list;
    }
}

