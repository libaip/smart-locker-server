/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.wxpay.sdk.WXPayUtil
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_cash_stream
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.agent.model.Tb_withdrawal_appl
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.company.model.Tb_sys_param
 *  com.jcg.company.model.Tb_wx_pay_info
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.agent.serviceimpl;

import com.github.wxpay.sdk.WXPayUtil;
import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentRolesRelDao;
import com.jcg.agent.idao.CashStreamDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.idao.WithdrawalApplDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_cash_stream;
import com.jcg.agent.model.Tb_statistics;
import com.jcg.agent.model.Tb_withdrawal_appl;
import com.jcg.agent.serviceimpl.StatisticsServiceImpl;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.WxPayInfoDao;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.zf.wx.EnterprisesPayment;
import com.jcg.zf.wx.Signature;
import com.jcg.zf.wx.UUidUtils;
import com.jcg.zf.wx.WXWithdrawTools;
import com.jcg.zf.wx.WithdrawInfo;
import com.jcg.zf.wx.WxAPIV3Common;
import com.jcg.zf.wx.WxSdjAPICommon;
import com.jcg.zf.wxtoyhk.RSAUtils;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class WithdrawalApplServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private WithdrawalApplDao withdrawalApplDao;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private CashStreamDao cashStreamDao;
    @Autowired
    private AgentRolesRelDao roleRelDao;
    @Autowired
    private CommonLogic commonLogic;
    @Autowired
    private WxAPIV3Common wxAPIV3Common;
    @Autowired
    private WxSdjAPICommon wxSdjAPICommon;
    @Autowired
    private RSAUtils rsaUtils;
    @Autowired
    private WXWithdrawTools wxWithdrawTools;
    @Autowired
    private StatisticsServiceImpl statisticsService;
    @Autowired
    private WxPayInfoDao wxPayInfoDao;
    @Autowired
    private OrderDao orderDao;
    private String AGENT_JY = "AGENT_JY";
    private String AGENT_FD = "AGENT_FD";
    private String one_day_minmoney_wx = "1";
    private String one_day_maxmoney_wx = "500";

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========WithdrawalApplServiceImpl=========");
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_withdrawal_appl withdrawalAppl = new Tb_withdrawal_appl();
        Integer sd_id = null;
        Page page = new Page();
        if (param != null) {
            sd_id = XcbStringUtils.getObjtoint((Object)param.get("sd_id"));
            withdrawalAppl = (Tb_withdrawal_appl)param.get("withdrawalAppl");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.WITHDRAWAL_APPL_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createWithdrawalAppl(identifier, withdrawalAppl);
            } else if (XcbConstantValue.WITHDRAWAL_APPL_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findWithdrawalApplByParam_agent(identifier, withdrawalAppl, page);
            } else if (XcbConstantValue.WITHDRAWAL_APPL_FIND_AGENTINFO_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findWithdrawalApplAgentInfoByParam_agent(withdrawalAppl);
            } else if (XcbConstantValue.WITHDRAWAL_APPL_CREATE_SHARE.equalsIgnoreCase(functionCode)) {
                ret = this.createWithdrawalAppl_cpy(identifier, withdrawalAppl);
            } else if (XcbConstantValue.WITHDRAWAL_APPL_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findWithdrawalApplByParam_cpy(identifier, withdrawalAppl, page);
            } else if (XcbConstantValue.WITHDRAWAL_APPL_FIND_ALL_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findAllWithdrawalApplByParam_cpy(identifier, withdrawalAppl);
            } else if (XcbConstantValue.WITHDRAWAL_APPL_FIND_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findWithdrawalApplById_cpy(identifier, sd_id);
            } else if (XcbConstantValue.WITHDRAWAL_APPL_UPDATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateWithdrawalAppl_cpy(identifier, withdrawalAppl);
            } else if (XcbConstantValue.WITHDRAWAL_APPL_PAY.equalsIgnoreCase(functionCode)) {
                ret = this.payToAgent(identifier, withdrawalAppl, identifier.getUserName(), "cpy");
            }
        }
        catch (BusinessException e) {
            this.log.error("WithdrawalApplServiceImpl error:" + e.getMessage());
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findWithdrawalApplById_cpy(Identifier identifier, Integer sd_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        Tb_withdrawal_appl withdrawalAppl = this.withdrawalApplDao.findWithdrawalApplById(sd_id);
        if (withdrawalAppl != null) {
            Tb_agent agent = this.agentDao.findAgentMoneyById_user(withdrawalAppl.getSw_agent_id());
            Tb_withdrawal_appl o_appl = new Tb_withdrawal_appl();
            o_appl.setSw_agent_id(withdrawalAppl.getSw_agent_id());
            o_appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_DSP);
            List<Tb_withdrawal_appl> applList = this.withdrawalApplDao.findWithdrawalApplByParam(o_appl);
            BigDecimal totalDSPMoney = new BigDecimal(0);
            for (Tb_withdrawal_appl appl : applList) {
                totalDSPMoney = BigDecimalUtil.add((BigDecimal)totalDSPMoney, (BigDecimal)appl.getDc_appl_money());
            }
            Map<String, Object> agentBusiness = this.cashStreamDao.findAgentForBusiness(withdrawalAppl.getSw_agent_id());
            BigDecimal sr_cashflow_money_sum = XcbStringUtils.getObjToBigDecimal((Object)agentBusiness.get("sr_cashflow_money_sum"));
            Map<String, Object> agentBusinessTk = this.cashStreamDao.findAgentForBusinessTk(withdrawalAppl.getSw_agent_id());
            BigDecimal tkMoney = XcbStringUtils.getObjToBigDecimal((Object)agentBusinessTk.get("sr_cashflow_money_sum"));
            sr_cashflow_money_sum = BigDecimalUtil.sub((BigDecimal)sr_cashflow_money_sum, (BigDecimal)tkMoney);
            BigDecimal agentMoney = BigDecimalUtil.sub((BigDecimal)sr_cashflow_money_sum, (BigDecimal)agent.getDc_tx_money());
            BigDecimal tmpAgentMoney = BigDecimalUtil.add((BigDecimal)agent.getDc_agent_money(), (BigDecimal)totalDSPMoney);
            BigDecimal errorMoney = BigDecimalUtil.sub((BigDecimal)agentMoney, (BigDecimal)tmpAgentMoney);
            dataMap.put("agent", agent);
            dataMap.put("agentMoney", agentMoney);
            dataMap.put("totalDSPMoney", totalDSPMoney);
            dataMap.put("sr_cashflow_money_sum", sr_cashflow_money_sum);
            dataMap.put("withdrawalAppl", withdrawalAppl);
            dataMap.put("errorMoney", errorMoney);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        } else {
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.find.fail"));
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> createWithdrawalAppl(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        Map<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        try {
            BigDecimal dc_appl_money = XcbStringUtils.getObjToBigDecimal((Object)withdrawalAppl.getDc_appl_money());
            if (dc_appl_money.compareTo(BigDecimal.ZERO) <= 0) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u63d0\u73b0\u7533\u8bf7\u91d1\u989d\u5fc5\u987b\u5927\u4e8e0\uff01");
                return ret_method;
            }
            Tb_agent agent = this.agentDao.findAgentById_agent(withdrawalAppl.getSw_agent_id());
            if (!XcbStringUtils.isNullOrBlank((Object)agent.getSr_admin_id())) {
                agent = this.agentDao.findAgentById_agent(XcbStringUtils.getObjtoint((Object)agent.getSr_admin_id()));
            }
            withdrawalAppl.setSw_agent_id(agent.getSd_agent_id());
            String sr_way = withdrawalAppl.getSr_way();
            if ("1".equals(sr_way)) {
                if ("Y".equals(agent.getSr_is_month())) {
                    if (dc_appl_money.compareTo(agent.getDc_max_money()) == 1) {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u63d0\u73b0\u91d1\u989d\u4e0d\u53ef\u8d85\u8fc7\u4e0a\u4e2a\u6708\u53ef\u63d0\u73b0\u91d1\u989d" + agent.getDc_max_money() + "\u5143");
                        return ret_method;
                    }
                    if (agent.getDc_max_money().compareTo(BigDecimal.ZERO) <= 0) {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u5f53\u6708\u53ef\u63d0\u73b0\u91d1\u989d\u5df2\u7528\u5c3d\uff0c\u8bf7\u4e0b\u4e2a\u6708\u518d\u63d0\uff01");
                        return ret_method;
                    }
                }
            } else if ("2".equals(agent.getSr_ad_income_date())) {
                BigDecimal dc_ad_max_money = BigDecimal.ZERO;
                String start_day = XcbDateUtil.getCurrentMonthFirst();
                String end_day = XcbDateUtil.getEndDay((String)XcbDateUtil.getBeforeDay((Date)new Date(), (int)1, (String)"yyyy-MM-dd"));
                Object this_month = BigDecimal.ZERO;
                if ("1".equals(agent.getSr_role())) {
                    List<String> subList = this.agentDao.findSubAgentList(agent.getSd_agent_id());
                    String[] subArr = new String[subList.size()];
                    subList.toArray(subArr);
                    this_month = this.orderDao.findShowNowMonthAdMoney(subArr, start_day, end_day);
                } else if ("2".equals(agent.getSr_role())) {
                    this_month = this.orderDao.findNowMonthAdMoney(agent.getSd_agent_id(), start_day, end_day);
                }
                dc_ad_max_money = BigDecimalUtil.sub((BigDecimal)agent.getDc_ad_money(), (BigDecimal)this_month);
                if (dc_appl_money.compareTo(dc_ad_max_money) == 1) {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u63d0\u73b0\u91d1\u989d\u4e0d\u53ef\u8d85\u8fc7\u4e0a\u4e2a\u6708\u53ef\u63d0\u73b0\u91d1\u989d" + dc_ad_max_money + "\u5143");
                    return ret_method;
                }
                if (dc_ad_max_money.compareTo(BigDecimal.ZERO) <= 0) {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u5f53\u6708\u53ef\u63d0\u73b0\u91d1\u989d\u989d\u5ea6\u5df2\u7528\u5c3d\uff0c\u8bf7\u4e0b\u4e2a\u6708\u518d\u63d0\uff01");
                    return ret_method;
                }
            }
            withdrawalAppl.setSr_type(agent.getSr_pay_way());
            if (XcbConstantValue.WITHDRAWAL_APPL_WX.equals(withdrawalAppl.getSr_type()) || XcbConstantValue.WITHDRAWAL_APPL_YHK.equals(withdrawalAppl.getSr_type()) || XcbConstantValue.WITHDRAWAL_APPL_DG.equals(withdrawalAppl.getSr_type())) {
                if (XcbConstantValue.WITHDRAWAL_APPL_WX.equals(withdrawalAppl.getSr_type()) && XcbStringUtils.isNullOrBlank((Object)agent.getSr_open_id())) {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.warn4"));
                    return ret_method;
                }
                Tb_withdrawal_appl o_appl = new Tb_withdrawal_appl();
                o_appl.setSw_agent_id(withdrawalAppl.getSw_agent_id());
                o_appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                o_appl.setSr_type(withdrawalAppl.getSr_type());
                o_appl.setSr_appl_time(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                List<Tb_withdrawal_appl> applList = this.withdrawalApplDao.findWithdrawalApplByParam(o_appl);
                BigDecimal tmpMoney = XcbStringUtils.getObjToBigDecimal((Object)withdrawalAppl.getDc_appl_money());
                for (Tb_withdrawal_appl appl : applList) {
                    tmpMoney = BigDecimalUtil.add((BigDecimal)tmpMoney, (BigDecimal)appl.getDc_appl_money());
                }
                Tb_sys_param sysParam1 = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.WX_DLS_ONCE_MOST);
                Tb_sys_param sysParam2 = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.WX_DLS_DAY_MOST);
                if (XcbConstantValue.WITHDRAWAL_APPL_YHK.equals(withdrawalAppl.getSr_type()) || XcbConstantValue.WITHDRAWAL_APPL_DG.equals(withdrawalAppl.getSr_type())) {
                    sysParam1 = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.HK_DLS_ONCE_MOST);
                    sysParam2 = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.HK_DLS_DAY_MOST);
                    if (XcbStringUtils.isNullOrBlank((Object)agent.getSr_txn_bindno())) {
                        ret_method.put(XcbConstantValue.MSG, "\u63d0\u4f9b\u6536\u6b3e\u94f6\u884c\u5361\u6536\u6b3e\u4fe1\u606f");
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        return ret_method;
                    }
                }
                if (dc_appl_money.compareTo(new BigDecimal(this.one_day_minmoney_wx)) == -1) {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.warn1", this.one_day_minmoney_wx));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    return ret_method;
                }
                if (dc_appl_money.compareTo(new BigDecimal(sysParam1.getSr_param_value())) == 1) {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.warn2", sysParam1.getSr_param_value()));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    return ret_method;
                }
                if (tmpMoney.compareTo(new BigDecimal(sysParam2.getSr_param_value())) == 1) {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.warn3", sysParam2.getSr_param_value()));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    return ret_method;
                }
                if (applList.size() >= 10) {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.warn5"));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    return ret_method;
                }
            }
            BigDecimal dc_agent_money = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_agent_money());
            if ("2".equals(sr_way)) {
                dc_agent_money = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_ad_money());
            }
            if (dc_appl_money.compareTo(dc_agent_money) <= 0) {
                withdrawalAppl.setSr_create_time(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd"));
                Tb_withdrawal_appl appl = this.withdrawalApplDao.findLastWXWithdrawalAppl(withdrawalAppl);
                Tb_sys_param sysParam = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.PAY_TIME);
                boolean isPay = false;
                if (appl != null) {
                    long fiveTime;
                    long cTime;
                    long nowTime = XcbDateUtil.getCurrentTimestamp();
                    long diff = nowTime - (cTime = appl.getTm_create_time().getTime() / 1000L);
                    if (diff > (fiveTime = XcbStringUtils.getObjtoLong((Object)sysParam.getSr_param_value()))) {
                        isPay = true;
                    }
                } else {
                    isPay = true;
                }
                if (isPay) {
                    Tb_wx_pay_info pay_info = this.wxPayInfoDao.findDefaultPayOut(agent.getSw_company_id());
                    if (XcbConstantValue.WITHDRAWAL_APPL_WX.equals(agent.getSr_pay_way())) {
                        pay_info = this.wxPayInfoDao.findUserDefaultPayOutByCpy(agent.getSw_company_id());
                    }
                    withdrawalAppl.setSw_agent_id(agent.getSd_agent_id());
                    withdrawalAppl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_DSP);
                    withdrawalAppl.setSi_create_person(withdrawalAppl.getSw_agent_id());
                    withdrawalAppl.setTm_create_time(new Date());
                    withdrawalAppl.setSi_modify_person(withdrawalAppl.getSw_agent_id());
                    withdrawalAppl.setTm_modify_time(new Date());
                    withdrawalAppl.setSr_mchid(pay_info.getSub_mchid());
                    result = this.withdrawalApplDao.createWithdrawalAppl(withdrawalAppl);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        if ("Y".equals(agent.getSr_is_appl())) {
                            result = "2".equals(withdrawalAppl.getSr_way()) ? this.commonLogic.updateAgent_admoney(dc_appl_money, agent, XcbConstantValue.TB_TYPE_MINUS) : this.commonLogic.updateAgent_agentmoney(dc_appl_money, agent, XcbConstantValue.TB_TYPE_MINUS);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                if ("1".equals(withdrawalAppl.getSr_way()) && "Y".equals(agent.getSr_is_month())) {
                                    result = this.commonLogic.updateAgent_maxmoney(dc_appl_money, agent, XcbConstantValue.TB_TYPE_MINUS);
                                }
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.success"));
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                                } else {
                                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.fail"));
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                }
                            } else {
                                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.fail"));
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            }
                        } else if (XcbConstantValue.WITHDRAWAL_APPL_WX.equals(withdrawalAppl.getSr_type()) || XcbConstantValue.WITHDRAWAL_APPL_YHK.equals(withdrawalAppl.getSr_type()) || XcbConstantValue.WITHDRAWAL_APPL_DG.equals(withdrawalAppl.getSr_type())) {
                            ret_method = this.payToAgent(identifier, withdrawalAppl, "\u7cfb\u7edf\u5ba1\u6279", "auto");
                        } else if (XcbConstantValue.WITHDRAWAL_APPL_XX.equals(withdrawalAppl.getSr_type())) {
                            result = "2".equals(withdrawalAppl.getSr_way()) ? this.commonLogic.updateAgent_admoney(dc_appl_money, agent, XcbConstantValue.TB_TYPE_MINUS) : this.commonLogic.updateAgent_agentmoney(dc_appl_money, agent, XcbConstantValue.TB_TYPE_MINUS);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                if ("1".equals(withdrawalAppl.getSr_way()) && "Y".equals(agent.getSr_is_month())) {
                                    result = this.commonLogic.updateAgent_maxmoney(dc_appl_money, agent, XcbConstantValue.TB_TYPE_MINUS);
                                }
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.success"));
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                                } else {
                                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.fail"));
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                }
                            } else {
                                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.fail"));
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            }
                        }
                    } else {
                        ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.fail"));
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    }
                } else {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.status.warn", sysParam.getSr_param_value()));
                }
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.warn"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            result = XcbStringUtils.getObjtoint(ret_method.get(XcbConstantValue.STATUS));
            if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.WITHDRAWAL_APPL_CREATE, PromptProperties.getProperty("withdrawalAppl.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> createWithdrawalAppl_cpy(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        try {
            Tb_agent agent = this.agentDao.findAgentById_agent(withdrawalAppl.getSw_agent_id());
            if (!XcbStringUtils.isNullOrBlank((Object)agent.getSr_admin_id())) {
                agent = this.agentDao.findAgentById_agent(XcbStringUtils.getObjtoint((Object)agent.getSr_admin_id()));
            }
            Tb_wx_pay_info pay_info = this.wxPayInfoDao.findDefaultPayOut(agent.getSw_company_id());
            if (XcbConstantValue.WITHDRAWAL_APPL_WX.equals(agent.getSr_pay_way())) {
                pay_info = this.wxPayInfoDao.findUserDefaultPayOutByCpy(agent.getSw_company_id());
            }
            withdrawalAppl.setSi_create_person(withdrawalAppl.getSw_agent_id());
            withdrawalAppl.setTm_create_time(new Date());
            withdrawalAppl.setSi_modify_person(withdrawalAppl.getSw_agent_id());
            withdrawalAppl.setTm_modify_time(new Date());
            withdrawalAppl.setSr_mchid(pay_info.getSub_mchid());
            result = this.withdrawalApplDao.createWithdrawalAppl(withdrawalAppl);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.success"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.WITHDRAWAL_APPL_CREATE, PromptProperties.getProperty("withdrawalAppl.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findWithdrawalApplByParam_agent(Identifier identifier, Tb_withdrawal_appl withdrawalAppl, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_withdrawal_appl> applList = null;
            int totalCount = 0;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(withdrawalAppl.getSw_agent_id());
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                withdrawalAppl.setSw_agent_id(Integer.valueOf(XcbStringUtils.getObjtoint((Object)adminAgent.getSr_admin_id())));
            }
            applList = this.withdrawalApplDao.findWithdrawalApplByParam_agent(withdrawalAppl, page);
            totalCount = this.withdrawalApplDao.findCountByParam_agent(withdrawalAppl);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("applList", applList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.WITHDRAWAL_APPL_FIND_BYPARAM, PromptProperties.getProperty("withdrawalAppl.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findWithdrawalApplAgentInfoByParam_agent(Tb_withdrawal_appl withdrawalAppl) {
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        Tb_statistics statistics = new Tb_statistics();
        statistics.setSw_agent_id(withdrawalAppl.getSw_agent_id());
        statistics.setSr_login_type(withdrawalAppl.getSr_login_type());
        try {
            this.statisticsService.getAgentMoney(statistics.getSr_login_type(), statistics.getSw_company_id(), statistics.getSw_agent_id(), dataMap);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.WITHDRAWAL_APPL_FIND_AGENTINFO_BYPARAM, PromptProperties.getProperty("withdrawalAppl.findbyparam.fail"), (Throwable)e);
        }
        return dataMap;
    }

    private Map<String, Object> findWithdrawalApplByParam_cpy(Identifier identifier, Tb_withdrawal_appl withdrawalAppl, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_withdrawal_appl> applList = this.withdrawalApplDao.findWithdrawalApplByParam_cpy(withdrawalAppl, page);
            int totalCount = this.withdrawalApplDao.findCountByParam_cpy(withdrawalAppl);
            for (Tb_withdrawal_appl appl : applList) {
                BigDecimal cpyBonus;
                Integer sw_agent_id = appl.getSw_agent_id();
                BigDecimal dc_appl_money = appl.getDc_appl_money();
                if (appl.getSi_code() == 0) {
                    appl.setSr_code("\u6b63\u5e38");
                } else {
                    appl.setSr_code("\u5f02\u5e38");
                }
                Tb_agent agent = this.agentDao.findAgentById_agent(sw_agent_id);
                BigDecimal allbonus = cpyBonus = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_bonus()).divide(new BigDecimal(100));
                dc_appl_money = BigDecimalUtil.mul((BigDecimal)BigDecimalUtil.sub((BigDecimal)new BigDecimal(1), (BigDecimal)allbonus), (BigDecimal)dc_appl_money);
                appl.setDc_temp_income_money(dc_appl_money);
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("applList", applList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.WITHDRAWAL_APPL_FIND_BYPARAM_CPY, PromptProperties.getProperty("withdrawalAppl.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findAllWithdrawalApplByParam_cpy(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_withdrawal_appl> applList = this.withdrawalApplDao.findAllWithdrawalApplByParam_cpy(withdrawalAppl);
            int totalCount = applList.size();
            for (Tb_withdrawal_appl appl : applList) {
                BigDecimal cpyBonus;
                Integer sw_agent_id = appl.getSw_agent_id();
                BigDecimal dc_appl_money = appl.getDc_appl_money();
                if (appl.getSi_code() == 0) {
                    appl.setSr_code("\u6b63\u5e38");
                } else {
                    appl.setSr_code("\u5f02\u5e38");
                }
                Tb_agent agent = this.agentDao.findAgentById_agent(sw_agent_id);
                BigDecimal allbonus = cpyBonus = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_bonus()).divide(new BigDecimal(100));
                dc_appl_money = BigDecimalUtil.mul((BigDecimal)BigDecimalUtil.sub((BigDecimal)new BigDecimal(1), (BigDecimal)allbonus), (BigDecimal)dc_appl_money);
                appl.setDc_temp_income_money(dc_appl_money);
                appl.setSr_path(XcbConstantValue.server_host + "/jcgweb-company");
                appl.setSr_path_name(XcbConstantValue.title);
            }
            Page page = new Page();
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("applList", applList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.WITHDRAWAL_APPL_FIND_ALL_BYPARAM_CPY, PromptProperties.getProperty("withdrawalAppl.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> payToAgent(Identifier identifier, Tb_withdrawal_appl withdrawalAppl, String sr_appl_person, String way) {
        HashMap<String, Object> ret_method = new HashMap<String, String>();
        try {
            Tb_withdrawal_appl appl = this.withdrawalApplDao.findWithdrawalApplById(withdrawalAppl.getSd_id());
            if (XcbConstantValue.WITHDRAWAL_APPL_STATUS_DSP.equals(appl.getSr_status())) {
                ret_method = this.qiye_remittance_agent(appl, sr_appl_person, way);
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.status.error", appl.getSr_status_desc()));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.WITHDRAWAL_APPL_PAY, PromptProperties.getProperty("withdrawalAppl.pay.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> payToAgentWithXx(String sr_appl_person, Tb_withdrawal_appl withdrawalAppl, Tb_agent agent, BigDecimal dc_income_momey, String nowDate) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        try {
            String cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
            Tb_cash_stream cashflow = new Tb_cash_stream();
            cashflow.setSd_cash_id(cash_trade_no);
            cashflow.setSw_agent_id(agent.getSd_agent_id());
            cashflow.setDc_cashflow_money(withdrawalAppl.getDc_appl_money());
            if ("1".equals(withdrawalAppl.getSr_way())) {
                cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
            } else {
                cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_GGTX);
            }
            cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
            cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
            cashflow.setSi_create_person(agent.getSd_agent_id());
            cashflow.setSi_modify_person(agent.getSd_agent_id());
            cashflow.setSr_modify_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
            cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
            cashflow.setSr_remarks(withdrawalAppl.getSr_type_desc());
            this.log.info("\u521b\u5efa\u8d44\u91d1\u6d41\u6c34remittance_agent_wx cash_trade_no\uff1a" + cash_trade_no + "---------end----\u65f6\u95f4\uff1a" + XcbDateUtil.getCurrentDate((String)"yyyyMMddHHmmssSSS"));
            result = this.cashStreamDao.createCashStream(cashflow);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                result = this.commonLogic.updateOnlyAgent_txmoney(withdrawalAppl.getDc_appl_money(), agent);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Tb_withdrawal_appl appl = new Tb_withdrawal_appl();
                    appl.setSd_id(withdrawalAppl.getSd_id());
                    appl.setTm_appl_time(new Date());
                    appl.setDc_income_money(dc_income_momey);
                    appl.setSr_appl_person(sr_appl_person);
                    appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                    result = this.withdrawalApplDao.updateWithdrawalAppl_cpy(appl);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.update.success"));
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    } else {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.updateappl.fail"));
                    }
                } else {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.updatetx.fail"));
                }
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.createcash.fail"));
                this.log.error(PromptProperties.getProperty("withdrawalAppl.pay.createcash.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.WITHDRAWAL_APPL_CREATE, PromptProperties.getProperty("withdrawalAppl.pay.xx.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> payToAgentWithSf(String sr_appl_person, Tb_withdrawal_appl withdrawalAppl, Tb_agent agent, BigDecimal dc_income_momey, String nowDate) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        try {
            Tb_withdrawal_appl appl = new Tb_withdrawal_appl();
            appl.setSd_id(withdrawalAppl.getSd_id());
            appl.setTm_appl_time(new Date());
            appl.setDc_income_money(dc_income_momey);
            appl.setSr_appl_person(sr_appl_person);
            appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
            result = this.withdrawalApplDao.updateWithdrawalAppl_cpy(appl);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.update.success"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.updateappl.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.WITHDRAWAL_APPL_CREATE, PromptProperties.getProperty("withdrawalAppl.pay.xx.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> updateWithdrawalAppl_cpy(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        Map<String, Object> ret_method = new HashMap<String, Object>();
        String nowDate = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss");
        int result = 0;
        try {
            Tb_withdrawal_appl o_appl = this.withdrawalApplDao.findWithdrawalApplById(withdrawalAppl.getSd_id());
            Tb_agent agent = this.agentDao.findAgentById_agent(o_appl.getSw_agent_id());
            if (XcbConstantValue.WITHDRAWAL_APPL_STATUS_DSP.equals(o_appl.getSr_status())) {
                if (XcbConstantValue.WITHDRAWAL_APPL_STATUS_YJJ.equals(withdrawalAppl.getSr_status())) {
                    withdrawalAppl.setTm_appl_time(new Date());
                    withdrawalAppl.setSr_appl_person(identifier.getUserName());
                    result = this.withdrawalApplDao.updateWithdrawalAppl_cpy(withdrawalAppl);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        if (XcbConstantValue.WITHDRAWAL_APPL_SF.equals(o_appl.getSr_type())) {
                            ret_method.put(XcbConstantValue.MSG, "\u5ba1\u6279\u6210\u529f\uff0c\u5df2\u62d2\u7edd\u7533\u8bf7");
                            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        } else {
                            result = "2".equals(o_appl.getSr_way()) ? this.commonLogic.updateAgent_admoney(o_appl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_ADD) : this.commonLogic.updateAgent_agentmoney(o_appl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_ADD);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                if ("1".equals(o_appl.getSr_way()) && "Y".equals(agent.getSr_is_month())) {
                                    result = this.commonLogic.updateAgent_maxmoney(o_appl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_ADD);
                                }
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.YJJ.success"));
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                                } else {
                                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.update.fail"));
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                }
                            } else {
                                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.update.fail"));
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            }
                        }
                    } else {
                        ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.update.fail"));
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    }
                } else if (XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG.equals(withdrawalAppl.getSr_status())) {
                    BigDecimal cpyBonus;
                    BigDecimal agent_once_money = o_appl.getDc_appl_money();
                    BigDecimal allbonus = cpyBonus = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_bonus()).divide(new BigDecimal(100));
                    result = 1;
                    if (result > XcbConstantValue.OPERA_INT_ZERO && BigDecimalUtil.compareToZero((BigDecimal)(agent_once_money = BigDecimalUtil.mul((BigDecimal)BigDecimalUtil.sub((BigDecimal)new BigDecimal(1), (BigDecimal)allbonus), (BigDecimal)agent_once_money)))) {
                        ret_method = XcbConstantValue.WITHDRAWAL_APPL_SF.equals(o_appl.getSr_type()) ? this.payToAgentWithSf(identifier.getUserName(), o_appl, agent, agent_once_money, nowDate) : this.payToAgentWithXx(identifier.getUserName(), o_appl, agent, agent_once_money, nowDate);
                        result = XcbStringUtils.getObjtoint((Object)ret_method.get(XcbConstantValue.STATUS));
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.update.success"));
                            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        } else {
                            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.update.fail"));
                            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        }
                    }
                }
                if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                    TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                }
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.update.warn"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.WITHDRAWAL_APPL_UPDATE_CPY, PromptProperties.getProperty("withdrawalAppl.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> qiye_remittance_agent(Tb_withdrawal_appl withdrawalAppl, String sr_appl_person, String way) {
        HashMap<String, Object> ret_method = new HashMap<String, String>();
        String nowDate = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd");
        BigDecimal max_qycurrentday_money = new BigDecimal("0");
        BigDecimal max_agentcurrentday_money = new BigDecimal("0");
        BigDecimal qy_currentday_money = new BigDecimal("0");
        BigDecimal agent_currentday_money = new BigDecimal("0");
        BigDecimal max_agent_once_money = new BigDecimal("0");
        BigDecimal min_agent_full_money = new BigDecimal("0");
        ArrayList<String> keyCodelist = new ArrayList<String>();
        keyCodelist.add(XcbConstantValue.HK_DLS_FULL_MONEY);
        keyCodelist.add(XcbConstantValue.HK_DLS_ONCE_MOST);
        keyCodelist.add(XcbConstantValue.HK_DLS_DAY_MOST);
        keyCodelist.add(XcbConstantValue.HK_QY_DAY_MOST);
        Tb_sys_param sysParam = new Tb_sys_param();
        sysParam.setSr_category_code(XcbConstantValue.XTCL);
        sysParam.setSr_key_code_list(keyCodelist);
        List<Tb_sys_param> sysParamList = this.sysParamDao.findSysParamByKeyCodeForBusinessTask(sysParam);
        if (sysParamList != null && sysParamList.size() > 0) {
            for (Tb_sys_param tb_sys_param : sysParamList) {
                if (XcbConstantValue.HK_DLS_FULL_MONEY.equals(tb_sys_param.getSr_key_code())) {
                    min_agent_full_money = XcbStringUtils.getObjToBigDecimal((Object)tb_sys_param.getSr_param_value());
                }
                if (XcbConstantValue.HK_DLS_ONCE_MOST.equals(tb_sys_param.getSr_key_code())) {
                    max_agent_once_money = XcbStringUtils.getObjToBigDecimal((Object)tb_sys_param.getSr_param_value());
                }
                if (XcbConstantValue.HK_DLS_DAY_MOST.equals(tb_sys_param.getSr_key_code())) {
                    max_agentcurrentday_money = XcbStringUtils.getObjToBigDecimal((Object)tb_sys_param.getSr_param_value());
                }
                if (!XcbConstantValue.HK_QY_DAY_MOST.equals(tb_sys_param.getSr_key_code())) continue;
                max_qycurrentday_money = XcbStringUtils.getObjToBigDecimal((Object)tb_sys_param.getSr_param_value());
            }
            if (!(BigDecimalUtil.compareToZero((BigDecimal)min_agent_full_money) && BigDecimalUtil.compareToZero((BigDecimal)max_agent_once_money) && BigDecimalUtil.compareToZero((BigDecimal)max_agentcurrentday_money) && BigDecimalUtil.compareToZero((BigDecimal)max_qycurrentday_money))) {
                this.log.error("\u4f01\u4e1a\u6c47\u6b3e-\u4ee3\u7406\u5546\u7ed3\u7b97\uff1a \u6c47\u6b3e\u7684\u7cfb\u7edf\u53c2\u6570\u8bbe\u7f6e\u9519\u8bef1");
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u8d44\u91d1\u63d0\u73b0\u5931\u8d25:\u7cfb\u7edf\u53c2\u6570\u5f02\u5e38", "", "");
                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                operationLogs.setSr_operate_primarykey("");
                operationLogs.setSr_operate_table("");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("sysparam.find.error"));
                return ret_method;
            }
        } else {
            this.log.error("\u4f01\u4e1a\u6c47\u6b3e-\u4ee3\u7406\u5546\u7ed3\u7b97\uff1a \u6c47\u6b3e\u7684\u7cfb\u7edf\u53c2\u6570\u8bbe\u7f6e\u9519\u8bef2");
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u8d44\u91d1\u63d0\u73b0\u5931\u8d25:\u7cfb\u7edf\u53c2\u6570\u5217\u8868\u4e3a\u7a7a", "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.PC);
            operationLogs.setSr_operate_primarykey("");
            operationLogs.setSr_operate_table("");
            this.operationLogServiceImpl.createOperaLog(operationLogs);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("sysparam.find.fail"));
            return ret_method;
        }
        try {
            ret_method = this.remittance_agent_yj(withdrawalAppl, qy_currentday_money, max_qycurrentday_money, agent_currentday_money, max_agentcurrentday_money, nowDate, sr_appl_person, way);
        }
        catch (Exception e) {
            this.log.error("\u4ee3\u7406\u5546\u63d0\u73b0\u5f02\u5e38:" + e.getMessage());
        }
        return ret_method;
    }

    public Map<String, Object> remittance_agent_yj(Tb_withdrawal_appl withdrawalAppl, BigDecimal qy_currentday_money, BigDecimal max_qycurrentday_money, BigDecimal agent_currentday_money, BigDecimal max_agentcurrentday_money, String nowDate, String sr_appl_person, String way) {
        Map<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        String msg = "";
        try {
            BigDecimal cpyBonus;
            Integer sw_agent_id = withdrawalAppl.getSw_agent_id();
            Tb_agent agent = this.agentDao.findAgentById_agent(sw_agent_id);
            if (!XcbStringUtils.isNullOrBlank((Object)agent.getSr_admin_id())) {
                agent = this.agentDao.findAgentById_agent(XcbStringUtils.getObjtoint((Object)agent.getSr_admin_id()));
            }
            Tb_wx_pay_info pay_info = this.wxPayInfoDao.findDefaultPayOut(agent.getSw_company_id());
            if (XcbConstantValue.WITHDRAWAL_APPL_WX.equals(agent.getSr_pay_way())) {
                pay_info = this.wxPayInfoDao.findUserDefaultPayOutByCpy(agent.getSw_company_id());
            }
            String sr_pay_type = agent.getSr_pay_way();
            BigDecimal agent_once_money = withdrawalAppl.getDc_appl_money();
            if (new BigDecimal(0).compareTo(agent_once_money) >= 0) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.money.iszero.warn"));
                return ret_method;
            }
            Tb_withdrawal_appl cpy_appl = new Tb_withdrawal_appl();
            cpy_appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
            cpy_appl.setSr_appl_time(nowDate);
            cpy_appl.setSr_type(agent.getSr_pay_way());
            List<Tb_withdrawal_appl> cpy_applList = this.withdrawalApplDao.findWithdrawalApplByParam(cpy_appl);
            if (cpy_applList != null && cpy_applList.size() > 0) {
                for (Tb_withdrawal_appl o_appl : cpy_applList) {
                    BigDecimal tempMoney = XcbStringUtils.getObjToBigDecimal((Object)o_appl.getDc_appl_money());
                    qy_currentday_money = BigDecimalUtil.add((BigDecimal)qy_currentday_money, (BigDecimal)tempMoney);
                }
            }
            if (max_qycurrentday_money.compareTo(qy_currentday_money = BigDecimalUtil.add((BigDecimal)qy_currentday_money, (BigDecimal)agent_once_money)) <= 0) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.qymax.warn"));
                return ret_method;
            }
            Tb_withdrawal_appl agent_appl = new Tb_withdrawal_appl();
            agent_appl.setSw_agent_id(sw_agent_id);
            agent_appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
            agent_appl.setSr_appl_time(nowDate);
            agent_appl.setSr_type(agent.getSr_pay_way());
            List<Tb_withdrawal_appl> agent_applList = this.withdrawalApplDao.findWithdrawalApplByParam(agent_appl);
            if (agent_applList != null && agent_applList.size() > 0) {
                for (Tb_withdrawal_appl o_appl : agent_applList) {
                    BigDecimal tempMoney = XcbStringUtils.getObjToBigDecimal((Object)o_appl.getDc_appl_money());
                    agent_currentday_money = BigDecimalUtil.add((BigDecimal)agent_currentday_money, (BigDecimal)tempMoney);
                }
            }
            agent_currentday_money = BigDecimalUtil.add((BigDecimal)agent_currentday_money, (BigDecimal)agent_once_money);
            if (XcbConstantValue.WITHDRAWAL_APPL_YHK.equals(sr_pay_type) || XcbConstantValue.WITHDRAWAL_APPL_DG.equals(sr_pay_type)) {
                if (max_agentcurrentday_money.compareTo(agent_currentday_money) == -1) {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.agentmax.warn2", max_agentcurrentday_money));
                    return ret_method;
                }
            } else if (max_agentcurrentday_money.compareTo(agent_currentday_money) == -1) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.agentmax.warn2", max_agentcurrentday_money));
                return ret_method;
            }
            BigDecimal allbonus = cpyBonus = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_bonus()).divide(new BigDecimal(100));
            result = 1;
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                BigDecimal agent_once_money_ori = withdrawalAppl.getDc_appl_money();
                agent_once_money = BigDecimalUtil.mul((BigDecimal)BigDecimalUtil.sub((BigDecimal)new BigDecimal(1), (BigDecimal)allbonus), (BigDecimal)agent_once_money);
                if (agent_once_money.compareTo(new BigDecimal(1)) >= 0) {
                    ret_method = XcbConstantValue.PAY_QY.equals(pay_info.getSr_pay_type()) ? (XcbConstantValue.WITHDRAWAL_APPL_YHK.equals(sr_pay_type) || XcbConstantValue.WITHDRAWAL_APPL_DG.equals(sr_pay_type) ? this.remittance_agent_sdj(withdrawalAppl, agent, agent_once_money_ori, agent_once_money, this.AGENT_JY, nowDate, sr_appl_person, way, pay_info) : this.remittance_agent_wx(withdrawalAppl, agent, agent_once_money_ori, agent_once_money, this.AGENT_JY, nowDate, sr_appl_person, way, pay_info)) : this.remittance_agent_wx_sj(withdrawalAppl, agent, agent_once_money_ori, agent_once_money, this.AGENT_JY, nowDate, sr_appl_person, way, pay_info);
                } else {
                    TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u5b9e\u9645\u5230\u8d26\u91d1\u989d\u5fc5\u987b\u5927\u4e8e1\u5143");
                }
            } else {
                this.log.error("\u4f01\u4e1a\u6c47\u6b3e\uff0c\u62bd\u4f63\u4e1a\u52a1\u5904\u7406\u62a5\u9519:" + msg);
                try {
                    TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                }
                catch (Exception e) {
                    this.log.error("\u4f01\u4e1a\u6c47\u6b3e\uff0c\u4e8b\u52a1\u56de\u6eda\u62a5\u9519");
                }
            }
        }
        catch (Exception ex) {
            try {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
            catch (Exception e) {
                this.log.error("\u4f01\u4e1a\u6c47\u6b3e\uff0c\u4e8b\u52a1\u56de\u6eda\u62a5\u9519");
            }
            this.log.error("\u4f01\u4e1a\u6c47\u6b3e-\u4ee3\u7406\u5546\u7ed3\u7b97\u62a5\u9519\uff1a " + XcbStringUtils.exceptionToString((Exception)ex));
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4ee3\u7406\u5546\u7ed3\u7b97", "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.PC);
            operationLogs.setSr_operate_primarykey("");
            operationLogs.setSr_operate_table("");
            this.operationLogServiceImpl.createOperaLog(operationLogs);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.update.error"));
        }
        return ret_method;
    }

    public Map<String, Object> remittance_agent_wx(Tb_withdrawal_appl withdrawalAppl, Tb_agent agent, BigDecimal agent_once_money_ori, BigDecimal agent_once_money, String flow_type, String act_time, String sr_appl_person, String way, Tb_wx_pay_info pay_info) throws Exception {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        this.log.info("#######################\u6253\u6b3e\u5230\u5fae\u4fe1\u4f59\u989d\u5f00\u59cb #######################");
        int result = 0;
        String error_msg = "";
        String zf_money_fen = CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)agent_once_money));
        String sr_account_name = agent.getSr_wx_actname();
        String zf_desc = pay_info.getSr_payment_desc();
        String cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
        EnterprisesPayment enterprisesPayment = new EnterprisesPayment();
        enterprisesPayment.setMch_appid(pay_info.getSr_wx_gzh_appid());
        enterprisesPayment.setMchid(pay_info.getSub_mchid());
        enterprisesPayment.setNonce_str(UUidUtils.getUUid());
        enterprisesPayment.setPartner_trade_no(cash_trade_no);
        enterprisesPayment.setOpenid(agent.getSr_open_id());
        enterprisesPayment.setCheck_name("FORCE_CHECK");
        enterprisesPayment.setRe_user_name(sr_account_name);
        enterprisesPayment.setAmount(XcbStringUtils.getObjtoint((Object)zf_money_fen));
        enterprisesPayment.setDesc(zf_desc);
        enterprisesPayment.setSpbill_create_ip(pay_info.getSr_payserver_ip());
        String apiKey = pay_info.getSub_merkey_v2();
        this.log.info("sign key ============{}", (Object)apiKey);
        String sign = Signature.getSign(apiKey, enterprisesPayment);
        enterprisesPayment.setSign(sign);
        this.log.info("sign====={}", (Object)sign);
        String xmlWithdrawInfo = this.wxWithdrawTools.getXMLStringForObj(enterprisesPayment);
        this.log.info("\u63d0\u73b0\u53c2\u6570\u4e3a======{}", (Object)xmlWithdrawInfo);
        String response = this.wxWithdrawTools.postParamesForUrl(xmlWithdrawInfo, "https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers", pay_info);
        this.log.info("\u63d0\u73b0\u7ed3\u679c\u4e3a==={}", (Object)response);
        Map return_data = null;
        try {
            return_data = WXPayUtil.xmlToMap((String)response);
        }
        catch (Exception e) {
            this.log.error("\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u652f\u4ed8\u8fd4\u56de\u7ed3\u679c\u89e3\u6790\u5931\u8d25:" + XcbStringUtils.exceptionToString((Exception)e));
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u652f\u4ed8\u8fd4\u56de\u7ed3\u679c\u89e3\u6790\u5931\u8d25\uff0ccash_trade_no\uff1a" + cash_trade_no, "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.PC);
            operationLogs.setSr_operate_primarykey("");
            operationLogs.setSr_operate_table("");
            this.operationLogServiceImpl.createOperaLog(operationLogs);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.wx.error"));
            return ret_method;
        }
        String return_code = (String)return_data.get("return_code");
        String result_code = (String)return_data.get("result_code");
        if ("SUCCESS".equals(return_code)) {
            try {
                Tb_operation_logs operationLogs;
                this.log.info("\u521b\u5efa\u8d44\u91d1\u6d41\u6c34remittance_agent_wx cash_trade_no\uff1a" + cash_trade_no + "---------start----\u65f6\u95f4\uff1a" + XcbDateUtil.getCurrentDate((String)"yyyyMMddHHmmssSSS"));
                Tb_cash_stream cashflow = new Tb_cash_stream();
                cashflow.setSd_cash_id(cash_trade_no);
                cashflow.setSw_agent_id(agent.getSd_agent_id());
                cashflow.setDc_cashflow_money(agent_once_money_ori);
                if ("1".equals(withdrawalAppl.getSr_way())) {
                    cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
                } else {
                    cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_GGTX);
                }
                cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                cashflow.setSr_remarks("\u4f01\u4e1a\u6253\u6b3e\u5230\u5fae\u4fe1\u96f6\u94b1");
                this.log.info("\u521b\u5efa\u8d44\u91d1\u6d41\u6c34remittance_agent_wx cash_trade_no\uff1a" + cash_trade_no + "---------end----\u65f6\u95f4\uff1a" + XcbDateUtil.getCurrentDate((String)"yyyyMMddHHmmssSSS"));
                if ("AGENT_JY".equals(flow_type)) {
                    Tb_operation_logs operationLogs2;
                    result = this.cashStreamDao.createCashStream(cashflow);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u521b\u5efa\u8d44\u91d1\u63d0\u73b0\u6d41\u6c34\u5f02\u5e38: \u6d41\u6c34\u53f7:" + cash_trade_no + "\uff0c\u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u6d41\u6c34\u91d1\u989d:" + agent_once_money_ori + ",\u8d44\u91d1\u7c7b\u578b: \u7ecf\u8425\u6536\u5165 ";
                        this.log.error(error_msg);
                        operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey("");
                        operationLogs.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                    if ((result = this.commonLogic.updateOnlyAgent_txmoney(agent_once_money_ori, agent)) <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u63d0\u73b0\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u63d0\u73b0\u91d1\u989d:" + agent.getDc_tx_money();
                        this.log.error(error_msg);
                        operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey("");
                        operationLogs.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                    BigDecimal dcMoney = BigDecimal.ZERO;
                    if ("auto".equals(way)) {
                        if ("1".equals(withdrawalAppl.getSr_way()) && "Y".equals(agent.getSr_is_month()) && (result = this.commonLogic.updateAgent_maxmoney(withdrawalAppl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_MINUS)) <= XcbConstantValue.OPERA_INT_ZERO) {
                            error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u8d26\u6237\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u8d26\u6237\u91d1\u989d:" + agent.getDc_max_money();
                            this.log.error(error_msg);
                            Tb_operation_logs operationLogs3 = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                            operationLogs3.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs3.setSr_operate_primarykey("");
                            operationLogs3.setSr_operate_table("");
                            this.operationLogServiceImpl.createOperaLog(operationLogs3);
                        }
                        BigDecimal dc_agent_money = agent.getDc_agent_money();
                        if ("2".equals(withdrawalAppl.getSr_way())) {
                            dc_agent_money = agent.getDc_ad_money();
                            result = this.commonLogic.updateAgent_admoney(withdrawalAppl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_MINUS);
                        } else {
                            result = this.commonLogic.updateAgent_agentmoney(withdrawalAppl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_MINUS);
                        }
                        if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                            error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u8d26\u6237\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u8d26\u6237\u91d1\u989d:" + dc_agent_money;
                            this.log.error(error_msg);
                            operationLogs2 = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                            operationLogs2.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs2.setSr_operate_primarykey("");
                            operationLogs2.setSr_operate_table("");
                            this.operationLogServiceImpl.createOperaLog(operationLogs2);
                        }
                    }
                    Tb_withdrawal_appl appl = new Tb_withdrawal_appl();
                    appl.setSd_id(withdrawalAppl.getSd_id());
                    appl.setTm_appl_time(new Date());
                    appl.setDc_income_money(agent_once_money);
                    appl.setSr_appl_person(sr_appl_person);
                    appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                    if (!"SUCCESS".equals(result_code)) {
                        appl.setSi_code(Integer.valueOf(1));
                    }
                    if ((result = this.withdrawalApplDao.updateWithdrawalAppl_cpy(appl)) <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u66f4\u65b0\u63d0\u73b0\u7533\u8bf7\u8bb0\u5f55\u5f02\u5e38,\u7533\u8bf7\u7f16\u53f7:" + withdrawalAppl.getSd_id() + "\u5b9e\u9645\u6253\u6b3e\u91d1\u989d:" + agent_once_money;
                        this.log.error(error_msg);
                        operationLogs2 = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs2.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs2.setSr_operate_primarykey("");
                        operationLogs2.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs2);
                    }
                } else {
                    cashflow.setSr_remarks("\u8fd4\u70b9\u6536\u5165");
                    result = this.cashStreamDao.createCashStream(cashflow);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u521b\u5efa\u8d44\u91d1\u63d0\u73b0\u6d41\u6c34\u5f02\u5e38: \u6d41\u6c34\u53f7:" + cash_trade_no + "\uff0c\u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u6d41\u6c34\u91d1\u989d:" + agent_once_money_ori + ",\u8d44\u91d1\u7c7b\u578b: \u8fd4\u70b9\u6536\u5165 ";
                        this.log.error(error_msg);
                        operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey("");
                        operationLogs.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                }
                if (!"SUCCESS".equals(result_code)) {
                    error_msg = "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u4ed8\u6b3e\u901a\u4fe1\u6210\u529f\uff0c\u4f46\u652f\u4ed8\u7ed3\u679c\u53ef\u80fd\u5931\u8d25\u4e86\uff01cash_trade_no\uff1a" + cash_trade_no;
                    this.log.error(error_msg);
                    operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u4ed8\u6b3e\u901a\u4fe1\u6210\u529f\uff0c\u4f46\u652f\u4ed8\u7ed3\u679c\u53ef\u80fd\u5931\u8d25\u4e86\uff01cash_trade_no\uff1a" + cash_trade_no, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.PC);
                    operationLogs.setSr_operate_primarykey("");
                    operationLogs.setSr_operate_table("");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.wx.success"));
            }
            catch (Exception e) {
                error_msg = "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u5f02\u5e38:" + XcbStringUtils.exceptionToString((Exception)e);
                this.log.error(error_msg);
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u4ed8\u6b3e\u66f4\u65b0\u6d41\u6c34\u72b6\u6001\u5931\u8d25\uff0ccash_trade_no\uff1a" + cash_trade_no, "", "");
                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                operationLogs.setSr_operate_primarykey("");
                operationLogs.setSr_operate_table("");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.error"));
            }
        } else {
            this.log.info("\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u4ed8\u6b3e\u901a\u4fe1\u5f02\u5e38\uff0cresult_code: " + result_code + "  cash_trade_no\uff1a" + cash_trade_no);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.wx.fail2"));
        }
        this.log.info("#######################\u6253\u6b3e\u5230\u5fae\u4fe1\u4f59\u989d\u7ed3\u675f #######################");
        return ret_method;
    }

    public Map<String, Object> remittance_agent_wx_sj(Tb_withdrawal_appl withdrawalAppl, Tb_agent agent, BigDecimal agent_once_money_ori, BigDecimal agent_once_money, String flow_type, String act_time, String sr_appl_person, String way, Tb_wx_pay_info pay_info) throws Exception {
        Map<Object, Object> ret_method = new HashMap();
        this.log.info("#######################\u6253\u6b3e\u5230\u5fae\u4fe1\u4f59\u989d\u5f00\u59cb #######################");
        int result = 0;
        String error_msg = "";
        int zf_money_fen = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)agent_once_money)));
        String cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
        ret_method = this.wxAPIV3Common.wx_pay(pay_info, zf_money_fen, agent, cash_trade_no);
        result = XcbStringUtils.getObjtoint((Object)ret_method.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            try {
                this.log.info("\u521b\u5efa\u8d44\u91d1\u6d41\u6c34remittance_agent_wx cash_trade_no\uff1a" + cash_trade_no + "---------start----\u65f6\u95f4\uff1a" + XcbDateUtil.getCurrentDate((String)"yyyyMMddHHmmssSSS"));
                Tb_cash_stream cashflow = new Tb_cash_stream();
                cashflow.setSd_cash_id(cash_trade_no);
                cashflow.setSw_agent_id(agent.getSd_agent_id());
                cashflow.setDc_cashflow_money(agent_once_money_ori);
                if ("1".equals(withdrawalAppl.getSr_way())) {
                    cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
                } else {
                    cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_GGTX);
                }
                cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                cashflow.setSr_remarks("\u4f01\u4e1a\u6253\u6b3e\u5230\u5fae\u4fe1\u96f6\u94b1");
                this.log.info("\u521b\u5efa\u8d44\u91d1\u6d41\u6c34remittance_agent_wx cash_trade_no\uff1a" + cash_trade_no + "---------end----\u65f6\u95f4\uff1a" + XcbDateUtil.getCurrentDate((String)"yyyyMMddHHmmssSSS"));
                if ("AGENT_JY".equals(flow_type)) {
                    Tb_operation_logs operationLogs;
                    Tb_operation_logs operationLogs2;
                    result = this.cashStreamDao.createCashStream(cashflow);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u521b\u5efa\u8d44\u91d1\u63d0\u73b0\u6d41\u6c34\u5f02\u5e38: \u6d41\u6c34\u53f7:" + cash_trade_no + "\uff0c\u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u6d41\u6c34\u91d1\u989d:" + agent_once_money_ori + ",\u8d44\u91d1\u7c7b\u578b: \u7ecf\u8425\u6536\u5165 ";
                        this.log.error(error_msg);
                        operationLogs2 = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs2.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs2.setSr_operate_primarykey("");
                        operationLogs2.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs2);
                    }
                    if ((result = this.commonLogic.updateOnlyAgent_txmoney(agent_once_money_ori, agent)) <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u63d0\u73b0\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u63d0\u73b0\u91d1\u989d:" + agent.getDc_tx_money();
                        this.log.error(error_msg);
                        operationLogs2 = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs2.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs2.setSr_operate_primarykey("");
                        operationLogs2.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs2);
                    }
                    BigDecimal dcMoney = BigDecimal.ZERO;
                    if ("auto".equals(way)) {
                        if ("1".equals(withdrawalAppl.getSr_way()) && "Y".equals(agent.getSr_is_month()) && (result = this.commonLogic.updateAgent_maxmoney(withdrawalAppl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_MINUS)) <= XcbConstantValue.OPERA_INT_ZERO) {
                            error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u8d26\u6237\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u8d26\u6237\u91d1\u989d:" + agent.getDc_max_money();
                            this.log.error(error_msg);
                            Tb_operation_logs operationLogs3 = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                            operationLogs3.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs3.setSr_operate_primarykey("");
                            operationLogs3.setSr_operate_table("");
                            this.operationLogServiceImpl.createOperaLog(operationLogs3);
                        }
                        BigDecimal dc_agent_money = agent.getDc_agent_money();
                        if ("2".equals(withdrawalAppl.getSr_way())) {
                            dc_agent_money = agent.getDc_ad_money();
                            result = this.commonLogic.updateAgent_admoney(withdrawalAppl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_MINUS);
                        } else {
                            result = this.commonLogic.updateAgent_agentmoney(withdrawalAppl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_MINUS);
                        }
                        if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                            error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u8d26\u6237\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u8d26\u6237\u91d1\u989d:" + dc_agent_money;
                            this.log.error(error_msg);
                            operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                            operationLogs.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs.setSr_operate_primarykey("");
                            operationLogs.setSr_operate_table("");
                            this.operationLogServiceImpl.createOperaLog(operationLogs);
                        }
                    }
                    Tb_withdrawal_appl appl = new Tb_withdrawal_appl();
                    appl.setSd_id(withdrawalAppl.getSd_id());
                    appl.setTm_appl_time(new Date());
                    appl.setDc_income_money(agent_once_money);
                    appl.setSr_appl_person(sr_appl_person);
                    appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                    result = this.withdrawalApplDao.updateWithdrawalAppl_cpy(appl);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u66f4\u65b0\u63d0\u73b0\u7533\u8bf7\u8bb0\u5f55\u5f02\u5e38,\u7533\u8bf7\u7f16\u53f7:" + withdrawalAppl.getSd_id() + "\u5b9e\u9645\u6253\u6b3e\u91d1\u989d:" + agent_once_money;
                        this.log.error(error_msg);
                        operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey("");
                        operationLogs.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                } else {
                    cashflow.setSr_remarks("\u8fd4\u70b9\u6536\u5165");
                    result = this.cashStreamDao.createCashStream(cashflow);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u521b\u5efa\u8d44\u91d1\u63d0\u73b0\u6d41\u6c34\u5f02\u5e38: \u6d41\u6c34\u53f7:" + cash_trade_no + "\uff0c\u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u6d41\u6c34\u91d1\u989d:" + agent_once_money_ori + ",\u8d44\u91d1\u7c7b\u578b: \u8fd4\u70b9\u6536\u5165 ";
                        this.log.error(error_msg);
                        Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey("");
                        operationLogs.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                }
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.wx.success"));
            }
            catch (Exception e) {
                error_msg = "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u5f02\u5e38:" + XcbStringUtils.exceptionToString((Exception)e);
                this.log.error(error_msg);
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u4ed8\u6b3e\u66f4\u65b0\u6d41\u6c34\u72b6\u6001\u5931\u8d25\uff0ccash_trade_no\uff1a" + cash_trade_no, "", "");
                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                operationLogs.setSr_operate_primarykey("");
                operationLogs.setSr_operate_table("");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.error"));
            }
        } else {
            Tb_withdrawal_appl appl = new Tb_withdrawal_appl();
            appl.setSd_id(withdrawalAppl.getSd_id());
            appl.setTm_appl_time(new Date());
            appl.setDc_income_money(agent_once_money);
            appl.setSr_appl_person("\u7cfb\u7edf\u5ba1\u6279");
            appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
            appl.setSi_code(Integer.valueOf(1));
            result = this.withdrawalApplDao.updateWithdrawalAppl_cpy(appl);
            if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                error_msg = "\u66f4\u65b0\u63d0\u73b0\u7533\u8bf7\u8bb0\u5f55\u5f02\u5e38,\u7533\u8bf7\u7f16\u53f7:" + withdrawalAppl.getSd_id() + "\u5b9e\u9645\u6253\u6b3e\u91d1\u989d:" + agent_once_money;
                this.log.error(error_msg);
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                operationLogs.setSr_operate_primarykey("");
                operationLogs.setSr_operate_table("");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
            }
        }
        this.log.info("#######################\u6253\u6b3e\u5230\u5fae\u4fe1\u4f59\u989d\u7ed3\u675f #######################");
        return ret_method;
    }

    public Map<String, Object> remittance_agent_sdj(Tb_withdrawal_appl withdrawalAppl, Tb_agent agent, BigDecimal agent_once_money_ori, BigDecimal agent_once_money, String flow_type, String act_time, String sr_appl_person, String way, Tb_wx_pay_info info) throws Exception {
        HashMap<String, Object> ret = new HashMap();
        int result = 0;
        String error_msg = "";
        try {
            String cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
            ret = this.wxSdjAPICommon.bindingPay(info, agent, agent_once_money, cash_trade_no);
            result = XcbStringUtils.getObjtoint(ret.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                try {
                    this.log.info("\u521b\u5efa\u8d44\u91d1\u6d41\u6c34remittance_agent_wx cash_trade_no\uff1a" + cash_trade_no + "---------start----\u65f6\u95f4\uff1a" + XcbDateUtil.getCurrentDate((String)"yyyyMMddHHmmssSSS"));
                    Tb_cash_stream cashflow = new Tb_cash_stream();
                    cashflow.setSd_cash_id(cash_trade_no);
                    cashflow.setSw_agent_id(agent.getSd_agent_id());
                    cashflow.setDc_cashflow_money(agent_once_money_ori);
                    if ("1".equals(withdrawalAppl.getSr_way())) {
                        cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
                    } else {
                        cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_GGTX);
                    }
                    cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                    cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                    cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                    cashflow.setSr_remarks("\u4f01\u4e1a\u6253\u6b3e\u5230\u5fae\u4fe1\u96f6\u94b1");
                    this.log.info("\u521b\u5efa\u8d44\u91d1\u6d41\u6c34remittance_agent_wx cash_trade_no\uff1a" + cash_trade_no + "---------end----\u65f6\u95f4\uff1a" + XcbDateUtil.getCurrentDate((String)"yyyyMMddHHmmssSSS"));
                    if ("AGENT_JY".equals(flow_type)) {
                        Tb_operation_logs operationLogs;
                        Tb_operation_logs operationLogs2;
                        result = this.cashStreamDao.createCashStream(cashflow);
                        if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                            error_msg = "\u521b\u5efa\u8d44\u91d1\u63d0\u73b0\u6d41\u6c34\u5f02\u5e38: \u6d41\u6c34\u53f7:" + cash_trade_no + "\uff0c\u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u6d41\u6c34\u91d1\u989d:" + agent_once_money_ori + ",\u8d44\u91d1\u7c7b\u578b: \u7ecf\u8425\u6536\u5165 ";
                            this.log.error(error_msg);
                            operationLogs2 = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                            operationLogs2.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs2.setSr_operate_primarykey("");
                            operationLogs2.setSr_operate_table("");
                            this.operationLogServiceImpl.createOperaLog(operationLogs2);
                        }
                        if ((result = this.commonLogic.updateOnlyAgent_txmoney(agent_once_money_ori, agent)) <= XcbConstantValue.OPERA_INT_ZERO) {
                            error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u63d0\u73b0\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u63d0\u73b0\u91d1\u989d:" + agent.getDc_tx_money();
                            this.log.error(error_msg);
                            operationLogs2 = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                            operationLogs2.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs2.setSr_operate_primarykey("");
                            operationLogs2.setSr_operate_table("");
                            this.operationLogServiceImpl.createOperaLog(operationLogs2);
                        }
                        BigDecimal dcMoney = BigDecimal.ZERO;
                        if ("auto".equals(way)) {
                            if ("1".equals(withdrawalAppl.getSr_way()) && "Y".equals(agent.getSr_is_month()) && (result = this.commonLogic.updateAgent_maxmoney(withdrawalAppl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_MINUS)) <= XcbConstantValue.OPERA_INT_ZERO) {
                                error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u8d26\u6237\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u8d26\u6237\u91d1\u989d:" + agent.getDc_max_money();
                                this.log.error(error_msg);
                                Tb_operation_logs operationLogs3 = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                                operationLogs3.setSr_operate_from(XcbConstantValue.PC);
                                operationLogs3.setSr_operate_primarykey("");
                                operationLogs3.setSr_operate_table("");
                                this.operationLogServiceImpl.createOperaLog(operationLogs3);
                            }
                            BigDecimal dc_agent_money = agent.getDc_agent_money();
                            if ("2".equals(withdrawalAppl.getSr_way())) {
                                dc_agent_money = agent.getDc_ad_money();
                                result = this.commonLogic.updateAgent_admoney(withdrawalAppl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_MINUS);
                            } else {
                                result = this.commonLogic.updateAgent_agentmoney(withdrawalAppl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_MINUS);
                            }
                            if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                                error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u8d26\u6237\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u8d26\u6237\u91d1\u989d:" + dc_agent_money;
                                this.log.error(error_msg);
                                operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                                operationLogs.setSr_operate_primarykey("");
                                operationLogs.setSr_operate_table("");
                                this.operationLogServiceImpl.createOperaLog(operationLogs);
                            }
                        }
                        Tb_withdrawal_appl appl = new Tb_withdrawal_appl();
                        appl.setSd_id(withdrawalAppl.getSd_id());
                        appl.setTm_appl_time(new Date());
                        appl.setDc_income_money(agent_once_money);
                        appl.setSr_appl_person(sr_appl_person);
                        appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                        result = this.withdrawalApplDao.updateWithdrawalAppl_cpy(appl);
                        if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                            error_msg = "\u66f4\u65b0\u63d0\u73b0\u7533\u8bf7\u8bb0\u5f55\u5f02\u5e38,\u7533\u8bf7\u7f16\u53f7:" + withdrawalAppl.getSd_id() + "\u5b9e\u9645\u6253\u6b3e\u91d1\u989d:" + agent_once_money;
                            this.log.error(error_msg);
                            operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                            operationLogs.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs.setSr_operate_primarykey("");
                            operationLogs.setSr_operate_table("");
                            this.operationLogServiceImpl.createOperaLog(operationLogs);
                        }
                    } else {
                        cashflow.setSr_remarks("\u8fd4\u70b9\u6536\u5165");
                        result = this.cashStreamDao.createCashStream(cashflow);
                        if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                            error_msg = "\u521b\u5efa\u8d44\u91d1\u63d0\u73b0\u6d41\u6c34\u5f02\u5e38: \u6d41\u6c34\u53f7:" + cash_trade_no + "\uff0c\u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u6d41\u6c34\u91d1\u989d:" + agent_once_money_ori + ",\u8d44\u91d1\u7c7b\u578b: \u8fd4\u70b9\u6536\u5165 ";
                            this.log.error(error_msg);
                            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                            operationLogs.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs.setSr_operate_primarykey("");
                            operationLogs.setSr_operate_table("");
                            this.operationLogServiceImpl.createOperaLog(operationLogs);
                        }
                    }
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.wx.success"));
                }
                catch (Exception e) {
                    error_msg = "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u5f02\u5e38:" + XcbStringUtils.exceptionToString((Exception)e);
                    this.log.error(error_msg);
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u4ed8\u6b3e\u66f4\u65b0\u6d41\u6c34\u72b6\u6001\u5931\u8d25\uff0ccash_trade_no\uff1a" + cash_trade_no, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.PC);
                    operationLogs.setSr_operate_primarykey("");
                    operationLogs.setSr_operate_table("");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.error"));
                }
            } else {
                Tb_withdrawal_appl appl = new Tb_withdrawal_appl();
                appl.setSd_id(withdrawalAppl.getSd_id());
                appl.setTm_appl_time(new Date());
                appl.setDc_income_money(agent_once_money);
                appl.setSr_appl_person("\u7cfb\u7edf\u5ba1\u6279");
                appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                appl.setSi_code(Integer.valueOf(1));
                result = this.withdrawalApplDao.updateWithdrawalAppl_cpy(appl);
                if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                    error_msg = "\u66f4\u65b0\u63d0\u73b0\u7533\u8bf7\u8bb0\u5f55\u5f02\u5e38,\u7533\u8bf7\u7f16\u53f7:" + withdrawalAppl.getSd_id() + "\u5b9e\u9645\u6253\u6b3e\u91d1\u989d:" + agent_once_money;
                    this.log.error(error_msg);
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.PC);
                    operationLogs.setSr_operate_primarykey("");
                    operationLogs.setSr_operate_table("");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.exceptionToString((Exception)e));
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return ret;
    }

    public Map<String, Object> remittance_agent(Tb_withdrawal_appl withdrawalAppl, Tb_agent agent, BigDecimal agent_once_money_ori, BigDecimal agent_once_money, String flow_type, String act_time, Tb_wx_pay_info pay_info) throws Exception {
        this.log.info("#######################\u6253\u6b3e\u5230\u94f6\u884c\u5361\u5f00\u59cb #######################");
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        String error_msg = "";
        String zf_money_fen = CommonFunction.yuanToFen((String)agent_once_money.toString());
        String sr_account_name = agent.getSr_account_name();
        String sr_account = agent.getSr_account();
        String sr_bank = agent.getSr_bank();
        String zf_desc = pay_info.getSr_payment_desc();
        String cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
        WithdrawInfo withdrawInfo = new WithdrawInfo();
        withdrawInfo.setAmount(Integer.valueOf(zf_money_fen));
        withdrawInfo.setBank_code(sr_bank);
        String encBankNo = this.rsaUtils.encryptData(sr_account, pay_info.getSub_mchid());
        String encTrueName = this.rsaUtils.encryptData(sr_account_name, pay_info.getSub_mchid());
        withdrawInfo.setDesc(zf_desc);
        withdrawInfo.setEncBankNo(encBankNo);
        withdrawInfo.setEncTrueName(encTrueName);
        withdrawInfo.setMch_id(pay_info.getSub_mchid());
        withdrawInfo.setNonce_str(UUidUtils.getUUid());
        withdrawInfo.setPartner_trade_no(cash_trade_no);
        String apiKey = pay_info.getSub_merkey_v2();
        this.log.info("sign key ============{}", (Object)apiKey);
        String sign = Signature.getSign(apiKey, withdrawInfo);
        withdrawInfo.setSign(sign);
        this.log.info("sign====={}", (Object)sign);
        String xmlWithdrawInfo = this.wxWithdrawTools.getXMLStringForObj(withdrawInfo);
        this.log.info("\u63d0\u73b0\u53c2\u6570\u4e3a======{}", (Object)xmlWithdrawInfo);
        String response = this.wxWithdrawTools.postParamesForUrl(xmlWithdrawInfo, "https://api.mch.weixin.qq.com/mmpaysptrans/pay_bank", pay_info);
        this.log.info("\u63d0\u73b0\u7ed3\u679c\u4e3a==={}", (Object)response);
        Map return_data = null;
        try {
            return_data = WXPayUtil.xmlToMap((String)response);
        }
        catch (Exception e) {
            this.log.error("\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u652f\u4ed8\u8fd4\u56de\u7ed3\u679c\u89e3\u6790\u5931\u8d25:" + XcbStringUtils.exceptionToString((Exception)e));
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u652f\u4ed8\u8fd4\u56de\u7ed3\u679c\u89e3\u6790\u5931\u8d25\uff0ccash_trade_no\uff1a" + cash_trade_no, "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.PC);
            operationLogs.setSr_operate_primarykey("");
            operationLogs.setSr_operate_table("");
            this.operationLogServiceImpl.createOperaLog(operationLogs);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.error"));
            return ret;
        }
        String return_code = (String)return_data.get("return_code");
        String result_code = (String)return_data.get("result_code");
        if ("SUCCESS".equals(return_code)) {
            try {
                Tb_operation_logs operationLogs;
                Tb_cash_stream cashflow = new Tb_cash_stream();
                cashflow.setSd_cash_id(cash_trade_no);
                cashflow.setSw_agent_id(agent.getSd_agent_id());
                cashflow.setDc_cashflow_money(agent_once_money_ori);
                cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
                cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                cashflow.setSr_remarks("\u4f01\u4e1a\u6253\u6b3e\u5230\u94f6\u884c\u5361");
                if ("AGENT_JY".equals(flow_type)) {
                    result = this.cashStreamDao.createCashStream(cashflow);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u521b\u5efa\u8d44\u91d1\u63d0\u73b0\u6d41\u6c34\u5f02\u5e38: \u6d41\u6c34\u53f7:" + cash_trade_no + "\uff0c\u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u6d41\u6c34\u91d1\u989d:" + agent_once_money_ori + ",\u8d44\u91d1\u7c7b\u578b: \u7ecf\u8425\u6536\u5165 ";
                        this.log.error(error_msg);
                        operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey("");
                        operationLogs.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                    if ((result = this.commonLogic.updateOnlyAgent_txmoney(agent_once_money_ori, agent)) <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u63d0\u73b0\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u63d0\u73b0\u91d1\u989d:" + agent.getSr_tx_money();
                        this.log.error(error_msg);
                        operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey("");
                        operationLogs.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                    if ((result = this.commonLogic.updateAgent_agentmoney(withdrawalAppl.getDc_appl_money(), agent, XcbConstantValue.TB_TYPE_MINUS)) <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u66f4\u65b0\u4ee3\u7406\u5546\u8d26\u6237\u91d1\u989d\u5f02\u5e38: \u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u63d0\u73b0\u91d1\u989d:" + agent_once_money_ori + ",\u4ee3\u7406\u5546\u73b0\u5728\u7684\u8d26\u6237\u91d1\u989d:" + agent.getSr_agent_money();
                        this.log.error(error_msg);
                        operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey("");
                        operationLogs.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                    Tb_withdrawal_appl appl = new Tb_withdrawal_appl();
                    appl.setSd_id(withdrawalAppl.getSd_id());
                    appl.setTm_appl_time(new Date());
                    appl.setDc_income_money(agent_once_money);
                    appl.setSr_appl_person("\u7cfb\u7edf\u5ba1\u6279");
                    appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                    if (!"SUCCESS".equals(result_code)) {
                        appl.setSi_code(Integer.valueOf(1));
                    }
                    if ((result = this.withdrawalApplDao.updateWithdrawalAppl_cpy(appl)) <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u66f4\u65b0\u63d0\u73b0\u7533\u8bf7\u8bb0\u5f55\u5f02\u5e38,\u7533\u8bf7\u7f16\u53f7:" + withdrawalAppl.getSd_id() + "\u5b9e\u9645\u6253\u6b3e\u91d1\u989d:" + agent_once_money;
                        this.log.error(error_msg);
                        Tb_operation_logs operationLogs2 = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs2.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs2.setSr_operate_primarykey("");
                        operationLogs2.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs2);
                    }
                } else {
                    cashflow.setSr_remarks("\u8fd4\u70b9\u6536\u5165");
                    result = this.cashStreamDao.createCashStream(cashflow);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        error_msg = "\u521b\u5efa\u8d44\u91d1\u63d0\u73b0\u6d41\u6c34\u5f02\u5e38: \u6d41\u6c34\u53f7:" + cash_trade_no + "\uff0c\u4ee3\u7406\u5546ID:" + agent.getSd_agent_id() + "\uff0c\u6d41\u6c34\u91d1\u989d:" + agent_once_money_ori + ",\u8d44\u91d1\u7c7b\u578b: \u8fd4\u70b9\u6536\u5165 ";
                        this.log.error(error_msg);
                        operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey("");
                        operationLogs.setSr_operate_table("");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                }
                if (!"SUCCESS".equals(result_code)) {
                    error_msg = "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u4ed8\u6b3e\u901a\u4fe1\u6210\u529f\uff0c\u4f46\u652f\u4ed8\u7ed3\u679c\u53ef\u80fd\u5931\u8d25\u4e86\uff01cash_trade_no\uff1a" + cash_trade_no;
                    this.log.error(error_msg);
                    operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.PC);
                    operationLogs.setSr_operate_primarykey("");
                    operationLogs.setSr_operate_table("");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.success"));
            }
            catch (Exception e) {
                error_msg = "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u5f02\u5e38:" + XcbStringUtils.exceptionToString((Exception)e);
                this.log.error(error_msg);
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4f01\u4e1a\u6253\u6b3e-\u4ee3\u7406\u5546\u4ed8\u6b3e-\u4ed8\u6b3e\u66f4\u65b0\u6d41\u6c34\u72b6\u6001\u5931\u8d25\uff0ccash_trade_no\uff1a" + cash_trade_no, "", "");
                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                operationLogs.setSr_operate_primarykey("");
                operationLogs.setSr_operate_table("");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.error"));
            }
        }
        this.log.info("#######################\u6253\u6b3e\u5230\u94f6\u884c\u5361\u7ed3\u675f #######################");
        return ret;
    }

    private int createAgentCashStream(Integer ben_agent_id, Integer agent_father_id, BigDecimal fandian_money) {
        int result = 0;
        try {
            String cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
            Tb_cash_stream cashflow = new Tb_cash_stream();
            cashflow.setSd_cash_id(cash_trade_no);
            cashflow.setSw_agent_id(agent_father_id);
            cashflow.setDc_cashflow_money(fandian_money);
            cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_FDLS);
            cashflow.setTm_cashflow_time(new Date());
            cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_WFK);
            cashflow.setSi_nextagent_id(ben_agent_id);
            cashflow.setSi_create_person(agent_father_id);
            cashflow.setTm_create_time(new Date());
            cashflow.setSi_modify_person(agent_father_id);
            cashflow.setTm_modify_time(new Date());
            result = this.cashStreamDao.createCashStream(cashflow);
        }
        catch (Exception e) {
            this.log.error("\u521b\u5efa\u8fd4\u70b9\u8d44\u91d1\u6d41\u6c34\u5f02\u5e38:\u8fd4\u70b9\u4ee3\u7406\u5546:" + agent_father_id + ",\u4ed8\u6b3e\u4ee3\u7406\u5546:" + ben_agent_id + "\u5f02\u5e38:" + e.getMessage());
        }
        return result;
    }
}

