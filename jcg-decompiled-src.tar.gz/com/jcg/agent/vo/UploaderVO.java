/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.agent.vo;

public class UploaderVO {
    private String name;
    private String type;
    private int size;
    private int chunk;
    private int chunks;
    private String guid;
    private String uploadCode;
    private Integer agentId;
    private Integer netPointId;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSize() {
        return this.size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getChunk() {
        return this.chunk;
    }

    public void setChunk(int chunk) {
        this.chunk = chunk;
    }

    public int getChunks() {
        return this.chunks;
    }

    public void setChunks(int chunks) {
        this.chunks = chunks;
    }

    public String getGuid() {
        return this.guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getUploadCode() {
        return this.uploadCode;
    }

    public void setUploadCode(String uploadCode) {
        this.uploadCode = uploadCode;
    }

    public Integer getNetPointId() {
        return this.netPointId;
    }

    public void setNetPointId(Integer netPointId) {
        this.netPointId = netPointId;
    }

    public Integer getAgentId() {
        return this.agentId;
    }

    public void setAgentId(Integer agentId) {
        this.agentId = agentId;
    }
}

