/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  javax.servlet.http.HttpServletRequest
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jcg.agent.zf.wx;

import com.jcg.agent.common.BaseService;
import com.jcg.agent.common.PromptProperties;
import com.jcg.agent.service.CompanyServiceImpl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WXzfCommon
extends BaseService {
    protected static Logger log = LoggerFactory.getLogger(WXzfCommon.class);
    @Autowired
    private CompanyServiceImpl companyService;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String sendGet(String url) {
        String result = "";
        BufferedReader in = null;
        try {
            String line;
            String urlNameString = url;
            URL realUrl = new URL(urlNameString);
            URLConnection connection = realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.connect();
            Map<String, List<String>> map = connection.getHeaderFields();
            for (String key : map.keySet()) {
                System.out.println(key + "--->" + map.get(key));
            }
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
            while ((line = in.readLine()) != null) {
                result = result + line;
            }
        }
        catch (Exception e) {
            System.out.println("\u53d1\u9001GET\u8bf7\u6c42\u51fa\u73b0\u5f02\u5e38\uff01" + e);
            e.printStackTrace();
        }
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            }
            catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return result;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public String sendPost(String url, String param) {
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            String line;
            URL realUrl = new URL(url);
            URLConnection conn = realUrl.openConnection();
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            out = new PrintWriter(new OutputStreamWriter(conn.getOutputStream(), "utf-8"));
            out.print(param);
            out.flush();
            in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            while ((line = in.readLine()) != null) {
                result = result + line;
            }
        }
        catch (Exception e) {
            System.out.println("\u53d1\u9001 POST \u8bf7\u6c42\u51fa\u73b0\u5f02\u5e38\uff01" + e);
            e.printStackTrace();
        }
        finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    public static String getIpAdrress(HttpServletRequest request) {
        String Xip = request.getHeader("X-Real-IP");
        String XFor = request.getHeader("X-Forwarded-For");
        if (!XcbStringUtils.isNullOrBlank((Object)XFor) && !"unKnown".equalsIgnoreCase(XFor)) {
            int index = XFor.indexOf(",");
            if (index != -1) {
                return XFor.substring(0, index);
            }
            return XFor;
        }
        XFor = Xip;
        if (!XcbStringUtils.isNullOrBlank((Object)XFor) && !"unKnown".equalsIgnoreCase(XFor)) {
            return XFor;
        }
        if (XcbStringUtils.isNullOrBlank((Object)XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("Proxy-Client-IP");
        }
        if (XcbStringUtils.isNullOrBlank((Object)XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("WL-Proxy-Client-IP");
        }
        if (XcbStringUtils.isNullOrBlank((Object)XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("HTTP_CLIENT_IP");
        }
        if (XcbStringUtils.isNullOrBlank((Object)XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (XcbStringUtils.isNullOrBlank((Object)XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getRemoteAddr();
        }
        return XFor;
    }

    public Tb_company getCompany(Identifier identifier, String sw_company_id, String sr_wx_mer_id) throws Exception {
        Tb_company company = new Tb_company();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)sr_wx_mer_id)) {
                Map<String, Object> dataMap = this.companyService.findCompanyByMerId(identifier, sr_wx_mer_id);
                company = (Tb_company)dataMap.get(XcbConstantValue.DATA);
            } else {
                Map<String, Object> dataMap = this.companyService.findCompanyPayIn(identifier, sw_company_id);
                company = (Tb_company)dataMap.get(XcbConstantValue.DATA);
            }
        }
        catch (Exception e) {
            log.error(PromptProperties.getProperty("company.find.error", sw_company_id));
            throw new Exception(e);
        }
        return company;
    }

    public String getOpenid(String code, Tb_company company) throws Exception {
        String openId_str = "";
        try {
            StringBuffer sb = new StringBuffer();
            String wx_appid = company.getSr_wx_gzh_appid();
            String wx_secretKey = company.getSr_wx_gzh_appsecret();
            sb.append(XcbConstantValue.wx_gzh_openId_url);
            sb.append(wx_appid).append("&secret=").append(wx_secretKey);
            sb.append("&code=").append(code);
            sb.append("&grant_type=authorization_code");
            log.info("apiUrl:" + sb.toString());
            openId_str = WXzfCommon.sendGet(sb.toString());
        }
        catch (Exception e) {
            throw new Exception(e);
        }
        return openId_str;
    }
}

