/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  javax.servlet.http.HttpServletRequest
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.agent.zf.zfb;

import com.jcg.agent.common.BaseController;
import com.jcg.agent.common.PromptProperties;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.service.OrderServiceImpl;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/zfbRefund"})
public class zfbRefund
extends BaseController {
    protected static final Logger log = LoggerFactory.getLogger(zfbRefund.class);
    @Autowired
    private OrderServiceImpl orderService;

    @RequestMapping(value={"/zfbRefund"})
    @ResponseBody
    public Map<String, Object> zfbRefund(HttpServletRequest request) throws Exception {
        Tb_agent agent_user = (Tb_agent)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(agent_user.getSd_agent_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(agent_user.getSd_agent_id());
        identifier.setUserName(agent_user.getSr_agent_name());
        String out_trade_no = request.getParameter("out_trade_no");
        String sr_refund_fee = request.getParameter("sr_refund_money");
        Map<Object, Object> ret = new HashMap<String, String>();
        sr_refund_fee = request.getParameter("sr_refund_money");
        if (XcbStringUtils.isNullOrBlank((Object)sr_refund_fee)) {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("tk.refundmoney.isnull"));
            return ret;
        }
        String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
        ret = this.checkRefund(identifier, out_trade_no, sr_refund_fee);
        int result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            log.info("\u652f\u4ed8\u5b9d\u9000\u6b3e\u4e0b\u5355\uff1a\u4e1a\u52a1\u5f00\u59cb");
            String tkType = "\u667a\u80fd\u67dc\u7ed3\u7b97\u8ba2\u5355";
            ret = this.orderService.tkNotify(identifier, out_trade_no, sr_refund_fee, sd_cash_id);
            log.info("\u652f\u4ed8\u5b9d" + tkType + "\u9000\u6b3e\u4e0b\u5355\uff1a\u4e1a\u52a1\u7ed3\u675f");
        }
        log.info("\u9000\u6b3e\u4e0b\u5355\u7ed3\u679c\uff1a" + XcbStringUtils.getObjtoString((Object)ret.get(XcbConstantValue.MSG)));
        return ret;
    }

    public Map<String, Object> checkRefund(Identifier identifier, String out_trade_no, String total_fee) {
        HashMap<String, Object> rtnMap = new HashMap();
        log.info("\u652f\u4ed8\u5b9d\u9000\u6b3e\u6821\u9a8c\u5f00\u59cb");
        try {
            rtnMap = this.orderService.checkRefund(identifier, out_trade_no, total_fee);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        log.info("\u652f\u4ed8\u5b9d\u9000\u6b3e\u6821\u9a8c\u7ed3\u675f");
        return rtnMap;
    }
}

