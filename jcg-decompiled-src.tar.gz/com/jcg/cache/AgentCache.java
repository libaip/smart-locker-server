/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.cache.annotation.CachePut
 *  org.springframework.cache.annotation.Cacheable
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.cache;

import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AgentCache
extends BaseService
implements GenericCaller {
    private static Tb_agent agent;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private RedisUtil<String, Object> redisUtil;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========AgentCache=========");
        this.log.debug(identifier.toString());
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        return ret;
    }

    @Cacheable(value={"agentCache"}, key="#sr_user_name")
    public Tb_agent findAgentByUserName(String sr_user_name) {
        try {
            agent = this.agentDao.findAgentByUserName_agent(sr_user_name);
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("agent.find.error", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return agent;
    }

    @CachePut(value={"agentCache"}, key="#agent.sr_user_name")
    public Tb_agent updateAgentById_agent(Tb_agent agent) {
        try {
            int result = this.agentDao.updateAgentById_agent(agent);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                agent = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("agent.update.error", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return agent;
    }

    @CachePut(value={"agentCache"}, key="#sr_user_name")
    public Tb_agent updateCacheById_agent(String sr_user_name) {
        try {
            agent = this.agentDao.findAgentByUserName_agent(sr_user_name);
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("agent.update.error", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return agent;
    }

    @CachePut(value={"agentCache"}, key="#agent.sr_user_name")
    public Tb_agent updateStsById_agent(Tb_agent agent) {
        try {
            int result = this.agentDao.updateStsById_agent(agent);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                agent = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("agent.update.error", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return agent;
    }
}

