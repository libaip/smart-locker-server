/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  com.alibaba.fastjson.serializer.SerializerFeature
 *  org.springframework.cache.interceptor.KeyGenerator
 *  org.springframework.util.ClassUtils
 */
package com.jcg.cache;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import java.util.Date;
import java.util.Locale;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.util.ClassUtils;

public class CacheKeyGenerator
implements KeyGenerator {
    private static final int NO_PARAM_KEY = 0;
    private String keyPrefix = "jcg_server";

    public Object generate(Object target, Method method, Object ... params) {
        char sp = ':';
        StringBuilder strBuilder = new StringBuilder(30);
        strBuilder.append(this.keyPrefix);
        strBuilder.append(sp);
        strBuilder.append(target.getClass().getSimpleName());
        strBuilder.append(sp);
        strBuilder.append(method.getName());
        strBuilder.append(sp);
        if (params.length > 0) {
            for (Object object : params) {
                if (this.isSimpleValueType(object.getClass())) {
                    strBuilder.append(object);
                    continue;
                }
                strBuilder.append(this.toJson(object).hashCode());
            }
        } else {
            strBuilder.append(0);
        }
        return strBuilder.toString();
    }

    public String getKeyPrefix() {
        return this.keyPrefix;
    }

    public void setKeyPrefix(String keyPrefix) {
        this.keyPrefix = keyPrefix;
    }

    public String toJson(Object obj) {
        return JSON.toJSONString((Object)obj, (SerializerFeature[])new SerializerFeature[]{SerializerFeature.WriteMapNullValue});
    }

    public boolean isSimpleValueType(Class<?> clazz) {
        return ClassUtils.isPrimitiveOrWrapper(clazz) || clazz.isEnum() || CharSequence.class.isAssignableFrom(clazz) || Number.class.isAssignableFrom(clazz) || Date.class.isAssignableFrom(clazz) || URI.class == clazz || URL.class == clazz || Locale.class == clazz || Class.class == clazz;
    }
}

