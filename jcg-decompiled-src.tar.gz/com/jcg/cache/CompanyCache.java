/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.cache;

import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.company.serviceimpl.CompanyServiceImpl;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CompanyCache
extends BaseService
implements GenericCaller {
    private static List<Tb_company> list_company;
    @Autowired
    public CompanyServiceImpl companyService;
    @Autowired
    private RedisUtil<String, Object> redisUtil;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========CompanyCache=========");
        this.log.debug(identifier.toString());
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        if (XcbConstantValue.COMPANY_CLEAR_CACHE.equalsIgnoreCase(functionCode)) {
            this.refresh();
            HashMap<String, Object> ret_method = new HashMap<String, Object>();
            this.initResultMap(ret_method);
            ret = ret_method;
        }
        return ret;
    }

    public void init() {
        try {
            list_company = this.companyService.findCompanyAll();
            for (Tb_company company : list_company) {
                String comapnyid = XcbStringUtils.getObjtoString((Object)company.getSd_company_id());
                this.redisUtil.set(comapnyid, company);
            }
        }
        catch (Exception e) {
            this.log.error(PromptProperties.getProperty("company.param.init.fail", XcbStringUtils.exceptionToString((Exception)e)));
        }
    }

    public void refresh() {
        try {
            this.companyService.clearCache();
            list_company = this.companyService.findCompanyAll();
            for (Tb_company company : list_company) {
                String comapnyid = XcbStringUtils.getObjtoString((Object)company.getSd_company_id());
                this.redisUtil.set(comapnyid, company);
            }
        }
        catch (Exception e) {
            this.log.error(PromptProperties.getProperty("company.param.init.fail", XcbStringUtils.exceptionToString((Exception)e)));
        }
    }

    public List<Tb_company> getCompanyList() {
        try {
            list_company = this.companyService.findCompanyAll();
            for (Tb_company company : list_company) {
                String comapnyid = XcbStringUtils.getObjtoString((Object)company.getSd_company_id());
                this.redisUtil.set(comapnyid, company);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("company.param.init.fail", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return list_company;
    }
}

