/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.company.model.Tb_cuser
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.cache;

import com.jcg.common.BaseService;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.company.idao.CuserDao;
import com.jcg.company.model.Tb_cuser;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CuserCache
extends BaseService
implements GenericCaller {
    private static Tb_cuser cuser;
    @Autowired
    private CuserDao cuserDao;
    @Autowired
    private RedisUtil<String, Object> redisUtil;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========CuserCache=========");
        this.log.debug(identifier.toString());
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        return ret;
    }
}

