/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.cache.Cache
 *  org.springframework.cache.Cache$ValueWrapper
 *  org.springframework.cache.support.SimpleValueWrapper
 *  org.springframework.data.redis.core.RedisTemplate
 */
package com.jcg.cache;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Set;
import org.springframework.cache.Cache;
import org.springframework.cache.support.SimpleValueWrapper;
import org.springframework.data.redis.core.RedisTemplate;

public class RedisCache
implements Cache {
    private RedisTemplate<String, Object> redisTemplate;
    private String name;

    public RedisTemplate<String, Object> getRedisTemplate() {
        return this.redisTemplate;
    }

    public void setRedisTemplate(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public Object getNativeCache() {
        return this.redisTemplate;
    }

    public Cache.ValueWrapper get(Object key) {
        String _key = this.name + "_" + String.valueOf(key);
        SimpleValueWrapper result = null;
        Object val = this.redisTemplate.opsForValue().get((Object)_key);
        if (val != null) {
            result = new SimpleValueWrapper(val);
        }
        return result;
    }

    public <T> T get(Object key, Class<T> type) {
        return null;
    }

    public void put(Object key, Object value) {
        System.out.println("put key");
        String _key = this.name + "_" + String.valueOf(key);
        if (null != value) {
            this.redisTemplate.opsForValue().set((Object)_key, value);
        }
    }

    private byte[] toByteArray(Object obj) {
        byte[] bytes = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(obj);
            oos.flush();
            bytes = bos.toByteArray();
            oos.close();
            bos.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        return bytes;
    }

    private Object toObject(byte[] bytes) {
        Object obj = null;
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
            ObjectInputStream ois = new ObjectInputStream(bis);
            obj = ois.readObject();
            ois.close();
            bis.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
        catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return obj;
    }

    public void evict(Object key) {
        System.out.println("del key");
        String _key = this.name + "_" + String.valueOf(key);
        this.redisTemplate.delete((Object)_key);
    }

    public void clear() {
        System.out.println("clear key");
        String prefix = this.name + "*";
        Set ks = this.redisTemplate.keys((Object)prefix);
        for (String bys : ks) {
            this.redisTemplate.delete((Object)bys);
        }
    }

    public Cache.ValueWrapper putIfAbsent(Object key, Object value) {
        return null;
    }
}

