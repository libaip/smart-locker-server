/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.cache;

import com.jcg.common.BaseService;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.serviceimpl.AreaCityServiceImpl;
import com.jcg.company.serviceimpl.AreaDistrictServiceImpl;
import com.jcg.company.serviceimpl.AreaProvinceServiceImpl;
import com.jcg.company.serviceimpl.AreaTownServiceImpl;
import com.jcg.company.serviceimpl.SysParamServiceImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SystemParamCache
extends BaseService
implements GenericCaller {
    private static List<Map<String, Object>> list_provinces;
    private static Map<String, List<Map<String, Object>>> map_citys;
    private static Map<String, List<Map<String, Object>>> map_districts;
    private static Map<String, List<Map<String, Object>>> map_towns;
    private static Map<String, List<Map<String, Object>>> map_sysParam;
    @Autowired
    public AreaProvinceServiceImpl provinceService;
    @Autowired
    public AreaCityServiceImpl cityService;
    @Autowired
    public AreaTownServiceImpl townService;
    @Autowired
    public AreaDistrictServiceImpl districtService;
    @Autowired
    public SysParamServiceImpl sysParamService;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=======SystemParamCache==========");
        this.log.debug(identifier.toString());
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        if (XcbConstantValue.SYSTEM_CLEAR_CACHE.equalsIgnoreCase(functionCode)) {
            this.refresh();
            HashMap<String, Object> ret_method = new HashMap<String, Object>();
            this.initResultMap(ret_method);
            ret = ret_method;
        }
        return ret;
    }

    public void init() {
        try {
            list_provinces = this.provinceService.findProvinceAll();
            map_citys = this.cityService.findCityAll();
            map_districts = this.districtService.findDistrictAll();
            map_towns = this.townService.findTownAll();
            map_sysParam = this.sysParamService.findSysParamAll();
        }
        catch (Exception e) {
            this.log.error("\u521d\u59cb\u5316\u7cfb\u7edf\u57fa\u7840\u6570\u636e\u62a5\u9519" + XcbStringUtils.exceptionToString((Exception)e));
        }
    }

    public void refresh() {
        try {
            this.provinceService.clearCache();
            list_provinces = this.provinceService.findProvinceAll();
            map_citys = this.cityService.findCityAll();
            map_districts = this.districtService.findDistrictAll();
            map_towns = this.townService.findTownAll();
            map_sysParam = this.sysParamService.findSysParamAll();
        }
        catch (Exception e) {
            this.log.error("\u521d\u59cb\u5316\u7cfb\u7edf\u57fa\u7840\u6570\u636e\u62a5\u9519" + XcbStringUtils.exceptionToString((Exception)e));
        }
    }

    public List<Map<String, Object>> getProvinces() {
        if (list_provinces == null || list_provinces.size() == 0) {
            list_provinces = this.provinceService.findProvinceAll();
        }
        List<Map<String, Object>> provinces = list_provinces;
        return provinces;
    }

    public List<Map<String, Object>> getProvince(String sd_code) {
        if (list_provinces == null || list_provinces.isEmpty()) {
            list_provinces = this.provinceService.findProvinceAll();
        }
        List<Map<String, Object>> provinces = list_provinces.stream().filter(map -> map.get("value").equals(sd_code)).collect(Collectors.toList());
        return provinces;
    }

    public List<Map<String, Object>> getCitysByPro(String province_code) {
        if (map_citys == null || map_citys.isEmpty()) {
            map_citys = this.cityService.findCityAll();
        }
        List<Map<String, Object>> citys = map_citys.get(province_code);
        return citys;
    }

    public List<Map<String, Object>> getDistrictByCity(String city_code) {
        if (map_districts == null || map_districts.isEmpty()) {
            map_districts = this.districtService.findDistrictAll();
        }
        List<Map<String, Object>> districts = map_districts.get(city_code);
        return districts;
    }

    public List<Map<String, Object>> getTownByDistr(String city_code) {
        if (map_towns == null || map_towns.isEmpty()) {
            map_towns = this.townService.findTownAll();
        }
        List<Map<String, Object>> towns = map_towns.get(city_code);
        return towns;
    }

    public List<Map<String, Object>> getSysParam(String category_code) {
        List<Map<String, Object>> sysParams = new ArrayList<Map<String, Object>>();
        try {
            if (map_sysParam == null || map_sysParam.isEmpty()) {
                map_sysParam = this.sysParamService.findSysParamAll();
            }
            sysParams = map_sysParam.get(category_code);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return sysParams;
    }

    public Map<String, Object> getSysParamByType(String category_code, String key_code) {
        Map<String, Object> sysParam = new HashMap<String, Object>();
        List<Map<String, Object>> sysParams = this.getSysParam(category_code);
        if (sysParams != null && sysParams.size() > 0) {
            for (int i = 0; i < sysParams.size(); ++i) {
                Map<String, Object> sysParam_zh = sysParams.get(i);
                String key_code_zh = XcbStringUtils.getObjtoString((Object)sysParam_zh.get("value"));
                if (XcbStringUtils.isNullOrBlank((Object)key_code_zh) || XcbStringUtils.isNullOrBlank((Object)key_code) || !key_code_zh.equalsIgnoreCase(key_code)) continue;
                sysParam = sysParam_zh;
            }
        }
        return sysParam;
    }
}

