/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.user.model.Tb_user
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.cache.annotation.CachePut
 *  org.springframework.cache.annotation.Cacheable
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.cache;

import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.user.idao.UserDao;
import com.jcg.user.model.Tb_user;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserCache
extends BaseService
implements GenericCaller {
    private static Tb_user user;
    @Autowired
    private UserDao userDao;
    @Autowired
    private RedisUtil<String, Object> redisUtil;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========UserCache=========");
        this.log.debug(identifier.toString());
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        return ret;
    }

    @Cacheable(value={"userCache"}, key="#sd_user_id")
    public Tb_user findUserCacheById(Integer sd_user_id) {
        try {
            user = this.userDao.findUserCacheById(sd_user_id);
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("user.find.error", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return user;
    }

    @CachePut(value={"userCache"}, key="#sd_user_id")
    public Tb_user upateUserCacheById(Integer sd_user_id) {
        try {
            user = this.userDao.findUserCacheById(sd_user_id);
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("user.find.error", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return user;
    }

    @Cacheable(value={"userCache"}, key="#user.sr_open_id+'_'+#user.sw_company_id")
    public Tb_user findUserByOpenId(Tb_user user) {
        try {
            user = this.userDao.findUserByOpenId(user);
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("user.find.error", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return user;
    }

    @Cacheable(value={"userCache"}, key="#user.sr_zfb_open_id+'_'+#user.sw_company_id")
    public Tb_user findUserByZfbOpenId(Tb_user user) {
        try {
            user = this.userDao.findUserByZfbOpenId(user);
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("user.find.error", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return user;
    }

    @CachePut(value={"userCache"}, key="#user.sr_open_id+'_'+#user.sw_company_id")
    public Tb_user upateUserByOpenId(Tb_user user) {
        try {
            user = this.userDao.findUserByOpenId(user);
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("user.find.error", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return user;
    }

    @CachePut(value={"userCache"}, key="#user.sr_zfb_open_id+'_'+#user.sw_company_id")
    public Tb_user upateUserByZfbOpenId(Tb_user user) {
        try {
            user = this.userDao.findUserByZfbOpenId(user);
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.error(PromptProperties.getProperty("user.find.error", XcbStringUtils.exceptionToString((Exception)e)));
        }
        return user;
    }
}

