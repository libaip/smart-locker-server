/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.client.bean;

public class CreateQrcodeReq {
    private String appToken;
    private String extra;
    private Integer validTime;

    public String getAppToken() {
        return this.appToken;
    }

    public void setAppToken(String appToken) {
        this.appToken = appToken;
    }

    public String getExtra() {
        return this.extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }

    public Integer getValidTime() {
        return this.validTime;
    }

    public void setValidTime(Integer validTime) {
        this.validTime = validTime;
    }
}

