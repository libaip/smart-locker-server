/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.client.bean;

import java.util.HashSet;
import java.util.Set;

public class Message {
    public static final int CONTENT_TYPE_TEXT = 1;
    public static final int CONTENT_TYPE_HTML = 2;
    public static final int CONTENT_TYPE_MD = 3;
    private String appToken;
    private Set<String> uids;
    private Set<Long> topicIds;
    private Integer contentType;
    private String content;
    private String url;

    public String getAppToken() {
        return this.appToken;
    }

    public void setAppToken(String appToken) {
        this.appToken = appToken;
    }

    public Set<String> getUids() {
        return this.uids;
    }

    public void setUid(String uid) {
        this.uids = new HashSet<String>(1);
        this.uids.add(uid);
    }

    public void setTopicId(Long topicId) {
        this.topicIds = new HashSet<Long>(1);
        this.topicIds.add(topicId);
    }

    public void setUids(Set<String> uids) {
        this.uids = uids;
    }

    public Set<Long> getTopicIds() {
        return this.topicIds;
    }

    public void setTopicIds(Set<Long> topicIds) {
        this.topicIds = topicIds;
    }

    public Integer getContentType() {
        return this.contentType;
    }

    public void setContentType(Integer contentType) {
        this.contentType = contentType;
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}

