/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.client.bean;

import com.jcg.client.bean.ResultCode;

public class MessageResult {
    private String uid;
    private String status;
    private Integer code;
    private Long messageId;

    public boolean isSuccess() {
        return this.code.intValue() == ResultCode.SUCCESS.getCode();
    }

    public String getUid() {
        return this.uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getCode() {
        return this.code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public Long getMessageId() {
        return this.messageId;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }
}

