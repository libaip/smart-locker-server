/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.client.bean;

public enum ResultCode {
    SUCCESS(1000),
    BIZ_FAIL(1001),
    UNAUTHORIZED(1002),
    SIGN_FAIL(1003),
    NOT_FOUND(1004),
    INTERNAL_SERVER_ERROR(1005),
    WEIXIN_ERROR(1006),
    NETWORK_ERROR(1007),
    DATA_ERROR(1008),
    UNKNOWN_ERROR(1009);

    private final int code;

    private ResultCode(int code) {
        this.code = code;
    }

    public int getCode() {
        return this.code;
    }
}

