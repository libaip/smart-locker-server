/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.client.bean.callback;

public class AppSubscribeBean {
    public static final String SOURCE_SCAN = "scan";
    public static final String SOURCE_LINK = "link";
    private String uid;
    private String appKey;
    private String appName;
    private Long time;
    private String source;
    private String extra;

    public String getUid() {
        return this.uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getAppKey() {
        return this.appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppName() {
        return this.appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public Long getTime() {
        return this.time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getSource() {
        return this.source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getExtra() {
        return this.extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }
}

