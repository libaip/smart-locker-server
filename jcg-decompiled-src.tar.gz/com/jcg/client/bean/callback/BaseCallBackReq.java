/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.client.bean.callback;

public class BaseCallBackReq {
    public static final String ACTION_APP_SUBSCRIBE = "app_subscribe";
    private String action;
    private Object data;

    public String getAction() {
        return this.action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Object getData() {
        return this.data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}

