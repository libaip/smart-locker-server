/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_device_fittings
 *  com.jcg.agent.model.Tb_device_param
 *  com.jcg.agent.model.Tb_devicelogs
 *  com.jcg.agent.model.Tb_opendoor_record
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  net.sf.json.JSONArray
 *  net.sf.json.JSONObject
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.cloud;

import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_device_fittings;
import com.jcg.agent.model.Tb_device_param;
import com.jcg.agent.model.Tb_devicelogs;
import com.jcg.agent.model.Tb_opendoor_record;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.serviceimpl.DeviceLogsServiceImpl;
import com.jcg.agent.serviceimpl.DeviceServiceImpl;
import com.jcg.agent.serviceimpl.OpenDoorRecordServiceImpl;
import com.jcg.cloud.SocketServiceImpl;
import com.jcg.cloud.StompWebSocketServiceImpl;
import com.jcg.common.BaseService;
import com.jcg.common.HttpClientUtil;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DeviceCloudServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private StompWebSocketServiceImpl stompWebSocketService;
    @Autowired
    private SocketServiceImpl socketService;
    @Autowired
    private DeviceLogsServiceImpl deviceLogsService;
    @Autowired
    private OpenDoorRecordServiceImpl openDoorRecordService;
    @Autowired
    private DeviceDao deviceDao;
    @Autowired
    private DeviceBoxDao deviceBoxDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private DeviceServiceImpl deviceService;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=======DeviceCloudServiceImpl==========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_device device = new Tb_device();
        Tb_device_box deviceBox = new Tb_device_box();
        if (param != null) {
            deviceBox = (Tb_device_box)param.get("deviceBox");
            device = (Tb_device)param.get("device");
        }
        try {
            if (XcbConstantValue.DEVICE_CLOUD_OPENLOCK.equalsIgnoreCase(functionCode)) {
                Integer userid = XcbStringUtils.getObjtoint((Object)param.get("userid"));
                String sw_order_id = XcbStringUtils.getObjtoString((Object)param.get("sw_order_id"));
                String sr_type = XcbStringUtils.getObjtoString((Object)param.get("sr_type"));
                String sr_remarks = XcbStringUtils.getObjtoString((Object)param.get("sr_remarks"));
                ret = this.openLock(userid, deviceBox, sw_order_id, sr_type, sr_remarks);
            } else if (XcbConstantValue.DEVICE_CLOUD_OPENLOCK_AGENT.equalsIgnoreCase(functionCode)) {
                ret = this.openLock_agent(deviceBox);
            } else if (XcbConstantValue.DEVICE_CLOUD_OPEN_ALL_LOCK.equalsIgnoreCase(functionCode)) {
                ret = this.openAllLock(deviceBox);
            } else if (XcbConstantValue.DEVICE_CLOUD_GET_STATE_AGENT.equalsIgnoreCase(functionCode)) {
                ret = this.getState_agent(deviceBox);
            } else if (XcbConstantValue.DEVICE_CLOUD_OPENLOCK_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.openLock_cpy(deviceBox);
            } else if (XcbConstantValue.DEVICE_CLOUD_REBOOT.equalsIgnoreCase(functionCode)) {
                ret = this.reboot_cpy(device);
            } else if (XcbConstantValue.DEVICE_CLOUD_OPEN_ALL_LOCK_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.openAllLock_cpy(deviceBox);
            } else if (XcbConstantValue.DEVICE_CLOUD_UPDATE_APP.equalsIgnoreCase(functionCode)) {
                ret = this.updateApp_cpy(device);
            } else if (XcbConstantValue.DEVICE_CLOUD_REFRESH.equalsIgnoreCase(functionCode)) {
                String sw_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("sw_mainboard_id"));
                ret = this.refreshApp(sw_mainboard_id);
            } else if (XcbConstantValue.DEVICE_CLOUD_REFRESH_DOOR.equalsIgnoreCase(functionCode)) {
                String sw_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("sw_mainboard_id"));
                ret = this.refreshDoor(sw_mainboard_id);
            } else if (XcbConstantValue.DEVICE_CLOUD_GET_COVER_PICTURE.equalsIgnoreCase(functionCode)) {
                String sw_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("sw_mainboard_id"));
                ret = this.getCoverPicture(sw_mainboard_id);
            } else if (XcbConstantValue.DEVICE_CLOUD_REFRESH_ALL.equalsIgnoreCase(functionCode)) {
                Integer sw_netpoint_id = XcbStringUtils.getObjtoint((Object)param.get("sw_netpoint_id"));
                ret = this.refreshAll(sw_netpoint_id);
            } else if (XcbConstantValue.DEVICE_CLOUD_CHECK_STATUS.equalsIgnoreCase(functionCode)) {
                ret = this.checkDeviceStatus(deviceBox);
            } else if (XcbConstantValue.DEVICE_CLOUD_GET_SIM.equalsIgnoreCase(functionCode)) {
                String sw_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("sw_mainboard_id"));
                ret = this.getSimInfo(sw_mainboard_id);
            } else if (XcbConstantValue.DEVICE_CLOUD_GET_MCUID.equalsIgnoreCase(functionCode)) {
                ret = this.readMcuid(deviceBox);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> checkDeviceStatus(Tb_device_box deviceBox) {
        HashMap<String, Object> result_map = new HashMap();
        try {
            result_map = this.socketService.checkDeviceStatus(deviceBox);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_CHECK_STATUS, PromptProperties.getProperty("device.cloud.check.status.fail"), (Throwable)e);
        }
        return result_map;
    }

    private Map<String, Object> getSimInfo(String sw_mainboard_id) {
        Map<Object, Object> result_map = new HashMap();
        try {
            Tb_devicelogs deviceLogs = new Tb_devicelogs();
            deviceLogs.setSw_mid(sw_mainboard_id);
            result_map = this.deviceLogsService.checkDeviceLogs(deviceLogs);
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                result_map = this.stompWebSocketService.getSimInfo(sw_mainboard_id);
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline2"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_GET_SIM, PromptProperties.getProperty("device.cloud.getsim.fail"), (Throwable)e);
        }
        return result_map;
    }

    public Map<String, Object> refreshApp(String sw_mainboard_id) {
        HashMap<String, Object> result_map = new HashMap();
        try {
            result_map = this.stompWebSocketService.refreshApp(sw_mainboard_id);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_REFRESH, PromptProperties.getProperty("device.cloud.reflesh.fail"), (Throwable)e);
        }
        return result_map;
    }

    public Map<String, Object> refreshDoor(String sw_mainboard_id) {
        HashMap<String, Object> result_map = new HashMap();
        try {
            result_map = this.stompWebSocketService.refreshDoor(sw_mainboard_id);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_REFRESH_DOOR, PromptProperties.getProperty("device.cloud.reflesh.fail"), (Throwable)e);
        }
        return result_map;
    }

    private Map<String, Object> refreshAll(Integer sw_netpoint_id) {
        HashMap<String, Object> result_map = new HashMap();
        try {
            result_map = this.stompWebSocketService.refreshAll(sw_netpoint_id);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_REFRESH_ALL, PromptProperties.getProperty("device.cloud.reflesh.fail"), (Throwable)e);
        }
        return result_map;
    }

    private Map<String, Object> reboot_cpy(Tb_device device) {
        Map<Object, Object> result_map = new HashMap();
        try {
            Tb_devicelogs deviceLogs = new Tb_devicelogs();
            deviceLogs.setSw_mid(device.getSi_mainboard_id());
            result_map = this.stompWebSocketService.reboot_cpy(device.getSi_mainboard_id());
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, "\u91cd\u542f\u6210\u529f");
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, "\u91cd\u542f\u5931\u8d25");
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_REBOOT, "\u5e73\u677f\u91cd\u542f\u5f02\u5e38", (Throwable)e);
        }
        return result_map;
    }

    private Map<String, Object> updateApp_cpy(Tb_device device) {
        Map<String, Object> result_map = new HashMap<String, Object>();
        try {
            String[] deviceArr = device.getDeviceArr();
            if (deviceArr.length > 0) {
                for (String mid : deviceArr) {
                    Tb_devicelogs deviceLogs = new Tb_devicelogs();
                    deviceLogs.setSw_mid(mid);
                    result_map = this.deviceLogsService.checkDeviceLogs(deviceLogs);
                    int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        Tb_device o_device = this.deviceDao.findDeviceByMid(mid);
                        String outPutJsonPath = XcbConstantValue.server_host + "/" + device.getSw_company_id() + "/android_app/output.json";
                        String str = HttpClientUtil.getUrlData(outPutJsonPath);
                        if (XcbStringUtils.isNullOrBlank((Object)str)) continue;
                        JSONArray jsonArr = JSONArray.fromObject((Object)str);
                        JSONObject json = (JSONObject)jsonArr.get(0);
                        JSONObject apkInfo = json.getJSONObject("apkInfo");
                        String versionCode = apkInfo.getString("versionCode");
                        String versionName = apkInfo.getString("versionName");
                        result_map = this.stompWebSocketService.updateApp_cpy(o_device.getSi_mainboard_id());
                        result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
                        if (result <= XcbConstantValue.OPERA_INT_ZERO) continue;
                        Tb_device n_device = new Tb_device();
                        n_device.setSd_device_id(o_device.getSd_device_id());
                        n_device.setSr_version(versionName);
                        result = this.deviceDao.updateDeviceByStsId_agent(n_device);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.update.apk.success"));
                            continue;
                        }
                        result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.update.apk.fail"));
                        continue;
                    }
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline2"));
                }
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.update.apk.null"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_UPDATE_APP, PromptProperties.getProperty("device.cloud.update.apk.fail"), (Throwable)e);
        }
        return result_map;
    }

    private Map<String, Object> openLock_agent(Tb_device_box deviceBox) {
        Map<Object, Object> result_map = new HashMap();
        try {
            Tb_device_box boxInfo = this.deviceBoxDao.findDeviceBoxById_user(deviceBox.getSd_box_id());
            Tb_devicelogs deviceLogs = new Tb_devicelogs();
            deviceLogs.setSw_mid(boxInfo.getSw_mainboard_id());
            result_map = this.deviceLogsService.checkDeviceLogs(deviceLogs);
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                String msg;
                Tb_order order;
                if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(boxInfo.getSr_device_type())) {
                    result_map = this.stompWebSocketService.openLock(boxInfo);
                } else if (XcbConstantValue.DEVICE_TYPE_WPJCG.equals(boxInfo.getSr_device_type())) {
                    result_map = this.socketService.openLock(boxInfo);
                }
                if (XcbConstantValue.DEVICE_BOX_STATUS_ZY.equals(boxInfo.getSr_box_status()) && (order = this.orderDao.findNewestOrderByBox(deviceBox.getSd_box_id())) != null) {
                    Tb_opendoor_record record = new Tb_opendoor_record();
                    String sd_openid_id = CommonFunction.getVoucherNum((String)CommonFunction.op_id);
                    record.setSd_openid_id(sd_openid_id);
                    record.setSw_order_id(order.getSd_order_id());
                    record.setSw_user_id(order.getSw_user_id());
                    record.setSr_type(XcbConstantValue.OPEN_DOOR_TYPE_KMCG);
                    record.setTm_create_time(new Date());
                    record.setSr_create_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                    record.setTm_modify_time(new Date());
                    record.setSr_modify_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                    record.setSr_remarks("\u4ee3\u7406\u5546\u5f00\u95e8");
                    result_map = this.openDoorRecordService.createOpenDoorRecord(record);
                }
                if ((result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS))) > XcbConstantValue.OPERA_INT_ZERO && XcbStringUtils.isNullOrBlank((Object)(msg = XcbStringUtils.getObjtoString((Object)result_map.get(XcbConstantValue.MSG))))) {
                    result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.openlock.success"));
                }
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline2"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_OPENLOCK_AGENT, PromptProperties.getProperty("device.cloud.openlock.fail"), (Throwable)e);
        }
        return result_map;
    }

    private Map<String, Object> openAllLock(Tb_device_box deviceBox) {
        Map<Object, Object> result_map = new HashMap();
        try {
            Tb_device device = this.deviceDao.findDeviceDetailById_agent(deviceBox.getSw_device_id());
            Tb_devicelogs deviceLogs = new Tb_devicelogs();
            deviceLogs.setSw_mid(device.getSi_mainboard_id());
            result_map = this.deviceLogsService.checkDeviceLogs(deviceLogs);
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                List<Tb_device_box> boxList;
                deviceBox.setSr_device_type(device.getSr_device_type());
                deviceBox.setSw_mainboard_id(device.getSi_mainboard_id());
                deviceBox.setSw_device_id(device.getSd_device_id());
                deviceBox.setSi_number(device.getSi_box_count());
                List<String> boardList = this.deviceBoxDao.findBoardListByDeviceId(deviceBox);
                String[] animals = boardList.toArray(new String[0]);
                deviceBox.setBoardArr(animals);
                if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(deviceBox.getSr_device_type())) {
                    result_map = this.stompWebSocketService.openAllLock(deviceBox);
                } else if (XcbConstantValue.DEVICE_TYPE_WPJCG.equals(deviceBox.getSr_device_type())) {
                    result_map = this.socketService.openAllLock(deviceBox);
                }
                result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO && (boxList = this.deviceBoxDao.findDeviceBoxByDeviceId_agent(deviceBox)).size() > 0) {
                    for (Tb_device_box box : boxList) {
                        Tb_order order;
                        if (!XcbConstantValue.DEVICE_BOX_STATUS_ZY.equals(box.getSr_box_status()) || (order = this.orderDao.findNewestOrderByBox(box.getSd_box_id())) == null) continue;
                        Tb_opendoor_record record = new Tb_opendoor_record();
                        String sd_openid_id = CommonFunction.getVoucherNum((String)CommonFunction.op_id);
                        record.setSd_openid_id(sd_openid_id);
                        record.setSw_order_id(order.getSd_order_id());
                        record.setSw_user_id(order.getSw_user_id());
                        record.setSr_type(XcbConstantValue.OPEN_DOOR_TYPE_KMCG);
                        record.setTm_create_time(new Date());
                        record.setSr_create_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                        record.setTm_modify_time(new Date());
                        record.setSr_modify_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                        record.setSr_remarks("\u4ee3\u7406\u5546\u5f00\u95e8");
                        result_map = this.openDoorRecordService.createOpenDoorRecord(record);
                    }
                }
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline2"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_OPEN_ALL_LOCK, PromptProperties.getProperty("device.cloud.openlock.fail"), (Throwable)e);
        }
        return result_map;
    }

    public Map<String, Object> openLock(Integer sw_user_id, Tb_device_box deviceBox, String sw_order_id, String sr_type, String sr_remarks) {
        Map<Object, Object> result_map = new HashMap();
        try {
            Tb_devicelogs deviceLogs = new Tb_devicelogs();
            deviceLogs.setSw_mid(deviceBox.getSw_mainboard_id());
            result_map = this.deviceLogsService.checkDeviceLogs(deviceLogs);
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                this.log.info("#################\u5f00\u9501\u65f6\u95f4\u5f00\u59cb:" + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss") + "#################");
                if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(deviceBox.getSr_device_type())) {
                    this.stompWebSocketService.openLock(deviceBox);
                } else if (XcbConstantValue.DEVICE_TYPE_WPJCG.equals(deviceBox.getSr_device_type())) {
                    this.socketService.openLock(deviceBox);
                }
                this.log.info("#################\u5f00\u9501\u65f6\u95f4\u7ed3\u675f:" + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss") + "#################");
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Tb_opendoor_record record = new Tb_opendoor_record();
                    String sd_openid_id = CommonFunction.getVoucherNum((String)CommonFunction.op_id);
                    record.setSd_openid_id(sd_openid_id);
                    record.setSw_order_id(sw_order_id);
                    record.setSw_user_id(sw_user_id);
                    record.setSr_type(sr_type);
                    record.setTm_create_time(new Date());
                    record.setSr_create_person(XcbStringUtils.getObjtoString((Object)sw_user_id));
                    record.setTm_modify_time(new Date());
                    record.setSr_modify_person(XcbStringUtils.getObjtoString((Object)sw_user_id));
                    record.setSr_remarks(sr_remarks);
                    this.openDoorRecordService.createOpenDoorRecord(record);
                    result_map.put(XcbConstantValue.DATA, sw_order_id);
                }
            } else {
                this.log.error(PromptProperties.getProperty("device.cloud.check.status.offline2"));
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline2"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_OPENLOCK, PromptProperties.getProperty("device.cloud.openlock.fail"), (Throwable)e);
        }
        return result_map;
    }

    public Map<String, Object> getState_agent(Tb_device_box deviceBox) {
        Map<Object, Object> result_map = new HashMap();
        try {
            Tb_device_box boxInfo = this.deviceBoxDao.findDeviceBoxById_user(deviceBox.getSd_box_id());
            Tb_devicelogs deviceLogs = new Tb_devicelogs();
            deviceLogs.setSw_mid(boxInfo.getSw_mainboard_id());
            result_map = this.deviceLogsService.checkDeviceLogs(deviceLogs);
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(boxInfo.getSr_device_type())) {
                    result_map = this.stompWebSocketService.getState(boxInfo);
                } else if (XcbConstantValue.DEVICE_TYPE_WPJCG.equals(boxInfo.getSr_device_type())) {
                    result_map = this.socketService.getState(boxInfo);
                }
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline2"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_GET_STATE_AGENT, PromptProperties.getProperty("device.cloud.getstate.fail"), (Throwable)e);
        }
        return result_map;
    }

    private Map<String, Object> getCoverPicture(String sw_mainboard_id) {
        Map<Object, Object> result_map = new HashMap();
        try {
            Tb_devicelogs deviceLogs = new Tb_devicelogs();
            deviceLogs.setSw_mid(sw_mainboard_id);
            result_map = this.deviceLogsService.checkDeviceLogs(deviceLogs);
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                result_map = this.stompWebSocketService.getCoverPicture(sw_mainboard_id);
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline2"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_GET_COVER_PICTURE, PromptProperties.getProperty("device.cloud.getpicture.fail"), (Throwable)e);
        }
        return result_map;
    }

    private Map<String, Object> openLock_cpy(Tb_device_box deviceBox) {
        Map<Object, Object> result_map = new HashMap();
        try {
            Tb_device_box boxInfo = this.deviceBoxDao.findDeviceBoxById_user(deviceBox.getSd_box_id());
            Tb_devicelogs deviceLogs = new Tb_devicelogs();
            deviceLogs.setSw_mid(boxInfo.getSw_mainboard_id());
            result_map = this.deviceLogsService.checkDeviceLogs(deviceLogs);
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                String msg;
                Tb_order order;
                if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(boxInfo.getSr_device_type())) {
                    result_map = this.stompWebSocketService.openLock(boxInfo);
                } else if (XcbConstantValue.DEVICE_TYPE_WPJCG.equals(boxInfo.getSr_device_type())) {
                    result_map = this.socketService.openLock(boxInfo);
                }
                if (XcbConstantValue.DEVICE_BOX_STATUS_ZY.equals(boxInfo.getSr_box_status()) && (order = this.orderDao.findNewestOrderByBox(deviceBox.getSd_box_id())) != null) {
                    Tb_opendoor_record record = new Tb_opendoor_record();
                    String sd_openid_id = CommonFunction.getVoucherNum((String)CommonFunction.op_id);
                    record.setSd_openid_id(sd_openid_id);
                    record.setSw_order_id(order.getSd_order_id());
                    record.setSw_user_id(order.getSw_user_id());
                    record.setSr_type(XcbConstantValue.OPEN_DOOR_TYPE_KMCG);
                    record.setTm_create_time(new Date());
                    record.setSr_create_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                    record.setTm_modify_time(new Date());
                    record.setSr_modify_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                    record.setSr_remarks("\u516c\u53f8\u5f00\u95e8");
                    result_map = this.openDoorRecordService.createOpenDoorRecord(record);
                }
                if ((result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS))) > XcbConstantValue.OPERA_INT_ZERO && XcbStringUtils.isNullOrBlank((Object)(msg = XcbStringUtils.getObjtoString((Object)result_map.get(XcbConstantValue.MSG))))) {
                    result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.openlock.success"));
                }
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline2"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_OPENLOCK_CPY, PromptProperties.getProperty("device.cloud.openlock.fail"), (Throwable)e);
        }
        return result_map;
    }

    private Map<String, Object> openAllLock_cpy(Tb_device_box deviceBox) {
        Map<Object, Object> result_map = new HashMap();
        try {
            Tb_device device = this.deviceDao.findDeviceDetailById_agent(deviceBox.getSw_device_id());
            deviceBox.setSr_device_type(device.getSr_device_type());
            deviceBox.setSw_mainboard_id(device.getSi_mainboard_id());
            deviceBox.setSw_device_id(device.getSd_device_id());
            deviceBox.setSi_number(device.getSi_box_count());
            List<String> boardList = this.deviceBoxDao.findBoardListByDeviceId(deviceBox);
            String[] animals = boardList.toArray(new String[0]);
            deviceBox.setBoardArr(animals);
            Tb_devicelogs deviceLogs = new Tb_devicelogs();
            deviceLogs.setSw_mid(deviceBox.getSw_mainboard_id());
            result_map = this.deviceLogsService.checkDeviceLogs(deviceLogs);
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                List<Tb_device_box> boxList;
                if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(deviceBox.getSr_device_type())) {
                    result_map = this.stompWebSocketService.openAllLock(deviceBox);
                } else if (XcbConstantValue.DEVICE_TYPE_WPJCG.equals(deviceBox.getSr_device_type())) {
                    result_map = this.socketService.openAllLock(deviceBox);
                }
                result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO && (boxList = this.deviceBoxDao.findDeviceBoxByDeviceId_agent(deviceBox)).size() > 0) {
                    for (Tb_device_box box : boxList) {
                        Tb_order order;
                        if (!XcbConstantValue.DEVICE_BOX_STATUS_ZY.equals(box.getSr_box_status()) || (order = this.orderDao.findNewestOrderByBox(box.getSd_box_id())) == null) continue;
                        Tb_opendoor_record record = new Tb_opendoor_record();
                        String sd_openid_id = CommonFunction.getVoucherNum((String)CommonFunction.op_id);
                        record.setSd_openid_id(sd_openid_id);
                        record.setSw_order_id(order.getSd_order_id());
                        record.setSw_user_id(order.getSw_user_id());
                        record.setSr_type(XcbConstantValue.OPEN_DOOR_TYPE_KMCG);
                        record.setTm_create_time(new Date());
                        record.setSr_create_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                        record.setTm_modify_time(new Date());
                        record.setSr_modify_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                        record.setSr_remarks("\u516c\u53f8\u5f00\u95e8");
                        result_map = this.openDoorRecordService.createOpenDoorRecord(record);
                    }
                }
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline2"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_OPEN_ALL_LOCK_CPY, PromptProperties.getProperty("device.cloud.openlock.fail"), (Throwable)e);
        }
        return result_map;
    }

    public Map<String, Object> powerMain(List<Tb_device_fittings> fittingsList, String way) {
        Map<String, Object> result_map = new HashMap<String, Object>();
        try {
            for (Tb_device_fittings fittings : fittingsList) {
                if (XcbConstantValue.FITTINGS_STATUS_CWK.equals(fittings.getSr_status())) {
                    result_map = "create".equals(way) ? this.stompWebSocketService.openPower(fittings) : this.stompWebSocketService.closePower(fittings);
                } else if (XcbConstantValue.FITTINGS_STATUS_CWG.equals(fittings.getSr_status())) {
                    result_map = "create".equals(way) ? this.stompWebSocketService.closePower(fittings) : this.stompWebSocketService.openPower(fittings);
                }
                String msg = XcbStringUtils.getObjtoString(result_map.get(XcbConstantValue.MSG));
                this.log.info("\u8bbe\u5907" + fittings.getSi_mainboard_id() + "\u901a\u7535\u6307\u4ee4\u8fd4\u56de: " + msg);
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            e.printStackTrace();
        }
        return result_map;
    }

    private Map<String, Object> readMcuid(Tb_device_box deviceBox) {
        Map<Object, Object> result_map = new HashMap();
        try {
            Tb_devicelogs deviceLogs = new Tb_devicelogs();
            deviceLogs.setSw_mid(deviceBox.getSw_mainboard_id());
            result_map = this.deviceLogsService.checkDeviceLogs(deviceLogs);
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                String sr_mcuid;
                result_map = this.stompWebSocketService.readMcuid(deviceBox);
                result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO && !XcbStringUtils.isNullOrBlank((Object)(sr_mcuid = XcbStringUtils.getObjtoString((Object)result_map.get(XcbConstantValue.MSG))))) {
                    Tb_device_param deviceParam = new Tb_device_param();
                    deviceParam.setSr_mcuid(sr_mcuid);
                    deviceParam.setTm_create_time(new Date());
                    this.deviceService.createMcuid(deviceParam);
                }
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline2"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DEVICE_CLOUD_GET_MCUID, "\u67e5\u8be2mcuid\u5f02\u5e38", (Throwable)e);
        }
        return result_map;
    }
}

