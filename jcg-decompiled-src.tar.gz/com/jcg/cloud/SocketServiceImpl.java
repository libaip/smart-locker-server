/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  net.sf.json.JSONObject
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.client.utils.URIBuilder
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 *  org.apache.http.util.EntityUtils
 *  org.springframework.stereotype.Service
 */
package com.jcg.cloud;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import net.sf.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

@Service
public class SocketServiceImpl
extends BaseService {
    private static String socket_url = XcbConstantValue.socket_url;

    public Map<String, Object> openLock(Tb_device_box deviceBox) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = socket_url + "/api/openLock";
            dataMap = new HashMap();
            dataMap.put("uid", deviceBox.getSw_mainboard_id());
            dataMap.put("BoardNo", deviceBox.getSi_board_number());
            dataMap.put("LockNo", deviceBox.getSi_lock_number());
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.openlock.success"));
            } else {
                String msg = EntityUtils.toString((HttpEntity)response.getEntity());
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> getState(Tb_device_box deviceBox) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = socket_url + "/api/getState";
            dataMap = new HashMap();
            dataMap.put("uid", deviceBox.getSw_mainboard_id());
            dataMap.put("BoardNo", deviceBox.getSi_board_number());
            dataMap.put("LockNo", deviceBox.getSi_lock_number());
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = EntityUtils.toString((HttpEntity)response.getEntity());
            JSONObject jsonResult = JSONObject.fromObject((Object)msg);
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, jsonResult.get("data"));
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, jsonResult.get("data"));
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> openAllLock(Tb_device_box deviceBox) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = socket_url + "/api/openAllLock";
            dataMap = new HashMap();
            dataMap.put("uid", deviceBox.getSw_mainboard_id());
            dataMap.put("BoardNo", deviceBox.getSi_board_number());
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = EntityUtils.toString((HttpEntity)response.getEntity());
            JSONObject jsonResult = JSONObject.fromObject((Object)msg);
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.openlock.success"));
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> checkDeviceStatus(Tb_device_box deviceBox) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = socket_url + "/api/getOnline";
            dataMap = new HashMap();
            dataMap.put("uid", deviceBox.getSw_mainboard_id());
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = EntityUtils.toString((HttpEntity)response.getEntity());
            JSONObject jsonResult = JSONObject.fromObject((Object)msg);
            if (statusCode == 200) {
                String data = jsonResult.getString("data");
                JSONObject dataJson = JSONObject.fromObject((Object)data);
                boolean isOnline = (Boolean)dataJson.get("isOnline");
                if (isOnline) {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.online"));
                } else {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.offline"));
                }
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.check.status.fail"));
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> getToken() throws Exception {
        String result;
        JSONObject json;
        int code;
        Map<String, Object> resMap = new HashMap<String, Object>();
        String token = "";
        String url = socket_url + "/api/getToken";
        String key = XcbConstantValue.STOMP_WEBSOCKET_KEY;
        HashMap<String, String> dataMap = new HashMap<String, String>();
        dataMap.put("key", key);
        String reqdata = JSONObject.fromObject(dataMap).toString();
        CloseableHttpResponse response = this.sendPost(url, reqdata, token);
        int statusCode = response.getStatusLine().getStatusCode();
        if (statusCode == 200 && (code = (json = JSONObject.fromObject((Object)(result = EntityUtils.toString((HttpEntity)response.getEntity())))).getInt("code")) == 200) {
            resMap = (Map)json.get("data");
        }
        return resMap;
    }

    private CloseableHttpResponse sendPost(String url, String reqdata, String token) throws Exception {
        CloseableHttpResponse response = null;
        CloseableHttpClient httpClient = HttpClients.createDefault();
        try {
            URIBuilder uriBuilder = new URIBuilder(url);
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, XcbConstantValue.ENCODING_UTF8);
            entity.setContentType("application/json");
            httpPost.setEntity((HttpEntity)entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Authorization", token);
            response = httpClient.execute((HttpUriRequest)httpPost);
        }
        catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }
}

