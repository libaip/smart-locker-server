/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_device_fittings
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  net.sf.json.JSONObject
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.client.utils.URIBuilder
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 *  org.apache.http.util.EntityUtils
 *  org.springframework.stereotype.Service
 */
package com.jcg.cloud;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_device_fittings;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import net.sf.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

@Service
public class StompWebSocketServiceImpl
extends BaseService {
    private static String websocket_url = XcbConstantValue.websocket_url;

    public Map<String, Object> openLock(Tb_device_box deviceBox) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("mid", deviceBox.getSw_mainboard_id());
            dataMap.put("boardno", deviceBox.getSi_board_number());
            dataMap.put("lockno", deviceBox.getSi_lock_number());
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_OPEN);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.openlock.success"));
            } else {
                String msg = EntityUtils.toString((HttpEntity)response.getEntity());
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                this.log.error("\u5f00\u9501\u8fd4\u56de:" + msg);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> openPower(Tb_device_fittings fittings) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("mid", fittings.getSi_mainboard_id());
            dataMap.put("boardno", fittings.getSi_board_number());
            dataMap.put("lockno", fittings.getSi_lock_number());
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_OPEN_POWER);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.openlock.success"));
            } else {
                String msg = EntityUtils.toString((HttpEntity)response.getEntity());
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> closePower(Tb_device_fittings fittings) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("mid", fittings.getSi_mainboard_id());
            dataMap.put("boardno", fittings.getSi_board_number());
            dataMap.put("lockno", fittings.getSi_lock_number());
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_CLOSE_POWER);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.openlock.success"));
            } else {
                String msg = EntityUtils.toString((HttpEntity)response.getEntity());
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> getState(Tb_device_box deviceBox) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        JSONObject json = null;
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("mid", deviceBox.getSw_mainboard_id());
            dataMap.put("boardno", deviceBox.getSi_board_number());
            dataMap.put("lockno", deviceBox.getSi_lock_number());
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_STATE);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = "";
            String str = EntityUtils.toString((HttpEntity)response.getEntity());
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                json = JSONObject.fromObject((Object)str);
                msg = json.getString("data");
            }
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, msg);
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> getCoverPicture(String sw_mainboard_id) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        JSONObject json = null;
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("mid", sw_mainboard_id);
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_COVER);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = "";
            String str = EntityUtils.toString((HttpEntity)response.getEntity());
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                json = JSONObject.fromObject((Object)str);
                msg = json.getString("data");
            }
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, msg);
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> readMcuid(Tb_device_box deviceBox) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        JSONObject json = null;
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("mid", deviceBox.getSw_mainboard_id());
            dataMap.put("boardno", deviceBox.getSi_board_number());
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_MCUID);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = "";
            String str = EntityUtils.toString((HttpEntity)response.getEntity());
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                json = JSONObject.fromObject((Object)str);
                msg = json.getString("data");
            }
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, msg);
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> getSimInfo(String sw_mainboard_id) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        JSONObject json = null;
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("mid", sw_mainboard_id);
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_SIM);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = "";
            String str = EntityUtils.toString((HttpEntity)response.getEntity());
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                json = JSONObject.fromObject((Object)str);
                msg = json.getString("data");
            }
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, "\u8bfb\u53d6\u6210\u529f");
                result_map.put(XcbConstantValue.DATA, JSONObject.fromObject((Object)msg));
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> openAllLock(Tb_device_box deviceBox) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("mid", deviceBox.getSw_mainboard_id());
            dataMap.put("boardArr", deviceBox.getBoardArr());
            dataMap.put("cnt", deviceBox.getSi_number());
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_OPENALL);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.openlock.success"));
            } else {
                String msg = EntityUtils.toString((HttpEntity)response.getEntity());
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> getToken() throws Exception {
        String result;
        JSONObject json;
        int code;
        Map<String, Object> resMap = new HashMap<String, Object>();
        String token = "";
        String url = websocket_url + "/api/getToken";
        String key = XcbConstantValue.STOMP_WEBSOCKET_KEY;
        HashMap<String, String> dataMap = new HashMap<String, String>();
        dataMap.put("key", key);
        String reqdata = JSONObject.fromObject(dataMap).toString();
        CloseableHttpResponse response = this.sendPost(url, reqdata, token);
        int statusCode = response.getStatusLine().getStatusCode();
        if (statusCode == 200 && (code = (json = JSONObject.fromObject((Object)(result = EntityUtils.toString((HttpEntity)response.getEntity())))).getInt("code")) == 200) {
            resMap = (Map)json.get("data");
        }
        return resMap;
    }

    public Map<String, Object> updateApp_cpy(String sw_mainboard_id) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_UPDATE);
            dataMap.put("mid", sw_mainboard_id);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.update.apk.success"));
            } else {
                String msg = EntityUtils.toString((HttpEntity)response.getEntity());
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> refreshApp(String sw_mainboard_id) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        JSONObject json = null;
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("mid", sw_mainboard_id);
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_REFRESH);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = "";
            String str = EntityUtils.toString((HttpEntity)response.getEntity());
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                json = JSONObject.fromObject((Object)str);
                msg = json.getString("data");
            }
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, msg);
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> refreshDoor(String sw_mainboard_id) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        JSONObject json = null;
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("mid", sw_mainboard_id);
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_REFRESH_DOOR);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = "";
            String str = EntityUtils.toString((HttpEntity)response.getEntity());
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                json = JSONObject.fromObject((Object)str);
                msg = json.getString("data");
            }
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, msg);
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    public Map<String, Object> refreshAll(Integer sw_netpoint_id) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        JSONObject json = null;
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToAll";
            dataMap = new HashMap();
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_REFRESH);
            dataMap.put("netid", sw_netpoint_id);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = "";
            String str = EntityUtils.toString((HttpEntity)response.getEntity());
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                json = JSONObject.fromObject((Object)str);
                msg = json.getString("data");
            }
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, msg);
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }

    private CloseableHttpResponse sendPost(String url, String reqdata, String token) throws Exception {
        CloseableHttpResponse response = null;
        CloseableHttpClient httpClient = HttpClients.createDefault();
        try {
            URIBuilder uriBuilder = new URIBuilder(url);
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, XcbConstantValue.ENCODING_UTF8);
            entity.setContentType("application/json");
            httpPost.setEntity((HttpEntity)entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Authorization", token);
            response = httpClient.execute((HttpUriRequest)httpPost);
        }
        catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }

    public Map<String, Object> reboot_cpy(String sw_mainboard_id) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> dataMap = new HashMap();
        dataMap = this.getToken();
        String tokenHead = (String)dataMap.get("tokenHead");
        String token = XcbStringUtils.getObjtoString((Object)dataMap.get("token"));
        StringBuffer sb = new StringBuffer();
        sb.append(tokenHead).append(token);
        if (!XcbStringUtils.isNullOrBlank((Object)sb.toString())) {
            String url = websocket_url + "/api/sendToMid";
            dataMap = new HashMap();
            dataMap.put("type", XcbConstantValue.DEVICE_CLOUD_TYPE_REBOOT);
            dataMap.put("mid", sw_mainboard_id);
            dataMap.put("method", "send");
            String reqdata = JSONObject.fromObject(dataMap).toString();
            CloseableHttpResponse response = this.sendPost(url, reqdata, sb.toString());
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.cloud.update.apk.success"));
            } else {
                String msg = EntityUtils.toString((HttpEntity)response.getEntity());
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u83b7\u53d6\u8ba4\u8bc1\u5931\u8d25");
        }
        return result_map;
    }
}

