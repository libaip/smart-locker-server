/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.XcbConstantValue
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 */
package com.jcg.common;

import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.idao.SysParamDao;
import com.jcg.company.serviceimpl.OperationLogServiceImpl;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class BaseService {
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    @Autowired
    public SysParamDao sysParamDao;
    @Autowired
    public OperationLogServiceImpl operationLogServiceImpl;

    public Map<String, Object> initResultMap(Map<String, Object> map) {
        if (map != null) {
            if (!map.containsKey(XcbConstantValue.MSG)) {
                map.put(XcbConstantValue.MSG, XcbConstantValue.DEFAULT_STR);
            }
            if (!map.containsKey(XcbConstantValue.STATUS)) {
                map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            }
            if (!map.containsKey(XcbConstantValue.DATA)) {
                map.put(XcbConstantValue.DATA, XcbConstantValue.DEFAULT_STR);
            }
        }
        return map;
    }
}

