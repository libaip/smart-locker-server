/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_customer_app
 *  com.jcg.company.model.Tb_goods_category
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.user.model.Tb_user_account
 *  javax.servlet.http.HttpServletRequest
 *  net.sf.json.JSONObject
 *  org.apache.commons.lang.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.common;

import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_device;
import com.jcg.client.WxPusher;
import com.jcg.client.bean.Message;
import com.jcg.client.bean.MessageResult;
import com.jcg.client.bean.Page;
import com.jcg.client.bean.Result;
import com.jcg.client.bean.WxUser;
import com.jcg.common.BaseService;
import com.jcg.common.ConstantsProperties;
import com.jcg.common.OSSClientUtil;
import com.jcg.common.PromptProperties;
import com.jcg.common.QRCodeKit;
import com.jcg.common.QRCodeKit2;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_customer_app;
import com.jcg.company.model.Tb_goods_category;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.user.idao.UserAccountDao;
import com.jcg.user.model.Tb_user_account;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CommonLogic
extends BaseService {
    private Logger log = LoggerFactory.getLogger(this.getClass());
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private UserAccountDao userAccountDao;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int updateAgent_agentmoney(BigDecimal income_money, Tb_agent agent, String type) {
        int count = 0;
        Class<CommonLogic> clazz = CommonLogic.class;
        synchronized (CommonLogic.class) {
            BigDecimal oldAgentMoney = agent.getDc_agent_money();
            BigDecimal newAgentMoney = this.jSMoney(oldAgentMoney, income_money, type);
            agent.setDc_agent_money(newAgentMoney);
            agent.setDc_old_agent_money(oldAgentMoney);
            count = this.agentDao.updateAgentMoneyById(agent);
            if (count <= 0) {
                agent = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
                oldAgentMoney = agent.getDc_agent_money();
                newAgentMoney = this.jSMoney(oldAgentMoney, income_money, type);
                agent.setDc_agent_money(newAgentMoney);
                agent.setDc_old_agent_money(oldAgentMoney);
                count = this.agentDao.updateAgentMoneyById(agent);
                if (count <= 0) {
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "updateAgent_agentmoney", agent.getSd_agent_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u4ee3\u7406\u5546\u4f59\u989d\u4fee\u6539\uff0c\u4e1a\u52a1\u7c7b\u578b:" + type, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                    operationLogs.setSr_operate_primarykey(String.valueOf(agent.getSd_agent_id()));
                    operationLogs.setSr_operate_table("Tb_agent");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
            }
            // ** MonitorExit[var5_5] (shouldn't be in output)
            return count;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int updateAgent_maxmoney(BigDecimal income_money, Tb_agent agent, String type) {
        int count = 0;
        Class<CommonLogic> clazz = CommonLogic.class;
        synchronized (CommonLogic.class) {
            BigDecimal oldMaxMoney = agent.getDc_max_money();
            BigDecimal newMaxMoney = this.jSMoney(oldMaxMoney, income_money, type);
            agent.setDc_max_money(newMaxMoney);
            agent.setDc_old_max_money(oldMaxMoney);
            count = this.agentDao.updateMaxMoneyById(agent);
            if (count <= 0) {
                agent = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
                oldMaxMoney = agent.getDc_max_money();
                newMaxMoney = this.jSMoney(oldMaxMoney, income_money, type);
                agent.setDc_max_money(newMaxMoney);
                agent.setDc_old_max_money(oldMaxMoney);
                count = this.agentDao.updateMaxMoneyById(agent);
                if (count <= 0) {
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "updateAgent_maxmoney", agent.getSd_agent_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u4ee3\u7406\u5546\u4f59\u989d\u4fee\u6539\uff0c\u4e1a\u52a1\u7c7b\u578b:" + type, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                    operationLogs.setSr_operate_primarykey(String.valueOf(agent.getSd_agent_id()));
                    operationLogs.setSr_operate_table("Tb_agent");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
            }
            // ** MonitorExit[var5_5] (shouldn't be in output)
            return count;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int updateAgent_txmoney(BigDecimal income_money, Tb_agent agent) {
        int count = 0;
        Class<CommonLogic> clazz = CommonLogic.class;
        synchronized (CommonLogic.class) {
            BigDecimal oldTxMoney = agent.getDc_tx_money();
            BigDecimal oldAgentMoney = agent.getDc_agent_money();
            BigDecimal newTxMoney = null;
            BigDecimal newAgentMoney = null;
            newTxMoney = this.jSMoney(oldTxMoney, income_money, XcbConstantValue.TB_TYPE_ADD);
            newAgentMoney = this.jSMoney(oldAgentMoney, income_money, XcbConstantValue.TB_TYPE_MINUS);
            agent.setDc_tx_money(newTxMoney);
            agent.setDc_old_tx_money(oldTxMoney);
            agent.setDc_agent_money(newAgentMoney);
            agent.setDc_old_agent_money(oldAgentMoney);
            count = this.agentDao.updateAgentTxMoneyById(agent);
            if (count <= 0) {
                agent = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
                oldTxMoney = agent.getDc_tx_money();
                oldAgentMoney = agent.getDc_agent_money();
                newTxMoney = this.jSMoney(oldTxMoney, income_money, XcbConstantValue.TB_TYPE_ADD);
                newAgentMoney = this.jSMoney(oldAgentMoney, income_money, XcbConstantValue.TB_TYPE_MINUS);
                agent.setDc_tx_money(newTxMoney);
                agent.setDc_old_tx_money(oldTxMoney);
                agent.setDc_agent_money(newAgentMoney);
                agent.setDc_old_agent_money(oldAgentMoney);
                count = this.agentDao.updateAgentTxMoneyById(agent);
                if (count <= 0) {
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "updateAgent_txmoney", agent.getSd_agent_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u4ee3\u7406\u5546\u63d0\u73b0\u91d1\u989d\u4fee\u6539\uff08\u6d89\u53ca\u63d0\u73b0\u91d1\u989d\u5411\u52a0\uff0c\u4f59\u989d\u5411\u51cf\uff09", "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                    operationLogs.setSr_operate_primarykey(String.valueOf(agent.getSd_agent_id()));
                    operationLogs.setSr_operate_result(XcbConstantValue.OPERATION_FAIL);
                    operationLogs.setSr_operate_table("Tb_agent");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
            }
            // ** MonitorExit[var4_4] (shouldn't be in output)
            return count;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int updateOnlyAgent_txmoney(BigDecimal income_money, Tb_agent agent) {
        int count = 0;
        Class<CommonLogic> clazz = CommonLogic.class;
        synchronized (CommonLogic.class) {
            BigDecimal oldTxMoney = agent.getDc_tx_money();
            BigDecimal newTxMoney = null;
            newTxMoney = this.jSMoney(oldTxMoney, income_money, XcbConstantValue.TB_TYPE_ADD);
            agent.setDc_tx_money(newTxMoney);
            agent.setDc_old_tx_money(oldTxMoney);
            count = this.agentDao.updateAgentTxMoneyById(agent);
            if (count <= 0) {
                agent = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
                oldTxMoney = agent.getDc_tx_money();
                newTxMoney = this.jSMoney(oldTxMoney, income_money, XcbConstantValue.TB_TYPE_ADD);
                agent.setDc_tx_money(newTxMoney);
                agent.setDc_old_tx_money(oldTxMoney);
                count = this.agentDao.updateAgentTxMoneyById(agent);
                if (count <= 0) {
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "updateOnlyAgent_txmoney", agent.getSd_agent_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u4ee3\u7406\u5546\u63d0\u73b0\u91d1\u989d\u4fee\u6539\uff08\u63d0\u73b0\u7533\u8bf7\uff09", "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                    operationLogs.setSr_operate_primarykey(String.valueOf(agent.getSd_agent_id()));
                    operationLogs.setSr_operate_result(XcbConstantValue.OPERATION_FAIL);
                    operationLogs.setSr_operate_table("Tb_agent");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
            }
            // ** MonitorExit[var4_4] (shouldn't be in output)
            return count;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int updateAgent_cbmoney(BigDecimal income_money, Tb_agent agent, String type) {
        int count = 0;
        Class<CommonLogic> clazz = CommonLogic.class;
        synchronized (CommonLogic.class) {
            BigDecimal oldCbMoney = agent.getDc_cb_money();
            BigDecimal newCbMoney = null;
            newCbMoney = this.jSMoney(oldCbMoney, income_money, type);
            agent.setDc_cb_money(newCbMoney);
            agent.setDc_old_cb_money(oldCbMoney);
            count = this.agentDao.updateAgentCbMoneyById(agent);
            if (count <= 0) {
                agent = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
                oldCbMoney = agent.getDc_cb_money();
                newCbMoney = this.jSMoney(oldCbMoney, income_money, type);
                agent.setDc_cb_money(newCbMoney);
                agent.setDc_old_cb_money(oldCbMoney);
                count = this.agentDao.updateAgentCbMoneyById(agent);
                if (count <= 0) {
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "updateAgent_cbmoney", agent.getSd_agent_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u4ee3\u7406\u5546\u50a8\u5907\u91d1\u4fee\u6539\uff0c\u4e1a\u52a1\u7c7b\u578b:" + type, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                    operationLogs.setSr_operate_primarykey(String.valueOf(agent.getSd_agent_id()));
                    operationLogs.setSr_operate_table("Tb_agent");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
            }
            // ** MonitorExit[var5_5] (shouldn't be in output)
            return count;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int updateAgent_admoney(BigDecimal income_money, Tb_agent agent, String type) {
        int count = 0;
        Class<CommonLogic> clazz = CommonLogic.class;
        synchronized (CommonLogic.class) {
            BigDecimal oldAdMoney = agent.getDc_ad_money();
            BigDecimal newAdMoney = null;
            newAdMoney = this.jSMoney(oldAdMoney, income_money, type);
            agent.setDc_ad_money(newAdMoney);
            agent.setDc_old_ad_money(oldAdMoney);
            count = this.agentDao.updateAdMoneyById(agent);
            if (count <= 0) {
                agent = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
                oldAdMoney = agent.getDc_cb_money();
                newAdMoney = this.jSMoney(oldAdMoney, income_money, type);
                agent.setDc_ad_money(newAdMoney);
                agent.setDc_old_ad_money(oldAdMoney);
                count = this.agentDao.updateAdMoneyById(agent);
                if (count <= 0) {
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "updateAgent_admoney", agent.getSd_agent_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u4ee3\u7406\u5546\u5e7f\u544a\u8d39\u91d1\u989d\u4fee\u6539\uff0c\u4e1a\u52a1\u7c7b\u578b:" + type, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                    operationLogs.setSr_operate_primarykey(String.valueOf(agent.getSd_agent_id()));
                    operationLogs.setSr_operate_table("Tb_agent");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
            }
            // ** MonitorExit[var5_5] (shouldn't be in output)
            return count;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int updateUser_account(Identifier identifier, BigDecimal account_money, BigDecimal present_money, Tb_user_account userAccount, String type, String model) throws Exception {
        int count = 0;
        Class<CommonLogic> clazz = CommonLogic.class;
        synchronized (CommonLogic.class) {
            BigDecimal dc_integral = BigDecimalUtil.mul((BigDecimal)account_money, (BigDecimal)new BigDecimal(100));
            BigDecimal oldAccountMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money());
            BigDecimal oldPresentMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_present_money());
            BigDecimal oldIntegral = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_integral());
            Map<Object, Object> resultMap = new HashMap();
            BigDecimal newAccountMoney = oldAccountMoney;
            BigDecimal newPresentMoney = oldPresentMoney;
            BigDecimal newIntegral = oldIntegral;
            try {
                resultMap = this.jSMoney2(oldAccountMoney, account_money, oldPresentMoney, present_money, oldIntegral, dc_integral, type, model);
                newAccountMoney = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newAccountMoney"));
                newPresentMoney = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newPresentMoney"));
                newIntegral = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newIntegral"));
                if (new BigDecimal("0").compareTo(newAccountMoney) > 0) {
                    newAccountMoney = new BigDecimal("0");
                }
                userAccount.setDc_account_money(newAccountMoney);
                userAccount.setDc_old_account_money(oldAccountMoney);
                userAccount.setDc_present_money(newPresentMoney);
                userAccount.setDc_old_present_money(oldPresentMoney);
                userAccount.setDc_integral(newIntegral);
                userAccount.setDc_old_integral(oldIntegral);
                count = this.userAccountDao.updateUserAccountById_user(userAccount);
                if (count <= 0) {
                    userAccount = this.userAccountDao.findUserAccountByUser(userAccount.getSw_user_id());
                    oldAccountMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money());
                    oldPresentMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_present_money());
                    oldIntegral = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_integral());
                    newAccountMoney = oldAccountMoney;
                    newPresentMoney = oldPresentMoney;
                    newIntegral = oldIntegral;
                    resultMap = this.jSMoney2(oldAccountMoney, account_money, oldPresentMoney, present_money, oldIntegral, dc_integral, type, model);
                    newAccountMoney = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newAccountMoney"));
                    newPresentMoney = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newPresentMoney"));
                    newIntegral = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newIntegral"));
                    if (new BigDecimal("0").compareTo(newAccountMoney) > 0) {
                        newAccountMoney = new BigDecimal("0");
                    }
                    userAccount.setDc_account_money(newAccountMoney);
                    userAccount.setDc_old_account_money(oldAccountMoney);
                    userAccount.setDc_present_money(newPresentMoney);
                    userAccount.setDc_old_present_money(oldPresentMoney);
                    userAccount.setDc_integral(newIntegral);
                    userAccount.setDc_old_integral(oldIntegral);
                    count = this.userAccountDao.updateUserAccountById_user(userAccount);
                    if (count <= 0) {
                        Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_USER, "updateUser_account", userAccount.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", PromptProperties.getProperty("userAccount.update.fail2", model), identifier.getUrl(), identifier.getIp());
                        operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                        operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)userAccount.getSd_account_id()));
                        operationLogs.setSr_operate_table("tb_user_account");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                }
            }
            catch (Exception e) {
                this.log.error(e.getMessage());
                throw new Exception();
            }
            return count;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int updateRemarkUser_account(Identifier identifier, BigDecimal account_money, Tb_user_account userAccount, String type) throws Exception {
        int count = 0;
        Class<CommonLogic> clazz = CommonLogic.class;
        synchronized (CommonLogic.class) {
            BigDecimal oldRemarkMoney;
            BigDecimal newRemarkMoney = oldRemarkMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_remark_money());
            try {
                newRemarkMoney = this.jSMoney(oldRemarkMoney, account_money, type);
                if (new BigDecimal("0").compareTo(newRemarkMoney) > 0) {
                    newRemarkMoney = new BigDecimal("0");
                }
                userAccount.setDc_remark_money(newRemarkMoney);
                userAccount.setDc_old_remark_money(oldRemarkMoney);
                count = this.userAccountDao.updateRemarkUserAccountById_user(userAccount);
                if (count <= 0) {
                    userAccount = this.userAccountDao.findUserAccountByUser(userAccount.getSw_user_id());
                    newRemarkMoney = oldRemarkMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_remark_money());
                    newRemarkMoney = this.jSMoney(oldRemarkMoney, account_money, type);
                    if (new BigDecimal("0").compareTo(newRemarkMoney) > 0) {
                        newRemarkMoney = new BigDecimal("0");
                    }
                    userAccount.setDc_account_money(newRemarkMoney);
                    userAccount.setDc_old_account_money(oldRemarkMoney);
                    count = this.userAccountDao.updateRemarkUserAccountById_user(userAccount);
                    if (count <= 0) {
                        Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_USER, "updateRemarkUser_account", userAccount.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", PromptProperties.getProperty("userAccount.update.fail2", "\u5173\u95ed\u8ba2\u5355"), identifier.getUrl(), identifier.getIp());
                        operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                        operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)userAccount.getSd_account_id()));
                        operationLogs.setSr_operate_table("tb_user_account");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                }
            }
            catch (Exception e) {
                this.log.error(e.getMessage());
                throw new Exception();
            }
            return count;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int updateUser_account_task(BigDecimal account_money, BigDecimal present_money, BigDecimal dc_remark_money, Tb_user_account userAccount) throws Exception {
        int count = 0;
        Class<CommonLogic> clazz = CommonLogic.class;
        synchronized (CommonLogic.class) {
            BigDecimal oldAccountMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money());
            BigDecimal oldPresentMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_present_money());
            BigDecimal oldRemarkMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_remark_money());
            Map<Object, Object> resultMap = new HashMap();
            BigDecimal newAccountMoney = oldAccountMoney;
            BigDecimal newPresentMoney = oldPresentMoney;
            BigDecimal newRemarkMoney = oldRemarkMoney;
            try {
                resultMap = this.jSMoney(oldAccountMoney, account_money, oldPresentMoney, present_money, oldRemarkMoney, newRemarkMoney);
                newAccountMoney = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newAccountMoney"));
                newPresentMoney = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newPresentMoney"));
                newRemarkMoney = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newRemarkMoney"));
                if (BigDecimal.ZERO.compareTo(newAccountMoney) > 0) {
                    newAccountMoney = BigDecimal.ZERO;
                }
                userAccount.setDc_account_money(newAccountMoney);
                userAccount.setDc_old_account_money(oldAccountMoney);
                userAccount.setDc_present_money(newPresentMoney);
                userAccount.setDc_old_present_money(oldPresentMoney);
                userAccount.setDc_remark_money(newRemarkMoney);
                userAccount.setDc_old_remark_money(oldRemarkMoney);
                count = this.userAccountDao.updateUserAccountById_task(userAccount);
                if (count <= 0) {
                    userAccount = this.userAccountDao.findUserAccountByUser(userAccount.getSw_user_id());
                    oldAccountMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money());
                    oldPresentMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_present_money());
                    oldRemarkMoney = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_remark_money());
                    newAccountMoney = oldAccountMoney;
                    newPresentMoney = oldPresentMoney;
                    newRemarkMoney = oldRemarkMoney;
                    resultMap = this.jSMoney(oldAccountMoney, account_money, oldPresentMoney, present_money, oldRemarkMoney, newRemarkMoney);
                    newAccountMoney = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newAccountMoney"));
                    newPresentMoney = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newPresentMoney"));
                    newRemarkMoney = XcbStringUtils.getObjToBigDecimal((Object)resultMap.get("newRemarkMoney"));
                    if (BigDecimal.ZERO.compareTo(newAccountMoney) > 0) {
                        newAccountMoney = BigDecimal.ZERO;
                    }
                    userAccount.setDc_account_money(newAccountMoney);
                    userAccount.setDc_old_account_money(oldAccountMoney);
                    userAccount.setDc_present_money(newPresentMoney);
                    userAccount.setDc_old_present_money(oldPresentMoney);
                    userAccount.setDc_remark_money(newRemarkMoney);
                    userAccount.setDc_old_remark_money(oldRemarkMoney);
                    count = this.userAccountDao.updateUserAccountById_task(userAccount);
                    if (count <= 0) {
                        Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_TASK, "updateUser_account", userAccount.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", PromptProperties.getProperty("userAccount.update.fail2", "\u8bbe\u5907\u6e05\u7a7a\u8d26\u6237"), "", "127.0.0.1");
                        operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
                        operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)userAccount.getSd_account_id()));
                        operationLogs.setSr_operate_table("tb_user_account");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                }
            }
            catch (Exception e) {
                this.log.error(e.getMessage());
                throw new Exception();
            }
            return count;
        }
    }

    public BigDecimal jSMoney(BigDecimal oldMoney, BigDecimal changeMoney, String type) {
        BigDecimal result_money = new BigDecimal("0");
        result_money = XcbConstantValue.TB_TYPE_ADD.equalsIgnoreCase(type) ? BigDecimalUtil.add((BigDecimal)oldMoney, (BigDecimal)changeMoney) : BigDecimalUtil.sub((BigDecimal)oldMoney, (BigDecimal)changeMoney);
        return result_money;
    }

    public Map<String, Object> jSMoney2(BigDecimal oldAccountMoney, BigDecimal changeMoney, BigDecimal oldPersentMoney, BigDecimal changeAward, BigDecimal oldRemainIntegral, BigDecimal changIntegral, String type, String model) {
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        BigDecimal newAccountMoney = BigDecimal.ZERO;
        BigDecimal newPresentMoney = BigDecimal.ZERO;
        BigDecimal newRemainIntegral = BigDecimal.ZERO;
        if (XcbConstantValue.TB_TYPE_ADD.equalsIgnoreCase(type)) {
            if (XcbConstantValue.TB_MODEL_CZ.equals(model)) {
                newAccountMoney = BigDecimalUtil.add((BigDecimal)oldAccountMoney, (BigDecimal)changeMoney);
                newPresentMoney = BigDecimalUtil.add((BigDecimal)oldPersentMoney, (BigDecimal)changeAward);
                newRemainIntegral = BigDecimalUtil.add((BigDecimal)oldRemainIntegral, (BigDecimal)changIntegral);
            } else if (!XcbConstantValue.TB_MODEL_XF.equals(model) && XcbConstantValue.TB_MODEL_DSTK.equals(model)) {
                newAccountMoney = BigDecimalUtil.add((BigDecimal)oldAccountMoney, (BigDecimal)changeMoney);
                newPresentMoney = BigDecimalUtil.add((BigDecimal)oldPersentMoney, (BigDecimal)changeAward);
                newRemainIntegral = BigDecimalUtil.add((BigDecimal)oldRemainIntegral, (BigDecimal)changIntegral);
            }
        } else if (XcbConstantValue.TB_MODEL_CZ.equals(model)) {
            newAccountMoney = BigDecimalUtil.sub((BigDecimal)oldAccountMoney, (BigDecimal)changeMoney);
            newPresentMoney = BigDecimalUtil.sub((BigDecimal)oldPersentMoney, (BigDecimal)changeAward);
            newRemainIntegral = BigDecimalUtil.sub((BigDecimal)oldRemainIntegral, (BigDecimal)changIntegral);
            if (!BigDecimalUtil.compareToZero((BigDecimal)newRemainIntegral)) {
                newRemainIntegral = BigDecimal.ZERO;
            }
        } else if (XcbConstantValue.TB_MODEL_XF.equals(model)) {
            if (changeMoney.compareTo(oldAccountMoney) > 0) {
                BigDecimal tmpMoney = BigDecimalUtil.sub((BigDecimal)changeMoney, (BigDecimal)oldAccountMoney);
                newAccountMoney = new BigDecimal("0");
                newPresentMoney = BigDecimalUtil.sub((BigDecimal)oldPersentMoney, (BigDecimal)tmpMoney);
                if (!BigDecimalUtil.compareToZero((BigDecimal)newPresentMoney)) {
                    newPresentMoney = new BigDecimal("0");
                }
            } else {
                newAccountMoney = BigDecimalUtil.sub((BigDecimal)oldAccountMoney, (BigDecimal)changeMoney);
                newPresentMoney = oldPersentMoney;
            }
            newRemainIntegral = BigDecimalUtil.add((BigDecimal)oldRemainIntegral, (BigDecimal)changIntegral);
        } else {
            newAccountMoney = oldAccountMoney;
            newPresentMoney = oldPersentMoney;
            newRemainIntegral = oldRemainIntegral;
        }
        resultMap.put("newAccountMoney", newAccountMoney);
        resultMap.put("newPresentMoney", newPresentMoney);
        resultMap.put("newIntegral", newRemainIntegral);
        return resultMap;
    }

    public Map<String, Object> jSMoney(BigDecimal oldAccountMoney, BigDecimal changeMoney, BigDecimal oldPersentMoney, BigDecimal changeAward, BigDecimal oldRemarkMoney, BigDecimal remarkMoney) {
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        BigDecimal newAccountMoney = BigDecimal.ZERO;
        BigDecimal newPresentMoney = BigDecimal.ZERO;
        BigDecimal newRemarkMoney = BigDecimal.ZERO;
        newRemarkMoney = BigDecimalUtil.add((BigDecimal)oldRemarkMoney, (BigDecimal)oldAccountMoney);
        newRemarkMoney = BigDecimalUtil.add((BigDecimal)newRemarkMoney, (BigDecimal)oldPersentMoney);
        resultMap.put("newAccountMoney", newAccountMoney);
        resultMap.put("newPresentMoney", newPresentMoney);
        resultMap.put("newRemarkMoney", newRemarkMoney);
        return resultMap;
    }

    public Map<String, Object> jSMoney(BigDecimal oldAccountMoney, BigDecimal changeMoney, BigDecimal oldPersentMoney, BigDecimal changeAward, String type, String model) {
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        BigDecimal newAccountMoney = new BigDecimal("0");
        BigDecimal newPresentMoney = new BigDecimal("0");
        if (XcbConstantValue.TB_TYPE_ADD.equalsIgnoreCase(type)) {
            if (XcbConstantValue.TB_MODEL_CZ.equals(model)) {
                newAccountMoney = BigDecimalUtil.add((BigDecimal)oldAccountMoney, (BigDecimal)changeMoney);
                newPresentMoney = BigDecimalUtil.add((BigDecimal)oldPersentMoney, (BigDecimal)changeAward);
            } else if (!XcbConstantValue.TB_MODEL_XF.equals(model) && XcbConstantValue.TB_MODEL_DSTK.equals(model)) {
                newAccountMoney = BigDecimalUtil.add((BigDecimal)oldAccountMoney, (BigDecimal)changeMoney);
                newPresentMoney = BigDecimalUtil.add((BigDecimal)oldPersentMoney, (BigDecimal)changeAward);
            }
        } else if (XcbConstantValue.TB_MODEL_CZ.equals(model)) {
            newAccountMoney = BigDecimalUtil.sub((BigDecimal)oldAccountMoney, (BigDecimal)changeMoney);
            newPresentMoney = BigDecimalUtil.sub((BigDecimal)oldPersentMoney, (BigDecimal)changeAward);
        } else if (XcbConstantValue.TB_MODEL_XF.equals(model)) {
            if (changeMoney.compareTo(oldAccountMoney) > 0) {
                BigDecimal tmpMoney = BigDecimalUtil.sub((BigDecimal)changeMoney, (BigDecimal)oldAccountMoney);
                newAccountMoney = new BigDecimal("0");
                newPresentMoney = BigDecimalUtil.sub((BigDecimal)oldPersentMoney, (BigDecimal)tmpMoney);
                if (!BigDecimalUtil.compareToZero((BigDecimal)newPresentMoney)) {
                    newPresentMoney = new BigDecimal("0");
                }
            } else {
                newAccountMoney = BigDecimalUtil.sub((BigDecimal)oldAccountMoney, (BigDecimal)changeMoney);
                newPresentMoney = oldPersentMoney;
            }
        } else {
            newAccountMoney = oldAccountMoney;
            newPresentMoney = oldPersentMoney;
        }
        resultMap.put("newAccountMoney", newAccountMoney);
        resultMap.put("newPresentMoney", newPresentMoney);
        return resultMap;
    }

    public int jSCount(int oldCount, int changeCount, String type) {
        int result_count = 0;
        result_count = XcbConstantValue.TB_TYPE_ADD.equalsIgnoreCase(type) ? oldCount + changeCount : oldCount - changeCount;
        return result_count;
    }

    public void genCode(Map<String, Object> result_map, Tb_device device, HttpServletRequest request) {
        String rootPath = request.getSession().getServletContext().getRealPath("/");
        if (!"/".equals(rootPath.substring(rootPath.length() - 1))) {
            rootPath = rootPath + "/";
        }
        String deviceId = device.getSd_device_id();
        String mid = device.getSi_mainboard_id();
        String rscpathPrefix = "jcgpic" + ConstantsProperties.getProperty("agent.device.rscpath.prefix").trim();
        String content = ConstantsProperties.getProperty("QRcode.content").trim() + "?deviceid=" + deviceId;
        String srcImagePath = rootPath + ConstantsProperties.getProperty("QRcode.iconUrl");
        String qrCodePathPrefix = rscpathPrefix + "/agent_" + device.getSw_agent_id() + "/netpoint_" + device.getSw_netpoint_id() + "/";
        Integer qrCodeWidth = Integer.valueOf(ConstantsProperties.getProperty("QRcode.width").trim());
        Integer qrCodeHeight = Integer.valueOf(ConstantsProperties.getProperty("QRcode.height").trim());
        String fileName = CommonFunction.getVoucherNum((String)CommonFunction.src_prefix) + "_" + deviceId + "_" + mid + ".png";
        String qrCodePath = qrCodePathPrefix + fileName;
        String drawWord = device.getSi_mainboard_id();
        if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(device.getSr_device_type())) {
            drawWord = null;
        }
        int result = 0;
        result = !XcbStringUtils.isNullOrBlank((Object)srcImagePath) ? QRCodeKit.encode(content, qrCodeWidth, qrCodeHeight, srcImagePath, qrCodePath, drawWord) : QRCodeKit2.encode(content, qrCodePath, qrCodeWidth, qrCodeHeight);
        if (result == 1 && StringUtils.isNotEmpty((String)device.getSr_qr_code())) {
            OSSClientUtil.deleteObject(device.getSr_qr_code());
        }
        device.setSr_qr_code(qrCodePath);
    }

    public void genQrNCode(Map<String, Object> result_map, Tb_device device, Tb_company company, HttpServletRequest request) {
        int result;
        String url;
        String rootPath = request.getSession().getServletContext().getRealPath("/");
        if (!"/".equals(rootPath.substring(rootPath.length() - 1))) {
            rootPath = rootPath + "/";
        }
        String deviceId = device.getSd_device_id();
        String mid = device.getSi_mainboard_id();
        StringBuffer sb = new StringBuffer();
        String content = url = XcbConstantValue.user_host + "?version=" + company.getSr_version() + "/#index?mid=" + mid;
        String rscpathPrefix = "jcgpic" + ConstantsProperties.getProperty("agent.device.rscpath.prefix").trim();
        String srcImagePath = rootPath + ConstantsProperties.getProperty("QRcode.iconUrl");
        String qrCodePathPrefix = rscpathPrefix + "/agent_" + device.getSw_agent_id() + "/netpoint_" + device.getSw_netpoint_id() + "/";
        Integer qrCodeWidth = Integer.valueOf(ConstantsProperties.getProperty("QRcode.width").trim());
        Integer qrCodeHeight = Integer.valueOf(ConstantsProperties.getProperty("QRcode.height").trim());
        String fileName = CommonFunction.getVoucherNum((String)CommonFunction.src_prefix) + "_" + deviceId + "_" + mid + ".png";
        String qrCodePath = qrCodePathPrefix + fileName;
        String drawWord = device.getSi_mainboard_id();
        if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(device.getSr_device_type())) {
            drawWord = null;
        }
        if ((result = QRCodeKit.encode(content, qrCodeWidth, qrCodeHeight, srcImagePath, qrCodePath, drawWord)) == 1 && StringUtils.isNotEmpty((String)device.getSr_qr_code())) {
            OSSClientUtil.deleteObject(device.getSr_qr_code());
        }
        device.setSr_qr_code(qrCodePath);
    }

    public void genWxGzhCode(Map<String, Object> result_map, Tb_device device, String url, HttpServletRequest request) {
        String rootPath = request.getSession().getServletContext().getRealPath("/");
        if (!"/".equals(rootPath.substring(rootPath.length() - 1))) {
            rootPath = rootPath + "/";
        }
        String deviceId = device.getSd_device_id();
        String mid = device.getSi_mainboard_id();
        String rscpathPrefix = "jcgpic" + ConstantsProperties.getProperty("agent.device.rscpath.prefix").trim();
        String content = url;
        String srcImagePath = rootPath + ConstantsProperties.getProperty("QRcode.iconUrl");
        srcImagePath = "";
        String qrCodePathPrefix = rscpathPrefix + "/agent_" + device.getSw_agent_id() + "/netpoint_" + device.getSw_netpoint_id() + "/";
        Integer qrCodeWidth = Integer.valueOf(ConstantsProperties.getProperty("QRcode.width").trim());
        Integer qrCodeHeight = Integer.valueOf(ConstantsProperties.getProperty("QRcode.height").trim());
        String fileName = CommonFunction.getVoucherNum((String)CommonFunction.src_prefix) + "_" + deviceId + "_" + mid + ".png";
        String qrCodePath = qrCodePathPrefix + fileName;
        String drawWord = device.getSi_mainboard_id();
        int result = 0;
        if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(device.getSr_device_type())) {
            drawWord = null;
        }
        if ((result = !XcbStringUtils.isNullOrBlank((Object)srcImagePath) ? QRCodeKit.encode(content, qrCodeWidth, qrCodeHeight, srcImagePath, qrCodePath, drawWord) : QRCodeKit2.encode(content, qrCodePath, qrCodeWidth, qrCodeHeight)) == 1 && StringUtils.isNotEmpty((String)device.getSr_qr_code())) {
            OSSClientUtil.deleteObject(device.getSr_qr_code());
        }
        device.setSr_qr_code(qrCodePath);
        if (!XcbStringUtils.isNullOrBlank((Object)url)) {
            String[] arr = url.split("http://weixin.qq.com/q/");
            device.setSr_wx_qr_code(arr[1]);
        }
    }

    public void genWxAllCode(Map<String, Object> result_map, Tb_device device, HttpServletRequest request) {
        String rootPath = request.getSession().getServletContext().getRealPath("/");
        if (!"/".equals(rootPath.substring(rootPath.length() - 1))) {
            rootPath = rootPath + "/";
        }
        String url = XcbConstantValue.server_host + "/jcgweb-user/qrcode/getPath?mid=" + device.getSi_mainboard_id();
        String deviceId = device.getSd_device_id();
        String mid = device.getSi_mainboard_id();
        String rscpathPrefix = "jcgpic" + ConstantsProperties.getProperty("agent.device.rscpath.prefix").trim();
        String content = url;
        String srcImagePath = rootPath + ConstantsProperties.getProperty("QRcode.iconUrl");
        String qrCodePathPrefix = rscpathPrefix + "/agent_" + device.getSw_agent_id() + "/netpoint_" + device.getSw_netpoint_id() + "/";
        Integer qrCodeWidth = Integer.valueOf(ConstantsProperties.getProperty("QRcode.width").trim());
        Integer qrCodeHeight = Integer.valueOf(ConstantsProperties.getProperty("QRcode.height").trim());
        String fileName = CommonFunction.getVoucherNum((String)CommonFunction.src_prefix) + "_" + deviceId + "_" + mid + ".png";
        String qrCodePath = qrCodePathPrefix + fileName;
        String drawWord = device.getSi_mainboard_id();
        if (XcbConstantValue.DEVICE_TYPE_YPJCG.equals(device.getSr_device_type())) {
            drawWord = null;
        }
        int result = 0;
        result = !XcbStringUtils.isNullOrBlank((Object)srcImagePath) ? QRCodeKit.encode(content, qrCodeWidth, qrCodeHeight, srcImagePath, qrCodePath, drawWord) : QRCodeKit2.encode(content, qrCodePath, qrCodeWidth, qrCodeHeight);
        if (result == 1 && StringUtils.isNotEmpty((String)device.getSr_qr_code())) {
            OSSClientUtil.deleteObject(device.getSr_qr_code());
        }
        device.setSr_qr_code(qrCodePath);
    }

    public void genWxCode(Map<String, Object> result_map, Tb_agent agent, Tb_company company, HttpServletRequest request) {
        String rootPath = request.getSession().getServletContext().getRealPath("/");
        if (!"/".equals(rootPath.substring(rootPath.length() - 1))) {
            rootPath = rootPath + "/";
        }
        Integer agentId = agent.getSd_agent_id();
        String agentName = agent.getSr_agent_petname();
        StringBuffer sb = new StringBuffer();
        String url = XcbConstantValue.server_host + "/jcgweb-agent/agent/getOpenid?sd_agent_id=" + agentId + "&type=jcg";
        String redirect_uri = CommonLogic.encodeURIComponent(url);
        sb.append("https://open.weixin.qq.com/connect/oauth2/authorize?appid=" + company.getSr_wx_gzh_appid() + "&redirect_uri=").append(redirect_uri).append("&response_type=code&scope=snsapi_userinfo&state=" + company.getSd_company_id() + "&connect_redirect=1#wechat_redirect");
        String sr_content = sb.toString();
        String uploadBaseUrl = ConstantsProperties.getProperty("upload.baseUrl").trim();
        String rscpathPrefix = "jcgpic" + ConstantsProperties.getProperty("agent.wx.openid.rscpath.prefix").trim();
        String content = sr_content;
        String srcImagePath = rootPath + ConstantsProperties.getProperty("QRcode.iconUrl");
        String qrCodePathPrefix = rscpathPrefix + "/agent_" + agent.getSd_agent_id();
        String fileName = CommonFunction.getVoucherNum((String)CommonFunction.src_prefix) + "_" + agentId.toString() + ".png";
        String destImagePath = uploadBaseUrl + qrCodePathPrefix;
        String qrCodePath = qrCodePathPrefix + "/" + fileName;
        Integer qrCodeWidth = Integer.valueOf(ConstantsProperties.getProperty("QRcode.width").trim());
        Integer qrCodeHeight = Integer.valueOf(ConstantsProperties.getProperty("QRcode.height").trim());
        String agentNameNew = null;
        agentNameNew = agentName != null && agentName.length() > 3 ? agentName.substring(0, 3) : agentName;
        String agentFlag = agentNameNew + ":" + agentId.toString();
        this.createDir(destImagePath);
        int result = QRCodeKit.encode(content, qrCodeWidth, qrCodeHeight, srcImagePath, qrCodePath, null);
        if (result == 1 && StringUtils.isNotEmpty((String)agent.getSr_wx_openid_qrcode())) {
            OSSClientUtil.deleteObject(agent.getSr_wx_openid_qrcode());
        }
        agent.setSr_wx_openid_qrcode(qrCodePath);
    }

    public void deleteSourceFile(String filePath) {
        String uploadBaseUrl = ConstantsProperties.getProperty("upload.baseUrl").trim();
        String originalFilePath = uploadBaseUrl + "/xcbpic/" + XcbConstantValue.companyid + filePath;
        File originalFile = new File(originalFilePath);
        if (originalFile.exists()) {
            originalFile.delete();
        }
    }

    public Integer GetQRCode(String ACCESS_TOKEN, String Folder, String FileName, String xcxUrlPage, String xcxUrlScene, int width) {
        String createwxaqrcodeStr = XcbConstantValue.wx_aqrcode_url + ACCESS_TOKEN;
        JSONObject paramJson = new JSONObject();
        paramJson.put((Object)"scene", (Object)xcxUrlScene);
        paramJson.put((Object)"page", (Object)xcxUrlPage);
        paramJson.put((Object)"width", (Object)430);
        paramJson.put((Object)"auto_color", (Object)false);
        InputStream is = this.PostInputStream(createwxaqrcodeStr, paramJson.toString());
        int result = this.saveToImgByInputStream(is, Folder, FileName);
        return result;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int saveToImgByInputStream(InputStream instreams, String imgPath, String imgName) {
        int stateInt = 1;
        if (instreams != null) {
            try {
                this.createDir(imgPath);
                File file = new File(imgPath, imgName);
                FileOutputStream fos = new FileOutputStream(file);
                byte[] b = new byte[1024];
                int nRead = 0;
                while ((nRead = instreams.read(b)) != -1) {
                    fos.write(b, 0, nRead);
                }
                fos.flush();
                fos.close();
            }
            catch (Exception e) {
                stateInt = 0;
                this.log.error(e.getMessage());
            }
        }
        return stateInt;
    }

    public InputStream PostInputStream(String strURL, String params) {
        try {
            URL url = new URL(strURL);
            HttpURLConnection connection = (HttpURLConnection)url.openConnection();
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setUseCaches(false);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.connect();
            OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
            out.append(params);
            out.flush();
            out.close();
            InputStream is = connection.getInputStream();
            return is;
        }
        catch (IOException e) {
            this.log.error(e.getMessage());
            return null;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public String sendGet(String url) {
        String result = "";
        BufferedReader in = null;
        try {
            String line;
            String urlNameString = url;
            URL realUrl = new URL(urlNameString);
            URLConnection connection = realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(20000);
            connection.connect();
            Map<String, List<String>> map = connection.getHeaderFields();
            for (String key : map.keySet()) {
                System.out.println(key + "--->" + map.get(key));
            }
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            while ((line = in.readLine()) != null) {
                result = result + line;
            }
        }
        catch (Exception e) {
            this.log.info(e.getMessage());
        }
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            }
            catch (Exception e2) {
                this.log.info(e2.getMessage());
            }
        }
        return result;
    }

    public boolean createDir(String destDirName) {
        try {
            destDirName = URLDecoder.decode(destDirName, "GB2312");
        }
        catch (UnsupportedEncodingException e) {
            this.log.error(e.getMessage());
        }
        File dir = new File(destDirName);
        if (dir.exists()) {
            this.log.info("\u76ee\u5f55" + destDirName + "\u5df2\u7ecf\u5b58\u5728");
            return false;
        }
        if (!destDirName.endsWith(File.separator)) {
            destDirName = destDirName + File.separator;
        }
        if (dir.mkdirs()) {
            this.log.info("\u521b\u5efa\u76ee\u5f55:" + destDirName + "\u6210\u529f\uff01");
            return true;
        }
        this.log.error("\u521b\u5efa\u76ee\u5f55:" + destDirName + "\u5931\u8d25\uff01");
        return false;
    }

    public void sendWXMsg(Tb_customer_app customer_app) {
        StringBuffer content = new StringBuffer();
        content.append("<h3>\u5ba2\u6237\u540d\u79f0\uff1a" + customer_app.getSr_name() + "</h3>");
        content.append("<br />");
        content.append("<h3>\u5ba2\u6237\u7535\u8bdd\uff1a" + customer_app.getSr_telphone() + "</h3>");
        content.append("<br />");
        if (!XcbStringUtils.isNullOrBlank((Object)customer_app.getSr_wx())) {
            content.append("<h3>\u5ba2\u6237\u5fae\u4fe1\uff1a" + customer_app.getSr_wx() + "</h3>");
            content.append("<br />");
        }
        content.append("<h3>\u6240\u5728\u5730\u533a\uff1a" + customer_app.getSr_addr() + "</h3>");
        content.append("<br />");
        content.append("<h3>\u8be6\u7ec6\u5730\u5740\uff1a" + customer_app.getSr_addr_detail() + "</h3>");
        content.append("<br />");
        content.append("<h3>\u7533\u8bf7\u4fe1\u606f\uff1a" + customer_app.getSr_cus_remark() + "</h3>");
        content.append("<br />");
        content.append("<h3>\u7533\u8bf7\u65f6\u95f4\uff1a" + XcbDateUtil.formatDate((Date)customer_app.getTm_create_time(), (String)"yyyy-MM-dd HH:mm:ss") + "</h3>");
        Message message = new Message();
        message.setContentType(2);
        message.setAppToken(XcbConstantValue.appToken);
        message.setContent(content.toString());
        message.setUrl(XcbConstantValue.wxUrl);
        Result<Page<WxUser>> re = WxPusher.queryWxUser(XcbConstantValue.appToken, 1, 100);
        if (re != null && re.getCode() != null && "1000".equals(re.getCode().toString())) {
            Page<WxUser> p = re.getData();
            List<WxUser> l = p.getRecords();
            for (WxUser wxuser : l) {
                message.setUid(wxuser.getUid());
                Result<List<MessageResult>> result = WxPusher.send(message);
                for (MessageResult messageResult : result.getData()) {
                    if (messageResult.getCode() != null && "1000".equals(messageResult.getCode().toString())) {
                        this.log.info("WxPusher\u5fae\u4fe1\u63a8\u9001\u670d\u52a1[\u63a8\u9001\u76ee\u6807:" + wxuser.getNickName() + ",\u7ed3\u679c:" + messageResult.getStatus() + "]");
                        continue;
                    }
                    this.log.info("WxPusher\u5fae\u4fe1\u63a8\u9001\u670d\u52a1[\u63a8\u9001\u76ee\u6807:" + wxuser.getNickName() + ",\u7ed3\u679c:" + result.getMsg() + "]");
                }
            }
        } else {
            this.log.info("WxPusher\u5fae\u4fe1\u63a8\u9001\u670d\u52a1[\u67e5\u8be2\u8ba2\u9605\u7528\u6237\u4fe1\u606f\u64cd\u4f5c:" + re.getMsg() + "]");
        }
    }

    public static String decodeURIComponent(String s) {
        if (s == null) {
            return null;
        }
        String result = null;
        try {
            result = URLDecoder.decode(s, "UTF-8");
        }
        catch (UnsupportedEncodingException e) {
            result = s;
        }
        return result;
    }

    public static String encodeURIComponent(String s) {
        String result = null;
        try {
            result = URLEncoder.encode(s, "UTF-8").replaceAll("\\+", "%20").replaceAll("\\%21", "!").replaceAll("\\%27", "'").replaceAll("\\%28", "(").replaceAll("\\%29", ")").replaceAll("\\%7E", "~");
        }
        catch (UnsupportedEncodingException e) {
            result = s;
        }
        return result;
    }

    public ArrayList<Tb_goods_category> getAllCatesCoverPic(Map<String, Object> map, HttpServletRequest request) {
        String rootPath = request.getSession().getServletContext().getRealPath("/");
        if (!"/".equals(rootPath.substring(rootPath.length() - 1))) {
            rootPath = rootPath + "/";
        }
        rootPath = ConstantsProperties.getProperty("upload.baseUrl").trim();
        String rscpathPrefix = null;
        rscpathPrefix = ConstantsProperties.getProperty("goods.category.prefix").trim();
        ArrayList<Tb_goods_category> catesList = new ArrayList<Tb_goods_category>();
        File file = new File(rootPath + "/xcbpic/" + XcbConstantValue.companyid + rscpathPrefix);
        File[] tempList = file.listFiles();
        for (int i = 0; i < tempList.length; ++i) {
            if (tempList[i].isDirectory()) continue;
            Tb_goods_category cates = new Tb_goods_category();
            String sr_picture = tempList[i].getPath().substring(rootPath.length(), tempList[i].getPath().length());
            sr_picture = sr_picture.replaceAll("xcbpic", "");
            cates.setSr_picture(sr_picture);
            catesList.add(cates);
        }
        return catesList;
    }
}

