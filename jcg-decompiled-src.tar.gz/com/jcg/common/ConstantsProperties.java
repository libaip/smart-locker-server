/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.common;

import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class ConstantsProperties {
    private static String filePath = "properties/config.properties";
    private static Map<String, String> propertyMap;

    public static String getProperty(String name) {
        return propertyMap.get(name);
    }

    static {
        Properties props = new Properties();
        propertyMap = new HashMap<String, String>();
        try {
            InputStream in = ConstantsProperties.class.getClassLoader().getResourceAsStream(filePath);
            props.load(in);
            Enumeration<?> en = props.propertyNames();
            while (en.hasMoreElements()) {
                String key = (String)en.nextElement();
                String value = props.getProperty(key);
                propertyMap.put(key, value);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}

