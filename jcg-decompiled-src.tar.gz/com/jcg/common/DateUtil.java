/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mxgraph.util.svg.ParseException
 */
package com.jcg.common;

import com.mxgraph.util.svg.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;

public class DateUtil {
    public static String toTimeText(Date date) {
        return DateUtil.toString(date, "HH:mm:ss");
    }

    public static String toDateText(Date date) {
        return DateUtil.toString(date, "yyyy-MM-dd");
    }

    public static String toDateText2(Date date) {
        return DateUtil.toString(date, "yyyyMMdd");
    }

    public static String toDatetimeText(Date date) {
        return DateUtil.toString(date, "yyyy-MM-dd HH:mm:ss");
    }

    public static String toDatetimeText2(Date date) {
        return DateUtil.toString2(date, "yyyyMMddHHmmss");
    }

    public static String toString(Date date, String format) {
        if (date == null) {
            return null;
        }
        if (format == null) {
            format = "yyyy-MM-dd HH:mm:ss";
        }
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        return formatter.format(date);
    }

    public static Date StringToDate(String strDate, String format) throws Exception {
        Date date = null;
        try {
            if (strDate == null) {
                return null;
            }
            if (format == null) {
                format = "yyyy-MM-dd HH:mm:ss";
            }
            SimpleDateFormat formatter = new SimpleDateFormat(format);
            date = formatter.parse(strDate);
        }
        catch (ParseException px) {
            px.printStackTrace();
        }
        return date;
    }

    public static String toString2(Date date, String format) {
        if (date == null) {
            return null;
        }
        if (format == null) {
            format = "yyyyMMddHHmmss";
        }
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        return formatter.format(date);
    }

    public static int getYear(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(1);
    }

    public static int getMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(2);
    }

    public static int getWeek(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(2);
        calendar.setTime(date);
        return calendar.get(3);
    }

    public static Date addDay(Date date, int addCount) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(5, addCount);
        return calendar.getTime();
    }

    public static Date subDay(Date date, int subCount) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(5, -subCount);
        return calendar.getTime();
    }

    public static int getDays(Date startDate, Date endDate) {
        return Math.abs((int)((endDate.getTime() - startDate.getTime()) / 86400000L));
    }

    public static boolean isSameDate(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        boolean isSameYear = cal1.get(1) == cal2.get(1);
        boolean isSameMonth = isSameYear && cal1.get(2) == cal2.get(2);
        boolean isSameDate = isSameMonth && cal1.get(5) == cal2.get(5);
        return isSameDate;
    }

    public static List isSameDate(List diffList, Date startDate, Set<String> dateSet, String dayType) throws Exception {
        String month;
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(startDate);
        if (!dateSet.isEmpty()) {
            for (String strDate : dateSet) {
                if ("days".equals(dayType)) {
                    String day = DateUtil.toString(startDate, "yyyyMMdd");
                    if (dateSet.contains(day)) continue;
                    diffList.add(DateUtil.toDateText2(startDate));
                    dateSet.add(day.trim());
                } else if ("weeks".equals(dayType)) {
                    int year = DateUtil.getYear(startDate);
                    int week = DateUtil.getWeek(startDate);
                    String startD = String.valueOf(year) + String.valueOf(week);
                    if (dateSet.contains(startD)) continue;
                    diffList.add(startD.trim());
                    dateSet.add(startD.trim());
                } else {
                    String month2;
                    if (!"months".equals(dayType) || dateSet.contains(month2 = DateUtil.toString(startDate, "yyyyMM"))) continue;
                    diffList.add(month2.trim());
                    dateSet.add(month2.trim());
                }
                break;
            }
        } else if ("days".equals(dayType)) {
            diffList.add(DateUtil.toDateText2(startDate));
        } else if ("weeks".equals(dayType)) {
            int year = DateUtil.getYear(startDate);
            int week = DateUtil.getWeek(startDate);
            String startD = String.valueOf(year) + String.valueOf(week);
            if (!dateSet.contains(startD)) {
                diffList.add(startD.trim());
                dateSet.add(startD);
            }
        } else if ("months".equals(dayType) && !dateSet.contains(month = DateUtil.toString(startDate, "yyyyMM"))) {
            diffList.add(month);
            dateSet.add(month);
        }
        return diffList;
    }

    public static void main(String[] args) {
        int subCount = 31;
        Date date = DateUtil.subDay(new Date(), subCount);
        System.out.println(DateUtil.toDatetimeText(date));
    }
}

