/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jcg.common;

import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GenericCallerProxy
implements GenericCaller {
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    private Map<String, GenericCaller> functionList;

    public void setFunctionList(Map functionList) {
        this.functionList = functionList;
    }

    public Map genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.info("functionCode is :------------------------- " + identifier.getFunctionCode());
        GenericCaller targetCaller = this.functionList.get(identifier.getFunctionCode());
        this.log.info("targetCaller is  :------------------------------ " + targetCaller);
        return targetCaller.genericCall(identifier, param);
    }
}

