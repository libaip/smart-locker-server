/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSONObject
 *  org.apache.http.Header
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.client.utils.URIBuilder
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 *  org.apache.http.message.BasicHeader
 *  org.apache.http.util.EntityUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jcg.common;

import com.alibaba.fastjson.JSONObject;
import com.jcg.common.GenToken;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HttpClientUtil {
    private static final String ENCODING = "UTF-8";
    protected static Logger log = LoggerFactory.getLogger(HttpClientUtil.class);

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String sendPost(String url, Map<String, String> headers, JSONObject data, String encoding) {
        log.info("\u8fdb\u5165post\u8bf7\u6c42\u65b9\u6cd5...");
        log.info("\u8bf7\u6c42\u5165\u53c2\uff1aURL= " + url);
        log.info("\u8bf7\u6c42\u5165\u53c2\uff1aheaders=" + headers.toString());
        log.info("\u8bf7\u6c42\u5165\u53c2\uff1adata=" + data.toString());
        String resultJson = null;
        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost();
        try {
            httpPost.setURI(new URI(url));
            if (headers != null) {
                BasicHeader[] allHeader = new BasicHeader[headers.size()];
                int i = 0;
                for (Map.Entry<String, String> entry : headers.entrySet()) {
                    allHeader[i] = new BasicHeader(entry.getKey(), entry.getValue());
                    ++i;
                }
                httpPost.setHeaders((Header[])allHeader);
            }
            httpPost.setEntity((HttpEntity)new StringEntity(data.toString()));
            CloseableHttpResponse response = client.execute((HttpUriRequest)httpPost);
            int status = response.getStatusLine().getStatusCode();
            if (status == 200) {
                resultJson = EntityUtils.toString((HttpEntity)response.getEntity(), (String)encoding);
            } else {
                log.error("\u54cd\u5e94\u5931\u8d25\uff0c\u72b6\u6001\u7801\uff1a" + status);
            }
        }
        catch (Exception e) {
            log.error("\u53d1\u9001post\u8bf7\u6c42\u5931\u8d25", (Throwable)e);
        }
        finally {
            httpPost.releaseConnection();
        }
        return resultJson;
    }

    public static String sendPost(String url, JSONObject data) {
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Accept", "application/json, text/plain, */*");
        headers.put("Content-Type", "application/json;charset=utf-8");
        try {
            headers.put("Authorization", GenToken.genApiToken());
        }
        catch (UnsupportedEncodingException | InvalidKeyException | NoSuchAlgorithmException e) {
            log.info("gen ontnet api token error,error msg:{}", (Object)e.getMessage());
            e.printStackTrace();
        }
        return HttpClientUtil.sendPost(url, headers, data, ENCODING);
    }

    public static String sendPost(String url, Map<String, String> headers, JSONObject data) {
        return HttpClientUtil.sendPost(url, headers, data, ENCODING);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String sendGet(String url, Map<String, Object> params, Map<String, String> headers, String encoding) {
        log.info("\u8fdb\u5165get\u8bf7\u6c42\u65b9\u6cd5...");
        log.info("\u8bf7\u6c42\u5165\u53c2\uff1aURL= " + url);
        log.info("\u8bf7\u6c42\u5165\u53c2\uff1aparams=" + JSONObject.toJSONString(params));
        String resultJson = null;
        CloseableHttpClient client = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet();
        try {
            CloseableHttpResponse response;
            int status;
            URIBuilder builder = new URIBuilder(url);
            if (params != null) {
                for (String key : params.keySet()) {
                    builder.addParameter(key, params.get(key).toString());
                }
            }
            URI uri = builder.build();
            log.info("\u8bf7\u6c42\u5730\u5740\uff1a" + uri);
            httpGet.setURI(uri);
            if (headers != null) {
                BasicHeader[] allHeader = new BasicHeader[headers.size()];
                int i = 0;
                for (Map.Entry<String, String> entry : headers.entrySet()) {
                    allHeader[i] = new BasicHeader(entry.getKey(), entry.getValue());
                    ++i;
                }
                httpGet.setHeaders((Header[])allHeader);
            }
            if ((status = (response = client.execute((HttpUriRequest)httpGet)).getStatusLine().getStatusCode()) == 200) {
                resultJson = EntityUtils.toString((HttpEntity)response.getEntity(), (String)encoding);
            } else {
                log.error("\u54cd\u5e94\u5931\u8d25\uff0c\u72b6\u6001\u7801\uff1a" + status);
            }
        }
        catch (Exception e) {
            log.error("\u53d1\u9001get\u8bf7\u6c42\u5931\u8d25", (Throwable)e);
        }
        finally {
            httpGet.releaseConnection();
        }
        return resultJson;
    }

    public static String getJsonData(String jsonParam, String urls) {
        StringBuffer sb = new StringBuffer();
        try {
            URL url = new URL(urls);
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Connection", "Keep-Alive");
            conn.setRequestProperty("Charset", ENCODING);
            byte[] data = jsonParam.getBytes();
            conn.setRequestProperty("Content-Length", String.valueOf(data.length));
            conn.setRequestProperty("contentType", "application/json");
            conn.connect();
            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream(), "utf-8");
            out.write(jsonParam);
            out.flush();
            out.close();
            if (200 == conn.getResponseCode()) {
                InputStream in1 = conn.getInputStream();
                try {
                    String readLine = new String();
                    BufferedReader responseReader = new BufferedReader(new InputStreamReader(in1, ENCODING));
                    while ((readLine = responseReader.readLine()) != null) {
                        sb.append(readLine).append("\n");
                    }
                    responseReader.close();
                }
                catch (Exception e1) {
                    e1.printStackTrace();
                }
            } else {
                System.out.println("error++");
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return sb.toString();
    }

    public static String sendGet(String url, Map<String, Object> params) {
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Accept", "application/json, text/plain, */*");
        headers.put("Content-Type", "application/json");
        try {
            headers.put("Authorization", GenToken.genApiToken());
        }
        catch (UnsupportedEncodingException | InvalidKeyException | NoSuchAlgorithmException e) {
            log.info("gen ontnet api token error,error msg:{}", (Object)e.getMessage());
            e.printStackTrace();
        }
        return HttpClientUtil.sendGet(url, params, headers, ENCODING);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String sendPost(String url) {
        log.info("\u8fdb\u5165post\u8bf7\u6c42\u65b9\u6cd5...");
        log.info("\u8bf7\u6c42\u5165\u53c2\uff1aURL= " + url);
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("content-type", "application/json");
        log.info("\u8bf7\u6c42\u5165\u53c2\uff1aheaders=" + JSONObject.toJSONString(headers));
        String resultJson = null;
        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost();
        try {
            CloseableHttpResponse response;
            int status;
            httpPost.setURI(new URI(url));
            if (headers != null) {
                BasicHeader[] allHeader = new BasicHeader[headers.size()];
                int i = 0;
                for (Map.Entry entry : headers.entrySet()) {
                    allHeader[i] = new BasicHeader((String)entry.getKey(), (String)entry.getValue());
                    ++i;
                }
                httpPost.setHeaders((Header[])allHeader);
            }
            if ((status = (response = client.execute((HttpUriRequest)httpPost)).getStatusLine().getStatusCode()) == 200) {
                resultJson = EntityUtils.toString((HttpEntity)response.getEntity(), (String)ENCODING);
            } else {
                log.error("\u54cd\u5e94\u5931\u8d25\uff0c\u72b6\u6001\u7801\uff1a" + status);
            }
        }
        catch (Exception e) {
            log.error("\u53d1\u9001post\u8bf7\u6c42\u5931\u8d25", (Throwable)e);
        }
        finally {
            httpPost.releaseConnection();
        }
        return resultJson;
    }

    public static String getUrlData(String path) {
        String content = "";
        try {
            int len;
            URL url = new URL(path);
            URLConnection conn = url.openConnection();
            InputStream is = conn.getInputStream();
            ByteArrayOutputStream outStream = new ByteArrayOutputStream();
            byte[] bs = new byte[1024];
            while ((len = is.read(bs)) != -1) {
                outStream.write(bs, 0, len);
            }
            byte[] bb = outStream.toByteArray();
            content = new String(bb);
            is.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }
}

