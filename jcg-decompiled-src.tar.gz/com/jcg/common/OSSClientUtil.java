/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.aliyun.oss.OSS
 *  com.aliyun.oss.OSSClientBuilder
 *  com.aliyun.oss.model.ListObjectsV2Result
 *  com.aliyun.oss.model.OSSObjectSummary
 *  com.aliyun.oss.model.PutObjectRequest
 *  com.aliyun.oss.model.PutObjectResult
 */
package com.jcg.common;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.ListObjectsV2Result;
import com.aliyun.oss.model.OSSObjectSummary;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyun.oss.model.PutObjectResult;
import com.jcg.common.ConstantsProperties;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class OSSClientUtil {
    static String ossUrl = ConstantsProperties.getProperty("ALIYUN_OSS_URL").trim();
    static String endpoint = ConstantsProperties.getProperty("ALIYUN_OSS_ENDPOINT").trim();
    static String accessKeyId = ConstantsProperties.getProperty("ALIYUN_OSS_ACCESSKEYID").trim();
    static String accessKeySecret = ConstantsProperties.getProperty("ALIYUN_OSS_ACCESSKEYSECRET").trim();
    static String bucketName = ConstantsProperties.getProperty("ALIYUN_OSS_BUCKET_NAME").trim();

    public static OSS getOssClient() {
        return new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
    }

    public static Collection<File> listFile(String prefix) {
        ArrayList<File> listFile = new ArrayList<File>();
        OSS ossClient = OSSClientUtil.getOssClient();
        ListObjectsV2Result listResult = ossClient.listObjectsV2(bucketName, prefix);
        List dataList = listResult.getObjectSummaries();
        for (OSSObjectSummary elementData : dataList) {
            listFile.add(new File(ossUrl + elementData.getKey()));
        }
        return listFile;
    }

    public static String putObject(String uploadPath, InputStream input) {
        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
        String objectName = uploadPath;
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, objectName, input);
        PutObjectResult putResult = ossClient.putObject(putObjectRequest);
        ossClient.shutdown();
        return ossUrl + objectName;
    }

    public static void deleteObject(String uploadPath) {
        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
        String objectName = uploadPath;
        ossClient.deleteObject(bucketName, objectName);
        ossClient.shutdown();
    }
}

