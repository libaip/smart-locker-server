/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.zxing.BarcodeFormat
 *  com.google.zxing.EncodeHintType
 *  com.google.zxing.MultiFormatWriter
 *  com.google.zxing.WriterException
 *  com.google.zxing.common.BitMatrix
 *  com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
 *  com.jcg.common.model.XcbStringUtils
 *  net.coobird.thumbnailator.Thumbnails
 */
package com.jcg.common;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.jcg.common.OSSClientUtil;
import com.jcg.common.model.XcbStringUtils;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import net.coobird.thumbnailator.Thumbnails;

public class QRCodeKit {
    private static final int IMAGE_WIDTH = 220;
    private static final int IMAGE_HEIGHT = 220;
    private static final int IMAGE_HALF_WIDTH = 110;
    private static final int FRAME_WIDTH = 2;
    private static MultiFormatWriter mutiWriter = new MultiFormatWriter();

    public static int encode(String content, int width, int height, String srcImagePath, String qrCodePath, String drawWord) {
        int stateInt = 1;
        try {
            if (XcbStringUtils.isNullOrBlank((Object)drawWord)) {
                BufferedImage bi = QRCodeKit.genBarcode(content, width, height, srcImagePath);
                ByteArrayOutputStream bs = new ByteArrayOutputStream();
                ImageOutputStream imOut = ImageIO.createImageOutputStream(bs);
                ImageIO.write((RenderedImage)bi, "jpg", imOut);
                ByteArrayInputStream inputStream = new ByteArrayInputStream(bs.toByteArray());
                OSSClientUtil.putObject(qrCodePath, inputStream);
            } else {
                BufferedImage bi = new BufferedImage(width, height, 1);
                BufferedImage imageBuf = QRCodeKit.genBarcode(content, width, height, srcImagePath);
                Graphics2D g = bi.createGraphics();
                g.drawImage(imageBuf, 0, 0, width, height, null);
                Font font = null;
                font = qrCodePath.indexOf("recharge") != -1 ? new Font("\u5b8b\u4f53", 1, 60) : new Font("Arial", 1, 60);
                g.setColor(new Color(0, 0, 0));
                g.setFont(font);
                g.setBackground(Color.WHITE);
                g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (qrCodePath.indexOf("recharge") != -1) {
                    int y;
                    int x;
                    String[] drawWordArr = drawWord.split(":");
                    if (drawWordArr[0].length() < 3) {
                        x = 350;
                        y = 870;
                        int rectX = 349;
                        int rectY = 870;
                        g.clearRect(rectX, rectY - 50, 292, 60);
                        g.drawString(drawWord, x, y);
                    } else {
                        x = 330;
                        y = 870;
                        int rectX = 329;
                        int rectY = 870;
                        g.clearRect(rectX, rectY - 50, 355, 60);
                        g.drawString(drawWord, x, y);
                    }
                } else {
                    int x = 371;
                    int y = 870;
                    int rectX = 370;
                    int rectY = 870;
                    g.clearRect(rectX, rectY - 50, 273, 58);
                    g.drawString(drawWord, x, y);
                }
                g.dispose();
                ByteArrayOutputStream bs = new ByteArrayOutputStream();
                ImageOutputStream imOut = ImageIO.createImageOutputStream(bs);
                ImageIO.write((RenderedImage)bi, "jpg", imOut);
                ByteArrayInputStream inputStream = new ByteArrayInputStream(bs.toByteArray());
                OSSClientUtil.putObject(qrCodePath, inputStream);
            }
        }
        catch (IOException e) {
            stateInt = 0;
            e.printStackTrace();
        }
        catch (WriterException e) {
            stateInt = 0;
            e.printStackTrace();
        }
        return stateInt;
    }

    private static BufferedImage genBarcode(String content, int width, int height, String srcImagePath) throws WriterException, IOException {
        BufferedImage scaleImage = QRCodeKit.scale(srcImagePath, 220, 220, true);
        int[][] srcPixels = new int[220][220];
        for (int i = 0; i < scaleImage.getWidth(); ++i) {
            for (int j = 0; j < scaleImage.getHeight(); ++j) {
                srcPixels[i][j] = scaleImage.getRGB(i, j);
            }
        }
        HashMap<EncodeHintType, Object> hint = new HashMap<EncodeHintType, Object>();
        hint.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hint.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        hint.put(EncodeHintType.MARGIN, 3);
        BitMatrix matrix = mutiWriter.encode(content, BarcodeFormat.QR_CODE, width, height, hint);
        int halfW = matrix.getWidth() / 2;
        int halfH = matrix.getHeight() / 2;
        int[] pixels = new int[width * height];
        for (int y = 0; y < matrix.getHeight(); ++y) {
            for (int x = 0; x < matrix.getWidth(); ++x) {
                if (x > halfW - 110 && x < halfW + 110 && y > halfH - 110 && y < halfH + 110) {
                    pixels[y * width + x] = srcPixels[x - halfW + 110][y - halfH + 110];
                    continue;
                }
                if (x > halfW - 110 - 2 && x < halfW - 110 + 2 && y > halfH - 110 - 2 && y < halfH + 110 + 2 || x > halfW + 110 - 2 && x < halfW + 110 + 2 && y > halfW - 110 - 2 && y < halfH + 110 + 2 || x > halfW - 110 - 2 && x < halfW + 110 + 2 && y > halfH - 110 - 2 && y < halfH - 110 + 2 || x > halfW - 110 - 2 && x < halfW + 110 + 2 && y > halfH + 110 - 2 && y < halfH + 110 + 2) {
                    pixels[y * width + x] = 0xFFFFFFF;
                    continue;
                }
                int num1 = (int)(40.0 - 37.0 / (double)matrix.getHeight() * (double)(y + 1));
                int num2 = (int)(125.0 - 93.0 / (double)matrix.getHeight() * (double)(y + 1));
                int num3 = (int)(142.0 - 55.0 / (double)matrix.getHeight() * (double)(y + 1));
                Color color = new Color(num1, num2, num3);
                int colorInt = color.getRGB();
                pixels[y * width + x] = matrix.get(x, y) ? -16777216 : 0xFFFFFF;
            }
        }
        BufferedImage image = new BufferedImage(width, height, 1);
        image.getRaster().setDataElements(0, 0, width, height, pixels);
        return image;
    }

    private static BufferedImage scale(String srcImageFile, int height, int width, boolean hasFiller) throws IOException {
        double ratio = 0.0;
        File file = new File(srcImageFile);
        BufferedImage srcImage = Thumbnails.of((File[])new File[]{file}).size(220, 220).outputQuality(1.0f).asBufferedImage();
        return srcImage;
    }

    public static void main(String[] args) throws UnsupportedEncodingException {
        String filePath = "E:/project/projSpace/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/xcbweb-agent/resources/img/netpic/agent/1/netpoint_1/device_1/";
        File file = new File(filePath);
        if (!file.exists()) {
            file.mkdirs();
        }
    }
}

