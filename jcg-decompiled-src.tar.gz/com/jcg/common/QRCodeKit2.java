/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.zxing.BarcodeFormat
 *  com.google.zxing.EncodeHintType
 *  com.google.zxing.MultiFormatWriter
 *  com.google.zxing.NotFoundException
 *  com.google.zxing.WriterException
 *  com.google.zxing.common.BitMatrix
 *  com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
 *  org.apache.commons.codec.binary.Base64
 *  org.apache.commons.codec.binary.Base64OutputStream
 */
package com.jcg.common;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.NotFoundException;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.jcg.common.OSSClientUtil;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageOutputStream;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Base64OutputStream;

public class QRCodeKit2 {
    public static final String QRCODE_DEFAULT_CHARSET = "UTF-8";
    public static final int QRCODE_DEFAULT_HEIGHT = 300;
    public static final int QRCODE_DEFAULT_WIDTH = 300;
    private static final int BLACK = -16777216;
    private static final int WHITE = -1;

    public static void main(String[] args) throws IOException, NotFoundException {
    }

    public static int encode(String content, String qrCodePath, int width, int height) {
        int result = 1;
        try {
            BufferedImage bi = QRCodeKit2.createQRCode(content, width, height);
            ByteArrayOutputStream bs = new ByteArrayOutputStream();
            ImageOutputStream imOut = ImageIO.createImageOutputStream(bs);
            ImageIO.write((RenderedImage)bi, "jpg", imOut);
            ByteArrayInputStream inputStream = new ByteArrayInputStream(bs.toByteArray());
            OSSClientUtil.putObject(qrCodePath, inputStream);
        }
        catch (Exception e) {
            result = 0;
            e.printStackTrace();
        }
        return result;
    }

    public static BufferedImage createQRCode(String data) {
        return QRCodeKit2.createQRCode(data, 300, 300);
    }

    public static BufferedImage createQRCode(String data, int width, int height) {
        return QRCodeKit2.createQRCode(data, QRCODE_DEFAULT_CHARSET, width, height);
    }

    public static BufferedImage createQRCode(String data, String charset, int width, int height) {
        HashMap<EncodeHintType, Object> hint = new HashMap<EncodeHintType, Object>();
        hint.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        hint.put(EncodeHintType.CHARACTER_SET, charset);
        return QRCodeKit2.createQRCode(data, charset, hint, width, height);
    }

    public static BufferedImage createQRCode(String data, String charset, Map<EncodeHintType, ?> hint, int width, int height) {
        try {
            BitMatrix matrix = new MultiFormatWriter().encode(new String(data.getBytes(charset), charset), BarcodeFormat.QR_CODE, width, height, hint);
            return QRCodeKit2.toBufferedImage(matrix);
        }
        catch (WriterException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static BufferedImage toBufferedImage(BitMatrix matrix) {
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        BufferedImage image = new BufferedImage(width, height, 1);
        for (int x = 0; x < width; ++x) {
            for (int y = 0; y < height; ++y) {
                image.setRGB(x, y, matrix.get(x, y) ? -16777216 : -1);
            }
        }
        return image;
    }

    public static BufferedImage createQRCodeWithLogo(String data, File logoFile) {
        return QRCodeKit2.createQRCodeWithLogo(data, 300, 300, logoFile);
    }

    public static BufferedImage createQRCodeWithLogo(String data, int width, int height, File logoFile) {
        return QRCodeKit2.createQRCodeWithLogo(data, QRCODE_DEFAULT_CHARSET, width, height, logoFile);
    }

    public static BufferedImage createQRCodeWithLogo(String data, String charset, int width, int height, File logoFile) {
        HashMap<EncodeHintType, Object> hint = new HashMap<EncodeHintType, Object>();
        hint.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        hint.put(EncodeHintType.CHARACTER_SET, charset);
        hint.put(EncodeHintType.MARGIN, 2);
        return QRCodeKit2.createQRCodeWithLogo(data, charset, hint, width, height, logoFile);
    }

    public static BufferedImage createQRCodeWithLogo(String data, String charset, Map<EncodeHintType, ?> hint, int width, int height, File logoFile) {
        try {
            BufferedImage qrcode = QRCodeKit2.createQRCode(data, charset, hint, width, height);
            BufferedImage logo = ImageIO.read(logoFile);
            BufferedImage combined = new BufferedImage(height, width, 2);
            Graphics2D g = (Graphics2D)combined.getGraphics();
            int logoWidth = logo.getWidth() > qrcode.getWidth() * 2 / 10 ? qrcode.getWidth() * 2 / 10 : logo.getWidth();
            int logoHeight = logo.getHeight() > qrcode.getHeight() * 2 / 10 ? qrcode.getHeight() * 2 / 10 : logo.getHeight();
            int x = Math.round((qrcode.getWidth() - logoWidth) / 2);
            int y = Math.round((qrcode.getHeight() - logoHeight) / 2);
            g.drawImage((Image)qrcode, 0, 0, null);
            g.setComposite(AlphaComposite.getInstance(3, 1.0f));
            g.drawImage(logo, x, y, logoWidth, logoHeight, null);
            g.drawRoundRect(x, y, logoWidth, logoHeight, 15, 15);
            g.setStroke(new BasicStroke(3.0f));
            g.setColor(Color.white);
            g.drawRoundRect(x, y, logoWidth, logoHeight, 15, 15);
            g.dispose();
            logo.flush();
            qrcode.flush();
            return combined;
        }
        catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static String getImageBase64String(BufferedImage image) {
        String result = null;
        try {
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            Base64OutputStream b64 = new Base64OutputStream((OutputStream)os);
            ImageIO.write((RenderedImage)image, "png", (OutputStream)b64);
            result = os.toString(QRCODE_DEFAULT_CHARSET);
        }
        catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        return result;
    }

    public static void convertBase64StringToImage(String base64ImageString, File file) {
        try {
            Base64 d = new Base64();
            byte[] bs = d.decode(base64ImageString);
            FileOutputStream os = new FileOutputStream(file.getAbsolutePath());
            os.write(bs);
            os.close();
        }
        catch (FileNotFoundException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }
}

