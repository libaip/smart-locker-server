/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.aliyuncs.AcsRequest
 *  com.aliyuncs.DefaultAcsClient
 *  com.aliyuncs.dysmsapi.model.v20170525.QuerySendDetailsRequest
 *  com.aliyuncs.dysmsapi.model.v20170525.QuerySendDetailsResponse
 *  com.aliyuncs.dysmsapi.model.v20170525.QuerySendDetailsResponse$SmsSendDetailDTO
 *  com.aliyuncs.dysmsapi.model.v20170525.SendBatchSmsRequest
 *  com.aliyuncs.dysmsapi.model.v20170525.SendBatchSmsResponse
 *  com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest
 *  com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse
 *  com.aliyuncs.exceptions.ClientException
 *  com.aliyuncs.http.MethodType
 *  com.aliyuncs.profile.DefaultProfile
 *  com.aliyuncs.profile.IClientProfile
 *  com.jcg.common.model.XcbStringUtils
 */
package com.jcg.common;

import com.aliyuncs.AcsRequest;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.QuerySendDetailsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.QuerySendDetailsResponse;
import com.aliyuncs.dysmsapi.model.v20170525.SendBatchSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendBatchSmsResponse;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.jcg.common.model.XcbStringUtils;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;

public class SmsUtils {
    public static String product = "Dysmsapi";
    public static String domain = "dysmsapi.aliyuncs.com";
    public static String accessKeyId = "LTAIpruofKdF0IgC";
    public static String accessKeySecret = "HtTXSQW3RKeRWcASkkTHY0IhkzS4YP";

    public static void main(String[] args) {
        try {
            String templateValue = "2018-09-12 \u81f3 2018-09-25 \u767d\u77f3\u6d32\u7f51\u70b9 3\u5143\u6d17\u8f66";
            String setPhoneNumbers = "15818543933,11818543933,123569";
            SendSmsResponse response = SmsUtils.getloginSms("123", "", setPhoneNumbers, "");
            System.out.println("\u77ed\u4fe1\u63a5\u53e3\u8fd4\u56de\u7684\u6570\u636e----------------");
            System.out.println("Code=" + response.getCode());
            System.out.println("Message=" + response.getMessage());
            System.out.println("RequestId=" + response.getRequestId());
            System.out.println("BizId=" + response.getBizId());
            if (response.getCode() != null && response.getCode().equals("OK")) {
                QuerySendDetailsResponse querySendDetailsResponse = SmsUtils.querySendDetails(response.getBizId(), "11818543933");
                System.out.println("\u77ed\u4fe1\u660e\u7ec6\u67e5\u8be2\u63a5\u53e3\u8fd4\u56de\u6570\u636e----------------");
                System.out.println("Code=" + querySendDetailsResponse.getCode());
                System.out.println("Message=" + querySendDetailsResponse.getMessage());
                int i = 0;
                int count = querySendDetailsResponse.getSmsSendDetailDTOs().size();
                for (QuerySendDetailsResponse.SmsSendDetailDTO smsSendDetailDTO : querySendDetailsResponse.getSmsSendDetailDTOs()) {
                    System.out.println("SmsSendDetailDTO[" + i + "]:");
                    System.out.println("Content=" + smsSendDetailDTO.getContent());
                    System.out.println("ErrCode=" + smsSendDetailDTO.getErrCode());
                    System.out.println("OutId=" + smsSendDetailDTO.getOutId());
                    System.out.println("PhoneNum=" + smsSendDetailDTO.getPhoneNum());
                    System.out.println("ReceiveDate=" + smsSendDetailDTO.getReceiveDate());
                    System.out.println("SendDate=" + smsSendDetailDTO.getSendDate());
                    System.out.println("SendStatus=" + smsSendDetailDTO.getSendStatus());
                    System.out.println("Template=" + smsSendDetailDTO.getTemplateCode());
                }
                System.out.println("TotalCount=" + querySendDetailsResponse.getTotalCount());
                System.out.println("RequestId=" + querySendDetailsResponse.getRequestId());
            }
        }
        catch (Exception e) {
            e.toString();
        }
    }

    public static SendSmsResponse getloginSms(String templateValue, String signName, String setPhoneNumbers, String mb_name) throws ClientException {
        DefaultProfile profile = DefaultProfile.getProfile((String)"cn-hangzhou", (String)accessKeyId, (String)accessKeySecret);
        DefaultProfile.addEndpoint((String)"cn-hangzhou", (String)"cn-hangzhou", (String)product, (String)domain);
        DefaultAcsClient acsClient = new DefaultAcsClient((IClientProfile)profile);
        SendSmsRequest request = new SendSmsRequest();
        request.setMethod(MethodType.POST);
        request.setPhoneNumbers(setPhoneNumbers);
        request.setSignName(signName);
        request.setTemplateCode(mb_name);
        if (!XcbStringUtils.isNullOrBlank((Object)templateValue)) {
            request.setTemplateParam("{\"code\":\"" + templateValue + "\"}");
        }
        request.setOutId("yourOutId");
        SendSmsResponse sendSmsResponse = (SendSmsResponse)acsClient.getAcsResponse((AcsRequest)request);
        if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
            System.out.println("\u8bf7\u6c42\u6210\u529f");
        } else {
            System.out.println("\u8bf7\u6c42\u5931\u8d25");
        }
        return sendSmsResponse;
    }

    public static SendSmsResponse sendSms(Map<String, String> contentMap, String setPhoneNumbers, String smsId) throws ClientException, InterruptedException {
        System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
        System.setProperty("sun.net.client.defaultReadTimeout", "10000");
        DefaultProfile profile = DefaultProfile.getProfile((String)"cn-hangzhou", (String)accessKeyId, (String)accessKeySecret);
        DefaultProfile.addEndpoint((String)"cn-hangzhou", (String)"cn-hangzhou", (String)product, (String)domain);
        DefaultAcsClient acsClient = new DefaultAcsClient((IClientProfile)profile);
        SendSmsRequest request = new SendSmsRequest();
        request.setMethod(MethodType.POST);
        request.setPhoneNumbers(setPhoneNumbers);
        request.setSignName("\u6d17\u4e50\u6d3e\u79d1\u6280");
        request.setTemplateCode(smsId);
        Set<String> set = contentMap.keySet();
        StringBuffer sb = new StringBuffer();
        sb.append("{");
        for (String contentParam : set) {
            String contentValue = contentMap.get(contentParam);
            sb.append("\"");
            sb.append(contentParam);
            sb.append("\":\"");
            sb.append(contentValue);
            sb.append("\"");
            sb.append(",");
        }
        sb.append("}");
        int index = sb.lastIndexOf(",");
        System.out.println("++++++++++++" + sb.substring(0, index) + sb.substring(index + 1, sb.length()));
        request.setTemplateParam(sb.substring(0, index) + sb.substring(index + 1, sb.length()));
        request.setOutId("yourOutId");
        SendSmsResponse sendSmsResponse = (SendSmsResponse)acsClient.getAcsResponse((AcsRequest)request);
        System.out.println(sendSmsResponse.getMessage());
        Thread.sleep(3000L);
        if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
            System.out.println("\u8bf7\u6c42\u6210\u529f");
        } else {
            System.out.println("\u8bf7\u6c42\u5931\u8d25");
        }
        return sendSmsResponse;
    }

    public static void sendSmsPatch() throws ClientException {
        DefaultProfile profile = DefaultProfile.getProfile((String)"cn-hangzhou", (String)accessKeyId, (String)accessKeySecret);
        DefaultProfile.addEndpoint((String)"cn-hangzhou", (String)"cn-hangzhou", (String)product, (String)domain);
        DefaultAcsClient acsClient = new DefaultAcsClient((IClientProfile)profile);
        SendBatchSmsRequest request = new SendBatchSmsRequest();
        request.setMethod(MethodType.POST);
        request.setPhoneNumberJson("[\"1500000000\",\"1500000001\"]");
        request.setSignNameJson("[\"\u4e91\u901a\u4fe1\",\"\u4e91\u901a\u4fe1\"]");
        request.setTemplateCode("SMS_1000000");
        request.setTemplateParamJson("[{\"name\":\"Tom\", \"code\":\"123\"},{\"name\":\"Jack\", \"code\":\"456\"}]");
        SendBatchSmsResponse sendSmsResponse = (SendBatchSmsResponse)acsClient.getAcsResponse((AcsRequest)request);
        if (sendSmsResponse.getCode() == null || sendSmsResponse.getCode().equals("OK")) {
            // empty if block
        }
    }

    public static QuerySendDetailsResponse querySendDetails(String bizId, String setPhoneNumbers) throws ClientException {
        System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
        System.setProperty("sun.net.client.defaultReadTimeout", "10000");
        DefaultProfile profile = DefaultProfile.getProfile((String)"cn-hangzhou", (String)accessKeyId, (String)accessKeySecret);
        DefaultProfile.addEndpoint((String)"cn-hangzhou", (String)"cn-hangzhou", (String)product, (String)domain);
        DefaultAcsClient acsClient = new DefaultAcsClient((IClientProfile)profile);
        QuerySendDetailsRequest request = new QuerySendDetailsRequest();
        request.setPhoneNumber(setPhoneNumbers);
        SimpleDateFormat ft = new SimpleDateFormat("yyyyMMdd");
        request.setSendDate(ft.format(new Date()));
        request.setPageSize(Long.valueOf(10L));
        request.setCurrentPage(Long.valueOf(1L));
        QuerySendDetailsResponse querySendDetailsResponse = (QuerySendDetailsResponse)acsClient.getAcsResponse((AcsRequest)request);
        return querySendDetailsResponse;
    }
}

