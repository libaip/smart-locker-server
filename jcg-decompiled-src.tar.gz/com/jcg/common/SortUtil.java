/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 */
package com.jcg.common;

import com.jcg.agent.model.Tb_device_box;
import java.util.Comparator;
import java.util.List;

public class SortUtil {
    public static void SortDeviceBox(List<Tb_device_box> list) {
        list.sort(Comparator.comparing(Tb_device_box::getSr_recommend_time));
    }
}

