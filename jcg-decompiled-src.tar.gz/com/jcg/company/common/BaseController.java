/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  javax.servlet.http.HttpServletRequest
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.crypto.password.StandardPasswordEncoder
 *  org.springframework.web.bind.annotation.ExceptionHandler
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.common;

import com.jcg.common.model.BusinessException;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

public class BaseController {
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    @Autowired
    public StandardPasswordEncoder standardPasswordEncoder;
    public static int count = 1;

    @ExceptionHandler
    @ResponseBody
    public Map<String, Object> exp(HttpServletRequest request, Exception ex) {
        String error_str = "";
        HashMap<String, Object> ret = new HashMap<String, Object>();
        if (ex instanceof BusinessException) {
            BusinessException be = (BusinessException)ex;
            error_str = be.getMessage();
            this.log.error(" \u529f\u80fd\u7801\uff1a " + be.getActionCode() + " \u9519\u8bef\u4fe1\u606f " + XcbStringUtils.exceptionToString((Exception)be));
        } else {
            error_str = "\u7cfb\u7edf\u9519\u8bef\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458\uff01";
            this.log.error(XcbStringUtils.exceptionToString((Exception)ex));
        }
        ret.put(XcbConstantValue.MSG, error_str);
        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        ret.put(XcbConstantValue.DATA, XcbConstantValue.DEFAULT_STR);
        return ret;
    }

    public static synchronized String getVoucherNum() {
        int temp;
        String voucherNumStr = XcbDateUtil.formatDate((Date)new Date(), (String)"yyyyMMddHHmmss");
        String voucherNum = null;
        ++count;
        if ((count %= 999) == 0) {
            count = 1;
        }
        voucherNum = (temp = count) < 10 ? voucherNumStr + "000" + temp : (temp >= 10 && temp < 100 ? voucherNumStr + "00" + temp : (temp >= 100 && temp < 1000 ? voucherNumStr + "0" + temp : voucherNumStr + temp));
        return voucherNum;
    }
}

