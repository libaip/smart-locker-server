/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.company.common;

public class Const {
    public static final String MSG_CODE_SUCCESS = "000000";
    public static final String MSG_CODE_FAIL_SERVICE = "100001";
    public static final String MSG_CODE_FAIL_DAO = "100002";
    public static final String MSG_CODE_TOKEN_INVALID = "200001";
    public static final String MSG_CODE_REQUEST_FORBIDDEN = "200002";
}

