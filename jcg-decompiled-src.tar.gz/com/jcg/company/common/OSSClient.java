/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.aliyun.oss.OSS
 *  com.aliyun.oss.OSSClientBuilder
 *  com.aliyun.oss.model.ListObjectsV2Result
 *  com.aliyun.oss.model.OSSObject
 *  com.aliyun.oss.model.OSSObjectSummary
 */
package com.jcg.company.common;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.ListObjectsV2Result;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.OSSObjectSummary;
import com.jcg.company.common.ConfigProperties;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class OSSClient {
    static String ossUrl = ConfigProperties.getProperty("ALIYUN_OSS_URL").trim();
    static String endpoint = ConfigProperties.getProperty("ALIYUN_OSS_ENDPOINT").trim();
    static String accessKeyId = ConfigProperties.getProperty("ALIYUN_OSS_ACCESSKEYID").trim();
    static String accessKeySecret = ConfigProperties.getProperty("ALIYUN_OSS_ACCESSKEYSECRET").trim();
    static String bucketName = ConfigProperties.getProperty("ALIYUN_OSS_BUCKET_NAME").trim();

    public static OSS getOssClient() {
        return new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
    }

    public static OSSObject getObject(String objectName) {
        OSS ossClient = OSSClient.getOssClient();
        OSSObject ossObject = ossClient.getObject(bucketName, objectName);
        return ossObject;
    }

    public static Collection<File> listFile(String prefix) {
        ArrayList<File> listFile = new ArrayList<File>();
        OSS ossClient = OSSClient.getOssClient();
        ListObjectsV2Result listResult = ossClient.listObjectsV2(bucketName, prefix);
        List dataList = listResult.getObjectSummaries();
        for (OSSObjectSummary elementData : dataList) {
            listFile.add(new File(ossUrl + elementData.getKey()));
        }
        return listFile;
    }
}

