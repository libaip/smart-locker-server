/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.XcbStringUtils
 */
package com.jcg.company.common;

import com.jcg.common.model.XcbStringUtils;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class PromptProperties {
    private static String filePath = "properties/prompt.properties";
    private static Map<String, String> propertyMap;

    public static String getProperty(String name) {
        return propertyMap.get(name);
    }

    public static String getProperty(String name, Object ... params) {
        String message = XcbStringUtils.getObjtoString((Object)propertyMap.get(name));
        MessageFormat form = new MessageFormat(message);
        String propertiesValue = form.format(params);
        return propertiesValue;
    }

    public static void main(String[] args) {
        System.out.println(PromptProperties.getProperty("coupon.stream.LY.fail", 1));
    }

    static {
        Properties props = new Properties();
        propertyMap = new HashMap<String, String>();
        try {
            InputStream in = PromptProperties.class.getClassLoader().getResourceAsStream(filePath);
            props.load(in);
            Enumeration<?> en = props.propertyNames();
            while (en.hasMoreElements()) {
                String key = (String)en.nextElement();
                String value = props.getProperty(key);
                propertyMap.put(key, value);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}

