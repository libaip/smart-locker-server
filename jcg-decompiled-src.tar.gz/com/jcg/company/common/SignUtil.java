/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.fasterxml.jackson.databind.ObjectMapper
 *  javax.servlet.http.HttpServletRequest
 *  org.apache.commons.codec.digest.DigestUtils
 *  org.apache.commons.lang3.StringUtils
 */
package com.jcg.company.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

public class SignUtil {
    public static String DEFAULT_SECRET_KEY = "ISCAS123";
    private static String TIME_STAMP_KEY = "timeStamp";
    private static String SIGN_KEY = "sign";
    private static Long EXPIRE_TIME = 300000L;

    public static Map getSignature(Object param, String secretKey) {
        Map params;
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String jsonStr = objectMapper.writeValueAsString(param);
            params = (Map)objectMapper.readValue(jsonStr, Map.class);
        }
        catch (Exception e) {
            throw new RuntimeException("\u751f\u6210\u7b7e\u540d\uff1a\u8f6c\u6362json\u5931\u8d25");
        }
        if (params.get(TIME_STAMP_KEY) == null) {
            params.put(TIME_STAMP_KEY, System.currentTimeMillis());
        }
        Set keysSet = params.keySet();
        Object[] keys = keysSet.toArray();
        Arrays.sort(keys);
        String temp = Arrays.stream(keys).map(key -> key + "=" + (!params.containsKey(key) ? "" : params.get(key))).collect(Collectors.joining("&"));
        String sign = DigestUtils.sha256Hex((String)(temp + secretKey)).toUpperCase();
        params.put(SIGN_KEY, sign);
        return params;
    }

    public static boolean checkSignature(HttpServletRequest request, String secretKey) throws IOException {
        SortedMap<String, Object> param = SignUtil.getAllParams(request);
        String sign = (String)param.get(SIGN_KEY);
        Long start = SignUtil.convertTimestamp(param.get(TIME_STAMP_KEY));
        long now = System.currentTimeMillis();
        if (start == null || now - start > EXPIRE_TIME || start - now > 0L) {
            return false;
        }
        if (StringUtils.isBlank((CharSequence)sign)) {
            return false;
        }
        param.remove(SIGN_KEY);
        Map paramMap = SignUtil.getSignature(param, secretKey);
        String signature = (String)paramMap.get("sign");
        return sign.equals(signature);
    }

    private static Long convertTimestamp(Object timestampObj) {
        return timestampObj != null ? Long.valueOf(Long.parseLong(timestampObj.toString())) : null;
    }

    public static SortedMap<String, Object> getAllParams(HttpServletRequest request) throws IOException {
        TreeMap<String, Object> result = new TreeMap<String, Object>();
        return result;
    }
}

