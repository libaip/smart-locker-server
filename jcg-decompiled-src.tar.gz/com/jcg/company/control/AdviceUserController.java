/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_advice_user
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_advice_user;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.AdviceUserServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/adviceUser"})
public class AdviceUserController
extends BaseController {
    @Autowired
    private AdviceUserServiceImpl adviceUserService;

    @RequestMapping(value={"/findAdviceUserByParam"})
    @ResponseBody
    public Map<String, Object> findAdviceUserByParam(HttpServletRequest request, Tb_advice_user advice, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.adviceUserService.findAdviceUserByParam(identifier, advice, page);
        return result_map;
    }

    @RequestMapping(value={"/updateAdviceUser"})
    @ResponseBody
    public Map<String, Object> updateAdviceUser(HttpServletRequest request, Tb_advice_user adviceUser) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.adviceUserService.updateAdviceUser(identifier, adviceUser);
        return result_map;
    }
}

