/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_agent_way
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.alibaba.fastjson.JSONObject;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_agent_way;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.AgentServiceImpl;
import com.jcg.company.service.WebServiceImpl;
import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/agent"})
public class AgentController
extends BaseController {
    @Autowired
    private AgentServiceImpl agentService;
    @Autowired
    private WebServiceImpl webService;

    @RequestMapping(value={"/createAgent"})
    @ResponseBody
    public Map<String, Object> createAgent(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> ret = this.agentService.createAgent(identifier, agent);
        int result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            Tb_agent_way agentWay = new Tb_agent_way();
            agentWay.setSr_user_name(agent.getSr_user_name());
            agentWay.setSr_old_user_name(agent.getSr_user_name());
            agentWay.setSr_way(XcbConstantValue.LOGIN_WAY);
            this.webService.createAgentWay(identifier, agentWay);
        }
        return ret;
    }

    @RequestMapping(value={"/findAgentByParam"})
    @ResponseBody
    public Map<String, Object> findAgentByParam(HttpServletRequest request, Tb_agent agent, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.findAgentByParam(identifier, agent, page);
        return result_map;
    }

    @RequestMapping(value={"/findAgentMoneyByParam"})
    @ResponseBody
    public Map<String, Object> findAgentMoneyByParam(HttpServletRequest request, Tb_agent agent, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.findAgentMoneyByParam(identifier, agent, page);
        return result_map;
    }

    @RequestMapping(value={"/findStaffByParam"})
    @ResponseBody
    public Map<String, Object> findStaffByParam(HttpServletRequest request, Tb_agent agent, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.findStaffByParam(identifier, agent, page);
        return result_map;
    }

    @RequestMapping(value={"/findAgentForShare"})
    @ResponseBody
    public Map<String, Object> findAgentForShare(HttpServletRequest request, Tb_agent agent, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.findAgentForShare(identifier, agent, page);
        return result_map;
    }

    @RequestMapping(value={"/updateAgentById"})
    @ResponseBody
    public Map<String, Object> updateAgentById(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.agentService.updateAgentById(identifier, agent);
        int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            Tb_agent oldAgent = (Tb_agent)result_map.get(XcbConstantValue.DATA);
            Tb_agent_way agentWay = new Tb_agent_way();
            agentWay.setSr_user_name(agent.getSr_user_name());
            agentWay.setSr_old_user_name(oldAgent.getSr_old_user_name());
            agentWay.setSr_way(XcbConstantValue.LOGIN_WAY);
            this.webService.createAgentWay(identifier, agentWay);
        }
        return result_map;
    }

    @RequestMapping(value={"/updateAgentAd"})
    @ResponseBody
    public Map<String, Object> updateAgentAd(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.agentService.updateAgentAd(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/updateAgentWay"})
    @ResponseBody
    public Map<String, Object> updateAgentWay(HttpServletRequest request) throws Exception {
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        HashMap<String, Object> result_map = new HashMap();
        String sr_user_name = "";
        String sr_way = "";
        BufferedReader bufferReader = request.getReader();
        StringBuffer sb = new StringBuffer();
        String line = "";
        while ((line = bufferReader.readLine()) != null) {
            sb.append(line);
        }
        String postData = sb.toString();
        if (!XcbStringUtils.isNullOrBlank((Object)postData)) {
            JSONObject json = JSONObject.parseObject((String)postData);
            sr_user_name = (String)json.get("sr_user_name");
            sr_way = (String)json.get("sr_way");
        }
        Tb_agent agent = new Tb_agent();
        agent.setSr_user_name(sr_user_name);
        agent.setSr_way(sr_way);
        result_map = this.agentService.updateAgentWay(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/findAgentById"})
    @ResponseBody
    public Map<String, Object> findAgentById(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.agentService.findAgentById(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/findAllAgentById"})
    @ResponseBody
    public Map<String, Object> findAllAgentById(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.findAllAgentById(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/findUpAgentByParam"})
    @ResponseBody
    public Map<String, Object> findUpAgentByParam(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.findUpAgentByParam(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/updateAgentStatusById"})
    @ResponseBody
    public Map<String, Object> updateAgentStatusById(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.agentService.updateAgentStatusById(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/resetAgentPasswordById"})
    @ResponseBody
    public Map<String, Object> resetAgentPasswordById(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.agentService.resetAgentPasswordById(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/validateAgentUsername"})
    @ResponseBody
    public Map<String, Object> validateAgentUsername(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.agentService.validateAgentUsername(identifier, agent);
        return ret;
    }

    @RequestMapping(value={"/validateDistinctAgent"})
    @ResponseBody
    public Map<String, Object> validateDistinctAgent(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.validateDistinctAgent(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/genCode"})
    @ResponseBody
    public Map<String, Object> genCode(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.genCode(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/findAgentByAreaCode"})
    @ResponseBody
    public Map<String, Object> findAgentByAreaCode(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.agentService.findAgentByAreaCode(identifier, agent);
        return result_map;
    }

    @RequestMapping(value={"/identity_certificate"})
    @ResponseBody
    public Map<String, Object> identity_certificate(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.agentService.identity_certificate(identifier, agent);
        return ret;
    }

    @RequestMapping(value={"/binding"})
    @ResponseBody
    public Map<String, Object> binding(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.agentService.binding(identifier, agent);
        return ret;
    }

    @RequestMapping(value={"/unbinding"})
    @ResponseBody
    public Map<String, Object> unbinding(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.agentService.unbinding(identifier, agent);
        return ret;
    }

    @RequestMapping(value={"/bindingCpy"})
    @ResponseBody
    public Map<String, Object> bindingCpy(HttpServletRequest request, Tb_agent agent) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.agentService.bindingCpy(identifier, agent);
        return ret;
    }
}

