/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.agent.model.Tb_agent_way
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbStringUtils
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.alibaba.fastjson.JSONObject;
import com.jcg.agent.model.Tb_agent_way;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.common.BaseController;
import com.jcg.company.service.AgentWayServiceImpl;
import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/agentWay"})
public class AgentWayController
extends BaseController {
    @Autowired
    private AgentWayServiceImpl agentWayService;

    @RequestMapping(value={"/findAgentWayByName"})
    @ResponseBody
    public Map<String, Object> findAgentWayByName(HttpServletRequest request) throws Exception {
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        String sr_user_name = "";
        BufferedReader bufferReader = request.getReader();
        StringBuffer sb = new StringBuffer();
        String line = "";
        while ((line = bufferReader.readLine()) != null) {
            sb.append(line);
        }
        String postData = sb.toString();
        if (!XcbStringUtils.isNullOrBlank((Object)postData)) {
            JSONObject json = JSONObject.parseObject((String)postData);
            sr_user_name = (String)json.get("sr_user_name");
        }
        Tb_agent_way agentWay = new Tb_agent_way();
        agentWay.setSr_user_name(sr_user_name);
        Map<String, Object> result_map = this.agentWayService.findAgentWayByName(identifier, agentWay);
        return result_map;
    }

    @RequestMapping(value={"/updateAgentWayByWeb"})
    @ResponseBody
    public Map<String, Object> updateAgentWayByWeb(HttpServletRequest request) throws Exception {
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        HashMap<String, Object> result_map = new HashMap();
        String sr_old_user_name = "";
        String sr_user_name = "";
        String sr_way = "";
        String sr_remark = "";
        BufferedReader bufferReader = request.getReader();
        StringBuffer sb = new StringBuffer();
        String line = "";
        while ((line = bufferReader.readLine()) != null) {
            sb.append(line);
        }
        String postData = sb.toString();
        if (!XcbStringUtils.isNullOrBlank((Object)postData)) {
            JSONObject json = JSONObject.parseObject((String)postData);
            sr_user_name = (String)json.get("sr_user_name");
            sr_way = (String)json.get("sr_way");
            sr_remark = (String)json.get("sr_remark");
            sr_old_user_name = (String)json.get("sr_old_user_name");
        }
        Tb_agent_way agentWay = new Tb_agent_way();
        agentWay.setSr_user_name(sr_user_name);
        agentWay.setSr_old_user_name(sr_old_user_name);
        agentWay.setSr_way(sr_way);
        agentWay.setSr_remark(sr_remark);
        result_map = this.agentWayService.updateAgentWayByName(identifier, agentWay);
        return result_map;
    }
}

