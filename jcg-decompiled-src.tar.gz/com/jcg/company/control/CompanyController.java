/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.CompanyServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/company"})
public class CompanyController
extends BaseController {
    @Autowired
    private CompanyServiceImpl companyService;

    @RequestMapping(value={"/findCompanyByParam"})
    @ResponseBody
    public Map<String, Object> findCompanyByParam(HttpServletRequest request, Tb_company company, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.companyService.findCompanyByParam(identifier, company, c_user, page);
        return result_map;
    }

    @RequestMapping(value={"/createCompany"})
    @ResponseBody
    public Map<String, Object> createCompany(HttpServletRequest request, Tb_company company) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        Map<String, Object> result_map = this.companyService.createCompany(identifier, company, c_user);
        return result_map;
    }

    @RequestMapping(value={"/updateById"})
    @ResponseBody
    public Map<String, Object> updateById(HttpServletRequest request, Tb_company company) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.companyService.updateById(identifier, company);
        return result_map;
    }

    @RequestMapping(value={"/getV3Serialno"})
    @ResponseBody
    public Map<String, Object> getV3Serialno(HttpServletRequest request, String sr_mchid) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.companyService.getV3Serialno(identifier, sr_mchid);
        return result_map;
    }

    @RequestMapping(value={"/findCompanyById"})
    @ResponseBody
    public Map<String, Object> findCompanyById(HttpServletRequest request, String sd_company_id) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.companyService.findCompanyById(identifier, sd_company_id);
        return result_map;
    }

    @RequestMapping(value={"/findAllCompanyDropDown"})
    @ResponseBody
    public Map<String, Object> findAllCompanyDropDown(HttpServletRequest request, Tb_company company) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.companyService.findAllCompanyDropDown(identifier, company, c_user);
        return result_map;
    }
}

