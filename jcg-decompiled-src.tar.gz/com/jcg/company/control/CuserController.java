/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.security.crypto.password.StandardPasswordEncoder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.CuserServiceImpl;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/cuser"})
public class CuserController
extends BaseController {
    @Autowired
    private StandardPasswordEncoder standardPasswordEncoder;
    @Autowired
    private CuserServiceImpl cuserService;

    @RequestMapping(value={"/createCuser"})
    @ResponseBody
    public Map<String, Object> createCuser(HttpServletRequest request, Tb_cuser cuser) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.cuserService.createCuser(identifier, cuser);
        return ret;
    }

    @RequestMapping(value={"/findCuserById"})
    @ResponseBody
    public Map<String, Object> findCuserById(HttpServletRequest request, String sd_cuser_id) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.cuserService.findCuserById(identifier, sd_cuser_id);
        return result_map;
    }

    @RequestMapping(value={"/findCuserByParam"})
    @ResponseBody
    public Map<String, Object> findCuserByParam(HttpServletRequest request, HttpServletResponse response, Tb_cuser cuser, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.cuserService.findCuserByParam(identifier, cuser, page);
        return result_map;
    }

    @RequestMapping(value={"/updateCuserById"})
    @ResponseBody
    public Map<String, Object> updateCuserById(HttpServletRequest request, Tb_cuser cuser) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.cuserService.updateCuserById(identifier, cuser);
        return result_map;
    }

    @RequestMapping(value={"/updateCuserStsById"})
    @ResponseBody
    public Map<String, Object> updateCuserStsById(HttpServletRequest request, Tb_cuser cuser) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.cuserService.updateCuserStsById(identifier, cuser);
        return result_map;
    }

    @RequestMapping(value={"/updatePassword"})
    @ResponseBody
    public Map<String, Object> updatePassword(HttpServletRequest request, Tb_cuser cuser) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.cuserService.updatePassword(identifier, cuser);
        return result_map;
    }

    @RequestMapping(value={"/validateCuserUsername"})
    @ResponseBody
    public Map<String, Object> validateCuserUsername(HttpServletRequest request, Tb_cuser cuser) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.cuserService.validateCuserUsername(identifier, cuser);
        return result_map;
    }

    @RequestMapping(value={"/validateCuserOldPasswd"})
    @ResponseBody
    public Map<String, Object> validateCuserOldPasswd(HttpServletRequest request, String sd_cuser_id, String oldPasswd) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        HashMap<String, Object> map = new HashMap<String, Object>();
        HashMap<String, Boolean> dataMap = new HashMap<String, Boolean>();
        boolean isSamePasswd = false;
        Map<String, Object> result_map = this.cuserService.findCuserById(identifier, sd_cuser_id);
        if (result_map.get(XcbConstantValue.DATA) != null) {
            Tb_cuser cuser = (Tb_cuser)result_map.get(XcbConstantValue.DATA);
            isSamePasswd = this.standardPasswordEncoder.matches((CharSequence)oldPasswd, cuser.getPassword());
            dataMap.put("isSamePasswd", isSamePasswd);
        }
        map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        map.put(XcbConstantValue.DATA, dataMap);
        map.put(XcbConstantValue.MSG, "");
        return map;
    }

    @RequestMapping(value={"/findUserRolesByUserId"})
    @ResponseBody
    public Map<String, Object> findUserRolesByUserId(HttpServletRequest request, String sd_cuser_id) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.cuserService.findUserRolesByUserId(identifier, sd_cuser_id);
        return ret;
    }

    @RequestMapping(value={"/updateUserRolesByUserId"})
    @ResponseBody
    public Map<String, Object> updateUserRolesByUserId(HttpServletRequest request, String sd_cuser_id, String[] roleArr) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.cuserService.updateUserRolesByUserId(identifier, sd_cuser_id, roleArr);
        return ret;
    }

    @RequestMapping(value={"/findAllCuser"})
    @ResponseBody
    public Map<String, Object> findAllType(HttpServletRequest request) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.cuserService.findAllCuser(identifier);
        return ret;
    }

    @RequestMapping(value={"/resetCuserPasswordById"})
    @ResponseBody
    public Map<String, Object> resetCuserPasswordById(HttpServletRequest request, Tb_cuser cuser) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.cuserService.resetCuserPasswordById(identifier, cuser);
        return result_map;
    }

    @RequestMapping(value={"/sendSms"})
    @ResponseBody
    public Map<String, Object> sendSms(HttpServletRequest request, Tb_cuser cuser) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.cuserService.sendSms(identifier, cuser);
        return result_map;
    }
}

