/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_customer_app
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_customer_app;
import com.jcg.company.service.CustomerAppServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/customerApp"})
public class CustomerAppController
extends BaseController {
    @Autowired
    private CustomerAppServiceImpl customerAppService;

    @RequestMapping(value={"/findCustomerAppByParam"})
    @ResponseBody
    public Map<String, Object> findCustomerAppByParam(HttpServletRequest request, Tb_customer_app customer_app, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        customer_app.setSw_user_id(XcbStringUtils.getObjtoString((Object)c_user.getSd_cuser_id()));
        Map<String, Object> result_map = this.customerAppService.findCustomerAppByParam(identifier, customer_app, page);
        return result_map;
    }

    @RequestMapping(value={"/updateCustomerAppById"})
    @ResponseBody
    public Map<String, Object> updateCustomerAppById(HttpServletRequest request, Tb_customer_app customer_app) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.customerAppService.updateCustomerAppById(identifier, customer_app);
        return result_map;
    }
}

