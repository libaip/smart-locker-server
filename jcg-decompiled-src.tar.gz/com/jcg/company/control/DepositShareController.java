/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_deposit_share
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_deposit_share;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.DepositShareServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/share"})
public class DepositShareController
extends BaseController {
    @Autowired
    DepositShareServiceImpl depositShareService;

    @RequestMapping(value={"/createDepositShare"})
    @ResponseBody
    public Map<String, Object> createDepositShare(HttpServletRequest request, Tb_deposit_share share) throws Exception {
        this.log.debug("DepositShare================\u62bc\u91d1\u590d\u6838");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.depositShareService.createDepositShare(identifier, share);
        return result_map;
    }

    @RequestMapping(value={"/updateDepositShare"})
    @ResponseBody
    public Map<String, Object> updateDepositShare(HttpServletRequest request, Tb_deposit_share share) throws Exception {
        this.log.debug("DepositShare================\u62bc\u91d1\u590d\u6838");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.depositShareService.updateDepositShare(identifier, share);
        return result_map;
    }

    @RequestMapping(value={"/findDepositShareByParam"})
    @ResponseBody
    public Map<String, Object> findDepositShareByParam(HttpServletRequest request, Tb_deposit_share share, Page page) throws Exception {
        this.log.debug("DepositShare================\u62bc\u91d1\u590d\u6838");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.depositShareService.findDepositShareByParam(identifier, share, page);
        return result_map;
    }
}

