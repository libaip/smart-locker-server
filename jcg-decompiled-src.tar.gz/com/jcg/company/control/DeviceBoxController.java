/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.Identifier
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  net.sf.json.JSONArray
 *  net.sf.json.JsonConfig
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.common.model.Identifier;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.DeviceBoxServiceImpl;
import com.jcg.company.service.DeviceCloudServiceImpl;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/deviceBox"})
public class DeviceBoxController
extends BaseController {
    @Autowired
    private DeviceBoxServiceImpl deviceBoxService;
    @Autowired
    private DeviceCloudServiceImpl deviceCloudService;

    @RequestMapping(value={"/createDeviceBox"})
    @ResponseBody
    public Map<String, Object> createDeviceBox(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("DeviceBoxInfo================\u65b0\u5efa\u8bbe\u5907\u683c\u5b50\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceBoxService.createDeviceBox(identifier, deviceBox);
        this.deviceCloudService.refreshApp(identifier, deviceBox.getSw_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/batchCreateBox"})
    @ResponseBody
    public Map<String, Object> batchCreateBox(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("DeviceBoxInfo================\u65b0\u5efa\u8bbe\u5907\u683c\u5b50\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceBoxService.batchCreateBox(identifier, deviceBox);
        this.deviceCloudService.refreshLock(identifier, deviceBox.getSw_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/findDeviceBoxByDeviceId"})
    @ResponseBody
    public Map<String, Object> findDeviceBoxByDeviceId(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceBoxService.findDeviceBoxByDeviceId(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/batchUpdateDeviceBoxById"})
    @ResponseBody
    public Map<String, Object> batchUpdateDeviceBoxById(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceBoxInfo================\u6279\u91cf\u66f4\u65b0\u8bbe\u5907\u683c\u5b50\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceBoxService.batchUpdateDeviceBoxById(identifier, deviceBox);
        this.deviceCloudService.refreshLock(identifier, deviceBox.getSw_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/updateDeviceBoxById"})
    @ResponseBody
    public Map<String, Object> updateDeviceBoxById(HttpServletRequest request, String deviceBoxStrs) throws Exception {
        this.log.debug("deviceBoxInfo================\u66f4\u65b0\u8bbe\u5907\u683c\u5b50\u4fe1\u606f");
        deviceBoxStrs = deviceBoxStrs.replaceAll("&quot;", "\"");
        JSONArray array = JSONArray.fromObject((Object)deviceBoxStrs);
        List deviceBoxs = JSONArray.toList((JSONArray)array, (Object)new Tb_device_box(), (JsonConfig)new JsonConfig());
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceBoxService.updateDeviceBoxById(identifier, deviceBoxs);
        this.deviceCloudService.refreshLock(identifier, ((Tb_device_box)deviceBoxs.get(0)).getSw_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/updateDeviceBox"})
    @ResponseBody
    public Map<String, Object> updateDeviceBox(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_cuser_name());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceBoxService.updateDeviceBox(identifier, deviceBox);
        this.deviceCloudService.refreshLock(identifier, deviceBox.getSw_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/deleteDeviceBox"})
    @ResponseBody
    public Map<String, Object> deleteDeviceBox(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("DeviceBoxInfo================\u5220\u9664\u8bbe\u5907\u683c\u5b50");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceBoxService.deleteDeviceBox(identifier, deviceBox);
        this.deviceCloudService.refreshLock(identifier, deviceBox.getSw_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/batchDeleteDeviceBox"})
    @ResponseBody
    public Map<String, Object> batchDeleteDeviceBox(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("DeviceBoxInfo================\u6279\u91cf\u5220\u9664\u8bbe\u5907\u683c\u5b50");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceBoxService.batchDeleteDeviceBox(identifier, deviceBox);
        this.deviceCloudService.refreshLock(identifier, deviceBox.getSw_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/findBoardList"})
    @ResponseBody
    public Map<String, Object> findBoardList(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceBoxService.findBoardList(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/findBoxListByWeb"})
    @ResponseBody
    public Map<String, Object> findBoxListByWeb(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Identifier identifier = new Identifier();
        Map<String, Object> result_map = this.deviceBoxService.findBoxListByWeb(identifier, deviceBox);
        return result_map;
    }
}

