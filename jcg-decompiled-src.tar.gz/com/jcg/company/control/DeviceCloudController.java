/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.Identifier
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.common.model.Identifier;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.DeviceCloudServiceImpl;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/cloud"})
public class DeviceCloudController
extends BaseController {
    @Autowired
    private DeviceCloudServiceImpl deviceCloudService;

    @RequestMapping(value={"/openLock"})
    @ResponseBody
    public Map<String, Object> openLock(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        result_map = this.deviceCloudService.openLock(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/openLockAll"})
    @ResponseBody
    public Map<String, Object> openLockAll(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        result_map = this.deviceCloudService.openLock(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/openAllLock"})
    @ResponseBody
    public Map<String, Object> openAllLock(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        result_map = this.deviceCloudService.openAllLock(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/getState"})
    @ResponseBody
    public Map<String, Object> getState(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        result_map = this.deviceCloudService.getState(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/readMchid"})
    @ResponseBody
    public Map<String, Object> readMchid(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        result_map = this.deviceCloudService.readMchid(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/getStateAll"})
    @ResponseBody
    public Map<String, Object> getStateAll(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        result_map = this.deviceCloudService.getState(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/updateApp"})
    @ResponseBody
    public Map<String, Object> updateApp(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        result_map = this.deviceCloudService.updateApp(identifier, device);
        return result_map;
    }

    @RequestMapping(value={"/reboot"})
    @ResponseBody
    public Map<String, Object> reboot(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        result_map = this.deviceCloudService.reboot(identifier, device);
        return result_map;
    }

    @RequestMapping(value={"/refreshApp"})
    @ResponseBody
    public Map<String, Object> refreshApp(HttpServletRequest request, String sw_mainboard_id) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        result_map = this.deviceCloudService.refreshApp(identifier, sw_mainboard_id);
        return result_map;
    }

    @RequestMapping(value={"/getCoverPicture"})
    @ResponseBody
    public Map<String, Object> getCoverPicture(HttpServletRequest request, String sw_mainboard_id) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        result_map = this.deviceCloudService.getCoverPicture(identifier, sw_mainboard_id);
        return result_map;
    }

    @RequestMapping(value={"/refreshAll"})
    @ResponseBody
    public Map<String, Object> refreshAll(HttpServletRequest request, Integer sw_netpoint_id) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        result_map = this.deviceCloudService.refreshAll(identifier, sw_netpoint_id);
        return result_map;
    }
}

