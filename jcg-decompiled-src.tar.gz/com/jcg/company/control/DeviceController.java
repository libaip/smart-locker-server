/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_device;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.DeviceCloudServiceImpl;
import com.jcg.company.service.DeviceServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/device"})
public class DeviceController
extends BaseController {
    @Autowired
    private DeviceServiceImpl deviceService;
    @Autowired
    private DeviceCloudServiceImpl deviceCloudService;

    @RequestMapping(value={"/createDevice"})
    @ResponseBody
    public Map<String, Object> createDevice(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_cuser_name());
        identifier.setUserId(c_user.getSd_cuser_id());
        Map<String, Object> result_map = this.deviceService.createDevice(identifier, device);
        return result_map;
    }

    @RequestMapping(value={"/findDeviceByParam"})
    @ResponseBody
    public Map<String, Object> findDeviceByParam(HttpServletRequest request, Tb_device device, Page page) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceService.findDeviceByParam(identifier, device, page);
        return result_map;
    }

    @RequestMapping(value={"/findDeviceDetailById"})
    @ResponseBody
    public Map<String, Object> findDeviceDetailById(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceService.findDeviceDetailById(identifier, device);
        return result_map;
    }

    @RequestMapping(value={"/findDropDownDeviceByAgentId"})
    @ResponseBody
    public Map<String, Object> findDropDownDeviceByAgentId(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceService.findDropDownDeviceByAgentId(identifier, device);
        return result_map;
    }

    @RequestMapping(value={"/updateDeviceStsById"})
    @ResponseBody
    public Map<String, Object> findDropDownDeviceNotRelatedActyByAgentId(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceService.updateDeviceStsById(identifier, device);
        this.deviceCloudService.refreshApp(identifier, device.getSi_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/getSimInfo"})
    @ResponseBody
    public Map<String, Object> getSimInfo(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceCloudService.getSimInfo(identifier, device.getSi_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/updateDeviceById"})
    @ResponseBody
    public Map<String, Object> updateDeviceById(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceService.updateDeviceById(identifier, device);
        this.deviceCloudService.refreshApp(identifier, device.getSi_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/genCode"})
    @ResponseBody
    public Map<String, Object> genCode(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceInfo================\u751f\u6210\u4e8c\u7ef4\u7801");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceService.genCode(identifier, device);
        this.deviceCloudService.refreshApp(identifier, device.getSi_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/validateDeviceMainboard"})
    @ResponseBody
    public Map<String, Object> validateDeviceMainboard(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.deviceService.validateDeviceMainboard(identifier, device);
        return result_map;
    }

    @RequestMapping(value={"/findDeviceByNetpointId"})
    @ResponseBody
    public Map<String, Object> findDeviceByNetpointId(HttpServletRequest request, Tb_device device) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.deviceService.findDeviceByNetpointId(identifier, device);
        return result_map;
    }
}

