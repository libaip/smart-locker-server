/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_fittings
 *  com.jcg.common.model.Identifier
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_device_fittings;
import com.jcg.common.model.Identifier;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.DeviceFittingsServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/fittings"})
public class DeviceFittingsController
extends BaseController {
    @Autowired
    private DeviceFittingsServiceImpl deviceFittingsService;

    @RequestMapping(value={"/createFittings"})
    @ResponseBody
    public Map<String, Object> createFittings(HttpServletRequest request, Tb_device_fittings fittings) throws Exception {
        this.log.debug("DeviceFittings================\u65b0\u5efa\u8bbe\u5907\u914d\u4ef6\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceFittingsService.createFittings(identifier, fittings);
        return result_map;
    }

    @RequestMapping(value={"/findFittingsByBoxId"})
    @ResponseBody
    public Map<String, Object> findFittingsByBoxId(HttpServletRequest request, Tb_device_fittings fittings) throws Exception {
        this.log.debug("DeviceFittings================\u67e5\u8be2\u8bbe\u5907\u914d\u4ef6\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceFittingsService.findFittingsByBoxId(identifier, fittings);
        return result_map;
    }

    @RequestMapping(value={"/findMaxFittings"})
    @ResponseBody
    public Map<String, Object> findMaxFittings(HttpServletRequest request, Tb_device_fittings fittings) throws Exception {
        this.log.debug("DeviceFittings================\u67e5\u8be2\u914d\u4ef6\u6700\u65b0\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceFittingsService.findMaxFittings(identifier, fittings);
        return result_map;
    }

    @RequestMapping(value={"/deleteFittingsById"})
    @ResponseBody
    public Map<String, Object> deleteFittingsById(HttpServletRequest request, Tb_device_fittings fittings) throws Exception {
        this.log.debug("DeviceFittings================\u5220\u9664\u8bbe\u5907\u914d\u4ef6\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceFittingsService.deleteFittingsById(identifier, fittings);
        return result_map;
    }

    @RequestMapping(value={"/updateFittingsById"})
    @ResponseBody
    public Map<String, Object> deleftFittingsById(HttpServletRequest request, Tb_device_fittings fittings) throws Exception {
        this.log.debug("DeviceFittings================\u66f4\u65b0\u8bbe\u5907\u914d\u4ef6\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.deviceFittingsService.updateFittingsById(identifier, fittings);
        return result_map;
    }
}

