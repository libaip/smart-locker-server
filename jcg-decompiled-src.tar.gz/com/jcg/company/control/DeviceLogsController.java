/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_devicelogs
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_devicelogs;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.DeviceLogsServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/deviceLogs"})
public class DeviceLogsController
extends BaseController {
    @Autowired
    private DeviceLogsServiceImpl deviceLogsService;

    @RequestMapping(value={"/findDeviceLogsByParam"})
    @ResponseBody
    public Map<String, Object> findDeviceLogsByParam(HttpServletRequest request, Tb_devicelogs deviceLogs, String dateRange, Page page) throws Exception {
        this.log.debug("deviceLogsInfo================\u8fdb\u5165\u8bbe\u5907\u65e5\u5fd7\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceLogsService.findDeviceLogsByParam(identifier, deviceLogs, dateRange, page);
        return result_map;
    }

    @RequestMapping(value={"/findOffOnlineByNet"})
    @ResponseBody
    public Map<String, Object> findOffOnlineByNet(HttpServletRequest request, Tb_devicelogs deviceLogs, Page page) throws Exception {
        this.log.debug("deviceLogsInfo================\u8fdb\u5165\u8bbe\u5907\u65e5\u5fd7\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.deviceLogsService.findOffOnlineByNet(identifier, deviceLogs, page);
        return result_map;
    }
}

