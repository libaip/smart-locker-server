/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  net.sf.json.JSONArray
 *  net.sf.json.JsonConfig
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_device_package;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.DeviceCloudServiceImpl;
import com.jcg.company.service.DevicePackageServiceImpl;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/devicePackage"})
public class DevicePackageController
extends BaseController {
    @Autowired
    private DevicePackageServiceImpl devicePackageService;
    @Autowired
    private DeviceCloudServiceImpl deviceCloudService;

    @RequestMapping(value={"/findDevicePackageByDeviceId"})
    @ResponseBody
    public Map<String, Object> findDevicePackageById(HttpServletRequest request, Tb_device_package devicePackage, Page page) throws Exception {
        this.log.debug("devicePackageInfo================\u8fdb\u5165\u8bbe\u5907\u5957\u9910\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.devicePackageService.findDevicePackageByDeviceId(identifier, devicePackage, page);
        return result_map;
    }

    @RequestMapping(value={"/updateDevicePackageById"})
    @ResponseBody
    public Map<String, Object> updateDevicePackageById(HttpServletRequest request, String devicePackageStrs) throws Exception {
        this.log.debug("devicePackageInfo================\u8fdb\u5165\u8bbe\u5907\u5957\u9910\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        devicePackageStrs = devicePackageStrs.replaceAll("&quot;", "\"");
        JSONArray array = JSONArray.fromObject((Object)devicePackageStrs);
        List devicePackages = JSONArray.toList((JSONArray)array, (Object)new Tb_device_package(), (JsonConfig)new JsonConfig());
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.devicePackageService.updateDevicePackageById(identifier, devicePackages);
        this.deviceCloudService.refreshApp(identifier, ((Tb_device_package)devicePackages.get(0)).getSw_mainboard_id());
        return result_map;
    }

    @RequestMapping(value={"/updateDevicePackageByBatch"})
    @ResponseBody
    public Map<String, Object> updateDevicePackageByBatch(HttpServletRequest request, String devicePackageStrs) throws Exception {
        this.log.debug("devicePackageInfo================\u8fdb\u5165\u8bbe\u5907\u5957\u9910\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        devicePackageStrs = devicePackageStrs.replaceAll("&quot;", "\"");
        JSONArray array = JSONArray.fromObject((Object)devicePackageStrs);
        List devicePackages = JSONArray.toList((JSONArray)array, (Object)new Tb_device_package(), (JsonConfig)new JsonConfig());
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.devicePackageService.updateDevicePackageByBatch(identifier, devicePackages);
        for (String mid : ((Tb_device_package)devicePackages.get(0)).getMidArr()) {
            this.deviceCloudService.refreshApp(identifier, mid);
        }
        return result_map;
    }
}

