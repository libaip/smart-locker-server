/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.aliyun.oss.OSS
 *  com.aliyun.oss.OSSClientBuilder
 *  com.aliyun.oss.model.ListObjectsV2Result
 *  com.aliyun.oss.model.OSSObject
 *  com.aliyun.oss.model.OSSObjectSummary
 *  com.aliyun.oss.model.PutObjectRequest
 *  com.aliyun.oss.model.PutObjectResult
 *  com.jcg.agent.model.Tb_net_photo
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.UeditorResponseData
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_goods_category
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  net.sf.json.JSONArray
 *  net.sf.json.JSONObject
 *  org.apache.commons.io.FilenameUtils
 *  org.apache.tools.zip.ZipEntry
 *  org.apache.tools.zip.ZipOutputStream
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.http.HttpHeaders
 *  org.springframework.http.HttpStatus
 *  org.springframework.http.MediaType
 *  org.springframework.http.ResponseEntity
 *  org.springframework.stereotype.Controller
 *  org.springframework.util.MultiValueMap
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RequestMethod
 *  org.springframework.web.bind.annotation.RequestParam
 *  org.springframework.web.bind.annotation.ResponseBody
 *  org.springframework.web.multipart.MultipartFile
 *  org.springframework.web.multipart.MultipartHttpServletRequest
 */
package com.jcg.company.control;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.ListObjectsV2Result;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.OSSObjectSummary;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyun.oss.model.PutObjectResult;
import com.jcg.agent.model.Tb_net_photo;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.UeditorResponseData;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.common.BaseController;
import com.jcg.company.common.ConfigProperties;
import com.jcg.company.common.OSSClient;
import com.jcg.company.model.Tb_goods_category;
import com.jcg.company.plugin.ueditor.ActionEnter;
import com.jcg.company.service.NetPhotoServiceImpl;
import com.jcg.company.vo.UploaderVO;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.io.FilenameUtils;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@Controller
public class FileController
extends BaseController {
    Map<String, Integer> chunkCount = new ConcurrentHashMap<String, Integer>();
    @Autowired
    private NetPhotoServiceImpl netPicService;

    @RequestMapping(value={"/upload"}, method={RequestMethod.POST})
    @ResponseBody
    public Map<String, Object> uploadFile(@RequestParam(value="file") MultipartFile file, UploaderVO command, HttpServletRequest request) {
        Date currDt = new Date();
        String current_time_str = XcbDateUtil.formatDate((Date)currDt, (String)"yyyy-MM-dd HH:mm:ss");
        String timePrefix = CommonFunction.getVoucherNum((String)CommonFunction.src_prefix);
        HashMap<String, Object> result = new HashMap<String, Object>();
        HashMap<String, Object> data = new HashMap<String, Object>();
        command.setName(XcbStringUtils.isNullOrBlank((Object)file.getOriginalFilename()) ? timePrefix + '_' + command.getName() : timePrefix + '_' + file.getOriginalFilename());
        try {
            String tempFilePath = request.getSession().getServletContext().getRealPath("/");
            tempFilePath = ConfigProperties.getProperty("upload.baseUrl").trim();
            String rscpathPrefix = "";
            String rscpathSuffix = "";
            if (command.getType() != null && command.getType().trim().equals("netPic")) {
                rscpathPrefix = ConfigProperties.getProperty("agent.netpic.rscpath.prefix").trim();
            } else if (command.getType() != null && command.getType().trim().equals("goodsPic")) {
                rscpathPrefix = ConfigProperties.getProperty("agent.goodspic.rscpath.prefix").trim();
                rscpathSuffix = "/agent_" + command.getAgentId();
            } else if (command.getType() != null && command.getType().trim().equals("catesPic")) {
                rscpathPrefix = ConfigProperties.getProperty("goods.category.prefix").trim();
            }
            File destDic = null;
            tempFilePath = this.generateFilePath(tempFilePath + "/xcbpic/" + XcbConstantValue.companyid + rscpathPrefix + rscpathSuffix, command);
            if (command.getChunks() > 0) {
                this.chunkHanler(file, command, tempFilePath);
            } else {
                destDic = new File(tempFilePath);
                if (!destDic.exists()) {
                    destDic.mkdirs();
                }
                this.log.debug("Name\uff1a" + command.getName());
                this.log.debug("getOriginalFilenam\uff1a" + file.getOriginalFilename());
                File destFile = new File(destDic, URLDecoder.decode(command.getName(), "UTF-8"));
                file.transferTo(destFile);
            }
            if (command.getType() != null && command.getType().trim().equals("netPic")) {
                Identifier identifier = new Identifier(command.getAgentId(), request.getRemoteAddr(), request.getRequestURI());
                Tb_net_photo pic = new Tb_net_photo();
                pic.setSr_create_person(command.getAgentId().toString());
                pic.setSr_create_time(current_time_str);
                pic.setSr_modify_person(command.getAgentId().toString());
                pic.setSr_modify_time(current_time_str);
                pic.setSr_photo_name(command.getName());
                pic.setSr_photo_upload_time(current_time_str);
                pic.setSw_netpoint_id(command.getNetPointId());
                pic.setSr_photo_addreess(rscpathPrefix + command.getUploadCode() + "/" + command.getName());
                Map<String, Object> res = this.netPicService.createNetPhoto(identifier, pic);
                pic = res.get(XcbConstantValue.DATA) == null ? pic : (Tb_net_photo)res.get(XcbConstantValue.DATA);
                data.put("pic", pic);
            } else if (command.getType() != null && command.getType().trim().equals("catesPic")) {
                Tb_goods_category cates = new Tb_goods_category();
                cates.setSr_picture("/" + XcbConstantValue.companyid + rscpathPrefix + "/" + command.getName());
                data.put("cates", cates);
            } else if (command.getType() == null || !command.getType().trim().equals("goodsPic")) {
                data.put("fileName", file.getOriginalFilename());
                data.put("filePath", rscpathPrefix + command.getUploadCode() + "/" + command.getName());
                data.put("createDate", current_time_str);
            }
            result.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            result.put(XcbConstantValue.MSG, "\u6587\u4ef6\u4e0a\u4f20\u6210\u529f\uff01");
            result.put(XcbConstantValue.DATA, data);
        }
        catch (Exception e) {
            e.printStackTrace();
            result.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result.put(XcbConstantValue.MSG, "\u4e0a\u4f20\u51fa\u9519\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458\uff01");
            result.put(XcbConstantValue.DATA, "");
        }
        return result;
    }

    @RequestMapping(value={"/uploadUEImg"}, method={RequestMethod.GET, RequestMethod.POST, RequestMethod.OPTIONS})
    @ResponseBody
    public void uploadUEImg(HttpServletRequest request, HttpServletResponse response, String action, Integer agentId) {
        response.setContentType("application/json");
        String rootPath = request.getSession().getServletContext().getRealPath("/");
        String uploadHost = XcbConstantValue.server_host;
        String realPath = ConfigProperties.getProperty("upload.baseUrl").trim();
        String ossUrl = ConfigProperties.getProperty("ALIYUN_OSS_URL").trim();
        String endpoint = ConfigProperties.getProperty("ALIYUN_OSS_ENDPOINT").trim();
        String accessKeyId = ConfigProperties.getProperty("ALIYUN_OSS_ACCESSKEYID").trim();
        String accessKeySecret = ConfigProperties.getProperty("ALIYUN_OSS_ACCESSKEYSECRET").trim();
        String bucketName = ConfigProperties.getProperty("ALIYUN_OSS_BUCKET_NAME").trim();
        String uploadGoodsPicPathPrefix = ConfigProperties.getProperty("goods.content.prefix").trim();
        try {
            if ("config".equals(action)) {
                String exec = new ActionEnter(request, rootPath, null).exec();
                PrintWriter writer = response.getWriter();
                writer.write(exec);
                writer.flush();
                writer.close();
            } else if ("uploadimage".equals(action) || "uploadvideo".equals(action) || "uploadfile".equals(action)) {
                try {
                    MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest)request;
                    MultipartFile file = multipartRequest.getFile("upfile");
                    JSONObject jo = new JSONObject();
                    long size = file.getSize();
                    String originalFilename = file.getOriginalFilename();
                    OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
                    String objectName = uploadGoodsPicPathPrefix + "/" + agentId + "/" + CommonFunction.fileRename((String)originalFilename);
                    PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, objectName, FileController.multipartFileToFile(file));
                    PutObjectResult putResult = ossClient.putObject(putObjectRequest);
                    String fullUploadGoodsPicPath = ossUrl + objectName;
                    jo.put((Object)"state", (Object)"SUCCESS");
                    jo.put((Object)"original", (Object)originalFilename);
                    jo.put((Object)"size", (Object)size);
                    jo.put((Object)"title", (Object)originalFilename);
                    jo.put((Object)"type", (Object)FilenameUtils.getExtension((String)file.getOriginalFilename()));
                    jo.put((Object)"url", (Object)fullUploadGoodsPicPath);
                    FileController.render(response, jo.toString());
                    ossClient.shutdown();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            } else if ("catchimage".equals(action)) {
                String exec = new ActionEnter(request, rootPath, realPath).exec();
                PrintWriter writer = response.getWriter();
                writer.write(exec);
                writer.flush();
                writer.close();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @RequestMapping(value={"/uploadUEImg2"}, method={RequestMethod.GET, RequestMethod.POST, RequestMethod.OPTIONS})
    @ResponseBody
    public void uploadUEImg2(HttpServletRequest request, HttpServletResponse response, String action, Integer agentId, @RequestParam(value="callback") String callback) {
        response.setContentType("application/json");
        String rootPath = request.getSession().getServletContext().getRealPath("/");
        String uploadHost = XcbConstantValue.server_host;
        String realPath = ConfigProperties.getProperty("upload.baseUrl").trim();
        String ossUrl = ConfigProperties.getProperty("ALIYUN_OSS_URL").trim();
        String endpoint = ConfigProperties.getProperty("ALIYUN_OSS_ENDPOINT").trim();
        String accessKeyId = ConfigProperties.getProperty("ALIYUN_OSS_ACCESSKEYID").trim();
        String accessKeySecret = ConfigProperties.getProperty("ALIYUN_OSS_ACCESSKEYSECRET").trim();
        String bucketName = ConfigProperties.getProperty("ALIYUN_OSS_BUCKET_NAME").trim();
        String uploadGoodsPicPathPrefix = ConfigProperties.getProperty("goods.content.prefix").trim();
        try {
            if ("config".equals(action)) {
                String exec = new ActionEnter(request, rootPath, null).exec();
                PrintWriter writer = response.getWriter();
                writer.write(exec);
                writer.flush();
                writer.close();
            } else if ("uploadimage".equals(action) || "uploadvideo".equals(action) || "uploadfile".equals(action)) {
                try {
                    MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest)request;
                    MultipartFile file = multipartRequest.getFile("upfile");
                    JSONObject jo = new JSONObject();
                    long size = file.getSize();
                    String originalFilename = file.getOriginalFilename();
                    OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
                    String objectName = uploadGoodsPicPathPrefix + agentId + "/" + CommonFunction.fileRename((String)originalFilename);
                    PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, objectName, FileController.multipartFileToFile(file));
                    PutObjectResult putResult = ossClient.putObject(putObjectRequest);
                    String fullUploadGoodsPicPath = ossUrl + objectName;
                    jo.put((Object)"state", (Object)"SUCCESS");
                    jo.put((Object)"original", (Object)originalFilename);
                    jo.put((Object)"size", (Object)size);
                    jo.put((Object)"title", (Object)originalFilename);
                    jo.put((Object)"type", (Object)FilenameUtils.getExtension((String)file.getOriginalFilename()));
                    jo.put((Object)"url", (Object)fullUploadGoodsPicPath);
                    FileController.render(response, jo.toString());
                    ossClient.shutdown();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            } else if ("catchimage".equals(action)) {
                String exec = new ActionEnter(request, rootPath, realPath).exec();
                PrintWriter writer = response.getWriter();
                writer.write(exec);
                writer.flush();
                writer.close();
            } else if ("listimage".equals(action)) {
                ArrayList<UeditorResponseData> list = new ArrayList<UeditorResponseData>();
                String prefix = uploadGoodsPicPathPrefix + "/" + agentId;
                OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
                ListObjectsV2Result listResult = ossClient.listObjectsV2(bucketName, prefix);
                List dataList = listResult.getObjectSummaries();
                for (OSSObjectSummary elementData : dataList) {
                    UeditorResponseData data = new UeditorResponseData();
                    data.setState("SUCCESS");
                    data.setUrl(ossUrl + elementData.getKey());
                    list.add(data);
                }
                JSONArray jsonArray = JSONArray.fromObject(list);
                String listJson = jsonArray.toString();
                JSONObject jo = new JSONObject();
                jo.put((Object)"state", (Object)"SUCCESS");
                jo.put((Object)"total", (Object)dataList.size());
                jo.put((Object)"start", (Object)0);
                jo.put((Object)"list", (Object)listJson);
                FileController.render(response, callback + "(" + jo.toString() + ")");
                ossClient.shutdown();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void render(HttpServletResponse response, String text) {
        response.setContentType("application/json;charset=UTF-8");
        response.setHeader("Pragma", "No-cache");
        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expires", 0L);
        PrintWriter pWriter = null;
        try {
            pWriter = response.getWriter();
            pWriter.write(text);
            pWriter.flush();
        }
        catch (IOException iOException) {
        }
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    @RequestMapping(value={"/download"})
    @ResponseBody
    public ResponseEntity<byte[]> downloadFile(String fileName, String filePath) {
        try {
            String ossUrl = ConfigProperties.getProperty("ALIYUN_OSS_URL").trim();
            fileName = new String(fileName.getBytes("utf-8"), "iso-8859-1");
            HttpHeaders headers = new HttpHeaders();
            File file = new File(filePath);
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment", fileName);
            OSSObject ossObject = OSSClient.getObject(filePath);
            InputStream inputStream = ossObject.getObjectContent();
            return new ResponseEntity((Object)FileController.input2byte(inputStream), (MultiValueMap)headers, HttpStatus.CREATED);
        }
        catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        }
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @RequestMapping(value={"/downloadZip"})
    @ResponseBody
    public ResponseEntity<byte[]> downloadZipFile(String[] fileName, String[] filePath, String sd_device_id) {
        byte[] buf = new byte[1024];
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            ZipOutputStream out = new ZipOutputStream((OutputStream)bos);
            for (int i = 0; i < fileName.length; ++i) {
                int len;
                if (XcbStringUtils.isNullOrBlank((Object)filePath[i]) || XcbStringUtils.isNullOrBlank((Object)fileName[i])) continue;
                OSSObject ossObject = OSSClient.getObject(filePath[i]);
                InputStream in = ossObject.getObjectContent();
                out.putNextEntry(new ZipEntry(fileName[i]));
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                out.closeEntry();
                in.close();
            }
            out.close();
            bos.close();
            System.out.println("\u538b\u7f29\u5b8c\u6210.");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        HttpHeaders header = new HttpHeaders();
        header.add("Content-Disposition", "attachment;filename=" + sd_device_id + ".zip");
        return new ResponseEntity((Object)bos.toByteArray(), (MultiValueMap)header, HttpStatus.CREATED);
    }

    private void chunkHanler(MultipartFile file, UploaderVO command, String tempFilePath) throws IOException, FileNotFoundException {
        File destDic = new File(tempFilePath + "/" + command.getGuid());
        if (!destDic.exists()) {
            destDic.mkdirs();
        }
        File tempFile = new File(destDic, String.valueOf(command.getChunk()) + ".zip");
        file.transferTo(tempFile);
        if (!this.chunkCount.containsKey(command.getGuid())) {
            this.chunkCount.put(command.getGuid(), 1);
        } else {
            int count = this.chunkCount.get(command.getGuid());
            this.chunkCount.put(command.getGuid(), ++count);
        }
        if (command.getChunks() == this.chunkCount.get(command.getGuid()).intValue()) {
            BufferedInputStream inputStream = null;
            File chunkFile = null;
            File destFile = new File(tempFilePath + "/" + URLDecoder.decode(command.getName(), "UTF-8"));
            FileOutputStream fos = new FileOutputStream(destFile);
            for (int i = 0; i < command.getChunks(); ++i) {
                chunkFile = new File(destDic + "/" + i + ".zip");
                inputStream = new BufferedInputStream(new FileInputStream(chunkFile));
                byte[] buf = new byte[5120];
                int length = 0;
                while ((length = inputStream.read(buf)) != -1) {
                    fos.write(buf, 0, length);
                }
                inputStream.close();
                chunkFile.delete();
            }
            this.log.info("\u5206\u7247\u5408\u5e76\u5b8c\u6210\uff01");
            fos.close();
            this.chunkCount.remove(command.getGuid());
            destDic.delete();
        }
    }

    private String generateFilePath(String rootPath, UploaderVO command) throws Exception {
        String moduleName = command.getUploadCode();
        if (moduleName.length() > 0 && moduleName.substring(0, 1).equals("/")) {
            moduleName = moduleName.substring(1);
        }
        if (!"/".equals(rootPath.substring(rootPath.length() - 1))) {
            rootPath = rootPath + "/";
        }
        rootPath = rootPath + moduleName;
        return rootPath;
    }

    public static File multipartFileToFile(MultipartFile file) throws Exception {
        File toFile = null;
        if (file.equals("") || file.getSize() <= 0L) {
            file = null;
        } else {
            InputStream ins = null;
            ins = file.getInputStream();
            toFile = new File(file.getOriginalFilename());
            FileController.inputStreamToFile(ins, toFile);
            ins.close();
        }
        return toFile;
    }

    private static void inputStreamToFile(InputStream ins, File file) {
        try {
            FileOutputStream os = new FileOutputStream(file);
            int bytesRead = 0;
            byte[] buffer = new byte[8192];
            while ((bytesRead = ins.read(buffer, 0, 8192)) != -1) {
                ((OutputStream)os).write(buffer, 0, bytesRead);
            }
            ((OutputStream)os).close();
            ins.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static final byte[] input2byte(InputStream inStream) throws IOException {
        ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        byte[] buff = new byte[100];
        int rc = 0;
        while ((rc = inStream.read(buff, 0, 100)) > 0) {
            swapStream.write(buff, 0, rc);
        }
        byte[] in2b = swapStream.toByteArray();
        return in2b;
    }
}

