/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_goods_category
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_goods_category;
import com.jcg.company.service.GoodsCategoryServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/category"})
public class GoodsCategoryController
extends BaseController {
    @Autowired
    private GoodsCategoryServiceImpl goodsCategoryService;

    @RequestMapping(value={"/createGoodsCategory"})
    @ResponseBody
    public Map<String, Object> createGoodsCategory(HttpServletRequest request, Tb_goods_category category) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.goodsCategoryService.createGoodsCategory(identifier, category);
        return result_map;
    }

    @RequestMapping(value={"/findGoodsCategoryByParam"})
    @ResponseBody
    public Map<String, Object> findCustomerAppByParam(HttpServletRequest request, Tb_goods_category category, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.goodsCategoryService.findGoodsCategoryByParam(identifier, category, page);
        return result_map;
    }

    @RequestMapping(value={"/updateGoodsCategory"})
    @ResponseBody
    public Map<String, Object> updateGoodsCategory(HttpServletRequest request, Tb_goods_category category) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.goodsCategoryService.updateGoodsCategory(identifier, category);
        return result_map;
    }

    @RequestMapping(value={"/findAllCatesCoverPic"})
    @ResponseBody
    public Map<String, Object> findAllCatesCoverPic(HttpServletRequest request) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.goodsCategoryService.findAllCatesCoverPic(identifier);
        return result_map;
    }
}

