/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_goods
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_goods;
import com.jcg.company.service.GoodsServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/goods"})
public class GoodsController
extends BaseController {
    @Autowired
    private GoodsServiceImpl goodsService;

    @RequestMapping(value={"/createGoods"})
    @ResponseBody
    public Map<String, Object> createGoods(HttpServletRequest request, Tb_goods goods) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.goodsService.createGoods(identifier, goods);
        return result_map;
    }

    @RequestMapping(value={"/findMaxId"})
    @ResponseBody
    public Map<String, Object> findMaxId(HttpServletRequest request, Tb_goods goods) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.goodsService.findMaxId(identifier, goods);
        return result_map;
    }

    @RequestMapping(value={"/findGoodsByParam"})
    @ResponseBody
    public Map<String, Object> findGoodsByParam(HttpServletRequest request, Tb_goods goods, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.goodsService.findGoodsByParam(identifier, goods, page);
        return result_map;
    }

    @RequestMapping(value={"/updateGoods"})
    @ResponseBody
    public Map<String, Object> updateGoods(HttpServletRequest request, Tb_goods goods) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.goodsService.updateGoods(identifier, goods);
        return result_map;
    }

    @RequestMapping(value={"/findAllCates"})
    @ResponseBody
    public Map<String, Object> findAllCates(HttpServletRequest request) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.goodsService.findAllCates(identifier);
        return result_map;
    }
}

