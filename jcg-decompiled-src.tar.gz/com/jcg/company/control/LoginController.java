/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.authentication.AuthenticationManager
 *  org.springframework.security.authentication.UsernamePasswordAuthenticationToken
 *  org.springframework.security.core.Authentication
 *  org.springframework.security.core.authority.SimpleGrantedAuthority
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.security.core.userdetails.UserDetails
 *  org.springframework.security.core.userdetails.UserDetailsService
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RequestMethod
 *  org.springframework.web.bind.annotation.RestController
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.security.JwtTokenUtil;
import com.jcg.company.service.CuserServiceImpl;
import com.jcg.company.vo.LoginUser;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value={"/auth"}, method={RequestMethod.POST})
public class LoginController
extends BaseController {
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private CuserServiceImpl cuserService;

    @RequestMapping(value={"/login"}, method={RequestMethod.POST})
    public Map<String, Object> login(LoginUser loginUser, HttpServletRequest request) throws Exception {
        this.log.info("in login...");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        HashMap<String, Object> userInfodataMap = new HashMap<String, Object>();
        Map<String, Object> resMp = this.cuserService.login(identifier, loginUser);
        String status = XcbStringUtils.getObjtoString((Object)resMp.get(XcbConstantValue.STATUS));
        if (!XcbStringUtils.isNullOrBlank((Object)status) && status.equals(XcbConstantValue.OPERA_SUCCESS)) {
            Authentication authentication = this.authenticationManager.authenticate((Authentication)new UsernamePasswordAuthenticationToken((Object)loginUser.getUsername(), (Object)loginUser.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            Tb_cuser cuser = (Tb_cuser)this.userDetailsService.loadUserByUsername(loginUser.getUsername());
            Collection authList = cuser.getAuthorities();
            ArrayList authList2 = (ArrayList)cuser.getUserInfoRoles();
            ArrayList<String> accessCodeList = new ArrayList<String>();
            String[] accessArr = new String[authList2.size()];
            Iterator iter = authList2.iterator();
            while (iter.hasNext()) {
                accessCodeList.add(((SimpleGrantedAuthority)iter.next()).getAuthority());
            }
            String token = this.jwtTokenUtil.generateToken((UserDetails)cuser, authList);
            dataMap.put("token", token);
            accessCodeList.toArray(accessArr);
            String show_deposit = "N";
            if (accessCodeList.contains("ROLE_ORDER_SHOW")) {
                show_deposit = "Y";
            }
            userInfodataMap.put("name", cuser.getSr_name());
            userInfodataMap.put("avatar", XcbConstantValue.AGENT_AVATAR_DEFAULT);
            userInfodataMap.put("access", accessArr);
            userInfodataMap.put("userid", cuser.getSd_cuser_id());
            userInfodataMap.put("companyId", cuser.getSw_company_id());
            userInfodataMap.put("companyPId", cuser.getSw_company_pid());
            userInfodataMap.put("companyType", cuser.getSr_type());
            userInfodataMap.put("sex", cuser.getSr_sex());
            userInfodataMap.put("loginType", loginUser.getType());
            userInfodataMap.put("show_deposit", show_deposit);
            dataMap.put("info", userInfodataMap);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        ret.put(XcbConstantValue.MSG, XcbStringUtils.getObjtoString((Object)resMp.get(XcbConstantValue.MSG)));
        return ret;
    }

    public static List<String> listrem(List<String> listA, List<String> listB) {
        Iterator<String> itA = listA.iterator();
        while (itA.hasNext()) {
            String temp = itA.next();
            for (int i = 0; i < listB.size(); ++i) {
                if (!temp.equals(listB.get(i))) continue;
                itA.remove();
            }
        }
        return listA;
    }
}

