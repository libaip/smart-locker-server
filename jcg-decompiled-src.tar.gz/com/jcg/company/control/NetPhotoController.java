/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RequestMethod
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.NetPhotoServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/netPhoto"})
public class NetPhotoController
extends BaseController {
    @Autowired
    private NetPhotoServiceImpl netPhotoService;

    @RequestMapping(value={"/findNetPhotoByNetId"})
    @ResponseBody
    public Map<String, Object> findNetPhotoByNetId(HttpServletRequest request, String sw_netpoint_id) throws Exception {
        this.log.debug("netPhotoInfo================\u8fdb\u5165\u7f51\u70b9\u76f8\u518c\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.netPhotoService.findNetPhotoByNetId(identifier, sw_netpoint_id);
        return result_map;
    }

    @RequestMapping(value={"/deleteNetPhotoById"}, method={RequestMethod.POST})
    @ResponseBody
    public Map<String, Object> deleteNetPhotoById(HttpServletRequest request, String sd_net_photo_id, String sr_photo_addreess) throws Exception {
        this.log.debug("netPhotoInfo================\u8fdb\u5165\u7f51\u70b9\u76f8\u518c\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.netPhotoService.deleteNetPhotoById(identifier, sd_net_photo_id, sr_photo_addreess);
        return result_map;
    }
}

