/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_netpoint
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_netpoint;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.DeviceCloudServiceImpl;
import com.jcg.company.service.NetPointServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/netpoint"})
public class NetPointController
extends BaseController {
    @Autowired
    private NetPointServiceImpl netpointService;
    @Autowired
    private DeviceCloudServiceImpl deviceCloudService;

    @RequestMapping(value={"/createNetPoint"})
    @ResponseBody
    public Map<String, Object> createNetPoint(HttpServletRequest request, Tb_netpoint netpoint) throws Exception {
        this.log.debug("NetPointInfo================\u65b0\u589e\u7f51\u70b9\u5217\u8868");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.netpointService.createNetPoint(identifier, netpoint);
        return result_map;
    }

    @RequestMapping(value={"/findNetPointByParam"})
    @ResponseBody
    public Map<String, Object> findNetPointByParam(HttpServletRequest request, Tb_netpoint netpoint, Page page) throws Exception {
        this.log.debug("NetPointInfo================\u67e5\u8be2\u7f51\u70b9\u5217\u8868");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.netpointService.findNetPointByParam(identifier, netpoint, page);
        return result_map;
    }

    @RequestMapping(value={"/findDropDownNetpointByAgentId"})
    @ResponseBody
    public Map<String, Object> findDropDownNetpointByAgentId(HttpServletRequest request, Tb_netpoint netpoint) throws Exception {
        this.log.debug("netpointInfo================\u67e5\u8be2\u7f51\u70b9\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.netpointService.findDropDownNetpointByAgentId(identifier, netpoint.getSw_agent_id());
        return result_map;
    }

    @RequestMapping(value={"/findNetPointById"})
    @ResponseBody
    public Map<String, Object> findNetPointById(HttpServletRequest request, Tb_netpoint netpoint) throws Exception {
        this.log.debug("NetPointInfo================\u67e5\u8be2\u7f51\u70b9\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.netpointService.findNetPointById(identifier, netpoint);
        return result_map;
    }

    @RequestMapping(value={"/updateNetPointById"})
    @ResponseBody
    public Map<String, Object> updateNetPointById(HttpServletRequest request, Tb_netpoint netpoint) throws Exception {
        this.log.debug("NetPointInfo================\u66f4\u65b0\u7f51\u70b9\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.netpointService.updateNetPointById(identifier, netpoint);
        this.deviceCloudService.refreshAll(identifier, netpoint.getSd_netpoint_id());
        return result_map;
    }

    @RequestMapping(value={"/updateNetStsById"})
    @ResponseBody
    public Map<String, Object> updateNetStsById(HttpServletRequest request, Tb_netpoint netpoint) throws Exception {
        this.log.debug("NetPointInfo================\u66f4\u65b0\u7f51\u70b9\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.netpointService.updateNetStsById(identifier, netpoint);
        return result_map;
    }

    @RequestMapping(value={"/findAllNetpointByAreaCode"})
    @ResponseBody
    public Map<String, Object> findAllNetpointByAreaCode(HttpServletRequest request, Tb_netpoint netpoint, String companyId) throws Exception {
        this.log.debug("findAllNetpointByAreaCode================\u67e5\u8be2\u7f51\u70b9\u4e0b\u62c9\u6846");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.netpointService.findAllNetpointByAreaCode(identifier, netpoint, companyId);
        return result_map;
    }

    @RequestMapping(value={"/findOrderInfoByNet"})
    @ResponseBody
    public Map<String, Object> findOrderInfoByNet(HttpServletRequest request, Integer sd_netpoint_id) throws Exception {
        this.log.debug("NetPointInfo================\u67e5\u8be2\u7f51\u70b9\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.netpointService.findOrderInfoByNet(identifier, sd_netpoint_id);
        return result_map;
    }
}

