/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_ordercash_stream
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_ordercash_stream;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.OrderCashStreamServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/orderCashStream"})
public class OrderCashStreamController
extends BaseController {
    @Autowired
    private OrderCashStreamServiceImpl orderCashStreamService;

    @RequestMapping(value={"/findOrderCashStreamByParam"})
    @ResponseBody
    public Map<String, Object> findOrderCashStreamByParam(HttpServletRequest request, Tb_ordercash_stream orderCashStream, Page page) throws Exception {
        this.log.debug("OrderCashStreamInfo================\u67e5\u8be2\u7ed3\u7b97\u6d41\u6c34\u5217\u8868");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderCashStreamService.findOrderCashStreamByParam(identifier, orderCashStream, page);
        return result_map;
    }

    @RequestMapping(value={"/findOrderCashStreamByOrder"})
    @ResponseBody
    public Map<String, Object> findOrderCashStreamByOrder(HttpServletRequest request, String sw_order_id) throws Exception {
        this.log.debug("OrderCashStreamInfo================\u67e5\u8be2\u7ed3\u7b97\u6d41\u6c34\u5217\u8868");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.orderCashStreamService.findOrderCashStreamByOrder(identifier, sw_order_id);
        return result_map;
    }
}

