/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_sys_param
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.alibaba.fastjson.JSONObject;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.common.BaseController;
import com.jcg.company.common.ExportToExcel;
import com.jcg.company.common.RedisUtil;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.service.OrderServiceImpl;
import com.jcg.company.service.SysParamServiceImpl;
import java.io.BufferedReader;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/order"})
public class OrderController
extends BaseController {
    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private SysParamServiceImpl sysParamService;
    @Autowired
    private RedisUtil redis;

    @RequestMapping(value={"/findOrderByParam"})
    @ResponseBody
    public Map<String, Object> findOrderByParam(HttpServletRequest request, Tb_order order, Page page) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u5217\u8868");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_iphone_num())) {
            order.setSr_iphone_num(order.getSr_iphone_num().replaceAll("\\s*", ""));
        }
        Map<String, Object> result_map = this.orderService.findOrderByParam(identifier, order, page);
        return result_map;
    }

    @RequestMapping(value={"/findOrderByApp"})
    @ResponseBody
    public Map<String, Object> findOrderByApp(HttpServletRequest request, Tb_order order, String dateRange, Page page) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u5217\u8868");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_iphone_num())) {
            order.setSr_iphone_num(order.getSr_iphone_num().replaceAll("\\s*", ""));
        }
        Map<String, Object> result_map = this.orderService.findOrderByApp(identifier, order, dateRange, page);
        return result_map;
    }

    @RequestMapping(value={"/findOrderById"})
    @ResponseBody
    public Map<String, Object> findOrderById(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_iphone_num())) {
            order.setSr_iphone_num(order.getSr_iphone_num().replaceAll("\\s*", ""));
        }
        Map<String, Object> result_map = this.orderService.findOrderById(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/findOrderRecordById_cpy"})
    @ResponseBody
    public Map<String, Object> findOrderRecordById_cpy(HttpServletRequest request, String sd_order_id) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderService.findOrderRecordById_cpy(identifier, sd_order_id);
        return result_map;
    }

    @RequestMapping(value={"/findAllOrderByParam"})
    @ResponseBody
    public Map<String, Object> findAllOrderByParam(HttpServletRequest request) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = new HashMap<String, Object>();
        BufferedReader bufferReader = request.getReader();
        StringBuffer sb = new StringBuffer();
        String line = "";
        while ((line = bufferReader.readLine()) != null) {
            sb.append(line);
        }
        String postData = sb.toString();
        if (!XcbStringUtils.isNullOrBlank((Object)postData)) {
            JSONObject json = JSONObject.parseObject((String)postData);
            String sd_order_id = (String)json.get("sd_order_id");
            String sw_bus_order_id = (String)json.get("sw_bus_order_id");
            String sr_net_name = (String)json.get("sr_net_name");
            String sr_alias_desc = (String)json.get("sr_alias_desc");
            String si_mainboard_id = (String)json.get("si_mainboard_id");
            String sr_iphone_num = (String)json.get("sr_iphone_num");
            Integer sw_netpoint_id = (Integer)json.get("sw_netpoint_id");
            Integer sw_agent_id = (Integer)json.get("sw_agent_id");
            if (!XcbStringUtils.isNullOrBlank((Object)sr_iphone_num)) {
                sr_iphone_num = sr_iphone_num.replaceAll("\\s*", "");
            }
            String sw_company_id = (String)json.get("sw_company_id");
            String sr_order_time_start = (String)json.get("sr_order_time_start");
            String sr_order_time_end = (String)json.get("sr_order_time_end");
            Tb_order order = new Tb_order();
            order.setSd_order_id(sd_order_id);
            order.setSw_bus_order_id(sw_bus_order_id);
            order.setSr_net_name(sr_net_name);
            order.setSr_alias_desc(sr_alias_desc);
            order.setSi_mainboard_id(si_mainboard_id);
            order.setSr_iphone_num(sr_iphone_num);
            order.setSw_company_id(sw_company_id);
            order.setSw_netpoint_id(sw_netpoint_id);
            order.setSw_agent_id(sw_agent_id);
            order.setSr_order_time_start(sr_order_time_start);
            order.setSr_order_time_end(sr_order_time_end);
            result_map = this.orderService.findAllOrderByParam(identifier, order);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u53c2\u6570\u4f20\u5165\u9519\u8bef");
        }
        return result_map;
    }

    @RequestMapping(value={"/findAllOrderById"})
    @ResponseBody
    public Map<String, Object> findAllOrderById(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_iphone_num())) {
            order.setSr_iphone_num(order.getSr_iphone_num().replaceAll("\\s*", ""));
        }
        Map<String, Object> result_map = this.orderService.findAllOrderById(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/findAllOrderRecordById"})
    @ResponseBody
    public Map<String, Object> findAllOrderRecordById(HttpServletRequest request, String sd_order_id) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.orderService.findOrderRecordById_cpy(identifier, sd_order_id);
        return result_map;
    }

    @RequestMapping(value={"/findPizhuOrderByUser"})
    @ResponseBody
    public Map<String, Object> findPizhuOrderByUser(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderService.findPizhuOrderByUser(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/deleteOrderByDeviceId"})
    @ResponseBody
    public Map<String, Object> deleteOrderByDeviceId(HttpServletRequest request, String[] deviceArr, String sr_password) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderService.deleteOrderByDeviceId(identifier, deviceArr, sr_password);
        return result_map;
    }

    @RequestMapping(value={"/updateOrderById"})
    @ResponseBody
    public Map<String, Object> updateOrderById(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u66f4\u65b0\u8ba2\u5355\u4fe1\u606f");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderService.updateOrderById(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/closeOrder"})
    @ResponseBody
    public Map<String, Object> closeOrder(HttpServletRequest request, String sd_order_id) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Map<String, Object> result_map = new HashMap<String, Object>();
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        String order_redis = XcbStringUtils.getObjtoString((Object)this.redis.get(sd_order_id));
        if (XcbStringUtils.isNullOrBlank((Object)order_redis)) {
            this.redis.setForTimeMS(sd_order_id, XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"), 10000L);
            result_map = this.orderService.closeOrder(identifier, sd_order_id);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u8bf7\u52ff\u91cd\u590d\u64cd\u4f5c");
        }
        return result_map;
    }

    @RequestMapping(value={"/closeAllOrder"})
    @ResponseBody
    public Map<String, Object> closeAllOrder(HttpServletRequest request, String sd_order_id) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Map<String, Object> result_map = new HashMap<String, Object>();
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        String order_redis = XcbStringUtils.getObjtoString((Object)this.redis.get(sd_order_id));
        if (XcbStringUtils.isNullOrBlank((Object)order_redis)) {
            this.redis.setForTimeMS(sd_order_id, XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"), 10000L);
            result_map = this.orderService.closeAllOrder(identifier, sd_order_id);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u8bf7\u52ff\u91cd\u590d\u64cd\u4f5c");
        }
        return result_map;
    }

    @RequestMapping(value={"/updatePhone"})
    @ResponseBody
    public Map<String, Object> updatePhone(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.orderService.updatePhone(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/checkRefund"})
    @ResponseBody
    public Map<String, Object> checkRefund(HttpServletRequest request, String sd_ordercash_id, String sr_refund_money) throws Exception {
        this.log.debug("OrderInfo================\u8d26\u6237\u4f59\u989d\u68c0\u67e5");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderService.checkRefund(identifier, sd_ordercash_id, sr_refund_money);
        return result_map;
    }

    @RequestMapping(value={"/checkRefundAll"})
    @ResponseBody
    public Map<String, Object> checkRefundAll(HttpServletRequest request, String sd_ordercash_id, String sr_refund_money) throws Exception {
        this.log.debug("OrderInfo================\u8d26\u6237\u4f59\u989d\u68c0\u67e5");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        if (XcbStringUtils.isNullOrBlank((Object)sd_ordercash_id)) {
            BufferedReader bufferReader = request.getReader();
            StringBuffer sb = new StringBuffer();
            String line = "";
            while ((line = bufferReader.readLine()) != null) {
                sb.append(line);
            }
            String postData = sb.toString();
            if (!XcbStringUtils.isNullOrBlank((Object)postData)) {
                JSONObject json = JSONObject.parseObject((String)postData);
                sd_ordercash_id = (String)json.get("sd_ordercash_id");
                sr_refund_money = (String)json.get("sr_refund_money");
            }
        }
        Map<String, Object> result_map = this.orderService.checkRefund(identifier, sd_ordercash_id, sr_refund_money);
        return result_map;
    }

    @RequestMapping(value={"/zhRefund"})
    @ResponseBody
    public Map<String, Object> zhRefund(HttpServletRequest request, String sd_ordercash_id, String sr_refund_money) throws Exception {
        this.log.debug("OrderInfo================\u8d26\u6237\u4f59\u989d\u9000\u6b3e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderService.zhRefund(identifier, sd_ordercash_id, sr_refund_money);
        return result_map;
    }

    @RequestMapping(value={"/zhRefundAll"})
    @ResponseBody
    public Map<String, Object> zhRefundAll(HttpServletRequest request, String sd_ordercash_id, String sr_refund_money) throws Exception {
        this.log.debug("OrderInfo================\u8d26\u6237\u4f59\u989d\u9000\u6b3e");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.orderService.zhRefund(identifier, sd_ordercash_id, sr_refund_money);
        return result_map;
    }

    @RequestMapping(value={"/depositRefund"})
    @ResponseBody
    public Map<String, Object> depositRefund(HttpServletRequest request, String sd_order_id, String sr_refund_money) throws Exception {
        this.log.debug("OrderInfo================\u8ba2\u5355\u62bc\u91d1\u9000\u6b3e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.orderService.depositRefund(identifier, sd_order_id, sr_refund_money);
        return result_map;
    }

    @RequestMapping(value={"/depositRefundAll"})
    @ResponseBody
    public Map<String, Object> depositRefundAll(HttpServletRequest request, String sd_order_id, String sr_refund_money) throws Exception {
        this.log.debug("OrderInfo================\u8ba2\u5355\u62bc\u91d1\u9000\u6b3e");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.orderService.depositRefundAll(identifier, sd_order_id, sr_refund_money);
        return result_map;
    }

    @RequestMapping(value={"/updateBoxByWeb"})
    @ResponseBody
    public Map<String, Object> updateBoxByWeb(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u66f4\u6362\u67dc\u95e8");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.orderService.updateBoxByWeb(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/reUseBoxByWeb"})
    @ResponseBody
    public Map<String, Object> reUseBoxByWeb(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u91cd\u65b0\u5360\u7528");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.orderService.reUseBoxByWeb(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/findDepositByAgentId"})
    @ResponseBody
    public Map<String, Object> findDepositByAgentId(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u5546\u5bb6\u8ba2\u5355\u62bc\u91d1");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.orderService.findDepositByAgentId(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/batchUpdateOrderAd"})
    @ResponseBody
    public Map<String, Object> batchUpdateOrderAd(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u6279\u91cf\u66f4\u65b0\u5546\u5bb6\u8ba2\u5355\u5e7f\u544a");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.orderService.batchUpdateOrderAd(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/expExcelOrder"})
    @ResponseBody
    public Map<String, Object> expExcelOrder(HttpServletRequest request, HttpServletResponse response, Tb_order order) throws Exception {
        this.log.debug("orderInfo================\u8fdb\u5165\u8ba2\u5355\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> maxExpMap = this.sysParamService.findSysParamByKeyCode(identifier, XcbConstantValue.XTCL, XcbConstantValue.EXPMAX);
        Tb_sys_param sysparam = (Tb_sys_param)maxExpMap.get("sysParam");
        Integer maxExpCnt = Integer.valueOf(sysparam.getSr_param_value());
        Page page = new Page();
        page.setStart(0);
        page.setPageSize(maxExpCnt.intValue());
        Map<String, Object> result_map = this.orderService.findOrderForExcel(identifier, order, page);
        Map dataMap = (Map)result_map.get(XcbConstantValue.DATA);
        List orders = (List)dataMap.get("orders");
        this.genTransExcelFile(request, response, orders);
        return null;
    }

    private void genTransExcelFile(HttpServletRequest request, HttpServletResponse response, List dataList) throws Exception {
        this.log.debug("orderInfo================\u5bfc\u51fa");
        Date currentDt = new Date();
        String StrCurrentDt = XcbDateUtil.formatDate((Date)currentDt, (String)"yyyyMMddHHmmss");
        String filedisplay = StrCurrentDt + "\u5728\u7ebf\u8ba2\u5355.xlsx";
        String title = "\u5728\u7ebf\u8ba2\u5355";
        String titleCode = XcbConstantValue.EXPORT_DD;
        String[] headers = new String[]{"\u8ba2\u5355ID", "\u4ee3\u7406\u5546", "\u7f51\u70b9\u540d\u79f0", "\u8bbe\u5907ID", "\u67dc\u5b50\u7f16\u53f7", "\u7528\u6237\u624b\u673a\u53f7\u7801", "\u5fae\u4fe1\u6635\u79f0", "\u8ba2\u5355\u6765\u6e90", "\u8ba1\u8d39\u65b9\u5f0f", "\u8ba2\u5355\u91d1\u989d", "\u5b9e\u9645\u91d1\u989d", "\u8ba2\u5355\u9000\u6b3e\u91d1\u989d", "\u62bc\u91d1", "\u5df2\u9000\u6b3e\u62bc\u91d1", "\u5546\u5bb6\u5e7f\u544a\u8d39", "\u4ee3\u7406\u5e7f\u544a\u8d39", "\u5f00\u59cb\u65f6\u95f4", "\u7ed3\u675f\u65f6\u95f4", "\u903b\u8f91\u6807\u8bb0", "\u8ba2\u5355\u72b6\u6001"};
        String[] fieldNams = new String[]{"sd_order_id", "sr_agent_name", "sr_net_name", "si_mainboard_id", "sr_alias_desc", "sr_user_name", "sr_user_petname", "sr_order_way_desc", "sr_charging_type_desc", "dc_order_money", "dc_actual_income", "dc_refund_money", "dc_deposit_money", "dc_deposit_refund", "dc_ad_money", "dc_up_ad_money", "sr_order_starttime", "sr_order_endtime", "sr_is_steal", "sr_order_status_desc"};
        new ExportToExcel().exportExcel(filedisplay, title, titleCode, headers, fieldNams, dataList, response, null, null);
    }
}

