/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_order_goods
 *  com.jcg.company.model.Tb_ordercash_goods
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.company.model.Tb_ordercash_goods;
import com.jcg.company.service.OrderGoodsServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/orderGoods"})
public class OrderGoodsController
extends BaseController {
    @Autowired
    private OrderGoodsServiceImpl orderGoodsService;

    @RequestMapping(value={"/findOrderGoodsByParam"})
    @ResponseBody
    public Map<String, Object> findOrderGoodsByParam(HttpServletRequest request, Tb_order_goods order, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.orderGoodsService.findOrderGoodsByParam(identifier, order, page);
        return result_map;
    }

    @RequestMapping(value={"/closeOrder"})
    @ResponseBody
    public Map<String, Object> closeOrder(HttpServletRequest request, Tb_order_goods order) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderGoodsService.closeOrder(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/updateOrder"})
    @ResponseBody
    public Map<String, Object> updateOrder(HttpServletRequest request, Tb_order_goods order) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderGoodsService.updateOrder(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/refund"})
    @ResponseBody
    public Map<String, Object> refund(HttpServletRequest request, Tb_ordercash_goods cash) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderGoodsService.refund(identifier, cash);
        return result_map;
    }
}

