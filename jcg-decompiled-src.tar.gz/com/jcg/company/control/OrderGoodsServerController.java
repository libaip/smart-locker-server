/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_ordergoods_server
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_ordergoods_server;
import com.jcg.company.service.OrderGoodsServerServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/serverGoods"})
public class OrderGoodsServerController {
    @Autowired
    private OrderGoodsServerServiceImpl orderGoodsServerService;

    @RequestMapping(value={"/updateOrderServer"})
    @ResponseBody
    public Map<String, Object> createOrderServer(HttpServletRequest request, Tb_ordergoods_server server) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderGoodsServerService.updateOrderServer(identifier, server);
        return result_map;
    }

    @RequestMapping(value={"/findOrderGoodsServerByParam"})
    @ResponseBody
    public Map<String, Object> findOrderGoodsServerByParam(HttpServletRequest request, Tb_ordergoods_server server, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderGoodsServerService.findOrderGoodsServerByParam(identifier, server, page);
        return result_map;
    }

    @RequestMapping(value={"/findOrderGoodsServerById"})
    @ResponseBody
    public Map<String, Object> findOrderGoodsServerById(HttpServletRequest request, Tb_ordergoods_server server) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.orderGoodsServerService.findOrderGoodsServerById(identifier, server);
        return result_map;
    }
}

