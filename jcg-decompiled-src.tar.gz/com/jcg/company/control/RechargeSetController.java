/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_recharge_set
 *  com.jcg.common.model.Identifier
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_recharge_set;
import com.jcg.common.model.Identifier;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.RechargeSetServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/rechargeSet"})
public class RechargeSetController
extends BaseController {
    @Autowired
    private RechargeSetServiceImpl rechargeSetService;

    @RequestMapping(value={"/findRechargeSetByParam"})
    @ResponseBody
    public Map<String, Object> findRechargeSetByParam(HttpServletRequest request, Tb_recharge_set rechargeSet) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.rechargeSetService.findRechargeSetByParam(identifier, rechargeSet);
        return result_map;
    }

    @RequestMapping(value={"/updaeRechargeSet"})
    @ResponseBody
    public Map<String, Object> updaeRechargeSet(HttpServletRequest request, Tb_recharge_set rechargeSet) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.rechargeSetService.updaeRechargeSet(identifier, rechargeSet);
        return result_map;
    }

    @RequestMapping(value={"/findUserTaskCount"})
    @ResponseBody
    public Map<String, Object> findUserTaskCount(HttpServletRequest request, Tb_recharge_set rechargeSet) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.rechargeSetService.findUserTaskCount(identifier, rechargeSet);
        return result_map;
    }

    @RequestMapping(value={"/findUserApplTaskCount"})
    @ResponseBody
    public Map<String, Object> findUserApplTaskCount(HttpServletRequest request, Tb_recharge_set rechargeSet) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.rechargeSetService.findUserApplTaskCount(identifier, rechargeSet);
        return result_map;
    }

    @RequestMapping(value={"/executeUpdateUserTask"})
    @ResponseBody
    public Map<String, Object> executeUpdateUserTask(HttpServletRequest request, Tb_recharge_set rechargeSet) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.rechargeSetService.executeUpdateUserTask(identifier, rechargeSet);
        return result_map;
    }
}

