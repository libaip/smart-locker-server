/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.agent.model.Tb_statistics;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.StatisticsServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/statistics"})
public class StatisticsController
extends BaseController {
    @Autowired
    private StatisticsServiceImpl statisticsService;

    @RequestMapping(value={"/findStatisticsByParam"})
    @ResponseBody
    public Map<String, Object> findStatisticsByParam(HttpServletRequest request, Tb_statistics statistics, String sr_way) throws Exception {
        this.log.debug("StatisticsInfo================\u67e5\u8be2\u9996\u9875\u7edf\u8ba1\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.statisticsService.findStatisticsByParam(identifier, statistics, sr_way);
        return result_map;
    }

    @RequestMapping(value={"/findLineChartGroupByParam"})
    @ResponseBody
    public Map<String, Object> findLineChartGroupByParam(HttpServletRequest request, Tb_statistics statistics, String sr_way) throws Exception {
        this.log.debug("StatisticsInfo================\u67e5\u8be2\u9996\u9875\u6298\u7ebf\u56fe\u7edf\u8ba1\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.statisticsService.findLineChartGroupByParam(identifier, statistics, sr_way);
        return result_map;
    }

    @RequestMapping(value={"/findLineChartDataByParam"})
    @ResponseBody
    public Map<String, Object> findLineChartDataByParam(HttpServletRequest request, Tb_statistics statistics) throws Exception {
        this.log.debug("StatisticsInfo================\u67e5\u8be2\u5546\u54c1\u5217\u8868");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.statisticsService.findLineChartDataByParam(identifier, statistics);
        return result_map;
    }

    @RequestMapping(value={"/reSetData"})
    @ResponseBody
    public Map<String, Object> reSetData(HttpServletRequest request, Tb_statistics statistics) throws Exception {
        this.log.debug("StatisticsInfo================\u91cd\u65b0\u751f\u6210\u7edf\u8ba1\u6570\u636e");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.statisticsService.reSetData(identifier, statistics);
        return result_map;
    }

    @RequestMapping(value={"/findDepositRateByNet"})
    @ResponseBody
    public Map<String, Object> findDepositRateByNet(HttpServletRequest request, Tb_statistics statistics, Page page) throws Exception {
        this.log.debug("StatisticsInfo================\u7f51\u70b9\u6570\u636e\u6392\u540d");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.statisticsService.findDepositRateByNet(identifier, statistics, page);
        return result_map;
    }
}

