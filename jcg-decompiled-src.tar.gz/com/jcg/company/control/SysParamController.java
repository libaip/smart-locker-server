/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_sys_param
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.service.SysParamServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/sysParam"})
public class SysParamController
extends BaseController {
    @Autowired
    private SysParamServiceImpl sysParamService;

    @RequestMapping(value={"/findSysParamById"})
    @ResponseBody
    public Map<String, Object> getDropDownSelectDataByCate(HttpServletResponse reponse, HttpServletRequest request, String sr_category_code) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> ret = this.sysParamService.findSysParamByCate(identifier, sr_category_code);
        return ret;
    }

    @RequestMapping(value={"/findDropDownInfos"})
    @ResponseBody
    public Map<String, Object> findDropDownInfos(HttpServletRequest request, String sr_login_type) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        String categoryCodes = request.getParameter("categoryCodes") == null ? "" : request.getParameter("categoryCodes");
        Map<String, Object> ret = this.sysParamService.findDropDownInfos(identifier, categoryCodes, sr_login_type);
        return ret;
    }

    @RequestMapping(value={"/findSysPramaByKeyCode"})
    @ResponseBody
    public Map<String, Object> findSysPramaByKeyCode(HttpServletRequest request, String sr_category_code, String sr_key_code) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> ret = this.sysParamService.findSysPramaByKeyCode(identifier, sr_category_code, sr_key_code);
        return ret;
    }

    @RequestMapping(value={"/updateSysParamById"})
    @ResponseBody
    public Map<String, Object> updateSysParamById(HttpServletRequest request, Tb_sys_param sysParam) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> ret = this.sysParamService.updateSysParamById(identifier, sysParam);
        return ret;
    }

    @RequestMapping(value={"/createMenu"})
    @ResponseBody
    public Map<String, Object> createMenu(HttpServletRequest request, String sr_way, String sr_version) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> ret = this.sysParamService.createMenu(identifier, sr_way, sr_version);
        return ret;
    }

    @RequestMapping(value={"/findWxInfo"})
    @ResponseBody
    public Map<String, Object> findWxInfo(HttpServletRequest request) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> ret = this.sysParamService.findWxInfo(identifier);
        return ret;
    }

    @RequestMapping(value={"/excuteNetpointTask"})
    @ResponseBody
    public Map<String, Object> excuteNetpointTask(HttpServletRequest request, Integer sd_netpoint_id) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> ret = this.sysParamService.excuteNetpointTask(identifier, sd_netpoint_id);
        return ret;
    }

    @RequestMapping(value={"/clearSysCache"})
    @ResponseBody
    public Map<String, Object> clearSysCache(HttpServletRequest request) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.sysParamService.clearSysCache(identifier);
        return result_map;
    }
}

