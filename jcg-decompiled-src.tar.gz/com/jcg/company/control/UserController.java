/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.UserServiceImpl;
import com.jcg.user.model.Tb_user;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@RequestMapping(value={"/user"})
@Controller
public class UserController
extends BaseController {
    @Autowired
    private UserServiceImpl userService;

    @RequestMapping(value={"/updateUserById"})
    @ResponseBody
    public Map<String, Object> updateUserById(HttpServletResponse reponse, HttpServletRequest request, Tb_user user) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> ret = this.userService.updateUserById(identifier, user);
        return ret;
    }

    @RequestMapping(value={"/findUserByParam"})
    @ResponseBody
    public Map<String, Object> findUserByParam(HttpServletResponse reponse, HttpServletRequest request, Tb_user user, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> ret = this.userService.findUserByParam(identifier, user, page);
        return ret;
    }

    @RequestMapping(value={"/findUserByModeParam"})
    @ResponseBody
    public Map<String, Object> findUserByModeParam(HttpServletResponse reponse, HttpServletRequest request, Tb_user user, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> ret = this.userService.findUserByModeParam(identifier, user, page);
        return ret;
    }
}

