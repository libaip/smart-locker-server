/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.user.model.Tb_user_recharge
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.UserRechargeServiceImpl;
import com.jcg.user.model.Tb_user_recharge;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/userRecharge"})
public class UserRechargeController
extends BaseController {
    @Autowired
    private UserRechargeServiceImpl userRechargeService;

    @RequestMapping(value={"/findUserRechargeByParam"})
    @ResponseBody
    public Map<String, Object> findUserRechargeByParam(HttpServletRequest request, Tb_user_recharge userRecharge, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.userRechargeService.findUserRechargeByParam(identifier, userRecharge, page);
        return result_map;
    }
}

