/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.user.model.Tb_user_withdrawal_appl
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.common.BaseController;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.UserWithdrawalApplServiceImpl;
import com.jcg.user.model.Tb_user_withdrawal_appl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@RequestMapping(value={"/userWithdrawal"})
@Controller
public class UserWithdrawalApplController
extends BaseController {
    @Autowired
    private UserWithdrawalApplServiceImpl userWithdrawalApplService;

    @RequestMapping(value={"/findUserWithdrawalApplByParam"})
    @ResponseBody
    public Map<String, Object> findUserWithdrawalApplByParam(HttpServletRequest request, Tb_user_withdrawal_appl userWithdrawalAppl, Page page) throws Exception {
        this.log.debug("UserWithdrawalAppl================\u67e5\u8be2\u63d0\u73b0\u8bb0\u5f55");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> result_map = this.userWithdrawalApplService.findUserWithdrawalApplByParam(identifier, userWithdrawalAppl, page);
        return result_map;
    }

    @RequestMapping(value={"/payToUser"})
    @ResponseBody
    public Map<String, Object> payToUser(HttpServletRequest request, Tb_user_withdrawal_appl userWithdrawalAppl) throws Exception {
        this.log.debug("UserWithdrawalAppl================\u67e5\u8be2\u63d0\u73b0\u8bb0\u5f55");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.userWithdrawalApplService.payToUser(identifier, userWithdrawalAppl);
        return result_map;
    }

    @RequestMapping(value={"/userTx"})
    @ResponseBody
    public Map<String, Object> userTx(HttpServletRequest request, Tb_user_withdrawal_appl userWithdrawalAppl) throws Exception {
        this.log.debug("UserWithdrawalAppl================\u67e5\u8be2\u63d0\u73b0\u8bb0\u5f55");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.userWithdrawalApplService.userTx(identifier, userWithdrawalAppl);
        return result_map;
    }
}

