/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cn.hutool.core.date.TimeInterval
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.agent.model.Tb_agent_way
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import cn.hutool.core.date.TimeInterval;
import com.alibaba.fastjson.JSONObject;
import com.jcg.agent.model.Tb_agent_way;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.common.BaseController;
import com.jcg.company.service.AgentServiceImpl;
import com.jcg.company.service.AgentWayServiceImpl;
import com.jcg.company.service.OrderServiceImpl;
import com.jcg.company.service.WebServiceImpl;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/webapi"})
public class WebApiController
extends BaseController {
    @Autowired
    private WebServiceImpl webService;
    @Autowired
    private AgentWayServiceImpl agentWayService;
    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private AgentServiceImpl agentService;

    @RequestMapping(value={"/findOrderByWeb"})
    @ResponseBody
    public Map<String, Object> findOrderByWeb(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("webapi================\u67e5\u8be2\u8ba2\u5355\u5217\u8868");
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> rtnMap = new HashMap();
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        int result = 0;
        List<Object> orderList = new ArrayList<Tb_order>();
        int total = 0;
        if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_order_time_start())) {
            order.setSr_order_time_start(XcbDateUtil.getStartDay((String)order.getSr_order_time_start()));
        }
        if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_order_time_end())) {
            order.setSr_order_time_end(XcbDateUtil.getEndDay((String)order.getSr_order_time_end()));
        }
        if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_iphone_num())) {
            order.setSr_iphone_num(order.getSr_iphone_num().replaceAll("\\s*", ""));
        }
        if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_alias_desc())) {
            order.setSr_alias_desc(order.getSr_alias_desc().toUpperCase());
        }
        String url = "";
        TimeInterval queryTime = new TimeInterval();
        queryTime.start();
        try {
            url = "http://localhost:8080/jcgweb-company/order/findAllOrderByParam";
            rtnMap = this.orderService.findAllOrderByParam(identifier, order);
            result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                Map dataMap = (Map)rtnMap.get(XcbConstantValue.DATA);
                orderList = (List)dataMap.get("orders");
                Page page = (Page)dataMap.get("page");
                total = page.getTotal();
            }
            System.out.println("\u667a\u5b58\u67e5\u8be2:" + queryTime.intervalPretty());
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.exceptionToString((Exception)e));
        }
        Page page = new Page();
        page.setTotal(total);
        queryTime = new TimeInterval();
        queryTime.start();
        WebApiController.SortOrder(orderList);
        System.out.println("\u5408\u5e76\u6392\u5e8f\u65f6\u95f4:" + queryTime.intervalPretty());
        HashMap<String, ArrayList<Object>> data = new HashMap<String, ArrayList<Object>>();
        data.put("orders", (ArrayList<Object>)orderList);
        data.put("page", (ArrayList<Object>)page);
        result_map.put(XcbConstantValue.DATA, data);
        result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        result_map.put(XcbConstantValue.MSG, "\u67e5\u8be2\u6210\u529f");
        return result_map;
    }

    @RequestMapping(value={"/findAgentWayByWeb"})
    @ResponseBody
    public Map<String, Object> findAgentWayByWeb(HttpServletRequest request, Tb_agent_way agentWay) throws Exception {
        this.log.debug("webapi================\u67e5\u8be2\u5546\u5bb6\u5217\u8868");
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> rtnMap = new HashMap();
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        int result = 0;
        String url = "https://platform2.cqdyxl.com/jcgweb-company/agentWay/findAgentWayByName";
        rtnMap = this.webService.findAgentWayByWeb(identifier, url, agentWay);
        result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            Map dataMap = (Map)rtnMap.get(XcbConstantValue.DATA);
            result_map.put(XcbConstantValue.DATA, dataMap);
        }
        result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        result_map.put(XcbConstantValue.MSG, "\u67e5\u8be2\u6210\u529f");
        return result_map;
    }

    @RequestMapping(value={"/updateAgentWayByWeb"})
    @ResponseBody
    public Map<String, Object> updateAgentWayByWeb(HttpServletRequest request, Tb_agent_way agentWay) throws Exception {
        this.log.debug("webapi================\u67e5\u8be2\u5546\u5bb6\u5217\u8868");
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> rtnMap = new HashMap();
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        int result = 0;
        String url = "https://platform2.cqdyxl.com/jcgweb-company/agentWay/updateAgentWayByWeb";
        rtnMap = this.webService.updateAgentWayByWeb(identifier, url, agentWay);
        result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            rtnMap = this.webService.updateAgentWayByName(identifier, url, agentWay);
            Map dataMap = (Map)rtnMap.get(XcbConstantValue.DATA);
            result_map.put(XcbConstantValue.DATA, dataMap);
        }
        result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        result_map.put(XcbConstantValue.MSG, "\u67e5\u8be2\u6210\u529f");
        return result_map;
    }

    @RequestMapping(value={"/createAgentWay"})
    @ResponseBody
    public Map<String, Object> createAgentWay(HttpServletRequest request) throws Exception {
        this.log.debug("webapi================\u65b0\u589e\u5546\u5bb6\u767b\u5f55\u914d\u7f6e");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = new HashMap<String, Object>();
        BufferedReader bufferReader = request.getReader();
        StringBuffer sb = new StringBuffer();
        String line = "";
        while ((line = bufferReader.readLine()) != null) {
            sb.append(line);
        }
        String postData = sb.toString();
        if (!XcbStringUtils.isNullOrBlank((Object)postData)) {
            JSONObject json = JSONObject.parseObject((String)postData);
            String sr_user_name = (String)json.get("sr_user_name");
            String sr_old_user_name = (String)json.get("sr_old_user_name");
            String sr_way = (String)json.get("sr_way");
            String sr_remark = (String)json.get("sr_remark");
            Tb_agent_way agentWay = new Tb_agent_way();
            agentWay.setSr_user_name(sr_user_name);
            agentWay.setSr_old_user_name(sr_old_user_name);
            agentWay.setSr_way(sr_way);
            agentWay.setSr_remark(sr_remark);
            result_map = this.agentWayService.createAgentWay(agentWay);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u53c2\u6570\u4f20\u5165\u9519\u8bef");
        }
        return result_map;
    }

    public static void SortOrder(List<Tb_order> list) {
        list.sort(Comparator.comparing(Tb_order::getTm_create_time).reversed());
    }
}

