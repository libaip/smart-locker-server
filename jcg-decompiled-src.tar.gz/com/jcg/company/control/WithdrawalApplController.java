/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.agent.model.Tb_withdrawal_appl
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_sys_param
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.company.control;

import com.alibaba.fastjson.JSONObject;
import com.jcg.agent.model.Tb_withdrawal_appl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.common.BaseController;
import com.jcg.company.common.ExportToExcel;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.service.SysParamServiceImpl;
import com.jcg.company.service.WebServiceImpl;
import com.jcg.company.service.WithdrawalApplServiceImpl;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/withdrawal"})
public class WithdrawalApplController
extends BaseController {
    @Autowired
    private WithdrawalApplServiceImpl withdrawalApplService;
    @Autowired
    private SysParamServiceImpl sysParamService;
    @Autowired
    private WebServiceImpl webService;

    @RequestMapping(value={"/findWithdrawalApplByWeb"})
    @ResponseBody
    public Map<String, Object> findWithdrawalApplByWeb(HttpServletRequest request, Tb_withdrawal_appl withdrawalAppl) throws Exception {
        this.log.debug("webapi================\u67e5\u8be2\u63d0\u73b0\u5217\u8868");
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        Map<Object, Object> rtnMap = new HashMap();
        int result = 0;
        ArrayList<Tb_withdrawal_appl> applList = new ArrayList<Tb_withdrawal_appl>();
        int total = 0;
        String url = "";
        try {
            url = "https://platform2.cqdyxl.com/jcgweb-company/withdrawal/findAllWithdrawalApplByParam";
            rtnMap = this.webService.findWithdrawalApplByWeb(identifier, withdrawalAppl, url);
            result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                Map dataMap = (Map)rtnMap.get(XcbConstantValue.DATA);
                List list = (List)dataMap.get("applList");
                Page page = (Page)dataMap.get("page");
                total = page.getTotal();
                applList.addAll(list);
            }
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.exceptionToString((Exception)e));
        }
        Page page = new Page();
        page.setTotal(total);
        WithdrawalApplController.SortOrder(applList);
        HashMap<String, ArrayList<Object>> data = new HashMap<String, ArrayList<Object>>();
        data.put("applList", applList);
        data.put("page", (ArrayList<Object>)page);
        result_map.put(XcbConstantValue.DATA, data);
        result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        result_map.put(XcbConstantValue.MSG, "\u67e5\u8be2\u6210\u529f");
        return result_map;
    }

    public static void SortOrder(List<Tb_withdrawal_appl> list) {
        list.sort(Comparator.comparing(Tb_withdrawal_appl::getTm_create_time).reversed());
    }

    @RequestMapping(value={"/findWithdrawalApplByParam"})
    @ResponseBody
    public Map<String, Object> findWithdrawalApplByParam(HttpServletRequest request, Tb_withdrawal_appl withdrawalAppl, Page page) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.withdrawalApplService.findWithdrawalApplByParam(identifier, withdrawalAppl, page);
        return result_map;
    }

    @RequestMapping(value={"/findAllWithdrawalApplByParam"})
    @ResponseBody
    public Map<String, Object> findAllWithdrawalApplByParam(HttpServletRequest request) throws Exception {
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = new HashMap<String, Object>();
        BufferedReader bufferReader = request.getReader();
        StringBuffer sb = new StringBuffer();
        String line = "";
        while ((line = bufferReader.readLine()) != null) {
            sb.append(line);
        }
        String postData = sb.toString();
        if (!XcbStringUtils.isNullOrBlank((Object)postData)) {
            JSONObject json = JSONObject.parseObject((String)postData);
            Integer sw_agent_id = (Integer)json.get("sw_agent_id");
            String sr_type = (String)json.get("sr_type");
            String sr_way = (String)json.get("sr_way");
            String sr_status = (String)json.get("sr_status");
            String sr_province = (String)json.get("sr_province");
            String sr_city = (String)json.get("sr_city");
            String sr_street = (String)json.get("sr_street");
            String sr_district = (String)json.get("sr_district");
            String sr_create_time_start = (String)json.get("sr_create_time_start");
            String sr_create_time_end = (String)json.get("sr_create_time_end");
            if (XcbStringUtils.isNullOrBlank((Object)sr_create_time_start) && XcbStringUtils.isNullOrBlank((Object)sr_create_time_end)) {
                sr_create_time_start = XcbDateUtil.getBeforeDay((Date)new Date(), (int)30, (String)"yyyy-MM-dd");
                sr_create_time_end = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd");
            }
            Tb_withdrawal_appl withdrawalAppl = new Tb_withdrawal_appl();
            withdrawalAppl.setSw_agent_id(sw_agent_id);
            withdrawalAppl.setSr_type(sr_type);
            withdrawalAppl.setSr_way(sr_way);
            withdrawalAppl.setSr_status(sr_status);
            withdrawalAppl.setSr_province(sr_province);
            withdrawalAppl.setSr_city(sr_city);
            withdrawalAppl.setSr_street(sr_street);
            withdrawalAppl.setSr_district(sr_district);
            withdrawalAppl.setSr_create_time_start(sr_create_time_start);
            withdrawalAppl.setSr_create_time_end(sr_create_time_end);
            result_map = this.withdrawalApplService.findAllWithdrawalApplByParam(identifier, withdrawalAppl);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u53c2\u6570\u4f20\u5165\u9519\u8bef");
        }
        return result_map;
    }

    @RequestMapping(value={"/findWithdrawalApplById"})
    @ResponseBody
    public Map<String, Object> findWithdrawalApplById(HttpServletRequest request, Integer sd_id) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.withdrawalApplService.findWithdrawalApplById(identifier, sd_id);
        return result_map;
    }

    @RequestMapping(value={"/updateWithdrawalAppl"})
    @ResponseBody
    public Map<String, Object> updateWithdrawalAppl(HttpServletRequest request, Tb_withdrawal_appl withdrawalAppl) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.withdrawalApplService.updateWithdrawalAppl(identifier, withdrawalAppl);
        return result_map;
    }

    @RequestMapping(value={"/payToAgent"})
    @ResponseBody
    public Map<String, Object> payToAgent(HttpServletRequest request, Tb_withdrawal_appl withdrawalAppl) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.withdrawalApplService.payToAgent(identifier, withdrawalAppl);
        return result_map;
    }

    public Map<String, Object> createWithdrawalAppl(HttpServletRequest request, Tb_withdrawal_appl withdrawalAppl) {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_name());
        Map<String, Object> result_map = this.withdrawalApplService.createWithdrawalAppl(identifier, withdrawalAppl);
        return result_map;
    }

    @RequestMapping(value={"/expExcelWithdrawal"})
    @ResponseBody
    public Map<String, Object> expExcelWithdrawal(HttpServletRequest request, HttpServletResponse response, Tb_withdrawal_appl withdrawalAppl) throws Exception {
        Tb_cuser c_user = (Tb_cuser)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(c_user.getSd_cuser_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(c_user.getSd_cuser_id());
        identifier.setUserName(c_user.getSr_cuser_name());
        Map<String, Object> maxExpMap = this.sysParamService.findSysParamByKeyCode(identifier, XcbConstantValue.XTCL, XcbConstantValue.EXPMAX);
        Tb_sys_param sysparam = (Tb_sys_param)maxExpMap.get("sysParam");
        Integer maxExpCnt = Integer.valueOf(sysparam.getSr_param_value());
        Page page = new Page();
        page.setStart(0);
        page.setPageSize(maxExpCnt.intValue());
        Map<String, Object> result_map = this.withdrawalApplService.findWithdrawalApplByParam(identifier, withdrawalAppl, page);
        Map dataMap = (Map)result_map.get(XcbConstantValue.DATA);
        List applList = (List)dataMap.get("applList");
        this.genTransExcelFile(request, response, applList);
        return null;
    }

    private void genTransExcelFile(HttpServletRequest request, HttpServletResponse response, List dataList) throws Exception {
        Date currentDt = new Date();
        String StrCurrentDt = XcbDateUtil.formatDate((Date)currentDt, (String)"yyyyMMddHHmmss");
        String filedisplay = StrCurrentDt + "\u63d0\u73b0\u7533\u8bf7.xlsx";
        String title = "\u63d0\u73b0\u7533\u8bf7";
        String titleCode = XcbConstantValue.EXPORT_ZJLS;
        String[] headers = new String[]{"\u6d41\u6c34ID", "\u5546\u5bb6\u540d\u79f0", "\u63d0\u73b0\u7533\u8bf7\u91d1\u989d", "\u5bf9\u516c\u4fe1\u606f", "\u5df2\u63d0\u73b0\u91d1\u989d", "\u63d0\u73b0\u65b9\u5f0f", "\u72b6\u6001", "\u5907\u6ce8", "\u5ba1\u6279\u4eba", "\u5ba1\u6279\u65f6\u95f4", "\u7533\u8bf7\u65f6\u95f4", "\u6253\u6b3e\u6807\u8bb0"};
        String[] fieldNams = new String[]{"rowIndex", "sr_agent_name", "dc_appl_money", "sr_qq", "dc_income_money", "sr_type_desc", "sr_status_desc", "sr_remarks", "sr_appl_person", "sr_appl_time", "sr_create_time", "sr_code"};
        ArrayList cashflowItemFieldList = new ArrayList();
        new ExportToExcel().exportExcel(filedisplay, title, titleCode, headers, fieldNams, dataList, response, null, cashflowItemFieldList);
    }
}

