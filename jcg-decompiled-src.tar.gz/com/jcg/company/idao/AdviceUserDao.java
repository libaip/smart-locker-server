/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_advice_user
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_advice_user;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AdviceUserDao {
    public int createAdviceUser_user(Tb_advice_user var1);

    public List<Tb_advice_user> findById_user(@Param(value="sw_user_id") Integer var1, @Param(value="page") Page var2);

    public int findCountById_user(@Param(value="sw_user_id") Integer var1);

    public Tb_advice_user findById(@Param(value="id") Integer var1);

    public List<Tb_advice_user> findByParam(@Param(value="fi") Tb_advice_user var1, @Param(value="page") Page var2);

    public int findCountByParam(@Param(value="fi") Tb_advice_user var1);

    public int updateById(Tb_advice_user var1);

    public int deleteById(@Param(value="id") Integer var1);
}

