/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface AreaProvinceDao {
    public List<Map<String, Object>> findProvinceById(@Param(value="sd_code") String var1);

    public List<Map<String, Object>> findProvinceAll();
}

