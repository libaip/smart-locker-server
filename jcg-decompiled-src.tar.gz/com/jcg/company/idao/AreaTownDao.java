/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface AreaTownDao {
    public List<Map<String, Object>> findTownById(@Param(value="sr_district_code") String var1);

    public List<Map<String, Object>> findTownAll();
}

