/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_company_authorities
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.company.model.Tb_company_authorities;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface CompanyAuthoritiesDao {
    public int createCompanyAuth(Tb_company_authorities var1);

    public int deleteById(int var1);

    public int deleteByPId(int var1);

    public int batchDeleteById(@Param(value="authArr") String[] var1);

    public int updateById(Tb_company_authorities var1);

    public List<Map<String, Object>> findAll();

    public List<Tb_company_authorities> findAuthsByCuserId(@Param(value="sw_cuser_id") Integer var1);
}

