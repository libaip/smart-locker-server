/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_company
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_company;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface CompanyDao {
    public List<Tb_company> findCompanyAll();

    public int createCompany(Tb_company var1);

    public int updateById(Tb_company var1);

    public List<Tb_company> findCompanyByParams(@Param(value="fi") Tb_company var1, @Param(value="page") Page var2);

    public int findCountCompanyByParams(@Param(value="fi") Tb_company var1);

    public Tb_company findCompanyById(String var1);

    public Tb_company findCompanyByType(String var1);

    public List<Map<String, Object>> findAllCompanyDropDown(@Param(value="sd_company_id") String var1);

    public Tb_company findCompanyForBusinessTask(@Param(value="sd_company_id") String var1);
}

