/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_company_roles_auth
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.company.model.Tb_company_roles_auth;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CompanyRolesAuthDao {
    public List<Tb_company_roles_auth> findByRoleId(@Param(value="sw_roles_id") Integer var1);

    public List<Tb_company_roles_auth> findByAuthId(@Param(value="sw_authority_id") Integer var1);

    public int deleteRoleAuthsByRoleId(@Param(value="sw_roles_id") Integer var1);

    public int deleteRoleAuthsByAuthId(@Param(value="sw_authority_id") Integer var1);

    public int batchDeleteRoleAuthsByAuthId(@Param(value="authArr") String[] var1);

    public int createRoleAuth(Tb_company_roles_auth var1);

    public int insertRoleAuthByBatch(@Param(value="roleAuths") List<Tb_company_roles_auth> var1);
}

