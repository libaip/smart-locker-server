/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_company_roles
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_company_roles;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CompanyRolesDao {
    public int createCompanyRoles(Tb_company_roles var1);

    public int deleteById(int var1);

    public int updateById(Tb_company_roles var1);

    public Tb_company_roles findById(int var1);

    public List<Tb_company_roles> findByParam(@Param(value="fi") Tb_company_roles var1, @Param(value="page") Page var2);

    public int findCntByParam(@Param(value="fi") Tb_company_roles var1);

    public List<Tb_company_roles> findAll(String var1);
}

