/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_company_roles_rel
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.company.model.Tb_company_roles_rel;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CompanyRolesRelDao {
    public int createCompanyRolesRel(Tb_company_roles_rel var1);

    public int deleteById(int var1);

    public int updateById(Tb_company_roles_rel var1);

    public Tb_company_roles_rel findById(int var1);

    public List<Tb_company_roles_rel> findByParam(Tb_company_roles_rel var1);

    public List<Tb_company_roles_rel> findByCuserId(@Param(value="sw_cuser_id") Integer var1);

    public int deleteByCuserId(@Param(value="sw_cuser_id") Integer var1);

    public List<Tb_company_roles_rel> findByRoleId(@Param(value="sw_roles_id") Integer var1);

    public int insertUserRoleByBatch(@Param(value="userRoles") List<Tb_company_roles_rel> var1);
}

