/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_cuser
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_cuser;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface CuserDao {
    public int createCuser(Tb_cuser var1);

    public int updateById(Tb_cuser var1);

    public int updateStsById(Tb_cuser var1);

    public List<Tb_cuser> findCusersByCuser(@Param(value="fi") Tb_cuser var1, @Param(value="page") Page var2);

    public int findCusersCntByCuser(Tb_cuser var1);

    public Tb_cuser findCuserById(int var1);

    public Tb_cuser findCuserByName(String var1);

    public int updatePassword(Tb_cuser var1);

    public List<Map<String, Object>> findAllCuser();

    public Tb_cuser findCompanyInfoById(int var1);

    public int resetPasswordById(Tb_cuser var1);

    public int updateSmsById(Tb_cuser var1);
}

