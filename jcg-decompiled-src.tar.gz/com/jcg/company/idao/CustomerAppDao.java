/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_customer_app
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_customer_app;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CustomerAppDao {
    public int createCustomerApp_user(Tb_customer_app var1);

    public List<Tb_customer_app> findByParam(@Param(value="fi") Tb_customer_app var1, @Param(value="page") Page var2);

    public int findCountByParam(@Param(value="fi") Tb_customer_app var1);

    public int updateById(Tb_customer_app var1);
}

