/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_goods_category
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_goods_category;
import java.util.ArrayList;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface GoodsCategoryDao {
    public int createGoodsCategory(Tb_goods_category var1);

    public int updateGoodsCategory(Tb_goods_category var1);

    public List<Tb_goods_category> findGoodsCategoryByParam(@Param(value="fi") Tb_goods_category var1, @Param(value="page") Page var2);

    public int findCountByParam(Tb_goods_category var1);

    public ArrayList<Tb_goods_category> findAllCates_cpy();
}

