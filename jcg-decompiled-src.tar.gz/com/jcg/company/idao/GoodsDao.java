/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_goods
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_goods;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface GoodsDao {
    public int createGoods(Tb_goods var1);

    public int updateGoods(Tb_goods var1);

    public List<Tb_goods> findGoodsByParam(@Param(value="fi") Tb_goods var1, @Param(value="page") Page var2);

    public int findCountByParam(Tb_goods var1);

    public int findMaxId();

    public Tb_goods findGoodsById(Integer var1);

    public List<Integer> findGoodIdList(Tb_goods var1);

    public List<Tb_goods> findGoodsCartByParam_user(@Param(value="fi") Tb_goods var1);

    public List<Tb_goods> findGoodsByIdArr(@Param(value="goodsArr") Integer[] var1);
}

