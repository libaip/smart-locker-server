/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_operation_logs
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_operation_logs;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OperationLogDao {
    public int createOperaLog(Tb_operation_logs var1);

    public List<Tb_operation_logs> findOperationLogByParam_cpy(@Param(value="fi") Tb_operation_logs var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(Tb_operation_logs var1);
}

