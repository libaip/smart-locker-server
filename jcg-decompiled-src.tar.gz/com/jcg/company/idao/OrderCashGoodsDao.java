/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_ordercash_goods
 */
package com.jcg.company.idao;

import com.jcg.company.model.Tb_ordercash_goods;
import java.util.List;

public interface OrderCashGoodsDao {
    public int batchCreateOrderCashGoods(List<Tb_ordercash_goods> var1);

    public List<Tb_ordercash_goods> findOrderCashByOrderId(String var1);

    public int updateOrderCashById(Tb_ordercash_goods var1);

    public Tb_ordercash_goods findOrderCashGoodsById(Integer var1);
}

