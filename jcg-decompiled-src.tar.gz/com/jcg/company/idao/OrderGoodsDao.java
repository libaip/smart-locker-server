/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_order_goods
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_order_goods;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OrderGoodsDao {
    public int createOrderGoods(Tb_order_goods var1);

    public Tb_order_goods findOrderById(String var1);

    public int updateOrderById(Tb_order_goods var1);

    public List<Tb_order_goods> findOrderGoodsByParam(@Param(value="fi") Tb_order_goods var1, @Param(value="page") Page var2);

    public int findCountByParam(@Param(value="fi") Tb_order_goods var1);

    public List<Tb_order_goods> findOrderGoodsByParam_cpy(@Param(value="fi") Tb_order_goods var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(@Param(value="fi") Tb_order_goods var1);
}

