/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_ordergoods_server
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_ordergoods_server;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OrderGoodsServerDao {
    public int createOrderServer(Tb_ordergoods_server var1);

    public int updateOrderServer(Tb_ordergoods_server var1);

    public List<Tb_ordergoods_server> findOrderServerByParam_cpy(@Param(value="fi") Tb_ordergoods_server var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(@Param(value="fi") Tb_ordergoods_server var1);

    public List<Tb_ordergoods_server> findOrderGoodsServerById(Tb_ordergoods_server var1);

    public Tb_ordergoods_server findServerById(String var1);
}

