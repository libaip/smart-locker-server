/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_package
 */
package com.jcg.company.idao;

import com.jcg.company.model.Tb_package;
import java.util.List;

public interface PackageDao {
    public List<Tb_package> findPackageParam(Tb_package var1);
}

