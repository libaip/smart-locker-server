/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_sys_param
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_sys_param;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface SysParamDao {
    public Tb_sys_param findSysParamByKeyCode(@Param(value="sr_category_code") String var1, @Param(value="sr_key_code") String var2);

    public List<Map<String, Object>> findSysParamAll();

    public List<Tb_sys_param> findSysParamByCate_agent(String var1);

    public List<Map<String, Object>> getDropDownSelectDataByCate(String var1);

    public int updateParamForId(Map<String, Integer> var1);

    public int createSysParam_cpy(Tb_sys_param var1);

    public List<Tb_sys_param> findSysParamByParam_cpy(@Param(value="fi") Tb_sys_param var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(Tb_sys_param var1);

    public int updateById_cpy(Tb_sys_param var1);

    public Tb_sys_param findSysParamById_cpy(int var1);

    public int deleteById_cpy(int var1);

    public int deleteByTypeId_cpy(int var1);

    public List<Tb_sys_param> findSysParamByKeyCode_cpy(Tb_sys_param var1);

    public Map<Object, Object> findSysParamById_user(@Param(value="sr_category_code") String var1, @Param(value="sr_key_code") String var2);

    public List<Tb_sys_param> findSysParamByKeyCodeForBusinessTask(Tb_sys_param var1);
}

