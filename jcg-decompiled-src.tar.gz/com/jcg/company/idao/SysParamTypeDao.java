/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_sys_paramtype
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_sys_paramtype;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface SysParamTypeDao {
    public int createSysParamType(Tb_sys_paramtype var1);

    public List<Tb_sys_paramtype> findSysParamTypeByParam(@Param(value="fi") Tb_sys_paramtype var1, @Param(value="page") Page var2);

    public int findCountByParam(Tb_sys_paramtype var1);

    public int updateById(Tb_sys_paramtype var1);

    public Tb_sys_paramtype findSysParamTypeById(String var1);

    public int deleteById(int var1);

    public List<Map<String, Object>> findAllType();
}

