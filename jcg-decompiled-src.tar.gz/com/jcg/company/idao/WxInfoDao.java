/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_wx_info
 */
package com.jcg.company.idao;

import com.jcg.company.model.Tb_wx_info;
import java.util.List;
import java.util.Map;

public interface WxInfoDao {
    public List<Map<String, Object>> findInfoList();

    public Tb_wx_info findInfoByCode(String var1);

    public int updateWxInfo(Tb_wx_info var1);
}

