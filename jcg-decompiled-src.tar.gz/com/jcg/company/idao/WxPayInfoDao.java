/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_wx_pay_info
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_wx_pay_info;
import org.apache.ibatis.annotations.Param;

public interface WxPayInfoDao {
    public Tb_wx_pay_info findPayInfo(String var1);

    public Tb_company findDefaultPayIn(String var1);

    public Tb_wx_pay_info findDefaultPayOut(String var1);

    public Tb_wx_pay_info findUserDefaultPayOutByCpy(String var1);

    public Tb_company findDefaultPayInByMerid(String var1);

    public Tb_wx_pay_info findNewDefaultPayIn(String var1);

    public Tb_wx_pay_info findNewDefaultPayOut(String var1);

    public Tb_wx_pay_info findUserDefaultPayOut(String var1);

    public Tb_wx_pay_info findPayInfoByWay(@Param(value="sr_way") String var1, @Param(value="sub_mchid") String var2);

    public int updateInfo(Tb_wx_pay_info var1);
}

