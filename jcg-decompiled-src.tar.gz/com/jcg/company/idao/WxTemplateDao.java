/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_wx_template
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.company.idao;

import com.jcg.company.model.Tb_wx_template;
import org.apache.ibatis.annotations.Param;

public interface WxTemplateDao {
    public Tb_wx_template findWxTemplateByType(@Param(value="sr_appid") String var1, @Param(value="sr_type") String var2);
}

