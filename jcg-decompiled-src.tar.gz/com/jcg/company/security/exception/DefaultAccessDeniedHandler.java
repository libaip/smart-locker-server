/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.servlet.ServletException
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  net.sf.json.JSONObject
 *  org.springframework.security.access.AccessDeniedException
 *  org.springframework.security.web.access.AccessDeniedHandler
 */
package com.jcg.company.security.exception;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

public class DefaultAccessDeniedHandler
implements AccessDeniedHandler {
    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
        System.out.println("in DefaultAccessDeniedHandler method...");
        System.out.println(accessDeniedException.getMessage());
        response.setCharacterEncoding("utf-8");
        response.setStatus(403);
        JSONObject json = new JSONObject();
        response.getWriter().write(json.toString());
    }
}

