/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_company_authorities
 *  com.jcg.company.model.Tb_cuser
 *  org.springframework.security.core.authority.SimpleGrantedAuthority
 *  org.springframework.security.core.userdetails.UserDetailsService
 *  org.springframework.security.core.userdetails.UsernameNotFoundException
 */
package com.jcg.company.security.service;

import com.jcg.common.model.BusinessException;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.model.Tb_company_authorities;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.service.CuserServiceImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class JwtUserDetailsServiceImpl
implements UserDetailsService {
    CuserServiceImpl cuserService = new CuserServiceImpl();

    public Tb_cuser loadUserByUsername(String username) throws UsernameNotFoundException {
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("username", username);
        Tb_cuser cuser = null;
        try {
            Identifier identifier = new Identifier();
            Map<String, Object> resMap = this.cuserService.findbyCuserName(username);
            if (XcbConstantValue.OPERA_SUCCESS.equals(resMap.get(XcbConstantValue.STATUS))) {
                cuser = (Tb_cuser)resMap.get(XcbConstantValue.DATA);
                identifier.setUserId(cuser.getSd_cuser_id());
                identifier.setUserName(cuser.getSr_cuser_name());
            }
            if (cuser != null) {
                ArrayList<SimpleGrantedAuthority> authList = new ArrayList<SimpleGrantedAuthority>();
                List<Tb_company_authorities> list = this.selectAuthoritiesByUserId(identifier, cuser.getSd_cuser_id());
                if (list != null && list.size() > 0) {
                    for (int i = 0; i < list.size(); ++i) {
                        Tb_company_authorities auth = list.get(i);
                        authList.add(new SimpleGrantedAuthority(auth.getSr_authcode().toUpperCase()));
                    }
                }
                authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
                cuser.setUserInfoRoles(authList);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return cuser;
    }

    public List<Tb_company_authorities> selectAuthoritiesByUserId(Identifier identifier, Integer userId) {
        List<Object> authoritiesList = new ArrayList<Tb_company_authorities>();
        try {
            Map<String, Object> res = this.cuserService.findUserAuthsByUserId(identifier, userId.toString());
            if (res != null && res.get(XcbConstantValue.STATUS).equals(XcbConstantValue.OPERA_SUCCESS)) {
                authoritiesList = (List)res.get(XcbConstantValue.DATA);
            }
        }
        catch (Exception e) {
            throw new BusinessException("\u7528\u6237\u7ba1\u7406", (Throwable)e);
        }
        return authoritiesList;
    }
}

