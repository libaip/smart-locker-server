/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_advice_user
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import com.jcg.company.model.Tb_advice_user;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class AdviceUserServiceImpl
extends BaseService {
    public Map<String, Object> findAdviceUserByParam(Identifier identifier, Tb_advice_user adviceUser, Page page) {
        identifier.setFunctionCode(XcbConstantValue.ADVICEUSER_FINDBYPARAM);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("adviceUser", adviceUser);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAdviceUser(Identifier identifier, Tb_advice_user adviceUser) {
        identifier.setFunctionCode(XcbConstantValue.ADVICEUSER_UPDATE);
        HashMap<String, Tb_advice_user> param = new HashMap<String, Tb_advice_user>();
        param.put("adviceUser", adviceUser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

