/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_agent;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import com.jcg.company.vo.LoginUser;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class AgentServiceImpl
extends BaseService {
    public Map<String, Object> login(Identifier identifier, LoginUser loginUser) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_LOGIN_CPY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sr_user_name", loginUser.getUsername());
        param.put("sr_password", loginUser.getPassword());
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findbyUserName(String sr_user_name) throws Exception {
        Identifier identifier = new Identifier();
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_BY_USERNAME_CPY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sr_user_name", sr_user_name);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createAgent(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_CREATE_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAgentByParam(Identifier identifier, Tb_agent agent, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("agent", agent);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAgentMoneyByParam(Identifier identifier, Tb_agent agent, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_MONEY_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("agent", agent);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findStaffByParam(Identifier identifier, Tb_agent agent, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_STAFF_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("agent", agent);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAgentForShare(Identifier identifier, Tb_agent agent, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_FOR_SHARE_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("agent", agent);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAgentById(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_UPDATE_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAgentStsById(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_UPDATE_STS_BYID_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAgentById(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_BYID_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllAgentById(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_BYUPAGENT_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findUpAgentByParam(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_UPAGENT_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAgentStatusById(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_UPDATE_STS_BYID_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> resetAgentPasswordById(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_RESET_PASSWORD_BYID_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> validateAgentUsername(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_VALIDATE_USERNAME_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> validateDistinctAgent(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_VALIDATE_AGENTEXIST_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> genCode(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_GENCODE_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAgentByAreaCode(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_FIND_BYAREACODE_CPY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAgentAd(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_UPDATE_AD_MONEY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAgentWay(Identifier identifier, Tb_agent agent) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_UPDATE_AGENT_WAY);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> identity_certificate(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_IDENTITY_CERTIFICATE);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> binding(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_IDENTITY_BINDING);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> bindingCpy(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_IDENTITY_BINDING_OPEN);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> unbinding(Identifier identifier, Tb_agent agent) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AGENT_IDENTITY_UNBINDING);
        HashMap<String, Tb_agent> param = new HashMap<String, Tb_agent>();
        param.put("agent", agent);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

