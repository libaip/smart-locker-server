/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent_way
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_agent_way;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class AgentWayServiceImpl
extends BaseService {
    public Map<String, Object> createAgentWay(Tb_agent_way agentWay) throws Exception {
        Identifier identifier = new Identifier();
        identifier.setFunctionCode(XcbConstantValue.AGENT_WAY_CREATE);
        HashMap<String, Tb_agent_way> param = new HashMap<String, Tb_agent_way>();
        param.put("agentWay", agentWay);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAgentWayByName(Identifier identifier, Tb_agent_way agentWay) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_WAY_FIND_BYNAME);
        HashMap<String, Tb_agent_way> param = new HashMap<String, Tb_agent_way>();
        param.put("agentWay", agentWay);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAgentWayByName(Identifier identifier, Tb_agent_way agentWay) {
        identifier.setFunctionCode(XcbConstantValue.AGENT_WAY_UPDATE_BYNAME);
        HashMap<String, Tb_agent_way> param = new HashMap<String, Tb_agent_way>();
        param.put("agentWay", agentWay);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

