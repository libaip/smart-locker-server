/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_cuser
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_cuser;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class CompanyServiceImpl
extends BaseService {
    public Map<String, Object> findCompanyById(Identifier identifier, String sd_company_id) {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_FIND_BYID);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_company_id", sd_company_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateById(Identifier identifier, Tb_company company) {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_UPDATE_BYID);
        HashMap<String, Tb_company> param = new HashMap<String, Tb_company>();
        param.put("company", company);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> getV3Serialno(Identifier identifier, String sr_mchid) {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_GET_V3);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sr_mchid", sr_mchid);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createCompany(Identifier identifier, Tb_company company, Tb_cuser cuser) {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_CREATE);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("company", company);
        param.put("cuser", cuser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findCompanyByParam(Identifier identifier, Tb_company company, Tb_cuser cuser, Page page) {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_FIND_BYPARAMS);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("company", company);
        param.put("cuser", cuser);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllCompanyDropDown(Identifier identifier, Tb_company company, Tb_cuser cuser) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_FIND_ALL);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("company", company);
        param.put("cuser", cuser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findComanyParamCache(Identifier identifier, String sd_company_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_PARAM_CACHE);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sd_company_id", sd_company_id);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Map<String, Object> findCompanyByMerId(Identifier identifier, String sr_wx_mer_id) {
        identifier.setFunctionCode(XcbConstantValue.COMPANY_FIND_BYMERID);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_wx_mer_id", sr_wx_mer_id);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }
}

