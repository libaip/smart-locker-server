/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_cuser
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.vo.LoginUser;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class CuserServiceImpl
extends BaseService {
    public Map<String, Object> findCuserByParam(Identifier identifier, Tb_cuser cuser, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.CUSER_FIND_BYPARAM);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("cuser", cuser);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findCuserById(Identifier identifier, String sd_cuser_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.CUSER_FIND_BYID);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_cuser_id", sd_cuser_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createCuser(Identifier identifier, Tb_cuser cuser) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.CUSER_CREATE);
        HashMap<String, Tb_cuser> param = new HashMap<String, Tb_cuser>();
        param.put("cuser", cuser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateCuserById(Identifier identifier, Tb_cuser cuser) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.CUSER_UPDATE_BYID);
        HashMap<String, Tb_cuser> param = new HashMap<String, Tb_cuser>();
        param.put("cuser", cuser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateCuserStsById(Identifier identifier, Tb_cuser cuser) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.CUSER_UPDATE_STS_BYID);
        HashMap<String, Tb_cuser> param = new HashMap<String, Tb_cuser>();
        param.put("cuser", cuser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> login(Identifier identifier, LoginUser loginUser) {
        identifier.setFunctionCode(XcbConstantValue.CUSER_LOGIN);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sr_cuser_name", loginUser.getUsername());
        param.put("sr_password", loginUser.getPassword());
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findbyCuserName(String sr_cuser_name) throws Exception {
        Identifier identifier = new Identifier();
        identifier.setFunctionCode(XcbConstantValue.CUSER_FIND_BY_USERNAME);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sr_cuser_name", sr_cuser_name);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updatePassword(Identifier identifier, Tb_cuser cuser) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.CUSER_UPDATE_PASSWORD);
        HashMap<String, Tb_cuser> param = new HashMap<String, Tb_cuser>();
        param.put("cuser", cuser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> validateCuserUsername(Identifier identifier, Tb_cuser cuser) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.CUSER_VALIDATE_USERNAME);
        HashMap<String, Tb_cuser> param = new HashMap<String, Tb_cuser>();
        param.put("cuser", cuser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findUserRolesByUserId(Identifier identifier, String sd_cuser_id) {
        identifier.setFunctionCode(XcbConstantValue.CUSER_ROLE_FIND_BYUSERID);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_cuser_id", sd_cuser_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findUserAuthsByUserId(Identifier identifier, String sd_cuser_id) {
        identifier.setFunctionCode(XcbConstantValue.CUSER_AUTH_FIND_BYUSERID);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_cuser_id", sd_cuser_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateUserRolesByUserId(Identifier identifier, String sd_cuser_id, String[] roleArr) {
        identifier.setFunctionCode(XcbConstantValue.CUSER_ROLE_UPDATE_BYUSERID);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("sd_cuser_id", sd_cuser_id);
        param.put("roleArr", roleArr);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllCuser(Identifier identifier) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.CUSER_FIND_ALL);
        HashMap param = new HashMap();
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> resetCuserPasswordById(Identifier identifier, Tb_cuser cuser) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.CUSER_RESET_PASSWORD_BYID);
        HashMap<String, Tb_cuser> param = new HashMap<String, Tb_cuser>();
        param.put("cuser", cuser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> sendSms(Identifier identifier, Tb_cuser cuser) {
        identifier.setFunctionCode(XcbConstantValue.CUSER_SEND_SMS);
        HashMap<String, Tb_cuser> param = new HashMap<String, Tb_cuser>();
        param.put("cuser", cuser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

