/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_customer_app
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import com.jcg.company.model.Tb_customer_app;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class CustomerAppServiceImpl
extends BaseService {
    public Map<String, Object> findCustomerAppByParam(Identifier identifier, Tb_customer_app customer_app, Page page) {
        identifier.setFunctionCode(XcbConstantValue.CUSTOMERAPP_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("customer_app", customer_app);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateCustomerAppById(Identifier identifier, Tb_customer_app customer_app) {
        identifier.setFunctionCode(XcbConstantValue.CUSTOMERAPP_UPDATE_BYID_CPY);
        HashMap<String, Tb_customer_app> param = new HashMap<String, Tb_customer_app>();
        param.put("customer_app", customer_app);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

