/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_deposit_share
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_deposit_share;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DepositShareServiceImpl
extends BaseService {
    public Map<String, Object> createDepositShare(Identifier identifier, Tb_deposit_share share) {
        identifier.setFunctionCode(XcbConstantValue.DEPOSIT_SHARE_CREATE);
        HashMap<String, Tb_deposit_share> param = new HashMap<String, Tb_deposit_share>();
        param.put("share", share);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDepositShareByParam(Identifier identifier, Tb_deposit_share share, Page page) {
        identifier.setFunctionCode(XcbConstantValue.DEPOSIT_SHARE_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("share", share);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateDepositShare(Identifier identifier, Tb_deposit_share share) {
        identifier.setFunctionCode(XcbConstantValue.DEPOSIT_SHARE_UPDATE);
        HashMap<String, Tb_deposit_share> param = new HashMap<String, Tb_deposit_share>();
        param.put("share", share);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

