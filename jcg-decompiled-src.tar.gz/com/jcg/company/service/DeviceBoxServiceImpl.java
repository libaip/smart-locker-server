/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DeviceBoxServiceImpl
extends BaseService {
    public Map<String, Object> createDeviceBox(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_CREATE);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> batchCreateBox(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_BATCH_CREATE);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDeviceBoxByDeviceId(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_FIND_BYDEVICEID);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDeviceBoxById(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_FIND_BYARRID);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> batchUpdateDeviceBoxById(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_UPDATE_BATCH);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("deviceBox", deviceBox);
        param.put("sr_way", "CPY");
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateDeviceBoxById(Identifier identifier, List<Tb_device_box> deviceBoxList) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_UPDATE_BYID);
        HashMap<String, List<Tb_device_box>> param = new HashMap<String, List<Tb_device_box>>();
        param.put("deviceBoxList", deviceBoxList);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateDeviceBox(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_UPDATE_BYID_AGENTMB);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> deleteDeviceBox(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_DELETE);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> batchDeleteDeviceBox(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_BATCH_DELETE);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findBoardList(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_FIND_BOARD_LIST);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findBoxListByWeb(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_FIND_LIST_WEB);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

