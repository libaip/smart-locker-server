/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DeviceCloudServiceImpl
extends BaseService {
    public Map<String, Object> openLock(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_OPENLOCK_CPY);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> openAllLock(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_OPEN_ALL_LOCK_CPY);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> getState(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_GET_STATE_AGENT);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateApp(Identifier identifier, Tb_device device) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_UPDATE_APP);
        HashMap<String, Tb_device> param = new HashMap<String, Tb_device>();
        param.put("device", device);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> reboot(Identifier identifier, Tb_device device) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_REBOOT);
        HashMap<String, Tb_device> param = new HashMap<String, Tb_device>();
        param.put("device", device);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> refreshApp(Identifier identifier, String sw_mainboard_id) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_REFRESH);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sw_mainboard_id", sw_mainboard_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> refreshLock(Identifier identifier, String sw_mainboard_id) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_REFRESH_DOOR);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sw_mainboard_id", sw_mainboard_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> getCoverPicture(Identifier identifier, String sw_mainboard_id) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_GET_COVER_PICTURE);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sw_mainboard_id", sw_mainboard_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> refreshAll(Identifier identifier, Integer sw_netpoint_id) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_REFRESH_ALL);
        HashMap<String, Integer> param = new HashMap<String, Integer>();
        param.put("sw_netpoint_id", sw_netpoint_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> getSimInfo(Identifier identifier, String sw_mainboard_id) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_GET_SIM);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sw_mainboard_id", sw_mainboard_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> readMchid(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_GET_MCUID);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

