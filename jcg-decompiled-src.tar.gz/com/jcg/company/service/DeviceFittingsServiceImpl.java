/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_fittings
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_device_fittings;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DeviceFittingsServiceImpl
extends BaseService {
    public Map<String, Object> createFittings(Identifier identifier, Tb_device_fittings fittings) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FITTINGS_CREATE);
        HashMap<String, Tb_device_fittings> param = new HashMap<String, Tb_device_fittings>();
        param.put("fittings", fittings);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findFittingsByBoxId(Identifier identifier, Tb_device_fittings fittings) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FITTINGS_FIND_BYBOXID);
        HashMap<String, Tb_device_fittings> param = new HashMap<String, Tb_device_fittings>();
        param.put("fittings", fittings);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findMaxFittings(Identifier identifier, Tb_device_fittings fittings) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FITTINGS_FIND_MAX);
        HashMap<String, Tb_device_fittings> param = new HashMap<String, Tb_device_fittings>();
        param.put("fittings", fittings);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> deleteFittingsById(Identifier identifier, Tb_device_fittings fittings) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FITTINGS_DELETE_BYID);
        HashMap<String, Tb_device_fittings> param = new HashMap<String, Tb_device_fittings>();
        param.put("fittings", fittings);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateFittingsById(Identifier identifier, Tb_device_fittings fittings) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FITTINGS_UPDATE_BYID);
        HashMap<String, Tb_device_fittings> param = new HashMap<String, Tb_device_fittings>();
        param.put("fittings", fittings);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

