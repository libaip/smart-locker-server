/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_device_package;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DevicePackageServiceImpl
extends BaseService {
    public Map<String, Object> createDevicePackage(Identifier identifier, Tb_device_package devicePackage) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_PACKAGE_CREATE);
        HashMap<String, Tb_device_package> param = new HashMap<String, Tb_device_package>();
        param.put("devicePackage", devicePackage);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDevicePackageByDeviceId(Identifier identifier, Tb_device_package devicePackage, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_PACKAGE_FIND_BYDEVICEID);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("devicePackage", devicePackage);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateDevicePackageById(Identifier identifier, List<Tb_device_package> devicePackageList) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_PACKAGE_UPDATE);
        HashMap<String, List<Tb_device_package>> param = new HashMap<String, List<Tb_device_package>>();
        param.put("devicePackageList", devicePackageList);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateDevicePackageByBatch(Identifier identifier, List<Tb_device_package> devicePackageList) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_PACKAGE_UPDATE_BATCH);
        HashMap<String, List<Tb_device_package>> param = new HashMap<String, List<Tb_device_package>>();
        param.put("devicePackageList", devicePackageList);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

