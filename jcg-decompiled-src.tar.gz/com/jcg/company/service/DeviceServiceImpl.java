/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_device;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DeviceServiceImpl
extends BaseService {
    public Map<String, Object> createDevice(Identifier identifier, Tb_device device) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CREATE_CPY);
        HashMap<String, Tb_device> param = new HashMap<String, Tb_device>();
        param.put("device", device);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDeviceByParam(Identifier identifier, Tb_device device, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("device", device);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDeviceDetailById(Identifier identifier, Tb_device device) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FIND_BYID_CPY);
        HashMap<String, Tb_device> param = new HashMap<String, Tb_device>();
        param.put("device", device);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDropDownDeviceByAgentId(Identifier identifier, Tb_device device) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FIND_BYAGENTID_CPY);
        HashMap<String, Tb_device> param = new HashMap<String, Tb_device>();
        param.put("device", device);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateDeviceStsById(Identifier identifier, Tb_device device) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_UPDATE_STS_BYID_CPY);
        HashMap<String, Tb_device> param = new HashMap<String, Tb_device>();
        param.put("device", device);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateDeviceById(Identifier identifier, Tb_device device) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_UPDATE_BYID_CPY);
        HashMap<String, Tb_device> param = new HashMap<String, Tb_device>();
        param.put("device", device);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> genCode(Identifier identifier, Tb_device device) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_GENCODE_CPY);
        HashMap<String, Tb_device> param = new HashMap<String, Tb_device>();
        param.put("device", device);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> validateDeviceMainboard(Identifier identifier, Tb_device device) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_VALIDATE_MAINBOARD);
        HashMap<String, Tb_device> param = new HashMap<String, Tb_device>();
        param.put("device", device);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDeviceByNetpointId(Identifier identifier, Tb_device device) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FIND_BYNETID_CPY);
        HashMap<String, Tb_device> param = new HashMap<String, Tb_device>();
        param.put("device", device);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

