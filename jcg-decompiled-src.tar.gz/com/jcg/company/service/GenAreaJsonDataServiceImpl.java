/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class GenAreaJsonDataServiceImpl
extends BaseService {
    public Map<String, Object> findAreaJsonDataByParam(Identifier identifier, String sd_code) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.AREA_JSONDATA_FIND_BYPARAM_CPY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_code", sd_code);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

