/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_goods_category
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import com.jcg.company.model.Tb_goods_category;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class GoodsCategoryServiceImpl
extends BaseService {
    public Map<String, Object> createGoodsCategory(Identifier identifier, Tb_goods_category category) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_CATEGORY_CREATE_CPY);
        HashMap<String, Tb_goods_category> param = new HashMap<String, Tb_goods_category>();
        param.put("category", category);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findGoodsCategoryByParam(Identifier identifier, Tb_goods_category category, Page page) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_CATEGORY_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("category", category);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateGoodsCategory(Identifier identifier, Tb_goods_category category) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_CATEGORY_UPDATE_BYID_CPY);
        HashMap<String, Tb_goods_category> param = new HashMap<String, Tb_goods_category>();
        param.put("category", category);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllCatesCoverPic(Identifier identifier) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_CATEGORY_ALL_COVERPIC_CPY);
        HashMap param = new HashMap();
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

