/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_goods
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import com.jcg.company.model.Tb_goods;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class GoodsServiceImpl
extends BaseService {
    public Map<String, Object> createGoods(Identifier identifier, Tb_goods goods) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_CREATE_CPY);
        HashMap<String, Tb_goods> param = new HashMap<String, Tb_goods>();
        param.put("goods", goods);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findGoodsByParam(Identifier identifier, Tb_goods goods, Page page) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("goods", goods);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateGoods(Identifier identifier, Tb_goods goods) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_UPDATE_BYID_CPY);
        HashMap<String, Tb_goods> param = new HashMap<String, Tb_goods>();
        param.put("goods", goods);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllCates(Identifier identifier) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_CATEGORY_ALL_CPY);
        HashMap param = new HashMap();
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findMaxId(Identifier identifier, Tb_goods goods) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_FIND_MAX_ID);
        HashMap param = new HashMap();
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

