/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_net_photo
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_net_photo;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class NetPhotoServiceImpl
extends BaseService {
    public Map<String, Object> createNetPhoto(Identifier identifier, Tb_net_photo netPhoto) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPHOTO_CREATE_CPY);
        HashMap<String, Tb_net_photo> param = new HashMap<String, Tb_net_photo>();
        param.put("netPhoto", netPhoto);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findNetPhotoByNetId(Identifier identifier, String sw_netpoint_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPHOTO_FIND_BYNETID_CPY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sw_netpoint_id", sw_netpoint_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> deleteNetPhotoById(Identifier identifier, String sd_net_photo_id, String sr_photo_addreess) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPHOTO_DELETE_CPY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_net_photo_id", sd_net_photo_id);
        param.put("sr_photo_addreess", sr_photo_addreess);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

