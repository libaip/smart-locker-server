/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_netpoint
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_netpoint;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class NetPointServiceImpl
extends BaseService {
    public Map<String, Object> createNetPoint(Identifier identifier, Tb_netpoint netpoint) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_CREATE_CPY);
        HashMap<String, Tb_netpoint> param = new HashMap<String, Tb_netpoint>();
        param.put("netpoint", netpoint);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findNetPointByParam(Identifier identifier, Tb_netpoint netpoint, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("netpoint", netpoint);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDropDownNetpointByAgentId(Identifier identifier, Integer sd_agent_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_FIND_BYAGENTID_CPY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_agent_id", sd_agent_id.toString());
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findNetPointById(Identifier identifier, Tb_netpoint netpoint) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_FIND_BYID_CPY);
        HashMap<String, Tb_netpoint> param = new HashMap<String, Tb_netpoint>();
        param.put("netpoint", netpoint);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateNetPointById(Identifier identifier, Tb_netpoint netpoint) {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_UPDATE_BYID_CPY);
        HashMap<String, Tb_netpoint> param = new HashMap<String, Tb_netpoint>();
        param.put("netpoint", netpoint);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateNetStsById(Identifier identifier, Tb_netpoint netpoint) {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_UPDATE_BYID_CPY);
        HashMap<String, Tb_netpoint> param = new HashMap<String, Tb_netpoint>();
        param.put("netpoint", netpoint);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllNetpointByAreaCode(Identifier identifier, Tb_netpoint netpoint, String companyId) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.NETPOINTDROPDOWN_FIND_BYAREACODE_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("netpoint", netpoint);
        param.put("companyId", companyId);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderInfoByNet(Identifier identifier, Integer sd_netpoint_id) {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_FIND_ORDER);
        HashMap<String, Integer> param = new HashMap<String, Integer>();
        param.put("sd_netpoint_id", sd_netpoint_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

