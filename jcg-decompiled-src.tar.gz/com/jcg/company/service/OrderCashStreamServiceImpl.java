/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_ordercash_stream
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_ordercash_stream;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class OrderCashStreamServiceImpl
extends BaseService {
    public Map<String, Object> findOrderCashStreamByParam(Identifier identifier, Tb_ordercash_stream orderCashStream, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.ORDERCASHSTREAM_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("orderCashStream", orderCashStream);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderCashStreamByOrder(Identifier identifier, String sw_order_id) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.ORDERCASHSTREAM_FIND_BYORDER_CPY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sw_order_id", sw_order_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

