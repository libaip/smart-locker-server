/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl
extends BaseService {
    public Map<String, Object> findOrderByParam(Identifier identifier, Tb_order order, Page page) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateOrderById(Identifier identifier, Tb_order order) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.ORDER_UPDATE_CPY);
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderById(Identifier identifier, Tb_order order) {
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYID_AGENTMB);
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderRecordById_cpy(Identifier identifier, String sd_order_id) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_RECORD_BYID_CPY);
        param.put("sd_order_id", sd_order_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllOrderByParam(Identifier identifier, Tb_order order) {
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_ALL_BYPARAM);
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllOrderById(Identifier identifier, Tb_order order) {
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_ALL_BYID);
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findPizhuOrderByUser(Identifier identifier, Tb_order order) {
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_PIZHU_BYUSER);
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> checkRefund(Identifier identifier, String sd_ordercash_id, String sr_refund_money) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_TK_CHECK_AGENT);
        param.put("sd_ordercash_id", sd_ordercash_id);
        param.put("sr_refund_money", sr_refund_money);
        param.put("sr_way", "CPY");
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> tkNotify(Identifier identifier, String out_trade_no, String refund_fee, String sd_cash_id) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_TKNOTIFY);
        param.put("sd_ordercash_id", out_trade_no);
        param.put("refund_fee", refund_fee);
        param.put("sd_cash_id", sd_cash_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> zhRefund(Identifier identifier, String sd_ordercash_id, String sr_refund_money) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_REFUND);
        param.put("sd_ordercash_id", sd_ordercash_id);
        param.put("sr_refund_money", sr_refund_money);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> closeOrder(Identifier identifier, String sd_order_id) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_CLOSE);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_order_id", sd_order_id);
        param.put("sr_type", "");
        param.put("sr_way", "CPY");
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> closeAllOrder(Identifier identifier, String sd_order_id) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_CLOSE);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_order_id", sd_order_id);
        param.put("sr_type", "");
        param.put("sr_way", "CPY");
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updatePhone(Identifier identifier, Tb_order order) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_UPDATE_PHONE);
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderByApp(Identifier identifier, Tb_order order, String dateRange, Page page) {
        HashMap<String, Object> param = new HashMap<String, Object>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYPARAM_CPYMB);
        param.put("order", order);
        param.put("dateRange", dateRange);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> depositRefund(Identifier identifier, String sd_order_id, String sr_refund_money) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_DEPOSIT_REFUND);
        param.put("sd_order_id", sd_order_id);
        param.put("sr_refund_money", sr_refund_money);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> depositRefundAll(Identifier identifier, String sd_order_id, String sr_refund_money) {
        HashMap<String, String> param = new HashMap<String, String>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_DEPOSIT_REFUND);
        param.put("sd_order_id", sd_order_id);
        param.put("sr_refund_money", sr_refund_money);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateBoxByWeb(Identifier identifier, Tb_order order) {
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_UPDATE_BOX_WEB);
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDepositByAgentId(Identifier identifier, Tb_order order) {
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_DEPOSIT_BYAGENT);
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> deleteOrderByDeviceId(Identifier identifier, String[] deviceArr, String sr_password) {
        HashMap<String, Object> param = new HashMap<String, Object>();
        identifier.setFunctionCode(XcbConstantValue.ORDER_DATA_RESET);
        param.put("deviceArr", deviceArr);
        param.put("sr_password", sr_password);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderForExcel(Identifier identifier, Tb_order order, Page page) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_FOREXCEL);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderByWeb(Identifier identifier, Tb_order order) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYWEB);
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> reUseBoxByWeb(Identifier identifier, Tb_order order) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_REUSE_BYWEB);
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> batchUpdateOrderAd(Identifier identifier, Tb_order order) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_REUSE_BYWEB);
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

