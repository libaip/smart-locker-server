/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_statistics;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class StatisticsServiceImpl
extends BaseService {
    public Map<String, Object> findStatisticsByParam(Identifier identifier, Tb_statistics statistics, String sr_way) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.STATISTICS_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("statistics", statistics);
        param.put("sr_way", sr_way);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findLineChartGroupByParam(Identifier identifier, Tb_statistics statistics, String sr_way) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.STATISTICS_LINE_CHART_FIND_BYDAYTYPE_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("statistics", statistics);
        param.put("sr_way", sr_way);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findLineChartDataByParam(Identifier identifier, Tb_statistics statistics) {
        identifier.setFunctionCode(XcbConstantValue.STATISTICS_LINE_CHART_FIND_BYDAYTYPE_CPY);
        HashMap<String, Tb_statistics> param = new HashMap<String, Tb_statistics>();
        param.put("statistics", statistics);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> reSetData(Identifier identifier, Tb_statistics statistics) {
        identifier.setFunctionCode(XcbConstantValue.STATISTICS_RESET_DATA);
        HashMap<String, Tb_statistics> param = new HashMap<String, Tb_statistics>();
        param.put("statistics", statistics);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDepositRateByNet(Identifier identifier, Tb_statistics statistics, Page page) {
        identifier.setFunctionCode(XcbConstantValue.STATISTICS_FIND_DEPOSIT_RATE_BYNET);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("statistics", statistics);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

