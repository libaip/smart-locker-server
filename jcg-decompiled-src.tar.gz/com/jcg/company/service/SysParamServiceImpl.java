/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_sys_param
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import com.jcg.company.model.Tb_sys_param;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class SysParamServiceImpl
extends BaseService {
    public Map<String, Object> updateParamForId(Identifier identifier, Map<String, Object> paraMap) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_WEIHU_ID);
        Map ret = this.genericCaller.genericCall(identifier, paraMap);
        return ret;
    }

    public Map<String, Object> findSysParamByKeyCode(Identifier identifier, String sr_category_code, String sr_key_code) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_BYKEYCODE);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_category_code", sr_category_code);
        param_map.put("sr_key_code", sr_key_code);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Map<String, Object> findDropDownInfos(Identifier identifier, String categoryCodes, String sr_login_type) {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_BYCATES);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("categoryCodes", categoryCodes);
        param_map.put("sr_login_type", sr_login_type);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Map<String, Object> findSysParamByCate(Identifier identifier, String sr_category_code) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_BYCATE);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_category_code", sr_category_code);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Map<String, Object> findSysPramaByKeyCode(Identifier identifier, String sr_category_code, String sr_key_code) {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_BYKEYCODE);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_category_code", sr_category_code);
        param_map.put("sr_key_code", sr_key_code);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Map<String, Object> updateSysParamById(Identifier identifier, Tb_sys_param sysParam) {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_UPDATE_CPY);
        HashMap<String, Tb_sys_param> param_map = new HashMap<String, Tb_sys_param>();
        param_map.put("sysParam", sysParam);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Map<String, Object> createMenu(Identifier identifier, String sr_way, String sr_version) {
        identifier.setFunctionCode(XcbConstantValue.WX_GZH_MENU_CREATE);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sr_way", sr_way);
        param.put("sr_version", sr_version);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findWxInfo(Identifier identifier) {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_WX_INFO_CPY);
        HashMap param = new HashMap();
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> excuteNetpointTask(Identifier identifier, Integer sd_netpoint_id) {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_TASK);
        HashMap<String, Integer> param = new HashMap<String, Integer>();
        param.put("sd_netpoint_id", sd_netpoint_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> clearSysCache(Identifier identifier) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.SYSTEM_CLEAR_CACHE);
        HashMap param = new HashMap();
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

