/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.user.model.Tb_user
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import com.jcg.user.model.Tb_user;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl
extends BaseService {
    public Map<String, Object> updateUserById(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_UPDATE_BYID_CPY);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findUserByParam(Identifier identifier, Tb_user user, Page page) {
        HashMap<String, Object> param = new HashMap<String, Object>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_FIND_BYPARAM_CPY);
        param.put("user", user);
        param.put("page", page);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findUserByModeParam(Identifier identifier, Tb_user user, Page page) {
        HashMap<String, Object> param = new HashMap<String, Object>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_FIND_MODE_BYPARAM_CPY);
        param.put("user", user);
        param.put("page", page);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

