/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.agent.model.Tb_agent_way
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.agent.model.Tb_withdrawal_appl
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.client.utils.URIBuilder
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 *  org.apache.http.util.EntityUtils
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.alibaba.fastjson.JSONObject;
import com.jcg.agent.model.Tb_agent_way;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.model.Tb_withdrawal_appl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.common.BaseService;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

@Service
public class WebServiceImpl
extends BaseService {
    public Map<String, Object> findOrderByWeb(Identifier identifier, Tb_order order, String url, String sw_company_id) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        HashMap<String, Object> paramMap = new HashMap<String, Object>();
        HashMap dataMap = new HashMap();
        List orders = null;
        Page page = new Page();
        JSONObject json = null;
        paramMap = new HashMap();
        paramMap.put("sr_net_name", order.getSr_net_name());
        paramMap.put("si_mainboard_id", order.getSi_mainboard_id());
        paramMap.put("sr_alias_desc", order.getSr_alias_desc());
        paramMap.put("sw_netpoint_id", order.getSw_netpoint_id());
        paramMap.put("sd_order_id", order.getSd_order_id());
        paramMap.put("sw_bus_order_id", order.getSw_bus_order_id());
        paramMap.put("sw_agent_id", order.getSw_agent_id());
        paramMap.put("sr_iphone_num", order.getSr_iphone_num());
        paramMap.put("sw_company_id", sw_company_id);
        paramMap.put("sr_order_time_start", order.getSr_order_time_start());
        paramMap.put("sr_order_time_end", order.getSr_order_time_end());
        String reqdata = JSONObject.toJSONString(paramMap);
        CloseableHttpResponse response = this.sendPost(url, reqdata, "");
        int statusCode = response.getStatusLine().getStatusCode();
        String msg = "\u67e5\u8be2\u8ba2\u5355\u5217\u8868\u5f02\u5e38";
        int result = 0;
        String str = EntityUtils.toString((HttpEntity)response.getEntity());
        if (!XcbStringUtils.isNullOrBlank((Object)str)) {
            str.replaceAll("null", "\"\"");
            json = JSONObject.parseObject((String)str);
            JSONObject data = (JSONObject)json.get((Object)XcbConstantValue.DATA);
            orders = JSONObject.parseArray((String)data.getString("orders"), Tb_order.class);
            page = (Page)JSONObject.parseObject((String)data.getString("page"), Page.class);
            result = XcbStringUtils.getObjtoint((Object)json.get((Object)XcbConstantValue.STATUS));
            msg = XcbStringUtils.getObjtoString((Object)json.get((Object)XcbConstantValue.MSG));
        }
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            dataMap.put("orders", orders);
            dataMap.put("page", page);
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            result_map.put(XcbConstantValue.MSG, msg);
            result_map.put(XcbConstantValue.DATA, dataMap);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, msg);
        }
        return result_map;
    }

    public Map<String, Object> findAgentWayByWeb(Identifier identifier, String url, Tb_agent_way agentWay) {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        HashMap<String, Tb_agent_way> dataMap = new HashMap<String, Tb_agent_way>();
        HashMap<String, String> paramMap = new HashMap<String, String>();
        JSONObject json = null;
        try {
            paramMap = new HashMap();
            paramMap.put("sr_user_name", agentWay.getSr_old_user_name());
            String reqdata = JSONObject.toJSONString(paramMap);
            CloseableHttpResponse response = this.sendPost(url, reqdata, "");
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = "\u67e5\u8be2\u4fe1\u606f\u5f02\u5e38";
            boolean result = false;
            String str = EntityUtils.toString((HttpEntity)response.getEntity());
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                str.replaceAll("null", "\"\"");
                json = JSONObject.parseObject((String)str);
                JSONObject data = (JSONObject)json.get((Object)XcbConstantValue.DATA);
                JSONObject agentWayJson = data.getJSONObject("agentWay");
                String sr_user_name = agentWayJson.getString("sr_user_name");
                String sr_way = agentWayJson.getString("sr_way");
                String sr_remark = agentWayJson.getString("sr_remark");
                Tb_agent_way way = new Tb_agent_way();
                way.setSr_user_name(sr_user_name);
                way.setSr_way(sr_way);
                way.setSr_remark(sr_remark);
                dataMap.put("agentWay", way);
                msg = XcbStringUtils.getObjtoString((Object)json.get((Object)XcbConstantValue.MSG));
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.MSG, msg);
                result_map.put(XcbConstantValue.DATA, dataMap);
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return result_map;
    }

    public Map<String, Object> createAgentWay(Identifier identifier, Tb_agent_way agentWay) throws Exception {
        String url = "https://platform2.cqdyxl.com/jcgweb-company/webapi/createAgentWay";
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        HashMap<String, String> paramMap = new HashMap<String, String>();
        HashMap dataMap = new HashMap();
        JSONObject json = null;
        paramMap = new HashMap();
        paramMap.put("sr_user_name", agentWay.getSr_user_name());
        paramMap.put("sr_old_user_name", agentWay.getSr_old_user_name());
        paramMap.put("sr_way", agentWay.getSr_way());
        paramMap.put("sr_remark", agentWay.getSr_remark());
        String reqdata = JSONObject.toJSONString(paramMap);
        CloseableHttpResponse response = this.sendPost(url, reqdata, "");
        int statusCode = response.getStatusLine().getStatusCode();
        String msg = "";
        int result = 0;
        String str = EntityUtils.toString((HttpEntity)response.getEntity());
        if (!XcbStringUtils.isNullOrBlank((Object)str)) {
            json = JSONObject.parseObject((String)str);
            result = XcbStringUtils.getObjtoint((Object)json.get((Object)XcbConstantValue.STATUS));
        }
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            result_map.put(XcbConstantValue.MSG, msg);
        } else {
            msg = XcbStringUtils.getObjtoString((Object)json.get((Object)XcbConstantValue.MSG));
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, msg);
        }
        return result_map;
    }

    public Map<String, Object> updateAgentWayByWeb(Identifier identifier, String url, Tb_agent_way agentWay) {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        HashMap dataMap = new HashMap();
        HashMap<String, String> paramMap = new HashMap<String, String>();
        JSONObject json = null;
        try {
            paramMap = new HashMap();
            paramMap.put("sr_user_name", agentWay.getSr_user_name());
            paramMap.put("sr_old_user_name", agentWay.getSr_old_user_name());
            paramMap.put("sr_way", agentWay.getSr_way());
            paramMap.put("sr_remark", agentWay.getSr_remark());
            String reqdata = JSONObject.toJSONString(paramMap);
            CloseableHttpResponse response = this.sendPost(url, reqdata, "");
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = "\u67e5\u8be2\u4fe1\u606f\u5f02\u5e38";
            int result = 0;
            String str = EntityUtils.toString((HttpEntity)response.getEntity());
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                str.replaceAll("null", "\"\"");
                json = JSONObject.parseObject((String)str);
                result = XcbStringUtils.getObjtoint((Object)json.get((Object)XcbConstantValue.STATUS));
                msg = XcbStringUtils.getObjtoString((Object)json.get((Object)XcbConstantValue.MSG));
                if (result > 0) {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                } else {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
                result_map.put(XcbConstantValue.MSG, msg);
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return result_map;
    }

    public Map<String, Object> updateAgentWayByName(Identifier identifier, String url, Tb_agent_way agentWay) {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        HashMap dataMap = new HashMap();
        HashMap<String, String> paramMap = new HashMap<String, String>();
        JSONObject json = null;
        try {
            paramMap = new HashMap();
            paramMap.put("sr_user_name", agentWay.getSr_user_name());
            paramMap.put("sr_way", agentWay.getSr_way());
            String reqdata = JSONObject.toJSONString(paramMap);
            CloseableHttpResponse response = this.sendPost(url, reqdata, "");
            int statusCode = response.getStatusLine().getStatusCode();
            String msg = "\u67e5\u8be2\u4fe1\u606f\u5f02\u5e38";
            int result = 0;
            String str = EntityUtils.toString((HttpEntity)response.getEntity());
            if (!XcbStringUtils.isNullOrBlank((Object)str)) {
                str.replaceAll("null", "\"\"");
                json = JSONObject.parseObject((String)str);
                result = XcbStringUtils.getObjtoint((Object)json.get((Object)XcbConstantValue.STATUS));
                msg = XcbStringUtils.getObjtoString((Object)json.get((Object)XcbConstantValue.MSG));
                if (result > 0) {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                } else {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
                result_map.put(XcbConstantValue.MSG, msg);
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return result_map;
    }

    private CloseableHttpResponse sendPost(String url, String reqdata, String token) throws Exception {
        CloseableHttpResponse response = null;
        CloseableHttpClient httpClient = HttpClients.createDefault();
        try {
            URIBuilder uriBuilder = new URIBuilder(url);
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, XcbConstantValue.ENCODING_UTF8);
            entity.setContentType("application/json");
            httpPost.setEntity((HttpEntity)entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Authorization", token);
            response = httpClient.execute((HttpUriRequest)httpPost);
        }
        catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return response;
    }

    public Map<String, Object> findWithdrawalApplByWeb(Identifier identifier, Tb_withdrawal_appl withdrawalAppl, String url) throws Exception {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        HashMap<String, Object> paramMap = new HashMap<String, Object>();
        HashMap dataMap = new HashMap();
        List applList = null;
        Page page = new Page();
        JSONObject json = null;
        paramMap = new HashMap();
        paramMap.put("sw_agent_id", withdrawalAppl.getSw_agent_id());
        paramMap.put("sr_type", withdrawalAppl.getSr_type());
        paramMap.put("sr_way", withdrawalAppl.getSr_way());
        paramMap.put("sr_status", withdrawalAppl.getSr_status());
        paramMap.put("sr_province", withdrawalAppl.getSr_province());
        paramMap.put("sr_city", withdrawalAppl.getSr_city());
        paramMap.put("sr_street", withdrawalAppl.getSr_street());
        paramMap.put("sr_district", withdrawalAppl.getSr_district());
        paramMap.put("sr_create_time_start", withdrawalAppl.getSr_create_time_start());
        paramMap.put("sr_create_time_end", withdrawalAppl.getSr_create_time_end());
        String reqdata = JSONObject.toJSONString(paramMap);
        CloseableHttpResponse response = this.sendPost(url, reqdata, "");
        int statusCode = response.getStatusLine().getStatusCode();
        String msg = "\u67e5\u8be2\u63d0\u73b0\u5217\u8868\u5f02\u5e38";
        int result = 0;
        String str = EntityUtils.toString((HttpEntity)response.getEntity());
        if (!XcbStringUtils.isNullOrBlank((Object)str)) {
            str.replaceAll("null", "\"\"");
            json = JSONObject.parseObject((String)str);
            JSONObject data = (JSONObject)json.get((Object)XcbConstantValue.DATA);
            applList = JSONObject.parseArray((String)data.getString("applList"), Tb_withdrawal_appl.class);
            page = (Page)JSONObject.parseObject((String)data.getString("page"), Page.class);
            result = XcbStringUtils.getObjtoint((Object)json.get((Object)XcbConstantValue.STATUS));
            msg = XcbStringUtils.getObjtoString((Object)json.get((Object)XcbConstantValue.MSG));
        }
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            dataMap.put("applList", applList);
            dataMap.put("page", page);
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            result_map.put(XcbConstantValue.MSG, msg);
            result_map.put(XcbConstantValue.DATA, dataMap);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, msg);
        }
        return result_map;
    }
}

