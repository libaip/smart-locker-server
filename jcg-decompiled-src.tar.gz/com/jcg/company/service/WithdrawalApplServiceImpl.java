/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_withdrawal_appl
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.company.service;

import com.jcg.agent.model.Tb_withdrawal_appl;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class WithdrawalApplServiceImpl
extends BaseService {
    public Map<String, Object> createWithdrawalAppl(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        identifier.setFunctionCode(XcbConstantValue.WITHDRAWAL_APPL_CREATE);
        HashMap<String, Tb_withdrawal_appl> param = new HashMap<String, Tb_withdrawal_appl>();
        param.put("withdrawalAppl", withdrawalAppl);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findWithdrawalApplByParam(Identifier identifier, Tb_withdrawal_appl withdrawalAppl, Page page) {
        identifier.setFunctionCode(XcbConstantValue.WITHDRAWAL_APPL_FIND_BYPARAM_CPY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("withdrawalAppl", withdrawalAppl);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllWithdrawalApplByParam(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        identifier.setFunctionCode(XcbConstantValue.WITHDRAWAL_APPL_FIND_ALL_BYPARAM_CPY);
        HashMap<String, Tb_withdrawal_appl> param = new HashMap<String, Tb_withdrawal_appl>();
        param.put("withdrawalAppl", withdrawalAppl);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findWithdrawalApplById(Identifier identifier, Integer sd_id) {
        identifier.setFunctionCode(XcbConstantValue.WITHDRAWAL_APPL_FIND_BYID_CPY);
        HashMap<String, Integer> param = new HashMap<String, Integer>();
        param.put("sd_id", sd_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateWithdrawalAppl(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        identifier.setFunctionCode(XcbConstantValue.WITHDRAWAL_APPL_UPDATE_CPY);
        HashMap<String, Tb_withdrawal_appl> param = new HashMap<String, Tb_withdrawal_appl>();
        param.put("withdrawalAppl", withdrawalAppl);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> payToAgent(Identifier identifier, Tb_withdrawal_appl withdrawalAppl) {
        identifier.setFunctionCode(XcbConstantValue.WITHDRAWAL_APPL_PAY);
        HashMap<String, Tb_withdrawal_appl> param = new HashMap<String, Tb_withdrawal_appl>();
        param.put("withdrawalAppl", withdrawalAppl);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

