/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_advice_user
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.AdviceUserDao;
import com.jcg.company.model.Tb_advice_user;
import com.jcg.wxmsg.serviceimpl.WxMessageServiceImpl;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class AdviceUserServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private AdviceUserDao adviceUserDao;
    @Autowired
    private WxMessageServiceImpl wxMessageService;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=======AdviceUserServiceImpl==========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_advice_user adviceUser = new Tb_advice_user();
        Integer id = null;
        Page page = new Page();
        if (param != null) {
            adviceUser = (Tb_advice_user)param.get("adviceUser");
            id = (Integer)param.get("id");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.ADVICEUSER_CREATE_USER.equalsIgnoreCase(functionCode)) {
                ret = this.createAdviceUser_user(adviceUser);
            } else if (XcbConstantValue.ADVICEUSER_FINDBYID_USER.equalsIgnoreCase(functionCode)) {
                Integer sw_user_id = XcbStringUtils.getObjtoint((Object)param.get("sw_user_id"));
                ret = this.findAdviceUserById_user(sw_user_id, page);
            } else if (XcbConstantValue.ADVICEUSER_DELETE.equalsIgnoreCase(functionCode)) {
                ret = this.deleteAdviceUserById(id);
            } else if (XcbConstantValue.ADVICEUSER_FINDBYID.equalsIgnoreCase(functionCode)) {
                ret = this.findAdviceUserById(id);
            } else if (XcbConstantValue.ADVICEUSER_UPDATE.equalsIgnoreCase(functionCode)) {
                ret = this.updateAdviceUser(adviceUser);
            } else if (XcbConstantValue.ADVICEUSER_FINDBYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findAdviceUserByParam(adviceUser, page);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findAdviceUserByParam(Tb_advice_user adviceUser, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Object>> dataMap = new HashMap<String, List<Object>>();
        List<Tb_advice_user> advices = null;
        try {
            advices = this.adviceUserDao.findByParam(adviceUser, page);
            int count = this.adviceUserDao.findCountByParam(adviceUser);
            page.setTotal(count);
            dataMap.put("adviceUsers", advices);
            dataMap.put("page", (List<Object>)page);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ADVICEUSER_FINDBYPARAM, PromptProperties.getProperty("advice.user.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> updateAdviceUser(Tb_advice_user adviceUser) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int count = 0;
        try {
            Tb_advice_user oldUser = this.adviceUserDao.findById(adviceUser.getId());
            adviceUser.setTm_reply_time(new Date());
            adviceUser.setSw_user_id(oldUser.getSw_user_id());
            adviceUser.setSr_advice_title(oldUser.getSr_advice_title());
            count = this.adviceUserDao.updateById(adviceUser);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("advice.user.update.success"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("advice.user.update.fail"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ADVICEUSER_UPDATE, PromptProperties.getProperty("advice.user.update.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findAdviceUserById(Integer id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_advice_user> dataMap = new HashMap<String, Tb_advice_user>();
        Tb_advice_user advices = null;
        try {
            advices = this.adviceUserDao.findById(id);
            dataMap.put("adviceUser", advices);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ADVICEUSER_FINDBYID_USER, PromptProperties.getProperty("advice.user.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> deleteAdviceUserById(Integer id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int count = 0;
        try {
            count = this.adviceUserDao.deleteById(id);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("advice.user.delete.success"));
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("advice.user.delete.fail"));
            }
            ret_method.put(XcbConstantValue.STATUS, count);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ADVICEUSER_DELETE, PromptProperties.getProperty("advice.user.delete.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findAdviceUserById_user(Integer sw_user_id, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        List<Tb_advice_user> advices = null;
        try {
            advices = this.adviceUserDao.findById_user(sw_user_id, page);
            int count = this.adviceUserDao.findCountById_user(sw_user_id);
            page.setTotal(count);
            dataMap.put("page", page);
            dataMap.put("adviceUsers", advices);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ADVICEUSER_FINDBYID_USER, PromptProperties.getProperty("advice.user.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> createAdviceUser_user(Tb_advice_user adviceUser) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int count = 0;
        try {
            adviceUser.setTm_advice_time(new Date());
            adviceUser.setSr_status(XcbConstantValue.ADVICEUSER_DHF);
            count = this.adviceUserDao.createAdviceUser_user(adviceUser);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("advice.user.create.success"));
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("advice.user.create.fail"));
            }
            ret_method.put(XcbConstantValue.STATUS, count);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ADVICEUSER_CREATE_USER, PromptProperties.getProperty("advice.user.create.fail"), (Throwable)e);
        }
        return ret_method;
    }
}

