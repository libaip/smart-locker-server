/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.cache.annotation.Cacheable
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.cache.SystemParamCache;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.AreaCityDao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.transaction.annotation.Transactional;

public class AreaCityServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private AreaCityDao areaCityDao;
    @Autowired
    private SystemParamCache systemParamService;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=================");
        this.log.debug(identifier.toString());
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        String sr_province_code = null;
        if (param != null) {
            sr_province_code = (String)param.get("sr_province_code");
        }
        try {
            if (XcbConstantValue.CITY_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findCityById(sr_province_code);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    public Map<String, Object> findCityById(String sr_province_code) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> citys = this.systemParamService.getCitysByPro(sr_province_code);
            ret_method.put(XcbConstantValue.DATA, citys);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CITY_FIND_BYID, PromptProperties.getProperty("city.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    @Cacheable(value={"sysParamCache"})
    public Map<String, List<Map<String, Object>>> findCityAll() {
        HashMap<String, List<Map<String, Object>>> map_citys = new HashMap<String, List<Map<String, Object>>>();
        try {
            List<Map<String, Object>> list_citys = this.areaCityDao.findCityAll();
            if (list_citys != null && list_citys.size() > 0) {
                for (int i = 0; i < list_citys.size(); ++i) {
                    Map<String, Object> map_city = list_citys.get(i);
                    String province_code = XcbStringUtils.getObjtoString((Object)map_city.get("sr_province_code"));
                    if (map_citys.containsKey(province_code)) {
                        ((List)map_citys.get(province_code)).add(map_city);
                        continue;
                    }
                    ArrayList<Map<String, Object>> province_citys = new ArrayList<Map<String, Object>>();
                    province_citys.add(map_city);
                    map_citys.put(province_code, province_citys);
                }
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CITY_FIND_BYID, PromptProperties.getProperty("city.findbyid.fail"), (Throwable)e);
        }
        return map_citys;
    }
}

