/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.cache.annotation.Cacheable
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.cache.SystemParamCache;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.AreaDistrictDao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.transaction.annotation.Transactional;

public class AreaDistrictServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private AreaDistrictDao areaDistrictDao;
    @Autowired
    private SystemParamCache systemParamService;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========AreaDistrictServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        String sr_city_code = null;
        if (param != null) {
            sr_city_code = XcbStringUtils.getObjtoString((Object)param.get("sr_city_code"));
        }
        try {
            if (XcbConstantValue.DISTRICT_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findDistrictById(sr_city_code);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    public Map<String, Object> findDistrictById(String sr_city_code) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> districts = this.systemParamService.getDistrictByCity(sr_city_code);
            ret_method.put(XcbConstantValue.DATA, districts);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.DISTRICT_FIND_BYID, PromptProperties.getProperty("district.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    @Cacheable(value={"sysParamCache"})
    public Map<String, List<Map<String, Object>>> findDistrictAll() {
        HashMap<String, List<Map<String, Object>>> map_districts = new HashMap<String, List<Map<String, Object>>>();
        try {
            List<Map<String, Object>> list_districts = this.areaDistrictDao.findDistrictAll();
            if (list_districts != null && list_districts.size() > 0) {
                for (int i = 0; i < list_districts.size(); ++i) {
                    Map<String, Object> map_district = list_districts.get(i);
                    String city_code = XcbStringUtils.getObjtoString((Object)map_district.get("sr_city_code"));
                    if (map_districts.containsKey(city_code)) {
                        ((List)map_districts.get(city_code)).add(map_district);
                        continue;
                    }
                    ArrayList<Map<String, Object>> city_district = new ArrayList<Map<String, Object>>();
                    city_district.add(map_district);
                    map_districts.put(city_code, city_district);
                }
            }
        }
        catch (Exception e) {
            throw new BusinessException("findDistrictAll", PromptProperties.getProperty("district.findbyid.fail"), (Throwable)e);
        }
        return map_districts;
    }
}

