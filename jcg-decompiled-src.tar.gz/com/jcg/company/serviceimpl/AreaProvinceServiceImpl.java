/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.cache.annotation.CacheEvict
 *  org.springframework.cache.annotation.Cacheable
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.cache.SystemParamCache;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.AreaProvinceDao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.transaction.annotation.Transactional;

public class AreaProvinceServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private AreaProvinceDao areaProvinceDao;
    @Autowired
    private SystemParamCache systemParamService;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========AreaProvinceServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        String sd_code = null;
        if (param != null) {
            sd_code = XcbStringUtils.getObjtoString((Object)param.get("sd_code"));
        }
        try {
            if (XcbConstantValue.PROVINCE_FINDALL.equalsIgnoreCase(functionCode)) {
                ret = this.findProvinces(identifier, sd_code);
            } else if (XcbConstantValue.PROVINCE_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findProvinceById(sd_code);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    public Map<String, Object> findProvinces(Identifier identifier, String sd_code) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> provinces = this.systemParamService.getProvinces();
            ret_method.put(XcbConstantValue.DATA, provinces);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.PROVINCE_FIND_BYID, PromptProperties.getProperty("province.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findProvinceById(String sd_code) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> provinces = this.systemParamService.getProvince(sd_code);
            ret_method.put(XcbConstantValue.DATA, provinces);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.PROVINCE_FIND_BYID, PromptProperties.getProperty("province.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    @Cacheable(value={"sysParamCache"})
    public List<Map<String, Object>> findProvinceAll() {
        ArrayList<Map<String, Object>> provinces = new ArrayList();
        try {
            provinces = this.areaProvinceDao.findProvinceAll();
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.PROVINCE_FIND_BYID, PromptProperties.getProperty("privence.findbyid.fail"), (Throwable)e);
        }
        return provinces;
    }

    @CacheEvict(value={"sysParamCache"}, allEntries=true, beforeInvocation=true)
    public void clearCache() {
        System.out.println("\u6e05\u9664\u7f13\u5b58\uff01");
    }
}

