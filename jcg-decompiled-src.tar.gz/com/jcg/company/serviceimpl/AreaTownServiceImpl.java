/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.cache.annotation.Cacheable
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.cache.SystemParamCache;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.AreaTownDao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.transaction.annotation.Transactional;

public class AreaTownServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private AreaTownDao areaTownDao;
    @Autowired
    private SystemParamCache systemParamService;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========AreaTownServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        String sr_district_code = null;
        if (param != null) {
            sr_district_code = XcbStringUtils.getObjtoString((Object)param.get("sr_district_code"));
        }
        try {
            if (XcbConstantValue.TOWN_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findTownById(sr_district_code);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    public Map<String, Object> findTownById(String sr_district_code) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> privences = this.systemParamService.getTownByDistr(sr_district_code);
            ret_method.put(XcbConstantValue.DATA, privences);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.TOWN_FIND_BYID, PromptProperties.getProperty("town.findbyid.fail"), (Throwable)e);
        }
        return ret_method;
    }

    @Cacheable(value={"sysParamCache"})
    public Map<String, List<Map<String, Object>>> findTownAll() {
        HashMap<String, List<Map<String, Object>>> map_towns = new HashMap<String, List<Map<String, Object>>>();
        try {
            List<Map<String, Object>> list_towns = this.areaTownDao.findTownAll();
            if (list_towns != null && list_towns.size() > 0) {
                for (int i = 0; i < list_towns.size(); ++i) {
                    Map<String, Object> map_town = list_towns.get(i);
                    String district_code = XcbStringUtils.getObjtoString((Object)map_town.get("sr_district_code"));
                    if (map_towns.containsKey(district_code)) {
                        ((List)map_towns.get(district_code)).add(map_town);
                        continue;
                    }
                    ArrayList<Map<String, Object>> district_town = new ArrayList<Map<String, Object>>();
                    district_town.add(map_town);
                    map_towns.put(district_code, district_town);
                }
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.TOWN_FIND_BYID, PromptProperties.getProperty("town.findbyid.fail"), (Throwable)e);
        }
        return map_towns;
    }
}

