/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cn.hutool.core.util.ObjectUtil
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CertificateVO
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_company_roles
 *  com.jcg.company.model.Tb_company_roles_auth
 *  com.jcg.company.model.Tb_company_roles_rel
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_sys_param
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.webapi.model.Tb_sdj_orderResp
 *  com.wechat.pay.contrib.apache.httpclient.util.PemUtil
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 *  org.apache.http.util.EntityUtils
 *  org.bouncycastle.util.encoders.Hex
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.cache.annotation.CacheEvict
 *  org.springframework.cache.annotation.Cacheable
 *  org.springframework.security.crypto.password.StandardPasswordEncoder
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 *  org.springframework.util.Base64Utils
 */
package com.jcg.company.serviceimpl;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CertificateVO;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.CompanyAuthoritiesDao;
import com.jcg.company.idao.CompanyDao;
import com.jcg.company.idao.CompanyRolesAuthDao;
import com.jcg.company.idao.CompanyRolesDao;
import com.jcg.company.idao.CompanyRolesRelDao;
import com.jcg.company.idao.CuserDao;
import com.jcg.company.idao.WxPayInfoDao;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_company_roles;
import com.jcg.company.model.Tb_company_roles_auth;
import com.jcg.company.model.Tb_company_roles_rel;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.webapi.model.Tb_sdj_orderResp;
import com.jcg.zf.sdj.util.PfxCerUtil;
import com.jcg.zf.sdj.util.SDKUtil;
import com.jcg.zf.sdj.util.SM2Util;
import com.wechat.pay.contrib.apache.httpclient.util.PemUtil;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.bouncycastle.util.encoders.Hex;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.Base64Utils;

public class CompanyServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private CompanyDao companyDao;
    @Autowired
    private WxPayInfoDao wxPayInfoDao;
    @Autowired
    private CuserDao cuserDao;
    @Autowired
    private CompanyRolesDao companyrolesDao;
    @Autowired
    private CompanyRolesAuthDao companyRolesAuthDao;
    @Autowired
    private CompanyAuthoritiesDao companyAuthoritiesDao;
    @Autowired
    private CompanyRolesRelDao companyRolesRelDao;
    @Autowired
    private StandardPasswordEncoder standardPasswordEncoder;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_company company = new Tb_company();
        Tb_cuser cuser = new Tb_cuser();
        String sd_company_id = null;
        Page page = new Page();
        if (param != null) {
            company = (Tb_company)param.get("company");
            cuser = (Tb_cuser)param.get("cuser");
            page = (Page)param.get("page");
            sd_company_id = XcbStringUtils.getObjtoString((Object)param.get("sd_company_id"));
        }
        try {
            if (XcbConstantValue.COMPANY_PARAM_CACHE.equalsIgnoreCase(functionCode)) {
                ret = this.findComanyParamCache(sd_company_id);
            } else if (XcbConstantValue.COMPANY_FIND_PAYIN.equalsIgnoreCase(functionCode)) {
                ret = this.findCompanyPayIn(sd_company_id);
            } else if (XcbConstantValue.COMPANY_FIND_BYMERID.equalsIgnoreCase(functionCode)) {
                String sr_wx_mer_id = XcbStringUtils.getObjtoString((Object)param.get("sr_wx_mer_id"));
                ret = this.findCompanyByMerId(sr_wx_mer_id);
            } else if (XcbConstantValue.COMPANY_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createCompany(identifier, company, cuser);
            } else if (XcbConstantValue.COMPANY_UPDATE_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.updateById(identifier, company);
            } else if (XcbConstantValue.COMPANY_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findCompanyById(identifier, sd_company_id);
            } else if (XcbConstantValue.COMPANY_FIND_BYPARAMS.equalsIgnoreCase(functionCode)) {
                ret = this.findCompanyByParams(identifier, company, cuser, page);
            } else if (XcbConstantValue.COMPANY_FIND_ALL.equalsIgnoreCase(functionCode)) {
                ret = this.findAllCompanyDropDown(company, cuser);
            } else if (XcbConstantValue.COMPANY_GET_V3.equalsIgnoreCase(functionCode)) {
                String sr_mchid = XcbStringUtils.getObjtoString((Object)param.get("sr_mchid"));
                ret = this.getV3Serialno(identifier, sr_mchid);
            } else if (XcbConstantValue.COMPANY_INIT_CERT_VERIFYSIGN.equalsIgnoreCase(functionCode)) {
                Tb_wx_pay_info info = (Tb_wx_pay_info)param.get("info");
                Object result = param.get("result");
                String respSign = XcbStringUtils.getObjtoString((Object)param.get("respSign"));
                ret = this.checkSdjVerifySign(identifier, info, result, respSign);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    public Map<String, Object> findCompanyByMerId(String sr_wx_mer_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        Tb_company company = new Tb_company();
        try {
            company = this.wxPayInfoDao.findDefaultPayInByMerid(sr_wx_mer_id);
            ret_method.put(XcbConstantValue.DATA, company);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.COMPANY_FIND_BYMERID, PromptProperties.getProperty("company.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findCompanyByParams(Identifier identifier, Tb_company company, Tb_cuser cuser, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            Tb_company c = this.companyDao.findCompanyById(cuser.getSw_company_id());
            if (ObjectUtil.isNotEmpty((Object)c) && XcbConstantValue.COMPANY_TYPE_OEM.equals(c.getSr_type())) {
                company.setSd_company_id(cuser.getSw_company_id());
                company.setSw_parent_id(cuser.getSw_company_id());
            } else if (ObjectUtil.isNotEmpty((Object)c) && XcbConstantValue.COMPANY_TYPE_FGS.equals(c.getSr_type())) {
                company.setSd_company_id(cuser.getSw_company_id());
            }
            List<Tb_company> companyList = this.companyDao.findCompanyByParams(company, page);
            int totalCount = this.companyDao.findCountCompanyByParams(company);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("companys", companyList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.COMPANY_FIND_BYPARAMS, PromptProperties.getProperty("company.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findCompanyById(Identifier identifier, String sd_company_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_company company = this.companyDao.findCompanyById(sd_company_id);
            ret_method.put(XcbConstantValue.DATA, company);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.COMPANY_FIND_BYID, PromptProperties.getProperty("company.findbyid.error"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    Map<String, Object> updateById(Identifier identifier, Tb_company company) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            company.setTm_modify_time(new Date());
            int count = this.companyDao.updateById(company);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("company.update.success"));
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("company.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.COMPANY_UPDATE_BYID, PromptProperties.getProperty("company.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    Map<String, Object> createCompany(Identifier identifier, Tb_company company, Tb_cuser cuser) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int count;
            String companyId = CommonFunction.getVoucherNum((String)CommonFunction.company_id);
            company.setSd_company_id(companyId);
            company.setTm_create_time(new Date());
            company.setSi_create_person(identifier.getUserId());
            if (XcbConstantValue.COMPANY_TYPE_FGS.equals(company.getSr_type())) {
                company.setSw_parent_id(cuser.getSw_company_id());
            }
            if ((count = this.companyDao.createCompany(company)) <= XcbConstantValue.OPERA_INT_ZERO) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("company.create.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("company.create.success"));
            Tb_cuser c = new Tb_cuser();
            c.setSw_company_id(companyId);
            c.setSr_cuser_name(company.getSr_company_tel());
            c.setSr_status(XcbConstantValue.CUSER_STATUS_ZC);
            c.setSr_name(company.getSr_rel_person());
            c.setSr_cuser_petname(company.getSr_rel_person());
            c.setSr_phone(company.getSr_company_tel());
            c.setSr_tel(company.getSr_company_tel());
            Tb_sys_param sysParamMod = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.CPASS);
            String defaultPass = sysParamMod.getSr_param_value();
            String password_md5 = this.standardPasswordEncoder.encode((CharSequence)defaultPass);
            c.setSr_password(password_md5);
            c.setSr_password_mw(defaultPass);
            c.setTm_create_time(new Date());
            count = this.cuserDao.createCuser(c);
            if (count <= XcbConstantValue.OPERA_INT_ZERO) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("company.create.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            Tb_company_roles cr = new Tb_company_roles();
            cr.setSw_company_id(companyId);
            cr.setSr_rolecode(XcbConstantValue.ROLE_CODE_ADMIN);
            cr.setSr_rolename(XcbConstantValue.ROLE_NAME_ADMIN);
            cr.setSr_remarks(XcbConstantValue.ROLE_NAME_ADMIN);
            cr.setTm_createdate(new Date());
            cr.setSi_createuser(identifier.getUserId());
            count = this.companyrolesDao.createCompanyRoles(cr);
            if (count <= XcbConstantValue.OPERA_INT_ZERO) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("company.create.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            List<Map<String, Object>> auths = this.companyAuthoritiesDao.findAll();
            Integer[] authArr = new Integer[auths.size()];
            for (int i = 0; i < auths.size(); ++i) {
                authArr[i] = (Integer)auths.get(i).get("sd_authority_id");
            }
            ArrayList<Tb_company_roles_auth> roleAuths = new ArrayList<Tb_company_roles_auth>();
            Date current = new Date();
            if (authArr.length > 0) {
                for (int i = 0; i < authArr.length; ++i) {
                    Tb_company_roles_auth roleAuth = new Tb_company_roles_auth();
                    roleAuth.setSw_roles_id(cr.getSd_roles_id());
                    roleAuth.setSw_authority_id(Integer.valueOf(authArr[i]));
                    roleAuth.setCreatedate(current);
                    roleAuth.setCreateuser(identifier.getUserName());
                    roleAuths.add(roleAuth);
                }
            }
            if (roleAuths.size() > 0) {
                count = this.companyRolesAuthDao.insertRoleAuthByBatch(roleAuths);
            }
            if (count <= XcbConstantValue.OPERA_INT_ZERO) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("company.create.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            Tb_company_roles_rel crr = new Tb_company_roles_rel();
            crr.setSw_cuser_id(c.getSd_cuser_id());
            crr.setSw_roles_id(cr.getSd_roles_id());
            crr.setTm_createdate(new Date());
            crr.setSi_createuser(identifier.getUserId());
            count = this.companyRolesRelDao.createCompanyRolesRel(crr);
            if (count <= XcbConstantValue.OPERA_INT_ZERO) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("company.create.fail"));
                this.initResultMap(ret_method);
                return ret_method;
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.COMPANY_CREATE, PromptProperties.getProperty("company.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findAllCompanyDropDown(Tb_company company, Tb_cuser cuser) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            Tb_company c = this.companyDao.findCompanyById(cuser.getSw_company_id());
            if (ObjectUtil.isNotEmpty((Object)c) && XcbConstantValue.COMPANY_TYPE_ZGS.equals(c.getSr_type()) && XcbConstantValue.CUSER_FIND_BYPARAM.equals(company.getAction_code())) {
                cuser.setSw_company_id(null);
            }
            List<Map<String, Object>> companys = this.companyDao.findAllCompanyDropDown(cuser.getSw_company_id());
            map.put(XcbConstantValue.DATA, companys);
            map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(map);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.COMPANY_FIND_ALL, PromptProperties.getProperty("company.findbyparam.error"), (Throwable)e);
        }
        return map;
    }

    public Map<String, Object> findComanyParamCache(String sd_company_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        Tb_company company = new Tb_company();
        try {
            List<Tb_company> companys = this.findCompanyAll();
            for (Tb_company temp : companys) {
                if (!temp.getSd_company_id().equals(sd_company_id)) continue;
                company = temp;
                break;
            }
            ret_method.put(XcbConstantValue.DATA, company);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.COMPANY_PARAM_CACHE, PromptProperties.getProperty("company.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findCompanyPayIn(String sd_company_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        Tb_company company = new Tb_company();
        try {
            company = this.wxPayInfoDao.findDefaultPayIn(sd_company_id);
            ret_method.put(XcbConstantValue.DATA, company);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.COMPANY_FIND_PAYIN, PromptProperties.getProperty("company.find.fail"), (Throwable)e);
        }
        return ret_method;
    }

    @Cacheable(value={"companyCache"})
    public List<Tb_company> findCompanyAll() {
        ArrayList<Tb_company> companys = new ArrayList();
        try {
            companys = this.companyDao.findCompanyAll();
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.COMPANY_CLEAR_CACHE, PromptProperties.getProperty("company.findAll.fail"), (Throwable)e);
        }
        return companys;
    }

    @CacheEvict(value={"companyCache"}, allEntries=true, beforeInvocation=true)
    public void clearCache() {
        System.out.println("\u6e05\u9664\u7f13\u5b58\uff01");
    }

    public Map<String, Object> getV3Serialno(Identifier identifier, String sr_mchid) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            CloseableHttpClient httpClient = HttpClients.createDefault();
            String result = "";
            Tb_wx_pay_info info = this.wxPayInfoDao.findPayInfo(sr_mchid);
            String url = "https://api.mch.weixin.qq.com/v3/certificates";
            HttpGet httpGet = new HttpGet(url);
            String path = info.getSr_key_path() + info.getSub_mchid() + "apiclient_key.pem";
            PrivateKey merchantPrivateKey = PemUtil.loadPrivateKey((InputStream)new FileInputStream(path));
            httpGet.addHeader("Content-Type", "application/json;charset=UTF-8");
            httpGet.addHeader("Accept", "application/json");
            httpGet.addHeader("Authorization", CompanyServiceImpl.getToken("GET", url, "", info, merchantPrivateKey));
            CloseableHttpResponse response = httpClient.execute((HttpUriRequest)httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                result = EntityUtils.toString((HttpEntity)response.getEntity(), (String)"UTF-8");
            }
            if (!XcbStringUtils.isNullOrBlank((Object)result)) {
                JSONObject jsonObject = JSONObject.parseObject((String)result);
                String serial_no = "";
                String expire_time = "";
                CertificateVO newCertificateVO = new CertificateVO();
                List certificateList = JSONObject.parseArray((String)jsonObject.getString("data"), CertificateVO.class);
                for (CertificateVO certificate : certificateList) {
                    serial_no = certificate.getSerial_no();
                    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                    Date date = formatter.parse(certificate.getExpire_time());
                    expire_time = XcbDateUtil.formatDate((Date)date, (String)"yyyy-MM-dd HH:mm:ss");
                    newCertificateVO = certificate;
                }
                Tb_wx_pay_info n_info = new Tb_wx_pay_info();
                n_info.setSr_v3_serialno(serial_no);
                n_info.setSd_id(info.getSd_id());
                n_info.setSr_expire_time(expire_time);
                int code = this.wxPayInfoDao.updateInfo(n_info);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, "\u83b7\u53d6\u6210\u529f");
            }
        }
        catch (Exception e) {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, "\u83b7\u53d6\u5fae\u4fe1v3\u5e73\u53f0\u8bc1\u4e66\u5f02\u5e38");
        }
        return ret;
    }

    public static String getToken(String method, String url, String body, Tb_wx_pay_info info, PrivateKey merchantPrivateKey) {
        Long timestamp = System.currentTimeMillis() / 1000L;
        String nonceStr = UUID.randomUUID().toString().replace("-", "");
        String signature = CompanyServiceImpl.getSign(method, url, body, timestamp, nonceStr, merchantPrivateKey);
        String TOKEN_PATTERN = "WECHATPAY2-SHA256-RSA2048 mchid=\"%s\",nonce_str=\"%s\",timestamp=\"%d\",serial_no=\"%s\",signature=\"%s\"";
        return String.format("WECHATPAY2-SHA256-RSA2048 mchid=\"%s\",nonce_str=\"%s\",timestamp=\"%d\",serial_no=\"%s\",signature=\"%s\"", info.getSub_mchid(), nonceStr, timestamp, info.getSub_service_serialno(), signature);
    }

    public static String getSign(String method, String canonicalUrl, String body, long timestamp, String nonceStr, PrivateKey merchantPrivateKey) {
        try {
            URL url = new URL(canonicalUrl);
            String signUrl = "GET".equals(method) && url.getQuery() != null ? url.getPath() + "?" + url.getQuery() : url.getPath();
            String signatureStr = Stream.of(method, signUrl, String.valueOf(timestamp), nonceStr, body).collect(Collectors.joining("\n", "", "\n"));
            Signature sign = Signature.getInstance("SHA256withRSA");
            sign.initSign(merchantPrivateKey);
            sign.update(signatureStr.getBytes("UTF-8"));
            return Base64Utils.encodeToString((byte[])sign.sign());
        }
        catch (Exception exception) {
            return null;
        }
    }

    private Map<String, Object> checkSdjVerifySign(Identifier identifier, Tb_wx_pay_info info, Object result, String respSign) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        boolean isVerifySign = false;
        try {
            if (result instanceof Tb_sdj_orderResp) {
                result = (Tb_sdj_orderResp)result;
            }
            String signObject = SDKUtil.getSignData(result, info.getSub_merkey_v2());
            String publicKeyPath = info.getSr_key_path() + info.getSub_mchid() + "/sdj_smclient.cer";
            PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
            byte[] sig1 = Hex.decode((String)respSign);
            isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.exceptionToString((Exception)e));
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        ret.put("isVerifySign", isVerifySign);
        return ret;
    }
}

