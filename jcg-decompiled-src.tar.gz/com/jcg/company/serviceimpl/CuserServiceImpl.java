/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cn.hutool.core.util.ObjectUtil
 *  com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_company_authorities
 *  com.jcg.company.model.Tb_company_roles_rel
 *  com.jcg.company.model.Tb_cuser
 *  com.jcg.company.model.Tb_sys_param
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.crypto.password.StandardPasswordEncoder
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import cn.hutool.core.util.ObjectUtil;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.jcg.cache.SystemParamCache;
import com.jcg.common.BaseService;
import com.jcg.common.DateUtil;
import com.jcg.common.PromptProperties;
import com.jcg.common.SmsUtils;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.CompanyAuthoritiesDao;
import com.jcg.company.idao.CompanyDao;
import com.jcg.company.idao.CompanyRolesRelDao;
import com.jcg.company.idao.CuserDao;
import com.jcg.company.idao.SysParamDao;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_company_authorities;
import com.jcg.company.model.Tb_company_roles_rel;
import com.jcg.company.model.Tb_cuser;
import com.jcg.company.model.Tb_sys_param;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CuserServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private CuserDao cuserDao;
    @Autowired
    private StandardPasswordEncoder standardPasswordEncoder;
    @Autowired
    private SysParamDao sysParamDao;
    @Autowired
    private CompanyRolesRelDao roleRelDao;
    @Autowired
    private CompanyAuthoritiesDao authDao;
    @Autowired
    private CompanyDao companyDao;
    @Autowired
    private SystemParamCache systemParamCache;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=================start " + identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Integer sd_cuser_id = null;
        Tb_cuser cuser = new Tb_cuser();
        Page page = new Page();
        String[] roleArr = null;
        if (param != null) {
            sd_cuser_id = XcbStringUtils.getObjtoint((Object)param.get("sd_cuser_id"));
            cuser = (Tb_cuser)param.get("cuser");
            page = (Page)param.get("page");
            roleArr = (String[])param.get("roleArr");
        }
        try {
            if (XcbConstantValue.CUSER_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createCuser(identifier, cuser);
            } else if (XcbConstantValue.CUSER_LOGIN.equals(functionCode)) {
                String sr_cuser_name = XcbStringUtils.getObjtoString((Object)param.get("sr_cuser_name"));
                String sr_password = XcbStringUtils.getObjtoString((Object)param.get("sr_password"));
                ret = this.login(sr_cuser_name, sr_password);
            } else if (XcbConstantValue.CUSER_FIND_BY_USERNAME.equals(functionCode)) {
                String sr_cuser_name = XcbStringUtils.getObjtoString((Object)param.get("sr_cuser_name"));
                ret = this.findCuserByUserName(sr_cuser_name);
            } else if (XcbConstantValue.CUSER_UPDATE_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.cuserUpdateById(identifier, cuser);
            } else if (XcbConstantValue.CUSER_UPDATE_STS_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.cuserUpdateStsById(identifier, cuser);
            } else if (XcbConstantValue.CUSER_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findCuserById(identifier, sd_cuser_id);
            } else if (XcbConstantValue.CUSER_FIND_BYNAME.equals(functionCode)) {
                String sr_cuser_name = XcbStringUtils.getObjtoString((Object)param.get("sr_cuser_name"));
                ret = this.findCuserByName(identifier, sr_cuser_name);
            } else if (XcbConstantValue.CUSER_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findCusersByParam(identifier, cuser, page);
            } else if (XcbConstantValue.CUSER_UPDATE_PASSWORD.equalsIgnoreCase(functionCode)) {
                ret = this.updatePassword(identifier, cuser);
            } else if (XcbConstantValue.CUSER_ROLE_FIND_BYUSERID.equalsIgnoreCase(functionCode)) {
                ret = this.findUserRolesByUserId(identifier, sd_cuser_id);
            } else if (XcbConstantValue.CUSER_AUTH_FIND_BYUSERID.equalsIgnoreCase(functionCode)) {
                ret = this.findUserAuthsByUserId(identifier, sd_cuser_id);
            } else if (XcbConstantValue.CUSER_ROLE_UPDATE_BYUSERID.equalsIgnoreCase(functionCode)) {
                ret = this.updateUserRolesByUserId(identifier, sd_cuser_id, roleArr);
            } else if (XcbConstantValue.CUSER_FIND_ALL.equalsIgnoreCase(functionCode)) {
                ret = this.findAllCuser();
            } else if (XcbConstantValue.CUSER_VALIDATE_USERNAME.equalsIgnoreCase(functionCode)) {
                ret = this.validateCuserUsername(cuser);
            } else if (XcbConstantValue.CUSER_RESET_PASSWORD_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.resetCuserPasswordById(identifier, cuser);
            } else if (XcbConstantValue.CUSER_SEND_SMS.equalsIgnoreCase(functionCode)) {
                ret = this.sendSms(identifier, cuser);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> login(String sr_cuser_name, String sr_password) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        boolean isSuccess = false;
        boolean isPass = false;
        String msg = "";
        try {
            Tb_cuser cuser = this.cuserDao.findCuserByName(sr_cuser_name);
            if (cuser != null) {
                Date today = new Date();
                String lastModify = cuser.getTm_modify_time() == null ? "" : XcbDateUtil.formatDate((Date)cuser.getTm_modify_time(), (String)"yyyy-MM-dd");
                String todayStr = XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd");
                isPass = this.standardPasswordEncoder.matches((CharSequence)sr_password, cuser.getPassword());
                if (isPass) {
                    if (cuser.getSr_status().equals(XcbConstantValue.CUSER_STATUS_ZX)) {
                        msg = PromptProperties.getProperty("cuser.login.error.zx");
                    } else if (cuser.getSr_status().equals(XcbConstantValue.CUSER_STATUS_DJ)) {
                        msg = PromptProperties.getProperty("cuser.login.error.dj");
                    } else if (cuser.getSr_status().equals(XcbConstantValue.CUSER_STATUS_SD)) {
                        msg = PromptProperties.getProperty("cuser.login.error.sd");
                    } else if (cuser.getSr_status().equals(XcbConstantValue.CUSER_STATUS_ZC)) {
                        cuser.setSi_errorpass_count(new Integer(0));
                        this.cuserDao.updateById(cuser);
                        isSuccess = true;
                    } else {
                        msg = PromptProperties.getProperty("cuser.login.fail");
                    }
                } else {
                    cuser.setTm_modify_time(today);
                    Integer errCnt = cuser.getSi_errorpass_count() == null ? new Integer(0) : cuser.getSi_errorpass_count();
                    errCnt = errCnt + 1;
                    Integer maxPassCnt = this.getMaxPassCnt();
                    if (!lastModify.equals(todayStr)) {
                        errCnt = new Integer(1);
                    }
                    Integer remainCnt = maxPassCnt - errCnt;
                    msg = PromptProperties.getProperty("cuser.login.error.pwd", remainCnt);
                    cuser.setSi_errorpass_count(errCnt);
                    if (errCnt.compareTo(maxPassCnt - 1) > 0) {
                        cuser.setSr_status(XcbConstantValue.CUSER_STATUS_SD);
                        this.cuserDao.updateStsById(cuser);
                        msg = PromptProperties.getProperty("cuser.login.error.lock", remainCnt);
                    } else {
                        this.cuserDao.updateById(cuser);
                    }
                }
            } else {
                msg = PromptProperties.getProperty("cuser.login.error.non-existent");
            }
            if (isSuccess) {
                ret.put(XcbConstantValue.DATA, cuser);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("cuser.login.success"));
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, msg);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_LOGIN, PromptProperties.getProperty("cuser.login.error"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> findCuserByUserName(String sr_cuser_name) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_company c;
            Tb_company company;
            Tb_cuser cuser = this.cuserDao.findCuserByName(sr_cuser_name);
            if (ObjectUtil.isNotEmpty((Object)cuser) && ObjectUtil.isNotEmpty((Object)(company = this.companyDao.findCompanyById(cuser.getSw_company_id()))) && XcbConstantValue.COMPANY_TYPE_FGS.equals(company.getSr_type()) && ObjectUtil.isNotEmpty((Object)(c = this.companyDao.findCompanyByType(XcbConstantValue.COMPANY_TYPE_ZGS)))) {
                cuser.setSw_company_pid(c.getSd_company_id());
            }
            ret.put(XcbConstantValue.DATA, cuser);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_FIND_BY_USERNAME, PromptProperties.getProperty("agent.find.error"), (Throwable)e);
        }
        return ret;
    }

    @Transactional
    public Map<String, Object> cuserUpdateById(Identifier identifier, Tb_cuser cuser) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int count = this.cuserDao.updateById(cuser);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("cuser.update.success"));
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("cuser.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_UPDATE_BYID, PromptProperties.getProperty("cuser.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    public Map<String, Object> cuserUpdateStsById(Identifier identifier, Tb_cuser cuser) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            String opt = cuser.getOptStr();
            Tb_cuser cuserDb = this.cuserDao.findCuserById(cuser.getSd_cuser_id());
            cuser.setSr_cuser_name(cuserDb.getSr_cuser_name());
            if (cuserDb.getSr_status().equalsIgnoreCase(XcbConstantValue.CUSER_STATUS_ZX)) {
                ret_method.put(XcbConstantValue.MSG, "\u7528\u6237\u5df2\u6ce8\u9500,\u64cd\u4f5c\u5931\u8d25!");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                return ret_method;
            }
            if (cuserDb.getSr_status().equalsIgnoreCase(XcbConstantValue.CUSER_STATUS_DJ)) {
                if (!opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_DISABLE) && !opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_UNFROZEN)) {
                    ret_method.put(XcbConstantValue.MSG, "\u7528\u6237\u5df2\u51bb\u7ed3,\u64cd\u4f5c\u5931\u8d25!");
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    return ret_method;
                }
                if (opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_UNFROZEN)) {
                    cuser.setSi_errorpass_count(new Integer(0));
                }
            }
            if (cuserDb.getSr_status().equalsIgnoreCase(XcbConstantValue.CUSER_STATUS_SD)) {
                if (!(opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_DISABLE) || opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_FROZEN) || opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_UNLOCK))) {
                    ret_method.put(XcbConstantValue.MSG, "\u7528\u6237\u5df2\u9501\u5b9a,\u64cd\u4f5c\u5931\u8d25!");
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    return ret_method;
                }
                if (opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_UNLOCK)) {
                    cuser.setSi_errorpass_count(new Integer(0));
                }
            }
            if (opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_UNLOCK) || opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_UNFROZEN)) {
                cuser.setSr_status(XcbConstantValue.CUSER_STATUS_ZC);
            } else if (opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_LOCK)) {
                cuser.setSr_status(XcbConstantValue.CUSER_STATUS_SD);
            } else if (opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_FROZEN)) {
                cuser.setSr_status(XcbConstantValue.CUSER_STATUS_DJ);
            } else if (opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_DISABLE)) {
                cuser.setSr_status(XcbConstantValue.CUSER_STATUS_ZX);
            }
            int result = this.cuserDao.updateStsById(cuser);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, "\u64cd\u4f5c\u6210\u529f");
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u64cd\u4f5c\u5931\u8d25");
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_UPDATE_BYID, "\u516c\u53f8\u7528\u6237\u64cd\u4f5c\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findCuserByName(Identifier identifier, String sr_cuser_name) {
        HashMap<String, Object> ret_method2 = new HashMap<String, Object>();
        try {
            Tb_cuser cuser = this.cuserDao.findCuserByName(sr_cuser_name);
            ret_method2.put(XcbConstantValue.DATA, cuser);
            this.initResultMap(ret_method2);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_FIND_BYNAME, "\u901a\u8fc7\u7528\u6237\u540d\u67e5\u627e\u516c\u53f8\u7528\u6237\u5931\u8d25", (Throwable)e);
        }
        return ret_method2;
    }

    private Map<String, Object> findCusersByParam(Identifier identifier, Tb_cuser cuser, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_cuser> cusers = this.cuserDao.findCusersByCuser(cuser, page);
            int totalCount = this.cuserDao.findCusersCntByCuser(cuser);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("cusers", cusers);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_FIND_BYPARAM, PromptProperties.getProperty("cuser.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findCuserById(Identifier identifier, Integer sd_cuser_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_cuser cuser = this.cuserDao.findCuserById(sd_cuser_id);
            ret_method.put(XcbConstantValue.DATA, cuser);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_FIND_BYID, PromptProperties.getProperty("cuser.findbyid.error"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    public Map<String, Object> createCuser(Identifier identifier, Tb_cuser cuser) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_cuser cuser_same = this.cuserDao.findCuserByName(cuser.getSr_cuser_name());
            if (cuser_same != null) {
                ret_method.put(XcbConstantValue.MSG, "\u624b\u673a\u53f7\u5df2\u5b58\u5728\uff0c\u7528\u6237\u521b\u5efa\u5931\u8d25\uff01");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                this.initResultMap(ret_method);
                return ret_method;
            }
            cuser.setSr_status(XcbConstantValue.CUSER_STATUS_ZC);
            Tb_sys_param sysParamMod = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.CPASS);
            String defaultPass = sysParamMod.getSr_param_value();
            String password_md5 = this.standardPasswordEncoder.encode((CharSequence)defaultPass);
            cuser.setSr_password(password_md5);
            cuser.setSr_password_mw(defaultPass);
            cuser.setTm_create_time(new Date());
            int count = this.cuserDao.createCuser(cuser);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("cuser.create.success"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_CREATE, PromptProperties.getProperty("cuser.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    public Map<String, Object> updatePassword(Identifier identifier, Tb_cuser cuser) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        int result = 0;
        try {
            String password = cuser.getSr_password();
            String password_md5 = this.standardPasswordEncoder.encode((CharSequence)password);
            cuser.setSr_password(password_md5);
            cuser.setSr_password_mw(password);
            result = this.cuserDao.updatePassword(cuser);
            if (result > 0) {
                Tb_cuser _cuser = this.cuserDao.findCuserById(cuser.getSd_cuser_id());
                cuser.setSr_cuser_name(_cuser.getSr_cuser_name());
                this.cuserDao.updateById(cuser);
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("cuser.updatepwd.success"));
                map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                map.put(XcbConstantValue.MSG, PromptProperties.getProperty("cuser.updatepwd.fail"));
                map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(map);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AGENT_UPDATE, PromptProperties.getProperty("cuser.updatepwd.error"), (Throwable)e);
        }
        return map;
    }

    private Map<String, Object> findUserRolesByUserId(Identifier identifier, Integer sd_cuser_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Tb_company_roles_rel> cuserRoles = this.roleRelDao.findByCuserId(sd_cuser_id);
            ret_method.put(XcbConstantValue.DATA, cuserRoles);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_FIND_BYID, PromptProperties.getProperty("cuser.find.role.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findUserAuthsByUserId(Identifier identifier, Integer sd_cuser_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Tb_company_authorities> cuserAuths = this.authDao.findAuthsByCuserId(sd_cuser_id);
            ret_method.put(XcbConstantValue.DATA, cuserAuths);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_FIND_BYID, PromptProperties.getProperty("cuser.find.auth.error"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    public Map<String, Object> updateUserRolesByUserId(Identifier identifier, Integer sd_cuser_id, String[] roleArr) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            this.roleRelDao.deleteByCuserId(sd_cuser_id);
            ArrayList<Tb_company_roles_rel> userRoles = new ArrayList<Tb_company_roles_rel>();
            Date current = new Date();
            for (int i = 0; i < roleArr.length; ++i) {
                Tb_company_roles_rel userRole = new Tb_company_roles_rel();
                userRole.setSw_cuser_id(sd_cuser_id);
                userRole.setSw_roles_id(Integer.valueOf(roleArr[i]));
                userRole.setTm_createdate(current);
                userRole.setSi_createuser(identifier.getUserId());
                userRoles.add(userRole);
            }
            if (userRoles.size() > 0) {
                this.roleRelDao.insertUserRoleByBatch(userRoles);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_ROLE_UPDATE_BYUSERID, PromptProperties.getProperty("cuser.update.auth.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findAllCuser() {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> cusers = this.cuserDao.findAllCuser();
            ret_method.put(XcbConstantValue.DATA, cusers);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_FIND_ALL, "\u67e5\u8be2\u6240\u6709\u516c\u53f8\u7528\u6237", (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> validateCuserUsername(Tb_cuser cuser) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Boolean> dataMap = new HashMap<String, Boolean>();
        boolean isExistName = false;
        String phone = cuser.getSr_phone();
        Integer cuserId = cuser.getSd_cuser_id();
        try {
            Tb_cuser cuser_same = this.cuserDao.findCuserByName(phone);
            if (cuser_same != null) {
                String sr_name = cuser_same.getSr_cuser_name();
                Integer sd_cuser_id = cuser_same.getSd_cuser_id();
                if (!XcbStringUtils.isNullOrBlank((Object)sr_name)) {
                    if (XcbStringUtils.isNullOrBlank((Object)cuserId)) {
                        if (phone.equals(sr_name)) {
                            isExistName = true;
                        }
                    } else if (phone.equals(sr_name) && !cuserId.equals(sd_cuser_id)) {
                        isExistName = true;
                    }
                }
            }
            dataMap.put("isExistName", isExistName);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_VALIDATE_USERNAME, PromptProperties.getProperty("cuser.validate.username.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> resetCuserPasswordById(Identifier identifier, Tb_cuser cuser) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        ArrayList<String> keyCodelist = new ArrayList<String>();
        try {
            String opt = cuser.getOptStr();
            if (opt.equalsIgnoreCase(XcbConstantValue.CUSER_OPT_RESETPASWD)) {
                Tb_sys_param sysParam = new Tb_sys_param();
                sysParam.setSr_category_code(XcbConstantValue.XTCL);
                keyCodelist.add(XcbConstantValue.CPASS);
                sysParam.setSr_key_code_list(keyCodelist);
                List<Tb_sys_param> sysParamList = this.sysParamDao.findSysParamByKeyCode_cpy(sysParam);
                String password = sysParamList.get(0).getSr_param_value();
                String password_md5 = this.standardPasswordEncoder.encode((CharSequence)password);
                cuser.setSr_password(password_md5);
                cuser.setSr_password_mw(password);
                cuser.setTm_modify_time(new Date());
                cuser.setSi_modify_person(identifier.getUserId());
            }
            int count = this.cuserDao.resetPasswordById(cuser);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("cuser.update.success"));
            } else {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("cuser.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_RESET_PASSWORD_BYID, PromptProperties.getProperty("cuser.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Integer getMaxPassCnt() {
        Integer cnt = 6;
        try {
            Map<String, Object> sysParam = this.systemParamCache.getSysParamByType(XcbConstantValue.XTCL, XcbConstantValue.MMCS);
            String passCntStr = XcbStringUtils.getObjtoString((Object)sysParam.get("label"));
            if (passCntStr != null) {
                cnt = XcbStringUtils.getObjtoint((Object)passCntStr);
            }
        }
        catch (Exception e) {
            this.log.info("Error Msg: \u83b7\u5f97\u7cfb\u7edf\u8bbe\u7f6e\u6700\u5927\u5bc6\u7801\u8f93\u9519\u6b21\u6570 \u5f02\u5e38");
        }
        return cnt;
    }

    private Map<String, Object> sendSms(Identifier identifier, Tb_cuser cuser) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Map<String, Object> sysMap = this.systemParamCache.getSysParamByType(XcbConstantValue.XTCL, XcbConstantValue.YZMCS);
            Tb_sys_param phoneMap = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.PAY_PHONE);
            Tb_sys_param smsCodeMap = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.PAY_SMS_CODE);
            Tb_sys_param smsTimeMap = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.PAY_SMS_TIME);
            Tb_sys_param smsCntMap = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.PAY_SMS_CNT);
            String maxCount = XcbStringUtils.getObjtoString((Object)sysMap.get("label"));
            String phone = XcbStringUtils.getObjtoString((Object)phoneMap.getSr_param_value());
            String sr_sms_time = XcbStringUtils.getObjtoString((Object)smsTimeMap.getSr_param_value());
            int si_verifycode_count = XcbStringUtils.getObjtoint((Object)smsCntMap.getSr_param_value());
            boolean isSuccess = true;
            boolean flag = true;
            flag = !XcbStringUtils.isNullOrBlank((Object)sr_sms_time) ? DateUtil.isSameDate(XcbDateUtil.parseDate((String)sr_sms_time, (String)"yyyy-MM-dd HH:mm:ss"), new Date()) : false;
            int verifycode_count = 0;
            if (flag) {
                verifycode_count = si_verifycode_count;
            }
            if (verifycode_count >= Integer.valueOf(maxCount)) {
                isSuccess = false;
                ret.put(XcbConstantValue.MSG, "\u5f53\u65e5\u77ed\u4fe1\u53d1\u9001\u6b21\u6570\u6700\u591a\u4e3a" + maxCount + "\u6b21,\u8bf7\u660e\u5929\u518d\u8bd5\uff01!");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            if (isSuccess) {
                String templateCode;
                Tb_company company;
                String signName;
                String verifyCode = String.valueOf(new Random().nextInt(8999) + 1000);
                SendSmsResponse sendSmsResponse = SmsUtils.getloginSms(verifyCode, signName = (company = this.companyDao.findCompanyById(cuser.getSw_company_id())).getSr_sms_signName(), phone, templateCode = company.getSr_sms_mould_other());
                if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
                    smsTimeMap.setSr_param_value(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
                    this.sysParamDao.updateById_cpy(smsTimeMap);
                    smsCntMap.setSr_param_value(XcbStringUtils.getObjtoString((Object)(verifycode_count + 1)));
                    this.sysParamDao.updateById_cpy(smsCntMap);
                    smsCodeMap.setSr_param_value(verifyCode);
                    this.sysParamDao.updateById_cpy(smsCodeMap);
                    ret.put(XcbConstantValue.MSG, "\u77ed\u4fe1\u9a8c\u8bc1\u7801\u8bf7\u6c42\u6210\u529f!");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                } else {
                    String message = sendSmsResponse.getMessage();
                    if (message != null) {
                        String[] msgArr = message.split(":");
                        Integer msgCode = Integer.valueOf(msgArr[1]);
                        if (XcbConstantValue.ALI_FAIL_1.equals(msgCode)) {
                            ret.put(XcbConstantValue.MSG, "\u4e00\u5206\u949f\u5185\u53ea\u80fd\u53d1\u9001\u4e00\u6761\u77ed\u4fe1\u9a8c\u8bc1\u7801,\u8bf7\u52ff\u9891\u7e41\u64cd\u4f5c!");
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        } else if (XcbConstantValue.ALI_FAIL_5.equals(msgCode)) {
                            ret.put(XcbConstantValue.MSG, "\u4e00\u5c0f\u65f6\u5185\u77ed\u4fe1\u53d1\u9001\u6761\u6570\u4e0d\u8d85\u8fc75\u6761,\u8bf7\u7a0d\u540e\u518d\u8bd5!");
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        } else if (XcbConstantValue.ALI_FAIL_10.equals(msgCode)) {
                            ret.put(XcbConstantValue.MSG, "\u5f53\u5929\u77ed\u4fe1\u53d1\u9001\u6761\u6570\u4e0d\u8d85\u8fc710\u6761!,\u8bf7\u660e\u65e5\u518d\u8bd5");
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        } else {
                            ret.put(XcbConstantValue.MSG, "\u77ed\u4fe1\u9a8c\u8bc1\u7801\u8bf7\u6c42\u5931\u8d25!");
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        }
                    } else {
                        ret.put(XcbConstantValue.MSG, "\u77ed\u4fe1\u9a8c\u8bc1\u7801\u8bf7\u6c42\u5931\u8d25!");
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    }
                }
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_SEND_SMS, "\u77ed\u4fe1\u9a8c\u8bc1\u7801\u8bf7\u6c42\u5931\u8d25", (Throwable)e);
        }
        return ret;
    }
}

