/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_customer_app
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.CustomerAppDao;
import com.jcg.company.model.Tb_customer_app;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class CustomerAppServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private CustomerAppDao customerAppDao;
    @Autowired
    private CommonLogic commonLogic;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=======CustomerAppServiceImpl==========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_customer_app customer_app = new Tb_customer_app();
        Page page = new Page();
        if (param != null) {
            customer_app = (Tb_customer_app)param.get("customer_app");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.CUSTOMERAPP_CREATE_USER.equalsIgnoreCase(functionCode)) {
                ret = this.createCustomerApp(customer_app);
            } else if (XcbConstantValue.CUSTOMERAPP_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findCustomerAppByParam(customer_app, page);
            } else if (XcbConstantValue.CUSTOMERAPP_UPDATE_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateCustomerAppById(identifier, customer_app);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findCustomerAppByParam(Tb_customer_app customer_app, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Object>> dataMap = new HashMap<String, List<Object>>();
        List<Tb_customer_app> customerApps = null;
        try {
            customerApps = this.customerAppDao.findByParam(customer_app, page);
            int count = this.customerAppDao.findCountByParam(customer_app);
            page.setTotal(count);
            dataMap.put("customerApps", customerApps);
            dataMap.put("page", (List<Object>)page);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSTOMERAPP_FIND_BYPARAM_CPY, "\u67e5\u8be2\u52a0\u76df\u7533\u8bf7\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> updateCustomerAppById(Identifier identifier, Tb_customer_app customer_app) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int count = 0;
        try {
            customer_app.setTm_deal_time(new Date());
            customer_app.setSi_deal_user(identifier.getUserId());
            count = this.customerAppDao.updateById(customer_app);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, "\u66f4\u65b0\u52a0\u76df\u7533\u8bf7\u6210\u529f");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u66f4\u65b0\u52a0\u76df\u7533\u8bf7\u5931\u8d25");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSTOMERAPP_UPDATE_BYID_CPY, "\u66f4\u65b0\u52a0\u76df\u7533\u8bf7\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> createCustomerApp(Tb_customer_app customer_app) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int count = 0;
        try {
            customer_app.setSr_status(XcbConstantValue.CUSTOMERAPP_DCL);
            customer_app.setTm_create_time(new Date());
            count = this.customerAppDao.createCustomerApp_user(customer_app);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                if (count > XcbConstantValue.OPERA_INT_ZERO) {
                    this.commonLogic.sendWXMsg(customer_app);
                    ret_method.put(XcbConstantValue.MSG, "\u521b\u5efa\u6210\u529f");
                } else {
                    ret_method.put(XcbConstantValue.MSG, "\u521b\u5efa\u5931\u8d25");
                }
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u521b\u5efa\u5931\u8d25");
            }
            ret_method.put(XcbConstantValue.STATUS, count);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSTOMERAPP_CREATE_USER, "\u521b\u5efa\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }
}

