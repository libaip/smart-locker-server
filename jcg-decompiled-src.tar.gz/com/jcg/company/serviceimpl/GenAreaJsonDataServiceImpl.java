/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.JsonData
 *  com.jcg.common.model.JsonDataRoot
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  net.sf.json.JSONArray
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.JsonData;
import com.jcg.common.model.JsonDataRoot;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.serviceimpl.AreaCityServiceImpl;
import com.jcg.company.serviceimpl.AreaDistrictServiceImpl;
import com.jcg.company.serviceimpl.AreaProvinceServiceImpl;
import com.jcg.company.serviceimpl.AreaTownServiceImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class GenAreaJsonDataServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private AreaProvinceServiceImpl areaProvinceService;
    @Autowired
    private AreaCityServiceImpl areaCityService;
    @Autowired
    private AreaDistrictServiceImpl areaDistrictService;
    @Autowired
    private AreaTownServiceImpl areaTownService;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========GenAreaJsonDataServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        String sd_code = null;
        if (param != null) {
            sd_code = XcbStringUtils.getObjtoString((Object)param.get("sd_code"));
        }
        try {
            if (XcbConstantValue.AREA_JSONDATA_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findAreaJsonDataByParam(identifier, sd_code);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    public Map<String, Object> findAreaJsonDataByParam(Identifier identifier, String sd_code) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            String areaJsonData = this.genJsonStreetAreaData(sd_code);
            ret_method.put(XcbConstantValue.DATA, areaJsonData);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AREA_JSONDATA_FIND_BYPARAM_CPY, PromptProperties.getProperty("area.jsondata.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }

    public String genJsonStreetAreaData(String sd_code) {
        Map<String, Object> map = this.areaProvinceService.findProvinceById(sd_code);
        List list = (List)map.get(XcbConstantValue.DATA);
        ArrayList<Object> dataList = new ArrayList<Object>();
        for (Object item : list) {
            HashMap province = (HashMap)item;
            for (Object key : province.keySet()) {
                String val;
                Map<String, Object> cityMap;
                List cityList;
                if (!"value".equals(key) || (cityList = (List)(cityMap = this.areaCityService.findCityById(val = (String)province.get(key))).get(XcbConstantValue.DATA)) == null) continue;
                for (Object item2 : cityList) {
                    String cityCode = "";
                    HashMap city = (HashMap)item2;
                    JsonData jsonData = new JsonData();
                    for (Object key2 : city.keySet()) {
                        if ("value".equals(key2)) {
                            String val2 = (String)city.get(key2);
                            jsonData.setValue(val2);
                            cityCode = val2;
                        }
                        if (!"label".equals(key2)) continue;
                        String lab2 = (String)city.get(key2);
                        jsonData.setLabel(lab2);
                    }
                    jsonData.setParent(val);
                    jsonData.setChildren(new ArrayList());
                    jsonData.setLoading(false);
                    dataList.add(jsonData);
                    Map<String, Object> districtsMap = this.areaDistrictService.findDistrictById(cityCode);
                    List districtsList = (List)districtsMap.get(XcbConstantValue.DATA);
                    if (districtsList == null) continue;
                    for (Object item3 : districtsList) {
                        String lab3;
                        String val3;
                        HashMap districts;
                        JsonDataRoot jsonData2;
                        String districtsCode = "";
                        if ("441900000000".equals(cityCode) || "442000000000".equals(cityCode) || "419001000000".equals(cityCode)) {
                            jsonData2 = new JsonDataRoot();
                            districts = (HashMap)item3;
                            for (Object key3 : districts.keySet()) {
                                if ("value".equals(key3)) {
                                    val3 = (String)districts.get(key3);
                                    jsonData2.setValue(val3);
                                    districtsCode = val3;
                                }
                                if (!"label".equals(key3)) continue;
                                lab3 = (String)districts.get(key3);
                                jsonData2.setLabel(lab3);
                            }
                            jsonData2.setParent(cityCode);
                            dataList.add(jsonData2);
                        } else {
                            jsonData2 = new JsonData();
                            districts = (HashMap)item3;
                            for (Object key3 : districts.keySet()) {
                                if ("value".equals(key3)) {
                                    val3 = (String)districts.get(key3);
                                    jsonData2.setValue(val3);
                                    districtsCode = val3;
                                }
                                if (!"label".equals(key3)) continue;
                                lab3 = (String)districts.get(key3);
                                jsonData2.setLabel(lab3);
                            }
                            jsonData2.setParent(cityCode);
                            jsonData2.setChildren(new ArrayList());
                            jsonData2.setLoading(false);
                            dataList.add(jsonData2);
                        }
                        Map<String, Object> townMap = this.areaTownService.findTownById(districtsCode);
                        List townList = (List)townMap.get(XcbConstantValue.DATA);
                        if (townList == null) continue;
                        for (Object item4 : townList) {
                            JsonDataRoot jsonData4 = new JsonDataRoot();
                            HashMap town = (HashMap)item4;
                            for (Object key4 : town.keySet()) {
                                if ("value".equals(key4)) {
                                    String val4 = (String)town.get(key4);
                                    jsonData4.setValue(val4);
                                }
                                if (!"label".equals(key4)) continue;
                                String lab4 = (String)town.get(key4);
                                jsonData4.setLabel(lab4);
                            }
                            jsonData4.setParent(districtsCode);
                            dataList.add(jsonData4);
                        }
                    }
                }
            }
        }
        JSONArray jsonArray = JSONArray.fromObject(dataList);
        String listJson = jsonArray.toString();
        return listJson;
    }
}

