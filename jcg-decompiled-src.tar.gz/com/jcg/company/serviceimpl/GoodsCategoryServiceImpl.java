/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_goods_category
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.GoodsCategoryDao;
import com.jcg.company.model.Tb_goods_category;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class GoodsCategoryServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private GoodsCategoryDao goodsCategoryDao;
    @Autowired
    private HttpServletRequest request;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=======GoodsCategoryServiceImpl==========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_goods_category category = new Tb_goods_category();
        Page page = new Page();
        if (param != null) {
            category = (Tb_goods_category)param.get("category");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.GOODS_CATEGORY_CREATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.createGoodsCategory(identifier, category);
            } else if (XcbConstantValue.GOODS_CATEGORY_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findGoodsCategoryByParam(category, page);
            } else if (XcbConstantValue.GOODS_CATEGORY_UPDATE_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateGoodsCategory(identifier, category);
            } else if (XcbConstantValue.GOODS_CATEGORY_ALL_COVERPIC_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findAllCatesCoverPic_cpy(identifier);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> createGoodsCategory(Identifier identifier, Tb_goods_category category) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int reuslt;
            category.setSr_create_person(identifier.getUserName());
            category.setTm_create_time(new Date());
            category.setSr_modify_person(identifier.getUserName());
            category.setTm_modify_time(new Date());
            category.setSr_status(XcbConstantValue.NETPOINT_ZC);
            if (!XcbStringUtils.isNullOrBlank((Object)category.getSr_picture())) {
                String sr_picture = category.getSr_picture();
                sr_picture = sr_picture.replaceAll("\\\\", "/");
                sr_picture = sr_picture.replaceAll("//", "/");
                category.setSr_picture(sr_picture);
            }
            if ((reuslt = this.goodsCategoryDao.createGoodsCategory(category)) > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, "\u5546\u54c1\u76ee\u5f55\u521b\u5efa\u6210\u529f");
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u5546\u54c1\u76ee\u5f55\u521b\u5efa\u5931\u8d25");
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.GOODS_CATEGORY_CREATE_CPY, "\u521b\u5efa\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> findGoodsCategoryByParam(Tb_goods_category category, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Object>> dataMap = new HashMap<String, List<Object>>();
        try {
            List<Tb_goods_category> categoryList = this.goodsCategoryDao.findGoodsCategoryByParam(category, page);
            int count = this.goodsCategoryDao.findCountByParam(category);
            page.setTotal(count);
            dataMap.put("categoryList", categoryList);
            dataMap.put("page", (List<Object>)page);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.GOODS_CATEGORY_FIND_BYPARAM_CPY, "\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> updateGoodsCategory(Identifier identifier, Tb_goods_category category) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int reuslt;
            category.setSr_modify_person(identifier.getUserName());
            category.setTm_modify_time(new Date());
            if (!XcbStringUtils.isNullOrBlank((Object)category.getSr_picture())) {
                String sr_picture = category.getSr_picture();
                sr_picture = sr_picture.replaceAll("\\\\", "/");
                sr_picture = sr_picture.replaceAll("//", "/");
                category.setSr_picture(sr_picture);
            }
            if ((reuslt = this.goodsCategoryDao.updateGoodsCategory(category)) > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, "\u66f4\u65b0\u6210\u529f");
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u66f4\u65b0\u5931\u8d25");
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.GOODS_CATEGORY_UPDATE_BYID_CPY, "\u66f4\u65b0\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> findAllCatesCoverPic_cpy(Identifier identifier) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            CommonLogic commonLogic = new CommonLogic();
            ArrayList<Tb_goods_category> catesList = commonLogic.getAllCatesCoverPic(map, this.request);
            map.put(XcbConstantValue.DATA, catesList);
            map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(map);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.GOODS_CATEGORY_ALL_COVERPIC_CPY, "\u56fe\u7247\u5217\u8868\u83b7\u53d6\u5f02\u5e38", (Throwable)e);
        }
        return map;
    }
}

