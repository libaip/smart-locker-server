/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_goods
 *  com.jcg.company.model.Tb_goods_category
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.GoodsCategoryDao;
import com.jcg.company.idao.GoodsDao;
import com.jcg.company.model.Tb_goods;
import com.jcg.company.model.Tb_goods_category;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class GoodsServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private GoodsDao goodsDao;
    @Autowired
    private GoodsCategoryDao goodsCategoryDao;
    @Autowired
    private HttpServletRequest request;
    @Autowired
    private RedisUtil redis;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=======GoodsServiceImpl==========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_goods goods = new Tb_goods();
        Page page = new Page();
        if (param != null) {
            goods = (Tb_goods)param.get("goods");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.GOODS_CREATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.createGoods(identifier, goods);
            } else if (XcbConstantValue.GOODS_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findGoodsByParam_cpy(goods, page);
            } else if (XcbConstantValue.GOODS_UPDATE_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateGoods(identifier, goods);
            } else if (XcbConstantValue.GOODS_CATEGORY_ALL_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findAllCates_cpy(identifier);
            } else if (XcbConstantValue.GOODS_FIND_MAX_ID.equalsIgnoreCase(functionCode)) {
                ret = this.findMaxId(identifier);
            } else if (XcbConstantValue.GOODS_FIND_BYPARAM_USER.equalsIgnoreCase(functionCode)) {
                ret = this.findGoodsByParam_user(goods, page);
            } else if (XcbConstantValue.GOODS_FIND_BYID.equalsIgnoreCase(functionCode)) {
                Integer sd_id = XcbStringUtils.getObjtoint((Object)param.get("sd_id"));
                ret = this.findGoodsById(identifier, sd_id);
            } else if (XcbConstantValue.GOODS_FIND_BYIDARR.equalsIgnoreCase(functionCode)) {
                Integer[] idArr = (Integer[])param.get("idArr");
                ret = this.findGoodsByIdArr(identifier, idArr);
            } else if (XcbConstantValue.GOODS_FIND_CART_USER.equalsIgnoreCase(functionCode)) {
                ret = this.findGoodsCart_user(identifier, goods);
            } else if (XcbConstantValue.GOODS_UPDATE_CART_USER.equalsIgnoreCase(functionCode)) {
                ret = this.updateGoodsCart_user(identifier, goods);
            } else if (XcbConstantValue.GOODS_REMOVE_CART_USER.equalsIgnoreCase(functionCode)) {
                ret = this.removeGoodsCart_user(identifier, goods);
            } else if (XcbConstantValue.GOODS_REMOVE_ALL_CART_USER.equalsIgnoreCase(functionCode)) {
                ret = this.removeAllGoodsCart_user(identifier, goods);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> createGoods(Identifier identifier, Tb_goods goods) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            goods.setSr_create_person(identifier.getUserName());
            goods.setTm_create_time(new Date());
            goods.setSr_modify_person(identifier.getUserName());
            goods.setTm_modify_time(new Date());
            goods.setSr_status(XcbConstantValue.NETPOINT_ZC);
            int reuslt = this.goodsDao.createGoods(goods);
            if (reuslt > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, "\u5546\u54c1\u521b\u5efa\u6210\u529f");
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u5546\u54c1\u521b\u5efa\u5931\u8d25");
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.GOODS_CREATE_CPY, "\u521b\u5efa\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> findGoodsByParam_cpy(Tb_goods goods, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Object>> dataMap = new HashMap<String, List<Object>>();
        try {
            List<Tb_goods> goodsList = this.goodsDao.findGoodsByParam(goods, page);
            int count = this.goodsDao.findCountByParam(goods);
            page.setTotal(count);
            dataMap.put("goodsList", goodsList);
            dataMap.put("page", (List<Object>)page);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.GOODS_FIND_BYPARAM_CPY, "\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> findGoodsByParam_user(Tb_goods goods, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Object>> dataMap = new HashMap<String, List<Object>>();
        try {
            goods.setSr_status(XcbConstantValue.NETPOINT_ZC);
            List<Tb_goods> goodsList = this.goodsDao.findGoodsByParam(goods, page);
            int count = this.goodsDao.findCountByParam(goods);
            page.setTotal(count);
            dataMap.put("goodsList", goodsList);
            dataMap.put("page", (List<Object>)page);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.GOODS_FIND_BYPARAM_USER, "\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> findGoodsById(Identifier identifier, Integer sd_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_goods> dataMap = new HashMap<String, Tb_goods>();
        try {
            Tb_goods goods = this.goodsDao.findGoodsById(sd_id);
            Integer count = XcbStringUtils.getObjtoint((Object)this.redis.get("Cart_" + identifier.getUserId() + "_id_" + sd_id));
            goods.setSi_shopping_cart(count);
            dataMap.put("goods", goods);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.GOODS_FIND_BYID, "\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> findGoodsByIdArr(Identifier identifier, Integer[] idArr) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_goods> goodsList = this.goodsDao.findGoodsByIdArr(idArr);
            BigDecimal dc_price_sum = BigDecimal.ZERO;
            for (Tb_goods g : goodsList) {
                Integer si_shopping_cart = XcbStringUtils.getObjtoint((Object)this.redis.get("Cart_" + identifier.getUserId() + "_id_" + g.getSd_id()));
                g.setSi_shopping_cart(si_shopping_cart);
                BigDecimal dc_shopping_price = BigDecimalUtil.mul((BigDecimal)g.getDc_price(), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)si_shopping_cart));
                BigDecimal dc_shopping_integral = BigDecimalUtil.mul((BigDecimal)g.getDc_integral(), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)si_shopping_cart));
                g.setDc_shopping_price(dc_shopping_price);
                g.setDc_shopping_integral(dc_shopping_integral);
                BigDecimal total_sum = dc_shopping_price;
                dc_price_sum = BigDecimalUtil.add((BigDecimal)dc_price_sum, (BigDecimal)total_sum);
            }
            dataMap.put("goodsList", goodsList);
            dataMap.put("dc_price_sum", dc_price_sum);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.GOODS_FIND_BYID, "\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    private Map<String, Object> updateGoods(Identifier identifier, Tb_goods goods) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            goods.setSr_modify_person(identifier.getUserName());
            goods.setTm_modify_time(new Date());
            int reuslt = this.goodsDao.updateGoods(goods);
            if (reuslt > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, "\u66f4\u65b0\u6210\u529f");
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u66f4\u65b0\u5931\u8d25");
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.GOODS_UPDATE_BYID_CPY, "\u66f4\u65b0\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> findAllCates_cpy(Identifier identifier) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            ArrayList<Tb_goods_category> catesList = this.goodsCategoryDao.findAllCates_cpy();
            map.put(XcbConstantValue.DATA, catesList);
            map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.GOODS_CATEGORY_ALL_CPY, "\u5217\u8868\u83b7\u53d6\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(map);
        return map;
    }

    public Map<String, Object> findMaxId(Identifier identifier) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            int id = this.goodsDao.findMaxId();
            map.put(XcbConstantValue.DATA, ++id);
            map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.GOODS_FIND_MAX_ID, "\u83b7\u53d6ID\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(map);
        return map;
    }

    public Map<String, Object> findGoodsCart_user(Identifier identifier, Tb_goods goods) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Serializable> dataMap = new HashMap<String, Serializable>();
        try {
            List<Object> cartList = new ArrayList();
            ArrayList<Integer> list = new ArrayList<Integer>();
            List<Integer> idList = this.goodsDao.findGoodIdList(goods);
            for (Integer n : idList) {
                Integer n2 = XcbStringUtils.getObjtoint((Object)this.redis.get("Cart_" + identifier.getUserId() + "_id_" + n));
                if (n2 <= 0) continue;
                list.add(n);
            }
            BigDecimal dc_price_sum = BigDecimal.ZERO;
            if (list != null && list.size() > 0) {
                goods.setGoodsArr(list.toArray(new Integer[list.size()]));
                cartList = this.goodsDao.findGoodsCartByParam_user(goods);
                for (Tb_goods tb_goods : cartList) {
                    Integer si_shopping_cart = XcbStringUtils.getObjtoint((Object)this.redis.get("Cart_" + identifier.getUserId() + "_id_" + tb_goods.getSd_id()));
                    tb_goods.setSi_shopping_cart(si_shopping_cart);
                    BigDecimal dc_shopping_price = BigDecimalUtil.mul((BigDecimal)tb_goods.getDc_price(), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)si_shopping_cart));
                    BigDecimal dc_shopping_integral = BigDecimalUtil.mul((BigDecimal)tb_goods.getDc_integral(), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)si_shopping_cart));
                    tb_goods.setDc_shopping_price(dc_shopping_price);
                    tb_goods.setDc_shopping_integral(dc_shopping_integral);
                    BigDecimal total_sum = dc_shopping_price;
                    dc_price_sum = BigDecimalUtil.add((BigDecimal)dc_price_sum, (BigDecimal)total_sum);
                }
            }
            String string = CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_price_sum));
            dataMap.put("cartList", (Serializable)((Object)cartList));
            dataMap.put("dc_price_sum", dc_price_sum);
            dataMap.put("dc_price_fen_sum", XcbStringUtils.getObjToBigDecimal((Object)string));
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.GOODS_FIND_CART_USER, "\u8d2d\u7269\u8f66\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> updateGoodsCart_user(Identifier identifier, Tb_goods goods) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Number> dataMap = new HashMap<String, Number>();
        try {
            Integer sd_id = goods.getSd_id();
            Integer si_shopping_cart = goods.getSi_shopping_cart();
            this.redis.setForTimeMIN("Cart_" + identifier.getUserId() + "_id_" + sd_id, si_shopping_cart, 1440L);
            int total = 0;
            List<Integer> idList = this.goodsDao.findGoodIdList(goods);
            for (Integer id : idList) {
                Integer count = XcbStringUtils.getObjtoint((Object)this.redis.get("Cart_" + identifier.getUserId() + "_id_" + id));
                total = count + total;
            }
            BigDecimal dc_price_sum = BigDecimal.ZERO;
            goods.setGoodsArr(idList.toArray(new Integer[idList.size()]));
            List<Tb_goods> cartList = this.goodsDao.findGoodsCartByParam_user(goods);
            for (Tb_goods cart : cartList) {
                Integer shopping_cart = XcbStringUtils.getObjtoint((Object)this.redis.get("Cart_" + identifier.getUserId() + "_id_" + cart.getSd_id()));
                if (shopping_cart <= 0) continue;
                cart.setSi_shopping_cart(shopping_cart);
                BigDecimal dc_shopping_price = BigDecimalUtil.mul((BigDecimal)cart.getDc_price(), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)shopping_cart));
                BigDecimal dc_shoping_integral = BigDecimalUtil.mul((BigDecimal)cart.getDc_integral(), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)shopping_cart));
                cart.setDc_shopping_price(dc_shopping_price);
                cart.setDc_shopping_integral(dc_shoping_integral);
                BigDecimal total_sum = dc_shopping_price;
                dc_price_sum = BigDecimalUtil.add((BigDecimal)dc_price_sum, (BigDecimal)total_sum);
            }
            String dc_price_fen_sum = CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_price_sum));
            dataMap.put("total", total);
            dataMap.put("dc_price_sum", dc_price_sum);
            dataMap.put("dc_price_fen_sum", XcbStringUtils.getObjToBigDecimal((Object)dc_price_fen_sum));
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.GOODS_UPDATE_CART_USER, "\u8d2d\u7269\u8f66\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> removeGoodsCart_user(Identifier identifier, Tb_goods goods) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Integer sd_id = goods.getSd_id();
            this.redis.delete("Cart_" + identifier.getUserId() + "_id_" + sd_id);
            ret.put(XcbConstantValue.MSG, "\u5220\u9664\u6210\u529f");
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.GOODS_REMOVE_CART_USER, "\u79fb\u9664\u8d2d\u7269\u8f66\u5f02\u5e38", (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> removeAllGoodsCart_user(Identifier identifier, Tb_goods goods) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            for (Integer sd_id : goods.getGoodsArr()) {
                this.redis.delete("Cart_" + identifier.getUserId() + "_id_" + sd_id);
            }
            ret.put(XcbConstantValue.MSG, "\u5220\u9664\u6210\u529f");
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.GOODS_REMOVE_ALL_CART_USER, "\u6e05\u7a7a\u8d2d\u7269\u8f66\u5f02\u5e38", (Throwable)e);
        }
        return ret;
    }
}

