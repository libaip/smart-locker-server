/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_operation_logs
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Propagation
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.OperationLogDao;
import com.jcg.company.model.Tb_operation_logs;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class OperationLogServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    public OperationLogDao operationLogDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_operation_logs operatLog = new Tb_operation_logs();
        Page page = new Page();
        if (param != null) {
            operatLog = (Tb_operation_logs)param.get("operationlogs");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.OPERA_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createOperaLog(operatLog);
            } else if (XcbConstantValue.OPERATIONLOG_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findOperationLogByParam_cpy(identifier, operatLog, page);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    @Transactional(propagation=Propagation.REQUIRES_NEW)
    public Map<String, Object> createOperaLog(Tb_operation_logs operaLog) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int sd_operation_logs_id = 0;
        try {
            sd_operation_logs_id = this.operationLogDao.createOperaLog(operaLog);
            if (sd_operation_logs_id > 0) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("operationlog.insert.success"));
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("operationlog.insert.fail"));
            }
            ret.put("sd_operation_logs_id", sd_operation_logs_id);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.OPERA_CREATE, PromptProperties.getProperty("operationlog.insert.fail"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> findOperationLogByParam_cpy(Identifier identifier, Tb_operation_logs operaLog, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_operation_logs> operaLogs = this.operationLogDao.findOperationLogByParam_cpy(operaLog, page);
            int totalCount = this.operationLogDao.findCountByParam_cpy(operaLog);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("operaLogs", operaLogs);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.OPERATIONLOG_FIND_BYPARAM_CPY, PromptProperties.getProperty("operationlog.find.error"), (Throwable)e);
        }
        return ret_method;
    }
}

