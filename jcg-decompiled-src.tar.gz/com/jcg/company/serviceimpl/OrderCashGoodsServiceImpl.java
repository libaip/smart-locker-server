/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_ordercash_goods
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.OrderCashGoodsDao;
import com.jcg.company.model.Tb_ordercash_goods;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderCashGoodsServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private OrderCashGoodsDao orderCashGoodsDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=======OrderCashGoodsServiceImpl==========");
        this.log.debug(identifier.toString());
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        Tb_ordercash_goods cash = new Tb_ordercash_goods();
        Integer sd_cash_id = null;
        Page page = new Page();
        if (param != null) {
            cash = (Tb_ordercash_goods)param.get("cash");
            page = (Page)param.get("page");
            sd_cash_id = XcbStringUtils.getObjtoint((Object)param.get("sd_cash_id"));
        }
        try {
            if (XcbConstantValue.ORDER_CASH_GOODS_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderCashGoodsById(sd_cash_id);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findOrderCashGoodsById(Integer sd_cash_id) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Tb_ordercash_goods> dataMap = new HashMap<String, Tb_ordercash_goods>();
        try {
            Tb_ordercash_goods cash = this.orderCashGoodsDao.findOrderCashGoodsById(sd_cash_id);
            if (cash != null) {
                String sr_goods_picture = cash.getSr_goods_picture();
                String[] picArr = sr_goods_picture.split(",");
                cash.setSr_picture(picArr[0]);
            }
            dataMap.put("cash", cash);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_CASH_GOODS_FIND_BYID, "\u8ba2\u5355\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }
}

