/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_order_goods
 *  com.jcg.company.model.Tb_ordercash_goods
 *  com.jcg.company.model.Tb_ordergoods_server
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.user.model.Tb_user
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.OrderCashGoodsDao;
import com.jcg.company.idao.OrderGoodsDao;
import com.jcg.company.idao.OrderGoodsServerDao;
import com.jcg.company.idao.WxPayInfoDao;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.company.model.Tb_ordercash_goods;
import com.jcg.company.model.Tb_ordergoods_server;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.idao.UserDao;
import com.jcg.user.model.Tb_user;
import com.jcg.zf.wx.WxAPIV3Common;
import com.jcg.zf.wx.WxSdjAPICommon;
import com.jcg.zf.wx.WxSpAPIV3Common;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderGoodsServerServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private OrderGoodsDao orderGoodsDao;
    @Autowired
    private OrderGoodsServerDao orderGoodsServerDao;
    @Autowired
    private OrderCashGoodsDao orderCashGoodsDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private WxPayInfoDao wxPayInfoDao;
    @Autowired
    private WxAPIV3Common wxAPIV3Common;
    @Autowired
    private WxSdjAPICommon wxSdjAPICommon;
    @Autowired
    private WxSpAPIV3Common wxSpAPIV3Common;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=======OrderGoodsServerServiceImpl==========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_ordergoods_server server = new Tb_ordergoods_server();
        Page page = new Page();
        if (param != null) {
            server = (Tb_ordergoods_server)param.get("server");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.ORDER_GOODS_SERVER_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createOrderServer(server);
            } else if (XcbConstantValue.ORDER_GOODS_SERVER_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderGoodsServerById(server);
            } else if (XcbConstantValue.ORDER_GOODS_SERVER_UPDATE.equalsIgnoreCase(functionCode)) {
                ret = this.updateOrderServer(identifier, server);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> createOrderServer(Tb_ordergoods_server server) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int reuslt = 0;
        try {
            Tb_order_goods order = this.orderGoodsDao.findOrderById(server.getSw_order_id());
            Tb_ordercash_goods cash = this.orderCashGoodsDao.findOrderCashGoodsById(server.getSw_cash_id());
            if (XcbConstantValue.ORDER_GOODS_STS_BFTK.equals(order.getSr_status()) || XcbConstantValue.ORDER_GOODS_STS_DCL.equals(order.getSr_status()) || XcbConstantValue.ORDER_GOODS_STS_YWC.equals(order.getSr_status())) {
                if (XcbConstantValue.ORDER_GOODS_CASH_STS_ZFCG.equals(cash.getSr_status())) {
                    server.setSd_id(CommonFunction.getVoucherNum((String)CommonFunction.jy_id));
                    server.setSr_status(XcbConstantValue.ORDER_GOODS_SERVER_STS_DCL);
                    server.setTm_create_time(new Date());
                    server.setSr_create_person(XcbStringUtils.getObjtoString((Object)server.getSw_user_id()));
                    reuslt = this.orderGoodsServerDao.createOrderServer(server);
                    if (reuslt > XcbConstantValue.OPERA_INT_ZERO) {
                        order.setSr_status(XcbConstantValue.ORDER_GOODS_STS_DCL);
                        order.setTm_modify_time(new Date());
                        this.orderGoodsDao.updateOrderById(order);
                        cash.setSr_status(XcbConstantValue.ORDER_GOODS_CASH_STS_DCL);
                        cash.setTm_modify_time(new Date());
                        this.orderCashGoodsDao.updateOrderCashById(cash);
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret.put(XcbConstantValue.MSG, "\u63d0\u4ea4\u6210\u529f");
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret.put(XcbConstantValue.MSG, "\u63d0\u4ea4\u5931\u8d25");
                    }
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, "\u5f53\u524d\u72b6\u6001\uff0c\u4e0d\u53ef\u64cd\u4f5c");
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u5df2\u63d0\u4ea4\u552e\u540e\u7533\u8bf7\uff0c\u8bf7\u52ff\u91cd\u590d\u64cd\u4f5c");
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_SERVER_CREATE, "\u552e\u540e\u8ba2\u5355\u521b\u5efa\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> updateOrderServer(Identifier identifier, Tb_ordergoods_server server) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        try {
            Tb_ordergoods_server og = this.orderGoodsServerDao.findServerById(server.getSd_id());
            if ("1".equals(server.getSr_type())) {
                og.setTm_appl_time(new Date());
                og.setSr_appl_person(identifier.getUserName());
                og.setSr_appl_remark(server.getSr_appl_remark());
                og.setSr_status(XcbConstantValue.ORDER_GOODS_SERVER_STS_CLZ);
            } else if ("2".equals(server.getSr_type())) {
                BigDecimal dc_refund_money = XcbStringUtils.getObjToBigDecimal((Object)server.getDc_refund_money());
                if (!BigDecimalUtil.compareToZero((BigDecimal)dc_refund_money)) {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, "\u9000\u6b3e\u91d1\u989d\u5fc5\u987b\u5927\u4e8e0\u5143");
                    return ret;
                }
                og.setTm_appl_time(new Date());
                og.setSr_appl_person(identifier.getUserName());
                og.setSr_appl_remark(server.getSr_appl_remark());
                og.setSr_status(XcbConstantValue.ORDER_GOODS_SERVER_STS_YWC);
            } else if ("3".equals(server.getSr_type())) {
                og.setTm_appl_time(new Date());
                og.setSr_appl_person(identifier.getUserName());
                og.setSr_appl_remark(server.getSr_appl_remark());
                og.setSr_status(XcbConstantValue.ORDER_GOODS_SERVER_STS_YWC);
            }
            result = this.orderGoodsServerDao.updateOrderServer(og);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                if ("1".equals(server.getSr_type())) {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.MSG, "\u5904\u7406\u6210\u529f");
                } else if ("2".equals(server.getSr_type())) {
                    BigDecimal refund_money = XcbStringUtils.getObjToBigDecimal((Object)server.getDc_refund_money());
                    Tb_order_goods order = this.orderGoodsDao.findOrderById(og.getSw_order_id());
                    Tb_user user = this.userDao.findUserById(og.getSw_user_id());
                    int si_refund_cnt = XcbStringUtils.getObjtoint((Object)order.getSi_refund_cnt()) + XcbStringUtils.getObjtoint((Object)server.getSi_refund());
                    BigDecimal dc_refund_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_refund_money());
                    BigDecimal temp_money = BigDecimalUtil.add((BigDecimal)dc_refund_money, (BigDecimal)refund_money);
                    order.setSi_refund_cnt(Integer.valueOf(si_refund_cnt));
                    order.setDc_refund_money(temp_money);
                    if (temp_money.compareTo(order.getDc_order_money()) == 0) {
                        order.setSr_status(XcbConstantValue.ORDER_GOODS_STS_YTK);
                    } else {
                        order.setSr_status(XcbConstantValue.ORDER_GOODS_STS_YWC);
                    }
                    result = this.orderGoodsDao.updateOrderById(order);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        Tb_ordercash_goods cash = this.orderCashGoodsDao.findOrderCashGoodsById(og.getSw_cash_id());
                        int si_refund = XcbStringUtils.getObjtoint((Object)cash.getSi_refund()) + XcbStringUtils.getObjtoint((Object)server.getSi_refund());
                        BigDecimal dc_refund_money2 = XcbStringUtils.getObjToBigDecimal((Object)cash.getDc_refund_money());
                        BigDecimal temp_money2 = BigDecimalUtil.add((BigDecimal)dc_refund_money2, (BigDecimal)refund_money);
                        cash.setSi_refund(Integer.valueOf(si_refund));
                        cash.setDc_refund_money(temp_money2);
                        if (temp_money2.compareTo(cash.getDc_order_money()) == 0) {
                            cash.setSr_status(XcbConstantValue.ORDER_GOODS_CASH_STS_YTK);
                        } else {
                            cash.setSr_status(XcbConstantValue.ORDER_GOODS_CASH_STS_BFTK);
                        }
                        result = this.orderCashGoodsDao.updateOrderCashById(cash);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                            String msg = "";
                            Tb_wx_pay_info pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
                            Map<Object, Object> rtnMap = new HashMap();
                            if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                                int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)refund_money)));
                                int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)order.getDc_order_money())));
                                pay_info.setSr_refund_desc("\u7528\u6237\u5546\u54c1\u9000\u6b3e");
                                rtnMap = this.wxAPIV3Common.xcrefund(identifier, order.getSd_order_id(), order.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                            } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                                String refund_fee = XcbStringUtils.getObjtoString((Object)refund_money);
                                String total_fee = XcbStringUtils.getObjtoString((Object)order.getDc_order_money());
                                pay_info.setSr_refund_desc("\u7528\u6237\u5546\u54c1\u9000\u6b3e");
                                rtnMap = this.wxSdjAPICommon.xcrefund(order.getSd_order_id(), order.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                            } else {
                                int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)refund_money)));
                                int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)order.getDc_order_money())));
                                pay_info.setSr_refund_desc("\u7528\u6237\u5546\u54c1\u9000\u6b3e");
                                rtnMap = this.wxSpAPIV3Common.xcrefund(identifier, order.getSd_order_id(), order.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                            }
                            result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                            msg = result > XcbConstantValue.OPERA_INT_ZERO ? "\u9000\u6b3e\u6210\u529f" : XcbStringUtils.getObjtoString((Object)rtnMap.get(XcbConstantValue.MSG));
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            ret.put(XcbConstantValue.MSG, msg);
                        } else {
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            ret.put(XcbConstantValue.MSG, "\u9000\u6b3e\u5931\u8d25,\u66f4\u65b0\u8ba2\u5355\u6d41\u6c34\u4fe1\u606f\u5f02\u5e38");
                        }
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, "\u9000\u6b3e\u5931\u8d25,\u66f4\u65b0\u8ba2\u5355\u4fe1\u606f\u5f02\u5e38");
                    }
                } else if ("3".equals(server.getSr_type())) {
                    Tb_order_goods order = this.orderGoodsDao.findOrderById(og.getSw_order_id());
                    order.setSr_status(XcbConstantValue.ORDER_GOODS_STS_YWC);
                    result = this.orderGoodsDao.updateOrderById(order);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret.put(XcbConstantValue.MSG, "\u5904\u7406\u6210\u529f");
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, "\u5904\u7406\u5931\u8d25,\u66f4\u65b0\u8ba2\u5355\u4fe1\u606f\u5f02\u5e38");
                    }
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u5904\u7406\u5931\u8d25");
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_SERVER_UPDATE, "\u552e\u540e\u8ba2\u5355\u66f4\u65b0\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> findOrderGoodsServerById(Tb_ordergoods_server os) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, List<Tb_ordergoods_server>> dataMap = new HashMap<String, List<Tb_ordergoods_server>>();
        try {
            List<Tb_ordergoods_server> list = this.orderGoodsServerDao.findOrderGoodsServerById(os);
            for (Tb_ordergoods_server order : list) {
                String sr_goods_picture = order.getSr_goods_picture();
                String[] picArr = sr_goods_picture.split(",");
                order.setSr_picture(picArr[0]);
            }
            dataMap.put("list", list);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_SERVER_FIND_BYID, "\u552e\u540e\u8ba2\u5355\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }
}

