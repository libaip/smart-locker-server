/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_goods
 *  com.jcg.company.model.Tb_order_goods
 *  com.jcg.company.model.Tb_ordercash_goods
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.user.model.Tb_user
 *  com.jcg.user.model.Tb_user_account
 *  com.jcg.user.model.Tb_user_address
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.company.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.GoodsDao;
import com.jcg.company.idao.OrderCashGoodsDao;
import com.jcg.company.idao.OrderGoodsDao;
import com.jcg.company.idao.WxPayInfoDao;
import com.jcg.company.model.Tb_goods;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.company.model.Tb_ordercash_goods;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.company.serviceimpl.SysParamServiceImpl;
import com.jcg.user.idao.UserAccountDao;
import com.jcg.user.idao.UserAddressDao;
import com.jcg.user.idao.UserDao;
import com.jcg.user.model.Tb_user;
import com.jcg.user.model.Tb_user_account;
import com.jcg.user.model.Tb_user_address;
import com.jcg.zf.wx.WxAPIV3Common;
import com.jcg.zf.wx.WxSdjAPICommon;
import com.jcg.zf.wx.WxSpAPIV3Common;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class OrderGoodsServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private UserAddressDao userAddressDao;
    @Autowired
    private UserAccountDao userAccountDao;
    @Autowired
    private GoodsDao goodsDao;
    @Autowired
    private OrderGoodsDao orderGoodsDao;
    @Autowired
    private OrderCashGoodsDao orderCashGoodsDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private SysParamServiceImpl sysParamService;
    @Autowired
    private RedisUtil redis;
    @Autowired
    private WxAPIV3Common wxAPIV3Common;
    @Autowired
    private WxSdjAPICommon wxSdjAPICommon;
    @Autowired
    private WxSpAPIV3Common wxSpAPIV3Common;
    @Autowired
    private WxPayInfoDao wxPayInfoDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=======OrderGoodsServiceImpl==========");
        this.log.debug(identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_order_goods order = new Tb_order_goods();
        String sd_order_id = "";
        Page page = new Page();
        if (param != null) {
            order = (Tb_order_goods)param.get("order");
            page = (Page)param.get("page");
            sd_order_id = XcbStringUtils.getObjtoString((Object)param.get("sd_order_id"));
        }
        try {
            if (XcbConstantValue.ORDER_GOODS_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createOrderGoods(order);
            } else if (XcbConstantValue.ORDER_GOODS_CHECK_PAYNOTIFY.equalsIgnoreCase(functionCode)) {
                String sw_bus_order_id = XcbStringUtils.getObjtoString((Object)param.get("sw_bus_order_id"));
                ret = this.orderPayNotify(identifier, sd_order_id, sw_bus_order_id);
            } else if (XcbConstantValue.ORDER_GOODS_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderGoodsById(sd_order_id);
            } else if (XcbConstantValue.ORDER_GOODS_FIND_BYPARAM_USER.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderGoodsByParam(order, page);
            } else if (XcbConstantValue.ORDER_GOODS_CLOSE.equalsIgnoreCase(functionCode)) {
                ret = this.closeOrder(order);
            } else if (XcbConstantValue.ORDER_GOODS_UPDATE.equalsIgnoreCase(functionCode)) {
                ret = this.updateOrderGoods(order);
            } else if (XcbConstantValue.ORDER_GOODS_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findOrderGoodsByParam_cpy(order, page);
            } else if (XcbConstantValue.ORDER_GOODS_UPDATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateOrderGoods_cpy(order);
            } else if (XcbConstantValue.ORDER_GOODS_REFUND_CPY.equalsIgnoreCase(functionCode)) {
                Tb_ordercash_goods cash = (Tb_ordercash_goods)param.get("cash");
                ret = this.refund_cpy(identifier, cash);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> refund_cpy(Identifier identifier, Tb_ordercash_goods cash) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        String msg = "";
        String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
        try {
            Tb_ordercash_goods cashGoods = this.orderCashGoodsDao.findOrderCashGoodsById(cash.getSd_cash_id());
            if (cashGoods != null) {
                Tb_order_goods order = this.orderGoodsDao.findOrderById(cashGoods.getSw_order_id());
                Tb_user user = this.userDao.findUserById(order.getSw_user_id());
                Tb_wx_pay_info pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
                if (XcbConstantValue.ORDER_GOODS_CASH_STS_ZFCG.equals(cashGoods.getSr_status()) || XcbConstantValue.ORDER_GOODS_CASH_STS_BFTK.equals(cashGoods.getSr_status())) {
                    Integer si_refund = XcbStringUtils.getObjtoint((Object)cash.getSi_refund());
                    BigDecimal dc_refund = XcbStringUtils.getObjToBigDecimal((Object)cash.getDc_refund_money());
                    int si_refund_cnt = XcbStringUtils.getObjtoint((Object)order.getSi_refund_cnt()) + si_refund;
                    BigDecimal dc_refund_money = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_refund_money());
                    BigDecimal temp_money = BigDecimalUtil.add((BigDecimal)dc_refund_money, (BigDecimal)dc_refund);
                    order.setSi_refund_cnt(Integer.valueOf(si_refund_cnt));
                    order.setDc_refund_money(temp_money);
                    if (temp_money.compareTo(order.getDc_order_money()) == 0) {
                        order.setSr_status(XcbConstantValue.ORDER_GOODS_STS_YTK);
                    } else {
                        order.setSr_status(XcbConstantValue.ORDER_GOODS_STS_YWC);
                    }
                    result = this.orderGoodsDao.updateOrderById(order);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        int si_refund_new = XcbStringUtils.getObjtoint((Object)cashGoods.getSi_refund()) + si_refund;
                        BigDecimal dc_refund_money2 = XcbStringUtils.getObjToBigDecimal((Object)cashGoods.getDc_refund_money());
                        BigDecimal temp_money2 = BigDecimalUtil.add((BigDecimal)dc_refund_money2, (BigDecimal)dc_refund);
                        cashGoods.setSi_refund(Integer.valueOf(si_refund_new));
                        cashGoods.setDc_refund_money(temp_money2);
                        if (temp_money2.compareTo(cashGoods.getDc_order_money()) == 0) {
                            cashGoods.setSr_status(XcbConstantValue.ORDER_GOODS_CASH_STS_YTK);
                        } else {
                            cashGoods.setSr_status(XcbConstantValue.ORDER_GOODS_CASH_STS_BFTK);
                        }
                        result = this.orderCashGoodsDao.updateOrderCashById(cashGoods);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            Map<Object, Object> rtnMap = new HashMap();
                            if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                                int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund)));
                                int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)order.getDc_order_money())));
                                pay_info.setSr_refund_desc("\u7528\u6237\u5546\u54c1\u9000\u6b3e");
                                rtnMap = this.wxAPIV3Common.xcrefund(identifier, order.getSd_order_id(), order.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                            } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                                String refund_fee = XcbStringUtils.getObjtoString((Object)dc_refund);
                                String total_fee = XcbStringUtils.getObjtoString((Object)order.getDc_order_money());
                                pay_info.setSr_refund_desc("\u7528\u6237\u5546\u54c1\u9000\u6b3e");
                                rtnMap = this.wxSdjAPICommon.xcrefund(order.getSd_order_id(), order.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                            } else {
                                int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_refund)));
                                int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)order.getDc_order_money())));
                                pay_info.setSr_refund_desc("\u7528\u6237\u5546\u54c1\u9000\u6b3e");
                                rtnMap = this.wxSpAPIV3Common.xcrefund(identifier, order.getSd_order_id(), order.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                            }
                            result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                            msg = result > XcbConstantValue.OPERA_INT_ZERO ? "\u9000\u6b3e\u6210\u529f" : XcbStringUtils.getObjtoString((Object)rtnMap.get(XcbConstantValue.MSG));
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            ret.put(XcbConstantValue.MSG, msg);
                        } else {
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            ret.put(XcbConstantValue.MSG, "\u9000\u6b3e\u5931\u8d25,\u66f4\u65b0\u8ba2\u5355\u6d41\u6c34\u4fe1\u606f\u5f02\u5e38");
                        }
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, "\u9000\u6b3e\u5931\u8d25,\u66f4\u65b0\u8ba2\u5355\u4fe1\u606f\u5f02\u5e38");
                    }
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, "\u9000\u6b3e\u5931\u8d25\uff0c\u5f53\u524d\u72b6\u6001\u4e0d\u53ef\u64cd\u4f5c");
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u9000\u6b3e\u5931\u8d25\uff0c\u6ca1\u6709\u627e\u5230\u8ba2\u5355");
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_REFUND_CPY, "\u9000\u6b3e\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> findOrderGoodsByParam(Tb_order_goods order, Page page) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            order.setSr_create_time_start(XcbDateUtil.getStartDay((String)XcbDateUtil.getBeforeDay((Date)new Date(), (int)90, (String)"yyyy-MM-dd")));
            order.setSr_create_time_end(XcbDateUtil.getTodayEnd((Date)new Date()));
            List<Tb_order_goods> orderList = this.orderGoodsDao.findOrderGoodsByParam(order, page);
            for (Tb_order_goods o : orderList) {
                List<Tb_ordercash_goods> orderCashGoodsList = this.orderCashGoodsDao.findOrderCashByOrderId(o.getSd_order_id());
                for (Tb_ordercash_goods og : orderCashGoodsList) {
                    String sr_goods_picture = og.getSr_goods_picture();
                    String[] picArr = sr_goods_picture.split(",");
                    og.setSr_picture(picArr[0]);
                }
                o.setOrderCashGoodsList(orderCashGoodsList);
            }
            int totalCount = this.orderGoodsDao.findCountByParam(order);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("orders", orderList);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_FIND_BYPARAM_USER, "\u8ba2\u5355\u5217\u8868\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> createOrderGoods(Tb_order_goods order) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = 0;
            Integer sw_address_id = XcbStringUtils.getObjtoint((Object)order.getSw_address_id());
            String[] idArr = order.getIdArr();
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(order.getSw_user_id());
            Tb_user_address address = this.userAddressDao.findAddressById(sw_address_id);
            if (address != null) {
                if (idArr.length > 0) {
                    ArrayList<Tb_ordercash_goods> cashGoodsList = new ArrayList<Tb_ordercash_goods>();
                    BigDecimal dc_order_money = BigDecimal.ZERO;
                    BigDecimal dc_integral_sum = BigDecimal.ZERO;
                    for (int i = 0; i < idArr.length; ++i) {
                        Integer si_shopping_cart;
                        String sd_id = idArr[i];
                        Tb_goods goods = this.goodsDao.findGoodsById(XcbStringUtils.getObjtoint((Object)sd_id));
                        if (goods != null) {
                            si_shopping_cart = XcbStringUtils.getObjtoint((Object)this.redis.get("Cart_" + order.getSw_user_id() + "_id_" + sd_id));
                            if (si_shopping_cart == 0) {
                                si_shopping_cart = 1;
                            }
                        } else {
                            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            ret_method.put(XcbConstantValue.MSG, "\u5546\u54c1\u5df2\u4e0b\u67b6\uff0c\u6682\u65e0\u6cd5\u8d2d\u4e70");
                            break;
                        }
                        BigDecimal dc_price = BigDecimalUtil.mul((BigDecimal)goods.getDc_price(), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)si_shopping_cart));
                        BigDecimal dc_integral = BigDecimalUtil.mul((BigDecimal)goods.getDc_integral(), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)si_shopping_cart));
                        dc_order_money = BigDecimalUtil.add((BigDecimal)dc_price, (BigDecimal)dc_order_money);
                        dc_integral_sum = BigDecimalUtil.add((BigDecimal)dc_integral, (BigDecimal)dc_integral_sum);
                        Tb_ordercash_goods cashGoods = new Tb_ordercash_goods();
                        cashGoods.setSw_order_id(order.getSd_order_id());
                        cashGoods.setSw_goods_id(Integer.valueOf(XcbStringUtils.getObjtoint((Object)sd_id)));
                        cashGoods.setSr_goods_name(goods.getSr_goods_name());
                        cashGoods.setSr_brand(goods.getSr_brand());
                        cashGoods.setDc_org_price(goods.getDc_org_price());
                        cashGoods.setDc_price(goods.getDc_price());
                        cashGoods.setDc_integral(goods.getDc_integral());
                        cashGoods.setSr_goods_desc(goods.getSr_goods_desc());
                        cashGoods.setSr_goods_picture(goods.getSr_goods_picture());
                        cashGoods.setSr_goods_content(goods.getSr_goods_content());
                        cashGoods.setDc_order_integral(dc_integral);
                        cashGoods.setDc_order_money(dc_price);
                        cashGoods.setSi_refund(Integer.valueOf(0));
                        cashGoods.setDc_refund_money(BigDecimal.ZERO);
                        cashGoods.setSi_shopping_cart(si_shopping_cart);
                        cashGoods.setSr_status(XcbConstantValue.ORDER_GOODS_CASH_STS_DZF);
                        cashGoods.setSr_create_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                        cashGoods.setTm_create_time(new Date());
                        cashGoods.setSr_modify_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                        cashGoods.setTm_modify_time(new Date());
                        cashGoodsList.add(cashGoods);
                    }
                    if (dc_integral_sum.compareTo(userAccount.getDc_integral()) == 1) {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u79ef\u5206\u4e0d\u8db3");
                        return ret_method;
                    }
                    order.setSi_sex(address.getSi_sex());
                    order.setSr_phone(address.getSr_mobile());
                    order.setSr_name(address.getSr_name());
                    order.setSr_abbreviation(address.getSr_abbreviation());
                    order.setSr_address(address.getSr_address());
                    order.setSr_house_number(address.getSr_house_number());
                    order.setSi_shopping_cart(Integer.valueOf(idArr.length));
                    order.setDc_order_money(dc_order_money);
                    order.setDc_integral_sum(dc_integral_sum);
                    order.setSi_refund_cnt(Integer.valueOf(0));
                    order.setDc_refund_money(BigDecimal.ZERO);
                    order.setSr_status(XcbConstantValue.ORDER_GOODS_STS_DZF);
                    order.setSr_create_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                    order.setTm_create_time(new Date());
                    order.setSr_modify_person(XcbStringUtils.getObjtoString((Object)order.getSw_user_id()));
                    order.setTm_modify_time(new Date());
                    result = this.orderGoodsDao.createOrderGoods(order);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        result = this.orderCashGoodsDao.batchCreateOrderCashGoods(cashGoodsList);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            BigDecimal dc_integral = BigDecimalUtil.sub((BigDecimal)userAccount.getDc_integral(), (BigDecimal)dc_integral_sum);
                            userAccount.setDc_old_integral(userAccount.getDc_integral());
                            userAccount.setDc_integral(dc_integral);
                            result = this.userAccountDao.updateIntegralUserAccountById_user(userAccount);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                for (int i = 0; i < idArr.length; ++i) {
                                    String sd_id = idArr[i];
                                    this.redis.delete("Cart_" + order.getSw_user_id() + "_id_" + sd_id);
                                }
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                                ret_method.put(XcbConstantValue.MSG, "\u521b\u5efa\u8ba2\u5355\u6210\u529f");
                                ret_method.put(XcbConstantValue.DATA, order);
                            } else {
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                ret_method.put(XcbConstantValue.MSG, "\u652f\u4ed8\u5931\u8d25\uff0c\u6263\u9664\u79ef\u5206\u5f02\u5e38");
                            }
                        } else {
                            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            ret_method.put(XcbConstantValue.MSG, "\u652f\u4ed8\u5931\u8d25\uff0c\u521b\u5efa\u8ba2\u5355\u5f02\u5e38");
                        }
                    } else {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u652f\u4ed8\u5931\u8d25\uff0c\u521b\u5efa\u8ba2\u5355\u5f02\u5e38");
                    }
                } else {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u8bf7\u9009\u62e9\u9700\u8981\u652f\u4ed8\u7684\u5546\u54c1");
                }
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u8bf7\u586b\u5199\u6536\u8d27\u5730\u5740");
            }
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_CREATE, "\u521b\u5efa\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    Map<String, Object> orderPayNotify(Identifier identifier, String sd_order_id, String sw_bus_order_id) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_order_goods order = this.orderGoodsDao.findOrderById(sd_order_id);
            if (order != null) {
                if (XcbConstantValue.ORDER_GOODS_STS_DZF.equals(order.getSr_status())) {
                    order.setSr_status(XcbConstantValue.ORDER_GOODS_STS_DFH);
                    order.setTm_modify_time(new Date());
                    order.setSw_bus_order_id(sw_bus_order_id);
                    order.setTm_pay_time(new Date());
                    int result = this.orderGoodsDao.updateOrderById(order);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        List<Tb_ordercash_goods> cashGoodsList = this.orderCashGoodsDao.findOrderCashByOrderId(sd_order_id);
                        for (Tb_ordercash_goods cash : cashGoodsList) {
                            cash.setSr_status(XcbConstantValue.ORDER_GOODS_CASH_STS_ZFCG);
                            cash.setTm_modify_time(new Date());
                            this.orderCashGoodsDao.updateOrderCashById(cash);
                        }
                    }
                } else {
                    ret.put(XcbConstantValue.MSG, "\u8ba2\u5355\u5df2\u66f4\u65b0\u72b6\u6001");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, "\u67e5\u65e0\u8ba2\u5355");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_CHECK_PAYNOTIFY, "\u56de\u8c03\u66f4\u65b0\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> findOrderGoodsById(String sd_order_id) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Tb_order_goods> dataMap = new HashMap<String, Tb_order_goods>();
        try {
            Tb_order_goods orderGoods = this.orderGoodsDao.findOrderById(sd_order_id);
            List<Tb_ordercash_goods> orderCashGoodsList = this.orderCashGoodsDao.findOrderCashByOrderId(orderGoods.getSd_order_id());
            for (Tb_ordercash_goods og : orderCashGoodsList) {
                String sr_goods_picture = og.getSr_goods_picture();
                String[] picArr = sr_goods_picture.split(",");
                og.setSr_picture(picArr[0]);
            }
            orderGoods.setOrderCashGoodsList(orderCashGoodsList);
            dataMap.put("order", orderGoods);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_FIND_BYID, "\u8ba2\u5355\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> closeOrder(Tb_order_goods order) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_order_goods o_order = this.orderGoodsDao.findOrderById(order.getSd_order_id());
            if (o_order != null) {
                if (!XcbConstantValue.ORDER_GOODS_STS_QX.equals(o_order.getSr_status())) {
                    o_order.setSr_status(XcbConstantValue.ORDER_GOODS_STS_QX);
                    o_order.setTm_dead_time(new Date());
                    o_order.setTm_modify_time(new Date());
                    int result = this.orderGoodsDao.updateOrderById(o_order);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        List<Tb_ordercash_goods> orderCashList = this.orderCashGoodsDao.findOrderCashByOrderId(o_order.getSd_order_id());
                        for (Tb_ordercash_goods oc : orderCashList) {
                            oc.setSr_status(XcbConstantValue.ORDER_GOODS_CASH_STS_QX);
                            oc.setTm_modify_time(new Date());
                            this.orderCashGoodsDao.updateOrderCashById(oc);
                        }
                        Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(o_order.getSw_user_id());
                        BigDecimal dc_integral = BigDecimalUtil.add((BigDecimal)o_order.getDc_integral_sum(), (BigDecimal)userAccount.getDc_integral());
                        userAccount.setDc_old_integral(userAccount.getDc_integral());
                        userAccount.setDc_integral(dc_integral);
                        result = this.userAccountDao.updateIntegralUserAccountById_user(userAccount);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                            ret.put(XcbConstantValue.MSG, "\u53d6\u6d88\u8ba2\u5355\u6210\u529f");
                        } else {
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            ret.put(XcbConstantValue.MSG, "\u53d6\u6d88\u8ba2\u5355\u5931\u8d25");
                        }
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, "\u53d6\u6d88\u8ba2\u5355\u5931\u8d25");
                    }
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, "\u8ba2\u5355\u5df2\u53d6\u6d88");
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u8ba2\u5355\u5df2\u5220\u9664");
            }
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_CLOSE, "\u53d6\u6d88\u8ba2\u5355\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> updateOrderGoods(Tb_order_goods order) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String msg = "\u66f4\u65b0\u6210\u529f";
        try {
            if (XcbConstantValue.ORDER_GOODS_STS_YWC.equals(order.getSr_status())) {
                msg = "\u7b7e\u6536\u6210\u529f";
                order.setTm_dead_time(new Date());
            }
            order.setTm_modify_time(new Date());
            int result = this.orderGoodsDao.updateOrderById(order);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, msg);
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u66f4\u65b0\u5931\u8d25");
            }
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_UPDATE, "\u8ba2\u5355\u66f4\u65b0\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> findOrderGoodsByParam_cpy(Tb_order_goods order, Page page) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_order_goods> orderList = this.orderGoodsDao.findOrderGoodsByParam_cpy(order, page);
            for (Tb_order_goods o : orderList) {
                List<Tb_ordercash_goods> orderCashGoodsList = this.orderCashGoodsDao.findOrderCashByOrderId(o.getSd_order_id());
                for (Tb_ordercash_goods og : orderCashGoodsList) {
                    String sr_goods_picture = og.getSr_goods_picture();
                    String[] picArr = sr_goods_picture.split(",");
                    og.setSr_picture(picArr[0]);
                }
                o.setOrderCashGoodsList(orderCashGoodsList);
            }
            int totalCount = this.orderGoodsDao.findCountByParam_cpy(order);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("orders", orderList);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_FIND_BYPARAM_CPY, "\u8ba2\u5355\u5217\u8868\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> updateOrderGoods_cpy(Tb_order_goods order) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String msg = "\u66f4\u65b0\u6210\u529f";
        try {
            if (XcbConstantValue.ORDER_GOODS_STS_DSH.equals(order.getSr_status())) {
                msg = "\u53d1\u8d27\u6210\u529f";
            } else if (XcbConstantValue.ORDER_GOODS_STS_YWC.equals(order.getSr_status())) {
                msg = "\u7b7e\u6536\u6210\u529f";
                order.setTm_dead_time(new Date());
            }
            order.setTm_modify_time(new Date());
            int result = this.orderGoodsDao.updateOrderById(order);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, msg);
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u66f4\u65b0\u5931\u8d25");
            }
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
            throw new BusinessException(XcbConstantValue.ORDER_GOODS_UPDATE_CPY, "\u8ba2\u5355\u66f4\u65b0\u5f02\u5e38", (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }
}

