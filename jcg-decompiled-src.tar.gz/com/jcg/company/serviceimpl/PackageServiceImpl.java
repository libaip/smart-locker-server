/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_package
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.PackageDao;
import com.jcg.company.model.Tb_package;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PackageServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    PackageDao packageDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========PackageServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        Tb_package msgPackage = new Tb_package();
        if (param != null) {
            msgPackage = (Tb_package)param.get("msgPackage");
        }
        try {
            if (XcbConstantValue.PACKAGE_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findPackageParam(msgPackage);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findPackageParam(Tb_package msgPackage) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, List<Tb_package>> dataMap = new HashMap<String, List<Tb_package>>();
        try {
            List<Tb_package> packages = this.packageDao.findPackageParam(msgPackage);
            dataMap.put("packages", packages);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.PACKAGE_FIND_BYPARAM, "\u5957\u9910\u5217\u8868\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }
}

