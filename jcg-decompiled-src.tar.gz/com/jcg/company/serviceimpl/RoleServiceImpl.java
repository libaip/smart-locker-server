/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  cn.hutool.core.util.ObjectUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company_authorities
 *  com.jcg.company.model.Tb_company_roles
 *  com.jcg.company.model.Tb_company_roles_auth
 *  com.jcg.company.model.Tb_company_roles_rel
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.company.serviceimpl;

import cn.hutool.core.util.ObjectUtil;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.CompanyAuthoritiesDao;
import com.jcg.company.idao.CompanyRolesAuthDao;
import com.jcg.company.idao.CompanyRolesDao;
import com.jcg.company.idao.CompanyRolesRelDao;
import com.jcg.company.idao.SysParamDao;
import com.jcg.company.model.Tb_company_authorities;
import com.jcg.company.model.Tb_company_roles;
import com.jcg.company.model.Tb_company_roles_auth;
import com.jcg.company.model.Tb_company_roles_rel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class RoleServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private CompanyRolesDao roleDao;
    @Autowired
    private CompanyRolesRelDao roleRelDao;
    @Autowired
    private CompanyRolesAuthDao rolesAuthoritiesDao;
    @Autowired
    private CompanyAuthoritiesDao authDao;
    @Autowired
    private SysParamDao sysParamDao;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=================start " + identifier.toString());
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Integer sd_roles_id = null;
        Integer sd_authority_id = null;
        Tb_company_roles role = new Tb_company_roles();
        Tb_company_authorities auth = new Tb_company_authorities();
        Page page = new Page();
        String[] authArr = null;
        if (param != null) {
            sd_roles_id = XcbStringUtils.getObjtoint((Object)param.get("sd_roles_id"));
            sd_authority_id = XcbStringUtils.getObjtoint((Object)param.get("sd_authority_id"));
            role = (Tb_company_roles)param.get("role");
            auth = (Tb_company_authorities)param.get("auth");
            page = (Page)param.get("page");
            authArr = (String[])param.get("authArr");
        }
        try {
            if (XcbConstantValue.ROLE_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createRole(identifier, role);
            } else if (XcbConstantValue.ROLE_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findRoleById(identifier, sd_roles_id);
            } else if (XcbConstantValue.ROLE_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findRoleByParam(identifier, role, page);
            } else if (XcbConstantValue.ROLE_UPDATE_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.updateRoleById(identifier, role);
            } else if (XcbConstantValue.ROLE_DELETE_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.delRoleById(identifier, sd_roles_id);
            } else if (XcbConstantValue.ROLE_AUTH_FIND_BYID.equalsIgnoreCase(functionCode)) {
                ret = this.findRoleAuthById(identifier, sd_roles_id);
            } else if (XcbConstantValue.ROLE_AUTH_UPDATE_BYROLEID.equalsIgnoreCase(functionCode)) {
                ret = this.updateRoleAuthByRoleId(identifier, sd_roles_id, authArr);
            } else if (XcbConstantValue.AUTH_CREATE.equalsIgnoreCase(functionCode)) {
                ret = this.createAuth(identifier, auth);
            } else if (XcbConstantValue.AUTH_UPDATE.equalsIgnoreCase(functionCode)) {
                ret = this.updateAuthById(identifier, auth);
            } else if (XcbConstantValue.AUTH_DELETE.equalsIgnoreCase(functionCode)) {
                ret = this.delAuthById(identifier, sd_authority_id);
            } else if (XcbConstantValue.AUTH_BATCH_DELETE.equalsIgnoreCase(functionCode)) {
                ret = this.batchDeleteById(identifier, authArr);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    @Transactional
    private Map<String, Object> createRole(Identifier identifier, Tb_company_roles role) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            role.setSi_createuser(identifier.getUserId());
            role.setTm_createdate(new Date());
            int count = this.roleDao.createCompanyRoles(role);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, "\u89d2\u8272\u521b\u5efa\u6210\u529f");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u89d2\u8272\u521b\u5efa\u5931\u8d25");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_UPDATE_BYID, "\u89d2\u8272\u521b\u5efa\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findRoleById(Identifier identifier, Integer sd_roles_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_company_roles cuser = this.roleDao.findById(sd_roles_id);
            ret_method.put(XcbConstantValue.DATA, cuser);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_FIND_BYID, "\u901a\u8fc7Id \u67e5\u627e\u89d2\u8272\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findRoleByParam(Identifier identifier, Tb_company_roles role, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            String findAll;
            List<Tb_company_roles> roles = null;
            int totalCount = 0;
            String string = findAll = XcbStringUtils.isNullOrBlank((Object)role.getFindAll()) ? "" : role.getFindAll();
            if (findAll.equalsIgnoreCase(XcbConstantValue.Y_STRING)) {
                roles = this.roleDao.findAll(role.getSw_company_id());
            } else {
                roles = this.roleDao.findByParam(role, page);
                totalCount = this.roleDao.findCntByParam(role);
                for (Tb_company_roles _role : roles) {
                    List<Tb_company_roles_auth> roleRels = this.rolesAuthoritiesDao.findByRoleId(_role.getSd_roles_id());
                    ArrayList<Integer> authList = new ArrayList<Integer>();
                    for (Tb_company_roles_auth roleRelObj : roleRels) {
                        authList.add(roleRelObj.getSw_authority_id());
                    }
                    _role.setMenu_list(authList);
                }
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("roles", roles);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.ROLE_FIND_BYPARAM, "\u901a\u8fc7\u6761\u4ef6\u67e5\u627e\u89d2\u8272\u4fe1\u606f\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    private Map<String, Object> updateRoleById(Identifier identifier, Tb_company_roles role) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int count = this.roleDao.updateById(role);
            ret_method.put(XcbConstantValue.STATUS, count);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, "\u89d2\u8272\u4fee\u6539\u6210\u529f");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u89d2\u8272\u4fee\u6539\u5931\u8d25");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_UPDATE_BYID, "\u89d2\u8272\u4fee\u6539\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    public Map<String, Object> delRoleById(Identifier identifier, Integer sd_roles_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Tb_company_roles_rel> roleRels = this.roleRelDao.findByRoleId(sd_roles_id);
            if (roleRels.size() > 0) {
                ret_method.put(XcbConstantValue.MSG, "\u89d2\u8272\u5df2\u6388\u4e88\u7528\u6237,\u5220\u9664\u5931\u8d25");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                return ret_method;
            }
            this.rolesAuthoritiesDao.deleteRoleAuthsByRoleId(sd_roles_id);
            int count = this.roleDao.deleteById(sd_roles_id);
            ret_method.put(XcbConstantValue.STATUS, count);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, "\u89d2\u8272\u5220\u9664\u6210\u529f");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u89d2\u8272\u5220\u9664\u5931\u8d25");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_UPDATE_BYID, "\u89d2\u8272\u5220\u9664\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findRoleAuthById(Identifier identifier, Integer sd_roles_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Tb_company_roles_auth> roleRels = this.rolesAuthoritiesDao.findByRoleId(sd_roles_id);
            ArrayList<String> authList = new ArrayList<String>();
            for (Tb_company_roles_auth roleRelObj : roleRels) {
                authList.add(roleRelObj.getSw_authority_id().toString());
            }
            List<Map<String, Object>> auths = this.authDao.findAll();
            List<Object> rolAuthTree = RoleServiceImpl.treeObjMpList(auths, "", authList);
            ret_method.put(XcbConstantValue.DATA, rolAuthTree);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.CUSER_UPDATE_BYID, "\u89d2\u8272\u5220\u9664\u5931\u8d25", (Throwable)e);
        }
        return ret_method;
    }

    private static List<Object> treeObjMpList(List<Map<String, Object>> objMpList, String parentId, List<String> authids) {
        ArrayList<Object> retObjMpList = new ArrayList<Object>();
        for (Map<String, Object> objMp : objMpList) {
            String sr_level;
            String tempParentId = objMp.get("sw_parentmenu") == null ? "" : objMp.get("sw_parentmenu").toString();
            String tempId = objMp.get("sd_authority_id") == null ? "" : objMp.get("sd_authority_id").toString();
            String string = sr_level = objMp.get("sr_level") == null ? "" : objMp.get("sr_level").toString();
            if (sr_level.equals(XcbConstantValue.MENUE_LEVEL_ZERO)) {
                objMp.put("expand", true);
            }
            if (!tempParentId.equals(parentId)) continue;
            objMp.put("title", (String)objMp.get("sr_authname"));
            retObjMpList.add(objMp);
            List<Object> retChildObjMpList = RoleServiceImpl.treeObjMpList(objMpList, tempId, authids);
            if (retChildObjMpList.size() > 0) {
                objMp.put("children", retChildObjMpList);
                continue;
            }
            if (!authids.contains(tempId)) continue;
            objMp.put("checked", true);
            retObjMpList.remove(retObjMpList.size() - 1);
            retObjMpList.add(objMp);
        }
        return retObjMpList;
    }

    @Transactional
    public Map<String, Object> updateRoleAuthByRoleId(Identifier identifier, Integer sd_roles_id, String[] authArr) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        try {
            List<Tb_company_roles_auth> craList = this.rolesAuthoritiesDao.findByRoleId(sd_roles_id);
            if (ObjectUtil.isNotEmpty(craList)) {
                result = this.rolesAuthoritiesDao.deleteRoleAuthsByRoleId(sd_roles_id);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    isSuccess = true;
                }
            } else {
                isSuccess = true;
            }
            ArrayList<Tb_company_roles_auth> roleAuths = new ArrayList<Tb_company_roles_auth>();
            Date current = new Date();
            if (authArr.length > 0) {
                for (int i = 0; i < authArr.length; ++i) {
                    Tb_company_roles_auth roleAuth = new Tb_company_roles_auth();
                    roleAuth.setSw_roles_id(sd_roles_id);
                    roleAuth.setSw_authority_id(Integer.valueOf(authArr[i]));
                    roleAuth.setCreatedate(current);
                    roleAuth.setCreateuser(identifier.getUserName());
                    roleAuths.add(roleAuth);
                }
            }
            if (roleAuths.size() > 0 && (result = this.rolesAuthoritiesDao.insertRoleAuthByBatch(roleAuths)) > XcbConstantValue.OPERA_INT_ZERO) {
                isSuccess = true;
            }
            if (!isSuccess) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("role.auth.update.fail"));
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("role.auth.update.success"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw new BusinessException(XcbConstantValue.ROLE_AUTH_UPDATE_BYROLEID, PromptProperties.getProperty("role.auth.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> createAuth(Identifier identifier, Tb_company_authorities role) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            role.setSr_authdesc(role.getSr_authname());
            role.setSr_menutitle(role.getSr_authname());
            if (XcbConstantValue.MENU_TYPE_HEADER.equals(role.getSr_type().toUpperCase())) {
                role.setSw_parentmenu(null);
            } else if (XcbConstantValue.MENU_TYPE_SIDER.equals(role.getSr_type().toUpperCase())) {
                role.setSw_parentmenu(role.getSd_authority_id());
            }
            int count = this.authDao.createCompanyAuth(role);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, "\u83dc\u5355\u6743\u9650\u521b\u5efa\u6210\u529f");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u83dc\u5355\u6743\u9650\u521b\u5efa\u5931\u8d25");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AUTH_CREATE, "\u83dc\u5355\u6743\u9650\u521b\u5efa\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> updateAuthById(Identifier identifier, Tb_company_authorities role) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            role.setSr_authdesc(role.getSr_authname());
            role.setSr_menutitle(role.getSr_authname());
            int count = this.authDao.updateById(role);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, "\u83dc\u5355\u6743\u9650\u4fee\u6539\u6210\u529f");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u83dc\u5355\u6743\u9650\u4fee\u6539\u5931\u8d25");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AUTH_UPDATE, "\u83dc\u5355\u6743\u9650\u4fee\u6539\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> delAuthById(Identifier identifier, Integer sd_authority_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int count = 0;
        try {
            this.rolesAuthoritiesDao.deleteRoleAuthsByAuthId(sd_authority_id);
            count = this.authDao.deleteById(sd_authority_id);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                count = this.authDao.deleteByPId(sd_authority_id);
                ret_method.put(XcbConstantValue.MSG, "\u83dc\u5355\u6743\u9650\u5220\u9664\u6210\u529f");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u83dc\u5355\u6743\u9650\u5220\u9664\u5931\u8d25");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AUTH_DELETE, "\u83dc\u5355\u6743\u9650\u5220\u9664\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> batchDeleteById(Identifier identifier, String[] authArr) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int count = 0;
        try {
            this.rolesAuthoritiesDao.batchDeleteRoleAuthsByAuthId(authArr);
            count = this.authDao.batchDeleteById(authArr);
            if (count > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.MSG, "\u83dc\u5355\u6743\u9650\u5220\u9664\u6210\u529f");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u83dc\u5355\u6743\u9650\u5220\u9664\u5931\u8d25");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.AUTH_BATCH_DELETE, "\u83dc\u5355\u6743\u9650\u5220\u9664\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }
}

