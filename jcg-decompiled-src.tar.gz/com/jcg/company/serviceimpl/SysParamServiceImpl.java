/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_sys_param
 *  com.jcg.company.model.Tb_sys_paramtype
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.company.model.Tb_wx_pay_info
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.cache.annotation.Cacheable
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.company.serviceimpl;

import com.jcg.cache.SystemParamCache;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.SysParamDao;
import com.jcg.company.idao.SysParamTypeDao;
import com.jcg.company.idao.WxInfoDao;
import com.jcg.company.idao.WxPayInfoDao;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.model.Tb_sys_paramtype;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.company.model.Tb_wx_pay_info;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class SysParamServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private SysParamDao sysParamDao;
    @Autowired
    private SysParamTypeDao sysParamTypeDao;
    @Autowired
    private SystemParamCache systemParamService;
    @Autowired
    private WxInfoDao wxInfoDao;
    @Autowired
    private WxPayInfoDao wxPayInfoDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Integer sd_sysparam_id = null;
        String sr_category_code = XcbStringUtils.getObjtoString((Object)param.get("sr_category_code"));
        String sr_key_code = XcbStringUtils.getObjtoString((Object)param.get("sr_key_code"));
        Tb_sys_param sysParam = new Tb_sys_param();
        Page page = new Page();
        if (param != null) {
            sd_sysparam_id = XcbStringUtils.getObjtoint((Object)param.get("sd_sysparam_id"));
            sysParam = (Tb_sys_param)param.get("sysParam");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.SYSPARAM_FIND_BYKEYCODE.equalsIgnoreCase(functionCode)) {
                ret = this.findSysParamByKeyCode(sr_category_code, sr_key_code);
            } else if (XcbConstantValue.SYSPARAM_FIND_BYCATE.equalsIgnoreCase(functionCode)) {
                ret = this.findSysParamByCate_agent(sr_category_code);
            } else if (XcbConstantValue.SYSPARAM_FIND_BYCATES.equalsIgnoreCase(functionCode)) {
                ret = this.findDropDownInfos_agent(param);
            } else if (XcbConstantValue.SYSPARAM_FIND_BYCATES_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findDropDownInfos_agent(param);
            } else if (XcbConstantValue.SYSPARAM_CREATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.createSysParam_cpy(identifier, sysParam);
            } else if (XcbConstantValue.SYSPARAM_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findSysParamByParam_cpy(identifier, sysParam, page);
            } else if (XcbConstantValue.SYSPARAM_FIND_BYID_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findSysParamById_cpy(sd_sysparam_id);
            } else if (XcbConstantValue.SYSPARAM_UPDATE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.updateSysParamById_cpy(identifier, sysParam);
            } else if (XcbConstantValue.SYSPARAM_DELETE_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.deleteSysParamById_cpy(identifier, sd_sysparam_id);
            } else if (XcbConstantValue.SYSPARAM_WX_INFO_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findWxInfo();
            } else if (XcbConstantValue.SYSPARAM_FIND_WX_INFO_BYCODE.equalsIgnoreCase(functionCode)) {
                String sr_code = XcbStringUtils.getObjtoString((Object)param.get("sr_code"));
                ret = this.findWxInfoByCode(sr_code);
            } else if (XcbConstantValue.SYSPARAM_FIND_WX_INFO_BYMCHID.equalsIgnoreCase(functionCode)) {
                String sr_mchid = XcbStringUtils.getObjtoString((Object)param.get("sr_mchid"));
                ret = this.findWxInfoByMchid(sr_mchid);
            } else if (XcbConstantValue.SYSPARAM_FIND_WX_OUT_INFO_BYCODE.equalsIgnoreCase(functionCode)) {
                String sr_code = XcbStringUtils.getObjtoString((Object)param.get("sr_code"));
                ret = this.findWxOutInfoByCode(sr_code);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    public Map<String, Object> findSysParamByKeyCode(String sr_category_code, String sr_key_code) {
        Tb_sys_param tb_sys_param = null;
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            tb_sys_param = this.sysParamDao.findSysParamByKeyCode(sr_category_code, sr_key_code);
            ret.put("sysParam", tb_sys_param);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_FIND_BYKEYCODE, PromptProperties.getProperty("sysparam.find.fail"), (Throwable)e);
        }
        return ret;
    }

    @Cacheable(value={"sysParamCache"})
    public Map<String, List<Map<String, Object>>> findSysParamAll() {
        HashMap<String, List<Map<String, Object>>> map_sysparams = new HashMap<String, List<Map<String, Object>>>();
        try {
            List<Map<String, Object>> list_sysParams = this.sysParamDao.findSysParamAll();
            if (list_sysParams != null && list_sysParams.size() > 0) {
                for (int i = 0; i < list_sysParams.size(); ++i) {
                    Map<String, Object> sysParam = list_sysParams.get(i);
                    String category_code = XcbStringUtils.getObjtoString((Object)sysParam.get("sr_category_code"));
                    if (map_sysparams.containsKey(category_code)) {
                        ((List)map_sysparams.get(category_code)).add(sysParam);
                        continue;
                    }
                    ArrayList<Map<String, Object>> category_param = new ArrayList<Map<String, Object>>();
                    category_param.add(sysParam);
                    map_sysparams.put(category_code, category_param);
                }
            }
        }
        catch (Exception e) {
            throw new BusinessException("findSysParamAll", PromptProperties.getProperty("sysparam.find.fail"), (Throwable)e);
        }
        return map_sysparams;
    }

    public Map<String, Object> findSysParamByCate_agent(String sr_category_code) {
        List<Tb_sys_param> list_sysParam = null;
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            list_sysParam = this.sysParamDao.findSysParamByCate_agent(sr_category_code);
            ret.put("sysParams", list_sysParam);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_FIND_BYCATE, PromptProperties.getProperty("sysparam.find.fail"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> findDropDownInfos_agent(Map<String, Object> param) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> retData = new HashMap<String, Object>();
        String categoryCodes = (String)param.get("categoryCodes");
        String sr_login_type = XcbStringUtils.getObjtoString((Object)param.get("sr_login_type"));
        String[] cates = null;
        try {
            cates = categoryCodes.indexOf(",") != -1 ? categoryCodes.split(",") : new String[]{categoryCodes};
            for (String cate : cates) {
                String value;
                ArrayList<Map<String, Object>> cateJcg;
                if ((cate = cate.trim()).equals("")) continue;
                List<Map<String, Object>> cateObjList = this.systemParamService.getSysParam(cate);
                if ("DEVICE_TYPE".equals(cate)) {
                    if (!XcbStringUtils.isNullOrBlank((Object)sr_login_type)) {
                        cateJcg = new ArrayList<Map<String, Object>>();
                        for (Map<String, Object> map : cateObjList) {
                            value = XcbStringUtils.getObjtoString((Object)map.get("value"));
                            cateJcg.add(map);
                        }
                        retData.put("DEVICE_TYPE_JCG", cateJcg);
                        continue;
                    }
                    retData.put(cate, cateObjList == null ? new HashMap() : cateObjList);
                    continue;
                }
                if ("LS_PROJECT".equals(cate)) {
                    if (!XcbStringUtils.isNullOrBlank((Object)sr_login_type)) {
                        cateJcg = new ArrayList();
                        for (Map<String, Object> map : cateObjList) {
                            value = XcbStringUtils.getObjtoString((Object)map.get("value"));
                            cateJcg.add(map);
                        }
                        retData.put("LS_PROJECT_JCG", cateJcg);
                        continue;
                    }
                    retData.put(cate, cateObjList == null ? new HashMap() : cateObjList);
                    continue;
                }
                if ("AGENT_USER_ROLE".equals(cate)) {
                    if (!XcbStringUtils.isNullOrBlank((Object)sr_login_type)) {
                        cateJcg = new ArrayList();
                        for (Map<String, Object> map : cateObjList) {
                            value = XcbStringUtils.getObjtoString((Object)map.get("value"));
                            cateJcg.add(map);
                        }
                        retData.put("AGENT_USER_ROLE_JCG", cateJcg);
                        continue;
                    }
                    retData.put(cate, cateObjList == null ? new HashMap() : cateObjList);
                    continue;
                }
                retData.put(cate, cateObjList == null ? new HashMap() : cateObjList);
            }
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.DATA, retData);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_FIND_BYKEYCODE, PromptProperties.getProperty("sysparam.find.fail"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> createSysParam_cpy(Identifier identifier, Tb_sys_param sysParam) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = 0;
            sysParam.setTm_create_time(new Date());
            sysParam.setSr_create_person(identifier.getUserName());
            Tb_sys_paramtype syspt = this.sysParamTypeDao.findSysParamTypeById(sysParam.getSw_category_code());
            if (syspt != null) {
                sysParam.setSr_category_code(syspt.getSr_category_code());
            }
            if ((result = this.sysParamDao.createSysParam_cpy(sysParam)) > 0) {
                ret_method.put(XcbConstantValue.DATA, result);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("\u65b0\u589e\u7cfb\u7edf\u53c2\u6570\u6210\u529f"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("\u65b0\u589e\u7cfb\u7edf\u53c2\u6570\u5931\u8d25"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_CREATE_CPY, PromptProperties.getProperty("\u65b0\u589e\u7cfb\u7edf\u53c2\u6570\u5931\u8d25"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findSysParamByParam_cpy(Identifier identifier, Tb_sys_param sysParam, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_sys_param> sysParams = this.sysParamDao.findSysParamByParam_cpy(sysParam, page);
            int totalCount = this.sysParamDao.findCountByParam_cpy(sysParam);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("sysParams", sysParams);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_FIND_BYPARAM_CPY, PromptProperties.getProperty("\u67e5\u8be2\u7cfb\u7edf\u53c2\u6570\u5931\u8d25"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateSysParamById_cpy(Identifier identifier, Tb_sys_param sysParam) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        sysParam.setTm_modify_time(new Date());
        sysParam.setSr_modify_person(identifier.getUserName());
        try {
            Tb_sys_paramtype syspt = this.sysParamTypeDao.findSysParamTypeById(sysParam.getSw_category_code());
            if (syspt != null) {
                sysParam.setSr_category_code(syspt.getSr_category_code());
            }
            if ((result = this.sysParamDao.updateById_cpy(sysParam)) > 0) {
                ret_method.put(XcbConstantValue.DATA, result);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("sysparam.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("sysparam.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_UPDATE_CPY, PromptProperties.getProperty("sysparam.update.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findSysParamById_cpy(Integer sd_sysparam_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_sys_param sysParam = this.sysParamDao.findSysParamById_cpy(sd_sysparam_id);
            ret_method.put(XcbConstantValue.DATA, sysParam);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_FIND_BYID_CPY, PromptProperties.getProperty("\u901a\u8fc7ID\u67e5\u8be2\u7cfb\u7edf\u53c2\u6570\u5931\u8d25"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> deleteSysParamById_cpy(Identifier identifier, Integer sd_sysparam_id) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            int result = this.sysParamDao.deleteById_cpy(sd_sysparam_id);
            if (result > 0) {
                ret_method.put(XcbConstantValue.DATA, result);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("\u5220\u9664\u7cfb\u7edf\u53c2\u6570\u6210\u529f"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("\u5220\u9664\u7cfb\u7edf\u53c2\u6570\u5931\u8d25"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_DELETE_CPY, PromptProperties.getProperty("\u5220\u9664\u7cfb\u7edf\u53c2\u6570\u5931\u8d25"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Integer> getNewId(String category_code, String key_code) {
        HashMap<String, Integer> ret = new HashMap<String, Integer>();
        try {
            Tb_sys_param tb_sys_param = this.sysParamDao.findSysParamByKeyCode(category_code, key_code);
            String id_str = tb_sys_param.getSr_param_value();
            int id_int = 0;
            if (id_str != null) {
                id_int = Integer.valueOf(id_str);
                ++id_int;
            }
            ret.put("sr_param_value", id_int);
            ret.put("sd_sysparam_id", tb_sys_param.getSd_sysparam_id());
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_NEW_ID, "\u67e5\u8be2\u7cfb\u7edf\u53c2\u6570\u83b7\u5f97\u6700\u65b0Id", (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> findWxInfo() {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            List<Map<String, Object>> dataMap = this.wxInfoDao.findInfoList();
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, "\u67e5\u8be2\u6210\u529f");
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_WX_INFO_CPY, "\u53c2\u6570\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findWxInfoByCode(String sr_code) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_wx_info info = this.wxInfoDao.findInfoByCode(sr_code);
            if (info != null) {
                Tb_wx_pay_info pay_info = this.wxPayInfoDao.findNewDefaultPayIn(info.getSr_code());
                info.setPay_info(pay_info);
            }
            ret_method.put(XcbConstantValue.DATA, info);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, "\u67e5\u8be2\u6210\u529f");
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_FIND_WX_INFO_BYCODE, "\u53c2\u6570\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findWxInfoByMchid(String sr_mchid) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_wx_pay_info pay_info = this.wxPayInfoDao.findPayInfo(sr_mchid);
            ret_method.put(XcbConstantValue.DATA, pay_info);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, "\u67e5\u8be2\u6210\u529f");
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_FIND_WX_INFO_BYMCHID, "\u53c2\u6570\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findWxOutInfoByCode(String sr_way) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_wx_info info = this.wxInfoDao.findInfoByCode(sr_way);
            if (info != null) {
                Tb_wx_pay_info pay_info = this.wxPayInfoDao.findNewDefaultPayOut(info.getSr_code());
                info.setPay_info(pay_info);
            }
            ret_method.put(XcbConstantValue.DATA, info);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, "\u67e5\u8be2\u6210\u529f");
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.SYSPARAM_FIND_WX_OUT_INFO_BYCODE, "\u53c2\u6570\u67e5\u8be2\u5f02\u5e38", (Throwable)e);
        }
        return ret_method;
    }
}

