/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.wxpay.sdk.WXPayUtil
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_cash_stream
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_netpoint
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.agent.model.Tb_ordercash_stream
 *  com.jcg.agent.model.Tb_recharge_set
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.user.model.Tb_user
 *  com.jcg.user.model.Tb_user_account
 *  com.jcg.user.model.Tb_user_withdrawal_appl
 *  javax.annotation.Resource
 *  org.apache.commons.lang.StringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.jdbc.datasource.DataSourceTransactionManager
 *  org.springframework.scheduling.annotation.Async
 *  org.springframework.scheduling.annotation.Scheduled
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.task.business;

import com.github.wxpay.sdk.WXPayUtil;
import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.CashStreamDao;
import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.DeviceLogsDao;
import com.jcg.agent.idao.OrderCashStreamDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.idao.RechargeSetDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_cash_stream;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_netpoint;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.model.Tb_ordercash_stream;
import com.jcg.agent.model.Tb_recharge_set;
import com.jcg.agent.serviceimpl.DeviceBoxServiceImpl;
import com.jcg.agent.serviceimpl.DeviceServiceImpl;
import com.jcg.agent.serviceimpl.OrderServiceImpl;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.PromptProperties;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.WxPayInfoDao;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.idao.UserAccountDao;
import com.jcg.user.idao.UserDao;
import com.jcg.user.idao.UserRechargeDao;
import com.jcg.user.idao.UserWithdrawalApplDao;
import com.jcg.user.model.Tb_user;
import com.jcg.user.model.Tb_user_account;
import com.jcg.user.model.Tb_user_withdrawal_appl;
import com.jcg.user.serviceimpl.UserAccountServiceImpl;
import com.jcg.user.serviceimpl.UserServiceImpl;
import com.jcg.user.serviceimpl.UserWithdrawalApplServiceImpl;
import com.jcg.wxmsg.serviceimpl.WxMessageServiceImpl;
import com.jcg.wxmsg.vo.WxMessage;
import com.jcg.zf.wx.EnterprisesPayment;
import com.jcg.zf.wx.Signature;
import com.jcg.zf.wx.UUidUtils;
import com.jcg.zf.wx.WXWithdrawTools;
import com.jcg.zf.wx.WxAPIV3Common;
import com.jcg.zf.wx.WxSdjAPICommon;
import com.jcg.zf.wx.WxSpAPIV3Common;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

public class BusinessTask
extends BaseService {
    @Autowired
    public OrderDao orderDao;
    @Autowired
    public OrderServiceImpl orderService;
    @Autowired
    public DeviceDao deviceDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private OrderCashStreamDao orderCashStreamDao;
    @Autowired
    public UserRechargeDao userRechargeDao;
    @Autowired
    public WxAPIV3Common wxAPIV3Common;
    @Autowired
    public WxSdjAPICommon wxSdjAPICommon;
    @Autowired
    public WxSpAPIV3Common wxSpAPIV3Common;
    @Autowired
    private DeviceLogsDao deviceLogsDao;
    @Autowired
    private RechargeSetDao rechargeSetDao;
    @Autowired
    private UserAccountDao userAccountDao;
    @Autowired
    private CommonLogic commonLogic;
    @Autowired
    private DeviceBoxServiceImpl deviceBoxService;
    @Autowired
    private DeviceBoxDao deviceBoxDao;
    @Autowired
    private RedisUtil redis;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private CashStreamDao cashStreamDao;
    @Autowired
    private UserWithdrawalApplDao userWithdrawalApplDao;
    @Autowired
    private WXWithdrawTools wxWithdrawTools;
    @Autowired
    private UserWithdrawalApplServiceImpl userWithdrawalApplService;
    @Resource
    private DataSourceTransactionManager transactionManager;
    @Autowired
    private WxMessageServiceImpl wxMessageService;
    @Autowired
    private WxPayInfoDao wxPayInfoDao;
    @Autowired
    private DeviceServiceImpl deviceService;
    @Autowired
    private UserAccountServiceImpl userAccountService;
    @Autowired
    private UserServiceImpl userService;

    @Scheduled(cron="0 15 0 ? * *")
    public void createStatistics() throws Exception {
        this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210 START #################");
        Date today = new Date();
        String statistics_date = XcbDateUtil.getBeforeDay((Date)today, (int)1, (String)"yyyy-MM-dd");
        List<Tb_agent> list_agent = this.orderDao.getAllAgent_task();
        if (list_agent != null && list_agent.size() > 0) {
            for (int i = 0; i < list_agent.size(); ++i) {
                Tb_agent agent = list_agent.get(i);
                Integer sw_agent_id = agent.getSd_agent_id();
                this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210\uff0c\u4ee3\u7406\u5546: " + sw_agent_id + " START #################");
                this.orderService.createStatistics(statistics_date, sw_agent_id);
                this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210\uff0c\u4ee3\u7406\u5546: " + sw_agent_id + " END #################");
            }
        }
        this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u7edf\u8ba1\u6570\u636e\u81ea\u52a8\u751f\u6210 END #################");
    }

    @Scheduled(cron="0 2 0 ? * *")
    @Transactional
    public void agentmoney_task() throws Exception {
        try {
            this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u5546\u5bb6\u4f59\u989d\u6253\u6b3e START #################");
            List<Tb_agent> list = this.agentDao.findAgentForTask();
            for (Tb_agent agent : list) {
                int result = 0;
                Tb_cash_stream cashStream = new Tb_cash_stream();
                cashStream.setSw_agent_id(agent.getSd_agent_id());
                List<String> cashList = this.cashStreamDao.findCashStreamListByParam(cashStream);
                if (cashList == null || cashList.size() <= 0) continue;
                cashStream.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_JCGDD);
                Map incomeMap = CommonFunction.null2HashMap(this.cashStreamDao.findCashStreamByParam_task(cashStream));
                BigDecimal incomeMoney = XcbStringUtils.getObjToBigDecimal(incomeMap.get("dc_cashflow_money_sum"));
                this.log.info("#################\u5546\u5bb6" + agent.getSd_agent_id() + "," + agent.getSr_user_name() + "," + agent.getSr_agent_money() + "#################");
                BigDecimal dc_agent_money = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_agent_money());
                this.log.info("#################\u5f53\u524d\u5269\u4f59\u8d26\u6237\u4f59\u989d : " + dc_agent_money + "\u5143 #################");
                BigDecimal dc_cb_money = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_cb_money());
                this.log.info("#################\u5f53\u524d\u5269\u4f59\u50a8\u5907\u91d1\u4f59\u989d : " + dc_cb_money + "\u5143 #################");
                BigDecimal dc_cb_single = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_cb_single());
                this.log.info("#################\u5f53\u524d\u50a8\u5907\u91d1\u5c01\u9876\u7684\u53c2\u6570 : " + dc_cb_single + "\u5143 #################");
                this.log.info("#################\u8ba2\u5355\u6d41\u6c34\u6536\u76ca\u603b\u989d #################");
                this.log.info("#################" + incomeMoney + "\u5143 #################");
                cashStream.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_CBJCZ);
                Map cbMap = CommonFunction.null2HashMap(this.cashStreamDao.findCashStreamByParam_task(cashStream));
                BigDecimal cbMoney = XcbStringUtils.getObjToBigDecimal(cbMap.get("dc_cashflow_money_sum"));
                this.log.info("#################\u50a8\u5907\u91d1\u6536\u76ca\u603b\u989d #################");
                this.log.info("#################" + cbMoney + "\u5143 #################");
                cashStream.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_JCGDDTK);
                Map tkMap = CommonFunction.null2HashMap(this.cashStreamDao.findCashStreamByParam_task(cashStream));
                BigDecimal tkMoney = XcbStringUtils.getObjToBigDecimal(tkMap.get("dc_cashflow_money_sum"));
                this.log.info("#################\u8ba2\u5355\u9000\u6b3e\u603b\u989d #################");
                this.log.info("#################" + tkMoney + "\u5143 #################");
                BigDecimal totalMoney = BigDecimalUtil.sub((BigDecimal)BigDecimalUtil.add((BigDecimal)incomeMoney, (BigDecimal)cbMoney), (BigDecimal)tkMoney);
                this.log.info("################# \u8ba1\u7b97\u540e\u771f\u5b9e\u6536\u5165\u603b\u989d : " + totalMoney + "\u5143 #################");
                if (dc_cb_single.compareTo(BigDecimal.ZERO) == 1) {
                    if (cbMoney.compareTo(dc_cb_single) >= 0) {
                        result = this.commonLogic.updateAgent_agentmoney(totalMoney, agent, XcbConstantValue.TB_TYPE_ADD);
                    } else {
                        BigDecimal tempMoney = BigDecimalUtil.add((BigDecimal)cbMoney, (BigDecimal)totalMoney);
                        if (tempMoney.compareTo(dc_cb_single) <= 0) {
                            result = this.commonLogic.updateAgent_cbmoney(totalMoney, agent, XcbConstantValue.TB_TYPE_ADD);
                        } else {
                            BigDecimal tempMoney2 = BigDecimalUtil.sub((BigDecimal)tempMoney, (BigDecimal)dc_cb_single);
                            result = this.commonLogic.updateAgent_cbmoney(BigDecimalUtil.sub((BigDecimal)totalMoney, (BigDecimal)tempMoney2), agent, XcbConstantValue.TB_TYPE_ADD);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                result = this.commonLogic.updateAgent_agentmoney(tempMoney2, agent, XcbConstantValue.TB_TYPE_ADD);
                            }
                        }
                    }
                } else {
                    result = this.commonLogic.updateAgent_agentmoney(totalMoney, agent, XcbConstantValue.TB_TYPE_ADD);
                }
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    Object[] arr = cashList.toArray(new String[0]);
                    String str = StringUtils.join((Object[])arr, (String)",");
                    this.log.info("############\u6279\u91cf\u5904\u7406\u7684\u8d44\u91d1\u6d41\u6c34\u8ba2\u5355\u53f7#############");
                    this.log.info(str);
                    this.log.info("############\u6279\u91cf\u5904\u7406\u7684\u8d44\u91d1\u6d41\u6c34\u8ba2\u5355\u53f7#############");
                    result = this.cashStreamDao.updateCash_task((String[])arr);
                    if (result >= XcbConstantValue.OPERA_INT_ZERO) continue;
                    TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                    continue;
                }
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
        }
        catch (Exception e) {
            System.out.println(e);
            this.log.error(e.getMessage());
        }
        this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u5546\u5bb6\u4f59\u989d\u6253\u6b3e END #################");
    }

    @Scheduled(cron="0 3 0 ? * *")
    @Transactional
    public void admoney_task() throws Exception {
        try {
            this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u5546\u5bb6\u5e7f\u544a\u8d39\u6253\u6b3e START #################");
            Date today = new Date();
            String sr_date = XcbDateUtil.getBeforeDay((Date)today, (int)1, (String)"yyyy-MM-dd");
            List<Tb_agent> list = this.agentDao.findAdAgentForTask();
            for (Tb_agent agent : list) {
                Map orderMap = CommonFunction.null2HashMap(this.orderDao.findAdCashByAgentId(agent.getSd_agent_id(), sr_date));
                BigDecimal dc_ad_money_sum = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_ad_money_sum"));
                this.log.info("############\u65f6\u95f4:" + sr_date + "\u66f4\u65b0\u524d - \u5546\u5bb6" + agent.getSd_agent_id() + " | " + agent.getSr_agent_name() + " | \u672a\u63d0\u73b0\u5e7f\u544a\u8d39: " + agent.getDc_ad_money() + "\u5143\u3002#############");
                this.log.info("############\u65f6\u95f4:" + sr_date + "\u5546\u5bb6" + agent.getSd_agent_id() + " | " + agent.getSr_agent_name() + " | \u5e7f\u544a\u6536\u5165: " + dc_ad_money_sum + "\u5143\u3002#############");
                int result = this.commonLogic.updateAgent_admoney(dc_ad_money_sum, agent, XcbConstantValue.TB_TYPE_ADD);
                if (result <= XcbConstantValue.OPERA_INT_ZERO) continue;
                Tb_cash_stream cashStream = new Tb_cash_stream();
                cashStream.setSd_cash_id(CommonFunction.getVoucherNum((String)CommonFunction.zx_id));
                cashStream.setSw_agent_id(agent.getSd_agent_id());
                cashStream.setDc_cashflow_money(dc_ad_money_sum);
                cashStream.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_GGSR);
                cashStream.setTm_cashflow_time(new Date());
                cashStream.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                cashStream.setTm_create_time(new Date());
                cashStream.setSi_create_person(agent.getSd_agent_id());
                cashStream.setTm_modify_time(new Date());
                cashStream.setSi_modify_person(agent.getSd_agent_id());
                cashStream.setSr_checked(XcbConstantValue.CASH_STREAM_YFH);
                this.cashStreamDao.createCashStream(cashStream);
                Tb_agent a = this.agentDao.findAgentById_agent(agent.getSd_agent_id());
                this.log.info("############\u65f6\u95f4:" + sr_date + "\u66f4\u65b0\u540e - \u5546\u5bb6" + a.getSd_agent_id() + " | " + a.getSr_agent_name() + " | \u672a\u63d0\u73b0\u5e7f\u544a\u8d39: " + a.getDc_ad_money() + "\u5143\u3002#############");
            }
            this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u5546\u5bb6\u5e7f\u544a\u8d39\u6253\u6b3e End #################");
        }
        catch (Exception e) {
            System.out.println(e);
            this.log.error(e.getMessage());
        }
    }

    @Scheduled(cron="0 5 0 ? * *")
    @Transactional
    public void upadmoney_task() throws Exception {
        try {
            this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u4ee3\u7406\u5546\u5e7f\u544a\u8d39\u6253\u6b3e START #################");
            Date today = new Date();
            String sr_date = XcbDateUtil.getBeforeDay((Date)today, (int)1, (String)"yyyy-MM-dd");
            List<Tb_agent> list = this.agentDao.findUpAdAgentForTask();
            for (Tb_agent agent : list) {
                Map orderMap = CommonFunction.null2HashMap(this.orderDao.findUpAdCashByAgentId(agent.getSd_agent_id(), agent.getSr_is_show(), sr_date));
                BigDecimal dc_ad_money_sum = XcbStringUtils.getObjToBigDecimal(orderMap.get("dc_ad_money_sum"));
                Tb_agent upAgent = this.agentDao.findAgentById_agent(agent.getSi_up_agent());
                this.log.info("############\u65f6\u95f4:" + sr_date + "\u66f4\u65b0\u524d - \u4ee3\u7406\u5546" + upAgent.getSd_agent_id() + " | " + upAgent.getSr_agent_name() + " | \u672a\u63d0\u73b0\u5e7f\u544a\u8d39: " + upAgent.getDc_ad_money() + "\u5143\u3002#############");
                this.log.info("############\u65f6\u95f4:" + sr_date + "\u4ee3\u7406\u5546" + upAgent.getSd_agent_id() + " | " + upAgent.getSr_agent_name() + " | \u5e7f\u544a\u6536\u5165: " + dc_ad_money_sum + "\u5143\u3002#############");
                int result = this.commonLogic.updateAgent_admoney(dc_ad_money_sum, upAgent, XcbConstantValue.TB_TYPE_ADD);
                if (result <= XcbConstantValue.OPERA_INT_ZERO) continue;
                Tb_cash_stream cashStream = new Tb_cash_stream();
                cashStream.setSd_cash_id(CommonFunction.getVoucherNum((String)CommonFunction.zx_id));
                cashStream.setSw_agent_id(upAgent.getSd_agent_id());
                cashStream.setDc_cashflow_money(dc_ad_money_sum);
                cashStream.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_GGSR);
                cashStream.setTm_cashflow_time(new Date());
                cashStream.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                cashStream.setTm_create_time(new Date());
                cashStream.setSi_create_person(upAgent.getSd_agent_id());
                cashStream.setTm_modify_time(new Date());
                cashStream.setSi_modify_person(upAgent.getSd_agent_id());
                cashStream.setSr_checked(XcbConstantValue.CASH_STREAM_YFH);
                this.cashStreamDao.createCashStream(cashStream);
                Tb_agent a = this.agentDao.findAgentById_agent(upAgent.getSd_agent_id());
                this.log.info("############\u65f6\u95f4:" + sr_date + "\u66f4\u65b0\u540e - \u4ee3\u7406\u5546" + a.getSd_agent_id() + " | " + a.getSr_agent_name() + " | \u672a\u63d0\u73b0\u5e7f\u544a\u8d39: " + a.getDc_ad_money() + "\u5143\u3002#############");
            }
            this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u4ee3\u7406\u5546\u5e7f\u544a\u8d39\u6253\u6b3e End #################");
        }
        catch (Exception e) {
            System.out.println(e);
            this.log.error(e.getMessage());
        }
    }

    @Scheduled(cron="0 0 0-23 * * ?")
    public void netpointTask() throws Exception {
        this.log.info("###############\u4efb\u52a1\u9000\u6b3e\u5f00\u59cb###############");
        Map<Object, Object> ret = new HashMap();
        int result = 0;
        String msg = "";
        Date nowDate = new Date();
        this.log.info("##########\u7cfb\u7edf\u65f6\u95f4:" + nowDate + "###########");
        Date afterDate = new Date(nowDate.getTime() + 6000L);
        this.log.info("##########\u5ef6\u8fdf\u7cfb\u7edf\u65f6\u95f4:" + afterDate + "###########");
        String sr_type = "TASK_USER_APPL";
        Tb_recharge_set set = this.rechargeSetDao.findUserTaskRechargeSet(sr_type);
        if (set != null) {
            String nowTime = XcbDateUtil.getHour((Date)afterDate);
            this.log.info("##########\u4efb\u52a1\u65f6\u95f4:" + nowTime + "###########");
            List<Tb_user_withdrawal_appl> dsp_appl = this.userWithdrawalApplDao.findDSPUserWithdrawalAppl_task();
            for (Tb_user_withdrawal_appl appl : dsp_appl) {
                boolean isSuccess = false;
                Tb_user user = this.userDao.findUserById(appl.getSw_user_id());
                String sr_order_arr = XcbStringUtils.getObjtoString((Object)appl.getSr_order_arr());
                if (!XcbStringUtils.isNullOrBlank((Object)sr_order_arr)) {
                    int cycle;
                    String[] orderArr = sr_order_arr.split(",");
                    Tb_netpoint netpoint = this.orderDao.findNewOrderForNetpoint(orderArr);
                    String sr_mode_task_hour = XcbStringUtils.getObjtoString((Object)netpoint.getSr_mode_task_hour());
                    String[] task_arr = sr_mode_task_hour.split(",");
                    List<String> hour_list = Arrays.asList(task_arr);
                    if (!hour_list.contains(nowTime)) continue;
                    int sr_mode_task_cycle = XcbStringUtils.getObjtoint((Object)netpoint.getSr_mode_task_cycle());
                    int tk_cnt = this.orderDao.findCountDepositRefundByOrderArr(orderArr);
                    int diff = XcbDateUtil.daysBetween((Date)appl.getTm_create_time(), (Date)afterDate);
                    if (diff < (cycle = sr_mode_task_cycle)) continue;
                    boolean isCanAppl = false;
                    Integer si_click = XcbStringUtils.getObjtoint((Object)user.getSi_click());
                    this.log.info("########################\u7cfb\u7edf\u4efb\u52a1: \u63d0\u73b0\u7533\u8bf7ID:" + appl.getSd_id() + "\uff0c\u5ba1\u6279\u7f51\u70b9: " + netpoint.getSr_net_name() + "\u5f00\u59cb########################");
                    if (tk_cnt == 0) {
                        BigDecimal dc_temp;
                        BigDecimal dc_temp_rate;
                        BigDecimal dc_rate = XcbStringUtils.getObjToBigDecimal((Object)netpoint.getDc_rate());
                        String[] si_max_click = Integer.valueOf(XcbStringUtils.getObjtoint((Object)netpoint.getSi_max_click()));
                        Integer si_max_appl = XcbStringUtils.getObjtoint((Object)netpoint.getSi_max_appl());
                        Integer si_wtx_cnt = 0;
                        Tb_order o_order = new Tb_order();
                        o_order.setSw_netpoint_id(netpoint.getSd_netpoint_id());
                        o_order.setSr_order_starttime(XcbDateUtil.getStartDay((String)XcbDateUtil.getBeforeDay((Date)new Date(), (int)90, (String)"yyyy-MM-dd")));
                        o_order.setSr_order_endtime(XcbDateUtil.getTodayEnd((Date)new Date()));
                        Integer all_cnt = this.orderDao.findAllOrderByNetId_task(o_order);
                        Integer success_cnt = this.orderDao.findSuccessOrderByNetId_task(o_order);
                        if (all_cnt == 0) {
                            all_cnt = 1;
                        }
                        if ((dc_temp_rate = BigDecimalUtil.mul((BigDecimal)(dc_temp = BigDecimalUtil.div3((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)success_cnt), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)all_cnt))), (BigDecimal)new BigDecimal(100))).compareTo(dc_rate) == 1) {
                            List<Tb_user_withdrawal_appl> list = this.userWithdrawalApplDao.findDSPUserWithdrawalAppl(appl.getSw_user_id());
                            if (list != null && list.size() > 0) {
                                si_wtx_cnt = list.size();
                                isCanAppl = si_wtx_cnt < si_max_appl ? si_click >= si_max_click.intValue() : true;
                            } else {
                                isCanAppl = false;
                                this.log.error("\u5f02\u5e38\u63d0\u73b0\u7533\u8bf7\uff0c\u627e\u4e0d\u5230\u5f53\u524d\u7528\u6237\u5f85\u5ba1\u6279\u7684\u63d0\u73b0\u8bb0\u5f55\uff0c\u63d0\u73b0ID:" + appl.getSd_id() + "\uff0c\u63d0\u73b0\u7528\u6237ID" + appl.getSw_user_id());
                            }
                        } else {
                            isCanAppl = true;
                        }
                    } else {
                        isCanAppl = true;
                    }
                    Identifier identifier = new Identifier();
                    identifier.setUserName("\u7cfb\u7edf\u5ba1\u6279");
                    if (isCanAppl) {
                        for (String sd_order_id : orderArr) {
                            Tb_order order = this.orderDao.findOrderById_user(sd_order_id);
                            BigDecimal dc_deposit_refund = XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_refund());
                            if (dc_deposit_refund.compareTo(BigDecimal.ZERO) == 0) {
                                BigDecimal dc_deposit_money = order.getDc_deposit_money();
                                String sr_checked = XcbStringUtils.getObjtoString((Object)order.getSr_checked());
                                this.log.info("\u4fee\u6539\u8ba2\u5355" + order.getSd_order_id() + "\u62bc\u91d1\u9000\u6b3e\u91d1\u989d:" + dc_deposit_money + "\u5143");
                                if (XcbConstantValue.ORDER_F.equals(sr_checked)) {
                                    order.setSr_checked(XcbConstantValue.ORDER_T);
                                }
                                order.setDc_deposit_refund(dc_deposit_money);
                                result = this.orderDao.updateDepositRefund(order);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    Tb_wx_pay_info pay_info;
                                    List<Tb_ordercash_stream> ordercashList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                    Tb_ordercash_stream orderCash = ordercashList.get(0);
                                    String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                                    Date tm_create_time = orderCash.getTm_create_time();
                                    int si_diff = XcbDateUtil.daysBetween((Date)tm_create_time, (Date)nowDate);
                                    if (si_diff < 180) {
                                        int refund_fee;
                                        pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
                                        if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                                            refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                            int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                            pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                            this.wxAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                        } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                                            String refund_fee2 = XcbStringUtils.getObjtoString((Object)dc_deposit_money);
                                            String total_fee = XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money());
                                            pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                            this.wxSdjAPICommon.xcrefund(orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee2, pay_info);
                                        } else {
                                            refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                            int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                            pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                            this.wxSpAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                        }
                                    } else {
                                        pay_info = this.wxPayInfoDao.findUserDefaultPayOut(user.getSr_way());
                                        if (XcbConstantValue.PAY_QY.equals(pay_info.getSr_pay_type())) {
                                            String zf_money_fen = CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money));
                                            String zf_desc = pay_info.getSr_payment_desc();
                                            String cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                                            EnterprisesPayment enterprisesPayment = new EnterprisesPayment();
                                            enterprisesPayment.setMch_appid(pay_info.getSub_appid());
                                            enterprisesPayment.setMchid(pay_info.getSub_mchid());
                                            enterprisesPayment.setNonce_str(UUidUtils.getUUid());
                                            enterprisesPayment.setPartner_trade_no(cash_trade_no);
                                            enterprisesPayment.setOpenid(user.getSr_app_open_id());
                                            enterprisesPayment.setCheck_name("NO_CHECK");
                                            enterprisesPayment.setAmount(XcbStringUtils.getObjtoint((Object)zf_money_fen));
                                            enterprisesPayment.setDesc(zf_desc);
                                            enterprisesPayment.setSpbill_create_ip(pay_info.getSr_payserver_ip());
                                            String apiKey = pay_info.getSub_merkey_v2();
                                            this.log.info("sign key ============{}", (Object)apiKey);
                                            String sign = Signature.getSign(apiKey, enterprisesPayment);
                                            enterprisesPayment.setSign(sign);
                                            this.log.info("sign====={}", (Object)sign);
                                            System.out.println("sign====={}" + sign);
                                            String xmlWithdrawInfo = this.wxWithdrawTools.getXMLStringForObj(enterprisesPayment);
                                            this.log.info("\u63d0\u73b0\u53c2\u6570\u4e3a======{}", (Object)xmlWithdrawInfo);
                                            System.out.println("\u63d0\u73b0\u53c2\u6570\u4e3a======{}" + xmlWithdrawInfo);
                                            String response = this.wxWithdrawTools.postParamesForUrl(xmlWithdrawInfo, "https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers", pay_info);
                                            this.log.info("\u63d0\u73b0\u7ed3\u679c\u4e3a==={}", (Object)response);
                                            System.out.println("\u63d0\u73b0\u7ed3\u679c\u4e3a======{}" + response);
                                            Map return_data = null;
                                            try {
                                                return_data = WXPayUtil.xmlToMap((String)response);
                                            }
                                            catch (Exception e) {
                                                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                                                this.log.error("\u4f01\u4e1a\u6253\u6b3e-\u7528\u6237\u4ed8\u6b3e-\u652f\u4ed8\u8fd4\u56de\u7ed3\u679c\u89e3\u6790\u5931\u8d25:" + XcbStringUtils.exceptionToString((Exception)e));
                                            }
                                            String return_code = (String)return_data.get("return_code");
                                            String result_code = (String)return_data.get("result_code");
                                            try {
                                                if ("SUCCESS".equals(return_code)) {
                                                    Tb_cash_stream cashflow = new Tb_cash_stream();
                                                    cashflow.setSd_cash_id(cash_trade_no);
                                                    cashflow.setSw_company_id(user.getSw_company_id());
                                                    cashflow.setSr_cashflow_remark(orderCash.getSd_ordercash_id());
                                                    cashflow.setDc_cashflow_money(dc_deposit_money);
                                                    cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
                                                    cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                                    cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                                    cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                                                    cashflow.setSr_remarks("\u7528\u6237" + user.getSd_user_id() + "\u4f59\u989d\u63d0\u73b0\u5230\u96f6\u94b1");
                                                    this.cashStreamDao.createCashStream(cashflow);
                                                }
                                            }
                                            catch (Exception e) {
                                                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4f01\u4e1a\u6253\u6b3e-\u7528\u6237\u4f59\u989d\u63d0\u73b0\u5931\u8d25\uff0ccash_trade_no\uff1a" + cash_trade_no, "", "");
                                                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                                                operationLogs.setSr_operate_primarykey(orderCash.getSd_ordercash_id());
                                                operationLogs.setSr_operate_table("tb_ordercash_stream");
                                                this.operationLogServiceImpl.createOperaLog(operationLogs);
                                            }
                                        } else {
                                            String cash_trade_no;
                                            int zf_money_fen = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                            ret = this.wxAPIV3Common.wx_pay_user(pay_info, zf_money_fen, user, cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id));
                                            result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
                                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                                Tb_cash_stream cashflow = new Tb_cash_stream();
                                                cashflow.setSd_cash_id(cash_trade_no);
                                                cashflow.setSw_company_id(user.getSw_company_id());
                                                cashflow.setSr_cashflow_remark(orderCash.getSd_ordercash_id());
                                                cashflow.setDc_cashflow_money(dc_deposit_money);
                                                cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
                                                cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                                cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                                cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                                                cashflow.setSr_remarks("\u7528\u6237" + user.getSd_user_id() + "\u4f59\u989d\u63d0\u73b0\u5230\u96f6\u94b1");
                                                result = this.cashStreamDao.createCashStream(cashflow);
                                            } else {
                                                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.wx.error"));
                                            }
                                        }
                                    }
                                    Tb_user n_user = new Tb_user();
                                    if (XcbStringUtils.isNullOrBlank((Object)user.getSi_click())) {
                                        n_user.setSi_click(Integer.valueOf(0));
                                        n_user.setTm_click_time(new Date());
                                        n_user.setSd_user_id(user.getSd_user_id());
                                        this.userDao.updateClick(n_user);
                                    }
                                    isSuccess = true;
                                    continue;
                                }
                                this.log.error("\u8ba2\u5355\u4fee\u6539\u590d\u6838\u5f02\u5e38:" + order.getSd_order_id());
                                continue;
                            }
                            this.log.info("\u8ba2\u5355\u5df2\u9000\u6b3e:" + order.getSd_order_id());
                        }
                        appl.setTm_appl_time(new Date());
                        appl.setSr_appl_person("\u7cfb\u7edf\u5ba1\u6279");
                        appl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                        this.userWithdrawalApplDao.updateUserWithdrawalAppl(appl);
                        if (isSuccess) {
                            this.wxMessageService.sendMessage(appl.getSw_user_id(), null, XcbStringUtils.getObjtoString((Object)appl.getDc_appl_money()), WxMessage.model_tx, null);
                        }
                    } else {
                        Tb_user n_user = new Tb_user();
                        n_user.setSi_click(Integer.valueOf(si_click + 1));
                        n_user.setTm_click_time(new Date());
                        n_user.setSd_user_id(user.getSd_user_id());
                        this.userDao.updateClick(n_user);
                        this.userWithdrawalApplService.refuseAppl(identifier, appl, "\u7cfb\u7edf\u5ba1\u6279\uff0c\u539f\u8def\u9000\u56de");
                    }
                    this.log.info("########################\u7cfb\u7edf\u4efb\u52a1: \u63d0\u73b0\u7533\u8bf7ID:" + appl.getSd_id() + "\uff0c\u5ba1\u6279\u7f51\u70b9: " + netpoint.getSr_net_name() + "\u7ed3\u675f########################");
                    continue;
                }
                this.log.error("\u5f02\u5e38\u63d0\u73b0\u7533\u8bf7\uff0c\u627e\u4e0d\u5230\u63d0\u73b0\u5bf9\u5e94\u7684\u8ba2\u5355\u53f7\uff0c\u63d0\u73b0ID:" + appl.getSd_id() + "\uff0c\u63d0\u73b0\u7528\u6237ID" + appl.getSw_user_id());
            }
        }
        this.log.info("###############\u4efb\u52a1\u9000\u6b3e\u7ed3\u675f###############");
    }

    @Async
    @Scheduled(cron="0 0 0-23 * * ?")
    public void deviceBoxTask() throws Exception {
        this.log.info("###############\u6e05\u7bb1\u5f00\u59cb###############");
        try {
            Date nowDate = new Date();
            this.log.info("##########\u7cfb\u7edf\u65f6\u95f4:" + nowDate + "###########");
            Date afterDate = new Date(nowDate.getTime() + 6000L);
            this.log.info("##########\u5ef6\u8fdf\u7cfb\u7edf\u65f6\u95f4:" + afterDate + "###########");
            List<Tb_device> list = this.deviceDao.findDeviceByTask();
            for (Tb_device device : list) {
                this.deviceService.dealDeviceBoxTask(afterDate, device);
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        this.log.info("###############\u6e05\u7bb1\u7ed3\u675f###############");
    }

    @Async
    @Scheduled(cron="0 0 2 ? * *")
    public void deviceBoxUserTask() throws Exception {
        this.log.info("###############\u6e05\u7a7a\u8d26\u6237 Start###############");
        System.out.println("#########\u6e05\u7a7a\u8d26\u6237 Start##########");
        Identifier identifier = new Identifier();
        try {
            Date nowDate = new Date();
            this.log.info("##########\u7cfb\u7edf\u65f6\u95f4:" + nowDate + "###########");
            Date afterDate = new Date(nowDate.getTime() + 6000L);
            this.log.info("##########\u5ef6\u8fdf\u7cfb\u7edf\u65f6\u95f4:" + afterDate + "###########");
            List<Tb_device> list = this.deviceDao.findDeviceByUserTask();
            for (Tb_device device : list) {
                boolean isExcute = false;
                String sr_user_task_cycle = device.getSr_user_task_cycle();
                String sr_user_task_hour = device.getSr_user_task_hour();
                String nowTime = XcbDateUtil.getHour((Date)afterDate);
                this.log.info("##########\u6e05\u7a7a\u65f6\u95f4:" + nowTime + "###########");
                if (!sr_user_task_hour.equals(nowTime)) continue;
                List<Tb_user_account> userAccountList = this.userAccountDao.findUserTaskUserAccount(device.getSd_device_id(), sr_user_task_cycle);
                System.out.println("\u8bbe\u5907:" + device.getSi_mainboard_id() + ",\u67e5\u8be2\u7ed3\u679c\u6570" + userAccountList.size());
                this.log.info("\u8bbe\u5907:" + device.getSi_mainboard_id() + ",\u67e5\u8be2\u7ed3\u679c\u6570" + userAccountList.size());
                if (userAccountList != null && userAccountList.size() > 0) {
                    System.out.println("#########\u6267\u884c\u4efb\u52a1\u5f00\u59cb##########" + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
                    this.log.info("#########\u6267\u884c\u4efb\u52a1\u5f00\u59cb##########" + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
                    for (Tb_user_account userAccount : userAccountList) {
                        this.userAccountService.dealUserAccountTask(identifier, userAccount);
                    }
                    isExcute = true;
                    this.log.info("#########\u6267\u884c\u4efb\u52a1\u7ed3\u675f##########" + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
                    System.out.println("#########\u6267\u884c\u4efb\u52a1\u7ed3\u675f##########" + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
                }
                if (!isExcute) continue;
                this.deviceDao.updateDeviceUserTaskTime(device.getSd_device_id());
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        System.out.println("#########\u6e05\u7a7a\u8d26\u6237 End##########");
        this.log.info("###############\u6e05\u7a7a\u8d26\u6237\u7ed3\u675f###############");
    }

    @Scheduled(cron="0 0/5 3,4,5 * * ?")
    public void updateUserAccount() throws Exception {
        this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u7528\u6237\u8d26\u6237 START #################");
        boolean result = false;
        String sr_type = "TASK_USER_ACCOUNT";
        String nowDate_str = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd");
        List<Tb_recharge_set> list = this.rechargeSetDao.findTaskRechargeSet(sr_type);
        if (list != null && list.size() > 0) {
            for (Tb_recharge_set rechargeSet : list) {
                rechargeSet.setExcute(false);
                String sw_company_id = rechargeSet.getSw_agent_id();
                int taskDiff = XcbStringUtils.getObjToBigDecimal((Object)rechargeSet.getDc_recharge_money()).intValue();
                int total = rechargeSet.getDc_present_award().intValue();
                try {
                    List<Tb_user_account> userAccountList = this.userAccountDao.findTaskUserAccount(sw_company_id, total);
                    System.out.println("\u67e5\u8be2\u7ed3\u679c\u6570" + userAccountList.size());
                    if (userAccountList == null || userAccountList.size() <= 0) continue;
                    System.out.println("#########\u6267\u884c\u4efb\u52a1\u5f00\u59cb##########");
                    this.log.info("#########\u6267\u884c\u4efb\u52a1\u5f00\u59cb##########");
                    for (Tb_user_account userAccount : userAccountList) {
                        this.userAccountService.dealUserAccountSysTask(taskDiff, userAccount, rechargeSet);
                    }
                    System.out.println("#########\u6267\u884c\u4efb\u52a1\u7ed3\u675f##########" + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
                    this.log.info("#########\u6267\u884c\u4efb\u52a1\u7ed3\u675f##########" + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
                }
                catch (Exception e) {
                    System.out.println(e.getMessage());
                    this.log.error(XcbStringUtils.exceptionToString((Exception)e));
                }
            }
            for (Tb_recharge_set rechargeSet : list) {
                boolean isExcute = rechargeSet.isExcute();
                if (!isExcute) continue;
                Tb_recharge_set n_set = new Tb_recharge_set();
                n_set.setSd_setrecharge_id(rechargeSet.getSd_setrecharge_id());
                n_set.setSw_coupon_id(nowDate_str);
                this.rechargeSetDao.updateRechargeSet(n_set);
            }
        }
        this.log.info("#################\u5b9a\u65f6\u4efb\u52a1\u7528\u6237\u8d26\u6237 END #################");
    }

    @Scheduled(cron="0 0 0 * * ? ")
    public void deleteDeviceLogs() {
        this.log.info("\u5b9a\u65f6\u4efb\u52a1\u5220\u9664\u65e5\u5fd7\uff1astart \u5f00\u59cb\u65f6\u95f4\uff1a" + XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
        String DateTime = "";
        int count = 0;
        try {
            DateTime = XcbDateUtil.getBeforeDay((Date)new Date(), (int)3, (String)"yyyy-MM-dd");
            DateTime = DateTime + " 00:00:00";
            count = this.deviceLogsDao.deleteDeviceLogs(DateTime);
        }
        catch (Exception e) {
            this.log.error("BusinessTask.deleteDeviceLogs\u5b9a\u65f6\u5220\u9664\u65e5\u5fd7\u5931\u8d25" + XcbStringUtils.exceptionToString((Exception)e));
        }
        this.log.info("\u5b9a\u65f6\u4efb\u52a1\u5220\u9664\u65e5\u5fd7\uff1aend count:" + count);
    }

    @Scheduled(cron="0 10 0 1 * ?")
    public void reSetAgentMaxMoney() {
        List<Tb_agent> list = this.agentDao.findBusinessAgent();
        for (Tb_agent agent : list) {
            BigDecimal dc_agent_money = XcbStringUtils.getObjToBigDecimal((Object)agent.getDc_agent_money());
            agent.setDc_max_money(dc_agent_money);
            this.agentDao.updateMaxMoneyById(agent);
        }
    }
}

