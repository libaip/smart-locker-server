/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.GenericCaller
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.context.ApplicationContext
 *  org.springframework.context.support.ClassPathXmlApplicationContext
 */
package com.jcg.user.common;

import com.jcg.common.model.GenericCaller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BaseService {
    ApplicationContext context = new ClassPathXmlApplicationContext("hessianServer-servlet.xml");
    protected GenericCaller genericCaller = (GenericCaller)this.context.getBean("genericCaller");
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
}

