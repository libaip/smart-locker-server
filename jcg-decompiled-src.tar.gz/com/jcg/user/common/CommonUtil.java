/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.user.model.Tb_user
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.authentication.AuthenticationManager
 *  org.springframework.security.authentication.UsernamePasswordAuthenticationToken
 *  org.springframework.security.core.Authentication
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.security.core.userdetails.UserDetails
 *  org.springframework.security.core.userdetails.UserDetailsService
 *  org.springframework.stereotype.Component
 */
package com.jcg.user.common;

import com.jcg.user.model.Tb_user;
import com.jcg.user.security.JwtTokenUtil;
import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

@Component
public class CommonUtil {
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    public String creatToken(String userid, String password) {
        UserDetails userDetails = this.userDetailsService.loadUserByUsername(userid);
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken((Object)userDetails, null, userDetails.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication((Authentication)authentication);
        Tb_user user = (Tb_user)this.userDetailsService.loadUserByUsername(userid);
        Collection authList = user.getAuthorities();
        String token = this.jwtTokenUtil.generateToken((UserDetails)user, authList);
        return token;
    }

    public String creatToken(String userid) {
        UserDetails userDetails = this.userDetailsService.loadUserByUsername(userid);
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken((Object)userDetails, null, userDetails.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication((Authentication)authentication);
        Tb_user user = (Tb_user)this.userDetailsService.loadUserByUsername(userid);
        Collection authList = user.getAuthorities();
        String token = this.jwtTokenUtil.generateToken((UserDetails)user, authList);
        return token;
    }
}

