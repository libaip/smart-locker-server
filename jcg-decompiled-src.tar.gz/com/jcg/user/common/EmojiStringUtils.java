/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.user.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmojiStringUtils {
    public static boolean hasEmoji(String content) {
        Pattern pattern = Pattern.compile("[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]");
        Matcher matcher = pattern.matcher(content);
        return matcher.find();
    }

    public static String replaceEmoji(String str) {
        if (!EmojiStringUtils.hasEmoji(str)) {
            return str;
        }
        str = str.replaceAll("[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]", " ");
        return str;
    }
}

