/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_advice_user
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_advice_user;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.AdviceUserServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/adviceUser"})
public class AdviceUserController
extends BaseController {
    @Autowired
    private AdviceUserServiceImpl adviceUserService;

    @RequestMapping(value={"/findAdviceUserById"})
    @ResponseBody
    public Map<String, Object> findAdviceUserById(HttpServletRequest request, String sw_user_id, Page page) throws Exception {
        Tb_user tb_user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(tb_user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.adviceUserService.findAdviceUserById(identifier, sw_user_id, page);
        return result_map;
    }

    @RequestMapping(value={"/createAdviceUser"})
    @ResponseBody
    public Map<String, Object> createAdviceUser(HttpServletRequest request, Tb_advice_user adviceUser) throws Exception {
        Tb_user tb_user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(tb_user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.adviceUserService.createAdviceUser(identifier, adviceUser);
        return result_map;
    }

    @RequestMapping(value={"/deleteById"})
    @ResponseBody
    public Map<String, Object> deleteById(HttpServletRequest request, String id) throws Exception {
        Tb_user tb_user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(tb_user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.adviceUserService.deleteById(identifier, id);
        return result_map;
    }
}

