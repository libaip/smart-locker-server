/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_customer_app
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_customer_app;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.CustomerAppServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/customerApp"})
public class CustomerAppController
extends BaseController {
    @Autowired
    private CustomerAppServiceImpl customerAppService;

    @RequestMapping(value={"/createCustomerApp"})
    @ResponseBody
    public Map<String, Object> createAdviceUser(HttpServletRequest request, Tb_customer_app customer_app) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        customer_app.setSw_user_id(XcbStringUtils.getObjtoString((Object)user.getSd_user_id()));
        Map<String, Object> result_map = this.customerAppService.createCustomerApp(identifier, customer_app);
        return result_map;
    }
}

