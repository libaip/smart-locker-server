/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.Identifier
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.common.model.Identifier;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.DeviceBoxServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/box"})
public class DeviceBoxController
extends BaseController {
    @Autowired
    private DeviceBoxServiceImpl deviceBoxService;

    @RequestMapping(value={"/findDeviceBoxDefault"})
    @ResponseBody
    public Map<String, Object> findDeviceBoxDefault(HttpServletRequest request, String si_mainboard_id, String sr_box_type) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.deviceBoxService.findDeviceBoxDefault(identifier, si_mainboard_id, sr_box_type);
        return result_map;
    }

    @RequestMapping(value={"/findDeviceBoxByParam"})
    @ResponseBody
    public Map<String, Object> findDeviceBoxByParam(HttpServletRequest request, String si_mainboard_id, String sr_box_type) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.deviceBoxService.findDeviceBoxByParam(identifier, si_mainboard_id, sr_box_type);
        return result_map;
    }

    @RequestMapping(value={"/updateDeviceBox"})
    @ResponseBody
    public Map<String, Object> updateDeviceBox(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.deviceBoxService.updateDeviceBox(identifier, deviceBox);
        return result_map;
    }

    @RequestMapping(value={"/findDeviceBoxById"})
    @ResponseBody
    public Map<String, Object> findDeviceBoxById(HttpServletRequest request, Integer sd_box_id) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.deviceBoxService.findDeviceBoxById(identifier, sd_box_id);
        return result_map;
    }

    @RequestMapping(value={"/cancelDeviceBox"})
    @ResponseBody
    public Map<String, Object> cancelDeviceBox(HttpServletRequest request, Integer sd_box_id) throws Exception {
        this.log.debug("deviceBoxInfo================\u8fdb\u5165\u8bbe\u5907\u683c\u5b50\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.deviceBoxService.cancelDeviceBox(user.getSd_user_id(), sd_box_id);
        return result_map;
    }
}

