/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.Identifier
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.common.model.Identifier;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.DeviceCloudServiceImpl;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/cloud"})
public class DeviceCloudController
extends BaseController {
    @Autowired
    private DeviceCloudServiceImpl deviceCloudService;

    @RequestMapping(value={"/openLock"})
    @ResponseBody
    public Map<String, Object> openLock(HttpServletRequest request, Integer sw_user_id, Tb_device_box deviceBox, String sw_order_id, String sr_type, String sr_remarks) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        result_map = this.deviceCloudService.openLock(identifier, sw_user_id, deviceBox, sw_order_id, sr_type, sr_remarks);
        return result_map;
    }

    @RequestMapping(value={"/checkDeviceStatus"})
    @ResponseBody
    public Map<String, Object> checkDeviceStatus(HttpServletRequest request, Tb_device_box deviceBox) throws Exception {
        this.log.debug("deviceCloud================\u8fdb\u5165\u4e2d\u95f4\u4ef6\u670d\u52a1\u5668\u5e76\u4f20\u5165\u6570\u636e");
        HashMap<String, Object> result_map = new HashMap();
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        result_map = this.deviceCloudService.checkDeviceStatus(identifier, deviceBox);
        return result_map;
    }
}

