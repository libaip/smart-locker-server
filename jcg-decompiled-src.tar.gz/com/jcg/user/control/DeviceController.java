/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.DeviceServiceImpl;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/device"})
public class DeviceController
extends BaseController {
    @Autowired
    private DeviceServiceImpl deviceService;

    @RequestMapping(value={"/findDeviceByMid"})
    @ResponseBody
    public Map<String, Object> findDeviceByMid(HttpServletRequest request, String sw_user_id, String si_mainboard_id, String sw_device_id, String sr_type) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        HashMap<String, Object> result_map = new HashMap<String, String>();
        if (!XcbStringUtils.isNullOrBlank((Object)sw_device_id)) {
            result_map = this.deviceService.findDeviceByMid(identifier, sw_user_id, si_mainboard_id, sw_device_id, sr_type);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u53c2\u6570\u7f3a\u5931");
        }
        return result_map;
    }

    @RequestMapping(value={"/findDeviceByQrCode"})
    @ResponseBody
    public Map<String, Object> findDeviceByQrCode(HttpServletRequest request, String sw_user_id, String sr_wx_qr_code) throws Exception {
        this.log.debug("deviceInfo================\u8fdb\u5165\u8bbe\u5907\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        HashMap<String, Object> result_map = new HashMap<String, String>();
        if (!XcbStringUtils.isNullOrBlank((Object)sr_wx_qr_code)) {
            result_map = this.deviceService.findDeviceByQrCode(identifier, sw_user_id, sr_wx_qr_code);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u53c2\u6570\u7f3a\u5931");
        }
        return result_map;
    }
}

