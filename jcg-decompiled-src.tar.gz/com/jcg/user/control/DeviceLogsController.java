/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_devicelogs
 *  com.jcg.common.model.Identifier
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.agent.model.Tb_devicelogs;
import com.jcg.common.model.Identifier;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.DeviceServiceLogsImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/deviceLogs"})
public class DeviceLogsController
extends BaseController {
    @Autowired
    private DeviceServiceLogsImpl deviceLogsService;

    @RequestMapping(value={"/checkDeviceLogs"})
    @ResponseBody
    public Map<String, Object> checkDeviceLogs(HttpServletRequest request, Tb_devicelogs deviceLogs) throws Exception {
        this.log.debug("deviceLogsInfo================\u8fdb\u5165\u8bbe\u5907\u65e5\u5fd7\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.deviceLogsService.checkDeviceLogs(identifier, deviceLogs);
        return result_map;
    }
}

