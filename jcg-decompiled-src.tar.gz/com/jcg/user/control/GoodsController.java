/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_goods
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_goods;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.GoodsServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/goods"})
public class GoodsController
extends BaseController {
    @Autowired
    private GoodsServiceImpl goodsService;

    @RequestMapping(value={"/findGoodsByParam"})
    @ResponseBody
    public Map<String, Object> findGoodsByParam(HttpServletRequest request, Tb_goods goods, Page page) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.goodsService.findGoodsByParam(identifier, goods, page);
        return result_map;
    }

    @RequestMapping(value={"/findGoodsById"})
    @ResponseBody
    public Map<String, Object> findGoodsById(HttpServletRequest request, Integer sd_id) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.goodsService.findGoodsById(identifier, sd_id);
        return result_map;
    }

    @RequestMapping(value={"/findGoodsByIdArr"})
    @ResponseBody
    public Map<String, Object> findGoodsByIdArr(HttpServletRequest request, Integer[] idArr) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.goodsService.findGoodsByIdArr(identifier, idArr);
        return result_map;
    }

    @RequestMapping(value={"/findAllCates"})
    @ResponseBody
    public Map<String, Object> findAllCates(HttpServletRequest request) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = this.goodsService.findAllCates(identifier);
        return result_map;
    }

    @RequestMapping(value={"/findGoodsCart"})
    @ResponseBody
    public Map<String, Object> findGoodsCart(HttpServletRequest request, Tb_goods goods, Page page) throws Exception {
        this.log.debug("goodsInfo================\u8fdb\u5165\u5546\u54c1\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.goodsService.findGoodsCart(identifier, goods, page);
        return result_map;
    }

    @RequestMapping(value={"/updateGoodsCart"})
    @ResponseBody
    public Map<String, Object> updateGoodsCart(HttpServletRequest request, Tb_goods goods) throws Exception {
        this.log.debug("goodsInfo================\u8fdb\u5165\u5546\u54c1\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.goodsService.updateGoodsCart(identifier, goods);
        return result_map;
    }

    @RequestMapping(value={"/removeGoodsCart"})
    @ResponseBody
    public Map<String, Object> removeGoodsCart(HttpServletRequest request, Tb_goods goods) throws Exception {
        this.log.debug("goodsInfo================\u8fdb\u5165\u5546\u54c1\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.goodsService.removeGoodsCart(identifier, goods);
        return result_map;
    }

    @RequestMapping(value={"/removeAllGoodsCart"})
    @ResponseBody
    public Map<String, Object> removeAllGoodsCart(HttpServletRequest request, Tb_goods goods) throws Exception {
        this.log.debug("goodsInfo================\u8fdb\u5165\u5546\u54c1\u4fe1\u606f\u9875\u9762\u5e76\u4f20\u5165\u6570\u636e");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.goodsService.removeAllGoodsCart(identifier, goods);
        return result_map;
    }
}

