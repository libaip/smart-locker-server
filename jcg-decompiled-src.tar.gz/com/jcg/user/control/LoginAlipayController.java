/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alipay.api.response.AlipaySystemOauthTokenResponse
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  net.sf.json.JSONObject
 *  org.apache.commons.lang3.StringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RequestMethod
 *  org.springframework.web.bind.annotation.ResponseBody
 *  org.springframework.web.bind.annotation.RestController
 */
package com.jcg.user.control;

import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.user.common.BaseController;
import com.jcg.user.common.CommonUtil;
import com.jcg.user.common.PromptProperties;
import com.jcg.user.model.Tb_user;
import com.jcg.user.redis.RedisUtil;
import com.jcg.user.service.UserServiceImpl;
import com.jcg.user.vo.LoginUser;
import com.jcg.user.zf.zfb.ZFBzfCommon;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value={"/authZfb"}, method={RequestMethod.POST})
public class LoginAlipayController
extends BaseController {
    @Autowired
    private CommonUtil commonUtil;
    @Autowired
    private UserServiceImpl userService;
    @Autowired
    private ZFBzfCommon zfbzfCommon;
    @Autowired
    private RedisUtil redis;

    @RequestMapping(value={"/autologin"}, method={RequestMethod.POST})
    public Map<String, Object> autologin(LoginUser loginUser, HttpServletRequest request) throws Exception {
        this.log.info("in autologin...start");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Tb_user user = new Tb_user();
        String msg = null;
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        if (!StringUtils.isNotBlank((CharSequence)loginUser.getCode())) {
            ret.put(XcbConstantValue.STATUS, 202);
            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            return ret;
        }
        this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
        AlipaySystemOauthTokenResponse response = this.zfbzfCommon.getAccessToken(identifier, loginUser);
        this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
        if (response.isSuccess()) {
            String accessToken = response.getAccessToken();
            String sr_open_id = response.getUserId();
            if (!XcbStringUtils.isNullOrBlank((Object)sr_open_id)) {
                user.setSr_zfb_open_id(sr_open_id);
                user.setSw_company_id(loginUser.getSw_company_id());
                Map<String, Object> resMp = this.userService.loginWithZfbOpenId(identifier, user);
                int result = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    if (resMp.get(XcbConstantValue.DATA) == null) {
                        msg = PromptProperties.getProperty("user.find.isNotExist");
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, msg);
                        return ret;
                    }
                } else {
                    msg = XcbStringUtils.getObjtoString((Object)resMp.get(XcbConstantValue.MSG));
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    return ret;
                }
                user = (Tb_user)resMp.get(XcbConstantValue.DATA);
                msg = PromptProperties.getProperty("user.auto.login.success");
                StringBuffer sb = new StringBuffer();
                sb.append(user.getUsername()).append(",").append(loginUser.getSw_company_id());
                String primarykey = sb.toString();
                String token = this.commonUtil.creatToken(XcbStringUtils.getObjtoString((Object)user.getSd_user_id()));
                dataMap.put("token", token);
                dataMap.put("userid", user.getSd_user_id());
                dataMap.put("nickname", user.getSr_user_zfb_petname());
                dataMap.put("username", user.getSr_user_name());
                dataMap.put("avatar", user.getSr_zfb_avatar_url());
                dataMap.put("sex", user.getSr_sex());
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, msg);
                ret.put(XcbConstantValue.DATA, dataMap);
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            }
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, "\u7528\u6237\u51ed\u8bc1\u83b7\u53d6\u5931\u8d25");
        }
        this.log.info("in login...end");
        return ret;
    }

    @RequestMapping(value={"/speedLogin"}, method={RequestMethod.POST})
    public Map<String, Object> speedLogin(LoginUser loginUser, HttpServletRequest request) throws Exception {
        this.log.info("in login...start");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Tb_user user = new Tb_user();
        String msg = null;
        Map<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        String mid = XcbStringUtils.getObjtoString((Object)request.getParameter("mid"));
        String deviceid = XcbStringUtils.getObjtoString((Object)request.getParameter("deviceid"));
        if (!StringUtils.isNotBlank((CharSequence)loginUser.getCode())) {
            ret.put(XcbConstantValue.STATUS, 202);
            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            return ret;
        }
        this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
        AlipaySystemOauthTokenResponse response = this.zfbzfCommon.getAccessToken(identifier, loginUser);
        this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
        if (response.isSuccess()) {
            String accessToken = response.getAccessToken();
            String sr_open_id = response.getUserId();
            if (!XcbStringUtils.isNullOrBlank((Object)sr_open_id)) {
                loginUser.setSr_zfb_open_id(sr_open_id);
                String content = loginUser.getEncryptedData();
                String jsonBack = this.zfbzfCommon.decryptPhoneNum(identifier, content, loginUser.getSw_company_id());
                JSONObject json = JSONObject.fromObject((Object)jsonBack);
                if ("10000".equals(json.get("code"))) {
                    String sr_user_name = XcbStringUtils.getObjtoString((Object)json.get("mobile"));
                    loginUser.setUsername(sr_user_name);
                    loginUser.setSr_zfb_open_id(sr_open_id);
                    Map<String, Object> resMp = this.checkUser(identifier, loginUser);
                    int result = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        boolean isRegister = (Boolean)resMp.get("isRegister");
                        if (isRegister) {
                            user = (Tb_user)resMp.get("user");
                            if (XcbStringUtils.isNullOrBlank((Object)user.getSr_zfb_open_id())) {
                                Tb_user newUser = new Tb_user();
                                newUser.setSd_user_id(user.getSd_user_id());
                                newUser.setSr_zfb_open_id(sr_open_id);
                                newUser.setTm_last_login_time(new Date());
                                resMp = this.userService.updateZfbUserById(identifier, newUser);
                                result = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
                                if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                                    msg = PromptProperties.getProperty("system.fail");
                                }
                            }
                        } else {
                            result = this.createUser(identifier, loginUser, mid, deviceid);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                user = this.Speedlogin(loginUser);
                            }
                        }
                        StringBuffer sb = new StringBuffer();
                        sb.append(user.getUsername()).append(",").append(loginUser.getSw_company_id());
                        String primarykey = sb.toString();
                        String token = this.commonUtil.creatToken(XcbStringUtils.getObjtoString((Object)user.getSd_user_id()));
                        msg = PromptProperties.getProperty("user.login.success");
                        dataMap.put("token", token);
                        dataMap.put("userid", user.getSd_user_id());
                        dataMap.put("nickname", user.getSr_user_zfb_petname());
                        dataMap.put("username", user.getSr_user_name());
                        dataMap.put("avatar", user.getSr_zfb_avatar_url());
                        dataMap.put("sex", user.getSr_sex());
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret.put(XcbConstantValue.MSG, msg);
                        ret.put(XcbConstantValue.DATA, dataMap);
                    } else {
                        ret = resMp;
                    }
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.login.getphone.fail"));
                }
            }
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, "\u7528\u6237\u51ed\u8bc1\u83b7\u53d6\u5931\u8d25");
        }
        return ret;
    }

    private Tb_user Speedlogin(LoginUser loginUser) throws Exception {
        Tb_user user = new Tb_user();
        HashMap<String, Object> params = new HashMap<String, Object>();
        params.put("sr_user_name", loginUser.getUsername());
        params.put("sw_company_id", loginUser.getSw_company_id());
        Map<String, Object> returnMap = this.userService.findUserByUsername(params);
        if (returnMap.get("user") != null) {
            user = (Tb_user)returnMap.get("user");
        }
        return user;
    }

    private int createUser(Identifier identifier, LoginUser loginUser, String mid, String deviceid) {
        Tb_user user = new Tb_user();
        user.setSr_zfb_open_id(loginUser.getSr_zfb_open_id());
        user.setSr_user_name(loginUser.getUsername());
        user.setSw_company_id(loginUser.getSw_company_id());
        user.setTm_create_time(new Date());
        user.setSr_user_status(XcbConstantValue.USER_YJH);
        user.setSr_user_zfb_petname(loginUser.getUsername());
        user.setSr_user_source(XcbConstantValue.USER_SOURCE_ZFB);
        user.setTm_register_time(new Date());
        Map<String, Object> ret = this.userService.createUser(identifier, user, mid, deviceid);
        int result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
        return result;
    }

    private Map<String, Object> checkUser(Identifier identifier, LoginUser loginUser) throws Exception {
        HashMap<String, Object> ret = new HashMap();
        Tb_user user = new Tb_user();
        user.setSw_company_id(loginUser.getSw_company_id());
        user.setSr_user_name(loginUser.getUsername());
        user.setSr_zfb_open_id(loginUser.getSr_zfb_open_id());
        ret = this.userService.checkUser(identifier, user);
        return ret;
    }

    @RequestMapping(value={"/loginout"}, method={RequestMethod.POST})
    @ResponseBody
    public Map<String, Object> loginout(LoginUser loginUser, HttpServletRequest request) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        String msg = "";
        boolean isSuccess = false;
        if (!StringUtils.isNotBlank((CharSequence)loginUser.getCode())) {
            ret.put(XcbConstantValue.STATUS, 202);
            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            return ret;
        }
        this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
        AlipaySystemOauthTokenResponse response = this.zfbzfCommon.getAccessToken(identifier, loginUser);
        this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
        if (response.isSuccess()) {
            String accessToken = response.getAccessToken();
            String sr_open_id = response.getUserId();
            if (!XcbStringUtils.isNullOrBlank((Object)sr_open_id)) {
                user.setSr_zfb_open_id(sr_open_id);
                user.setSw_company_id(loginUser.getSw_company_id());
                Map<String, Object> resMp = this.userService.loginWithZfbOpenId(identifier, user);
                int result = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    user = (Tb_user)resMp.get(XcbConstantValue.DATA);
                    Tb_user newUser = new Tb_user();
                    newUser.setSd_user_id(user.getSd_user_id());
                    newUser.setSr_zfb_open_id("");
                    resMp = this.userService.updateZfbUserById(identifier, newUser);
                    result = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        this.redis.delete("userCache_" + user.getSr_zfb_open_id() + "_" + user.getSw_company_id());
                        this.redis.delete("userCache_" + user.getSd_user_id());
                        isSuccess = true;
                        msg = PromptProperties.getProperty("user.loginout.success");
                    } else {
                        msg = PromptProperties.getProperty("system.fail");
                    }
                } else {
                    msg = PromptProperties.getProperty("system.fail");
                }
            } else {
                msg = PromptProperties.getProperty("user.auto.login.error");
            }
            if (isSuccess) {
                ret.put(XcbConstantValue.MSG, msg);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, msg);
            }
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, "\u7528\u6237\u51ed\u8bc1\u83b7\u53d6\u5931\u8d25");
        }
        return ret;
    }
}

