/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  net.sf.json.JSONObject
 *  org.apache.commons.lang3.StringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RequestMethod
 *  org.springframework.web.bind.annotation.ResponseBody
 *  org.springframework.web.bind.annotation.RestController
 */
package com.jcg.user.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.user.common.BaseController;
import com.jcg.user.common.CommonUtil;
import com.jcg.user.common.PromptProperties;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.SysParamServiceImpl;
import com.jcg.user.service.UserServiceImpl;
import com.jcg.user.vo.LoginUser;
import com.jcg.user.zf.wx.WXzfCommon;
import com.jcg.user.zf.wx.WechatDecryptDataUtil;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value={"/auth"}, method={RequestMethod.POST})
public class LoginController
extends BaseController {
    @Autowired
    private CommonUtil commonUtil;
    @Autowired
    private UserServiceImpl userService;
    @Autowired
    private WXzfCommon wxzfCommon;
    @Autowired
    private SysParamServiceImpl sysParamService;

    @RequestMapping(value={"/autologin"}, method={RequestMethod.POST})
    public Map<String, Object> autologin(LoginUser loginUser, HttpServletRequest request) throws Exception {
        this.log.info("in autologin...start");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Tb_user user = new Tb_user();
        String msg = null;
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        if (!StringUtils.isNotBlank((CharSequence)loginUser.getCode())) {
            ret.put(XcbConstantValue.STATUS, 202);
            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            return ret;
        }
        if (XcbStringUtils.isNullOrBlank((Object)loginUser.getSr_way())) {
            loginUser.setSr_way(XcbConstantValue.LOGIN_WAY);
        }
        Tb_wx_info wx_info = this.sysParamService.findWxInfoByCode(identifier, loginUser.getSr_way());
        this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
        String wx_param = this.wxzfCommon.getOpenId(identifier, loginUser);
        this.log.info("\u81ea\u52a8\u767b\u5f55" + wx_param);
        if (XcbStringUtils.isNullOrBlank((Object)wx_param)) {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, "\u6388\u6743\u5f02\u5e38");
            return ret;
        }
        JSONObject jb = JSONObject.fromObject((Object)wx_param);
        String sr_open_id = jb.getString("openid");
        this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
        if (!XcbStringUtils.isNullOrBlank((Object)sr_open_id)) {
            Map<Object, Object> resMp = new HashMap();
            if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type()) || XcbConstantValue.WX_INFO_MODE_4.equals(wx_info.getSr_type())) {
                String unionid = jb.getString("unionid");
                user.setSr_unionid(unionid);
                user.setSw_company_id(loginUser.getSw_company_id());
                user.setSr_app_open_id(sr_open_id);
                user.setSr_way(loginUser.getSr_way());
                user.setSr_info_type(wx_info.getSr_type());
                resMp = this.userService.loginWithUnionId(identifier, user);
            } else {
                user.setSw_company_id(loginUser.getSw_company_id());
                user.setSr_app_open_id(sr_open_id);
                user.setSr_way(loginUser.getSr_way());
                resMp = this.userService.loginWithAppOpenId(identifier, user);
            }
            int result = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                user = (Tb_user)resMp.get(XcbConstantValue.DATA);
            } else {
                user.setSr_user_petname("\u5fae\u4fe1\u7528\u6237");
                user.setSr_register_device(loginUser.getDeviceid());
                result = this.createUser(new Identifier(), user);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    user = this.Speedlogin(user, wx_info);
                }
            }
            if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                msg = PromptProperties.getProperty("user.find.isNotExist");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, msg);
                return ret;
            }
            msg = PromptProperties.getProperty("user.auto.login.success");
            String token = this.commonUtil.creatToken(XcbStringUtils.getObjtoString((Object)user.getSd_user_id()));
            dataMap.put("token", token);
            dataMap.put("userid", user.getSd_user_id());
            dataMap.put("app_openid", user.getSr_app_open_id());
            dataMap.put("check_scan", user.getSr_is_scan());
            dataMap.put("openid", user.getSr_open_id());
            dataMap.put("nickname", user.getSr_user_petname());
            dataMap.put("username", user.getSr_user_name());
            dataMap.put("avatar", user.getSr_wx_avatar_url());
            dataMap.put("sex", user.getSr_sex());
            dataMap.put("user_way", user.getSr_way());
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, msg);
            ret.put(XcbConstantValue.DATA, dataMap);
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
        }
        this.log.info("in login...end");
        return ret;
    }

    @RequestMapping(value={"/speedLogin"}, method={RequestMethod.POST})
    public Map<String, Object> speedLogin(LoginUser loginUser, HttpServletRequest request) throws Exception {
        this.log.info("in login...start");
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Tb_user user = new Tb_user();
        String msg = null;
        Map<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        String sr_way = loginUser.getSr_way();
        if (XcbStringUtils.isNullOrBlank((Object)sr_way)) {
            sr_way = XcbConstantValue.LOGIN_WAY;
            loginUser.setSr_way(sr_way);
        }
        Tb_wx_info wx_info = this.sysParamService.findWxInfoByCode(identifier, loginUser.getSr_way());
        String mid = XcbStringUtils.getObjtoString((Object)request.getParameter("mid"));
        String deviceid = XcbStringUtils.getObjtoString((Object)request.getParameter("deviceid"));
        if (!StringUtils.isNotBlank((CharSequence)loginUser.getCode())) {
            ret.put(XcbConstantValue.STATUS, 202);
            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            return ret;
        }
        this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
        String wx_param = this.wxzfCommon.getOpenId(identifier, loginUser);
        this.log.info("\u6388\u6743\u767b\u5f55" + wx_param);
        if (XcbStringUtils.isNullOrBlank((Object)wx_param)) {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, "\u6388\u6743\u5f02\u5e38");
            return ret;
        }
        JSONObject jb = JSONObject.fromObject((Object)wx_param);
        String sr_open_id = jb.getString("openid");
        String session_key = jb.getString("session_key");
        if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type()) || XcbConstantValue.WX_INFO_MODE_4.equals(wx_info.getSr_type())) {
            String unionid = jb.getString("unionid");
            loginUser.setSr_unionid(unionid);
            user.setSr_unionid(unionid);
        }
        loginUser.setSession_key(session_key);
        loginUser.setSr_open_id(sr_open_id);
        user.setSw_company_id(XcbConstantValue.companyid);
        user.setSr_app_open_id(sr_open_id);
        user.setSr_way(loginUser.getSr_way());
        this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
        if (!XcbStringUtils.isNullOrBlank((Object)sr_open_id)) {
            URLEncoder.encode(loginUser.getIv(), "UTF-8").replace("%3D", "=").replace("%2F", "/");
            String wxParam = WechatDecryptDataUtil.decryptData(loginUser.getEncryptedData(), loginUser.getSession_key(), loginUser.getIv());
            JSONObject wxMaps = JSONObject.fromObject((Object)wxParam);
            String code = XcbStringUtils.getObjtoString(wxMaps.get("code"));
            if (code.equals(XcbConstantValue.WX_RETURN_CODE)) {
                String userData = XcbStringUtils.getObjtoString(wxMaps.get("userInfo"));
                JSONObject userDataMaps = JSONObject.fromObject((Object)userData);
                String sr_user_name = XcbStringUtils.getObjtoString(userDataMaps.get("phoneNumber"));
                loginUser.setUsername(sr_user_name);
                Map<String, Object> resMp = this.checkUser(identifier, loginUser);
                int result = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    boolean isRegister = (Boolean)resMp.get("isRegister");
                    if (isRegister) {
                        user = (Tb_user)resMp.get("user");
                    } else {
                        user.setSr_user_petname("\u5fae\u4fe1\u7528\u6237");
                        user.setSr_user_name(sr_user_name);
                        result = this.createUser(identifier, user);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            user = this.Speedlogin(user, wx_info);
                        }
                    }
                    String token = this.commonUtil.creatToken(XcbStringUtils.getObjtoString((Object)user.getSd_user_id()));
                    msg = PromptProperties.getProperty("user.login.success");
                    dataMap.put("token", token);
                    dataMap.put("app_openid", user.getSr_app_open_id());
                    dataMap.put("openid", user.getSr_open_id());
                    dataMap.put("check_scan", user.getSr_is_scan());
                    dataMap.put("userid", user.getSd_user_id());
                    dataMap.put("nickname", user.getSr_user_petname());
                    dataMap.put("username", user.getSr_user_name());
                    dataMap.put("avatar", user.getSr_wx_avatar_url());
                    dataMap.put("sex", user.getSr_sex());
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.MSG, msg);
                    ret.put(XcbConstantValue.DATA, dataMap);
                } else {
                    ret = resMp;
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.login.getphone.fail"));
            }
        }
        return ret;
    }

    private Tb_user Speedlogin(Tb_user user, Tb_wx_info wx_info) throws Exception {
        Map<Object, Object> ret = new HashMap();
        Identifier identifier = new Identifier();
        ret = XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type()) ? this.userService.loginWithUnionId(identifier, user) : this.userService.loginWithAppOpenId(identifier, user);
        if (ret.get(XcbConstantValue.DATA) != null) {
            user = (Tb_user)ret.get(XcbConstantValue.DATA);
        }
        return user;
    }

    private int createUser(Identifier identifier, Tb_user user) {
        Map<Object, Object> ret = new HashMap();
        user.setTm_create_time(new Date());
        user.setSr_user_status(XcbConstantValue.USER_YJH);
        user.setSr_user_source(XcbConstantValue.USER_SOURCE_WX);
        user.setTm_register_time(new Date());
        user.setTm_modify_time(new Date());
        ret = this.userService.createWxUser(identifier, user);
        int result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
        return result;
    }

    private Map<String, Object> checkUser(Identifier identifier, LoginUser loginUser) throws Exception {
        HashMap<String, Object> ret = new HashMap();
        Tb_user user = new Tb_user();
        user.setSw_company_id(loginUser.getSw_company_id());
        user.setSr_user_name(loginUser.getUsername());
        user.setSr_unionid(loginUser.getSr_unionid());
        user.setSr_app_open_id(loginUser.getSr_open_id());
        user.setSr_way(loginUser.getSr_way());
        ret = this.userService.checkWxUser(identifier, user);
        return ret;
    }

    @RequestMapping(value={"/loginout"}, method={RequestMethod.POST})
    @ResponseBody
    public Map<String, Object> loginout(LoginUser loginUser, HttpServletRequest request) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        String msg = "";
        boolean isSuccess = false;
        if (!StringUtils.isNotBlank((CharSequence)loginUser.getCode())) {
            ret.put(XcbConstantValue.STATUS, 202);
            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            return ret;
        }
        this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
        String wx_param = this.wxzfCommon.getOpenId(identifier, loginUser);
        JSONObject jb = JSONObject.fromObject((Object)wx_param);
        String openid = jb.getString("openid");
        this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
        if (!XcbStringUtils.isNullOrBlank((Object)openid)) {
            user.setSr_open_id(openid);
            user.setSw_company_id(loginUser.getSw_company_id());
            Map<String, Object> resMp = this.userService.loginWithOpenId(identifier, user);
            int result = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                user = (Tb_user)resMp.get(XcbConstantValue.DATA);
                Tb_user newUser = new Tb_user();
                newUser.setSd_user_id(user.getSd_user_id());
                newUser.setSr_open_id("");
                resMp = this.userService.updateUserById(identifier, newUser);
                result = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    isSuccess = true;
                    msg = PromptProperties.getProperty("user.loginout.success");
                } else {
                    msg = PromptProperties.getProperty("system.fail");
                }
            } else {
                msg = PromptProperties.getProperty("system.fail");
            }
        } else {
            msg = PromptProperties.getProperty("user.auto.login.error");
        }
        if (isSuccess) {
            ret.put(XcbConstantValue.MSG, msg);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, msg);
        }
        return ret;
    }
}

