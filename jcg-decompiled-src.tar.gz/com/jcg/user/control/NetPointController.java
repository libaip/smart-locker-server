/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.common.model.Identifier;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.NetPointServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/netpoint"})
public class NetPointController
extends BaseController {
    @Autowired
    private NetPointServiceImpl netpointService;

    @RequestMapping(value={"/findNetPointByMid"})
    @ResponseBody
    public Map<String, Object> findNetPointByMid(HttpServletRequest request, String si_mainboard_id) throws Exception {
        this.log.debug("NetpointInfo================\u6839\u636e\u4ee3\u7406\u5546id\u67e5\u8be2\u53ef\u6d88\u8d39\u7f51\u70b9");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.netpointService.findNetPointByMid(identifier, si_mainboard_id);
        return result_map;
    }

    @RequestMapping(value={"/findNetInfoByMid"})
    @ResponseBody
    public Map<String, Object> findNetInfoByMid(HttpServletRequest request, String si_mainboard_id) throws Exception {
        this.log.debug("NetpointInfo================\u6839\u636e\u4ee3\u7406\u5546id\u67e5\u8be2\u53ef\u6d88\u8d39\u7f51\u70b9");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.netpointService.findNetInfoByMid(identifier, si_mainboard_id);
        return result_map;
    }
}

