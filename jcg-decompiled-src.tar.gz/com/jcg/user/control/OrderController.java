/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.user.model.Tb_user
 *  com.jcg.user.model.Tb_user_account
 *  javax.servlet.http.HttpServletRequest
 *  net.sf.json.JSONObject
 *  org.apache.commons.lang3.StringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.common.BaseController;
import com.jcg.user.common.PromptProperties;
import com.jcg.user.model.Tb_user;
import com.jcg.user.model.Tb_user_account;
import com.jcg.user.redis.RedisUtil;
import com.jcg.user.service.DeviceBoxServiceImpl;
import com.jcg.user.service.DeviceCloudServiceImpl;
import com.jcg.user.service.OrderServiceImpl;
import com.jcg.user.service.SysParamServiceImpl;
import com.jcg.user.service.UserAccountServiceImpl;
import com.jcg.user.vo.LoginUser;
import com.jcg.user.zf.wx.WXzfCommon;
import com.jcg.user.zf.wx.WxAPIV3Common;
import com.jcg.user.zf.zfb.ZFBzfCommon;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/order"})
public class OrderController
extends BaseController {
    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private UserAccountServiceImpl userAccountService;
    @Autowired
    private DeviceBoxServiceImpl deviceBoxService;
    @Autowired
    private DeviceCloudServiceImpl deviceCloudService;
    @Autowired
    private WxAPIV3Common wxAPIV3Common;
    @Autowired
    private WXzfCommon wxzfCommon;
    @Autowired
    private SysParamServiceImpl sysParamService;
    @Autowired
    private ZFBzfCommon zfbzfCommon;
    @Autowired
    private RedisUtil redis;

    @RequestMapping(value={"/zhPayEvent"})
    @ResponseBody
    public Map<String, Object> zhPayEvent(HttpServletRequest request, Tb_order order, Integer sd_id) throws Exception {
        this.log.debug("OrderInfo================\u8d26\u6237\u4f59\u989d\u652f\u4ed8");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> result_map = new HashMap<String, Object>();
        Map dataMap = new HashMap();
        int result = 0;
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Integer sw_box_id = order.getSw_box_id();
        Map<String, Object> resMap = this.deviceBoxService.findDeviceBoxById(identifier, sw_box_id);
        result = XcbStringUtils.getObjtoint((Object)resMap.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            dataMap = (Map)resMap.get(XcbConstantValue.DATA);
            Tb_device_box deviceBox = (Tb_device_box)dataMap.get("deviceBox");
            if (deviceBox != null && "KY".equals(deviceBox.getSr_box_status())) {
                if (!XcbConstantValue.USER_YJH.equals(user.getSr_user_status())) {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                    result_map.put(XcbConstantValue.MSG, "\u60a8\u7684\u8d26\u6237\u5f02\u5e38\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
                    return result_map;
                }
                String userid = XcbStringUtils.getObjtoString((Object)this.redis.get(XcbConstantValue.DEVICE_BOX_CACHE + sw_box_id));
                if (XcbStringUtils.isNullOrBlank((Object)userid)) {
                    this.redis.setForTimeMIN(XcbConstantValue.DEVICE_BOX_CACHE + sw_box_id, XcbStringUtils.getObjtoString((Object)user.getSd_user_id()), 3L);
                } else if (!userid.equals(XcbStringUtils.getObjtoString((Object)user.getSd_user_id()))) {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                    result_map.put(XcbConstantValue.MSG, "\u67dc\u95e8\u5df2\u88ab\u9501\u5b9a");
                    return result_map;
                }
                result_map = this.orderService.zhPayEvent(identifier, order, sd_id);
                this.deviceBoxService.cancelDeviceBox(user.getSd_user_id(), sw_box_id);
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                result_map.put(XcbConstantValue.MSG, "\u67dc\u95e8\u5df2\u88ab\u5360\u7528");
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
            result_map.put(XcbConstantValue.MSG, "\u8bbe\u5907\u6570\u636e\u5f02\u5e38\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
        }
        return result_map;
    }

    @RequestMapping(value={"/findOrderByParam"})
    @ResponseBody
    public Map<String, Object> findOrderByParam(HttpServletRequest request, Tb_order order, Page page) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u5217\u8868");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.orderService.findOrderByParam(identifier, order, page);
        return result_map;
    }

    @RequestMapping(value={"/findOrderByUser"})
    @ResponseBody
    public Map<String, Object> findOrderByUser(HttpServletRequest request, Tb_order order) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u5217\u8868");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.orderService.findOrderByUser(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/findOrderByLast"})
    @ResponseBody
    public Map<String, Object> findOrderByLast(HttpServletRequest request, Tb_order order, String type) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u5217\u8868");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.orderService.findOrderByLast(identifier, order, type);
        return result_map;
    }

    @RequestMapping(value={"/findOrderById"})
    @ResponseBody
    public Map<String, Object> findOrderById(HttpServletRequest request, String sd_order_id) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.orderService.findOrderById(identifier, sd_order_id);
        return result_map;
    }

    @RequestMapping(value={"/closeOrder"})
    @ResponseBody
    public Map<String, Object> closeOrder(HttpServletRequest request, String sd_order_id) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Map<String, Object> result_map = new HashMap<String, Object>();
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        String order_redis = XcbStringUtils.getObjtoString((Object)this.redis.get(sd_order_id));
        if (XcbStringUtils.isNullOrBlank((Object)order_redis)) {
            this.redis.setForTimeMS(sd_order_id, XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"), 10000L);
            result_map = this.orderService.closeOrder(identifier, sd_order_id);
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u8bf7\u52ff\u91cd\u590d\u64cd\u4f5c");
        }
        return result_map;
    }

    @RequestMapping(value={"/temporaryOrder"})
    @ResponseBody
    public Map<String, Object> temporaryOrder(HttpServletRequest request, String sd_order_id) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Map<String, Object> result_map = new HashMap<String, Object>();
        Map dataMap = new HashMap();
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        String code = request.getParameter("code");
        String sw_company_id = request.getParameter("sw_company_id");
        String sr_way = request.getParameter("sr_way");
        if (!StringUtils.isNotBlank((CharSequence)code)) {
            result_map.put(XcbConstantValue.STATUS, 202);
            result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            return result_map;
        }
        this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
        LoginUser loginUser = new LoginUser();
        loginUser.setCode(code);
        loginUser.setSw_company_id(sw_company_id);
        loginUser.setSr_way(sr_way);
        String openId_str = this.wxzfCommon.getOpenId(identifier, loginUser);
        JSONObject jsonObj = JSONObject.fromObject((Object)openId_str);
        String sr_open_id = jsonObj.getString("openid");
        this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
        this.log.info("----------------------------\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355 start--------------------------");
        Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, sr_way);
        Tb_wx_pay_info pay_info = info.getPay_info();
        String cus_ip = WXzfCommon.getIpAdrress(request);
        Tb_user_account userAccount = new Tb_user_account();
        userAccount.setSw_user_id(user.getSd_user_id());
        result_map = this.userAccountService.findUserAccountByUser(identifier, userAccount);
        int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            dataMap = (Map)result_map.get(XcbConstantValue.DATA);
            userAccount = (Tb_user_account)dataMap.get("userAccount");
            result_map = this.orderService.findOrderById(identifier, sd_order_id);
            result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                dataMap = (Map)result_map.get(XcbConstantValue.DATA);
                Tb_order order = (Tb_order)dataMap.get("order");
                if (XcbConstantValue.ORDER_YWC.equals(order.getSr_order_status())) {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                    result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.isfinish"));
                    return result_map;
                }
                if ("Y".equals(order.getSr_is_overtime())) {
                    if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_iphone_num())) {
                        result_map = this.deviceBoxService.findDeviceBoxById(identifier, order.getSw_box_id());
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            dataMap = (Map)result_map.get(XcbConstantValue.DATA);
                            Tb_device_box deviceBox = (Tb_device_box)dataMap.get("deviceBox");
                            result_map = this.deviceCloudService.openLock(identifier, order.getSw_user_id(), deviceBox, order.getSd_order_id(), XcbConstantValue.OPEN_DOOR_TYPE_KMCG, "");
                        }
                    } else {
                        BigDecimal totalMoney = BigDecimalUtil.sub((BigDecimal)order.getDc_order_money(), (BigDecimal)order.getDc_actual_income());
                        if (userAccount.getDc_account_money_sum().compareTo(totalMoney) >= 0) {
                            result_map = this.orderService.temporaryOrderForAccount(identifier, order, totalMoney);
                        } else {
                            int total = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)totalMoney)));
                            result_map = this.wxAPIV3Common.temporaryOrder(order, total, sr_open_id, pay_info, cus_ip);
                            result_map.put(XcbConstantValue.STATUS, "2");
                        }
                    }
                } else {
                    result_map = this.deviceBoxService.findDeviceBoxById(identifier, order.getSw_box_id());
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        dataMap = (Map)result_map.get(XcbConstantValue.DATA);
                        Tb_device_box deviceBox = (Tb_device_box)dataMap.get("deviceBox");
                        result_map = this.deviceCloudService.openLock(identifier, order.getSw_user_id(), deviceBox, order.getSd_order_id(), XcbConstantValue.OPEN_DOOR_TYPE_KMCG, "");
                    }
                }
            }
        }
        return result_map;
    }

    @RequestMapping(value={"/finishOrder"})
    @ResponseBody
    public Map<String, Object> finishOrder(HttpServletRequest request, String sd_order_id) throws Exception {
        this.log.debug("OrderInfo================\u67e5\u8be2\u8ba2\u5355\u4fe1\u606f");
        Map<String, Object> result_map = new HashMap<String, Object>();
        Map dataMap = new HashMap();
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        String code = request.getParameter("code");
        String sw_company_id = request.getParameter("sw_company_id");
        String sr_way = request.getParameter("sr_way");
        String order_redis = XcbStringUtils.getObjtoString((Object)this.redis.get(sd_order_id));
        if (XcbStringUtils.isNullOrBlank((Object)order_redis)) {
            this.redis.setForTimeMS(sd_order_id, XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"), 10000L);
            if (!StringUtils.isNotBlank((CharSequence)code)) {
                result_map.put(XcbConstantValue.STATUS, 202);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
                return result_map;
            }
            this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
            LoginUser loginUser = new LoginUser();
            loginUser.setCode(code);
            loginUser.setSw_company_id(sw_company_id);
            loginUser.setSr_way(sr_way);
            String openId_str = this.wxzfCommon.getOpenId(identifier, loginUser);
            JSONObject jsonObj = JSONObject.fromObject((Object)openId_str);
            String sr_open_id = jsonObj.getString("openid");
            this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
            this.log.info("----------------------------\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355 start--------------------------");
            Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, sr_way);
            Tb_wx_pay_info pay_info = info.getPay_info();
            String cus_ip = WXzfCommon.getIpAdrress(request);
            Tb_device_box deviceBox = new Tb_device_box();
            Tb_user_account userAccount = new Tb_user_account();
            userAccount.setSw_user_id(user.getSd_user_id());
            result_map = this.userAccountService.findUserAccountByUser(identifier, userAccount);
            int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                dataMap = (Map)result_map.get(XcbConstantValue.DATA);
                userAccount = (Tb_user_account)dataMap.get("userAccount");
                result_map = this.orderService.findOrderById(identifier, sd_order_id);
                result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    dataMap = (Map)result_map.get(XcbConstantValue.DATA);
                    Tb_order order = (Tb_order)dataMap.get("order");
                    if (XcbConstantValue.ORDER_YWC.equals(order.getSr_order_status())) {
                        result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                        result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("order.isfinish"));
                        return result_map;
                    }
                    if ("Y".equals(order.getSr_is_overtime())) {
                        BigDecimal totalMoney = BigDecimalUtil.sub((BigDecimal)order.getDc_order_money(), (BigDecimal)order.getDc_actual_income());
                        if (!XcbStringUtils.isNullOrBlank((Object)order.getSr_iphone_num())) {
                            result_map = this.orderService.finishOrder(identifier, order, "uniapp");
                        } else if (userAccount.getDc_account_money_sum().compareTo(totalMoney) >= 0) {
                            result_map = this.orderService.finishOrderForAccount(identifier, order, totalMoney);
                        } else {
                            int total = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)totalMoney)));
                            result_map = this.wxAPIV3Common.finishOrder(order, total, sr_open_id, pay_info, cus_ip);
                            result_map.put(XcbConstantValue.STATUS, "2");
                        }
                    } else {
                        BigDecimal totalMoney = new BigDecimal(0);
                        if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                            totalMoney = BigDecimalUtil.sub((BigDecimal)order.getDc_actual_income(), (BigDecimal)order.getDc_order_money());
                            result_map = this.orderService.finishOrderForRecharge(identifier, order, totalMoney);
                        } else {
                            result_map = this.orderService.finishOrderForAccount(identifier, order, totalMoney);
                        }
                    }
                }
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u8bf7\u52ff\u91cd\u590d\u64cd\u4f5c");
        }
        return result_map;
    }
}

