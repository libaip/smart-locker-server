/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.company.model.Tb_order_goods
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.OrderGoodsServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/orderGoods"})
public class OrderGoodsController
extends BaseController {
    @Autowired
    private OrderGoodsServiceImpl orderGoodsService;

    @RequestMapping(value={"/findOrderGoodsById"})
    @ResponseBody
    public Map<String, Object> findOrderGoodsById(HttpServletRequest request, String sd_order_id) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.orderGoodsService.findOrderGoodsById(identifier, sd_order_id);
        return result_map;
    }

    @RequestMapping(value={"/findOrderGoodsByParam"})
    @ResponseBody
    public Map<String, Object> findOrderGoodsByParam(HttpServletRequest request, Tb_order_goods order, Page page) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.orderGoodsService.findOrderGoodsByParam(identifier, order, page);
        return result_map;
    }

    @RequestMapping(value={"/closeOrder"})
    @ResponseBody
    public Map<String, Object> closeOrder(HttpServletRequest request, Tb_order_goods order) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.orderGoodsService.closeOrder(identifier, order);
        return result_map;
    }

    @RequestMapping(value={"/updateOrderGoods"})
    @ResponseBody
    public Map<String, Object> updateOrderGoods(HttpServletRequest request, Tb_order_goods order) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.orderGoodsService.updateOrderGoods(identifier, order);
        return result_map;
    }
}

