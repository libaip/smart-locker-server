/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.company.model.Tb_ordergoods_server
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.common.model.Identifier;
import com.jcg.company.model.Tb_ordergoods_server;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.OrderGoodsServerServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/serverGoods"})
public class OrderGoodsServerController {
    @Autowired
    private OrderGoodsServerServiceImpl orderGoodsServerService;

    @RequestMapping(value={"/createOrderServer"})
    @ResponseBody
    public Map<String, Object> createOrderServer(HttpServletRequest request, Tb_ordergoods_server server) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.orderGoodsServerService.createOrderServer(identifier, server);
        return result_map;
    }

    @RequestMapping(value={"/findOrderGoodsServerById"})
    @ResponseBody
    public Map<String, Object> findOrderGoodsServerById(HttpServletRequest request, Tb_ordergoods_server server) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.orderGoodsServerService.findOrderGoodsServerById(identifier, server);
        return result_map;
    }
}

