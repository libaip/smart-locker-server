/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.agent.model.Tb_device;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.user.common.BaseController;
import com.jcg.user.service.DeviceServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/qrcode"})
public class QrCodeController
extends BaseController {
    @Autowired
    private DeviceServiceImpl deviceService;

    @RequestMapping(value={"/getPath"})
    @ResponseBody
    public void getPath(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Identifier identifier = new Identifier();
        String url = "";
        int result = 0;
        String mid = request.getParameter("mid");
        System.out.println(mid);
        Map<String, Object> result_map = this.deviceService.findDeviceByMid(identifier, "", mid, "", "");
        result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            Map dataMap = CommonFunction.null2HashMap((Map)((Map)result_map.get(XcbConstantValue.DATA)));
            Tb_device device = (Tb_device)dataMap.get("device");
            if (device != null) {
                if (XcbConstantValue.DEVICE_QR_D.equals(device.getSr_qr_type())) {
                    url = device.getSr_wx_qrcode_url();
                } else if (XcbConstantValue.DEVICE_QR_O.equals(device.getSr_qr_type())) {
                    url = device.getSr_o_wx_qrcode_url();
                } else if (XcbConstantValue.DEVICE_QR_N.equals(device.getSr_qr_type())) {
                    url = device.getSr_web_url() + device.getSi_mainboard_id();
                }
            } else {
                System.out.println("\u8bbe\u5907\u4e0d\u5b58\u5728");
            }
        }
        response.sendRedirect(url);
    }
}

