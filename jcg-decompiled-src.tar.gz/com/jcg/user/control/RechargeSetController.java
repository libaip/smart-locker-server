/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_recharge_set
 *  com.jcg.common.model.Identifier
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.agent.model.Tb_recharge_set;
import com.jcg.common.model.Identifier;
import com.jcg.user.common.BaseController;
import com.jcg.user.service.RechargeSetServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/rechargeSet"})
public class RechargeSetController
extends BaseController {
    @Autowired
    private RechargeSetServiceImpl rechargeSetService;

    @RequestMapping(value={"/findRechargeSetByParam"})
    @ResponseBody
    public Map<String, Object> findRechargeSetByParam(HttpServletRequest request, Tb_recharge_set rechargeSet) throws Exception {
        Identifier identifier = new Identifier();
        Map<String, Object> result_map = this.rechargeSetService.findRechargeSetByParam(identifier, rechargeSet);
        return result_map;
    }
}

