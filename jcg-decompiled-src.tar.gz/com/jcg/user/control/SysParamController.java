/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.common.model.Identifier;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.SysParamServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/sysParam"})
public class SysParamController
extends BaseController {
    @Autowired
    private SysParamServiceImpl sysParamService;

    @RequestMapping(value={"/getDropDownSelectDataByCate"})
    @ResponseBody
    public Map<String, Object> getDropDownSelectDataByCate(HttpServletResponse reponse, HttpServletRequest request, String sr_category_code) throws Exception {
        Tb_user tb_user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(tb_user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        Map<String, Object> ret = this.sysParamService.getDropDownSelectDataByCate(identifier, sr_category_code);
        return ret;
    }
}

