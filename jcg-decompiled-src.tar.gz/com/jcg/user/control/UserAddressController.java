/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.user.model.Tb_user
 *  com.jcg.user.model.Tb_user_address
 *  javax.servlet.http.HttpServletRequest
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.common.model.Identifier;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.model.Tb_user_address;
import com.jcg.user.service.UserAddressServiceImpl;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/address"})
public class UserAddressController
extends BaseController {
    @Autowired
    private UserAddressServiceImpl userAddressService;

    @RequestMapping(value={"/findAddressByParam"})
    @ResponseBody
    public Map<String, Object> findAddressByParam(HttpServletRequest request, Tb_user_address address) throws Exception {
        this.log.debug("AddressInfo================\u67e5\u8be2\u5730\u5740\u5217\u8868");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.userAddressService.findAddressByParam(identifier, address);
        return result_map;
    }

    @RequestMapping(value={"/findAddressById"})
    @ResponseBody
    public Map<String, Object> findAddressById(HttpServletRequest request, Tb_user_address address) throws Exception {
        this.log.debug("AddressInfo================\u67e5\u8be2\u5730\u5740\u4fe1\u606f");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.userAddressService.findAddressById(identifier, address);
        return result_map;
    }

    @RequestMapping(value={"/findAddressDefaultByUse"})
    @ResponseBody
    public Map<String, Object> findAddressDefaultByUse(HttpServletRequest request, Tb_user_address address) throws Exception {
        this.log.debug("AddressInfo================\u67e5\u8be2\u5730\u5740\u4fe1\u606f");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.userAddressService.findAddressDefaultByUse(identifier, address);
        return result_map;
    }

    @RequestMapping(value={"/createAddress"})
    @ResponseBody
    public Map<String, Object> createAddress(HttpServletRequest request, Tb_user_address address) throws Exception {
        this.log.debug("AddressInfo================\u65b0\u589e\u5730\u5740\u4fe1\u606f");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.userAddressService.createAddress(identifier, address);
        return result_map;
    }

    @RequestMapping(value={"/updateAddress"})
    @ResponseBody
    public Map<String, Object> updateAddress(HttpServletRequest request, Tb_user_address address) throws Exception {
        this.log.debug("AddressInfo================\u66f4\u65b0\u5730\u5740\u4fe1\u606f");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.userAddressService.updateAddress(identifier, address);
        return result_map;
    }

    @RequestMapping(value={"/deleteAddress"})
    @ResponseBody
    public Map<String, Object> deleteAddress(HttpServletRequest request, Tb_user_address address) throws Exception {
        this.log.debug("AddressInfo================\u5220\u9664\u5730\u5740\u4fe1\u606f");
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = this.userAddressService.deleteAddress(identifier, address);
        return result_map;
    }
}

