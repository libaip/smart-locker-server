/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_devicelogs
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  net.sf.json.JSONObject
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control;

import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_devicelogs;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.redis.RedisUtil;
import com.jcg.user.service.DeviceServiceImpl;
import com.jcg.user.service.SysParamServiceImpl;
import com.jcg.user.service.UserServiceImpl;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@RequestMapping(value={"/user"})
@Controller
public class UserController
extends BaseController {
    @Autowired
    private UserServiceImpl userService;
    @Autowired
    private RedisUtil redis;
    @Autowired
    private DeviceServiceImpl deviceService;
    @Autowired
    private SysParamServiceImpl sysParamService;

    @RequestMapping(value={"/findUserById"})
    @ResponseBody
    public Map<String, Object> findUserById(HttpServletResponse reponse, HttpServletRequest request, Tb_user user) throws Exception {
        Tb_user tb_user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(tb_user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(tb_user.getSd_user_id());
        identifier.setUserName(tb_user.getSr_user_name());
        Map<String, Object> ret = this.userService.findUserByUserId(identifier, user);
        return ret;
    }

    @RequestMapping(value={"/getWxPath"})
    @ResponseBody
    public Map<String, Object> getWxPath(HttpServletRequest request, Tb_user user) throws Exception {
        Tb_user tb_user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(tb_user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(tb_user.getSd_user_id());
        identifier.setUserName(tb_user.getSr_user_name());
        Map<String, Object> ret = new HashMap<String, Object>();
        JSONObject pathMap = new HashMap();
        Tb_wx_info wx_info = this.sysParamService.findWxInfoByCode(identifier, tb_user.getSr_way());
        String id = "";
        id = XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type()) ? XcbStringUtils.getObjtoString((Object)this.redis.get(tb_user.getSr_unionid())) : (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type()) ? XcbStringUtils.getObjtoString((Object)this.redis.get(tb_user.getSr_app_open_id())) : XcbStringUtils.getObjtoString((Object)this.redis.get(tb_user.getSr_open_id())));
        String jsonStr = XcbStringUtils.getObjtoString((Object)id);
        if (!XcbStringUtils.isNullOrBlank((Object)jsonStr)) {
            int reuslt;
            pathMap = JSONObject.fromObject((Object)jsonStr);
            String mid = XcbStringUtils.getObjtoString(pathMap.get("mid"));
            if (!XcbStringUtils.isNullOrBlank((Object)mid) && (reuslt = XcbStringUtils.getObjtoint((Object)(ret = this.deviceService.findDeviceByMid(identifier, XcbStringUtils.getObjtoString((Object)tb_user.getSd_user_id()), mid, "", "")).get(XcbConstantValue.STATUS))) > XcbConstantValue.OPERA_INT_ZERO) {
                Map dataMap = (Map)ret.get(XcbConstantValue.DATA);
                Tb_device device = (Tb_device)dataMap.get("device");
                if (device != null) {
                    Tb_devicelogs logs = (Tb_devicelogs)dataMap.get("logs");
                    ret.put("logs", logs);
                }
                ret.put("device", device);
            }
            ret.put(XcbConstantValue.DATA, pathMap);
        } else {
            ret.put(XcbConstantValue.DATA, "");
        }
        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        return ret;
    }

    @RequestMapping(value={"/updateUserById"})
    @ResponseBody
    public Map<String, Object> updateUserById(HttpServletRequest request, Tb_user user) throws Exception {
        Tb_user tb_user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(tb_user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(tb_user.getSd_user_id());
        identifier.setUserName(tb_user.getSr_user_name());
        Map<String, Object> ret = this.userService.updateUserById(identifier, user);
        return ret;
    }

    @RequestMapping(value={"/updateUserSubscribe"})
    @ResponseBody
    public Map<String, Object> updateUserSubscribe(HttpServletRequest request, Tb_user user) throws Exception {
        Tb_user tb_user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(tb_user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(tb_user.getSd_user_id());
        identifier.setUserName(tb_user.getSr_user_name());
        user.setSd_user_id(tb_user.getSd_user_id());
        Map<String, Object> ret = this.userService.updateUserSubscribe(identifier, user);
        return ret;
    }

    @RequestMapping(value={"/sendTest"})
    @ResponseBody
    public Map<String, Object> sendTest(HttpServletResponse reponse, HttpServletRequest request, Tb_user user) throws Exception {
        Tb_user tb_user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(tb_user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(tb_user.getSd_user_id());
        identifier.setUserName(tb_user.getSr_user_name());
        Map<String, Object> ret = this.userService.sendTest(identifier, user);
        return ret;
    }

    @RequestMapping(value={"/getUnionId"})
    @ResponseBody
    public Map<String, Object> getUnionId(HttpServletResponse reponse, HttpServletRequest request, Tb_user user) throws Exception {
        Tb_user tb_user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(tb_user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(tb_user.getSd_user_id());
        identifier.setUserName(tb_user.getSr_user_name());
        Map<String, Object> ret = this.userService.getUnionId(identifier, tb_user);
        return ret;
    }
}

