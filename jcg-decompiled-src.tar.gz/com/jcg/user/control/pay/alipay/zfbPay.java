/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alipay.api.response.AlipaySystemOauthTokenResponse
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.http.HttpServletRequest
 *  org.apache.commons.lang3.StringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control.pay.alipay;

import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import com.jcg.agent.model.Tb_device_package;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.user.common.BaseController;
import com.jcg.user.common.PromptProperties;
import com.jcg.user.model.Tb_user;
import com.jcg.user.redis.RedisUtil;
import com.jcg.user.service.DevicePackageServiceImpl;
import com.jcg.user.vo.LoginUser;
import com.jcg.user.zf.zfb.ZFBzfCommon;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/zfbPay"})
public class zfbPay
extends BaseController {
    @Autowired
    private DevicePackageServiceImpl devicePackageService;
    @Autowired
    private ZFBzfCommon zfbzfCommon;
    @Autowired
    private RedisUtil redis;

    @RequestMapping(value={"/pay"})
    @ResponseBody
    public Map<String, Object> createPayOrder(HttpServletRequest request, Tb_order order, Integer sd_id) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = new HashMap<String, Object>();
        Map dataMap = new HashMap();
        if (!XcbConstantValue.USER_YJH.equals(user.getSr_user_status())) {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u60a8\u7684\u8d26\u6237\u5f02\u5e38\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
            return result_map;
        }
        String code = request.getParameter("code");
        String sw_company_id = request.getParameter("sw_company_id");
        Integer sw_box_id = order.getSw_box_id();
        if (!StringUtils.isNotBlank((CharSequence)code)) {
            result_map.put(XcbConstantValue.STATUS, 202);
            result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            return result_map;
        }
        this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
        LoginUser loginUser = new LoginUser();
        loginUser.setSw_company_id(sw_company_id);
        loginUser.setCode(code);
        AlipaySystemOauthTokenResponse response = this.zfbzfCommon.getAccessToken(identifier, loginUser);
        this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
        if (response.isSuccess()) {
            String accessToken = response.getAccessToken();
            String sr_open_id = response.getUserId();
            this.log.info("----------------------------\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355 start--------------------------");
            Tb_company company = this.zfbzfCommon.getCompany(identifier, user.getSw_company_id());
            String sd_order_id = CommonFunction.getVoucherNum((String)CommonFunction.dd_id);
            BigDecimal totalMoney = null;
            order.setSd_order_id(sd_order_id);
            order.setSw_user_id(user.getSd_user_id());
            String userid = XcbStringUtils.getObjtoString((Object)this.redis.get(XcbConstantValue.DEVICE_BOX_CACHE + sw_box_id));
            if (XcbStringUtils.isNullOrBlank((Object)userid)) {
                this.redis.setForTimeMIN(XcbConstantValue.DEVICE_BOX_CACHE + sw_box_id, XcbStringUtils.getObjtoString((Object)user.getSd_user_id()), 3L);
            } else if (!userid.equals(XcbStringUtils.getObjtoString((Object)user.getSd_user_id()))) {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, "\u67dc\u5b50\u5df2\u88ab\u4eba\u4f7f\u7528");
                return result_map;
            }
            Tb_device_package devicePackage = new Tb_device_package();
            devicePackage.setSd_id(sd_id);
            Map<String, Object> resMap = this.devicePackageService.findDevicePackageById(identifier, devicePackage);
            int result = XcbStringUtils.getObjtoint((Object)resMap.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                dataMap = (Map)resMap.get(XcbConstantValue.DATA);
                devicePackage = (Tb_device_package)dataMap.get("devicePackage");
                if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
                    BigDecimal dc_advance_price;
                    BigDecimal dc_once_price = XcbStringUtils.getObjToBigDecimal((Object)devicePackage.getDc_once_price());
                    totalMoney = BigDecimalUtil.add((BigDecimal)dc_once_price, (BigDecimal)(dc_advance_price = XcbStringUtils.getObjToBigDecimal((Object)devicePackage.getDc_advance_price())));
                    if (totalMoney.compareTo(new BigDecimal(0)) == 1) {
                        result_map = this.zfbzfCommon.createPayOrder(order, devicePackage, totalMoney, sr_open_id, company);
                    } else {
                        result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.package.find.fail"));
                    }
                } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                    totalMoney = XcbStringUtils.getObjToBigDecimal((Object)devicePackage.getDc_advance_price());
                    if (totalMoney.compareTo(new BigDecimal(0)) == 1) {
                        result_map = this.zfbzfCommon.createPayOrder(order, devicePackage, totalMoney, sr_open_id, company);
                    }
                } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type()) && (totalMoney = XcbStringUtils.getObjToBigDecimal((Object)devicePackage.getDc_advance_price())).compareTo(new BigDecimal(0)) == 1) {
                    result_map = this.zfbzfCommon.createPayOrder(order, devicePackage, totalMoney, sr_open_id, company);
                }
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.package.find.fail"));
            }
            this.log.info(XcbStringUtils.getObjtoString(result_map.get(XcbConstantValue.MSG)));
            this.log.info("----------------------------\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355 end--------------------------");
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
        }
        int result = XcbStringUtils.getObjtoint(result_map.get(XcbConstantValue.STATUS));
        return result_map;
    }
}

