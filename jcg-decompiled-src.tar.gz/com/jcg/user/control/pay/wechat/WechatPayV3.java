/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_order_goods
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.user.model.Tb_user
 *  com.jcg.user.model.Tb_user_account
 *  javax.servlet.http.HttpServletRequest
 *  net.sf.json.JSONObject
 *  org.apache.commons.lang3.StringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.security.core.context.SecurityContextHolder
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control.pay.wechat;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_device_package;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.common.BaseController;
import com.jcg.user.common.PromptProperties;
import com.jcg.user.model.Tb_user;
import com.jcg.user.model.Tb_user_account;
import com.jcg.user.redis.RedisUtil;
import com.jcg.user.service.DeviceBoxServiceImpl;
import com.jcg.user.service.DevicePackageServiceImpl;
import com.jcg.user.service.OrderGoodsServiceImpl;
import com.jcg.user.service.OrderServiceImpl;
import com.jcg.user.service.SysParamServiceImpl;
import com.jcg.user.service.UserAccountServiceImpl;
import com.jcg.user.vo.LoginUser;
import com.jcg.user.zf.wx.WXzfCommon;
import com.jcg.user.zf.wx.WxAPIV3Common;
import com.jcg.user.zf.wx.WxQbAPICommon;
import com.jcg.user.zf.wx.WxSdjAPICommon;
import com.jcg.user.zf.wx.WxSpAPIV3Common;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/wechatPayV3"})
public class WechatPayV3
extends BaseController {
    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private DevicePackageServiceImpl devicePackageService;
    @Autowired
    private DeviceBoxServiceImpl deviceBoxService;
    @Autowired
    private UserAccountServiceImpl userAccountService;
    @Autowired
    private WXzfCommon wxzfCommon;
    @Autowired
    private WxAPIV3Common wxAPIV3Common;
    @Autowired
    private WxSdjAPICommon wxSdjAPICommon;
    @Autowired
    private WxQbAPICommon wxQbAPICommon;
    @Autowired
    private WxSpAPIV3Common wxSpAPIV3Common;
    @Autowired
    private RedisUtil redis;
    @Autowired
    private OrderGoodsServiceImpl orderGoodsService;
    @Autowired
    private SysParamServiceImpl sysParamService;

    @RequestMapping(value={"/pay"})
    @ResponseBody
    public Map<String, Object> createPayOrder(HttpServletRequest request, Tb_order order, Integer sd_id) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = new HashMap<String, Object>();
        Map dataMap = new HashMap();
        int result = 0;
        if (!XcbConstantValue.USER_YJH.equals(user.getSr_user_status())) {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u60a8\u7684\u8d26\u6237\u5f02\u5e38\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
            return result_map;
        }
        String code = request.getParameter("code");
        String sw_company_id = request.getParameter("sw_company_id");
        String sr_way = request.getParameter("sr_way");
        if (XcbStringUtils.isNullOrBlank((Object)sr_way)) {
            sr_way = "ZC";
        }
        if (!StringUtils.isNotBlank((CharSequence)code)) {
            result_map.put(XcbConstantValue.STATUS, 202);
            result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            return result_map;
        }
        this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
        LoginUser loginUser = new LoginUser();
        loginUser.setCode(code);
        loginUser.setSw_company_id(sw_company_id);
        loginUser.setSr_way(sr_way);
        String openId_str = this.wxzfCommon.getOpenId(identifier, loginUser);
        JSONObject jsonObj = JSONObject.fromObject((Object)openId_str);
        String sr_open_id = jsonObj.getString("openid");
        this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
        this.log.info("----------------------------\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355 start--------------------------");
        Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, sr_way);
        Tb_wx_pay_info pay_info = info.getPay_info();
        String cus_ip = WXzfCommon.getIpAdrress(request);
        String sd_order_id = CommonFunction.getVoucherNum((String)CommonFunction.dd_id);
        BigDecimal totalMoney = null;
        order.setSd_order_id(sd_order_id);
        order.setSw_user_id(user.getSd_user_id());
        Integer sw_box_id = order.getSw_box_id();
        Map<String, Object> resMap = this.deviceBoxService.findDeviceBoxById(identifier, sw_box_id);
        result = XcbStringUtils.getObjtoint((Object)resMap.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            dataMap = (Map)resMap.get(XcbConstantValue.DATA);
            Tb_device_box deviceBox = (Tb_device_box)dataMap.get("deviceBox");
            if (deviceBox != null && XcbConstantValue.DEVICE_BOX_STATUS_KY.equals(deviceBox.getSr_box_status())) {
                String userid = XcbStringUtils.getObjtoString((Object)this.redis.get(XcbConstantValue.DEVICE_BOX_CACHE + sw_box_id));
                if (XcbStringUtils.isNullOrBlank((Object)userid)) {
                    this.redis.setForTimeMIN(XcbConstantValue.DEVICE_BOX_CACHE + sw_box_id, XcbStringUtils.getObjtoString((Object)user.getSd_user_id()), 3L);
                } else if (!userid.equals(XcbStringUtils.getObjtoString((Object)user.getSd_user_id()))) {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    result_map.put(XcbConstantValue.MSG, "\u67dc\u5b50\u5df2\u88ab\u4eba\u9501\u5b9a");
                    return result_map;
                }
                Tb_device_package devicePackage = new Tb_device_package();
                devicePackage.setSd_id(sd_id);
                resMap = this.devicePackageService.findDevicePackageById(identifier, devicePackage);
                result = XcbStringUtils.getObjtoint((Object)resMap.get(XcbConstantValue.STATUS));
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    dataMap = (Map)resMap.get(XcbConstantValue.DATA);
                    devicePackage = (Tb_device_package)dataMap.get("devicePackage");
                    if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
                        BigDecimal dc_advance_price;
                        BigDecimal dc_once_price = XcbStringUtils.getObjToBigDecimal((Object)devicePackage.getDc_once_price());
                        totalMoney = BigDecimalUtil.add((BigDecimal)dc_once_price, (BigDecimal)(dc_advance_price = XcbStringUtils.getObjToBigDecimal((Object)devicePackage.getDc_advance_price())));
                        if (totalMoney.compareTo(new BigDecimal(0)) == 1) {
                            int total = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)totalMoney)));
                            result_map = XcbConstantValue.PTSH.equals(pay_info.getSr_type()) ? this.wxAPIV3Common.createPayOrder(order, devicePackage, total, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.SDJSH.equals(pay_info.getSr_type()) ? this.wxSdjAPICommon.createPayOrder(identifier, order, devicePackage, totalMoney, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.QBSH.equals(pay_info.getSr_type()) ? this.wxQbAPICommon.createPayOrder(identifier, order, devicePackage, total, sr_open_id, pay_info, cus_ip) : this.wxSpAPIV3Common.createPayOrder(order, devicePackage, total, sr_open_id, pay_info, cus_ip)));
                        } else {
                            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.package.find.fail"));
                        }
                    } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                        BigDecimal dc_advance_price;
                        BigDecimal dc_once_price = XcbStringUtils.getObjToBigDecimal((Object)devicePackage.getDc_once_price());
                        totalMoney = BigDecimalUtil.add((BigDecimal)dc_once_price, (BigDecimal)(dc_advance_price = XcbStringUtils.getObjToBigDecimal((Object)devicePackage.getDc_advance_price())));
                        if (totalMoney.compareTo(new BigDecimal(0)) == 1) {
                            int total = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)totalMoney)));
                            result_map = XcbConstantValue.PTSH.equals(pay_info.getSr_type()) ? this.wxAPIV3Common.createPayOrder(order, devicePackage, total, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.SDJSH.equals(pay_info.getSr_type()) ? this.wxSdjAPICommon.createPayOrder(identifier, order, devicePackage, totalMoney, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.QBSH.equals(pay_info.getSr_type()) ? this.wxQbAPICommon.createPayOrder(identifier, order, devicePackage, total, sr_open_id, pay_info, cus_ip) : this.wxSpAPIV3Common.createPayOrder(order, devicePackage, total, sr_open_id, pay_info, cus_ip)));
                        }
                    } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type()) && (totalMoney = XcbStringUtils.getObjToBigDecimal((Object)devicePackage.getDc_advance_price())).compareTo(new BigDecimal(0)) == 1) {
                        int total = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)totalMoney)));
                        result_map = XcbConstantValue.PTSH.equals(pay_info.getSr_type()) ? this.wxAPIV3Common.createPayOrder(order, devicePackage, total, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.SDJSH.equals(pay_info.getSr_type()) ? this.wxSdjAPICommon.createPayOrder(identifier, order, devicePackage, totalMoney, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.QBSH.equals(pay_info.getSr_type()) ? this.wxQbAPICommon.createPayOrder(identifier, order, devicePackage, total, sr_open_id, pay_info, cus_ip) : this.wxSpAPIV3Common.createPayOrder(order, devicePackage, total, sr_open_id, pay_info, cus_ip)));
                    }
                } else {
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("device.package.find.fail"));
                }
            } else {
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, "\u67dc\u95e8\u5df2\u88ab\u5360\u7528");
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u8bbe\u5907\u6570\u636e\u5f02\u5e38\uff0c\u8bf7\u8054\u7cfb\u7ba1\u7406\u5458");
        }
        this.log.info(XcbStringUtils.getObjtoString(result_map.get(XcbConstantValue.MSG)));
        this.log.info("----------------------------\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355 end--------------------------");
        result = XcbStringUtils.getObjtoint(result_map.get(XcbConstantValue.STATUS));
        return result_map;
    }

    @RequestMapping(value={"/payGoods"})
    @ResponseBody
    public Map<String, Object> createGoodsOrder(HttpServletRequest request, Tb_order_goods order, String idStr) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = new HashMap<String, Object>();
        HashMap dataMap = new HashMap();
        String sr_open_id = user.getSr_open_id();
        String sr_way = request.getParameter("sr_way");
        if (XcbStringUtils.isNullOrBlank((Object)sr_way)) {
            sr_way = "ZC";
            sr_open_id = user.getSr_app_open_id();
        }
        int result = 0;
        if (!XcbConstantValue.USER_YJH.equals(user.getSr_user_status())) {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u60a8\u7684\u8d26\u6237\u5f02\u5e38");
            return result_map;
        }
        if (XcbStringUtils.isNullOrBlank((Object)order.getSw_address_id())) {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u8bf7\u586b\u5199\u6536\u8d27\u5730\u5740");
            return result_map;
        }
        if (!XcbStringUtils.isNullOrBlank((Object)idStr)) {
            String[] idArr = idStr.split(",");
            this.log.info("----------------------------\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355 start--------------------------");
            Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, sr_way);
            Tb_wx_pay_info pay_info = info.getPay_info();
            String cus_ip = WXzfCommon.getIpAdrress(request);
            String sd_order_id = CommonFunction.getVoucherNum((String)CommonFunction.gw_id);
            order.setSd_order_id(sd_order_id);
            order.setSw_user_id(user.getSd_user_id());
            order.setIdArr(idArr);
            order.setSr_mchid(pay_info.getSub_mchid());
            result_map = this.orderGoodsService.createOrderGoods(identifier, order);
            result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                order = (Tb_order_goods)result_map.get(XcbConstantValue.DATA);
                BigDecimal totalMoney = order.getDc_order_money();
                if (totalMoney.compareTo(new BigDecimal(0)) == 1) {
                    int total = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)totalMoney)));
                    result_map = XcbConstantValue.PTSH.equals(pay_info.getSr_type()) ? this.wxAPIV3Common.createPayOrderGoods(order, total, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.SDJSH.equals(pay_info.getSr_type()) ? this.wxSdjAPICommon.createPayOrderGoods(identifier, order, totalMoney, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.QBSH.equals(pay_info.getSr_type()) ? this.wxQbAPICommon.createPayOrderGoods(identifier, order, total, sr_open_id, pay_info, cus_ip) : this.wxSpAPIV3Common.createPayOrderGoods(order, total, sr_open_id, pay_info, cus_ip)));
                } else {
                    order.setSr_status(XcbConstantValue.ORDER_GOODS_STS_DFH);
                    this.orderGoodsService.updateOrderGoods(identifier, order);
                    result_map.put("sd_order_id", sd_order_id);
                    result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_WARN);
                }
            }
        } else {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u8bf7\u9009\u62e9\u9700\u8981\u652f\u4ed8\u7684\u5546\u54c1");
        }
        this.log.info(XcbStringUtils.getObjtoString(result_map.get(XcbConstantValue.MSG)));
        this.log.info("----------------------------\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355 end--------------------------");
        return result_map;
    }

    @RequestMapping(value={"/rePayOrderGoods"})
    @ResponseBody
    public Map<String, Object> rePayOrderGoods(HttpServletRequest request, Tb_order_goods order) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = new HashMap<String, Object>();
        Map dataMap = new HashMap();
        int result = 0;
        if (!XcbConstantValue.USER_YJH.equals(user.getSr_user_status())) {
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            result_map.put(XcbConstantValue.MSG, "\u60a8\u7684\u8d26\u6237\u5f02\u5e38");
            return result_map;
        }
        String sr_way = request.getParameter("sr_way");
        String sr_open_id = user.getSr_open_id();
        if (XcbStringUtils.isNullOrBlank((Object)sr_way)) {
            sr_way = "ZC";
            sr_open_id = user.getSr_app_open_id();
        }
        Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, sr_way);
        Tb_wx_pay_info pay_info = info.getPay_info();
        String cus_ip = WXzfCommon.getIpAdrress(request);
        result_map = this.orderGoodsService.findOrderGoodsById(identifier, order.getSd_order_id());
        result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            dataMap = (Map)result_map.get(XcbConstantValue.DATA);
            order = (Tb_order_goods)dataMap.get("order");
            BigDecimal totalMoney = order.getDc_order_money();
            int total = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)totalMoney)));
            result_map = XcbConstantValue.PTSH.equals(pay_info.getSr_type()) ? this.wxAPIV3Common.createPayOrderGoods(order, total, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.SDJSH.equals(pay_info.getSr_type()) ? this.wxSdjAPICommon.createPayOrderGoods(identifier, order, totalMoney, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.QBSH.equals(pay_info.getSr_type()) ? this.wxQbAPICommon.createPayOrderGoods(identifier, order, total, sr_open_id, pay_info, cus_ip) : this.wxSpAPIV3Common.createPayOrderGoods(order, total, sr_open_id, pay_info, cus_ip)));
        }
        this.log.info(XcbStringUtils.getObjtoString((Object)result_map.get(XcbConstantValue.MSG)));
        this.log.info("----------------------------\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355 end--------------------------");
        return result_map;
    }

    @RequestMapping(value={"/finish"})
    @ResponseBody
    public Map<String, Object> finishOrder(HttpServletRequest request, String sd_order_id) throws Exception {
        Tb_user user = (Tb_user)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Identifier identifier = new Identifier(user.getSd_user_id(), request.getRemoteAddr(), request.getRequestURI());
        identifier.setUserId(user.getSd_user_id());
        identifier.setUserName(user.getSr_user_name());
        Map<String, Object> result_map = new HashMap<String, Object>();
        Map dataMap = new HashMap();
        String code = request.getParameter("code");
        String sw_company_id = request.getParameter("sw_company_id");
        String sr_way = request.getParameter("sr_way");
        if (XcbStringUtils.isNullOrBlank((Object)sr_way)) {
            sr_way = "ZC";
        }
        if (!StringUtils.isNotBlank((CharSequence)code)) {
            result_map.put(XcbConstantValue.STATUS, 202);
            result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.auto.login.error"));
            return result_map;
        }
        this.log.info("----------------------------\u83b7\u5f97openId start--------------------------");
        LoginUser loginUser = new LoginUser();
        loginUser.setCode(code);
        loginUser.setSw_company_id(sw_company_id);
        loginUser.setSr_way(sr_way);
        String openId_str = this.wxzfCommon.getOpenId(identifier, loginUser);
        JSONObject jsonObj = JSONObject.fromObject((Object)openId_str);
        String sr_open_id = jsonObj.getString("openid");
        this.log.info("----------------------------\u83b7\u5f97openId end--------------------------");
        this.log.info("----------------------------\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355 start--------------------------");
        Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, sr_way);
        Tb_wx_pay_info pay_info = info.getPay_info();
        String cus_ip = WXzfCommon.getIpAdrress(request);
        Tb_order order = new Tb_order();
        result_map = this.orderService.findOrderById(identifier, sd_order_id);
        int result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            dataMap = (Map)result_map.get(XcbConstantValue.DATA);
            order = (Tb_order)dataMap.get("order");
            Tb_user_account userAccount = new Tb_user_account();
            userAccount.setSw_user_id(order.getSw_user_id());
            result_map = this.userAccountService.findUserAccountByUser(identifier, userAccount);
            result = XcbStringUtils.getObjtoint((Object)result_map.get(XcbConstantValue.STATUS));
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                dataMap = (Map)result_map.get(XcbConstantValue.DATA);
                userAccount = (Tb_user_account)dataMap.get("userAccount");
                BigDecimal dc_account_money_sum = BigDecimalUtil.add((BigDecimal)userAccount.getDc_account_money(), (BigDecimal)userAccount.getDc_present_money());
                if (order.getDc_order_money().compareTo(order.getDc_actual_income()) == 1) {
                    BigDecimal totalMoney = BigDecimalUtil.sub((BigDecimal)order.getDc_order_money(), (BigDecimal)order.getDc_actual_income());
                    if (dc_account_money_sum.compareTo(totalMoney) >= 0) {
                        result_map = this.orderService.finishOrderForAccount(identifier, order, totalMoney);
                    } else {
                        int total = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)totalMoney)));
                        result_map = XcbConstantValue.PTSH.equals(pay_info.getSr_type()) ? this.wxAPIV3Common.finishOrder(order, total, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.SDJSH.equals(pay_info.getSr_type()) ? this.wxSdjAPICommon.finishOrder(identifier, order, totalMoney, sr_open_id, pay_info, cus_ip) : (XcbConstantValue.QBSH.equals(pay_info.getSr_type()) ? this.wxQbAPICommon.finishOrder(identifier, order, total, sr_open_id, pay_info, cus_ip) : this.wxSpAPIV3Common.finishOrder(order, total, sr_open_id, pay_info, cus_ip)));
                    }
                } else {
                    BigDecimal totalMoney = BigDecimalUtil.sub((BigDecimal)order.getDc_actual_income(), (BigDecimal)order.getDc_order_money());
                    result_map = this.orderService.finishOrderForRecharge(identifier, order, totalMoney);
                }
            }
        } else {
            result_map.put(XcbConstantValue.MSG, PromptProperties.getProperty("system.fail"));
            result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        return result_map;
    }
}

