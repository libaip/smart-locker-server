/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alipay.api.AlipayApiException
 *  com.alipay.api.internal.util.AlipaySignature
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.ThreadPoolManager
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  net.sf.json.JSONObject
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 */
package com.jcg.user.control.paynotify.alipay;

import com.alipay.api.AlipayApiException;
import com.alipay.api.internal.util.AlipaySignature;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.ThreadPoolManager;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.user.common.BaseController;
import com.jcg.user.service.DeviceBoxServiceImpl;
import com.jcg.user.service.OrderServiceImpl;
import com.jcg.user.zf.zfb.ZFBzfCommon;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value={"/alipayNotify_31202112161654364290002"})
public class alipayNotify_31202112161654364290002
extends BaseController {
    private static String sr_company_id = XcbConstantValue.companyid;
    private static Map<String, Object> keyMap;
    private static Map<String, Map<String, Object>> cert_map;
    @Autowired
    private ZFBzfCommon zfbzfCommon;
    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private DeviceBoxServiceImpl deviceBoxService;

    private static void initCert(Tb_company company) throws Exception {
        keyMap = cert_map.get(company.getSd_company_id());
        if (keyMap == null) {
            String publicKey = alipayNotify_31202112161654364290002.readLocalPubKey(company.getSr_zfb_public_path());
            String privateKey = alipayNotify_31202112161654364290002.readLocalPriKey(company.getSr_zfb_privatekey_path());
            keyMap = new HashMap<String, Object>();
            keyMap.put("publicKey", publicKey);
            keyMap.put("privateKey", privateKey);
            cert_map.put(company.getSd_company_id(), keyMap);
        }
    }

    @RequestMapping(value={"/payNotify"})
    public String payNotify(HttpServletRequest request, HttpServletResponse reponse) throws Exception {
        String return_value;
        block11: {
            this.log.info("----------------------------\u652f\u4ed8\u5b9d\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355\u56de\u8c03 start--------------------------");
            final Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
            final Tb_company company = this.zfbzfCommon.getCompany(identifier, sr_company_id);
            return_value = "success";
            try {
                alipayNotify_31202112161654364290002.initCert(company);
            }
            catch (Exception e) {
                this.log.error("\u52a0\u8f7d\u652f\u4ed8\u5b9d\u8bc1\u4e66\u5f02\u5e38");
                e.printStackTrace();
            }
            String publicKey = XcbStringUtils.getObjtoString((Object)keyMap.get("publicKey"));
            try {
                request.setCharacterEncoding("GBK");
                final Map<String, String> return_data = this.zfbzfCommon.convertRequestParamsToMap(request);
                String paramsJson = JSONObject.fromObject(return_data).toString();
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03Map\uff1a" + return_data.toString());
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03title\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("subject")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03body\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("body")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03sign\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("sign")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03out_trade_no\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03trade_no\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("trade_no")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03total_amount\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("total_amount")));
                String trade_status = XcbStringUtils.getObjtoString((Object)return_data.get("trade_status"));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03trade_status\uff1a" + trade_status);
                try {
                    if (trade_status.equals(XcbConstantValue.zfb_zf_success) || trade_status.equals(XcbConstantValue.zfb_zf_finished)) {
                        boolean signVerified = AlipaySignature.rsaCheckV1(return_data, (String)publicKey, (String)"GBK", (String)"RSA2");
                        if (signVerified) {
                            Thread threads = new Thread(){

                                @Override
                                public void run() {
                                    super.run();
                                    try {
                                        alipayNotify_31202112161654364290002.this.checkOutTradeNo(identifier, return_data, 0, company);
                                    }
                                    catch (Exception e) {
                                        e.printStackTrace();
                                        alipayNotify_31202112161654364290002.this.log.error("\u652f\u4ed8\u5b9d\u56de\u8c03\u4e1a\u52a1\u5904\u7406\u5f02\u5e38:" + e.getMessage());
                                    }
                                }
                            };
                            ThreadPoolManager.getsInstance().execute((Runnable)threads);
                        } else {
                            this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u7b7e\u540d\u8ba4\u8bc1\u5931\u8d25\uff0csignVerified=false, paramsJson:{}", (Object)paramsJson);
                        }
                        break block11;
                    }
                    this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u652f\u4ed8\u5931\u8d25\uff0csignVerified=false, paramsJson:{}", (Object)paramsJson);
                }
                catch (AlipayApiException e) {
                    this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u7b7e\u540d\u8ba4\u8bc1\u5931\u8d25,paramsJson:{},errorMsg:{}", (Object)paramsJson, (Object)e.getMessage());
                }
            }
            catch (Exception e) {
                this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u5931\u8d25 \uff0cerror:" + XcbStringUtils.exceptionToString((Exception)e));
            }
        }
        reponse.setContentType("application/json;charset=UTF-8");
        reponse.setHeader("catch-control", "no-catch");
        PrintWriter out = null;
        try {
            out = reponse.getWriter();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        out.write(return_value);
        out.flush();
        out.close();
        this.log.info("----------------------------\u652f\u4ed8\u5b9d\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355\u56de\u8c03 end--------------------------");
        return null;
    }

    @RequestMapping(value={"/temporaryNotify"})
    public String temporaryNotify(HttpServletRequest request, HttpServletResponse reponse) throws Exception {
        String return_value;
        block11: {
            this.log.info("----------------------------\u652f\u4ed8\u5b9d\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355\u56de\u8c03 start--------------------------");
            final Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
            final Tb_company company = this.zfbzfCommon.getCompany(identifier, sr_company_id);
            return_value = "success";
            try {
                alipayNotify_31202112161654364290002.initCert(company);
            }
            catch (Exception e) {
                this.log.error("\u52a0\u8f7d\u652f\u4ed8\u5b9d\u8bc1\u4e66\u5f02\u5e38");
                e.printStackTrace();
            }
            String publicKey = XcbStringUtils.getObjtoString((Object)keyMap.get("publicKey"));
            try {
                request.setCharacterEncoding("GBK");
                final Map<String, String> return_data = this.zfbzfCommon.convertRequestParamsToMap(request);
                String paramsJson = JSONObject.fromObject(return_data).toString();
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03Map\uff1a" + return_data.toString());
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03title\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("subject")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03body\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("body")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03sign\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("sign")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03out_trade_no\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03trade_no\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("trade_no")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03total_amount\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("total_amount")));
                String trade_status = XcbStringUtils.getObjtoString((Object)return_data.get("trade_status"));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03trade_status\uff1a" + trade_status);
                try {
                    if (trade_status.equals(XcbConstantValue.zfb_zf_success) || trade_status.equals(XcbConstantValue.zfb_zf_finished)) {
                        boolean signVerified = AlipaySignature.rsaCheckV1(return_data, (String)publicKey, (String)"GBK", (String)"RSA2");
                        if (signVerified) {
                            Thread threads = new Thread(){

                                @Override
                                public void run() {
                                    super.run();
                                    try {
                                        alipayNotify_31202112161654364290002.this.checkOutTradeNo(identifier, return_data, 1, company);
                                    }
                                    catch (Exception e) {
                                        e.printStackTrace();
                                        alipayNotify_31202112161654364290002.this.log.error("\u652f\u4ed8\u5b9d\u56de\u8c03\u4e1a\u52a1\u5904\u7406\u5f02\u5e38:" + e.getMessage());
                                    }
                                }
                            };
                            ThreadPoolManager.getsInstance().execute((Runnable)threads);
                        } else {
                            this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u7b7e\u540d\u8ba4\u8bc1\u5931\u8d25\uff0csignVerified=false, paramsJson:{}", (Object)paramsJson);
                        }
                        break block11;
                    }
                    this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u652f\u4ed8\u5931\u8d25\uff0csignVerified=false, paramsJson:{}", (Object)paramsJson);
                }
                catch (AlipayApiException e) {
                    this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u7b7e\u540d\u8ba4\u8bc1\u5931\u8d25,paramsJson:{},errorMsg:{}", (Object)paramsJson, (Object)e.getMessage());
                }
            }
            catch (Exception e) {
                this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u5931\u8d25 \uff0cerror:" + XcbStringUtils.exceptionToString((Exception)e));
            }
        }
        reponse.setContentType("application/json;charset=UTF-8");
        reponse.setHeader("catch-control", "no-catch");
        PrintWriter out = null;
        try {
            out = reponse.getWriter();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        out.write(return_value);
        out.flush();
        out.close();
        this.log.info("----------------------------\u652f\u4ed8\u5b9d\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355\u56de\u8c03 end--------------------------");
        return null;
    }

    @RequestMapping(value={"/finishNotify"})
    public String finishNotify(HttpServletRequest request, HttpServletResponse reponse) throws Exception {
        String return_value;
        block11: {
            this.log.info("----------------------------\u652f\u4ed8\u5b9d\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355\u56de\u8c03 start--------------------------");
            final Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
            final Tb_company company = this.zfbzfCommon.getCompany(identifier, sr_company_id);
            return_value = "success";
            try {
                alipayNotify_31202112161654364290002.initCert(company);
            }
            catch (Exception e) {
                this.log.error("\u52a0\u8f7d\u652f\u4ed8\u5b9d\u8bc1\u4e66\u5f02\u5e38");
                e.printStackTrace();
            }
            String publicKey = XcbStringUtils.getObjtoString((Object)keyMap.get("publicKey"));
            try {
                request.setCharacterEncoding("GBK");
                final Map<String, String> return_data = this.zfbzfCommon.convertRequestParamsToMap(request);
                String paramsJson = JSONObject.fromObject(return_data).toString();
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03Map\uff1a" + return_data.toString());
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03title\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("subject")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03body\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("body")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03sign\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("sign")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03out_trade_no\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03trade_no\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("trade_no")));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03total_amount\uff1a" + XcbStringUtils.getObjtoString((Object)return_data.get("total_amount")));
                String trade_status = XcbStringUtils.getObjtoString((Object)return_data.get("trade_status"));
                this.log.info("\u652f\u4ed8\u5b9d\u56de\u8c03trade_status\uff1a" + trade_status);
                try {
                    if (trade_status.equals(XcbConstantValue.zfb_zf_success) || trade_status.equals(XcbConstantValue.zfb_zf_finished)) {
                        boolean signVerified = AlipaySignature.rsaCheckV1(return_data, (String)publicKey, (String)"GBK", (String)"RSA2");
                        if (signVerified) {
                            Thread threads = new Thread(){

                                @Override
                                public void run() {
                                    super.run();
                                    try {
                                        alipayNotify_31202112161654364290002.this.checkOutTradeNo(identifier, return_data, 2, company);
                                    }
                                    catch (Exception e) {
                                        e.printStackTrace();
                                        alipayNotify_31202112161654364290002.this.log.error("\u652f\u4ed8\u5b9d\u56de\u8c03\u4e1a\u52a1\u5904\u7406\u5f02\u5e38:" + e.getMessage());
                                    }
                                }
                            };
                            ThreadPoolManager.getsInstance().execute((Runnable)threads);
                        } else {
                            this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u7b7e\u540d\u8ba4\u8bc1\u5931\u8d25\uff0csignVerified=false, paramsJson:{}", (Object)paramsJson);
                        }
                        break block11;
                    }
                    this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u652f\u4ed8\u5931\u8d25\uff0csignVerified=false, paramsJson:{}", (Object)paramsJson);
                }
                catch (AlipayApiException e) {
                    this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u7b7e\u540d\u8ba4\u8bc1\u5931\u8d25,paramsJson:{},errorMsg:{}", (Object)paramsJson, (Object)e.getMessage());
                }
            }
            catch (Exception e) {
                this.log.error("\u652f\u4ed8\u5b9d\u5145\u503c\u56de\u8c03\u5931\u8d25 \uff0cerror:" + XcbStringUtils.exceptionToString((Exception)e));
            }
        }
        reponse.setContentType("application/json;charset=UTF-8");
        reponse.setHeader("catch-control", "no-catch");
        PrintWriter out = null;
        try {
            out = reponse.getWriter();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        out.write(return_value);
        out.flush();
        out.close();
        this.log.info("----------------------------\u652f\u4ed8\u5b9d\u652f\u4ed8\u7edf\u4e00\u4e0b\u5355\u56de\u8c03 end--------------------------");
        return null;
    }

    private Map<String, Object> checkOutTradeNo(Identifier identifier, Map<String, String> return_data, int model, Tb_company company) throws Exception {
        int result;
        Map<Object, Object> rtnMap = new HashMap();
        String out_trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no"));
        String trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("trade_no"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)return_data.get("body"));
        String[] attachArr = sr_attach.split(",");
        String sd_order_id = "";
        if (model == 0) {
            sd_order_id = XcbStringUtils.getObjtoString((Object)attachArr[10]);
        } else if (model == 1) {
            sd_order_id = XcbStringUtils.getObjtoString((Object)attachArr[0]);
        } else if (model == 2) {
            sd_order_id = XcbStringUtils.getObjtoString((Object)attachArr[0]);
        }
        String sign_type = sd_order_id.substring(0, 2);
        if (CommonFunction.dd_id.equals(sign_type) && (result = XcbStringUtils.getObjtoint((Object)(rtnMap = this.orderService.checkPayNotifyInfo(out_trade_no, sd_order_id)).get(XcbConstantValue.STATUS))) > XcbConstantValue.OPERA_INT_ZERO) {
            if (model == 0) {
                Integer sw_user_id = XcbStringUtils.getObjtoint((Object)attachArr[0]);
                Integer sw_box_id = XcbStringUtils.getObjtoint((Object)attachArr[4]);
                rtnMap = this.orderPayNotify(identifier, return_data);
                this.deviceBoxService.cancelDeviceBox(sw_user_id, sw_box_id);
            } else if (model == 1) {
                rtnMap = this.orderTemporaryPayNotify(identifier, return_data);
            } else if (model == 2) {
                rtnMap = this.orderFinishPayNotify(identifier, return_data);
            }
        }
        if ((result = XcbStringUtils.getObjtoint(rtnMap.get(XcbConstantValue.STATUS))) == XcbConstantValue.OPERA_INT_ZERO) {
            String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
            BigDecimal total_amount = XcbStringUtils.getObjToBigDecimal((Object)return_data.get("total_amount"));
            String reason = XcbStringUtils.getObjtoString((Object)rtnMap.get("sr_reason"));
            rtnMap = this.zfbzfCommon.xcrefund(trade_no, total_amount, total_amount, out_trade_no, sd_cash_id, company, reason);
            this.log.info("\u652f\u4ed8\u5b9d\u652f\u4ed8->\u9000\u6b3e\u4e0b\u5355\u7ed3\u679c\uff1a" + XcbStringUtils.getObjtoString((Object)rtnMap.get(XcbConstantValue.MSG)));
        }
        return rtnMap;
    }

    public Map<String, Object> orderPayNotify(Identifier identifier, Map<String, String> return_data) {
        HashMap<String, Object> rtnMap = new HashMap();
        String out_trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no"));
        BigDecimal total_amount = XcbStringUtils.getObjToBigDecimal((Object)return_data.get("total_amount"));
        String trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("trade_no"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)return_data.get("body"));
        this.log.info("\u521b\u5efa\u8ba2\u5355\u7684\u4fe1\u606f\u5982\u4e0b\uff1a");
        this.log.info("\u8ba2\u5355\u53f7\uff1aout_trade_no---------" + out_trade_no);
        this.log.info("\u652f\u4ed8\u5b9d\u652f\u4ed8\u5355\u53f7\uff1atransaction_id-----------" + trade_no);
        this.log.info("\u652f\u4ed8\u5b9d\u652f\u4ed8\u91d1\u989d\uff1atotal_amount-----------" + total_amount);
        this.log.info("\u5176\u4ed6\u4e00\u4e9b\u8ba2\u5355\u4fe1\u606f\uff1aattach-----------" + sr_attach);
        rtnMap = this.orderService.orderPayNotify(identifier, out_trade_no, total_amount, trade_no, "", sr_attach);
        return rtnMap;
    }

    public Map<String, Object> orderTemporaryPayNotify(Identifier identifier, Map<String, String> return_data) {
        HashMap<String, Object> rtnMap = new HashMap();
        String out_trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no"));
        BigDecimal total_amount = XcbStringUtils.getObjToBigDecimal((Object)return_data.get("total_amount"));
        String trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("trade_no"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)return_data.get("body"));
        this.log.info("\u521b\u5efa\u8ba2\u5355\u7684\u4fe1\u606f\u5982\u4e0b\uff1a");
        this.log.info("\u8ba2\u5355\u53f7\uff1aout_trade_no---------" + out_trade_no);
        this.log.info("\u652f\u4ed8\u5b9d\u652f\u4ed8\u5355\u53f7\uff1atransaction_id-----------" + trade_no);
        this.log.info("\u652f\u4ed8\u5b9d\u652f\u4ed8\u91d1\u989d\uff1atotal_amount-----------" + total_amount);
        this.log.info("\u5176\u4ed6\u4e00\u4e9b\u8ba2\u5355\u4fe1\u606f\uff1aattach-----------" + sr_attach);
        rtnMap = this.orderService.orderTemporaryPayNotify(identifier, out_trade_no, total_amount, trade_no, sr_attach);
        return rtnMap;
    }

    public Map<String, Object> orderFinishPayNotify(Identifier identifier, Map<String, String> return_data) {
        HashMap<String, Object> rtnMap = new HashMap();
        String out_trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no"));
        BigDecimal total_amount = XcbStringUtils.getObjToBigDecimal((Object)return_data.get("total_amount"));
        String trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("trade_no"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)return_data.get("body"));
        this.log.info("\u521b\u5efa\u8ba2\u5355\u7684\u4fe1\u606f\u5982\u4e0b\uff1a");
        this.log.info("\u8ba2\u5355\u53f7\uff1aout_trade_no---------" + out_trade_no);
        this.log.info("\u652f\u4ed8\u5b9d\u652f\u4ed8\u5355\u53f7\uff1atransaction_id-----------" + trade_no);
        this.log.info("\u652f\u4ed8\u5b9d\u652f\u4ed8\u91d1\u989d\uff1atotal_amount-----------" + total_amount);
        this.log.info("\u5176\u4ed6\u4e00\u4e9b\u8ba2\u5355\u4fe1\u606f\uff1aattach-----------" + sr_attach);
        rtnMap = this.orderService.orderFinishPayNotify(identifier, out_trade_no, total_amount, trade_no, sr_attach);
        return rtnMap;
    }

    public static String readLocalPubKey(String filePath) throws IOException {
        File file = new File(filePath);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        System.out.println("\u652f\u4ed8\u5b9d\u516c\u94a5\uff1a" + sb.toString());
        return sb.toString();
    }

    public static String readLocalPriKey(String filePath) throws IOException {
        File file = new File(filePath);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        System.out.println("\u652f\u4ed8\u5b9d\u79c1\u94a5\uff1a" + sb.toString());
        return sb.toString();
    }

    static {
        cert_map = new HashMap<String, Map<String, Object>>();
    }
}

