/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.ThreadPoolManager
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_wx_pay_info
 *  javax.servlet.ServletInputStream
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  net.sf.json.JSONObject
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.control.paynotify.wechat;

import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.ThreadPoolManager;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.common.BaseController;
import com.jcg.user.redis.RedisUtil;
import com.jcg.user.service.DeviceBoxServiceImpl;
import com.jcg.user.service.OrderServiceImpl;
import com.jcg.user.service.SysParamServiceImpl;
import com.jcg.user.zf.wx.WxAPIV3AesUtil;
import com.jcg.user.zf.wx.WxAPIV3Common;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/wechatPayNotify_162054_ZC"})
public class WechatPayNotify_162054_ZC
extends BaseController {
    private static String sr_company_id = XcbConstantValue.companyid;
    private static String sr_mchid = "162054";
    private static String sr_way = "ZC";
    private static String TRANSACTION_SUCCESS = "TRANSACTION.SUCCESS";
    private static String REFUND_SUCCESS = "REFUND.SUCCESS";
    @Autowired
    private RedisUtil redis;
    @Autowired
    private WxAPIV3Common wxAPIV3Common;
    @Autowired
    private OrderServiceImpl orderService;
    @Autowired
    private DeviceBoxServiceImpl deviceBoxService;
    @Autowired
    private SysParamServiceImpl sysParamService;

    @RequestMapping(value={"/payNotify"})
    @ResponseBody
    public String payNotify(HttpServletRequest request, HttpServletResponse response) throws Exception {
        this.log.info("------------------------\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03 start------------------------");
        HashMap<String, String> ret = new HashMap<String, String>();
        final Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        String return_msg = "";
        String callBackIn = "";
        final Tb_wx_pay_info pay_info = this.sysParamService.findWxInfoByMchId(identifier, sr_mchid);
        try {
            ServletInputStream servletInputStream = request.getInputStream();
            int contentLength = request.getContentLength();
            byte[] callBackInBytes = new byte[contentLength];
            servletInputStream.read(callBackInBytes, 0, contentLength);
            callBackIn = new String(callBackInBytes, XcbConstantValue.ENCODING_UTF8);
            this.log.info("\u3010\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03\u3011\uff1a" + callBackIn);
            final JSONObject notifyIn = JSONObject.fromObject((Object)callBackIn);
            if (notifyIn == null) {
                response.setStatus(500);
                this.log.error("\u53c2\u6570\u4e0d\u6b63\u786e\uff0c\u53cd\u5e8f\u5217\u5316\u5931\u8d25");
                ret.put("code", "FAIL");
                ret.put("message", "\u53c2\u6570\u4e0d\u6b63\u786e\uff0c\u53cd\u5e8f\u5217\u5316\u5931\u8d25");
                return_msg = JSONObject.fromObject(ret).toString();
                this.log.info(return_msg);
                response.setContentType("application/json;charset=UTF-8");
                response.setHeader("catch-control", "no-catch");
                response.getWriter().write(return_msg);
                response.getWriter().flush();
                response.getWriter().close();
                return null;
            }
            String tradeStatus = notifyIn.getString("tradeStatus");
            if ("SUCCESS".equals(tradeStatus)) {
                final HashMap<String, String> return_data = new HashMap<String, String>();
                return_data.put("out_trade_no", notifyIn.getString("outTransId"));
                return_data.put("transaction_id", notifyIn.getString("transactionId"));
                return_data.put("attach", this.redis.get(notifyIn.getString("outTransId")));
                return_data.put("total", notifyIn.getString("tradeAmount"));
                return_data.put("channelTransNo", notifyIn.getString("channelTransNo"));
                Thread threads = new Thread(){

                    @Override
                    public void run() {
                        super.run();
                        try {
                            WechatPayNotify_162054_ZC.this.checkOutTradeNo(identifier, return_data, 0, pay_info);
                            WechatPayNotify_162054_ZC.this.redis.delete(notifyIn.getString("outTransId"));
                        }
                        catch (Exception e) {
                            e.printStackTrace();
                            WechatPayNotify_162054_ZC.this.log.error("\u652f\u4ed8\u5b9d\u56de\u8c03\u4e1a\u52a1\u5904\u7406\u5f02\u5e38:" + e.getMessage());
                        }
                    }
                };
                ThreadPoolManager.getsInstance().execute((Runnable)threads);
                response.setStatus(200);
                ret.put("code", "SUCCESS");
                ret.put("message", "\u5904\u7406\u6210\u529f");
            } else {
                response.setStatus(500);
                this.log.error("\u5fae\u4fe1\u652f\u4ed8\u56de\u8c03\u5904\u7406\u5f02\u5e38:\u4ea4\u6613\u72b6\u6001\u5f02\u5e38");
                ret.put("code", "FAIL");
                ret.put("message", "\u7cfb\u7edf\u5f02\u5e38");
            }
            this.log.info("------------------------\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03 end------------------------");
        }
        catch (Exception e) {
            response.setStatus(500);
            this.log.error("\u5fae\u4fe1\u652f\u4ed8\u56de\u8c03\u5904\u7406\u5f02\u5e38\uff0c" + e.getMessage());
            ret.put("code", "FAIL");
            ret.put("message", "\u7cfb\u7edf\u5f02\u5e38");
        }
        return_msg = JSONObject.fromObject(ret).toString();
        this.log.info(return_msg);
        response.setContentType("application/json;charset=UTF-8");
        response.setHeader("catch-control", "no-catch");
        response.getWriter().write(return_msg);
        response.getWriter().flush();
        response.getWriter().close();
        return null;
    }

    @RequestMapping(value={"/payNotify2"})
    @ResponseBody
    public String payNotify2(HttpServletRequest request, HttpServletResponse response) throws Exception {
        this.log.info("------------------------\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03 start------------------------");
        HashMap<String, String> ret = new HashMap<String, String>();
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        String return_msg = "";
        String callBackIn = "";
        Tb_wx_pay_info pay_info = this.sysParamService.findWxInfoByMchId(identifier, sr_mchid);
        String mchKey = pay_info.getSp_merkey_v3();
        try {
            String decryptToString = "{\"mchid\":\"1605004395\",\"appid\":\"wx18baee0689cf237d\",\"out_trade_no\":\"13202306161828184933738\",\"transaction_id\":\"4200001835202306163864667324\",\"trade_type\":\"JSAPI\",\"trade_state\":\"SUCCESS\",\"trade_state_desc\":\"\u652f\u4ed8\u6210\u529f\",\"bank_type\":\"OTHERS\",\"attach\":\"342653,1280,3073,15202303211124019621908,68118,WX,ACJF,Y,18033393521,8888,10202306161828184303737,WX,2.00,20.00,1605004395\",\"success_time\":\"2023-06-16T18:28:24+08:00\",\"payer\":{\"openid\":\"ojGJt56ZY-zFRibkoXaiC1MFWY7c\"},\"amount\":{\"total\":2200,\"payer_total\":2200,\"currency\":\"CNY\",\"payer_currency\":\"CNY\"}}";
            if (XcbStringUtils.isNullOrBlank((Object)decryptToString)) {
                response.setStatus(500);
                ret.put("code", "FAIL");
                ret.put("message", "\u89e3\u5bc6\u56de\u8c03\u4fe1\u606f\u5f02\u5e38");
                return_msg = JSONObject.fromObject(ret).toString();
                this.log.info(return_msg);
                response.setContentType("application/json;charset=UTF-8");
                response.setHeader("catch-control", "no-catch");
                response.getWriter().write(return_msg);
                response.getWriter().flush();
                response.getWriter().close();
                return null;
            }
            this.log.info("\u3010\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03\uff1a\u3011" + decryptToString);
            this.log.info("\u7528\u6237\u786e\u8ba4\u6210\u529f");
            response.setStatus(200);
            ret.put("code", "SUCCESS");
            ret.put("message", "\u5904\u7406\u6210\u529f");
            return_msg = JSONObject.fromObject(ret).toString();
            this.log.info(return_msg);
            response.setContentType("application/json;charset=UTF-8");
            response.setHeader("catch-control", "no-catch");
            response.getWriter().write(return_msg);
            response.getWriter().flush();
            response.getWriter().close();
            JSONObject return_data = JSONObject.fromObject((Object)decryptToString);
            String trade_state = XcbStringUtils.getObjtoString(return_data.get("trade_state"));
            this.checkOutTradeNo(identifier, (Map<String, Object>)return_data, 0, pay_info);
            response.setStatus(200);
            ret.put("code", "SUCCESS");
            ret.put("message", "\u5904\u7406\u6210\u529f");
            this.log.info("------------------------\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03 end------------------------");
        }
        catch (Exception e) {
            response.setStatus(500);
            this.log.error("\u5fae\u4fe1\u652f\u4ed8\u56de\u8c03\u5904\u7406\u5f02\u5e38\uff0c" + e.getMessage());
            ret.put("code", "FAIL");
            ret.put("message", "\u7cfb\u7edf\u5f02\u5e38");
        }
        return_msg = JSONObject.fromObject(ret).toString();
        this.log.info(return_msg);
        response.setContentType("application/json;charset=UTF-8");
        response.setHeader("catch-control", "no-catch");
        response.getWriter().write(return_msg);
        response.getWriter().flush();
        response.getWriter().close();
        return null;
    }

    @RequestMapping(value={"/temporaryNotify"})
    @ResponseBody
    public String temporaryNotify(HttpServletRequest request, HttpServletResponse response) throws Exception {
        this.log.info("------------------------\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03 start------------------------");
        HashMap<String, String> ret = new HashMap<String, String>();
        HashMap dataMap = new HashMap();
        final Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        String return_msg = "";
        String callBackIn = "";
        Tb_wx_pay_info pay_info = this.sysParamService.findWxInfoByMchId(identifier, sr_mchid);
        String mchKey = pay_info.getSp_merkey_v3();
        try {
            ServletInputStream servletInputStream = request.getInputStream();
            int contentLength = request.getContentLength();
            byte[] callBackInBytes = new byte[contentLength];
            servletInputStream.read(callBackInBytes, 0, contentLength);
            callBackIn = new String(callBackInBytes, XcbConstantValue.ENCODING_UTF8);
            this.log.info("\u3010\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03\u3011\uff1a" + callBackIn);
            JSONObject notifyIn = JSONObject.fromObject((Object)callBackIn);
            if (notifyIn == null) {
                response.setStatus(500);
                this.log.error("\u53c2\u6570\u4e0d\u6b63\u786e\uff0c\u53cd\u5e8f\u5217\u5316\u5931\u8d25");
                ret.put("code", "FAIL");
                ret.put("message", "\u53c2\u6570\u4e0d\u6b63\u786e\uff0c\u53cd\u5e8f\u5217\u5316\u5931\u8d25");
                return_msg = JSONObject.fromObject(ret).toString();
                this.log.info(return_msg);
                response.setContentType("application/json;charset=UTF-8");
                response.setHeader("catch-control", "no-catch");
                response.getWriter().write(return_msg);
                response.getWriter().flush();
                response.getWriter().close();
                return null;
            }
            JSONObject resource = notifyIn.getJSONObject("resource");
            byte[] key = mchKey.getBytes();
            WxAPIV3AesUtil aesUtil = new WxAPIV3AesUtil(key);
            String decryptToString = aesUtil.decryptToString(resource.getString("associated_data").getBytes(XcbConstantValue.ENCODING_UTF8), resource.getString("nonce").getBytes(XcbConstantValue.ENCODING_UTF8), resource.getString("ciphertext"));
            if (XcbStringUtils.isNullOrBlank((Object)decryptToString)) {
                response.setStatus(500);
                ret.put("code", "FAIL");
                ret.put("message", "\u89e3\u5bc6\u56de\u8c03\u4fe1\u606f\u5f02\u5e38");
                return_msg = JSONObject.fromObject(ret).toString();
                this.log.info(return_msg);
                response.setContentType("application/json;charset=UTF-8");
                response.setHeader("catch-control", "no-catch");
                response.getWriter().write(return_msg);
                response.getWriter().flush();
                response.getWriter().close();
                return null;
            }
            this.log.info("\u3010\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03\uff1a\u3011" + decryptToString);
            if (TRANSACTION_SUCCESS.equals(notifyIn.get("event_type"))) {
                this.log.info("\u7528\u6237\u786e\u8ba4\u6210\u529f");
                JSONObject return_data = JSONObject.fromObject((Object)decryptToString);
                String trade_state = XcbStringUtils.getObjtoString(return_data.get("trade_state"));
                if (XcbConstantValue.OPERATION_SUCCESS.equals(trade_state)) {
                    Thread threads = new Thread((Map)return_data, pay_info){
                        final /* synthetic */ Map val$return_data;
                        final /* synthetic */ Tb_wx_pay_info val$pay_info;
                        {
                            this.val$return_data = map;
                            this.val$pay_info = tb_wx_pay_info;
                        }

                        @Override
                        public void run() {
                            super.run();
                            try {
                                WechatPayNotify_162054_ZC.this.checkOutTradeNo(identifier, this.val$return_data, 1, this.val$pay_info);
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                WechatPayNotify_162054_ZC.this.log.error("\u652f\u4ed8\u5b9d\u56de\u8c03\u4e1a\u52a1\u5904\u7406\u5f02\u5e38:" + e.getMessage());
                            }
                        }
                    };
                    ThreadPoolManager.getsInstance().execute((Runnable)threads);
                    response.setStatus(200);
                    ret.put("code", "SUCCESS");
                    ret.put("message", "\u5904\u7406\u6210\u529f");
                } else {
                    response.setStatus(500);
                    this.log.error("\u5fae\u4fe1\u652f\u4ed8->\u652f\u4ed8\u7ed3\u679c\u56de\u8c03\u7ed3\u679c:->" + trade_state);
                    ret.put("code", "FAIL");
                    ret.put("message", trade_state);
                }
            }
            this.log.info("------------------------\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03 end------------------------");
        }
        catch (Exception e) {
            response.setStatus(500);
            this.log.error("\u5fae\u4fe1\u652f\u4ed8\u56de\u8c03\u5904\u7406\u5f02\u5e38\uff0c" + e.getMessage());
            ret.put("code", "FAIL");
            ret.put("message", "\u7cfb\u7edf\u5f02\u5e38");
        }
        return_msg = JSONObject.fromObject(ret).toString();
        this.log.info(return_msg);
        response.setContentType("application/json;charset=UTF-8");
        response.setHeader("catch-control", "no-catch");
        response.getWriter().write(return_msg);
        response.getWriter().flush();
        response.getWriter().close();
        return null;
    }

    @RequestMapping(value={"/finishNotify"})
    @ResponseBody
    public String finishNotify(HttpServletRequest request, HttpServletResponse response) throws Exception {
        this.log.info("------------------------\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03 start------------------------");
        HashMap<String, String> ret = new HashMap<String, String>();
        HashMap dataMap = new HashMap();
        final Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        String return_msg = "";
        String callBackIn = "";
        Tb_wx_pay_info pay_info = this.sysParamService.findWxInfoByMchId(identifier, sr_mchid);
        String mchKey = pay_info.getSp_merkey_v3();
        try {
            ServletInputStream servletInputStream = request.getInputStream();
            int contentLength = request.getContentLength();
            byte[] callBackInBytes = new byte[contentLength];
            servletInputStream.read(callBackInBytes, 0, contentLength);
            callBackIn = new String(callBackInBytes, XcbConstantValue.ENCODING_UTF8);
            this.log.info("\u3010\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03\u3011\uff1a" + callBackIn);
            JSONObject notifyIn = JSONObject.fromObject((Object)callBackIn);
            if (notifyIn == null) {
                response.setStatus(500);
                this.log.error("\u53c2\u6570\u4e0d\u6b63\u786e\uff0c\u53cd\u5e8f\u5217\u5316\u5931\u8d25");
                ret.put("code", "FAIL");
                ret.put("message", "\u53c2\u6570\u4e0d\u6b63\u786e\uff0c\u53cd\u5e8f\u5217\u5316\u5931\u8d25");
                return_msg = JSONObject.fromObject(ret).toString();
                this.log.info(return_msg);
                response.setContentType("application/json;charset=UTF-8");
                response.setHeader("catch-control", "no-catch");
                response.getWriter().write(return_msg);
                response.getWriter().flush();
                response.getWriter().close();
                return null;
            }
            JSONObject resource = notifyIn.getJSONObject("resource");
            byte[] key = mchKey.getBytes();
            WxAPIV3AesUtil aesUtil = new WxAPIV3AesUtil(key);
            String decryptToString = aesUtil.decryptToString(resource.getString("associated_data").getBytes(XcbConstantValue.ENCODING_UTF8), resource.getString("nonce").getBytes(XcbConstantValue.ENCODING_UTF8), resource.getString("ciphertext"));
            if (XcbStringUtils.isNullOrBlank((Object)decryptToString)) {
                response.setStatus(500);
                ret.put("code", "FAIL");
                ret.put("message", "\u89e3\u5bc6\u56de\u8c03\u4fe1\u606f\u5f02\u5e38");
                return_msg = JSONObject.fromObject(ret).toString();
                this.log.info(return_msg);
                response.setContentType("application/json;charset=UTF-8");
                response.setHeader("catch-control", "no-catch");
                response.getWriter().write(return_msg);
                response.getWriter().flush();
                response.getWriter().close();
                return null;
            }
            this.log.info("\u3010\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03\uff1a\u3011" + decryptToString);
            if (TRANSACTION_SUCCESS.equals(notifyIn.get("event_type"))) {
                this.log.info("\u7528\u6237\u786e\u8ba4\u6210\u529f");
                response.setStatus(200);
                ret.put("code", "SUCCESS");
                ret.put("message", "\u5904\u7406\u6210\u529f");
                return_msg = JSONObject.fromObject(ret).toString();
                this.log.info(return_msg);
                response.setContentType("application/json;charset=UTF-8");
                response.setHeader("catch-control", "no-catch");
                response.getWriter().write(return_msg);
                response.getWriter().flush();
                response.getWriter().close();
                JSONObject return_data = JSONObject.fromObject((Object)decryptToString);
                String trade_state = XcbStringUtils.getObjtoString(return_data.get("trade_state"));
                if (XcbConstantValue.OPERATION_SUCCESS.equals(trade_state)) {
                    Thread threads = new Thread((Map)return_data, pay_info){
                        final /* synthetic */ Map val$return_data;
                        final /* synthetic */ Tb_wx_pay_info val$pay_info;
                        {
                            this.val$return_data = map;
                            this.val$pay_info = tb_wx_pay_info;
                        }

                        @Override
                        public void run() {
                            super.run();
                            try {
                                WechatPayNotify_162054_ZC.this.checkOutTradeNo(identifier, this.val$return_data, 2, this.val$pay_info);
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                                WechatPayNotify_162054_ZC.this.log.error("\u652f\u4ed8\u5b9d\u56de\u8c03\u4e1a\u52a1\u5904\u7406\u5f02\u5e38:" + e.getMessage());
                            }
                        }
                    };
                    ThreadPoolManager.getsInstance().execute((Runnable)threads);
                    response.setStatus(200);
                    ret.put("code", "SUCCESS");
                    ret.put("message", "\u5904\u7406\u6210\u529f");
                } else {
                    response.setStatus(500);
                    this.log.error("\u5fae\u4fe1\u652f\u4ed8->\u652f\u4ed8\u7ed3\u679c\u56de\u8c03\u7ed3\u679c:->" + trade_state);
                    ret.put("code", "FAIL");
                    ret.put("message", trade_state);
                }
            }
            this.log.info("------------------------\u5fae\u4fe1v3\u652f\u4ed8\u56de\u8c03 end------------------------");
        }
        catch (Exception e) {
            response.setStatus(500);
            this.log.error("\u5fae\u4fe1\u652f\u4ed8\u56de\u8c03\u5904\u7406\u5f02\u5e38\uff0c" + e.getMessage());
            ret.put("code", "FAIL");
            ret.put("message", "\u7cfb\u7edf\u5f02\u5e38");
        }
        return_msg = JSONObject.fromObject(ret).toString();
        this.log.info(return_msg);
        response.setContentType("application/json;charset=UTF-8");
        response.setHeader("catch-control", "no-catch");
        response.getWriter().write(return_msg);
        response.getWriter().flush();
        response.getWriter().close();
        return null;
    }

    public Map<String, Object> orderPayNotify(Identifier identifier, Map<String, Object> return_data) {
        HashMap<String, Object> rtnMap = new HashMap();
        String out_trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no"));
        String payer_total = XcbStringUtils.getObjtoString((Object)return_data.get("total"));
        BigDecimal dc_actual_income = XcbStringUtils.getObjToBigDecimal((Object)CommonFunction.fenToyuan((String)payer_total));
        String channelTransNo = XcbStringUtils.getObjtoString((Object)return_data.get("channelTransNo"));
        String transaction_id = XcbStringUtils.getObjtoString((Object)return_data.get("transaction_id"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)return_data.get("attach"));
        this.log.info("\u521b\u5efa\u8ba2\u5355\u7684\u4fe1\u606f\u5982\u4e0b\uff1a");
        this.log.info("\u8ba2\u5355\u53f7\uff1aout_trade_no---------" + out_trade_no);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u5355\u53f7\uff1atransaction_id-----------" + transaction_id);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u91d1\u989d\uff1atransaction_id-----------" + dc_actual_income);
        this.log.info("\u5176\u4ed6\u4e00\u4e9b\u8ba2\u5355\u4fe1\u606f\uff1aattach-----------" + sr_attach);
        rtnMap = this.orderService.orderPayNotify(identifier, out_trade_no, dc_actual_income, transaction_id, channelTransNo, sr_attach);
        return rtnMap;
    }

    public Map<String, Object> orderTemporaryPayNotify(Identifier identifier, Map<String, Object> return_data) {
        HashMap<String, Object> rtnMap = new HashMap();
        String out_trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no"));
        Map amountMap = (Map)return_data.get("amount");
        String payer_total = XcbStringUtils.getObjtoString(amountMap.get("total"));
        BigDecimal dc_actual_income = XcbStringUtils.getObjToBigDecimal((Object)CommonFunction.fenToyuan((String)payer_total));
        String transaction_id = XcbStringUtils.getObjtoString((Object)return_data.get("transaction_id"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)return_data.get("attach"));
        this.log.info("\u521b\u5efa\u8ba2\u5355\u7684\u4fe1\u606f\u5982\u4e0b\uff1a");
        this.log.info("\u8ba2\u5355\u53f7\uff1aout_trade_no---------" + out_trade_no);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u5355\u53f7\uff1atransaction_id-----------" + transaction_id);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u91d1\u989d\uff1atransaction_id-----------" + dc_actual_income);
        this.log.info("\u5176\u4ed6\u4e00\u4e9b\u8ba2\u5355\u4fe1\u606f\uff1aattach-----------" + sr_attach);
        rtnMap = this.orderService.orderTemporaryPayNotify(identifier, out_trade_no, dc_actual_income, transaction_id, sr_attach);
        return rtnMap;
    }

    public Map<String, Object> orderFinishPayNotify(Identifier identifier, Map<String, Object> return_data) {
        HashMap<String, Object> rtnMap = new HashMap();
        String out_trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no"));
        Map amountMap = (Map)return_data.get("amount");
        String payer_total = XcbStringUtils.getObjtoString(amountMap.get("total"));
        BigDecimal dc_actual_income = XcbStringUtils.getObjToBigDecimal((Object)CommonFunction.fenToyuan((String)payer_total));
        String transaction_id = XcbStringUtils.getObjtoString((Object)return_data.get("transaction_id"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)return_data.get("attach"));
        this.log.info("\u521b\u5efa\u8ba2\u5355\u7684\u4fe1\u606f\u5982\u4e0b\uff1a");
        this.log.info("\u8ba2\u5355\u53f7\uff1aout_trade_no---------" + out_trade_no);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u5355\u53f7\uff1atransaction_id-----------" + transaction_id);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u91d1\u989d\uff1atransaction_id-----------" + dc_actual_income);
        this.log.info("\u5176\u4ed6\u4e00\u4e9b\u8ba2\u5355\u4fe1\u606f\uff1aattach-----------" + sr_attach);
        rtnMap = this.orderService.orderFinishPayNotify(identifier, out_trade_no, dc_actual_income, transaction_id, sr_attach);
        return rtnMap;
    }

    private Map<String, Object> checkOutTradeNo(Identifier identifier, Map<String, Object> return_data, int model, Tb_wx_pay_info info) throws Exception {
        int result;
        Map<Object, Object> rtnMap = new HashMap();
        String out_trade_no = XcbStringUtils.getObjtoString((Object)return_data.get("out_trade_no"));
        String transaction_id = XcbStringUtils.getObjtoString((Object)return_data.get("transaction_id"));
        String sr_attach = XcbStringUtils.getObjtoString((Object)return_data.get("attach"));
        String[] attachArr = sr_attach.split(",");
        String sd_order_id = "";
        if (model == 0) {
            sd_order_id = XcbStringUtils.getObjtoString((Object)attachArr[10]);
        } else if (model == 1) {
            sd_order_id = XcbStringUtils.getObjtoString((Object)attachArr[0]);
        } else if (model == 2) {
            sd_order_id = XcbStringUtils.getObjtoString((Object)attachArr[0]);
        }
        String sign_type = sd_order_id.substring(0, 2);
        if (CommonFunction.dd_id.equals(sign_type) && (result = XcbStringUtils.getObjtoint((Object)(rtnMap = this.orderService.checkPayNotifyInfo(out_trade_no, sd_order_id)).get(XcbConstantValue.STATUS))) > XcbConstantValue.OPERA_INT_ZERO) {
            if (model == 0) {
                Integer sw_user_id = XcbStringUtils.getObjtoint((Object)attachArr[0]);
                Integer sw_box_id = XcbStringUtils.getObjtoint((Object)attachArr[4]);
                rtnMap = this.orderPayNotify(identifier, return_data);
                this.deviceBoxService.cancelDeviceBox(sw_user_id, sw_box_id);
            } else if (model == 1) {
                rtnMap = this.orderTemporaryPayNotify(identifier, return_data);
            } else if (model == 2) {
                rtnMap = this.orderFinishPayNotify(identifier, return_data);
            }
        }
        if ((result = XcbStringUtils.getObjtoint(rtnMap.get(XcbConstantValue.STATUS))) == XcbConstantValue.OPERA_INT_ZERO) {
            String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
            Map amountMap = (Map)return_data.get("amount");
            int total = XcbStringUtils.getObjtoint(amountMap.get("total"));
            int payer_total = XcbStringUtils.getObjtoint(amountMap.get("total"));
            String reason = XcbStringUtils.getObjtoString((Object)rtnMap.get("sr_reason"));
            rtnMap = this.wxAPIV3Common.xcrefund(transaction_id, total, payer_total, out_trade_no, sd_cash_id, info, reason);
            this.log.info("\u5fae\u4fe1\u652f\u4ed8->\u9000\u6b3e\u4e0b\u5355\u7ed3\u679c\uff1a" + XcbStringUtils.getObjtoString((Object)rtnMap.get(XcbConstantValue.MSG)));
        }
        return rtnMap;
    }

    @RequestMapping(value={"/refundNotify"})
    public String refundNotify(HttpServletRequest request, HttpServletResponse response) throws Exception {
        this.log.info("------------------------\u5fae\u4fe1v3\u9000\u6b3e\u56de\u8c03 start------------------------");
        HashMap<String, String> ret = new HashMap<String, String>();
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        String return_msg = "";
        String callBackIn = "";
        Tb_wx_pay_info pay_info = this.sysParamService.findWxInfoByMchId(identifier, sr_mchid);
        String mchKey = pay_info.getSp_merkey_v3();
        try {
            ServletInputStream servletInputStream = request.getInputStream();
            int contentLength = request.getContentLength();
            byte[] callBackInBytes = new byte[contentLength];
            servletInputStream.read(callBackInBytes, 0, contentLength);
            callBackIn = new String(callBackInBytes, XcbConstantValue.ENCODING_UTF8);
            this.log.info("\u3010\u5fae\u4fe1v3\u9000\u6b3e\u56de\u8c03\u3011\uff1a" + callBackIn);
            JSONObject notifyIn = JSONObject.fromObject((Object)callBackIn);
            if (notifyIn == null) {
                response.setStatus(500);
                this.log.error("\u53c2\u6570\u4e0d\u6b63\u786e\uff0c\u53cd\u5e8f\u5217\u5316\u5931\u8d25");
                ret.put("code", "FAIL");
                ret.put("message", "\u53c2\u6570\u4e0d\u6b63\u786e\uff0c\u53cd\u5e8f\u5217\u5316\u5931\u8d25");
                return_msg = JSONObject.fromObject(ret).toString();
                this.log.info(return_msg);
                response.setContentType("application/json;charset=UTF-8");
                response.setHeader("catch-control", "no-catch");
                response.getWriter().write(return_msg);
                response.getWriter().flush();
                response.getWriter().close();
                return null;
            }
            JSONObject resource = notifyIn.getJSONObject("resource");
            byte[] key = mchKey.getBytes();
            WxAPIV3AesUtil aesUtil = new WxAPIV3AesUtil(key);
            String decryptToString = aesUtil.decryptToString(resource.getString("associated_data").getBytes(XcbConstantValue.ENCODING_UTF8), resource.getString("nonce").getBytes(XcbConstantValue.ENCODING_UTF8), resource.getString("ciphertext"));
            if (XcbStringUtils.isNullOrBlank((Object)decryptToString)) {
                response.setStatus(500);
                ret.put("code", "FAIL");
                ret.put("message", "\u89e3\u5bc6\u56de\u8c03\u4fe1\u606f\u5f02\u5e38");
                return_msg = JSONObject.fromObject(ret).toString();
                this.log.info(return_msg);
                response.setContentType("application/json;charset=UTF-8");
                response.setHeader("catch-control", "no-catch");
                response.getWriter().write(return_msg);
                response.getWriter().flush();
                response.getWriter().close();
                return null;
            }
            this.log.info("\u3010\u5fae\u4fe1v3\u9000\u6b3e\u56de\u8c03\uff1a\u3011" + decryptToString);
            if (REFUND_SUCCESS.equals(notifyIn.get("event_type"))) {
                this.log.info("\u7528\u6237\u786e\u8ba4\u6210\u529f");
                response.setStatus(200);
                ret.put("code", "SUCCESS");
                ret.put("message", "\u5904\u7406\u6210\u529f");
                this.log.info("\u5fae\u4fe1\u9000\u6b3e->\u9000\u6b3e\u7ed3\u679c\u56de\u8c03\u7ed3\u679c:->\u9000\u6b3e\u6210\u529f");
            }
            this.log.info("------------------------\u5fae\u4fe1v3\u9000\u6b3e\u56de\u8c03 end------------------------");
        }
        catch (Exception e) {
            response.setStatus(500);
            this.log.error("\u5fae\u4fe1\u9000\u6b3e\u56de\u8c03\u5904\u7406\u5f02\u5e38\uff0c" + e.getMessage());
            ret.put("code", "FAIL");
            ret.put("message", "\u7cfb\u7edf\u5f02\u5e38");
        }
        return_msg = JSONObject.fromObject(ret).toString();
        this.log.info(return_msg);
        response.setContentType("application/json;charset=UTF-8");
        response.setHeader("catch-control", "no-catch");
        response.getWriter().write(return_msg);
        response.getWriter().flush();
        response.getWriter().close();
        return null;
    }
}

