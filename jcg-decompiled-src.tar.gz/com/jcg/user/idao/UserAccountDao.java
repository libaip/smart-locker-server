/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.user.model.Tb_user_account
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.user.idao;

import com.jcg.user.model.Tb_user_account;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface UserAccountDao {
    public int updateUserAccountById_user(Tb_user_account var1);

    public int updateRemarkUserAccountById_user(Tb_user_account var1);

    public int updateIntegralUserAccountById_user(Tb_user_account var1);

    public Tb_user_account findUserAccountByUser(Integer var1);

    public int createUserAccount_user(Tb_user_account var1);

    public Map<String, Object> findAccountMoneyByCompanyId(Tb_user_account var1);

    public List<Tb_user_account> findTaskUserAccount(@Param(value="sw_company_id") String var1, @Param(value="total") Integer var2);

    public List<Tb_user_account> findUserTaskUserAccount(@Param(value="sw_device_id") String var1, @Param(value="sr_user_task_cycle") String var2);

    public int findCountTaskUserAccount(@Param(value="sw_company_id") String var1);

    public int updateUserAccountById_task(Tb_user_account var1);
}

