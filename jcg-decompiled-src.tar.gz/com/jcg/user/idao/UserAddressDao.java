/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.user.model.Tb_user_address
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.user.idao;

import com.jcg.common.model.Page;
import com.jcg.user.model.Tb_user_address;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserAddressDao {
    public int createAddress(Tb_user_address var1);

    public List<Tb_user_address> findAddressByParam_user(Tb_user_address var1);

    public int findCountByParam_user(Tb_user_address var1);

    public Tb_user_address findAddressById(Integer var1);

    public int updateAddress(Tb_user_address var1);

    public int deleteAddress(Tb_user_address var1);

    public int updateOtherAddressDefault(Tb_user_address var1);

    public Tb_user_address findAddressDefaultByUse(Tb_user_address var1);

    public List<Tb_user_address> findAddressByParam_cpy(@Param(value="fi") Tb_user_address var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(@Param(value="fi") Tb_user_address var1);
}

