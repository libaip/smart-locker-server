/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Page
 *  com.jcg.user.model.Tb_user
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.user.idao;

import com.jcg.common.model.Page;
import com.jcg.user.model.Tb_user;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface UserDao {
    public Tb_user findUserByName(@Param(value="sr_user_name") String var1, @Param(value="sw_company_id") String var2);

    public Tb_user findUserByOpenId(Tb_user var1);

    public Tb_user findUserByAppOpenId(Tb_user var1);

    public Tb_user findUserByUnionId(Tb_user var1);

    public Tb_user findUserByZfbOpenId(Tb_user var1);

    public int createUser(Tb_user var1);

    public Tb_user findUserById(Integer var1);

    public Tb_user findUserCacheById(Integer var1);

    public int updateUserById_user(Tb_user var1);

    public int updateUserForName(Tb_user var1);

    public int updateUserById_agent(Tb_user var1);

    public List<Tb_user> findUserByParam_agent(@Param(value="usr") Tb_user var1, @Param(value="page") Page var2);

    public int findCountByParam_agent(@Param(value="usr") Tb_user var1);

    public Map<String, Object> findCountUserRegistByParam(@Param(value="ua") Tb_user var1, @Param(value="todayZero") String var2, @Param(value="todayEnd") String var3);

    public Map<String, Object> findAdCountUserRegistByParam(@Param(value="ua") Tb_user var1, @Param(value="todayZero") String var2, @Param(value="todayEnd") String var3);

    public Map<String, Object> findUpAdCountUserRegistByParam(@Param(value="ua") Tb_user var1, @Param(value="todayZero") String var2, @Param(value="todayEnd") String var3);

    public List<Tb_user> findUserByNetArr_agent(@Param(value="usr") Tb_user var1, @Param(value="page") Page var2);

    public int findCountByNetArr_agent(@Param(value="usr") Tb_user var1);

    public Map<String, Object> findCountUserRegistByNetArr(@Param(value="ua") Tb_user var1, @Param(value="todayZero") String var2, @Param(value="todayEnd") String var3);

    public List<Tb_user> findUserRegistRptByParam_agent(@Param(value="fi") Tb_user var1);

    public int findSumUserRegistRptByParam_agent(@Param(value="fi") Tb_user var1);

    public Tb_user findUserByWxOpenId(String var1);

    public int findCountByCompanyId(@Param(value="sw_company_id") String var1);

    public List<Tb_user> findUserByParam_cpy(@Param(value="usr") Tb_user var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(@Param(value="usr") Tb_user var1);

    public List<Tb_user> findUserByModeParam_cpy(@Param(value="usr") Tb_user var1, @Param(value="page") Page var2);

    public int findCountByModeParam_cpy(@Param(value="usr") Tb_user var1);

    public int updateUserSubscribe(Tb_user var1);

    public int updateClick(Tb_user var1);
}

