/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.common.model.Page
 *  com.jcg.user.model.Tb_user_recharge
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.user.idao;

import com.jcg.agent.model.Tb_statistics;
import com.jcg.common.model.Page;
import com.jcg.user.model.Tb_user_recharge;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface UserRechargeDao {
    public int createRecharge(Tb_user_recharge var1);

    public List<Tb_user_recharge> findUserRechargeByParam_cpy(@Param(value="fi") Tb_user_recharge var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(Tb_user_recharge var1);

    public Map<String, Object> findSumUserRecharge(@Param(value="sw_company_id") String var1, @Param(value="todayZero") String var2, @Param(value="todayEnd") String var3);

    public List<Map<String, Object>> findDateRechargeMoneyByParam(Tb_statistics var1);

    public Map<String, Object> findSumUserRechargeByCompany(@Param(value="sw_company_id") String var1);

    public int deleteByDeviceId(String var1);

    public Tb_user_recharge findUserRechargeByOrderId(String var1);
}

