/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_statistics
 *  com.jcg.common.model.Page
 *  com.jcg.user.model.Tb_user_withdrawal_appl
 *  org.apache.ibatis.annotations.Param
 */
package com.jcg.user.idao;

import com.jcg.agent.model.Tb_statistics;
import com.jcg.common.model.Page;
import com.jcg.user.model.Tb_user_withdrawal_appl;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface UserWithdrawalApplDao {
    public int createUserWithdrawalAppl(Tb_user_withdrawal_appl var1);

    public List<Tb_user_withdrawal_appl> findUserWithdrawalApplByParam_user(@Param(value="fi") Tb_user_withdrawal_appl var1, @Param(value="page") Page var2);

    public int findCountByParam_user(Tb_user_withdrawal_appl var1);

    public List<Tb_user_withdrawal_appl> findUserWithdrawalApplByParam(Tb_user_withdrawal_appl var1);

    public Tb_user_withdrawal_appl findUserWithdrawalApplById(Integer var1);

    public List<Tb_user_withdrawal_appl> findUserWithdrawalApplByParam_cpy(@Param(value="fi") Tb_user_withdrawal_appl var1, @Param(value="page") Page var2);

    public int findCountByParam_cpy(Tb_user_withdrawal_appl var1);

    public Map<String, Object> findSumUserWithdrawalAppl(@Param(value="sw_company_id") String var1, @Param(value="todayZero") String var2, @Param(value="todayEnd") String var3);

    public Map<String, Object> findSumDSPUserWithdrawalAppl(@Param(value="sw_company_id") String var1, @Param(value="todayZero") String var2, @Param(value="todayEnd") String var3);

    public List<Map<String, Object>> findDateApplMoneyByParam(Tb_statistics var1);

    public int updateUserWithdrawalAppl(Tb_user_withdrawal_appl var1);

    public List<Tb_user_withdrawal_appl> findDSPUserWithdrawalAppl(Integer var1);

    public List<Tb_user_withdrawal_appl> findDSPUserWithdrawalAppl_task();

    public Tb_user_withdrawal_appl findLastUserWithdrawalAppl(Tb_user_withdrawal_appl var1);

    public int updateUserWithdrawalAppl_cpy(Tb_user_withdrawal_appl var1);
}

