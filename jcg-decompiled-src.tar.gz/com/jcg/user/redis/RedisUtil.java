/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.data.redis.core.RedisTemplate
 *  org.springframework.data.redis.core.ZSetOperations$TypedTuple
 *  org.springframework.stereotype.Component
 */
package com.jcg.user.redis;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

@Component
public class RedisUtil<K, V> {
    @Autowired
    private RedisTemplate<K, V> redisTemplate;

    public RedisTemplate<K, V> getInstance() {
        return this.redisTemplate;
    }

    public void set(K key, V value) {
        this.redisTemplate.opsForValue().set(key, value);
    }

    public K get(K key) {
        return (K)this.redisTemplate.opsForValue().get(key);
    }

    public void setForTimeMS(K key, V value, long time) {
        this.redisTemplate.opsForValue().set(key, value, time, TimeUnit.MILLISECONDS);
    }

    public void setForTimeMIN(K key, V value, long time) {
        this.redisTemplate.opsForValue().set(key, value, time, TimeUnit.MINUTES);
    }

    public void setForTimeCustom(K key, V value, long time, TimeUnit type) {
        this.redisTemplate.opsForValue().set(key, value, time, type);
    }

    public V getAndSet(K key, V value) {
        return (V)this.redisTemplate.opsForValue().getAndSet(key, value);
    }

    public void batchSet(Map<K, V> keyAndValue) {
        this.redisTemplate.opsForValue().multiSet(keyAndValue);
    }

    public void batchSetIfAbsent(Map<K, V> keyAndValue) {
        this.redisTemplate.opsForValue().multiSetIfAbsent(keyAndValue);
    }

    public Long increment(K key, long number) {
        return this.redisTemplate.opsForValue().increment(key, number);
    }

    public Double increment(K key, double number) {
        return this.redisTemplate.opsForValue().increment(key, number);
    }

    public boolean expire(K key, long time, TimeUnit type) {
        return this.redisTemplate.boundValueOps(key).expire(time, type);
    }

    public boolean persist(K key) {
        return this.redisTemplate.boundValueOps(key).persist();
    }

    public Long getExpire(K key) {
        return this.redisTemplate.boundValueOps(key).getExpire();
    }

    public void rename(K key, K newKey) {
        this.redisTemplate.boundValueOps(key).rename(newKey);
    }

    public void delete(K key) {
        this.redisTemplate.delete(key);
    }

    public void put(K key, Object hashKey, V value) {
        this.redisTemplate.opsForHash().put(key, hashKey, value);
    }

    public void putAll(K key, Map<K, V> map) {
        this.redisTemplate.opsForHash().putAll(key, map);
    }

    public boolean putIfAbsent(K key, Object hashKey, V value) {
        return this.redisTemplate.opsForHash().putIfAbsent(key, hashKey, value);
    }

    public Long delete(K key, Object ... hashKeys) {
        return this.redisTemplate.opsForHash().delete(key, hashKeys);
    }

    public Long increment(K key, Object hashKey, long number) {
        return this.redisTemplate.opsForHash().increment(key, hashKey, number);
    }

    public Double increment(K key, Object hashKey, Double number) {
        return this.redisTemplate.opsForHash().increment(key, hashKey, number.doubleValue());
    }

    public Object getHashKey(K key, Object hashKey) {
        return this.redisTemplate.opsForHash().get(key, hashKey);
    }

    public Map<Object, Object> getHashEntries(K key) {
        return this.redisTemplate.opsForHash().entries(key);
    }

    public boolean hashKey(K key, Object hashKey) {
        return this.redisTemplate.opsForHash().hasKey(key, hashKey);
    }

    public Set<Object> hashKeys(K key) {
        return this.redisTemplate.opsForHash().keys(key);
    }

    public Long hashSize(K key) {
        return this.redisTemplate.opsForHash().size(key);
    }

    public Long leftPush(K key, V value) {
        return this.redisTemplate.opsForList().leftPush(key, value);
    }

    public Object leftPop(K key) {
        return this.redisTemplate.opsForList().leftPop(key);
    }

    public Long leftPushAll(K key, Collection<V> values) {
        return this.redisTemplate.opsForList().leftPushAll(key, values);
    }

    public Long rightPush(K key, V value) {
        return this.redisTemplate.opsForList().rightPush(key, value);
    }

    public V rightPop(K key) {
        return (V)this.redisTemplate.opsForList().rightPop(key);
    }

    public Long rightPushAll(K key, Collection<V> values) {
        return this.redisTemplate.opsForList().rightPushAll(key, values);
    }

    public V index(K key, long index) {
        return (V)this.redisTemplate.opsForList().index(key, index);
    }

    public Long listSize(K key) {
        return this.redisTemplate.opsForList().size(key);
    }

    public List<V> listRange(K key, long start, long end) {
        return this.redisTemplate.opsForList().range(key, start, end);
    }

    public Long listRemove(K key, long count, V value) {
        return this.redisTemplate.opsForList().remove(key, count, value);
    }

    public void listTrim(K key, long start, long end) {
        this.redisTemplate.opsForList().trim(key, start, end);
    }

    public Object rightPopAndLeftPush(K key, K key2) {
        return this.redisTemplate.opsForList().rightPopAndLeftPush(key, key2);
    }

    public Long add(K key, V ... values) {
        return this.redisTemplate.opsForSet().add(key, (Object[])values);
    }

    public Set<V> difference(K key, K otherkey) {
        return this.redisTemplate.opsForSet().difference(key, otherkey);
    }

    public Set<V> difference(K key, Collection<K> otherKeys) {
        return this.redisTemplate.opsForSet().difference(key, otherKeys);
    }

    public Long differenceAndStore(K key, K otherkey, K newKey) {
        return this.redisTemplate.opsForSet().differenceAndStore(key, otherkey, newKey);
    }

    public Long differenceAndStore(K key, Collection<K> otherKeys, K newKey) {
        return this.redisTemplate.opsForSet().differenceAndStore(newKey, otherKeys, newKey);
    }

    public Long remove(K key, Object ... values) {
        return this.redisTemplate.opsForSet().remove(key, values);
    }

    public Object randomSetPop(K key) {
        return this.redisTemplate.opsForSet().pop(key);
    }

    public Object randomSet(K key) {
        return this.redisTemplate.opsForSet().randomMember(key);
    }

    public List<V> randomSet(K key, long count) {
        return this.redisTemplate.opsForSet().randomMembers(key, count);
    }

    public Set<V> randomSetDistinct(K key, long count) {
        return this.redisTemplate.opsForSet().distinctRandomMembers(key, count);
    }

    public boolean moveSet(K key, V value, K destKey) {
        return this.redisTemplate.opsForSet().move(key, value, destKey);
    }

    public Long setSize(K key) {
        return this.redisTemplate.opsForSet().size(key);
    }

    public boolean isMember(K key, V value) {
        return this.redisTemplate.opsForSet().isMember(key, value);
    }

    public Set<V> unionSet(K key, K otherKey) {
        return this.redisTemplate.opsForSet().union(key, otherKey);
    }

    public Set<V> unionSet(K key, Collection<K> otherKeys) {
        return this.redisTemplate.opsForSet().union(key, otherKeys);
    }

    public Long unionAndStoreSet(K key, K otherKey, K destKey) {
        return this.redisTemplate.opsForSet().unionAndStore(key, otherKey, destKey);
    }

    public Long unionAndStoreSet(K key, Collection<K> otherKeys, K destKey) {
        return this.redisTemplate.opsForSet().unionAndStore(key, otherKeys, destKey);
    }

    public Set<V> members(K key) {
        return this.redisTemplate.opsForSet().members(key);
    }

    public boolean add(K key, V value, double score) {
        return this.redisTemplate.opsForZSet().add(key, value, score);
    }

    public Long batchAddZset(K key, Set<ZSetOperations.TypedTuple<V>> tuples) {
        return this.redisTemplate.opsForZSet().add(key, tuples);
    }

    public Long removeZset(K key, V ... values) {
        return this.redisTemplate.opsForZSet().remove(key, (Object[])values);
    }

    public Double incrementScore(K key, V value, double score) {
        return this.redisTemplate.opsForZSet().incrementScore(key, value, score);
    }

    public Long rank(K key, V value) {
        return this.redisTemplate.opsForZSet().rank(key, value);
    }

    public Long reverseRank(K key, V value) {
        return this.redisTemplate.opsForZSet().reverseRank(key, value);
    }

    public Set<ZSetOperations.TypedTuple<V>> rangeWithScores(K key, long start, long end) {
        return this.redisTemplate.opsForZSet().rangeWithScores(key, start, end);
    }

    public Set<V> range(K key, long start, long end) {
        return this.redisTemplate.opsForZSet().range(key, start, end);
    }

    public Set<V> rangeByScore(K key, double min, double max) {
        return this.redisTemplate.opsForZSet().rangeByScore(key, min, max);
    }

    public Set<ZSetOperations.TypedTuple<V>> rangeByScoreWithScores(K key, double min, double max) {
        return this.redisTemplate.opsForZSet().rangeByScoreWithScores(key, min, max);
    }

    public Set<V> rangeByScore(K key, double min, double max, long offset, long count) {
        return this.redisTemplate.opsForZSet().rangeByScore(key, min, max, offset, count);
    }

    public Set<ZSetOperations.TypedTuple<V>> rangeByScoreWithScores(K key, double min, double max, long offset, long count) {
        return this.redisTemplate.opsForZSet().rangeByScoreWithScores(key, min, max, offset, count);
    }

    public Set<V> reverseRange(K key, long start, long end) {
        return this.redisTemplate.opsForZSet().reverseRange(key, start, end);
    }

    public Set<ZSetOperations.TypedTuple<V>> reverseRangeWithScores(K key, long start, long end) {
        return this.redisTemplate.opsForZSet().reverseRangeWithScores(key, start, end);
    }

    public Set<V> reverseRangeByScore(K key, double min, double max) {
        return this.redisTemplate.opsForZSet().reverseRangeByScore(key, min, max);
    }

    public Set<ZSetOperations.TypedTuple<V>> reverseRangeByScoreWithScores(K key, double min, double max) {
        return this.redisTemplate.opsForZSet().reverseRangeByScoreWithScores(key, min, max);
    }

    public Set<V> reverseRangeByScore(K key, double min, double max, long offset, long count) {
        return this.redisTemplate.opsForZSet().reverseRangeByScore(key, min, max, offset, count);
    }

    public Set<ZSetOperations.TypedTuple<V>> reverseRangeByScoreWithScores(K key, double min, double max, long offset, long count) {
        return this.redisTemplate.opsForZSet().reverseRangeByScoreWithScores(key, min, max, offset, count);
    }

    public long countZSet(K key, double min, double max) {
        return this.redisTemplate.opsForZSet().count(key, min, max);
    }

    public long sizeZset(K key) {
        return this.redisTemplate.opsForZSet().size(key);
    }

    public Double score(K key, V value) {
        return this.redisTemplate.opsForZSet().score(key, value);
    }

    public Long removeRange(K key, long start, long end) {
        return this.redisTemplate.opsForZSet().removeRange(key, start, end);
    }

    public Long removeRangeByScore(K key, double min, double max) {
        return this.redisTemplate.opsForZSet().removeRangeByScore(key, min, max);
    }

    public Long unionAndStoreZset(K key, K otherKey, K destKey) {
        return this.redisTemplate.opsForZSet().unionAndStore(key, otherKey, destKey);
    }

    public Long unionAndStoreZset(K key, Collection<K> otherKeys, K destKey) {
        return this.redisTemplate.opsForZSet().unionAndStore(key, otherKeys, destKey);
    }

    public Long intersectAndStore(K key, K otherKey, K destKey) {
        return this.redisTemplate.opsForZSet().intersectAndStore(key, otherKey, destKey);
    }

    public Long intersectAndStore(K key, Collection<K> otherKeys, K destKey) {
        return this.redisTemplate.opsForZSet().intersectAndStore(key, otherKeys, destKey);
    }
}

