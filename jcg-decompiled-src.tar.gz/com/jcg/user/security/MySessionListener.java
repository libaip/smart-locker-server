/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  javax.servlet.http.HttpSessionEvent
 *  javax.servlet.http.HttpSessionListener
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jcg.user.security;

import com.jcg.common.model.Identifier;
import com.jcg.user.service.UserServiceImpl;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MySessionListener
implements HttpSessionListener {
    protected final Logger log = LoggerFactory.getLogger(this.getClass());
    private UserServiceImpl userService = new UserServiceImpl();
    private Identifier identifier = new Identifier();

    public void sessionCreated(HttpSessionEvent event) {
        this.log.debug("*******************************************************\u521b\u5efatreasurerSession*************************************");
    }

    public void sessionDestroyed(HttpSessionEvent se) {
        this.log.debug("*******************************************************\u9500\u6bc1treasurerSession*************************************");
    }
}

