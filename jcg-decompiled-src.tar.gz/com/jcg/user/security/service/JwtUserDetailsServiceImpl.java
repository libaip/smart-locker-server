/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.user.model.Tb_user
 *  org.springframework.security.core.authority.SimpleGrantedAuthority
 *  org.springframework.security.core.userdetails.UserDetailsService
 *  org.springframework.security.core.userdetails.UsernameNotFoundException
 */
package com.jcg.user.security.service;

import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.user.model.Tb_user;
import com.jcg.user.service.UserServiceImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class JwtUserDetailsServiceImpl
implements UserDetailsService {
    UserServiceImpl userService = new UserServiceImpl();

    public Tb_user loadUserByUsername(String key) throws UsernameNotFoundException {
        HashMap<String, Object> param = new HashMap<String, Object>();
        Tb_user temp = new Tb_user();
        temp.setSd_user_id(Integer.valueOf(XcbStringUtils.getObjtoint((Object)key)));
        param.put("user", temp);
        Tb_user user = null;
        try {
            Map<String, Object> ret = this.userService.findUserCacheById(param);
            Map dataMap = (Map)ret.get(XcbConstantValue.DATA);
            user = (Tb_user)dataMap.get("user");
            if (user != null) {
                ArrayList<SimpleGrantedAuthority> authList = new ArrayList<SimpleGrantedAuthority>();
                authList.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
                user.setUserInfoRoles(authList);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }
}

