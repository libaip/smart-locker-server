/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_advice_user
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.model.Tb_advice_user;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class AdviceUserServiceImpl
extends BaseService {
    public Map<String, Object> createAdviceUser(Identifier identifier, Tb_advice_user adviceUser) {
        identifier.setFunctionCode(XcbConstantValue.ADVICEUSER_CREATE_USER);
        HashMap<String, Tb_advice_user> param = new HashMap<String, Tb_advice_user>();
        param.put("adviceUser", adviceUser);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAdviceUserById(Identifier identifier, String sw_user_id, Page page) {
        identifier.setFunctionCode(XcbConstantValue.ADVICEUSER_FINDBYID_USER);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sw_user_id", sw_user_id);
        param.put("page", (String)page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> deleteById(Identifier identifier, String id) {
        identifier.setFunctionCode(XcbConstantValue.ADVICEUSER_DELETE);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("id", id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

