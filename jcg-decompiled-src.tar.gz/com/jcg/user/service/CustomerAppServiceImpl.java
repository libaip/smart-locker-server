/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_customer_app
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.model.Tb_customer_app;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class CustomerAppServiceImpl
extends BaseService {
    public Map<String, Object> createCustomerApp(Identifier identifier, Tb_customer_app customer_app) {
        identifier.setFunctionCode(XcbConstantValue.CUSTOMERAPP_CREATE_USER);
        HashMap<String, Tb_customer_app> param = new HashMap<String, Tb_customer_app>();
        param.put("customer_app", customer_app);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

