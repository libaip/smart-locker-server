/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.user.common.BaseService;
import com.jcg.user.redis.RedisUtil;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DeviceBoxServiceImpl
extends BaseService {
    @Autowired
    private RedisUtil redis;

    public Map<String, Object> findDeviceBoxDefault(Identifier identifier, String si_mainboard_id, String sr_box_type) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_FIND_BYMID_DEFAULT);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("si_mainboard_id", si_mainboard_id);
        param.put("sr_box_type", sr_box_type);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDeviceBoxByParam(Identifier identifier, String si_mainboard_id, String sr_box_type) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_FIND_BYPARAM_USER);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("si_mainboard_id", si_mainboard_id);
        param.put("sr_box_type", sr_box_type);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateDeviceBox(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_UPDATE_BYID_USER);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDeviceBoxById(Identifier identifier, Integer sd_box_id) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_BOX_FIND_BYID_USER);
        HashMap<String, Integer> param = new HashMap<String, Integer>();
        param.put("sd_box_id", sd_box_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> cancelDeviceBox(Integer sd_user_id, Integer sd_box_id) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String userid = XcbStringUtils.getObjtoString((Object)this.redis.get(XcbConstantValue.DEVICE_BOX_CACHE + sd_box_id));
        if (!XcbStringUtils.isNullOrBlank((Object)userid) && userid.equals(XcbStringUtils.getObjtoString((Object)sd_user_id))) {
            this.redis.delete(XcbConstantValue.DEVICE_BOX_CACHE + sd_box_id);
        }
        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        return ret;
    }
}

