/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.agent.model.Tb_device_box;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DeviceCloudServiceImpl
extends BaseService {
    public Map<String, Object> openLock(Identifier identifier, Integer sw_user_id, Tb_device_box deviceBox, String sw_order_id, String sr_type, String sr_remarks) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_OPENLOCK);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("userid", sw_user_id);
        param.put("deviceBox", deviceBox);
        param.put("sw_order_id", sw_order_id);
        param.put("sr_type", sr_type);
        param.put("sr_remarks", sr_remarks);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> checkDeviceStatus(Identifier identifier, Tb_device_box deviceBox) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_CLOUD_CHECK_STATUS);
        HashMap<String, Tb_device_box> param = new HashMap<String, Tb_device_box>();
        param.put("deviceBox", deviceBox);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

