/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.agent.model.Tb_device_package;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DevicePackageServiceImpl
extends BaseService {
    public Map<String, Object> findDevicePackageById(Identifier identifier, Tb_device_package devicePackage) throws Exception {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_PACKAGE_FIND_BYID);
        HashMap<String, Tb_device_package> param = new HashMap<String, Tb_device_package>();
        param.put("devicePackage", devicePackage);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

