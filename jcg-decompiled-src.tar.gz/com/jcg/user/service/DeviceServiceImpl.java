/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DeviceServiceImpl
extends BaseService {
    public Map<String, Object> findDeviceByMid(Identifier identifier, String sw_user_id, String si_mainboard_id, String sw_device_id, String sr_type) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FIND_BYMID_USER);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sw_user_id", sw_user_id);
        param.put("si_mainboard_id", si_mainboard_id);
        param.put("sw_device_id", sw_device_id);
        param.put("sr_type", sr_type);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDeviceByDeviceId(String sr_open_id, String sw_device_id) {
        Identifier identifier = new Identifier();
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FIND_BYDEVICE_USER);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sr_open_id", sr_open_id);
        param.put("sw_device_id", sw_device_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findDeviceByQrCode(Identifier identifier, String sw_user_id, String sr_wx_qr_code) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_FIND_BYQRCODE_USER);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sw_user_id", sw_user_id);
        param.put("sr_wx_qr_code", sr_wx_qr_code);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

