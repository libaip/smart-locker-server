/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_devicelogs
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.agent.model.Tb_devicelogs;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class DeviceServiceLogsImpl
extends BaseService {
    public Map<String, Object> checkDeviceLogs(Identifier identifier, Tb_devicelogs deviceLogs) {
        identifier.setFunctionCode(XcbConstantValue.DEVICE_LOGS_CHECK);
        HashMap<String, Tb_devicelogs> param = new HashMap<String, Tb_devicelogs>();
        param.put("deviceLogs", deviceLogs);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

