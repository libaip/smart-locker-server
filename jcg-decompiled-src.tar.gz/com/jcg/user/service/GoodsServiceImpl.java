/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_goods
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.model.Tb_goods;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class GoodsServiceImpl
extends BaseService {
    public Map<String, Object> findGoodsByParam(Identifier identifier, Tb_goods goods, Page page) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_FIND_BYPARAM_USER);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("goods", goods);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAllCates(Identifier identifier) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_CATEGORY_ALL_CPY);
        HashMap param = new HashMap();
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findGoodsById(Identifier identifier, Integer sd_id) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_FIND_BYID);
        HashMap<String, Integer> param = new HashMap<String, Integer>();
        param.put("sd_id", sd_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findGoodsByIdArr(Identifier identifier, Integer[] idArr) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_FIND_BYIDARR);
        HashMap<String, Integer[]> param = new HashMap<String, Integer[]>();
        param.put("idArr", idArr);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findGoodsCart(Identifier identifier, Tb_goods goods, Page page) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_FIND_CART_USER);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("goods", goods);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateGoodsCart(Identifier identifier, Tb_goods goods) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_UPDATE_CART_USER);
        HashMap<String, Tb_goods> param = new HashMap<String, Tb_goods>();
        param.put("goods", goods);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> removeGoodsCart(Identifier identifier, Tb_goods goods) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_REMOVE_CART_USER);
        HashMap<String, Tb_goods> param = new HashMap<String, Tb_goods>();
        param.put("goods", goods);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> removeAllGoodsCart(Identifier identifier, Tb_goods goods) {
        identifier.setFunctionCode(XcbConstantValue.GOODS_REMOVE_ALL_CART_USER);
        HashMap<String, Tb_goods> param = new HashMap<String, Tb_goods>();
        param.put("goods", goods);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

