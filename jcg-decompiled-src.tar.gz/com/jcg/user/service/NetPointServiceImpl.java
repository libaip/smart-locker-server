/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class NetPointServiceImpl
extends BaseService {
    public Map<String, Object> findNetPointByMid(Identifier identifier, String si_mainboard_id) {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_FIND_BYMID_USER);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("si_mainboard_id", si_mainboard_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findNetInfoByMid(Identifier identifier, String si_mainboard_id) {
        identifier.setFunctionCode(XcbConstantValue.NETPOINT_FIND_INFO_BYMID_USER);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("si_mainboard_id", si_mainboard_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

