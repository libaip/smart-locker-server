/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_opendoor_record
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.agent.model.Tb_opendoor_record;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class OpenDoorRecordServiceImpl
extends BaseService {
    public Map<String, Object> createOpenDoorRecord(Identifier identifier, Tb_opendoor_record record) {
        identifier.setFunctionCode(XcbConstantValue.OPEN_DOOR_RECORD_CREATE);
        HashMap<String, Tb_opendoor_record> param = new HashMap<String, Tb_opendoor_record>();
        param.put("openDoorRecord", record);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

