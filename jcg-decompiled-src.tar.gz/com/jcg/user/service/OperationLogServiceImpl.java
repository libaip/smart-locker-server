/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_operation_logs
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class OperationLogServiceImpl
extends BaseService {
    public Map<String, Object> createOperaLog(Identifier identifier, Tb_operation_logs operaLog) throws Exception {
        HashMap<String, Object> ret = new HashMap();
        HashMap<String, Tb_operation_logs> param_map = new HashMap<String, Tb_operation_logs>();
        param_map.put("operationlogs", operaLog);
        identifier.setFunctionCode(XcbConstantValue.OPERA_CREATE);
        ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }
}

