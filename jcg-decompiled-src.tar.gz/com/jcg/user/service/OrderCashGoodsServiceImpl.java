/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class OrderCashGoodsServiceImpl
extends BaseService {
    public Map<String, Object> findOrderCashGoodsById(Identifier identifier, Integer sd_cash_id) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_CASH_GOODS_FIND_BYID);
        HashMap<String, Integer> param = new HashMap<String, Integer>();
        param.put("sd_cash_id", sd_cash_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

