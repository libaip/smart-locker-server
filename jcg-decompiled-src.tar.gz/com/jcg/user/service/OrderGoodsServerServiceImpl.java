/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_ordergoods_server
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.model.Tb_ordergoods_server;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class OrderGoodsServerServiceImpl
extends BaseService {
    public Map<String, Object> createOrderServer(Identifier identifier, Tb_ordergoods_server server) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_GOODS_SERVER_CREATE);
        HashMap<String, Tb_ordergoods_server> param = new HashMap<String, Tb_ordergoods_server>();
        param.put("server", server);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderGoodsServerById(Identifier identifier, Tb_ordergoods_server server) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_GOODS_SERVER_FIND_BYID);
        HashMap<String, Tb_ordergoods_server> param = new HashMap<String, Tb_ordergoods_server>();
        param.put("server", server);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

