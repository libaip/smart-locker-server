/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_order_goods
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class OrderGoodsServiceImpl
extends BaseService {
    public Map<String, Object> createOrderGoods(Identifier identifier, Tb_order_goods order) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_GOODS_CREATE);
        HashMap<String, Tb_order_goods> param = new HashMap<String, Tb_order_goods>();
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderGoodsById(Identifier identifier, String sd_order_id) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_GOODS_FIND_BYID);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_order_id", sd_order_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderGoodsByParam(Identifier identifier, Tb_order_goods order, Page page) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_GOODS_FIND_BYPARAM_USER);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> closeOrder(Identifier identifier, Tb_order_goods order) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_GOODS_CLOSE);
        HashMap<String, Tb_order_goods> param = new HashMap<String, Tb_order_goods>();
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateOrderGoods(Identifier identifier, Tb_order_goods order) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_GOODS_UPDATE);
        HashMap<String, Tb_order_goods> param = new HashMap<String, Tb_order_goods>();
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

