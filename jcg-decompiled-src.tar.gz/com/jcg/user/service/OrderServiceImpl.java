/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl
extends BaseService {
    public Map<String, Object> orderPayNotify(Identifier identifier, String out_trade_no, BigDecimal dc_actual_income, String transaction_id, String channelTransNo, String attach) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_PAYNOTIFY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("out_trade_no", out_trade_no);
        param.put("dc_actual_income", dc_actual_income);
        param.put("transaction_id", transaction_id);
        param.put("channelTransNo", channelTransNo);
        param.put("attach", attach);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> orderTemporaryPayNotify(Identifier identifier, String out_trade_no, BigDecimal dc_actual_income, String transaction_id, String attach) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_TEMPORARY_PAYNOTIFY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("out_trade_no", out_trade_no);
        param.put("dc_actual_income", dc_actual_income);
        param.put("transaction_id", transaction_id);
        param.put("attach", attach);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> orderFinishPayNotify(Identifier identifier, String out_trade_no, BigDecimal dc_actual_income, String transaction_id, String attach) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FINISH_PAYNOTIFY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("out_trade_no", out_trade_no);
        param.put("dc_actual_income", dc_actual_income);
        param.put("transaction_id", transaction_id);
        param.put("attach", attach);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> zhPayEvent(Identifier identifier, Tb_order order, Integer sd_id) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_ZHPAYEVENT);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("sd_id", sd_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderByParam(Identifier identifier, Tb_order order, Page page) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYPARAM_USER);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("page", page);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderById(Identifier identifier, String sd_order_id) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYID_USER);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_order_id", sd_order_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> finishOrderForAccount(Identifier identifier, Tb_order order, BigDecimal totalMoney) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FOR_ACCOUNT);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("totalMoney", totalMoney);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> temporaryOrderForAccount(Identifier identifier, Tb_order order, BigDecimal totalMoney) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_TEMPORARY_FOR_ACCOUNT);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("totalMoney", totalMoney);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> finishOrderForRecharge(Identifier identifier, Tb_order order, BigDecimal totalMoney) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FOR_RECHARGE);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("totalMoney", totalMoney);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> closeOrder(Identifier identifier, String sd_order_id) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_CLOSE);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_order_id", sd_order_id);
        param.put("sr_type", "");
        param.put("sr_way", "USER");
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> tkNotify(Identifier identifier, String sd_ordercash_id, String refund_fee, String sd_cash_id) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_TKNOTIFY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_ordercash_id", sd_ordercash_id);
        param.put("refund_fee", refund_fee);
        param.put("sd_cash_id", sd_cash_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> autoTkNotify(Identifier identifier, String sd_ordercash_id, String refund_fee, String sd_cash_id) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_AUTO_TKNOTIFY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_ordercash_id", sd_ordercash_id);
        param.put("refund_fee", refund_fee);
        param.put("sd_cash_id", sd_cash_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> finishOrder(Identifier identifier, Tb_order order, String sr_way) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FINISH);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("sr_way", sr_way);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> checkPayNotifyInfo(String sd_ordercash_id, String sw_order_id) {
        Identifier identifier = new Identifier();
        identifier.setFunctionCode(XcbConstantValue.ORDER_CHECK_PAYNOTIFY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_ordercash_id", sd_ordercash_id);
        param.put("sd_order_id", sw_order_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> checkOrderGoods(String sd_order_id, String sw_bus_order_id) {
        Identifier identifier = new Identifier();
        identifier.setFunctionCode(XcbConstantValue.ORDER_GOODS_CHECK_PAYNOTIFY);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_order_id", sd_order_id);
        param.put("sw_bus_order_id", sw_bus_order_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderByUser(Identifier identifier, Tb_order order) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYUSER);
        HashMap<String, Tb_order> param = new HashMap<String, Tb_order>();
        param.put("order", order);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderByLast(Identifier identifier, Tb_order order, String type) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYLAST);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("type", type);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findOrderById_finish(Identifier identifier, String sd_order_id) {
        identifier.setFunctionCode(XcbConstantValue.ORDER_FIND_BYID_USER_FINISH);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("sd_order_id", sd_order_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

