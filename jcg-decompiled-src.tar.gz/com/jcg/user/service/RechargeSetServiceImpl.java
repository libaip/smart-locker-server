/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_recharge_set
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.agent.model.Tb_recharge_set;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class RechargeSetServiceImpl
extends BaseService {
    public Map<String, Object> findRechargeSetByParam(Identifier identifier, Tb_recharge_set rechargeSet) {
        identifier.setFunctionCode(XcbConstantValue.RECHARGESET_FIND_BYPARAM);
        HashMap<String, Tb_recharge_set> param = new HashMap<String, Tb_recharge_set>();
        param.put("rechargeSet", rechargeSet);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

