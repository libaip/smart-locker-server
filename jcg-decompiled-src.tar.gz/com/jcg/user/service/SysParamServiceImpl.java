/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.company.model.Tb_wx_pay_info
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.common.BaseService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class SysParamServiceImpl
extends BaseService {
    public Map<String, Object> getDropDownSelectDataByCate(Identifier identifier, String sr_category_code) {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_BYCATE);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_category_code", sr_category_code);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        return ret;
    }

    public Tb_wx_info findWxInfoByCode(Identifier identifier, String sr_code) {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_WX_INFO_BYCODE);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_code", sr_code);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        Tb_wx_info info = (Tb_wx_info)ret.get(XcbConstantValue.DATA);
        return info;
    }

    public Tb_wx_pay_info findWxInfoByMchId(Identifier identifier, String sr_mchid) {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_WX_INFO_BYMCHID);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_mchid", sr_mchid);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        Tb_wx_pay_info info = (Tb_wx_pay_info)ret.get(XcbConstantValue.DATA);
        return info;
    }

    public Tb_wx_info findWxOutInfoByCode(Identifier identifier, String sr_code) {
        identifier.setFunctionCode(XcbConstantValue.SYSPARAM_FIND_WX_OUT_INFO_BYCODE);
        HashMap<String, String> param_map = new HashMap<String, String>();
        param_map.put("sr_code", sr_code);
        Map ret = this.genericCaller.genericCall(identifier, param_map);
        Tb_wx_info info = (Tb_wx_info)ret.get(XcbConstantValue.DATA);
        return info;
    }
}

