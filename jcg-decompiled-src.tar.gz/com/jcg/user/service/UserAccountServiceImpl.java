/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.user.model.Tb_user_account
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import com.jcg.user.model.Tb_user_account;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class UserAccountServiceImpl
extends BaseService {
    public Map<String, Object> findUserAccountByUser(Identifier identifier, Tb_user_account userAccount) {
        HashMap<String, Tb_user_account> param = new HashMap<String, Tb_user_account>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USERACCOUNT_FIND_BYUSER);
        param.put("userAccount", userAccount);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

