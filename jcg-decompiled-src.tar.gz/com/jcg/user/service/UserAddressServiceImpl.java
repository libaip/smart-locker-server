/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.user.model.Tb_user_address
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import com.jcg.user.model.Tb_user_address;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class UserAddressServiceImpl
extends BaseService {
    public Map<String, Object> findAddressByParam(Identifier identifier, Tb_user_address address) {
        identifier.setFunctionCode(XcbConstantValue.USER_ADDRESS_FIND_BYPARAM);
        HashMap<String, Tb_user_address> param = new HashMap<String, Tb_user_address>();
        param.put("address", address);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAddressById(Identifier identifier, Tb_user_address address) {
        identifier.setFunctionCode(XcbConstantValue.USER_ADDRESS_FIND_BYID);
        HashMap<String, Tb_user_address> param = new HashMap<String, Tb_user_address>();
        param.put("address", address);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createAddress(Identifier identifier, Tb_user_address address) {
        identifier.setFunctionCode(XcbConstantValue.USER_ADDRESS_CREATE);
        HashMap<String, Tb_user_address> param = new HashMap<String, Tb_user_address>();
        param.put("address", address);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateAddress(Identifier identifier, Tb_user_address address) {
        identifier.setFunctionCode(XcbConstantValue.USER_ADDRESS_UPDATE);
        HashMap<String, Tb_user_address> param = new HashMap<String, Tb_user_address>();
        param.put("address", address);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> deleteAddress(Identifier identifier, Tb_user_address address) {
        identifier.setFunctionCode(XcbConstantValue.USER_ADDRESS_DELETE);
        HashMap<String, Tb_user_address> param = new HashMap<String, Tb_user_address>();
        param.put("address", address);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findAddressDefaultByUse(Identifier identifier, Tb_user_address address) {
        identifier.setFunctionCode(XcbConstantValue.USER_ADDRESS_FIND_DEFAULT);
        HashMap<String, Tb_user_address> param = new HashMap<String, Tb_user_address>();
        param.put("address", address);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

