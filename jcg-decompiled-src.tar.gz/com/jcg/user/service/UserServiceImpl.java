/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.user.model.Tb_user
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import com.jcg.user.model.Tb_user;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl
extends BaseService {
    public Map<String, Object> findUserCacheById(Map<String, Object> param) throws Exception {
        HashMap<String, Object> ret = new HashMap();
        Identifier identifier = new Identifier();
        identifier.setFunctionCode(XcbConstantValue.USER_FIND_CACHE_BYID);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findUserByUsername(Map<String, Object> param) throws Exception {
        HashMap<String, Object> ret = new HashMap();
        Identifier identifier = new Identifier();
        identifier.setFunctionCode(XcbConstantValue.USER_FIND_BYNAME);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> loginWithOpenId(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_FIND_BY_OPENID);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> loginWithAppOpenId(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_FIND_BY_APP_OPENID);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> loginWithUnionId(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_FIND_BY_UNIONID);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> loginWithZfbOpenId(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_FIND_BY_ZFB_OPENID);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createUser(Identifier identifier, Tb_user user, String si_mainboard_id, String sw_device_id) {
        HashMap<String, Object> param = new HashMap<String, Object>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_CREATE);
        param.put("user", user);
        param.put("si_mainboard_id", si_mainboard_id);
        param.put("sw_device_id", sw_device_id);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findUserByUserId(Identifier identifier, Tb_user user) throws Exception {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_FIND_BYID);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateUserById(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_UPDATE_BYID_USER);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateUserSubscribe(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_UPDATE_SUBSCRIBE_USER);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> updateZfbUserById(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_UPDATE_BYID_ZFBUSER);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> checkUser(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        identifier.setFunctionCode(XcbConstantValue.USER_CHECK);
        param.put("user", user);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> checkWxUser(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        identifier.setFunctionCode(XcbConstantValue.USER_CHECK_WX);
        param.put("user", user);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createWxUser(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_CREATE_WX);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> sendTest(Identifier identifier, Tb_user user) {
        HashMap<String, Integer> param = new HashMap<String, Integer>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.WX_MESSAGE_SEND);
        param.put("sw_user_id", user.getSd_user_id());
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> getUnionId(Identifier identifier, Tb_user user) {
        HashMap<String, Tb_user> param = new HashMap<String, Tb_user>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_GET_UNIONID);
        param.put("user", user);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

