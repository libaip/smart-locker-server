/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.user.model.Tb_user_withdrawal_appl
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.service;

import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.common.BaseService;
import com.jcg.user.model.Tb_user_withdrawal_appl;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class UserWithdrawalApplServiceImpl
extends BaseService {
    public Map<String, Object> findUserWithdrawalApplByParam(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl, Page page) {
        HashMap<String, Object> param = new HashMap<String, Object>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_WITHDRAWAL_APPL_FIND_BYPARAM);
        param.put("userWithdrawalAppl", userWithdrawalAppl);
        param.put("page", page);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> payToUser(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl) {
        HashMap<String, Object> param = new HashMap<String, Object>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_WITHDRAWAL_APPL_MAIN);
        param.put("userWithdrawalAppl", userWithdrawalAppl);
        param.put("sr_way", "USER");
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> findLastUserWithdrawalAppl(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl) {
        HashMap<String, Tb_user_withdrawal_appl> param = new HashMap<String, Tb_user_withdrawal_appl>();
        HashMap<String, Object> ret = new HashMap();
        identifier.setFunctionCode(XcbConstantValue.USER_WITHDRAWAL_FIND_LAST);
        param.put("userWithdrawalAppl", userWithdrawalAppl);
        ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

