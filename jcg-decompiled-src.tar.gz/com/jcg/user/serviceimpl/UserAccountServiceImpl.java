/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.agent.model.Tb_recharge_set
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.user.model.Tb_user_account
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Propagation
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.user.serviceimpl;

import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.model.Tb_recharge_set;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.user.idao.UserAccountDao;
import com.jcg.user.model.Tb_user_account;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserAccountServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private UserAccountDao userAccountDao;
    @Autowired
    private CommonLogic commonLogic;
    @Autowired
    private OrderDao orderDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        Tb_user_account userAccount = new Tb_user_account();
        Page page = new Page();
        if (param != null) {
            userAccount = (Tb_user_account)param.get("userAccount");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.USERACCOUNT_FIND_BYUSER.equals(functionCode)) {
                ret = this.findUserAccountByUser(identifier, userAccount);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findUserAccountByUser(Identifier identifier, Tb_user_account userAccount) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Tb_user_account> dataMap = new HashMap<String, Tb_user_account>();
        int result = 0;
        String msg = "";
        try {
            Tb_user_account userAccount_new = this.userAccountDao.findUserAccountByUser(userAccount.getSw_user_id());
            if (userAccount_new != null) {
                userAccount_new.setDc_account_money_sum(BigDecimalUtil.add((BigDecimal)userAccount_new.getDc_account_money(), (BigDecimal)userAccount_new.getDc_present_money()));
                dataMap.put("userAccount", userAccount_new);
                result = XcbConstantValue.OPERA_INT_ONE;
            } else {
                Tb_user_account ua = new Tb_user_account();
                ua.setDc_present_money(new BigDecimal(0));
                ua.setTm_create_time(new Date());
                ua.setSw_user_id(userAccount.getSw_user_id());
                ua.setDc_account_money(new BigDecimal(0));
                result = this.userAccountDao.createUserAccount_user(ua);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    ua.setDc_account_money_sum(BigDecimalUtil.add((BigDecimal)ua.getDc_account_money(), (BigDecimal)ua.getDc_present_money()));
                    dataMap.put("userAccount", ua);
                } else {
                    msg = PromptProperties.getProperty("userAccount.create.fail");
                }
            }
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.DATA, dataMap);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, msg);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USERACCOUNT_FIND_BYUSER, PromptProperties.getProperty("userAccount.find.fail"), (Throwable)e);
        }
        return ret;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Transactional(rollbackFor={Exception.class}, propagation=Propagation.REQUIRES_NEW)
    public void dealUserAccountTask(Identifier identifier, Tb_user_account userAccount) throws Exception {
        try {
            int result = 0;
            BigDecimal dc_account_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money());
            BigDecimal dc_present_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_present_money());
            BigDecimal dc_remark_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_remark_money());
            BigDecimal dc_account_money_sum = BigDecimalUtil.add((BigDecimal)dc_account_money, (BigDecimal)dc_present_money);
            if (dc_account_money_sum.compareTo(BigDecimal.ZERO) != 1 || (result = this.commonLogic.updateUser_account(identifier, dc_account_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_CZ)) <= XcbConstantValue.OPERA_INT_ZERO || (result = this.commonLogic.updateRemarkUser_account(identifier, dc_account_money, userAccount, XcbConstantValue.TB_TYPE_ADD)) <= XcbConstantValue.OPERA_INT_ZERO) return;
            this.orderDao.updateLastPizhu(userAccount.getSw_user_id());
            Tb_order order = this.orderDao.findLastOrderByUser(userAccount.getSw_user_id());
            result = this.orderDao.updatePizhuById(order.getSd_order_id());
            if (result <= XcbConstantValue.OPERA_INT_ZERO) return;
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.exceptionToString((Exception)e));
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
    }

    @Transactional(rollbackFor={Exception.class}, propagation=Propagation.REQUIRES_NEW)
    public void dealUserAccountSysTask(int taskDiff, Tb_user_account userAccount, Tb_recharge_set rechargeSet) {
        try {
            int result = 0;
            int diff = XcbStringUtils.getObjtoint((Object)userAccount.getDatediff());
            if (diff >= taskDiff) {
                BigDecimal dc_account_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money());
                BigDecimal dc_present_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_present_money());
                BigDecimal dc_remark_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_remark_money());
                BigDecimal dc_account_money_sum = BigDecimalUtil.add((BigDecimal)dc_account_money, (BigDecimal)dc_present_money);
                if (dc_account_money_sum.compareTo(BigDecimal.ZERO) == 1) {
                    rechargeSet.setExcute(true);
                    result = this.commonLogic.updateUser_account_task(dc_account_money, dc_present_money, dc_remark_money, userAccount);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        this.orderDao.updateLastPizhu(userAccount.getSw_user_id());
                        Tb_order order = this.orderDao.findLastOrderByUser(userAccount.getSw_user_id());
                        result = this.orderDao.updatePizhuById(order.getSd_order_id());
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            this.log.info("#########\u66f4\u65b0\u7528\u6237" + userAccount.getSw_user_id() + "\u66f4\u65b0\u6210\u529f##########");
                        } else {
                            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_TASK, XcbConstantValue.ORDER_PAYNOTIFY, userAccount.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u66f4\u65b0\u8ba2\u5355" + order.getSd_order_id() + "\u5f02\u5e38", "", "");
                            operationLogs.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)order.getSd_order_id()));
                            operationLogs.setSr_operate_table("tb_order");
                            this.operationLogServiceImpl.createOperaLog(operationLogs);
                        }
                    } else {
                        Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_TASK, XcbConstantValue.ORDER_PAYNOTIFY, userAccount.getSw_user_id(), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u66f4\u65b0\u7528\u6237\u8d26\u6237" + userAccount.getSd_account_id() + "\u7d2f\u8ba1\u91d1\u989d\u5f02\u5e38", "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)userAccount.getSd_account_id()));
                        operationLogs.setSr_operate_table("tb_user_account");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                }
            }
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
    }
}

