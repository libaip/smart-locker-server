/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.user.model.Tb_user_address
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.user.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.idao.UserAddressDao;
import com.jcg.user.model.Tb_user_address;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserAddressServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private UserAddressDao userAddressDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("=========UserAddressServiceImpl========");
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_user_address address = new Tb_user_address();
        Page page = new Page();
        if (param != null) {
            address = (Tb_user_address)param.get("address");
            page = (Page)param.get("page");
        }
        if (XcbConstantValue.USER_ADDRESS_FIND_BYPARAM.equals(functionCode)) {
            ret = this.findAddressByParam(identifier, address);
        } else if (XcbConstantValue.USER_ADDRESS_FIND_BYID.equals(functionCode)) {
            ret = this.findAddressById(identifier, address);
        } else if (XcbConstantValue.USER_ADDRESS_FIND_DEFAULT.equals(functionCode)) {
            ret = this.findAddressDefaultByUse(identifier, address);
        } else if (XcbConstantValue.USER_ADDRESS_CREATE.equals(functionCode)) {
            ret = this.createAddress(identifier, address);
        } else if (XcbConstantValue.USER_ADDRESS_UPDATE.equals(functionCode)) {
            ret = this.updateAddress(identifier, address);
        } else if (XcbConstantValue.USER_ADDRESS_DELETE.equals(functionCode)) {
            ret = this.deleteAddress(identifier, address);
        } else if (XcbConstantValue.USER_ADDRESS_FIND_BYPARAM_CPY.equals(functionCode)) {
            ret = this.findAddressByParam_cpy(identifier, address, page);
        }
        return ret;
    }

    private Map<String, Object> createAddress(Identifier identifier, Tb_user_address address) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Integer si_default = address.getSi_default();
            int count = this.userAddressDao.findCountByParam_user(address);
            if (count < 5) {
                int result;
                address.setSw_user_id(identifier.getUserId());
                Tb_user_address tmp = new Tb_user_address();
                tmp.setSw_user_id(identifier.getUserId());
                List<Tb_user_address> addressList = this.userAddressDao.findAddressByParam_user(tmp);
                if (addressList.size() == 0) {
                    address.setSi_default(Integer.valueOf(1));
                }
                if ((result = this.userAddressDao.createAddress(address)) > XcbConstantValue.OPERA_INT_ZERO) {
                    if (si_default != null && si_default == 1) {
                        address.setSw_user_id(identifier.getUserId());
                        result = this.userAddressDao.updateOtherAddressDefault(address);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("address.create.success"));
                            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        }
                    } else {
                        ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("address.create.success"));
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    }
                } else {
                    ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("address.create.fail"));
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("address.create.warn", 5));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_ADDRESS_CREATE, PromptProperties.getProperty("address.create.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> updateAddress(Identifier identifier, Tb_user_address address) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            boolean isSuccess = false;
            Integer si_default = address.getSi_default();
            int result = this.userAddressDao.updateAddress(address);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                if (si_default != null && si_default == 1) {
                    address.setSw_user_id(identifier.getUserId());
                    this.userAddressDao.updateOtherAddressDefault(address);
                    isSuccess = true;
                } else {
                    isSuccess = true;
                }
            }
            if (isSuccess) {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("address.update.success"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("address.update.fail"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_ADDRESS_UPDATE, PromptProperties.getProperty("address.update.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> deleteAddress(Identifier identifier, Tb_user_address address) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            int result = this.userAddressDao.deleteAddress(address);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("address.delete.success"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("address.delete.fail"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_ADDRESS_DELETE, PromptProperties.getProperty("address.delete.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> findAddressByParam(Identifier identifier, Tb_user_address address) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, List<Tb_user_address>> dataMap = new HashMap<String, List<Tb_user_address>>();
        try {
            address.setSw_user_id(identifier.getUserId());
            List<Tb_user_address> addressList = this.userAddressDao.findAddressByParam_user(address);
            dataMap.put("addressList", addressList);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_ADDRESS_FIND_BYPARAM, PromptProperties.getProperty("address.findbyparam.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> findAddressByParam_cpy(Identifier identifier, Tb_user_address address, Page page) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            address.setSw_user_id(identifier.getUserId());
            List<Tb_user_address> addressList = this.userAddressDao.findAddressByParam_cpy(address, page);
            int totalCount = this.userAddressDao.findCountByParam_cpy(address);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("addressList", addressList);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_ADDRESS_FIND_BYPARAM_CPY, PromptProperties.getProperty("address.findbyparam.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> findAddressById(Identifier identifier, Tb_user_address address) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Tb_user_address> dataMap = new HashMap<String, Tb_user_address>();
        try {
            address = this.userAddressDao.findAddressById(address.getSd_id());
            dataMap.put("address", address);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_ADDRESS_FIND_BYID, PromptProperties.getProperty("address.find.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> findAddressDefaultByUse(Identifier identifier, Tb_user_address address) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Tb_user_address> dataMap = new HashMap<String, Tb_user_address>();
        try {
            address.setSw_user_id(identifier.getUserId());
            address = this.userAddressDao.findAddressDefaultByUse(address);
            dataMap.put("address", address);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_ADDRESS_FIND_DEFAULT, PromptProperties.getProperty("address.find.error"), (Throwable)e);
        }
        return ret;
    }
}

