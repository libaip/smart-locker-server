/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.user.model.Tb_user_recharge
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.user.serviceimpl;

import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.user.idao.UserRechargeDao;
import com.jcg.user.model.Tb_user_recharge;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserRechargeServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private UserRechargeDao userRechargeDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========UserRechargeServiceImpl=========");
        this.log.debug(identifier.toString());
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        Tb_user_recharge userRecharge = new Tb_user_recharge();
        String sd_recharge_id = "";
        Page page = new Page();
        if (param != null) {
            userRecharge = (Tb_user_recharge)param.get("userRecharge");
            page = (Page)param.get("page");
            sd_recharge_id = XcbStringUtils.getObjtoString((Object)param.get("sd_recharge_id"));
        }
        try {
            if (XcbConstantValue.USERRECHARGE_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findUserRechargeByParam_cpy(userRecharge, page);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> findUserRechargeByParam_cpy(Tb_user_recharge userRecharge, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        List<Tb_user_recharge> userRecharges = null;
        try {
            userRecharges = this.userRechargeDao.findUserRechargeByParam_cpy(userRecharge, page);
            int totalCount = this.userRechargeDao.findCountByParam_cpy(userRecharge);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("userRecharges", userRecharges);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USERRECHARGE_FIND_BYPARAM_CPY, PromptProperties.getProperty("userrecharge.findbyparam.error"), (Throwable)e);
        }
        return ret_method;
    }
}

