/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_order_goods
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.user.model.Tb_user
 *  com.jcg.user.model.Tb_user_account
 *  net.sf.json.JSONObject
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.user.serviceimpl;

import com.jcg.agent.idao.AgentDao;
import com.jcg.agent.idao.AgentRolesRelDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.PromptProperties;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.CompanyDao;
import com.jcg.company.idao.OrderGoodsDao;
import com.jcg.company.idao.WxInfoDao;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.user.idao.UserAccountDao;
import com.jcg.user.idao.UserDao;
import com.jcg.user.model.Tb_user;
import com.jcg.user.model.Tb_user_account;
import com.jcg.wxmsg.serviceimpl.WxMessageServiceImpl;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private UserDao userDao;
    @Autowired
    private UserAccountDao userAccountDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private OrderGoodsDao orderGoodsDao;
    @Autowired
    private DeviceDao deviceDao;
    @Autowired
    private AgentDao agentDao;
    @Autowired
    private AgentRolesRelDao roleRelDao;
    @Autowired
    RedisUtil redis;
    @Autowired
    private WxMessageServiceImpl wxMessageService;
    @Autowired
    private CompanyDao companyDao;
    @Autowired
    private CommonLogic commonLogic;
    @Autowired
    private WxInfoDao wxInfoDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_user user = new Tb_user();
        String sr_user_name = null;
        String sw_company_id = null;
        Page page = new Page();
        if (param != null) {
            user = (Tb_user)param.get("user");
            page = (Page)param.get("page");
            sr_user_name = XcbStringUtils.getObjtoString((Object)param.get("sr_user_name"));
            sw_company_id = XcbStringUtils.getObjtoString((Object)param.get("sw_company_id"));
        }
        try {
            if (XcbConstantValue.USER_FIND_BYNAME.equals(functionCode)) {
                ret = this.findUserByName(sr_user_name, sw_company_id);
            } else if (XcbConstantValue.USER_FIND_BY_OPENID.equals(functionCode)) {
                ret = this.loginWithOpenId(user);
            } else if (XcbConstantValue.USER_FIND_BY_UNIONID.equals(functionCode)) {
                ret = this.loginWithUnionId(user);
            } else if (XcbConstantValue.USER_FIND_BY_APP_OPENID.equals(functionCode)) {
                ret = this.loginWithAppOpenId(user);
            } else if (XcbConstantValue.USER_FIND_BY_ZFB_OPENID.equals(functionCode)) {
                ret = this.loginWithZfbOpenId(user);
            } else if (XcbConstantValue.USER_CREATE.equals(functionCode)) {
                String si_mainboard_id = XcbStringUtils.getObjtoString((Object)param.get("si_mainboard_id"));
                String sw_device_id = XcbStringUtils.getObjtoString((Object)param.get("sw_device_id"));
                ret = this.createUser(identifier, user, si_mainboard_id, sw_device_id);
            } else if (XcbConstantValue.USER_FIND_BYID.equals(functionCode)) {
                ret = this.findUserById(user);
            } else if (XcbConstantValue.USER_GET_UNIONID.equals(functionCode)) {
                ret = this.getUnionId(user);
            } else if (XcbConstantValue.USER_FIND_CACHE_BYID.equals(functionCode)) {
                ret = this.findUserCacheById(user);
            } else if (XcbConstantValue.USER_UPDATE_BYID_USER.equals(functionCode)) {
                ret = this.updateUserById_user(identifier, user);
            } else if (XcbConstantValue.USER_UPDATE_BYID_ZFBUSER.equals(functionCode)) {
                ret = this.updateZfbUserById_user(user);
            } else if (XcbConstantValue.USER_CHECK.equals(functionCode)) {
                ret = this.checkUser(user);
            } else if (XcbConstantValue.USER_CHECK_WX.equals(functionCode)) {
                ret = this.checkWxUser(user);
            } else if (XcbConstantValue.USER_CREATE_WX.equals(functionCode)) {
                ret = this.createWxUser(identifier, user);
            } else if (XcbConstantValue.USER_UPDATE_SUBSCRIBE_USER.equals(functionCode)) {
                ret = this.updateUserSubscribe(identifier, user);
            } else if (XcbConstantValue.USER_UPDATE_BYID.equals(functionCode)) {
                ret = this.updateUserById_agent(identifier, user);
            } else if (XcbConstantValue.USER_FIND_BYPARAM.equals(functionCode)) {
                ret = this.findUserByParam_agent(identifier, user, page);
            } else if (XcbConstantValue.USER_UPDATE_BYID_CPY.equals(functionCode)) {
                ret = this.updateUserById_agent(identifier, user);
            } else if (XcbConstantValue.USER_FIND_BYPARAM_CPY.equals(functionCode)) {
                ret = this.findUserByParam_cpy(identifier, user, page);
            } else if (XcbConstantValue.USER_FIND_MODE_BYPARAM_CPY.equals(functionCode)) {
                ret = this.findUserByModeParam_cpy(identifier, user, page);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    private Map<String, Object> getUnionId(Tb_user user) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_wx_info info = this.wxInfoDao.findInfoByCode(user.getSr_way());
            String access_token = XcbStringUtils.getObjtoString((Object)this.redis.get("access_token_" + info.getSr_code()));
            if (XcbStringUtils.isNullOrBlank((Object)access_token)) {
                access_token = this.wxMessageService.getAccessToken(info);
            }
            StringBuffer sb = new StringBuffer();
            sb.append(XcbConstantValue.wx_gzh_unionId_url);
            sb.append(access_token).append("&openid=").append(user.getSr_open_id());
            sb.append("&lang=zh_CN");
            this.log.info("apiUrl:" + sb.toString());
            String unionId_str = this.commonLogic.sendGet(sb.toString());
            this.log.info("unionId_str:" + unionId_str);
            JSONObject json = JSONObject.fromObject((Object)unionId_str);
            String subscribe = json.get("subscribe").toString();
            if (!"0".equals(subscribe)) {
                String unionid = json.getString("unionid");
                if (!XcbStringUtils.isNullOrBlank((Object)user.getSd_user_id()) && XcbStringUtils.isNullOrBlank((Object)user.getSr_unionid())) {
                    user.setSr_unionid(unionid);
                    this.log.info("######20240307######  \u83b7\u53d6Unionid\u66f4\u65b0\uff0c\u7528\u6237\u4fe1\u606f");
                    this.userDao.updateUserById_user(user);
                }
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, "\u83b7\u53d6\u6210\u529f");
                ret.put(XcbConstantValue.DATA, unionid);
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u7528\u6237\u672a\u5173\u6ce8\u516c\u4f17\u53f7\uff0c\u62c9\u53d6unionid\u5931\u8d25");
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_GET_UNIONID, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        this.initResultMap(ret);
        return ret;
    }

    private Map<String, Object> findUserByName(String sr_user_name, String sw_company_id) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_user user = this.userDao.findUserByName(sr_user_name, sw_company_id);
            ret.put("user", user);
            ret.put(XcbConstantValue.DATA, user);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_FIND_BYNAME, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> loginWithOpenId(Tb_user user) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            user = this.userDao.findUserByOpenId(user);
            ret_method.put(XcbConstantValue.DATA, user);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_FIND_BY_OPENID, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> loginWithUnionId(Tb_user user) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            String sr_app_openid = user.getSr_app_open_id();
            user = this.userDao.findUserByUnionId(user);
            if (user != null) {
                if (XcbStringUtils.isNullOrBlank((Object)user.getSr_app_open_id())) {
                    this.log.info("######20240307######  \u66f4\u65b0\u7528\u6237\u5c0f\u7a0b\u5e8fappid");
                    user.setTm_last_login_time(new Date());
                    user.setSr_app_open_id(sr_app_openid);
                    this.userDao.updateUserById_user(user);
                    user = this.userDao.findUserByUnionId(user);
                }
                ret_method.put(XcbConstantValue.DATA, user);
                ret_method.put(XcbConstantValue.MSG, "unionid\u7528\u6237\u5b58\u5728");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u7528\u6237\u4e0d\u5b58\u5728");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_FIND_BY_UNIONID, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> loginWithAppOpenId(Tb_user user) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            user = this.userDao.findUserByAppOpenId(user);
            if (user != null) {
                user.setTm_last_login_time(new Date());
                this.userDao.updateUserById_user(user);
                user = this.userDao.findUserByAppOpenId(user);
                ret_method.put(XcbConstantValue.DATA, user);
                ret_method.put(XcbConstantValue.MSG, "\u7528\u6237\u5b58\u5728");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret_method.put(XcbConstantValue.MSG, "\u7528\u6237\u4e0d\u5b58\u5728");
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_FIND_BY_APP_OPENID, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> loginWithZfbOpenId(Tb_user user) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        try {
            user = this.userDao.findUserByZfbOpenId(user);
            if (user != null) {
                this.log.info("######20240307######  \u652f\u4ed8\u5b9d\u66f4\u65b0\u7528\u6237\u4fe1\u606f");
                user.setTm_last_login_time(new Date());
                this.userDao.updateUserById_user(user);
                user = this.userDao.findUserByZfbOpenId(user);
            }
            ret_method.put(XcbConstantValue.DATA, user);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_FIND_BY_ZFB_OPENID, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> createUser(Identifier identifier, Tb_user user, String si_mainboard_id, String sw_device_id) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        try {
            Tb_device device;
            System.out.println("\u521b\u5efa\u65b0\u7528\u6237");
            if (!XcbStringUtils.isNullOrBlank((Object)si_mainboard_id)) {
                device = this.deviceDao.findDeviceByMid(si_mainboard_id);
                user.setSr_register_device(device.getSd_device_id());
            } else if (!XcbStringUtils.isNullOrBlank((Object)sw_device_id)) {
                user.setSr_register_device(sw_device_id);
            }
            if (!XcbStringUtils.isNullOrBlank((Object)user.getSr_register_device())) {
                device = this.deviceDao.findDeviceDetailById_agent(user.getSr_register_device());
                System.out.println("\u8bbe\u5907:" + device.getSi_mainboard_id());
                user.setSr_is_scan(device.getSr_is_scan());
                user.setSr_mode(device.getSr_mode());
                user.setSr_scan_cycle(device.getSr_scan_cycle());
                user.setSr_check_appl(device.getSr_check_appl());
            } else {
                user.setSr_is_scan("N");
                user.setSr_check_appl("N");
            }
            if (XcbStringUtils.isNullOrBlank((Object)user.getSr_is_subscribe())) {
                user.setSr_is_subscribe("N");
            }
            user.setTm_last_login_time(new Date());
            result = this.userDao.createUser(user);
            if (result > XcbConstantValue.OPERA_INT_ZERO && (result = this.createUserAccount(user)) > XcbConstantValue.OPERA_INT_ZERO) {
                isSuccess = true;
            }
            if (isSuccess) {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.create.success"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.create.fail"));
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_CREATE, PromptProperties.getProperty("user.create.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> createWxUser(Identifier identifier, Tb_user user) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        String sr_unionid = "";
        try {
            Tb_wx_info wx_info = this.wxInfoDao.findInfoByCode(user.getSr_way());
            user.setTm_last_login_time(new Date());
            Tb_user o_user = null;
            if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type())) {
                o_user = this.userDao.findUserByUnionId(user);
            } else if (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type())) {
                o_user = this.userDao.findUserByAppOpenId(user);
            } else {
                o_user = this.userDao.findUserByOpenId(user);
                user.setSr_is_subscribe("N");
            }
            if (o_user != null) {
                isSuccess = true;
                if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type())) {
                    this.log.info("\u7528\u6237\u5df2\u5b58\u5728\uff0c\u8bf7\u52ff\u91cd\u590d\u521b\u5efa:" + o_user.getSr_app_open_id() + " | " + o_user.getSr_user_petname());
                } else if (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type())) {
                    this.log.info("\u7528\u6237\u5df2\u5b58\u5728\uff0c\u8bf7\u52ff\u91cd\u590d\u521b\u5efa:" + o_user.getSr_app_open_id() + " | " + o_user.getSr_user_petname());
                } else {
                    this.log.info("\u7528\u6237\u5df2\u5b58\u5728\uff0c\u8bf7\u52ff\u91cd\u590d\u521b\u5efa:" + o_user.getSr_open_id() + " | " + o_user.getSr_user_petname());
                }
            } else {
                try {
                    if (!XcbStringUtils.isNullOrBlank((Object)user.getSr_register_device())) {
                        Tb_device device = this.deviceDao.findDeviceDetailById_agent(user.getSr_register_device());
                        if (device != null) {
                            user.setSr_is_scan(device.getSr_is_scan());
                            user.setSr_mode(device.getSr_mode());
                            user.setSr_scan_cycle(device.getSr_scan_cycle());
                            user.setSr_check_appl(device.getSr_check_appl());
                        }
                    } else {
                        user.setSr_is_scan("N");
                        user.setSr_check_appl("N");
                    }
                    if (XcbStringUtils.isNullOrBlank((Object)user.getSr_is_subscribe())) {
                        user.setSr_is_subscribe("N");
                    }
                    if (XcbStringUtils.isNullOrBlank((Object)(sr_unionid = XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type()) ? XcbStringUtils.getObjtoString((Object)this.redis.get("USER_CREATE_" + user.getSr_unionid())) : (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type()) ? XcbStringUtils.getObjtoString((Object)this.redis.get("USER_CREATE_" + user.getSr_app_open_id())) : XcbStringUtils.getObjtoString((Object)this.redis.get("USER_CREATE_" + user.getSr_open_id())))))) {
                        if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type())) {
                            this.redis.setForTimeMIN("USER_CREATE_" + user.getSr_unionid(), user.getSr_unionid(), 2L);
                            sr_unionid = user.getSr_unionid();
                        } else if (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type())) {
                            this.redis.setForTimeMIN("USER_CREATE_" + user.getSr_app_open_id(), user.getSr_app_open_id(), 2L);
                            sr_unionid = user.getSr_app_open_id();
                        } else {
                            this.redis.setForTimeMIN("USER_CREATE_" + user.getSr_open_id(), user.getSr_open_id(), 2L);
                            sr_unionid = user.getSr_open_id();
                        }
                        result = this.userDao.createUser(user);
                    } else {
                        isSuccess = true;
                        if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type())) {
                            this.log.info("\u7528\u6237\u5df2\u5b58\u5728\uff0c\u8bf7\u52ff\u91cd\u590d\u521b\u5efa:" + o_user.getSr_app_open_id() + " | " + o_user.getSr_user_petname());
                        } else if (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type())) {
                            this.log.info("\u7528\u6237\u5df2\u5b58\u5728\uff0c\u8bf7\u52ff\u91cd\u590d\u521b\u5efa:" + o_user.getSr_app_open_id() + " | " + o_user.getSr_user_petname());
                        } else {
                            this.log.info("\u7528\u6237\u5df2\u5b58\u5728\uff0c\u8bf7\u52ff\u91cd\u590d\u521b\u5efa:" + o_user.getSr_open_id() + " | " + o_user.getSr_user_petname());
                        }
                    }
                }
                catch (Exception e) {
                    this.log.info("############\u7528\u6237\u6635\u79f0\u542b\u6709\u7279\u6b8a\u5b57\u7b26\uff0c\u9700\u8981\u5904\u7406############# : " + user.getSr_user_petname());
                    user.setSr_user_petname("\u5fae\u4fe1\u7528\u6237B");
                    if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type())) {
                        o_user = this.userDao.findUserByUnionId(user);
                    } else if (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type())) {
                        o_user = this.userDao.findUserByAppOpenId(user);
                    } else {
                        o_user = this.userDao.findUserByOpenId(user);
                        user.setSr_is_subscribe("N");
                    }
                    if (o_user == null) {
                        if (!XcbStringUtils.isNullOrBlank((Object)user.getSr_register_device())) {
                            Tb_device device = this.deviceDao.findDeviceDetailById_agent(user.getSr_register_device());
                            if (device != null) {
                                user.setSr_is_scan(device.getSr_is_scan());
                                user.setSr_mode(device.getSr_mode());
                                user.setSr_scan_cycle(device.getSr_scan_cycle());
                                user.setSr_check_appl(device.getSr_check_appl());
                            }
                        } else {
                            user.setSr_is_scan("N");
                            user.setSr_check_appl("N");
                        }
                        if (XcbStringUtils.isNullOrBlank((Object)user.getSr_is_subscribe())) {
                            user.setSr_is_subscribe("N");
                        }
                        result = this.userDao.createUser(user);
                    }
                    result = 1;
                }
                if (result > XcbConstantValue.OPERA_INT_ZERO && (result = this.createUserAccount(user)) > XcbConstantValue.OPERA_INT_ZERO) {
                    isSuccess = true;
                    this.redis.setForTimeMIN("USER_CREATE_" + sr_unionid, sr_unionid, 2L);
                }
            }
            if (isSuccess) {
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.create.success"));
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.create.fail"));
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_CREATE_WX, PromptProperties.getProperty("user.create.error"), (Throwable)e);
        }
        return ret;
    }

    private int createUserAccount(Tb_user newUser) {
        int result = 0;
        Tb_user_account old_account = this.userAccountDao.findUserAccountByUser(newUser.getSd_user_id());
        if (old_account == null) {
            Tb_user_account userAccount = new Tb_user_account();
            userAccount.setSw_user_id(newUser.getSd_user_id());
            userAccount.setDc_account_money(new BigDecimal(0));
            userAccount.setDc_present_money(new BigDecimal(0));
            result = this.userAccountDao.createUserAccount_user(userAccount);
        } else {
            result = 1;
        }
        return result;
    }

    private Map<String, Object> findUserById(Tb_user user) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Integer> dataMap = new HashMap<String, Integer>();
        try {
            user = this.userDao.findUserById(user.getSd_user_id());
            String username = user.getSr_user_name();
            if (!XcbStringUtils.isNullOrBlank((Object)username)) {
                user.setSr_user_name(CommonFunction.getUserName((String)username).trim());
                System.out.println(username);
            }
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(user.getSd_user_id());
            BigDecimal dc_account_money_sum = BigDecimalUtil.add((BigDecimal)userAccount.getDc_account_money(), (BigDecimal)userAccount.getDc_present_money());
            user.setDc_account_money_sum(dc_account_money_sum);
            user.setDc_account_money(userAccount.getDc_account_money());
            user.setDc_present_money(userAccount.getDc_present_money());
            user.setDc_integral(userAccount.getDc_integral());
            Tb_order order = this.orderDao.findLastOrderByUser(user.getSd_user_id());
            if (order != null && "Y".equals(user.getSr_is_scan())) {
                Date now = new Date();
                int diff = XcbDateUtil.daysBetween((Date)order.getTm_create_time(), (Date)now);
                if (diff < XcbStringUtils.getObjtoint((Object)user.getSr_scan_cycle())) {
                    user.setSr_is_scan("N");
                }
            }
            Tb_order_goods orderGoods = new Tb_order_goods();
            orderGoods.setSw_user_id(user.getSd_user_id());
            orderGoods.setSr_status(XcbConstantValue.ORDER_GOODS_STS_DZF);
            int dzf_cnt = this.orderGoodsDao.findCountByParam(orderGoods);
            orderGoods.setSr_status(XcbConstantValue.ORDER_GOODS_STS_DFH);
            int dfh_cnt = this.orderGoodsDao.findCountByParam(orderGoods);
            orderGoods.setSr_status(XcbConstantValue.ORDER_GOODS_STS_DSH);
            int dsh_cnt = this.orderGoodsDao.findCountByParam(orderGoods);
            orderGoods.setSr_status(XcbConstantValue.ORDER_GOODS_STS_DCL);
            int dcl_cnt = this.orderGoodsDao.findCountByParam(orderGoods);
            dataMap.put("dzf_cnt", dzf_cnt);
            dataMap.put("dfh_cnt", dfh_cnt);
            dataMap.put("dsh_cnt", dsh_cnt);
            dataMap.put("dcl_cnt", dcl_cnt);
            dataMap.put("user", (Integer)user);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_FIND_BYID, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findUserCacheById(Tb_user user) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Tb_user> dataMap = new HashMap<String, Tb_user>();
        try {
            user = this.userDao.findUserCacheById(user.getSd_user_id());
            dataMap.put("user", user);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_FIND_CACHE_BYID, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateUserById_user(Identifier identifier, Tb_user user) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 1;
        user.setSi_modify_person(identifier.getUserId());
        try {
            result = this.userDao.updateUserById_user(user);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                user = this.userDao.findUserCacheById(user.getSd_user_id());
                ret_method.put(XcbConstantValue.DATA, result);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_UPDATE_BYID_USER, PromptProperties.getProperty("user.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateUserSubscribe(Identifier identifier, Tb_user user) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        user.setSi_modify_person(identifier.getUserId());
        try {
            result = this.userDao.updateUserSubscribe(user);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_UPDATE_SUBSCRIBE_USER, PromptProperties.getProperty("user.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateZfbUserById_user(Tb_user user) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 1;
        try {
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                user = this.userDao.findUserCacheById(user.getSd_user_id());
                ret_method.put(XcbConstantValue.DATA, result);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_UPDATE_BYID_ZFBUSER, PromptProperties.getProperty("user.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> updateUserById_agent(Identifier identifier, Tb_user user) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        user.setSi_modify_person(identifier.getUserId());
        user.setTm_modify_time(new Date());
        try {
            result = this.userDao.updateUserById_agent(user);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.DATA, result);
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.update.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("user.update.fail"));
            }
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_UPDATE_BYID, PromptProperties.getProperty("user.update.error"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> findUserByParam_agent(Identifier identifier, Tb_user user, Page page) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_user> userList = null;
            int totalCount = 0;
            Tb_agent adminAgent = this.agentDao.findAgentById_agent(user.getSw_agent_id());
            if (adminAgent != null && !XcbStringUtils.isNullOrBlank((Object)adminAgent.getSr_admin_id())) {
                List<String> netList = this.roleRelDao.findNetArrByAgentId(adminAgent.getSd_agent_id());
                String[] netArr = netList.get(0).split(",");
                if (netList.size() > 0) {
                    user.setNetArr(netArr);
                    userList = this.userDao.findUserByNetArr_agent(user, page);
                    totalCount = this.userDao.findCountByNetArr_agent(user);
                }
            } else {
                userList = this.userDao.findUserByParam_agent(user, page);
                totalCount = this.userDao.findCountByParam_agent(user);
            }
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("userList", userList);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_FIND_BYPARAM, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> findUserByParam_cpy(Identifier identifier, Tb_user user, Page page) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List userList = null;
            int totalCount = 0;
            CompletableFuture<List> userListFuture = CompletableFuture.supplyAsync(() -> this.userDao.findUserByParam_cpy(user, page));
            CompletableFuture<Integer> totalCountFuture = CompletableFuture.supplyAsync(() -> this.userDao.findCountByParam_cpy(user));
            userList = userListFuture.get();
            totalCount = totalCountFuture.get();
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("userList", userList);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_FIND_BYPARAM_CPY, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        return ret;
    }

    public Map<String, Object> findUserByModeParam_cpy(Identifier identifier, Tb_user user, Page page) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List userList = null;
            int totalCount = 0;
            CompletableFuture<List> userListFuture = CompletableFuture.supplyAsync(() -> this.userDao.findUserByModeParam_cpy(user, page));
            CompletableFuture<Integer> totalCountFuture = CompletableFuture.supplyAsync(() -> this.userDao.findCountByModeParam_cpy(user));
            userList = userListFuture.get();
            totalCount = totalCountFuture.get();
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("userList", userList);
            ret.put(XcbConstantValue.DATA, dataMap);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_FIND_MODE_BYPARAM_CPY, PromptProperties.getProperty("user.find.error"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> checkUser(Tb_user user) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_user u_phone = this.userDao.findUserByUnionId(user);
            if (u_phone != null) {
                if (XcbStringUtils.isNullOrBlank((Object)u_phone.getSr_user_name())) {
                    this.log.info("######20240307######  \u6388\u6743\u7528\u6237\u624b\u673a\u53f7\u7801\uff0c\u66f4\u65b0\u7528\u6237\u4fe1\u606f");
                    u_phone.setSr_user_name(user.getSr_user_name());
                    u_phone.setTm_last_login_time(new Date());
                    this.userDao.updateUserById_user(u_phone);
                }
                Tb_user newUser = this.userDao.findUserByUnionId(u_phone);
                ret.put("user", newUser);
                ret.put("isRegister", true);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put("isRegister", false);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_CHECK, PromptProperties.getProperty("user.check.fail"), (Throwable)e);
        }
        return ret;
    }

    private Map<String, Object> checkWxUser(Tb_user user) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_wx_info wx_info = this.wxInfoDao.findInfoByCode(user.getSr_way());
            Tb_user wx_user = new Tb_user();
            wx_user = XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type()) ? this.userDao.findUserByUnionId(user) : (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type()) ? this.userDao.findUserByAppOpenId(user) : this.userDao.findUserByOpenId(user));
            if (wx_user != null) {
                if (XcbConstantValue.WX_INFO_MODE_1.equals(wx_info.getSr_type())) {
                    Tb_user u = new Tb_user();
                    user.setTm_last_login_time(new Date());
                    u.setSd_user_id(wx_user.getSd_user_id());
                    if (XcbStringUtils.isNullOrBlank((Object)wx_user.getSr_open_id())) {
                        this.log.info("######20240307######  \u66f4\u65b0\u7528\u6237\u516c\u4f17\u53f7openid");
                        u.setSr_open_id(user.getSr_open_id());
                        wx_user.setSr_open_id(user.getSr_open_id());
                    }
                    if (XcbStringUtils.isNullOrBlank((Object)wx_user.getSr_user_name())) {
                        this.log.info("######20240307######  \u6388\u6743\u7528\u6237\u624b\u673a\u53f7\u7801\uff0c\u66f4\u65b0\u7528\u6237\u4fe1\u606f");
                        u.setSr_user_name(user.getSr_user_name());
                        wx_user.setSr_user_name(user.getSr_user_name());
                    }
                    this.userDao.updateUserById_user(u);
                } else if (XcbConstantValue.WX_INFO_MODE_2.equals(wx_info.getSr_type())) {
                    Tb_user u = new Tb_user();
                    u.setSd_user_id(wx_user.getSd_user_id());
                    u.setTm_last_login_time(new Date());
                    if (XcbStringUtils.isNullOrBlank((Object)wx_user.getSr_app_open_id())) {
                        u.setSr_app_open_id(user.getSr_app_open_id());
                        wx_user.setSr_app_open_id(user.getSr_app_open_id());
                    }
                    if (XcbStringUtils.isNullOrBlank((Object)wx_user.getSr_user_name())) {
                        this.log.info("######20240307######  \u6388\u6743\u7528\u6237\u624b\u673a\u53f7\u7801\uff0c\u66f4\u65b0\u7528\u6237\u4fe1\u606f");
                        u.setSr_user_name(user.getSr_user_name());
                        wx_user.setSr_user_name(user.getSr_user_name());
                    }
                    this.userDao.updateUserById_user(u);
                } else if (!XcbStringUtils.isNullOrBlank((Object)user.getSr_open_id())) {
                    Tb_user u = new Tb_user();
                    u.setSr_wx_avatar_url(user.getSr_wx_avatar_url());
                    u.setSd_user_id(wx_user.getSd_user_id());
                    u.setSr_user_petname(user.getSr_user_petname());
                    if (XcbConstantValue.WX_INFO_MODE_4.equals(wx_info.getSr_type()) && XcbStringUtils.isNullOrBlank((Object)wx_user.getSr_unionid())) {
                        u.setSr_unionid(user.getSr_unionid());
                        u.setSr_is_subscribe(user.getSr_is_subscribe());
                        wx_user.setSr_unionid(user.getSr_unionid());
                        wx_user.setSr_is_subscribe(user.getSr_is_subscribe());
                    }
                    try {
                        this.userDao.updateUserById_user(u);
                    }
                    catch (Exception e) {
                        user.setSr_user_petname("\u5fae\u4fe1\u6635\u79f0");
                        u.setSr_user_petname("\u5fae\u4fe1\u6635\u79f0");
                        this.userDao.updateUserById_user(u);
                    }
                    if (!XcbStringUtils.isNullOrBlank((Object)user.getSr_wx_avatar_url())) {
                        wx_user.setSr_wx_avatar_url(user.getSr_wx_avatar_url());
                    }
                    if (!XcbStringUtils.isNullOrBlank((Object)user.getSr_user_petname())) {
                        wx_user.setSr_user_petname(user.getSr_user_petname());
                    }
                }
                ret.put("user", wx_user);
                ret.put("isRegister", true);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put("isRegister", false);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            }
            this.initResultMap(ret);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_CHECK_WX, PromptProperties.getProperty("user.check.fail"), (Throwable)e);
        }
        return ret;
    }
}

