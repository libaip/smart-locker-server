/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.wxpay.sdk.WXPayUtil
 *  com.jcg.agent.model.Tb_cash_stream
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.agent.model.Tb_ordercash_stream
 *  com.jcg.common.model.BigDecimalUtil
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.Page
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.company.model.Tb_sys_param
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.user.model.Tb_user
 *  com.jcg.user.model.Tb_user_account
 *  com.jcg.user.model.Tb_user_withdrawal_appl
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 *  org.springframework.transaction.interceptor.TransactionAspectSupport
 */
package com.jcg.user.serviceimpl;

import com.github.wxpay.sdk.WXPayUtil;
import com.jcg.agent.idao.CashStreamDao;
import com.jcg.agent.idao.OrderCashStreamDao;
import com.jcg.agent.idao.OrderDao;
import com.jcg.agent.model.Tb_cash_stream;
import com.jcg.agent.model.Tb_order;
import com.jcg.agent.model.Tb_ordercash_stream;
import com.jcg.common.BaseService;
import com.jcg.common.CommonLogic;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.BigDecimalUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.Page;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.SysParamDao;
import com.jcg.company.idao.WxInfoDao;
import com.jcg.company.idao.WxPayInfoDao;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.company.model.Tb_sys_param;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.idao.UserAccountDao;
import com.jcg.user.idao.UserDao;
import com.jcg.user.idao.UserWithdrawalApplDao;
import com.jcg.user.model.Tb_user;
import com.jcg.user.model.Tb_user_account;
import com.jcg.user.model.Tb_user_withdrawal_appl;
import com.jcg.wxmsg.serviceimpl.WxMessageServiceImpl;
import com.jcg.wxmsg.vo.WxMessage;
import com.jcg.zf.wx.EnterprisesPayment;
import com.jcg.zf.wx.Signature;
import com.jcg.zf.wx.UUidUtils;
import com.jcg.zf.wx.WXWithdrawTools;
import com.jcg.zf.wx.WxAPIV3Common;
import com.jcg.zf.wx.WxSdjAPICommon;
import com.jcg.zf.wx.WxSpAPIV3Common;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

@Service
public class UserWithdrawalApplServiceImpl
extends BaseService
implements GenericCaller {
    @Autowired
    private UserWithdrawalApplDao userWithdrawalApplDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private UserAccountDao userAccountDao;
    @Autowired
    private CommonLogic commonLogic;
    @Autowired
    private WxAPIV3Common wxAPIV3Common;
    @Autowired
    private WxSdjAPICommon wxSdjAPICommon;
    @Autowired
    private WxSpAPIV3Common wxSpAPIV3Common;
    @Autowired
    private WXWithdrawTools wxWithdrawTools;
    @Autowired
    private SysParamDao sysParamDao;
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private OrderCashStreamDao orderCashStreamDao;
    @Autowired
    private WxMessageServiceImpl wxMessageService;
    @Autowired
    private CashStreamDao cashStreamDao;
    @Autowired
    private WxPayInfoDao wxPayInfoDao;
    @Autowired
    private WxInfoDao wxInfoDao;
    private String pay_type = "WX";

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        this.log.debug("========UserWithdrawalApplServiceImpl=========");
        Map<Object, Object> ret = new HashMap();
        String functionCode = identifier.getFunctionCode();
        Tb_user_withdrawal_appl userWithdrawalAppl = new Tb_user_withdrawal_appl();
        Page page = new Page();
        if (param != null) {
            userWithdrawalAppl = (Tb_user_withdrawal_appl)param.get("userWithdrawalAppl");
            page = (Page)param.get("page");
        }
        try {
            if (XcbConstantValue.USER_WITHDRAWAL_APPL_MAIN.equalsIgnoreCase(functionCode)) {
                ret = this.mainPayMethod(identifier, userWithdrawalAppl);
            } else if (XcbConstantValue.USER_WITHDRAWAL_APPL_FIND_BYPARAM.equalsIgnoreCase(functionCode)) {
                ret = this.findUserWithdrawalApplByParam_user(identifier, userWithdrawalAppl, page);
            } else if (XcbConstantValue.USER_WITHDRAWAL_FIND_LAST.equalsIgnoreCase(functionCode)) {
                ret = this.findLastUserWithdrawalAppl(identifier, userWithdrawalAppl);
            } else if (XcbConstantValue.USER_WITHDRAWAL_APPL_FIND_BYPARAM_CPY.equalsIgnoreCase(functionCode)) {
                ret = this.findUserWithdrawalApplByParam_cpy(identifier, userWithdrawalAppl, page);
            } else if (XcbConstantValue.USER_WITHDRAWAL_APPL_PAY.equalsIgnoreCase(functionCode)) {
                ret = this.applUserAppl(identifier, userWithdrawalAppl);
            } else if (XcbConstantValue.USER_WITHDRAWAL_APPL_TX.equalsIgnoreCase(functionCode)) {
                ret = this.userTx(identifier, userWithdrawalAppl);
            }
        }
        catch (BusinessException e) {
            this.log.error("UserWithdrawalApplServiceImpl error:" + e.getMessage());
            throw e;
        }
        return ret;
    }

    @Transactional
    Map<String, Object> applUserAppl(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl) {
        Map<String, Object> ret_method = new HashMap<String, String>();
        try {
            Tb_user_withdrawal_appl appl = this.userWithdrawalApplDao.findUserWithdrawalApplById(userWithdrawalAppl.getSd_id());
            if (appl.getSr_status().equals(XcbConstantValue.WITHDRAWAL_APPL_STATUS_DSP)) {
                ret_method = userWithdrawalAppl.getSr_status().equals(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG) ? this.payToUser(identifier, appl, "CPY") : this.refuseAppl(identifier, appl, userWithdrawalAppl.getSr_remarks());
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.appl.check.warn1", appl.getSr_status_desc()));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_WITHDRAWAL_APPL_PAY, PromptProperties.getProperty("withdrawalAppl.appl.error"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    Map<String, Object> userTx(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl) {
        Tb_user user;
        BigDecimal totalMoney;
        boolean isSuccess;
        Map<String, Object> ret_method;
        block39: {
            ret_method = new HashMap<String, Object>();
            int result = 0;
            isSuccess = false;
            totalMoney = BigDecimal.ZERO;
            user = this.userDao.findUserById(userWithdrawalAppl.getSw_user_id());
            Tb_wx_info info = this.wxInfoDao.findInfoByCode(user.getSr_way());
            try {
                String[] orderArr = userWithdrawalAppl.getOrderArr();
                if (XcbConstantValue.WX_INFO_MODE_1.equals(info.getSr_type())) {
                    if (XcbStringUtils.isNullOrBlank((Object)user.getSr_app_open_id())) {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u7528\u6237openid\u4e3a\u7a7a\uff0c\u4e0d\u53ef\u63d0\u73b0");
                        return ret_method;
                    }
                } else if (XcbConstantValue.WX_INFO_MODE_2.equals(info.getSr_type())) {
                    if (XcbStringUtils.isNullOrBlank((Object)user.getSr_app_open_id())) {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, "\u7528\u6237openid\u4e3a\u7a7a\uff0c\u4e0d\u53ef\u63d0\u73b0");
                        return ret_method;
                    }
                } else if (XcbStringUtils.isNullOrBlank((Object)user.getSr_open_id())) {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u7528\u6237openid\u4e3a\u7a7a\uff0c\u4e0d\u53ef\u63d0\u73b0");
                    return ret_method;
                }
                Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(userWithdrawalAppl.getSw_user_id());
                BigDecimal dc_account_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_account_money());
                BigDecimal dc_remark_money = XcbStringUtils.getObjToBigDecimal((Object)userAccount.getDc_remark_money());
                BigDecimal dc_account_money_sum = BigDecimalUtil.add((BigDecimal)dc_account_money, (BigDecimal)dc_remark_money);
                if (orderArr != null && orderArr.length > 0) {
                    for (int i = 0; i < orderArr.length; ++i) {
                        String sd_order_id = orderArr[i];
                        Tb_order order = this.orderDao.findOrderById_user(sd_order_id);
                        if (XcbStringUtils.getObjToBigDecimal((Object)order.getDc_deposit_refund()).compareTo(BigDecimal.ZERO) == 1) {
                            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                            ret_method.put(XcbConstantValue.MSG, "\u8ba2\u5355" + order.getSd_order_id() + "\u62bc\u91d1\u5df2\u9000\u6b3e");
                            return ret_method;
                        }
                        this.log.info("###############\u8981\u63d0\u73b0\u9000\u6b3e\u7684\u8ba2\u5355:" + order.getSd_order_id() + "###############");
                        totalMoney = BigDecimalUtil.add((BigDecimal)totalMoney, (BigDecimal)order.getDc_deposit_money());
                    }
                    this.log.info("###############\u7528\u6237:" + userWithdrawalAppl.getSw_user_id() + "\uff0c\u63d0\u73b0\u7533\u8bf7: " + totalMoney + "\u5143###############");
                    if (dc_account_money_sum.compareTo(totalMoney) >= 0) {
                        if (dc_account_money.compareTo(totalMoney) >= 0) {
                            result = this.commonLogic.updateUser_account(identifier, totalMoney, BigDecimal.ZERO, userAccount, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_CZ);
                        } else {
                            BigDecimal tmpMoney = BigDecimalUtil.sub((BigDecimal)totalMoney, (BigDecimal)dc_account_money);
                            result = this.commonLogic.updateUser_account(identifier, dc_account_money, BigDecimal.ZERO, userAccount, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_CZ);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                result = this.commonLogic.updateRemarkUser_account(identifier, tmpMoney, userAccount, XcbConstantValue.TB_TYPE_MINUS);
                            } else {
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                ret_method.put(XcbConstantValue.MSG, "\u63d0\u73b0\u5f02\u5e38\uff0c\u7528\u6237\u8d26\u6237\u6263\u6b3e\u5931\u8d25");
                            }
                        }
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            String sr_order_arr = "";
                            StringBuffer sb = new StringBuffer();
                            for (String sd_order_id : orderArr) {
                                sb.append(sd_order_id).append(",");
                                Tb_order order = this.orderDao.findOrderById_user(sd_order_id);
                                BigDecimal dc_deposit_money = order.getDc_deposit_money();
                                String sr_checked = XcbStringUtils.getObjtoString((Object)order.getSr_checked());
                                this.log.info("\u4fee\u6539\u8ba2\u5355" + order.getSd_order_id() + "\u62bc\u91d1\u9000\u6b3e\u91d1\u989d:" + dc_deposit_money + "\u5143");
                                if (XcbConstantValue.ORDER_F.equals(sr_checked)) {
                                    order.setSr_checked(XcbConstantValue.ORDER_T);
                                }
                                order.setDc_deposit_refund(dc_deposit_money);
                                result = this.orderDao.updateDepositRefund(order);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    String cash_trade_no;
                                    Date nowDate;
                                    List<Tb_ordercash_stream> ordercashList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                    Tb_ordercash_stream orderCash = ordercashList.get(0);
                                    String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                                    Date tm_create_time = orderCash.getTm_create_time();
                                    int si_diff = XcbDateUtil.daysBetween((Date)tm_create_time, (Date)(nowDate = new Date()));
                                    if (si_diff < 180) {
                                        Map<Object, Object> rtnMap = new HashMap();
                                        Tb_wx_pay_info pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
                                        if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                                            int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                            int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                            pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                            rtnMap = this.wxAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                        } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                                            String refund_fee = XcbStringUtils.getObjtoString((Object)dc_deposit_money);
                                            String total_fee = XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money());
                                            pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                            rtnMap = this.wxSdjAPICommon.xcrefund(orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                        } else {
                                            int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                            int total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                            pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                            rtnMap = this.wxSpAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                        }
                                        result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                                        continue;
                                    }
                                    Tb_wx_pay_info pay_info = this.wxPayInfoDao.findUserDefaultPayOut(user.getSr_way());
                                    if (XcbConstantValue.PAY_QY.equals(pay_info.getSr_pay_type())) {
                                        String zf_money_fen = CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money));
                                        String zf_desc = pay_info.getSr_payment_desc();
                                        String cash_trade_no2 = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                                        EnterprisesPayment enterprisesPayment = new EnterprisesPayment();
                                        enterprisesPayment.setMch_appid(pay_info.getSub_appid());
                                        enterprisesPayment.setMchid(pay_info.getSub_mchid());
                                        enterprisesPayment.setNonce_str(UUidUtils.getUUid());
                                        enterprisesPayment.setPartner_trade_no(cash_trade_no2);
                                        enterprisesPayment.setOpenid(user.getSr_app_open_id());
                                        enterprisesPayment.setCheck_name("NO_CHECK");
                                        enterprisesPayment.setAmount(XcbStringUtils.getObjtoint((Object)zf_money_fen));
                                        enterprisesPayment.setDesc(zf_desc);
                                        enterprisesPayment.setSpbill_create_ip(pay_info.getSr_payserver_ip());
                                        String apiKey = pay_info.getSub_merkey_v2();
                                        this.log.info("sign key ============{}", (Object)apiKey);
                                        String sign = Signature.getSign(apiKey, enterprisesPayment);
                                        enterprisesPayment.setSign(sign);
                                        this.log.info("sign====={}", (Object)sign);
                                        System.out.println("sign====={}" + sign);
                                        String xmlWithdrawInfo = this.wxWithdrawTools.getXMLStringForObj(enterprisesPayment);
                                        this.log.info("\u63d0\u73b0\u53c2\u6570\u4e3a======{}", (Object)xmlWithdrawInfo);
                                        System.out.println("\u63d0\u73b0\u53c2\u6570\u4e3a======{}" + xmlWithdrawInfo);
                                        String response = this.wxWithdrawTools.postParamesForUrl(xmlWithdrawInfo, "https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers", pay_info);
                                        this.log.info("\u63d0\u73b0\u7ed3\u679c\u4e3a==={}", (Object)response);
                                        System.out.println("\u63d0\u73b0\u7ed3\u679c\u4e3a======{}" + response);
                                        Map return_data = null;
                                        try {
                                            return_data = WXPayUtil.xmlToMap((String)response);
                                        }
                                        catch (Exception e) {
                                            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                                            this.log.error("\u4f01\u4e1a\u6253\u6b3e-\u7528\u6237\u4ed8\u6b3e-\u652f\u4ed8\u8fd4\u56de\u7ed3\u679c\u89e3\u6790\u5931\u8d25:" + XcbStringUtils.exceptionToString((Exception)e));
                                            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.wx.error"));
                                            return ret_method;
                                        }
                                        String return_code = (String)return_data.get("return_code");
                                        String result_code = (String)return_data.get("result_code");
                                        try {
                                            if (!"SUCCESS".equals(return_code)) continue;
                                            Tb_cash_stream cashflow = new Tb_cash_stream();
                                            cashflow.setSd_cash_id(cash_trade_no2);
                                            cashflow.setSw_company_id(user.getSw_company_id());
                                            cashflow.setSr_cashflow_remark(orderCash.getSd_ordercash_id());
                                            cashflow.setDc_cashflow_money(dc_deposit_money);
                                            cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
                                            cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                            cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                            cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                                            cashflow.setSr_remarks("\u7528\u6237" + user.getSd_user_id() + "\u4f59\u989d\u63d0\u73b0\u5230\u96f6\u94b1");
                                            result = this.cashStreamDao.createCashStream(cashflow);
                                        }
                                        catch (Exception e) {
                                            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4f01\u4e1a\u6253\u6b3e-\u7528\u6237\u4f59\u989d\u63d0\u73b0\u5931\u8d25\uff0ccash_trade_no\uff1a" + cash_trade_no2, "", "");
                                            operationLogs.setSr_operate_from(XcbConstantValue.PC);
                                            operationLogs.setSr_operate_primarykey(orderCash.getSd_ordercash_id());
                                            operationLogs.setSr_operate_table("tb_ordercash_stream");
                                            this.operationLogServiceImpl.createOperaLog(operationLogs);
                                            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.pay.wx.error"));
                                        }
                                        continue;
                                    }
                                    int zf_money_fen = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                    ret_method = this.wxAPIV3Common.wx_pay_user(pay_info, zf_money_fen, user, cash_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zj_id));
                                    result = XcbStringUtils.getObjtoint((Object)ret_method.get(XcbConstantValue.STATUS));
                                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                        Tb_cash_stream cashflow = new Tb_cash_stream();
                                        cashflow.setSd_cash_id(cash_trade_no);
                                        cashflow.setSw_company_id(user.getSw_company_id());
                                        cashflow.setSr_cashflow_remark(orderCash.getSd_ordercash_id());
                                        cashflow.setDc_cashflow_money(dc_deposit_money);
                                        cashflow.setSr_cashflow_item(XcbConstantValue.CASH_STREAM_ZJTX);
                                        cashflow.setSr_cashflow_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                        cashflow.setSr_create_time(XcbDateUtil.formatDate((Date)new Date(), (String)"yyyy-MM-dd HH:mm:ss"));
                                        cashflow.setSr_company_pay(XcbConstantValue.CASH_STREAM_YFK);
                                        cashflow.setSr_remarks("\u7528\u6237" + user.getSd_user_id() + "\u4f59\u989d\u63d0\u73b0\u5230\u96f6\u94b1");
                                        result = this.cashStreamDao.createCashStream(cashflow);
                                        continue;
                                    }
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.wx.error"));
                                    continue;
                                }
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.wx.error"));
                            }
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                sr_order_arr = sb.deleteCharAt(sb.length() - 1).toString();
                                userWithdrawalAppl.setDc_appl_money(totalMoney);
                                userWithdrawalAppl.setSi_create_person(userWithdrawalAppl.getSw_user_id());
                                userWithdrawalAppl.setTm_create_time(new Date());
                                userWithdrawalAppl.setSi_modify_person(userWithdrawalAppl.getSw_user_id());
                                userWithdrawalAppl.setTm_modify_time(new Date());
                                userWithdrawalAppl.setTm_appl_time(new Date());
                                userWithdrawalAppl.setSr_appl_person(identifier.getUserName());
                                userWithdrawalAppl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                                userWithdrawalAppl.setSr_type(XcbConstantValue.WITHDRAWAL_APPL_WX);
                                userWithdrawalAppl.setSr_order_arr(sr_order_arr);
                                result = this.userWithdrawalApplDao.createUserWithdrawalAppl(userWithdrawalAppl);
                                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                    isSuccess = true;
                                } else {
                                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.wx.error"));
                                }
                            } else {
                                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.wx.error"));
                            }
                            break block39;
                        }
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.wx.error"));
                        break block39;
                    }
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, "\u63d0\u73b0\u5931\u8d25: \u53ef\u9000\u6b3e\u8d26\u6237\u4f59\u989d\u4e0d\u8db3");
                    break block39;
                }
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, "\u8bf7\u9009\u62e9\u8981\u62bc\u91d1\u9000\u6b3e\u7684\u8ba2\u5355!");
            }
            catch (Exception e) {
                throw new BusinessException(XcbConstantValue.USER_WITHDRAWAL_APPL_TX, "\u4f1a\u5458\u63d0\u73b0\u5f02\u5e38", (Throwable)e);
            }
        }
        if (isSuccess) {
            if ("Y".equals(user.getSr_is_subscribe())) {
                this.wxMessageService.sendMessage(userWithdrawalAppl.getSw_user_id(), null, XcbStringUtils.getObjtoString((Object)totalMoney), WxMessage.model_tx, null);
            }
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.create.success"));
        } else {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u7528\u6237\u63d0\u73b0\u6253\u6b3e\u5931\u8d25:" + ret_method.get(XcbConstantValue.MSG), "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.PC);
            operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)userWithdrawalAppl.getSw_user_id()));
            operationLogs.setSr_operate_result("");
            operationLogs.setSr_operate_table("");
            this.operationLogServiceImpl.createOperaLog(operationLogs);
        }
        this.initResultMap(ret_method);
        return ret_method;
    }

    public Map<String, Object> refuseAppl(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl, String sr_remarks) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        String msg = "";
        try {
            Tb_user_withdrawal_appl appl = this.userWithdrawalApplDao.findUserWithdrawalApplById(userWithdrawalAppl.getSd_id());
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(appl.getSw_user_id());
            BigDecimal dc_appl_money = XcbStringUtils.getObjToBigDecimal((Object)appl.getDc_appl_money());
            result = this.commonLogic.updateUser_account(identifier, dc_appl_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_ADD, XcbConstantValue.TB_MODEL_CZ);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                userWithdrawalAppl.setTm_appl_time(new Date());
                userWithdrawalAppl.setSr_appl_person(identifier.getUserName());
                userWithdrawalAppl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YJJ);
                userWithdrawalAppl.setSr_remarks(sr_remarks);
                result = this.userWithdrawalApplDao.updateUserWithdrawalAppl(userWithdrawalAppl);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    isSuccess = true;
                } else {
                    msg = PromptProperties.getProperty("userWithdrawalAppl.create.error");
                    this.log.error(msg);
                }
            } else {
                msg = PromptProperties.getProperty("userWithdrawalAppl.update.account.fail", userWithdrawalAppl.getSw_user_id());
                this.log.error(msg);
            }
            if (isSuccess) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.appl.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.STATUS, PromptProperties.getProperty("withdrawalAppl.appl.error"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_WITHDRAWAL_APPL_MAIN, PromptProperties.getProperty("withdrawalAppl.appl.error"), (Throwable)e);
        }
        return ret_method;
    }

    @Transactional
    Map<String, Object> mainPayMethod(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl) {
        Map<Object, Object> ret_method = new HashMap();
        Tb_sys_param sysParam = this.sysParamDao.findSysParamByKeyCode(XcbConstantValue.XTCL, XcbConstantValue.IS_APPL);
        ret_method = sysParam != null && sysParam.getSr_param_value().equals("Y") ? this.userAppl(identifier, userWithdrawalAppl) : this.payToUser(identifier, userWithdrawalAppl, "USER");
        return ret_method;
    }

    private Map<String, Object> userAppl(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl) {
        HashMap<String, Object> ret_method = new HashMap<String, String>();
        try {
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(userWithdrawalAppl.getSw_user_id());
            if (userWithdrawalAppl.getDc_appl_money().compareTo(userAccount.getDc_account_money()) == 1) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.check.warn3"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                return ret_method;
            }
            ret_method = this.createUserWithdrawalAppl(identifier, userWithdrawalAppl);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_WITHDRAWAL_APPL_MAIN, PromptProperties.getProperty("withdrawalAppl.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> createUserWithdrawalAppl(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        String msg = "";
        try {
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(userWithdrawalAppl.getSw_user_id());
            BigDecimal dc_appl_money = XcbStringUtils.getObjToBigDecimal((Object)userWithdrawalAppl.getDc_appl_money());
            result = this.commonLogic.updateUser_account(identifier, dc_appl_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_CZ);
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                String sr_order_sb = this.getOrderArr(userWithdrawalAppl);
                userWithdrawalAppl.setSi_create_person(userWithdrawalAppl.getSw_user_id());
                userWithdrawalAppl.setTm_create_time(new Date());
                userWithdrawalAppl.setSi_modify_person(userWithdrawalAppl.getSw_user_id());
                userWithdrawalAppl.setTm_modify_time(new Date());
                userWithdrawalAppl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_DSP);
                userWithdrawalAppl.setSr_order_arr(sr_order_sb);
                result = this.userWithdrawalApplDao.createUserWithdrawalAppl(userWithdrawalAppl);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    isSuccess = true;
                } else {
                    msg = PromptProperties.getProperty("userWithdrawalAppl.create.error");
                    this.log.error(msg);
                }
            } else {
                msg = PromptProperties.getProperty("userWithdrawalAppl.update.account.fail", userWithdrawalAppl.getSw_user_id());
                this.log.error(msg);
            }
            if (isSuccess) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("withdrawalAppl.create.success"));
            } else {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.STATUS, PromptProperties.getProperty("withdrawalAppl.create.fail"));
            }
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_WITHDRAWAL_APPL_MAIN, PromptProperties.getProperty("withdrawalAppl.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> payToUser(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl, String way) {
        HashMap<String, Object> ret_method = new HashMap();
        try {
            if ("USER".equals(way)) {
                Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(userWithdrawalAppl.getSw_user_id());
                if (userWithdrawalAppl.getDc_appl_money().compareTo(userAccount.getDc_account_money()) == 1) {
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.check.warn3"));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    return ret_method;
                }
            }
            ret_method = this.qiye_remittance_user(identifier, userWithdrawalAppl, way);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_WITHDRAWAL_APPL_MAIN, PromptProperties.getProperty("withdrawalAppl.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> autoPayToUser(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl) {
        Map<String, Object> ret_method = new HashMap<String, Object>();
        try {
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(userWithdrawalAppl.getSw_user_id());
            if (userWithdrawalAppl.getDc_appl_money().compareTo(userAccount.getDc_account_money()) == 1) {
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.check.warn3"));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                return ret_method;
            }
            Integer sw_user_id = userWithdrawalAppl.getSw_user_id();
            Tb_user user = this.userDao.findUserById(sw_user_id);
            BigDecimal dc_appl_money = XcbStringUtils.getObjToBigDecimal((Object)userWithdrawalAppl.getDc_appl_money());
            ret_method = this.remittance_user_wx_new(identifier, userWithdrawalAppl, user, userAccount, dc_appl_money);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_WITHDRAWAL_APPL_MAIN, PromptProperties.getProperty("withdrawalAppl.create.error"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findUserWithdrawalApplByParam_user(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_user_withdrawal_appl> applList = this.userWithdrawalApplDao.findUserWithdrawalApplByParam_user(userWithdrawalAppl, page);
            int totalCount = this.userWithdrawalApplDao.findCountByParam_user(userWithdrawalAppl);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("applList", applList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_WITHDRAWAL_APPL_FIND_BYPARAM, PromptProperties.getProperty("userWithdrawalAppl.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findLastUserWithdrawalAppl(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, BigDecimal> dataMap = new HashMap<String, BigDecimal>();
        try {
            BigDecimal dc_appl_money = BigDecimal.ZERO;
            List<Tb_user_withdrawal_appl> applList = this.userWithdrawalApplDao.findDSPUserWithdrawalAppl(userWithdrawalAppl.getSw_user_id());
            for (Tb_user_withdrawal_appl appl : applList) {
                dc_appl_money = BigDecimalUtil.add((BigDecimal)appl.getDc_appl_money(), (BigDecimal)dc_appl_money);
            }
            dataMap.put("dc_appl_money", dc_appl_money);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_WITHDRAWAL_FIND_LAST, PromptProperties.getProperty("userWithdrawalAppl.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    private Map<String, Object> findUserWithdrawalApplByParam_cpy(Identifier identifier, Tb_user_withdrawal_appl withdrawalAppl, Page page) {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            List<Tb_user_withdrawal_appl> applList = this.userWithdrawalApplDao.findUserWithdrawalApplByParam_cpy(withdrawalAppl, page);
            int totalCount = this.userWithdrawalApplDao.findCountByParam_cpy(withdrawalAppl);
            page.setTotal(totalCount);
            dataMap.put("page", page);
            dataMap.put("applList", applList);
            ret_method.put(XcbConstantValue.DATA, dataMap);
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            this.initResultMap(ret_method);
        }
        catch (Exception e) {
            throw new BusinessException(XcbConstantValue.USER_WITHDRAWAL_APPL_FIND_BYPARAM_CPY, PromptProperties.getProperty("withdrawalAppl.findbyparam.fail"), (Throwable)e);
        }
        return ret_method;
    }

    public Map<String, Object> qiye_remittance_user(Identifier identifier, Tb_user_withdrawal_appl withdrawalAppl, String way) {
        HashMap<String, Object> ret_method = new HashMap();
        try {
            ret_method = this.remittance_user_yj(identifier, withdrawalAppl, way);
        }
        catch (Exception e) {
            this.log.error("\u7528\u6237\u63d0\u73b0\u5f02\u5e38:" + e.getMessage());
        }
        return ret_method;
    }

    public Map<String, Object> remittance_user_yj(Identifier identifier, Tb_user_withdrawal_appl withdrawalAppl, String way) {
        Map<String, Object> ret_method = new HashMap<String, Object>();
        int result = 0;
        boolean isSuccess = false;
        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        try {
            String sr_type = withdrawalAppl.getSr_type();
            Integer sw_user_id = withdrawalAppl.getSw_user_id();
            Tb_user user = this.userDao.findUserById(sw_user_id);
            Tb_user_account userAccount = this.userAccountDao.findUserAccountByUser(sw_user_id);
            BigDecimal dc_appl_money = XcbStringUtils.getObjToBigDecimal((Object)withdrawalAppl.getDc_appl_money());
            if (this.pay_type.equals(sr_type) && (result = XcbStringUtils.getObjtoint((Object)(ret_method = this.remittance_user_wx_new(identifier, withdrawalAppl, user, userAccount, dc_appl_money, way)).get(XcbConstantValue.STATUS))) > XcbConstantValue.OPERA_INT_ZERO) {
                isSuccess = true;
            }
            if (!isSuccess) {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u63d0\u73b0\u7ed3\u7b97:" + ret_method.get(XcbConstantValue.MSG), "", "");
                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)withdrawalAppl.getSd_id()));
                operationLogs.setSr_operate_result("");
                operationLogs.setSr_operate_table("");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
            }
        }
        catch (Exception ex) {
            try {
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            }
            catch (Exception e) {
                this.log.error("\u4f01\u4e1a\u6c47\u6b3e\uff0c\u4e8b\u52a1\u56de\u6eda\u62a5\u9519");
            }
            this.log.error("\u4f01\u4e1a\u6c47\u6b3e-\u7528\u6237\u7ed3\u7b97\u62a5\u9519\uff1a " + XcbStringUtils.exceptionToString((Exception)ex));
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", "\u4ee3\u7406\u5546\u63d0\u73b0\u7ed3\u7b97", "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.PC);
            operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)withdrawalAppl.getSd_id()));
            operationLogs.setSr_operate_result("");
            operationLogs.setSr_operate_table("");
            this.operationLogServiceImpl.createOperaLog(operationLogs);
        }
        return ret_method;
    }

    /*
     * Unable to fully structure code
     */
    private Map<String, Object> remittance_user_wx_new(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl, Tb_user user, Tb_user_account userAccount, BigDecimal dc_appl_money, String way) throws Exception {
        block34: {
            block33: {
                ret_method = new HashMap<String, Object>();
                isSuccess = false;
                error_msg = "";
                result = 0;
                isCanAppl = false;
                if (!"USER".equals(way)) break block33;
                sr_order_sb = this.getOrderArr(userWithdrawalAppl);
                wtx_order = this.orderDao.findLastOrderByUser_wtx(userWithdrawalAppl.getSw_user_id());
                if (wtx_order == null) {
                    wtx_order = this.orderDao.findLastOrderByUser_wtx2(userWithdrawalAppl.getSw_user_id());
                }
                dc_rate = XcbStringUtils.getObjToBigDecimal((Object)wtx_order.getDc_rate());
                si_max_click = XcbStringUtils.getObjtoint((Object)wtx_order.getSi_max_click());
                si_max_appl = XcbStringUtils.getObjtoint((Object)wtx_order.getSi_max_appl());
                si_min_appl = XcbStringUtils.getObjtoint((Object)wtx_order.getSi_min_appl());
                si_click = XcbStringUtils.getObjtoint((Object)user.getSi_click());
                o_order = new Tb_order();
                o_order.setSw_netpoint_id(wtx_order.getSw_netpoint_id());
                o_order.setSr_order_starttime(XcbDateUtil.getStartDay((String)XcbDateUtil.getBeforeDay((Date)new Date(), (int)90, (String)"yyyy-MM-dd")));
                o_order.setSr_order_endtime(XcbDateUtil.getTodayEnd((Date)new Date()));
                all_cnt = this.orderDao.findAllOrderByNetId_task(o_order);
                success_cnt = this.orderDao.findSuccessOrderByNetId_task(o_order);
                if (all_cnt == 0) {
                    all_cnt = 1;
                }
                if ((dc_temp_rate = BigDecimalUtil.mul((BigDecimal)(dc_temp = BigDecimalUtil.div3((BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)success_cnt), (BigDecimal)XcbStringUtils.getObjToBigDecimal((Object)all_cnt))), (BigDecimal)new BigDecimal(100))).compareTo(dc_rate) == 1) {
                    si_wtx_cnt = this.orderDao.findCountOrderByUser_wtx(userWithdrawalAppl.getSw_user_id());
                    if (si_wtx_cnt == 0) {
                        si_wtx_cnt = this.orderDao.findCountOrderByUser_wtx2(userWithdrawalAppl.getSw_user_id());
                    }
                    isCanAppl = si_wtx_cnt < si_max_appl ? si_click >= si_max_click : true;
                } else {
                    isCanAppl = true;
                }
                if (!isCanAppl) ** GOTO lbl55
                result = this.commonLogic.updateUser_account(identifier, dc_appl_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_CZ);
                if (result > XcbConstantValue.OPERA_INT_ZERO) {
                    userWithdrawalAppl.setSi_create_person(userWithdrawalAppl.getSw_user_id());
                    userWithdrawalAppl.setTm_create_time(new Date());
                    userWithdrawalAppl.setSi_modify_person(userWithdrawalAppl.getSw_user_id());
                    userWithdrawalAppl.setTm_modify_time(new Date());
                    userWithdrawalAppl.setTm_appl_time(new Date());
                    userWithdrawalAppl.setSr_appl_person("\u7cfb\u7edf\u5ba1\u6279");
                    userWithdrawalAppl.setSr_order_arr(sr_order_sb);
                    userWithdrawalAppl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
                    result = this.userWithdrawalApplDao.createUserWithdrawalAppl(userWithdrawalAppl);
                    if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                        ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.account.error"));
                        return ret_method;
                    }
                } else {
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.account.error"));
                    return ret_method;
lbl55:
                    // 1 sources

                    result = 1;
                }
                break block34;
            }
            userWithdrawalAppl.setTm_appl_time(new Date());
            userWithdrawalAppl.setSr_appl_person(identifier.getUserName());
            userWithdrawalAppl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
            result = this.userWithdrawalApplDao.updateUserWithdrawalAppl(userWithdrawalAppl);
            if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.appl.update.fail"));
                return ret_method;
            }
            isCanAppl = true;
        }
        if (isCanAppl) {
            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                try {
                    orderList = this.orderDao.findDepositRefundByUserId(userWithdrawalAppl.getSw_user_id());
                    if (orderList != null && orderList.size() > 0) {
                        for (Tb_order order : orderList) {
                            user = this.userDao.findUserById(order.getSw_user_id());
                            pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
                            dc_deposit_money = order.getDc_deposit_money();
                            sr_checked = XcbStringUtils.getObjtoString((Object)order.getSr_checked());
                            if (XcbConstantValue.ORDER_F.equals(sr_checked)) {
                                order.setSr_checked(XcbConstantValue.ORDER_T);
                            }
                            this.log.info("\u4fee\u6539\u8ba2\u5355" + order.getSd_order_id() + "\u62bc\u91d1\u9000\u6b3e\u91d1\u989d:" + dc_deposit_money + "\u5143");
                            order.setDc_deposit_refund(dc_deposit_money);
                            result = this.orderDao.updateDepositRefund(order);
                            if (result > XcbConstantValue.OPERA_INT_ZERO) {
                                ordercashList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                                orderCash = ordercashList.get(0);
                                sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                                rtnMap = new HashMap<K, V>();
                                if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                                    refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                    total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                    pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                    rtnMap = this.wxAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                                    refund_fee = XcbStringUtils.getObjtoString((Object)dc_deposit_money);
                                    total_fee = XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money());
                                    pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                    rtnMap = this.wxSdjAPICommon.xcrefund(orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                } else {
                                    refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                    total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                    pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                    rtnMap = this.wxSpAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                                }
                                result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                                isSuccess = true;
                                n_user = new Tb_user();
                                if (XcbStringUtils.isNullOrBlank((Object)user.getSi_click())) {
                                    n_user.setSi_click(Integer.valueOf(0));
                                    n_user.setTm_click_time(new Date());
                                    n_user.setSd_user_id(user.getSd_user_id());
                                    this.userDao.updateClick(n_user);
                                }
                                if (result > XcbConstantValue.OPERA_INT_ZERO) continue;
                                error_msg = "\u62bc\u91d1\u8ba2\u5355\u9000\u6b3e\u5f02\u5e38:" + orderCash.getSd_ordercash_id();
                                this.log.info(error_msg);
                                operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                                operationLogs.setSr_operate_primarykey(order.getSd_order_id());
                                operationLogs.setSr_operate_table("tb_ordercash_stream");
                                this.operationLogServiceImpl.createOperaLog(operationLogs);
                                continue;
                            }
                            error_msg = PromptProperties.getProperty("withdrawalAppl.appl.fail", new Object[]{order.getSd_order_id()});
                            this.log.info("\u63d0\u73b0\u66f4\u65b0\u9000\u6b3e\u62bc\u91d1\u8ba2\u5355\u5f02\u5e38:" + error_msg);
                            operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                            operationLogs.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs.setSr_operate_primarykey(order.getSd_order_id());
                            operationLogs.setSr_operate_table("tb_order");
                            this.operationLogServiceImpl.createOperaLog(operationLogs);
                        }
                    }
                    orderList = this.orderDao.findDepositRefundByUserId_New(userWithdrawalAppl.getSw_user_id());
                    if (orderList == null || orderList.size() <= 0) ** GOTO lbl216
                    for (Tb_order order : orderList) {
                        pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
                        dc_deposit_money = order.getDc_deposit_money();
                        this.log.info("\u4fee\u6539\u8ba2\u5355" + order.getSd_order_id() + "\u62bc\u91d1\u9000\u6b3e\u91d1\u989d:" + dc_deposit_money + "\u5143");
                        order.setDc_deposit_refund(dc_deposit_money);
                        result = this.orderDao.updateDepositRefund(order);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            ordercashList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                            orderCash = ordercashList.get(0);
                            sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                            rtnMap = new HashMap<K, V>();
                            if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                                refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                rtnMap = this.wxAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                            } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                                refund_fee = XcbStringUtils.getObjtoString((Object)dc_deposit_money);
                                total_fee = XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money());
                                pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                rtnMap = this.wxSdjAPICommon.xcrefund(orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                            } else {
                                refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                                total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                                pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                                rtnMap = this.wxSpAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                            }
                            result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                            isSuccess = true;
                            n_user = new Tb_user();
                            if (XcbStringUtils.isNullOrBlank((Object)user.getSi_click())) {
                                n_user.setSi_click(Integer.valueOf(0));
                                n_user.setTm_click_time(new Date());
                                n_user.setSd_user_id(user.getSd_user_id());
                                this.userDao.updateClick(n_user);
                            }
                            if (result > XcbConstantValue.OPERA_INT_ZERO) continue;
                            error_msg = "\u62bc\u91d1\u8ba2\u5355\u9000\u6b3e\u5f02\u5e38:" + orderCash.getSd_ordercash_id();
                            this.log.info(error_msg);
                            operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                            operationLogs.setSr_operate_from(XcbConstantValue.PC);
                            operationLogs.setSr_operate_primarykey(order.getSd_order_id());
                            operationLogs.setSr_operate_table("tb_ordercash_stream");
                            this.operationLogServiceImpl.createOperaLog(operationLogs);
                            continue;
                        }
                        error_msg = PromptProperties.getProperty("withdrawalAppl.appl.fail", new Object[]{order.getSd_order_id()});
                        this.log.info("\u63d0\u73b0\u66f4\u65b0\u9000\u6b3e\u62bc\u91d1\u8ba2\u5355\u5f02\u5e38:" + error_msg);
                        operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey(order.getSd_order_id());
                        operationLogs.setSr_operate_table("tb_order");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                    }
                }
                catch (Exception e) {
                    error_msg = "\u5fae\u4fe1\u6253\u6b3e\u6210\u529f\uff0c\u4f46\u662f\u4e1a\u52a1\u5904\u7406\u5f02\u5e38";
                    this.log.info(error_msg);
                    operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.PC);
                    operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)userWithdrawalAppl.getSd_id()));
                    operationLogs.setSr_operate_table("");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                    this.log.error("\u4f01\u4e1a\u6253\u6b3e-\u7528\u6237\u4ed8\u6b3e-\u4ed8\u6b3e\u66f4\u65b0\u6d41\u6c34\u72b6\u6001\u5931\u8d25:" + XcbStringUtils.exceptionToString((Exception)e));
                    ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.create.success"));
                }
            }
        } else {
            isSuccess = true;
            n_user = new Tb_user();
            si_click = XcbStringUtils.getObjtoint((Object)user.getSi_click());
            n_user.setSi_click(Integer.valueOf(si_click + 1));
            n_user.setTm_click_time(new Date());
            n_user.setSd_user_id(user.getSd_user_id());
            this.userDao.updateClick(n_user);
        }
lbl216:
        // 5 sources

        if (isSuccess) {
            if (isCanAppl && "Y".equals(user.getSr_is_subscribe())) {
                this.wxMessageService.sendMessage(userWithdrawalAppl.getSw_user_id(), null, XcbStringUtils.getObjtoString((Object)userWithdrawalAppl.getDc_appl_money()), WxMessage.model_tx, null);
            }
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.create.success"));
        } else {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        return ret_method;
    }

    private Map<String, Object> remittance_user_wx_new(Identifier identifier, Tb_user_withdrawal_appl userWithdrawalAppl, Tb_user user, Tb_user_account userAccount, BigDecimal dc_appl_money) throws Exception {
        HashMap<String, Object> ret_method = new HashMap<String, Object>();
        boolean isSuccess = false;
        String error_msg = "";
        int result = 0;
        String sr_order_sb = this.getOrderArr(userWithdrawalAppl);
        result = this.commonLogic.updateUser_account(identifier, dc_appl_money, new BigDecimal(0), userAccount, XcbConstantValue.TB_TYPE_MINUS, XcbConstantValue.TB_MODEL_CZ);
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            userWithdrawalAppl.setSi_create_person(userWithdrawalAppl.getSw_user_id());
            userWithdrawalAppl.setTm_create_time(new Date());
            userWithdrawalAppl.setSi_modify_person(userWithdrawalAppl.getSw_user_id());
            userWithdrawalAppl.setTm_modify_time(new Date());
            userWithdrawalAppl.setTm_appl_time(new Date());
            userWithdrawalAppl.setSr_appl_person("\u7cfb\u7edf\u5ba1\u6279");
            userWithdrawalAppl.setSr_order_arr(sr_order_sb);
            userWithdrawalAppl.setSr_status(XcbConstantValue.WITHDRAWAL_APPL_STATUS_YTG);
            result = this.userWithdrawalApplDao.createUserWithdrawalAppl(userWithdrawalAppl);
            if (result <= XcbConstantValue.OPERA_INT_ZERO) {
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.account.error"));
                return ret_method;
            }
        } else {
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.pay.account.error"));
            return ret_method;
        }
        if (result > XcbConstantValue.OPERA_INT_ZERO) {
            try {
                String[] orderArr = sr_order_sb.split(",");
                for (int i = 0; i < orderArr.length; ++i) {
                    Tb_order order = this.orderDao.findOrderById_user(orderArr[i]);
                    Tb_wx_pay_info pay_info = this.wxPayInfoDao.findPayInfoByWay(user.getSr_way(), order.getSr_mchid());
                    BigDecimal dc_deposit_money = order.getDc_deposit_money();
                    String sr_checked = XcbStringUtils.getObjtoString((Object)order.getSr_checked());
                    if (XcbConstantValue.ORDER_F.equals(sr_checked)) {
                        order.setSr_checked(XcbConstantValue.ORDER_T);
                    }
                    this.log.info("\u4fee\u6539\u8ba2\u5355" + order.getSd_order_id() + "\u62bc\u91d1\u9000\u6b3e\u91d1\u989d:" + dc_deposit_money + "\u5143");
                    order.setDc_deposit_refund(dc_deposit_money);
                    result = this.orderDao.updateDepositRefund(order);
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        int total_fee;
                        List<Tb_ordercash_stream> ordercashList = this.orderCashStreamDao.findOrderCashStreamByOrderId(order.getSd_order_id());
                        Tb_ordercash_stream orderCash = ordercashList.get(0);
                        String sd_cash_id = CommonFunction.getVoucherNum((String)CommonFunction.zj_id);
                        Map<Object, Object> rtnMap = new HashMap();
                        if (XcbConstantValue.PTSH.equals(pay_info.getSr_type())) {
                            int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                            total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                            pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                            rtnMap = this.wxAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                        } else if (XcbConstantValue.SDJSH.equals(pay_info.getSr_type())) {
                            String refund_fee = XcbStringUtils.getObjtoString((Object)dc_deposit_money);
                            String total_fee2 = XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money());
                            pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                            rtnMap = this.wxSdjAPICommon.xcrefund(orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee2, refund_fee, pay_info);
                        } else {
                            int refund_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)dc_deposit_money)));
                            total_fee = XcbStringUtils.getObjtoint((Object)CommonFunction.yuanToFen((String)XcbStringUtils.getObjtoString((Object)orderCash.getDc_order_money())));
                            pay_info.setSr_refund_desc("\u7528\u6237\u63d0\u73b0");
                            rtnMap = this.wxSpAPIV3Common.xcrefund(identifier, orderCash.getSd_ordercash_id(), orderCash.getSw_bus_order_id(), sd_cash_id, total_fee, refund_fee, pay_info);
                        }
                        result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                        isSuccess = true;
                        if (result > XcbConstantValue.OPERA_INT_ZERO) continue;
                        error_msg = "\u62bc\u91d1\u8ba2\u5355\u9000\u6b3e\u5f02\u5e38:" + orderCash.getSd_ordercash_id();
                        this.log.info(error_msg);
                        Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                        operationLogs.setSr_operate_from(XcbConstantValue.PC);
                        operationLogs.setSr_operate_primarykey(order.getSd_order_id());
                        operationLogs.setSr_operate_table("tb_ordercash_stream");
                        this.operationLogServiceImpl.createOperaLog(operationLogs);
                        continue;
                    }
                    error_msg = PromptProperties.getProperty("withdrawalAppl.appl.fail", order.getSd_order_id());
                    this.log.info("\u63d0\u73b0\u66f4\u65b0\u9000\u6b3e\u62bc\u91d1\u8ba2\u5355\u5f02\u5e38:" + error_msg);
                    Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                    operationLogs.setSr_operate_from(XcbConstantValue.PC);
                    operationLogs.setSr_operate_primarykey(order.getSd_order_id());
                    operationLogs.setSr_operate_table("tb_order");
                    this.operationLogServiceImpl.createOperaLog(operationLogs);
                }
            }
            catch (Exception e) {
                error_msg = "\u5fae\u4fe1\u6253\u6b3e\u6210\u529f\uff0c\u4f46\u662f\u4e1a\u52a1\u5904\u7406\u5f02\u5e38";
                this.log.info(error_msg);
                Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_QYZF, XcbConstantValue.CASH_STREAM_ZJTX, Integer.valueOf(0), XcbConstantValue.OPEAR_FAIL_STR, "", error_msg, "", "");
                operationLogs.setSr_operate_from(XcbConstantValue.PC);
                operationLogs.setSr_operate_primarykey(XcbStringUtils.getObjtoString((Object)userWithdrawalAppl.getSd_id()));
                operationLogs.setSr_operate_table("");
                this.operationLogServiceImpl.createOperaLog(operationLogs);
                this.log.error("\u4f01\u4e1a\u6253\u6b3e-\u7528\u6237\u4ed8\u6b3e-\u4ed8\u6b3e\u66f4\u65b0\u6d41\u6c34\u72b6\u6001\u5931\u8d25:" + XcbStringUtils.exceptionToString((Exception)e));
                ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.create.success"));
            }
        } else {
            isSuccess = false;
        }
        if (isSuccess) {
            if ("Y".equals(user.getSr_is_subscribe())) {
                this.wxMessageService.sendMessage(userWithdrawalAppl.getSw_user_id(), null, XcbStringUtils.getObjtoString((Object)userWithdrawalAppl.getDc_appl_money()), WxMessage.model_tx, null);
            }
            ret_method.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret_method.put(XcbConstantValue.MSG, PromptProperties.getProperty("userWithdrawalAppl.create.success"));
        } else {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        return ret_method;
    }

    public String getOrderArr(Tb_user_withdrawal_appl userWithdrawalAppl) {
        String sr_order_arr = "";
        ArrayList<String> orderIds = new ArrayList<String>();
        StringBuffer sb = new StringBuffer();
        List<Tb_user_withdrawal_appl> applList = this.userWithdrawalApplDao.findDSPUserWithdrawalAppl(userWithdrawalAppl.getSw_user_id());
        if (applList != null && applList.size() > 0) {
            for (Tb_user_withdrawal_appl appl : applList) {
                sb.append(XcbStringUtils.getObjtoString((Object)appl.getSr_order_arr())).append(",");
            }
            sr_order_arr = sb.deleteCharAt(sb.length() - 1).toString();
        }
        String[] orderArr = sr_order_arr.split(",");
        List<String> list = Arrays.asList(orderArr);
        List<Tb_order> orderList = this.orderDao.findDepositRefundByUserId(userWithdrawalAppl.getSw_user_id());
        if (orderList != null && orderList.size() > 0) {
            if (XcbStringUtils.isNullOrBlank((Object)sr_order_arr)) {
                for (Tb_order order : orderList) {
                    orderIds.add(order.getSd_order_id());
                }
            } else {
                for (Tb_order order : orderList) {
                    if (list.contains(order.getSd_order_id())) continue;
                    orderIds.add(order.getSd_order_id());
                }
            }
        } else {
            orderList = this.orderDao.findDepositRefundByUserId_New(userWithdrawalAppl.getSw_user_id());
            if (orderList != null && orderList.size() > 0) {
                if (XcbStringUtils.isNullOrBlank((Object)sr_order_arr)) {
                    for (Tb_order order : orderList) {
                        orderIds.add(order.getSd_order_id());
                    }
                } else {
                    for (Tb_order order : orderList) {
                        if (list.contains(order.getSd_order_id())) continue;
                        orderIds.add(order.getSd_order_id());
                    }
                }
            }
        }
        sb = new StringBuffer();
        for (String id : orderIds) {
            sb.append(id).append(",");
        }
        String sr_order_sb = sb.deleteCharAt(sb.length() - 1).toString();
        return sr_order_sb;
    }
}

