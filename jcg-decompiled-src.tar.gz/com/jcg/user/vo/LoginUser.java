/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.user.vo;

public class LoginUser {
    private String username;
    private String password;
    private String smscode;
    private String reccode;
    private String sw_company_id;
    private String sr_way;
    private String deviceid;
    private String session_key;
    private String sr_open_id;
    private String sr_unionid;
    private String sr_zfb_open_id;
    private String code;
    private String encryptedData;
    private String iv;

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSmscode() {
        return this.smscode;
    }

    public void setSmscode(String smscode) {
        this.smscode = smscode;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getReccode() {
        return this.reccode;
    }

    public void setReccode(String reccode) {
        this.reccode = reccode;
    }

    public String getEncryptedData() {
        return this.encryptedData;
    }

    public void setEncryptedData(String encryptedData) {
        this.encryptedData = encryptedData;
    }

    public String getIv() {
        return this.iv;
    }

    public void setIv(String iv) {
        this.iv = iv;
    }

    public String getSession_key() {
        return this.session_key;
    }

    public void setSession_key(String session_key) {
        this.session_key = session_key;
    }

    public String getSr_open_id() {
        return this.sr_open_id;
    }

    public void setSr_open_id(String sr_open_id) {
        this.sr_open_id = sr_open_id;
    }

    public String getSr_zfb_open_id() {
        return this.sr_zfb_open_id;
    }

    public void setSr_zfb_open_id(String sr_zfb_open_id) {
        this.sr_zfb_open_id = sr_zfb_open_id;
    }

    public String getSw_company_id() {
        return this.sw_company_id;
    }

    public void setSw_company_id(String sw_company_id) {
        this.sw_company_id = sw_company_id;
    }

    public String getSr_unionid() {
        return this.sr_unionid;
    }

    public void setSr_unionid(String sr_unionid) {
        this.sr_unionid = sr_unionid;
    }

    public String getDeviceid() {
        return this.deviceid;
    }

    public void setDeviceid(String deviceid) {
        this.deviceid = deviceid;
    }

    public String getSr_way() {
        return this.sr_way;
    }

    public void setSr_way(String sr_way) {
        this.sr_way = sr_way;
    }
}

