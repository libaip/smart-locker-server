/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.wxpay.sdk.WXPayUtil
 *  com.jcg.common.model.XcbStringUtils
 *  javax.servlet.ServletInputStream
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.apache.log4j.Logger
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RequestMethod
 *  org.springframework.web.bind.annotation.ResponseBody
 *  org.springframework.web.bind.annotation.RestController
 */
package com.jcg.user.wechat.controller;

import com.github.wxpay.sdk.WXPayUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.user.common.BaseController;
import com.jcg.user.redis.RedisUtil;
import com.jcg.user.wechat.util.SignUtil;
import com.jcg.user.wechat.util.WXAPPBizMsgCrypt;
import com.jcg.user.zf.wx.WXzfCommon;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value={"/wechatApp"}, method={RequestMethod.POST})
public class WechatAppMsgController
extends BaseController {
    private static Logger logger = Logger.getLogger(WechatAppMsgController.class);
    @Autowired
    private WXAPPBizMsgCrypt wxBizMsgCrypt;
    @Autowired
    private WXzfCommon wxzfCommon;
    @Autowired
    private RedisUtil redis;

    @RequestMapping(value={"verify_wx_token"}, method={RequestMethod.GET})
    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            String signature = request.getParameter("signature");
            String timestamp = request.getParameter("timestamp");
            String nonce = request.getParameter("nonce");
            String echostr = request.getParameter("echostr");
            if (SignUtil.checkSignature(signature, timestamp, nonce)) {
                PrintWriter out = response.getWriter();
                out.print(echostr);
                out.close();
            } else {
                logger.info((Object)"\u8fd9\u91cc\u5b58\u5728\u975e\u6cd5\u8bf7\u6c42\uff01");
            }
        }
        catch (Exception e) {
            logger.error((Object)e, (Throwable)e);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @RequestMapping(value={"security"})
    @ResponseBody
    public String handlePublicMsg(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ServletInputStream is = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        try {
            response.setCharacterEncoding("UTF-8");
            is = request.getInputStream();
            isr = new InputStreamReader((InputStream)is, "utf-8");
            br = new BufferedReader(isr);
            String str = null;
            StringBuffer returnXml = new StringBuffer();
            while ((str = br.readLine()) != null) {
                returnXml.append(str);
            }
            Map encryptMap = WXPayUtil.xmlToMap((String)returnXml.toString());
            String decryptXml = this.wxBizMsgCrypt.decrypt((String)encryptMap.get("Encrypt"));
            System.out.println(decryptXml);
            Map decryptMap = WXPayUtil.xmlToMap((String)decryptXml);
            String msgType = (String)decryptMap.get("MsgType");
            if ("text".equals(msgType)) {
                HashMap returnMap = new HashMap();
                String content = (String)decryptMap.get("Content");
                this.log.info("\u63a5\u53d7\u6587\u672c" + decryptXml);
                this.log.info("\u63a5\u53d7\u6587\u672c\u5185\u5bb9" + content);
                if (!XcbStringUtils.isNullOrBlank((Object)content)) {
                    if (content.contains("\u62bc\u91d1") || content.contains("\u9000\u6b3e") || content.contains("\u9000") || content.contains("\u94b1") || content.contains("\u63d0\u73b0")) {
                        returnMap.put("ToUserName", decryptMap.get("FromUserName"));
                        returnMap.put("FromUserName", decryptMap.get("ToUserName"));
                        returnMap.put("CreateTime", new Date().getTime() + "");
                        returnMap.put("MsgType", "text");
                        returnMap.put("Content", "\u60a8\u53ef\u4ee5\u901a\u8fc7\u5e95\u90e8\u83dc\u5355\u680f\u3010\u9000\u6b3e&\u66f4\u591a\u3011\uff0c\u70b9\u51fb\u4f59\u989d\u9000\u6b3e\uff0c\u63d0\u73b0\u5230\u96f6\u94b1\uff0c\u5982\u6709\u7591\u95ee\u8bf7\u8054\u7cfb\u5ba2\u670d\u3002");
                    } else {
                        returnMap.put("ToUserName", decryptMap.get("FromUserName"));
                        returnMap.put("FromUserName", decryptMap.get("ToUserName"));
                        returnMap.put("CreateTime", new Date().getTime() + "");
                        returnMap.put("MsgType", "text");
                        returnMap.put("Content", "\u5728\u4f7f\u7528\u8fc7\u7a0b\u4e2d\u78b0\u5230\u4efb\u4f55\u95ee\u9898\uff0c\u8bf7\u62e8\u6253\u5ba2\u670d\u7535\u8bdd400-698-1080");
                    }
                }
            } else if ("image".equals(msgType)) {
            } else if ("voice".equals(msgType)) {
            } else if ("video".equals(msgType)) {
            } else if ("shortvideo".equals(msgType)) {
            } else if ("location".equals(msgType)) {
            } else if ("link".equals(msgType)) {
            } else if ("event".equals(msgType)) {
                // empty if block
            }
        }
        catch (Exception e) {
            logger.error((Object)"\u5904\u7406\u5fae\u4fe1\u516c\u4f17\u53f7\u8bf7\u6c42\u4fe1\u606f\uff0c\u5931\u8d25", (Throwable)e);
        }
        finally {
            if (null != is) {
                is.close();
            }
            if (null != isr) {
                isr.close();
            }
            if (null != br) {
                br.close();
            }
        }
        return null;
    }
}

