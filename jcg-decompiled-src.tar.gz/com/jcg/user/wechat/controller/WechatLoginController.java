/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.user.model.Tb_user
 *  com.vdurmont.emoji.EmojiParser
 *  javax.servlet.ServletException
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.ClientProtocolException
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.util.EntityUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Controller
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RequestMethod
 *  org.springframework.web.bind.annotation.ResponseBody
 */
package com.jcg.user.wechat.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.user.common.BaseController;
import com.jcg.user.common.CommonUtil;
import com.jcg.user.common.EmojiStringUtils;
import com.jcg.user.common.PromptProperties;
import com.jcg.user.model.Tb_user;
import com.jcg.user.redis.RedisUtil;
import com.jcg.user.service.SysParamServiceImpl;
import com.jcg.user.service.UserServiceImpl;
import com.jcg.user.wechat.util.SignUtil;
import com.jcg.user.wechat.vo.AccessToken;
import com.jcg.user.zf.wx.WXzfCommon;
import com.vdurmont.emoji.EmojiParser;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value={"/wx"})
public class WechatLoginController
extends BaseController {
    @Autowired
    private WXzfCommon wxzfCommon;
    @Autowired
    private UserServiceImpl userService;
    @Autowired
    private CommonUtil commonUtil;
    @Autowired
    private RedisUtil redis;
    @Autowired
    private SysParamServiceImpl sysParamService;

    @RequestMapping(value={"/wxLogin"}, method={RequestMethod.POST})
    @ResponseBody
    public Map<String, Object> wxLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        String msg = "";
        try {
            String code = request.getParameter("code");
            String sw_company_id = request.getParameter("sw_company_id");
            String sr_way = request.getParameter("sr_way");
            if (XcbStringUtils.isNullOrBlank((Object)sr_way)) {
                sr_way = XcbConstantValue.LOGIN_WAY;
            }
            Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, sr_way);
            AccessToken access = this.getAccessToken(code, info);
            String openid = access.getOpenid();
            String access_token = access.getAccessToken();
            String refresh_token = access.getRefreshToken();
            String unionid = "";
            boolean subscribe = false;
            if (!XcbStringUtils.isNullOrBlank((Object)openid)) {
                Map<String, Object> resMp;
                int result;
                String chickUrl = "https://api.weixin.qq.com/sns/auth?access_token=" + access_token + "&openid=" + openid;
                JSONObject chickuserInfo = this.doGetJson(chickUrl);
                System.out.println(chickuserInfo.toString());
                if (!"0".equals(chickuserInfo.getString("errcode"))) {
                    String refreshTokenUrl = "https://api.weixin.qq.com/sns/oauth2/refresh_token?appid=" + info.getSr_gzh_appid() + "&grant_type=refresh_token&refresh_token=" + refresh_token;
                    JSONObject refreshInfo = this.doGetJson(refreshTokenUrl);
                    access_token = refreshInfo.getString("access_token");
                }
                String infoUrl = "https://api.weixin.qq.com/sns/userinfo?access_token=" + access_token + "&openid=" + openid + "&lang=zh_CN";
                System.out.println("infoUrl:" + infoUrl);
                JSONObject userInfo = this.doGetJson(infoUrl);
                if (XcbConstantValue.WX_INFO_MODE_1.equals(info.getSr_type()) || XcbConstantValue.WX_INFO_MODE_4.equals(info.getSr_type())) {
                    unionid = userInfo.getString("unionid");
                }
                System.out.println("JSON-----" + userInfo.toString());
                System.out.println("openid-----" + userInfo.getString("openid"));
                if (!XcbStringUtils.isNullOrBlank((Object)userInfo.getString("openid"))) {
                    if (XcbConstantValue.WX_INFO_MODE_1.equals(info.getSr_type()) || XcbConstantValue.WX_INFO_MODE_4.equals(info.getSr_type())) {
                        System.out.println("unionid-----" + userInfo.getString("unionid"));
                    }
                    System.out.println("\u540d\u5b57-----" + userInfo.getString("nickname"));
                    System.out.println("\u5934\u50cf-----" + userInfo.getString("headimgurl"));
                    this.log.info("JSON-----" + userInfo.toString());
                    this.log.info("openid-----" + userInfo.getString("openid"));
                    if (XcbConstantValue.WX_INFO_MODE_1.equals(info.getSr_type()) || XcbConstantValue.WX_INFO_MODE_4.equals(info.getSr_type())) {
                        this.log.info("unionid-----" + userInfo.getString("unionid"));
                    }
                    this.log.info("\u540d\u5b57-----" + userInfo.getString("nickname"));
                    this.log.info("\u5934\u50cf-----" + userInfo.getString("headimgurl"));
                }
                Tb_user user = new Tb_user();
                user.setSr_open_id(openid);
                if (XcbConstantValue.WX_INFO_MODE_1.equals(info.getSr_type()) || XcbConstantValue.WX_INFO_MODE_4.equals(info.getSr_type())) {
                    user.setSr_unionid(unionid);
                }
                user.setSw_company_id(sw_company_id);
                user.setSr_way(sr_way);
                String username = "";
                if (!XcbStringUtils.isNullOrBlank((Object)userInfo.getString("openid"))) {
                    String nickname = EmojiParser.removeAllEmojis((String)userInfo.getString("nickname"));
                    if (EmojiStringUtils.hasEmoji(nickname)) {
                        username = "\u5fae\u4fe1\u7528\u6237";
                        System.out.println("\u540d\u5b57\u6709\u7279\u6b8a\u5b57\u7b26,\u5904\u7406\u540e-----" + username);
                        this.log.info("\u540d\u5b57\u6709\u7279\u6b8a\u5b57\u7b26\uff0c\u5904\u7406\u540e-----" + username);
                    } else {
                        username = nickname;
                    }
                } else {
                    username = "\u5fae\u4fe1\u7528\u6237";
                }
                user.setSr_user_petname(username);
                if (!XcbStringUtils.isNullOrBlank((Object)userInfo.getString("openid"))) {
                    user.setSr_wx_avatar_url(userInfo.getString("headimgurl"));
                    user.setSr_sex(userInfo.getString("sex"));
                }
                if ((result = XcbStringUtils.getObjtoint((Object)(resMp = this.userService.checkWxUser(identifier, user)).get(XcbConstantValue.STATUS))) > XcbConstantValue.OPERA_INT_ZERO) {
                    boolean isRegister = (Boolean)resMp.get("isRegister");
                    if (isRegister) {
                        user = (Tb_user)resMp.get("user");
                    } else {
                        result = this.createUser(identifier, user);
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            user = this.Speedlogin(identifier, user);
                        }
                    }
                    String token = this.commonUtil.creatToken(XcbStringUtils.getObjtoString((Object)user.getSd_user_id()));
                    msg = PromptProperties.getProperty("user.login.success");
                    dataMap.put("token", token);
                    dataMap.put("userid", user.getSd_user_id());
                    dataMap.put("openid", user.getSr_open_id());
                    dataMap.put("info_mode", info.getSr_type());
                    if (XcbConstantValue.WX_INFO_MODE_1.equals(info.getSr_type()) || XcbConstantValue.WX_INFO_MODE_4.equals(info.getSr_type())) {
                        dataMap.put("unionid", user.getSr_unionid());
                    } else {
                        dataMap.put("unionid", "");
                    }
                    dataMap.put("nickname", user.getSr_user_petname());
                    dataMap.put("username", user.getSr_user_name());
                    dataMap.put("avatar", user.getSr_wx_avatar_url());
                    dataMap.put("sex", user.getSr_sex());
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.MSG, msg);
                    ret.put(XcbConstantValue.DATA, dataMap);
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u767b\u5f55\u8fc7\u671f");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private AccessToken getAccessToken(String code, Tb_company company) throws Exception, IOException {
        AccessToken access = new AccessToken();
        if (null != this.redis.get(code)) {
            access = (AccessToken)((Object)this.redis.get(code));
        } else {
            String url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=" + company.getSr_wx_gzh_appid() + "&secret=" + company.getSr_wx_gzh_appsecret() + "&code=" + code + "&grant_type=authorization_code";
            System.out.println("url:" + url);
            JSONObject jsonObject = this.doGetJson(url);
            try {
                System.out.println("\u7ed3\u679c:" + jsonObject.toString());
                String openid = jsonObject.getString("openid");
                String access_token = jsonObject.getString("access_token");
                String refresh_token = jsonObject.getString("refresh_token");
                int expires = jsonObject.getInteger("expires_in");
                access.setOpenid(openid);
                access.setAccessToken(access_token);
                access.setExpiresin(expires);
                access.setRefreshToken(refresh_token);
                this.redis.setForTimeMIN(code, access, 100L);
            }
            catch (Exception e) {
                System.out.println("\u5fae\u4fe1\u516c\u4f17\u53f7\u6388\u6743code\u5df2\u8fc7\u671f");
                this.log.info("\u5fae\u4fe1\u516c\u4f17\u53f7\u6388\u6743code\u5df2\u8fc7\u671f");
            }
        }
        return access;
    }

    private AccessToken getAccessToken(String code, Tb_wx_info info) throws Exception, IOException {
        AccessToken access = new AccessToken();
        if (null != this.redis.get(code)) {
            access = (AccessToken)((Object)this.redis.get(code));
        } else {
            String url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=" + info.getSr_gzh_appid() + "&secret=" + info.getSr_gzh_appsecret() + "&code=" + code + "&grant_type=authorization_code";
            System.out.println("url:" + url);
            JSONObject jsonObject = this.doGetJson(url);
            try {
                System.out.println("\u7ed3\u679c:" + jsonObject.toString());
                String openid = jsonObject.getString("openid");
                String access_token = jsonObject.getString("access_token");
                String refresh_token = jsonObject.getString("refresh_token");
                int expires = jsonObject.getInteger("expires_in");
                access.setOpenid(openid);
                access.setAccessToken(access_token);
                access.setExpiresin(expires);
                access.setRefreshToken(refresh_token);
                this.redis.setForTimeMIN(code, access, 100L);
            }
            catch (Exception e) {
                System.out.println("\u5fae\u4fe1\u516c\u4f17\u53f7\u6388\u6743code\u5df2\u8fc7\u671f");
                this.log.info("\u5fae\u4fe1\u516c\u4f17\u53f7\u6388\u6743code\u5df2\u8fc7\u671f");
            }
        }
        return access;
    }

    public String getAccessToken(Tb_wx_info info) throws Exception, IOException {
        String access_token = XcbStringUtils.getObjtoString((Object)this.redis.get("access_token_" + info.getSr_code()));
        if (XcbStringUtils.isNullOrBlank((Object)access_token)) {
            String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + info.getSr_gzh_appid() + "&secret=" + info.getSr_gzh_appsecret();
            JSONObject jsonObject = this.doGetJson(url);
            this.log.info(jsonObject.toJSONString());
            access_token = jsonObject.getString("access_token");
            int expires = jsonObject.getInteger("expires_in");
            this.redis.setForTimeMIN("access_token_" + info.getSr_code(), access_token, 100L);
        }
        return access_token;
    }

    private String getJsApiTicket(String access_token) throws Exception, IOException {
        String ticket = "";
        String url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=" + access_token + "&type=jsapi";
        JSONObject jsonObject = this.doGetJson(url);
        ticket = jsonObject.getString("ticket");
        return ticket;
    }

    @RequestMapping(value={"/getWxJsapi"}, method={RequestMethod.POST})
    @ResponseBody
    public Map<String, String> getWxJsapi(HttpServletRequest request, HttpServletResponse resp) throws Exception {
        Identifier identifier = new Identifier(Integer.valueOf(0), request.getRemoteAddr(), request.getRequestURI());
        Map<String, String> ret = new HashMap<String, String>();
        String sr_way = request.getParameter("sr_way");
        Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, sr_way);
        if (info != null) {
            String accessToken = XcbStringUtils.getObjtoString((Object)this.redis.get("access_token_" + info.getSr_code()));
            if (XcbStringUtils.isNullOrBlank((Object)accessToken)) {
                accessToken = this.getAccessToken(info);
            }
            String jsapi_ticket = this.getJsApiTicket(accessToken);
            String url = request.getParameter("url");
            ret = SignUtil.sign(jsapi_ticket, url);
            ret.put("appid", info.getSr_gzh_appid());
            ret.put("app_appid", info.getSr_appid());
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
        } else {
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            ret.put(XcbConstantValue.MSG, "\u53c2\u6570\u7f3a\u5931");
        }
        return ret;
    }

    public JSONObject doGetJson(String url) throws ClientProtocolException, IOException {
        JSONObject jsonObject = null;
        DefaultHttpClient client = new DefaultHttpClient();
        HttpGet httpGet = new HttpGet(url);
        CloseableHttpResponse response = client.execute((HttpUriRequest)httpGet);
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            String result = EntityUtils.toString((HttpEntity)entity, (String)"UTF-8");
            jsonObject = JSON.parseObject((String)result);
        }
        return jsonObject;
    }

    public int createUser(Identifier identifier, Tb_user user) {
        user.setTm_create_time(new Date());
        user.setSr_user_status(XcbConstantValue.USER_YJH);
        user.setSr_user_source(XcbConstantValue.USER_SOURCE_WX);
        user.setTm_register_time(new Date());
        user.setTm_modify_time(new Date());
        Map<String, Object> ret = this.userService.createWxUser(identifier, user);
        int result = XcbStringUtils.getObjtoint((Object)ret.get(XcbConstantValue.STATUS));
        return result;
    }

    public Tb_user Speedlogin(Identifier identifier, Tb_user user) throws Exception {
        Map<String, Object> returnMap = this.userService.loginWithOpenId(identifier, user);
        if (returnMap.get(XcbConstantValue.DATA) != null) {
            user = (Tb_user)returnMap.get(XcbConstantValue.DATA);
        }
        return user;
    }
}

