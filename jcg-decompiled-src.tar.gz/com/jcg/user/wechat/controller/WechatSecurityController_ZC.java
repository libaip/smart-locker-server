/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSONObject
 *  com.github.wxpay.sdk.WXPayUtil
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_netpoint
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.user.model.Tb_user
 *  javax.servlet.ServletInputStream
 *  javax.servlet.http.HttpServletRequest
 *  javax.servlet.http.HttpServletResponse
 *  net.sf.json.JSONObject
 *  org.apache.log4j.Logger
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.web.bind.annotation.RequestMapping
 *  org.springframework.web.bind.annotation.RequestMethod
 *  org.springframework.web.bind.annotation.ResponseBody
 *  org.springframework.web.bind.annotation.RestController
 */
package com.jcg.user.wechat.controller;

import com.github.wxpay.sdk.WXPayUtil;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_netpoint;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.user.common.BaseController;
import com.jcg.user.model.Tb_user;
import com.jcg.user.redis.RedisUtil;
import com.jcg.user.service.DeviceServiceImpl;
import com.jcg.user.service.SysParamServiceImpl;
import com.jcg.user.service.UserServiceImpl;
import com.jcg.user.wechat.controller.WechatLoginController;
import com.jcg.user.wechat.util.MessageUtil;
import com.jcg.user.wechat.util.SignUtil;
import com.jcg.user.wechat.util.WXBizMsgCrypt;
import com.jcg.user.wechat.vo.Article;
import com.jcg.user.wechat.vo.NewsMessage;
import com.jcg.user.zf.wx.WXzfCommon;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value={"/wechat_zc"}, method={RequestMethod.POST})
public class WechatSecurityController_ZC
extends BaseController {
    private String sr_code = "ZC";
    private static Logger logger = Logger.getLogger(WechatSecurityController_ZC.class);
    @Autowired
    private WXBizMsgCrypt wxBizMsgCrypt;
    @Autowired
    private DeviceServiceImpl deviceService;
    @Autowired
    private UserServiceImpl userService;
    @Autowired
    private WXzfCommon wxzfCommon;
    @Autowired
    WechatLoginController wechatLogin;
    @Autowired
    private RedisUtil redis;
    @Autowired
    private SysParamServiceImpl sysParamService;
    private String bgPath = XcbConstantValue.img_host + "/" + XcbConstantValue.companyid + "/common/title.png";
    private String cunPath = XcbConstantValue.img_host + "/" + XcbConstantValue.companyid + "/common/cun.png";
    private String quPath = XcbConstantValue.img_host + "/" + XcbConstantValue.companyid + "/common/qu.png";
    private String mpNews = "https://mp.weixin.qq.com/s?__biz=MzkzOTYwMDAwMw==&mid=2247483661&idx=1&sn=7703a4169ba4b6f4d1a247d0c9cd52ca&chksm=c2ef30e1f598b9f76b9a1e5352c260efda9c285506f9bf898765538347a669774d4ee467e840#rd";

    @RequestMapping(value={"verify_wx_token"}, method={RequestMethod.GET})
    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            Identifier identifier = new Identifier();
            String signature = request.getParameter("signature");
            String timestamp = request.getParameter("timestamp");
            String nonce = request.getParameter("nonce");
            String echostr = request.getParameter("echostr");
            Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, this.sr_code);
            if (SignUtil.checkSignature(signature, timestamp, nonce, info)) {
                PrintWriter out = response.getWriter();
                out.print(echostr);
                out.close();
            } else {
                logger.info((Object)"\u8fd9\u91cc\u5b58\u5728\u975e\u6cd5\u8bf7\u6c42\uff01");
            }
        }
        catch (Exception e) {
            logger.error((Object)e, (Throwable)e);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @RequestMapping(value={"security"})
    @ResponseBody
    public String handlePublicMsg(HttpServletRequest request, HttpServletResponse response) throws Exception {
        block73: {
            Identifier identifier = new Identifier();
            Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, this.sr_code);
            ServletInputStream is = null;
            InputStreamReader isr = null;
            BufferedReader br = null;
            try {
                response.setCharacterEncoding("UTF-8");
                is = request.getInputStream();
                isr = new InputStreamReader((InputStream)is, "utf-8");
                br = new BufferedReader(isr);
                String str = null;
                StringBuffer returnXml = new StringBuffer();
                while ((str = br.readLine()) != null) {
                    returnXml.append(str);
                }
                Map encryptMap = WXPayUtil.xmlToMap((String)returnXml.toString());
                this.log.info(returnXml.toString());
                String decryptXml = this.wxBizMsgCrypt.decrypt((String)encryptMap.get("Encrypt"), info);
                Map decryptMap = WXPayUtil.xmlToMap((String)decryptXml);
                String msgType = (String)decryptMap.get("MsgType");
                if ("text".equals(msgType)) {
                    String encryptMsg;
                    String access_token;
                    HashMap returnMap = new HashMap();
                    String content = (String)decryptMap.get("Content");
                    this.log.info("\u63a5\u53d7\u6587\u672c" + decryptXml);
                    this.log.info("\u63a5\u53d7\u6587\u672c\u5185\u5bb9" + content);
                    if (!XcbStringUtils.isNullOrBlank((Object)content)) {
                        if (content.contains("\u62bc\u91d1") || content.contains("\u9000\u6b3e") || content.contains("\u9000") || content.contains("\u94b1") || content.contains("\u63d0\u73b0")) {
                            returnMap.put("ToUserName", decryptMap.get("FromUserName"));
                            returnMap.put("FromUserName", decryptMap.get("ToUserName"));
                            returnMap.put("CreateTime", new Date().getTime() + "");
                            returnMap.put("MsgType", "text");
                            returnMap.put("Content", "\u60a8\u53ef\u4ee5\u901a\u8fc7\u5e95\u90e8\u83dc\u5355\u680f\u3010\u9000\u6b3e&\u66f4\u591a\u3011\uff0c\u70b9\u51fb\u4f59\u989d\u9000\u6b3e\uff0c\u63d0\u73b0\u5230\u96f6\u94b1\uff0c\u5982\u6709\u7591\u95ee\u8bf7\u8054\u7cfb\u5ba2\u670d\u3002");
                        } else if (content.equals("\u53d6") || content.equals("\u5f00") || content.equals("\u4e2d\u9014")) {
                            String qubao = "pages/my/order/pickup";
                            access_token = this.wechatLogin.getAccessToken(info);
                            String url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" + access_token;
                            JSONObject object = new JSONObject();
                            object.put((Object)"touser", decryptMap.get("FromUserName"));
                            object.put((Object)"msgtype", (Object)"text");
                            JSONObject object1 = new JSONObject();
                            object1.put((Object)"content", (Object)("<a href=\"http://www.qq.com\" data-miniprogram-appid=\"" + info.getSr_appid() + "\" data-miniprogram-path=\"" + qubao + "\">\u261e\u261e\u261e\u70b9\u51fb\u6211\u53d6\u5305\u261c\u261c\u261c</a>"));
                            object.put((Object)"text", (Object)object1);
                            String string = this.wxzfCommon.sendPost(url, object.toString());
                        } else {
                            returnMap.put("ToUserName", decryptMap.get("FromUserName"));
                            returnMap.put("FromUserName", decryptMap.get("ToUserName"));
                            returnMap.put("CreateTime", new Date().getTime() + "");
                            returnMap.put("MsgType", "text");
                            returnMap.put("Content", "\u5728\u4f7f\u7528\u8fc7\u7a0b\u4e2d\u78b0\u5230\u4efb\u4f55\u95ee\u9898\uff0c\u8bf7\u62e8\u6253\u5ba2\u670d\u7535\u8bdd400-698-1080");
                        }
                    } else {
                        returnMap.put("ToUserName", decryptMap.get("FromUserName"));
                        returnMap.put("FromUserName", decryptMap.get("ToUserName"));
                        returnMap.put("CreateTime", new Date().getTime() + "");
                        returnMap.put("MsgType", "text");
                        returnMap.put("Content", "\u5728\u4f7f\u7528\u8fc7\u7a0b\u4e2d\u78b0\u5230\u4efb\u4f55\u95ee\u9898\uff0c\u8bf7\u62e8\u6253\u5ba2\u670d\u7535\u8bdd400-698-1080");
                    }
                    access_token = encryptMsg = this.wxBizMsgCrypt.encryptMsg(WXPayUtil.mapToXml(returnMap), new Date().getTime() + "", this.wxBizMsgCrypt.getRandomStr(), info);
                    return access_token;
                }
                if ("image".equals(msgType)) {
                    break block73;
                }
                if ("voice".equals(msgType)) {
                    break block73;
                }
                if ("video".equals(msgType)) {
                    break block73;
                }
                if ("shortvideo".equals(msgType)) {
                    break block73;
                }
                if ("location".equals(msgType)) {
                    break block73;
                }
                if ("link".equals(msgType)) {
                    break block73;
                }
                if (!"event".equals(msgType)) break block73;
                String event = (String)decryptMap.get("Event");
                if ("subscribe".equals(event)) {
                    ArrayList<Article> articleList = new ArrayList<Article>();
                    NewsMessage newsMessage = new NewsMessage();
                    newsMessage.setToUserName((String)decryptMap.get("FromUserName"));
                    newsMessage.setFromUserName((String)decryptMap.get("ToUserName"));
                    newsMessage.setCreateTime(new Date().getTime());
                    newsMessage.setMsgType("news");
                    String EventKey = (String)decryptMap.get("EventKey");
                    if (!XcbStringUtils.isNullOrBlank((Object)EventKey)) {
                        String finalQuery;
                        String finalCunbao;
                        Timer timer;
                        String deviceid = EventKey.split("_")[1];
                        String openid = (String)decryptMap.get("FromUserName");
                        Tb_user user = new Tb_user();
                        user.setSr_open_id(openid);
                        user.setSw_company_id(XcbConstantValue.companyid);
                        user.setSr_way(this.sr_code);
                        Map<String, Object> rtnMap = this.userService.getUnionId(new Identifier(), user);
                        int cnt = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                        if (cnt > XcbConstantValue.OPERA_INT_ZERO) {
                            String unionid = XcbStringUtils.getObjtoString((Object)rtnMap.get(XcbConstantValue.DATA));
                            user.setSr_unionid(unionid);
                            user.setSr_is_subscribe("Y");
                            Map<String, Object> resMp = this.userService.checkWxUser(new Identifier(), user);
                            cnt = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
                            if (cnt > XcbConstantValue.OPERA_INT_ZERO) {
                                boolean isRegister = (Boolean)resMp.get("isRegister");
                                if (isRegister) {
                                    user = (Tb_user)resMp.get("user");
                                    cnt = XcbConstantValue.OPERA_INT_ONE;
                                } else {
                                    user.setSr_user_petname("\u5fae\u4fe1\u7528\u6237");
                                    user.setSr_register_device(deviceid);
                                    cnt = this.wechatLogin.createUser(new Identifier(), user);
                                }
                            }
                        }
                        if (cnt <= XcbConstantValue.OPERA_INT_ZERO) break block73;
                        String respMessage = "";
                        String cunbao = "pages/my/scan/setting";
                        String qubao = "pages/my/order/pickup";
                        String query = "";
                        rtnMap = this.deviceService.findDeviceByDeviceId((String)decryptMap.get("FromUserName"), deviceid);
                        int result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                        if (result > XcbConstantValue.OPERA_INT_ZERO) {
                            Map dataMap = (Map)rtnMap.get(XcbConstantValue.DATA);
                            HashMap<String, String> pathMap = new HashMap<String, String>();
                            int sr_scan_time = XcbStringUtils.getObjtoint(dataMap.get("sr_scan_time"));
                            String sr_unionid = XcbStringUtils.getObjtoString(dataMap.get("sr_unionid"));
                            Tb_netpoint netpoint = (Tb_netpoint)dataMap.get("netpoint");
                            Tb_device device = (Tb_device)dataMap.get("device");
                            List list = (List)dataMap.get("list");
                            pathMap.put("boxtype", "");
                            if ("Y".equals(device.getSr_cj_function())) {
                                pathMap.put("path", "/setting");
                                cunbao = "pages/my/scan/setting";
                                query = "type=1&mid=" + device.getSi_mainboard_id();
                                pathMap.put("url", "/pages/my/scan/setting?" + query);
                            } else if (list.size() == 1) {
                                pathMap.put("path", "/payinfo");
                                pathMap.put("boxtype", (String)list.get(0));
                                cunbao = "pages/my/scan/payinfo";
                                query = "type=2&mid=" + device.getSi_mainboard_id() + "&boxtype=" + (String)list.get(0);
                                pathMap.put("url", "/pages/my/scan/payinfo?" + query);
                            } else {
                                pathMap.put("path", "/choose");
                                cunbao = "pages/my/scan/choose";
                                query = "type=2&mid=" + device.getSi_mainboard_id();
                                pathMap.put("url", "/pages/my/scan/choose?" + query);
                            }
                            pathMap.put("mid", device.getSi_mainboard_id());
                            pathMap.put("cj", device.getSr_cj_function());
                            Article article1 = new Article();
                            if (!XcbStringUtils.isNullOrBlank((Object)netpoint.getSr_net_name()) && netpoint.getSr_net_name().length() > 12) {
                                StringBuffer sb = new StringBuffer();
                                sb.append(netpoint.getSr_net_name().substring(0, 12)).append("...");
                                netpoint.setSr_net_name(sb.toString());
                            }
                            String title = netpoint.getSr_net_name();
                            String sr_device_name = XcbStringUtils.getObjtoString((Object)device.getSr_device_name());
                            String sr_alias = XcbStringUtils.getObjtoString((Object)device.getSr_alias());
                            if (!XcbStringUtils.isNullOrBlank((Object)sr_alias)) {
                                title = sr_alias.contains("\u67dc") ? title + sr_alias : title + sr_alias + "\u533a";
                            }
                            if (!XcbStringUtils.isNullOrBlank((Object)sr_device_name)) {
                                title = title + "(" + sr_device_name + ")";
                            }
                            article1.setTitle(title);
                            article1.setDescription(info.getSr_name());
                            article1.setPicUrl(this.bgPath);
                            article1.setUrl(this.mpNews);
                            String jsonStr = JSONObject.fromObject(pathMap).toString();
                            if (!XcbStringUtils.isNullOrBlank((Object)sr_unionid)) {
                                this.redis.setForTimeMIN(sr_unionid, jsonStr, sr_scan_time);
                            }
                            Article article2 = new Article();
                            article2.setTitle("            \u2b07\ufe0f\u2b07\ufe0f\u2b07\ufe0f \u70b9\u51fb\u4e0b\u65b9\u5b58\u5305 \u2b07\ufe0f\u2b07\ufe0f\u2b07\ufe0f            ");
                            article2.setUrl(this.mpNews);
                            articleList.add(article1);
                            articleList.add(article2);
                            newsMessage.setArticleCount(articleList.size());
                            newsMessage.setArticles(articleList);
                            respMessage = MessageUtil.newsMessageToXml(newsMessage);
                        } else {
                            HashMap returnMap = new HashMap();
                            returnMap.put("ToUserName", decryptMap.get("FromUserName"));
                            returnMap.put("FromUserName", decryptMap.get("ToUserName"));
                            returnMap.put("CreateTime", new Date().getTime() + "");
                            returnMap.put("MsgType", "text");
                            returnMap.put("Content", "\u672a\u67e5\u5230\u6b64\u4e8c\u7ef4\u7801\u7684\u673a\u67dc\uff0c\u8bf7\u79fb\u6b65\u5176\u4ed6\u673a\u67dc\u626b\u7801\u4f7f\u7528");
                            respMessage = WXPayUtil.mapToXml(returnMap);
                        }
                        String encryptMsg = this.wxBizMsgCrypt.encryptMsg(respMessage, new Date().getTime() + "", this.wxBizMsgCrypt.getRandomStr(), info);
                        PrintWriter out = null;
                        try {
                            out = response.getWriter();
                            out.print(encryptMsg);
                            out.close();
                            out = null;
                        }
                        catch (IOException e) {
                            try {
                                out.close();
                                out = null;
                                e.printStackTrace();
                                out.close();
                                out = null;
                            }
                            catch (Throwable throwable) {
                                out.close();
                                out = null;
                                String access_token = this.wechatLogin.getAccessToken(info);
                                Timer timer2 = new Timer();
                                String finalCunbao2 = cunbao;
                                String finalQuery2 = query;
                                timer2.schedule(new TimerTask(access_token, decryptMap, info, finalCunbao2, finalQuery2){
                                    final /* synthetic */ String val$access_token;
                                    final /* synthetic */ Map val$decryptMap;
                                    final /* synthetic */ Tb_wx_info val$info;
                                    final /* synthetic */ String val$finalCunbao;
                                    final /* synthetic */ String val$finalQuery;
                                    {
                                        this.val$access_token = string;
                                        this.val$decryptMap = map;
                                        this.val$info = tb_wx_info;
                                        this.val$finalCunbao = string2;
                                        this.val$finalQuery = string3;
                                    }

                                    @Override
                                    public void run() {
                                        String url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" + this.val$access_token;
                                        JSONObject object = new JSONObject();
                                        object.put((Object)"touser", this.val$decryptMap.get("FromUserName"));
                                        object.put((Object)"msgtype", (Object)"text");
                                        JSONObject object1 = new JSONObject();
                                        object1.put((Object)"content", (Object)("<a href=\"http://www.qq.com\" data-miniprogram-appid=\"" + this.val$info.getSr_appid() + "\" data-miniprogram-path=\"" + this.val$finalCunbao + "?" + this.val$finalQuery + "\">\u261e\u261e\u261e\u70b9\u51fb\u6211\u5b58\u5305\u261c\u261c\u261c</a>"));
                                        object.put((Object)"text", (Object)object1);
                                        String resp = WechatSecurityController_ZC.this.wxzfCommon.sendPost(url, object.toString());
                                    }
                                }, 1200L);
                                throw throwable;
                            }
                            String access_token = this.wechatLogin.getAccessToken(info);
                            timer = new Timer();
                            finalCunbao = cunbao;
                            finalQuery = query;
                            timer.schedule(new /* invalid duplicate definition of identical inner class */, 1200L);
                            break block73;
                        }
                        String access_token = this.wechatLogin.getAccessToken(info);
                        timer = new Timer();
                        finalCunbao = cunbao;
                        finalQuery = query;
                        timer.schedule(new /* invalid duplicate definition of identical inner class */, 1200L);
                        break block73;
                    }
                    String openid = (String)decryptMap.get("FromUserName");
                    Tb_user user = new Tb_user();
                    user.setSr_open_id(openid);
                    user.setSw_company_id(XcbConstantValue.companyid);
                    user.setSr_way(this.sr_code);
                    Map<String, Object> rtnMap = this.userService.getUnionId(new Identifier(), user);
                    int cnt = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                    if (cnt > XcbConstantValue.OPERA_INT_ZERO) {
                        String unionid = XcbStringUtils.getObjtoString((Object)rtnMap.get(XcbConstantValue.DATA));
                        user.setSr_unionid(unionid);
                        user.setSr_is_subscribe("Y");
                        Map<String, Object> resMp = this.userService.checkWxUser(new Identifier(), user);
                        cnt = XcbStringUtils.getObjtoint((Object)resMp.get(XcbConstantValue.STATUS));
                        if (cnt > XcbConstantValue.OPERA_INT_ZERO) {
                            boolean isRegister = (Boolean)resMp.get("isRegister");
                            if (isRegister) {
                                user = (Tb_user)resMp.get("user");
                            } else {
                                user.setSr_user_petname("\u5fae\u4fe1\u7528\u6237");
                                user.setSr_is_scan("N");
                                user.setSr_check_appl("N");
                                cnt = this.wechatLogin.createUser(new Identifier(), user);
                            }
                        }
                    }
                    String cunbao = "pages/index/loading?isScan=Y";
                    newsMessage = new NewsMessage();
                    newsMessage.setToUserName(openid);
                    newsMessage.setFromUserName((String)decryptMap.get("ToUserName"));
                    newsMessage.setCreateTime(new Date().getTime());
                    newsMessage.setMsgType("news");
                    Article article1 = new Article();
                    article1.setTitle("\u25ce\u6b22\u8fce\u4f7f\u7528" + info.getSr_name() + "\uff0c\u70b9\u51fb\u5b58\u5305\u5f00\u59cb\u5bc4\u5b58");
                    article1.setDescription(info.getSr_name());
                    article1.setPicUrl(this.bgPath);
                    article1.setUrl(this.mpNews);
                    Article article2 = new Article();
                    article2.setTitle("            \u2b07\ufe0f\u2b07\ufe0f\u2b07\ufe0f \u70b9\u51fb\u4e0b\u65b9\u5b58\u5305 \u2b07\ufe0f\u2b07\ufe0f\u2b07\ufe0f            ");
                    article2.setUrl(this.mpNews);
                    articleList.add(article1);
                    articleList.add(article2);
                    newsMessage.setArticleCount(articleList.size());
                    newsMessage.setArticles(articleList);
                    String respMessage = MessageUtil.newsMessageToXml(newsMessage);
                    String encryptMsg = this.wxBizMsgCrypt.encryptMsg(respMessage, new Date().getTime() + "", this.wxBizMsgCrypt.getRandomStr(), info);
                    PrintWriter out = null;
                    try {
                        out = response.getWriter();
                        out.print(encryptMsg);
                        out.close();
                        out = null;
                    }
                    catch (IOException e) {
                        try {
                            out.close();
                            out = null;
                            e.printStackTrace();
                            out.close();
                            out = null;
                        }
                        catch (Throwable throwable) {
                            out.close();
                            out = null;
                            String access_token = this.wechatLogin.getAccessToken(info);
                            Timer timer = new Timer();
                            timer.schedule(new TimerTask(access_token, decryptMap, info, cunbao){
                                final /* synthetic */ String val$access_token;
                                final /* synthetic */ Map val$decryptMap;
                                final /* synthetic */ Tb_wx_info val$info;
                                final /* synthetic */ String val$cunbao;
                                {
                                    this.val$access_token = string;
                                    this.val$decryptMap = map;
                                    this.val$info = tb_wx_info;
                                    this.val$cunbao = string2;
                                }

                                @Override
                                public void run() {
                                    String url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" + this.val$access_token;
                                    JSONObject object = new JSONObject();
                                    object.put((Object)"touser", this.val$decryptMap.get("FromUserName"));
                                    object.put((Object)"msgtype", (Object)"text");
                                    JSONObject object1 = new JSONObject();
                                    object1.put((Object)"content", (Object)("<a href=\"http://www.qq.com\" data-miniprogram-appid=\"" + this.val$info.getSr_appid() + "\" data-miniprogram-path=\"" + this.val$cunbao + "\">\u261e\u261e\u261e\u70b9\u51fb\u6211\u5b58\u5305\u261c\u261c\u261c</a>"));
                                    object.put((Object)"text", (Object)object1);
                                    String resp = WechatSecurityController_ZC.this.wxzfCommon.sendPost(url, object.toString());
                                }
                            }, 1200L);
                            throw throwable;
                        }
                        String access_token = this.wechatLogin.getAccessToken(info);
                        Timer timer = new Timer();
                        timer.schedule(new /* invalid duplicate definition of identical inner class */, 1200L);
                        break block73;
                    }
                    String access_token = this.wechatLogin.getAccessToken(info);
                    Timer timer = new Timer();
                    timer.schedule(new /* invalid duplicate definition of identical inner class */, 1200L);
                    break block73;
                }
                if ("unsubscribe".equals(event)) {
                    String openid = (String)decryptMap.get("FromUserName");
                    Tb_user user = new Tb_user();
                    user.setSr_open_id(openid);
                    user.setSw_company_id(XcbConstantValue.companyid);
                    user.setSr_way(this.sr_code);
                    Map<String, Object> rtnMap = this.userService.loginWithOpenId(new Identifier(), user);
                    int result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        user = (Tb_user)rtnMap.get(XcbConstantValue.DATA);
                        user.setSr_is_subscribe("N");
                        this.userService.checkWxUser(new Identifier(), user);
                        this.redis.delete(user.getSr_unionid());
                    }
                    break block73;
                }
                if ("SCAN".equals(event)) {
                    String finalQuery;
                    String finalCunbao;
                    Timer timer;
                    String respMessage = "";
                    ArrayList<Article> articleList = new ArrayList<Article>();
                    NewsMessage newsMessage = new NewsMessage();
                    newsMessage.setToUserName((String)decryptMap.get("FromUserName"));
                    newsMessage.setFromUserName((String)decryptMap.get("ToUserName"));
                    newsMessage.setCreateTime(new Date().getTime());
                    newsMessage.setMsgType("news");
                    String cunbao = "pages/my/scan/setting";
                    String qubao = "pages/my/order/pickup";
                    String query = "";
                    String deviceid = (String)decryptMap.get("EventKey");
                    Map<String, Object> rtnMap = this.deviceService.findDeviceByDeviceId((String)decryptMap.get("FromUserName"), deviceid);
                    int result = XcbStringUtils.getObjtoint((Object)rtnMap.get(XcbConstantValue.STATUS));
                    if (result > XcbConstantValue.OPERA_INT_ZERO) {
                        Map dataMap = (Map)rtnMap.get(XcbConstantValue.DATA);
                        HashMap<String, String> pathMap = new HashMap<String, String>();
                        int sr_scan_time = XcbStringUtils.getObjtoint(dataMap.get("sr_scan_time"));
                        String sr_unionid = XcbStringUtils.getObjtoString(dataMap.get("sr_unionid"));
                        Tb_netpoint netpoint = (Tb_netpoint)dataMap.get("netpoint");
                        Tb_device device = (Tb_device)dataMap.get("device");
                        List list = (List)dataMap.get("list");
                        pathMap.put("boxtype", "");
                        if ("Y".equals(device.getSr_cj_function())) {
                            pathMap.put("path", "/setting");
                            cunbao = "pages/my/scan/setting";
                            query = "type=1&mid=" + device.getSi_mainboard_id();
                            pathMap.put("url", "/pages/my/scan/setting?" + query);
                        } else if (list.size() == 1) {
                            pathMap.put("path", "/payinfo");
                            pathMap.put("boxtype", (String)list.get(0));
                            cunbao = "pages/my/scan/payinfo";
                            query = "type=2&mid=" + device.getSi_mainboard_id() + "&boxtype=" + (String)list.get(0);
                            pathMap.put("url", "/pages/my/scan/payinfo?" + query);
                        } else {
                            pathMap.put("path", "/choose");
                            cunbao = "pages/my/scan/choose";
                            query = "type=2&mid=" + device.getSi_mainboard_id();
                            pathMap.put("url", "/pages/my/scan/choose?" + query);
                        }
                        pathMap.put("mid", device.getSi_mainboard_id());
                        pathMap.put("cj", device.getSr_cj_function());
                        Article article1 = new Article();
                        if (!XcbStringUtils.isNullOrBlank((Object)netpoint.getSr_net_name()) && netpoint.getSr_net_name().length() > 12) {
                            StringBuffer sb = new StringBuffer();
                            sb.append(netpoint.getSr_net_name().substring(0, 12)).append("...");
                            netpoint.setSr_net_name(sb.toString());
                        }
                        String title = netpoint.getSr_net_name();
                        String sr_device_name = XcbStringUtils.getObjtoString((Object)device.getSr_device_name());
                        String sr_alias = XcbStringUtils.getObjtoString((Object)device.getSr_alias());
                        if (!XcbStringUtils.isNullOrBlank((Object)sr_alias)) {
                            title = sr_alias.contains("\u67dc") ? title + sr_alias : title + sr_alias + "\u533a";
                        }
                        if (!XcbStringUtils.isNullOrBlank((Object)sr_device_name)) {
                            title = title + "(" + sr_device_name + ")";
                        }
                        article1.setTitle(title);
                        article1.setDescription(info.getSr_name());
                        article1.setPicUrl(this.bgPath);
                        article1.setUrl(this.mpNews);
                        String jsonStr = JSONObject.fromObject(pathMap).toString();
                        if (!XcbStringUtils.isNullOrBlank((Object)sr_unionid)) {
                            this.redis.setForTimeMIN(sr_unionid, jsonStr, sr_scan_time);
                        }
                        Article article2 = new Article();
                        article2.setTitle("            \u2b07\ufe0f\u2b07\ufe0f\u2b07\ufe0f \u70b9\u51fb\u4e0b\u65b9\u5b58\u5305 \u2b07\ufe0f\u2b07\ufe0f\u2b07\ufe0f            ");
                        article2.setUrl(this.mpNews);
                        articleList.add(article1);
                        articleList.add(article2);
                        newsMessage.setArticleCount(articleList.size());
                        newsMessage.setArticles(articleList);
                        respMessage = MessageUtil.newsMessageToXml(newsMessage);
                    } else {
                        HashMap returnMap = new HashMap();
                        returnMap.put("ToUserName", decryptMap.get("FromUserName"));
                        returnMap.put("FromUserName", decryptMap.get("ToUserName"));
                        returnMap.put("CreateTime", new Date().getTime() + "");
                        returnMap.put("MsgType", "text");
                        returnMap.put("Content", "\u672a\u67e5\u5230\u6b64\u4e8c\u7ef4\u7801\u7684\u673a\u67dc\uff0c\u8bf7\u79fb\u6b65\u5176\u4ed6\u673a\u67dc\u626b\u7801\u4f7f\u7528");
                        respMessage = WXPayUtil.mapToXml(returnMap);
                    }
                    String encryptMsg = this.wxBizMsgCrypt.encryptMsg(respMessage, new Date().getTime() + "", this.wxBizMsgCrypt.getRandomStr(), info);
                    PrintWriter out = null;
                    try {
                        out = response.getWriter();
                        out.print(encryptMsg);
                        out.close();
                        out = null;
                    }
                    catch (IOException e) {
                        try {
                            out.close();
                            out = null;
                            e.printStackTrace();
                            out.close();
                            out = null;
                        }
                        catch (Throwable throwable) {
                            out.close();
                            out = null;
                            String access_token = this.wechatLogin.getAccessToken(info);
                            Timer timer3 = new Timer();
                            String finalCunbao3 = cunbao;
                            String finalQuery3 = query;
                            timer3.schedule(new TimerTask(access_token, decryptMap, info, finalCunbao3, finalQuery3){
                                final /* synthetic */ String val$access_token;
                                final /* synthetic */ Map val$decryptMap;
                                final /* synthetic */ Tb_wx_info val$info;
                                final /* synthetic */ String val$finalCunbao;
                                final /* synthetic */ String val$finalQuery;
                                {
                                    this.val$access_token = string;
                                    this.val$decryptMap = map;
                                    this.val$info = tb_wx_info;
                                    this.val$finalCunbao = string2;
                                    this.val$finalQuery = string3;
                                }

                                @Override
                                public void run() {
                                    String url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" + this.val$access_token;
                                    JSONObject object = new JSONObject();
                                    object.put((Object)"touser", this.val$decryptMap.get("FromUserName"));
                                    object.put((Object)"msgtype", (Object)"text");
                                    JSONObject object1 = new JSONObject();
                                    object1.put((Object)"content", (Object)("<a href=\"http://www.qq.com\" data-miniprogram-appid=\"" + this.val$info.getSr_appid() + "\" data-miniprogram-path=\"" + this.val$finalCunbao + "?" + this.val$finalQuery + "\">\u261e\u261e\u261e\u70b9\u51fb\u6211\u5b58\u5305\u261c\u261c\u261c</a>"));
                                    object.put((Object)"text", (Object)object1);
                                    String resp = WechatSecurityController_ZC.this.wxzfCommon.sendPost(url, object.toString());
                                }
                            }, 1200L);
                            throw throwable;
                        }
                        String access_token = this.wechatLogin.getAccessToken(info);
                        timer = new Timer();
                        finalCunbao = cunbao;
                        finalQuery = query;
                        timer.schedule(new /* invalid duplicate definition of identical inner class */, 1200L);
                        break block73;
                    }
                    String access_token = this.wechatLogin.getAccessToken(info);
                    timer = new Timer();
                    finalCunbao = cunbao;
                    finalQuery = query;
                    timer.schedule(new /* invalid duplicate definition of identical inner class */, 1200L);
                    break block73;
                }
                if ("LOCATION".equals(event)) {
                } else if ("CLICK".equals(event)) {
                } else if ("VIEW".equals(event)) {
                    // empty if block
                }
            }
            catch (Exception e) {
                logger.error((Object)"\u5904\u7406\u5fae\u4fe1\u516c\u4f17\u53f7\u8bf7\u6c42\u4fe1\u606f\uff0c\u5931\u8d25", (Throwable)e);
            }
            finally {
                if (null != is) {
                    is.close();
                }
                if (null != isr) {
                    isr.close();
                }
                if (null != br) {
                    br.close();
                }
            }
        }
        return null;
    }

    private String getUrlLink(Tb_company company, String path, String query) throws Exception, IOException {
        JSONObject json;
        String urlLink = "";
        String access_token = this.getAccessToken(company);
        String url = "https://api.weixin.qq.com/wxa/generate_urllink?access_token=" + access_token;
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        dataMap.put("path", path);
        dataMap.put("query", query);
        dataMap.put("is_expire", true);
        dataMap.put("expire_type", 1);
        dataMap.put("expire_interval", 1);
        dataMap.put("env_version", "release");
        String sb = JSONObject.fromObject(dataMap).toString();
        String response = this.wxzfCommon.sendPost(url, sb);
        if (!XcbStringUtils.isNullOrBlank((Object)response) && "0".equals(XcbStringUtils.getObjtoString((Object)(json = JSONObject.fromObject((Object)response)).get("errcode")))) {
            urlLink = XcbStringUtils.getObjtoString((Object)json.get("url_link"));
        }
        return urlLink;
    }

    public String getAccessToken(Tb_company company) throws Exception, IOException {
        String access_token = XcbStringUtils.getObjtoString((Object)this.redis.get("app_access_token"));
        if (XcbStringUtils.isNullOrBlank((Object)access_token)) {
            String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + company.getSr_yh_wx_appid() + "&secret=" + company.getSr_yh_wx_secretkey();
            com.alibaba.fastjson.JSONObject jsonObject = this.wechatLogin.doGetJson(url);
            this.log.info(jsonObject.toJSONString());
            access_token = jsonObject.getString("access_token");
            int expires = jsonObject.getInteger("expires_in");
            this.redis.setForTimeMIN("app_access_token", access_token, 100L);
        }
        return access_token;
    }
}

