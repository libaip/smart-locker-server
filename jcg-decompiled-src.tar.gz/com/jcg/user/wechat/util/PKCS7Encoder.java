/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.user.wechat.util;

import java.nio.charset.Charset;
import java.util.Arrays;

public class PKCS7Encoder {
    static Charset CHARSET = Charset.forName("utf-8");
    static int BLOCK_SIZE = 32;

    static byte[] encode(int count) {
        int amountToPad = BLOCK_SIZE - count % BLOCK_SIZE;
        if (amountToPad == 0) {
            amountToPad = BLOCK_SIZE;
        }
        char padChr = PKCS7Encoder.chr(amountToPad);
        String tmp = new String();
        for (int index = 0; index < amountToPad; ++index) {
            tmp = tmp + padChr;
        }
        return tmp.getBytes(CHARSET);
    }

    static byte[] decode(byte[] decrypted) {
        byte pad = decrypted[decrypted.length - 1];
        if (pad < 1 || pad > 32) {
            pad = 0;
        }
        return Arrays.copyOfRange(decrypted, 0, decrypted.length - pad);
    }

    static char chr(int a) {
        byte target = (byte)(a & 0xFF);
        return (char)target;
    }
}

