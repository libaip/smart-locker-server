/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.user.wechat.util;

import com.jcg.user.wechat.util.AesException;
import com.jcg.user.wechat.util.SHA1;

public class WXPublicUtils {
    public static boolean verifyUrl(String msgSignature, String timeStamp, String nonce, String echostr) throws AesException {
        String TOKEN = "ScAW2oeJKAj2HEvw";
        String signature = SHA1.getSHA1(TOKEN, timeStamp, nonce, echostr);
        if (!signature.equals(msgSignature)) {
            throw new AesException(-40001);
        }
        return true;
    }
}

