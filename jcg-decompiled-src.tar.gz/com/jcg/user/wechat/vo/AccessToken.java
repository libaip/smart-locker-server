/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.user.wechat.vo;

import java.io.Serializable;

public class AccessToken
implements Serializable {
    private String openid;
    private String accessToken;
    private String refreshToken;
    private int expiresin;

    public String getOpenid() {
        return this.openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getAccessToken() {
        return this.accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public int getExpiresin() {
        return this.expiresin;
    }

    public void setExpiresin(int expiresin) {
        this.expiresin = expiresin;
    }

    public String getRefreshToken() {
        return this.refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }
}

