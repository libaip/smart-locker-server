/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.user.zf.sf.util;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class BeanMapUtils {
    public static final Object toBean(Class<?> type, Map<String, ? extends Object> map) throws IntrospectionException, IllegalAccessException, InstantiationException, InvocationTargetException {
        BeanInfo beanInfo = Introspector.getBeanInfo(type);
        Object obj = type.newInstance();
        PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
        for (int i = 0; i < propertyDescriptors.length; ++i) {
            PropertyDescriptor descriptor = propertyDescriptors[i];
            String propertyName = descriptor.getName();
            if (!map.containsKey(propertyName)) continue;
            Object value = map.get(propertyName);
            Object[] args = new Object[]{value};
            descriptor.getWriteMethod().invoke(obj, args);
        }
        return obj;
    }

    public static final Map<String, Object> toMap(Object bean) throws IntrospectionException, IllegalAccessException, InvocationTargetException {
        HashMap<String, Object> returnMap = new HashMap<String, Object>();
        BeanInfo beanInfo = Introspector.getBeanInfo(bean.getClass());
        PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
        for (int i = 0; i < propertyDescriptors.length; ++i) {
            PropertyDescriptor descriptor = propertyDescriptors[i];
            String propertyName = descriptor.getName();
            if (propertyName.equals("class")) continue;
            Method readMethod = descriptor.getReadMethod();
            Object result = readMethod.invoke(bean, new Object[0]);
            if (result != null) {
                returnMap.put(propertyName, result);
                continue;
            }
            returnMap.put(propertyName, "");
        }
        return returnMap;
    }

    public static final TreeMap<String, Object> toTreeMap(Object bean) throws IntrospectionException, IllegalAccessException, InvocationTargetException {
        TreeMap<String, Object> treeMap = new TreeMap<String, Object>();
        BeanInfo beanInfo = Introspector.getBeanInfo(bean.getClass());
        PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
        for (int i = 0; i < propertyDescriptors.length; ++i) {
            PropertyDescriptor descriptor = propertyDescriptors[i];
            String propertyName = descriptor.getName();
            if (propertyName.equals("class")) continue;
            Method readMethod = descriptor.getReadMethod();
            Object result = readMethod.invoke(bean, new Object[0]);
            if (result != null) {
                treeMap.put(propertyName, result);
                continue;
            }
            treeMap.put(propertyName, "");
        }
        return treeMap;
    }

    public static final TreeMap<String, Object> toTreeMapNotNull(Object bean) throws IntrospectionException, IllegalAccessException, InvocationTargetException {
        TreeMap<String, Object> treeMap = new TreeMap<String, Object>();
        BeanInfo beanInfo = Introspector.getBeanInfo(bean.getClass());
        PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
        for (int i = 0; i < propertyDescriptors.length; ++i) {
            Method readMethod;
            Object result;
            PropertyDescriptor descriptor = propertyDescriptors[i];
            String propertyName = descriptor.getName();
            if (propertyName.equals("class") || !BeanMapUtils.notEmpty(result = (readMethod = descriptor.getReadMethod()).invoke(bean, new Object[0]), true)) continue;
            treeMap.put(propertyName, result);
        }
        return treeMap;
    }

    private static boolean notEmpty(Object value, boolean trim) {
        return !BeanMapUtils.isEmpty(value, trim);
    }

    private static boolean isEmpty(Object value, boolean trim) {
        if (value == null) {
            return true;
        }
        String text = value instanceof String ? (String)value : value.toString();
        return (trim ? text.trim() : text).isEmpty();
    }
}

