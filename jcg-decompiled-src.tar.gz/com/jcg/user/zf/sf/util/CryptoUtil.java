/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.codec.binary.Base64
 *  org.apache.commons.lang.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jcg.user.zf.sf.util;

import com.jcg.user.zf.sf.constants.HandlerException;
import com.jcg.user.zf.sf.util.RSAUtil;
import com.jcg.user.zf.sf.util.TransCode;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CryptoUtil {
    protected static final Logger logger = LoggerFactory.getLogger(CryptoUtil.class);

    public static byte[] digitalSign(byte[] plainBytes, PrivateKey privateKey, String signAlgorithm) throws HandlerException {
        try {
            Signature signature = Signature.getInstance(signAlgorithm);
            signature.initSign(privateKey);
            signature.update(plainBytes);
            byte[] signBytes = signature.sign();
            return signBytes;
        }
        catch (Exception e) {
            throw new HandlerException(TransCode.TRANS_100007.getCode(), "\u6570\u636e\u7b7e\u540d\u9519\u8bef");
        }
    }

    public static boolean verifyDigitalSign(byte[] plainBytes, byte[] signBytes, PublicKey publicKey, String signAlgorithm) throws HandlerException {
        boolean isValid = false;
        try {
            Signature signature = Signature.getInstance(signAlgorithm);
            signature.initVerify(publicKey);
            signature.update(plainBytes);
            isValid = signature.verify(signBytes);
            return isValid;
        }
        catch (Exception e) {
            throw new HandlerException(TransCode.TRANS_100005.getCode(), e.getMessage());
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static PublicKey getRSAPublicKeyByFileSuffix(String filePath, String fileSuffix, String keyAlgorithm) throws HandlerException {
        FileInputStream in = null;
        try {
            in = new FileInputStream(filePath);
            PublicKey pubKey = null;
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            StringBuilder sb = new StringBuilder();
            String readLine = null;
            while ((readLine = br.readLine()) != null) {
                if (readLine.charAt(0) == '-') continue;
                sb.append(readLine);
                sb.append('\r');
            }
            X509EncodedKeySpec pubX509 = new X509EncodedKeySpec(Base64.decodeBase64((byte[])sb.toString().getBytes()));
            KeyFactory keyFactory = KeyFactory.getInstance(keyAlgorithm);
            PublicKey publicKey = pubKey = keyFactory.generatePublic(pubX509);
            return publicKey;
        }
        catch (Exception e) {
            e.printStackTrace();
            PublicKey publicKey = null;
            return publicKey;
        }
        finally {
            try {
                if (in != null) {
                    ((InputStream)in).close();
                }
            }
            catch (IOException iOException) {}
        }
    }

    public static PrivateKey getRSAPrivateKeyByFileSuffix(String filePath, String fileSuffix, String password, String keyAlgorithm) throws HandlerException {
        FileInputStream in = null;
        try {
            in = new FileInputStream(filePath);
            PrivateKey priKey = null;
            String serailNumber = null;
            serailNumber = RSAUtil.getPFXPrivateSerialNumber(filePath, password);
            logger.info("\u7b7e\u540d\u8bc1\u4e66\uff1a" + filePath + " CertId=" + serailNumber);
            PrivateKey privateKey = priKey = RSAUtil.getPFXPrivateKey((String)filePath, (String)password).privateKey;
            return privateKey;
        }
        catch (Exception e) {
            logger.error(e.getMessage(), (Throwable)e);
            throw new HandlerException(TransCode.TRANS_100007.getCode(), e.getMessage());
        }
        finally {
            try {
                if (in != null) {
                    ((InputStream)in).close();
                }
            }
            catch (IOException iOException) {}
        }
    }

    public static byte[] RSAEncrypt(byte[] plainBytes, PublicKey publicKey, int keyLength, int reserveSize, String cipherAlgorithm) throws Exception {
        int keyByteSize = keyLength / 8;
        int encryptBlockSize = keyByteSize - reserveSize;
        int nBlock = plainBytes.length / encryptBlockSize;
        if (plainBytes.length % encryptBlockSize != 0) {
            ++nBlock;
        }
        try {
            Cipher cipher = Cipher.getInstance(cipherAlgorithm);
            cipher.init(1, publicKey);
            ByteArrayOutputStream outbuf = new ByteArrayOutputStream(nBlock * keyByteSize);
            for (int offset = 0; offset < plainBytes.length; offset += encryptBlockSize) {
                int inputLen = plainBytes.length - offset;
                if (inputLen > encryptBlockSize) {
                    inputLen = encryptBlockSize;
                }
                byte[] encryptedBlock = cipher.doFinal(plainBytes, offset, inputLen);
                outbuf.write(encryptedBlock);
            }
            outbuf.flush();
            outbuf.close();
            return outbuf.toByteArray();
        }
        catch (NoSuchAlgorithmException e) {
            throw new Exception(e);
        }
        catch (NoSuchPaddingException e) {
            throw new Exception(e);
        }
        catch (InvalidKeyException e) {
            throw new Exception(e);
        }
        catch (IllegalBlockSizeException e) {
            throw new Exception(e);
        }
        catch (BadPaddingException e) {
            throw new Exception(e);
        }
        catch (IOException e) {
            throw new Exception(e);
        }
    }

    public static byte[] RSADecrypt(byte[] encryptedBytes, PrivateKey privateKey, int keyLength, int reserveSize, String cipherAlgorithm) throws HandlerException {
        int keyByteSize = keyLength / 8;
        int decryptBlockSize = keyByteSize - reserveSize;
        int nBlock = encryptedBytes.length / keyByteSize;
        try {
            Cipher cipher = Cipher.getInstance(cipherAlgorithm);
            cipher.init(2, privateKey);
            ByteArrayOutputStream outbuf = new ByteArrayOutputStream(nBlock * decryptBlockSize);
            for (int offset = 0; offset < encryptedBytes.length; offset += keyByteSize) {
                int inputLen = encryptedBytes.length - offset;
                if (inputLen > keyByteSize) {
                    inputLen = keyByteSize;
                }
                byte[] decryptedBlock = cipher.doFinal(encryptedBytes, offset, inputLen);
                outbuf.write(decryptedBlock);
            }
            outbuf.flush();
            outbuf.close();
            return outbuf.toByteArray();
        }
        catch (Exception e) {
            throw new HandlerException(TransCode.TRANS_100006.getCode(), e.getMessage());
        }
    }

    public static byte[] AESEncrypt(byte[] plainBytes, byte[] keyBytes, String keyAlgorithm, String cipherAlgorithm, String IV) throws HandlerException {
        try {
            if (keyBytes.length % 8 != 0 || keyBytes.length < 16 || keyBytes.length > 32) {
                throw new Exception("AES\u5bc6\u94a5\u957f\u5ea6\u4e0d\u5408\u6cd5");
            }
            Cipher cipher = Cipher.getInstance(cipherAlgorithm);
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, keyAlgorithm);
            if (StringUtils.trimToNull((String)IV) != null) {
                IvParameterSpec ivspec = new IvParameterSpec(IV.getBytes());
                cipher.init(1, (Key)secretKey, ivspec);
            } else {
                cipher.init(1, secretKey);
            }
            byte[] encryptedBytes = cipher.doFinal(plainBytes);
            return encryptedBytes;
        }
        catch (Exception e) {
            throw new HandlerException(TransCode.TRANS_100007.getCode(), e.getMessage());
        }
    }

    public static byte[] AESDecrypt(byte[] encryptedBytes, byte[] keyBytes, String keyAlgorithm, String cipherAlgorithm, String IV) throws HandlerException {
        try {
            if (keyBytes.length % 8 != 0 || keyBytes.length < 16 || keyBytes.length > 32) {
                throw new Exception("AES\u5bc6\u94a5\u957f\u5ea6\u4e0d\u5408\u6cd5");
            }
            Cipher cipher = Cipher.getInstance(cipherAlgorithm);
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, keyAlgorithm);
            if (IV != null && StringUtils.trimToNull((String)IV) != null) {
                IvParameterSpec ivspec = new IvParameterSpec(IV.getBytes());
                cipher.init(2, (Key)secretKey, ivspec);
            } else {
                cipher.init(2, secretKey);
            }
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            return decryptedBytes;
        }
        catch (Exception e) {
            throw new HandlerException(TransCode.TRANS_100006.getCode(), e.getMessage());
        }
    }
}

