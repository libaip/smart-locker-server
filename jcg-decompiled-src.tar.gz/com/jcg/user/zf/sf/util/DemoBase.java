/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.user.zf.sf.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class DemoBase {
    public static String getCurrentTime() {
        return new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
    }

    public static String getOrderId() {
        return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
    }

    public static String genHtmlResult(Map<String, String> data) {
        TreeMap<String, String> tree = new TreeMap<String, String>();
        for (Map.Entry<String, String> en : data.entrySet()) {
            tree.put(en.getKey(), en.getValue());
        }
        Iterator<Map.Entry<String, String>> it = tree.entrySet().iterator();
        StringBuffer sf = new StringBuffer();
        while (it.hasNext()) {
            Map.Entry<String, String> en = it.next();
            String key = en.getKey();
            String value = en.getValue();
            if ("respCode".equals(key)) {
                sf.append("<b>" + key + "=" + value + "</br></b>");
                continue;
            }
            sf.append(key + "=" + value + "</br>");
        }
        return sf.toString();
    }

    public static List<Map> parseZMFile(String filePath) {
        int[] lengthArray = new int[]{3, 11, 11, 6, 10, 19, 12, 4, 2, 21, 2, 32, 2, 6, 10, 13, 13, 4, 15, 2, 2, 6, 2, 4, 32, 1, 21, 15, 1, 15, 32, 13, 13, 8, 32, 13, 13, 12, 2, 1, 32, 98};
        return DemoBase.parseFile(filePath, lengthArray);
    }

    public static List<Map> parseZMEFile(String filePath) {
        int[] lengthArray = new int[]{3, 11, 11, 6, 10, 19, 12, 4, 2, 2, 6, 10, 4, 12, 13, 13, 15, 15, 1, 12, 2, 135};
        return DemoBase.parseFile(filePath, lengthArray);
    }

    private static List<Map> parseFile(String filePath, int[] lengthArray) {
        ArrayList<Map> ZmDataList = new ArrayList<Map>();
        try {
            String encoding = "gbk";
            File file = new File(filePath);
            if (file.isFile() && file.exists()) {
                InputStreamReader read = new InputStreamReader((InputStream)new FileInputStream(file), "iso-8859-1");
                BufferedReader bufferedReader = new BufferedReader(read);
                String lineTxt = null;
                while ((lineTxt = bufferedReader.readLine()) != null) {
                    byte[] bs = lineTxt.getBytes("iso-8859-1");
                    LinkedHashMap<Integer, String> ZmDataMap = new LinkedHashMap<Integer, String>();
                    int leftIndex = 0;
                    int rightIndex = 0;
                    for (int i = 0; i < lengthArray.length; ++i) {
                        rightIndex = leftIndex + lengthArray[i];
                        String filed = new String(Arrays.copyOfRange(bs, leftIndex, rightIndex), encoding);
                        leftIndex = rightIndex + 1;
                        ZmDataMap.put(i, filed);
                    }
                    ZmDataList.add(ZmDataMap);
                }
                read.close();
            } else {
                System.out.println("\u627e\u4e0d\u5230\u6307\u5b9a\u7684\u6587\u4ef6");
            }
        }
        catch (Exception e) {
            System.out.println("\u8bfb\u53d6\u6587\u4ef6\u5185\u5bb9\u51fa\u9519");
            e.printStackTrace();
        }
        return ZmDataList;
    }

    public static String getFileContentTable(List<Map> dataList, String file) {
        StringBuffer tableSb = new StringBuffer("\u5bf9\u8d26\u6587\u4ef6\u7684\u89c4\u8303\u53c2\u8003 https://open.unionpay.com/ajweb/help/file/ \u4ea7\u54c1\u63a5\u53e3\u89c4\u8303->\u5e73\u53f0\u63a5\u53e3\u89c4\u8303:\u6587\u4ef6\u63a5\u53e3</br> \u6587\u4ef6\u3010" + file + "\u3011\u89e3\u6790\u540e\u5185\u5bb9\u5982\u4e0b\uff1a");
        tableSb.append("<table border=\"1\">");
        if (dataList.size() > 0) {
            Map dataMapTmp = dataList.get(0);
            tableSb.append("<tr>");
            for (Integer key : dataMapTmp.keySet()) {
                String value = (String)dataMapTmp.get(key);
                System.out.println("\u5e8f\u53f7\uff1a" + (key + 1) + " \u503c: '" + value + "'");
                tableSb.append("<td>\u5e8f\u53f7" + (key + 1) + "</td>");
            }
            tableSb.append("</tr>");
        }
        for (int i = 0; i < dataList.size(); ++i) {
            System.out.println("\u884c\u6570: " + (i + 1));
            Map dataMapTmp = dataList.get(i);
            tableSb.append("<tr>");
            for (Integer key : dataMapTmp.keySet()) {
                String value = (String)dataMapTmp.get(key);
                System.out.println("\u5e8f\u53f7\uff1a" + (key + 1) + " \u503c: '" + value + "'");
                tableSb.append("<td>" + value + "</td>");
            }
            tableSb.append("</tr>");
        }
        tableSb.append("</table>");
        return tableSb.toString();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static List<String> unzip(String zipFilePath, String outPutDirectory) {
        ArrayList<String> fileList = new ArrayList<String>();
        try {
            ZipInputStream zin = new ZipInputStream(new FileInputStream(zipFilePath));
            BufferedInputStream bin = new BufferedInputStream(zin);
            FilterOutputStream bout = null;
            File file = null;
            try {
                ZipEntry entry;
                while ((entry = zin.getNextEntry()) != null && !entry.isDirectory()) {
                    int b;
                    file = new File(outPutDirectory, entry.getName());
                    if (!file.exists()) {
                        new File(file.getParent()).mkdirs();
                    }
                    bout = new BufferedOutputStream(new FileOutputStream(file));
                    while ((b = bin.read()) != -1) {
                        ((BufferedOutputStream)bout).write(b);
                    }
                    ((BufferedOutputStream)bout).flush();
                    fileList.add(file.getAbsolutePath());
                    System.out.println(file + "\u89e3\u538b\u6210\u529f");
                }
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            finally {
                try {
                    bin.close();
                    zin.close();
                    if (bout != null) {
                        bout.close();
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return fileList;
    }
}

