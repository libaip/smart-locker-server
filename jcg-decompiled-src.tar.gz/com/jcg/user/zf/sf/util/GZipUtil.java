/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jcg.user.zf.sf.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.Key;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GZipUtil {
    private static final Logger logger = LoggerFactory.getLogger(GZipUtil.class);
    private static final String KEY_ALGORITHM = "AES";
    private static final String DEFAULT_CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";

    public static byte[] encrypt(byte[] byteContent, String password) {
        if (byteContent == null) {
            return null;
        }
        try {
            Key key = GZipUtil.toKey(password);
            Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
            cipher.init(1, key);
            byte[] result = cipher.doFinal(byteContent);
            return result;
        }
        catch (Exception e) {
            logger.error("AES\u52a0\u5bc6\u5f02\u5e38", (Throwable)e);
            return null;
        }
    }

    public static byte[] decrypt(byte[] byteContent, String password) {
        if (byteContent == null) {
            return null;
        }
        try {
            Key key = GZipUtil.toKey(password);
            Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
            cipher.init(2, key);
            byte[] result = cipher.doFinal(byteContent);
            return result;
        }
        catch (Exception e) {
            logger.error("AES\u89e3\u5bc6\u5f02\u5e38", (Throwable)e);
            return null;
        }
    }

    private static Key toKey(String password) throws UnsupportedEncodingException {
        return new SecretKeySpec(password.getBytes("UTF-8"), KEY_ALGORITHM);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static byte[] gzipString(String primStr) {
        if (primStr == null || primStr.length() == 0) {
            return null;
        }
        ByteArrayOutputStream out = null;
        DeflaterOutputStream gout = null;
        try {
            out = new ByteArrayOutputStream();
            gout = new GZIPOutputStream(out);
            gout.write(primStr.getBytes(Charset.forName("Utf-8")));
            gout.flush();
        }
        catch (IOException e) {
            logger.error("\u5bf9\u5b57\u7b26\u4e32\u8fdb\u884c\u52a0\u538b\u52a0\u5bc6\u64cd\u4f5c\u5931\u8d25\uff1a" + e.fillInStackTrace());
            byte[] byArray = null;
            return byArray;
        }
        finally {
            if (gout != null) {
                try {
                    gout.close();
                }
                catch (IOException e) {
                    logger.info("\u5bf9\u5b57\u7b26\u4e32\u8fdb\u884c\u52a0\u538b\u52a0\u5bc6\u64cd\u4f5c\uff0c\u5173\u95edgzip\u64cd\u4f5c\u6d41\u5931\u8d25\uff1a" + e.fillInStackTrace());
                }
            }
        }
        return out.toByteArray();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static final String ungzipString(byte[] compressed) {
        if (compressed == null) {
            return null;
        }
        ByteArrayOutputStream out = null;
        ByteArrayInputStream in = null;
        GZIPInputStream gin = null;
        String decompressed = null;
        try {
            out = new ByteArrayOutputStream();
            in = new ByteArrayInputStream(compressed);
            gin = new GZIPInputStream(in);
            byte[] buffer = new byte[1024];
            int offset = -1;
            while ((offset = gin.read(buffer)) != -1) {
                out.write(buffer, 0, offset);
            }
            decompressed = out.toString("Utf-8");
        }
        catch (IOException e) {
            logger.error("\u5bf9\u5b57\u7b26\u4e32\u8fdb\u884c\u89e3\u5bc6\u89e3\u538b\u64cd\u4f5c\u5931\u8d25\uff1a" + e.fillInStackTrace());
            decompressed = null;
        }
        finally {
            if (gin != null) {
                try {
                    gin.close();
                }
                catch (IOException e) {
                    logger.info("\u5bf9\u5b57\u7b26\u4e32\u8fdb\u884c\u89e3\u5bc6\u89e3\u538b\u64cd\u4f5c\uff0c\u5173\u95ed\u538b\u7f29\u6d41\u5931\u8d25\uff1a" + e.fillInStackTrace());
                }
            }
            if (in != null) {
                try {
                    in.close();
                }
                catch (IOException e) {
                    logger.info("\u5bf9\u5b57\u7b26\u4e32\u8fdb\u884c\u89e3\u5bc6\u89e3\u538b\u64cd\u4f5c\uff0c\u5173\u95ed\u8f93\u5165\u6d41\u5931\u8d25\uff1a" + e.fillInStackTrace());
                }
            }
            if (out != null) {
                try {
                    out.close();
                }
                catch (IOException e) {
                    logger.info("\u5bf9\u5b57\u7b26\u4e32\u8fdb\u884c\u89e3\u5bc6\u89e3\u538b\u64cd\u4f5c\uff0c\u5173\u95ed\u8f93\u51fa\u6d41\u5931\u8d25\uff1a" + e.fillInStackTrace());
                }
            }
        }
        return decompressed;
    }
}

