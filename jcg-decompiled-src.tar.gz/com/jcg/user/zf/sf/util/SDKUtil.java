/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_wx_pay_info
 *  net.sf.json.JSONObject
 *  org.apache.commons.codec.binary.Base64
 *  org.apache.commons.lang.StringUtils
 *  org.apache.commons.logging.Log
 *  org.apache.commons.logging.LogFactory
 */
package com.jcg.user.zf.sf.util;

import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.zf.sf.constants.HandlerException;
import com.jcg.user.zf.sf.util.BeanMapUtils;
import com.jcg.user.zf.sf.util.CryptoUtil;
import com.jcg.user.zf.sf.util.PfxCerUtil;
import com.jcg.user.zf.sf.util.UtilProperties;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SDKUtil {
    private static Log logger = LogFactory.getLog(SDKUtil.class);

    public static String getSign(Object requestDto) throws Exception {
        StringBuffer signData = new StringBuffer();
        String partnerKey = "";
        TreeMap<String, Object> map = BeanMapUtils.toTreeMapNotNull(requestDto);
        for (String in : map.keySet()) {
            if ("signature".equals(in)) continue;
            String str = (String)map.get(in);
            signData.append(in + "=" + str + "&");
            if (!in.equals("pnrNo")) continue;
            partnerKey = UtilProperties.getPropertiesValue("app.properties", "partnerKey");
        }
        signData.append("key=" + partnerKey);
        logger.info((Object)("\u7b7e\u540d\u5b57\u4e32\uff1a" + signData.toString()));
        return signData.toString();
    }

    public static String getSign(Object requestDto, boolean isLog) throws Exception {
        StringBuffer signData = new StringBuffer();
        String partnerKey = "";
        TreeMap<String, Object> map = BeanMapUtils.toTreeMapNotNull(requestDto);
        for (String in : map.keySet()) {
            if ("signature".equals(in)) continue;
            String str = (String)map.get(in);
            signData.append(in + "=" + str + "&");
            if (!in.equals("pnrNo")) continue;
            partnerKey = UtilProperties.getPropertiesValue("app.properties", "partnerKey");
        }
        signData.append("key=" + partnerKey);
        if (isLog) {
            logger.info((Object)("\u7b7e\u540d\u5b57\u4e32\uff1a" + signData.toString()));
        }
        return signData.toString();
    }

    public static String getMerSign(Object requestDto, Tb_wx_pay_info info) throws Exception {
        StringBuffer signData = new StringBuffer();
        String merchantKey = "";
        TreeMap<String, Object> map = BeanMapUtils.toTreeMapNotNull(requestDto);
        for (String in : map.keySet()) {
            if ("signature".equals(in)) continue;
            String str = (String)map.get(in);
            signData.append(in + "=" + str + "&");
            merchantKey = info.getSub_merkey_v3();
        }
        signData.append("key=" + merchantKey);
        logger.info((Object)("\u7b7e\u540d\u5b57\u4e32\uff1a" + signData.toString()));
        return signData.toString();
    }

    public static String getJsonObject(Object requestDto) throws Exception {
        JSONObject jsonObject = new JSONObject();
        TreeMap<String, Object> map = BeanMapUtils.toTreeMap(requestDto);
        for (String in : map.keySet()) {
            jsonObject.accumulate(in, (Object)((String)map.get(in)));
        }
        logger.info((Object)("\u8bf7\u6c42\u6570\u636e\uff1a" + jsonObject.toString()));
        return jsonObject.toString();
    }

    public static String getJsonObject(Object requestDto, boolean isLog) throws Exception {
        JSONObject jsonObject = new JSONObject();
        TreeMap<String, Object> map = BeanMapUtils.toTreeMap(requestDto);
        for (String in : map.keySet()) {
            jsonObject.accumulate(in, (Object)((String)map.get(in)));
        }
        if (isLog) {
            logger.info((Object)("\u8bf7\u6c42\u6570\u636e\uff1a" + jsonObject.toString()));
        }
        return jsonObject.toString();
    }

    public static Map<String, String> filterBlank(Map<String, String> contentData) {
        logger.info((Object)"\u6253\u5370\u8bf7\u6c42\u62a5\u6587\u57df :");
        HashMap<String, String> submitFromData = new HashMap<String, String>();
        Set<String> keyset = contentData.keySet();
        for (String key : keyset) {
            String value = contentData.get(key);
            if (!StringUtils.isNotBlank((String)value)) continue;
            submitFromData.put(key, value.trim());
            logger.info((Object)(key + "-->" + String.valueOf(value)));
        }
        return submitFromData;
    }

    public static String sign(String srcData, String rasPriPath, Tb_wx_pay_info info) throws HandlerException {
        String certPassword = info.getSub_merkey_v2();
        PrivateKey hzfPriKey = CryptoUtil.getRSAPrivateKeyByFileSuffix(rasPriPath, "pem", certPassword, "RSA");
        byte[] digitalSign = CryptoUtil.digitalSign(srcData.getBytes(), hzfPriKey, "SHA256withRSA");
        byte[] base64SingDataBytes = Base64.encodeBase64((byte[])digitalSign);
        String signData = new String(base64SingDataBytes);
        return signData;
    }

    public static String getSignData(Object result, String partnerKey) {
        StringBuffer signData = new StringBuffer();
        try {
            TreeMap<String, Object> map = BeanMapUtils.toTreeMapNotNull(result);
            for (String in : map.keySet()) {
                if ("signature".equals(in)) continue;
                String str = (String)map.get(in);
                signData.append(in + "=" + str + "&");
            }
            signData.append("key=" + partnerKey);
        }
        catch (Exception e) {
            e.getMessage();
        }
        return signData.toString();
    }

    public static boolean isRSAVerifySucc(String signString, String Signature2, String pub) {
        try {
            if (null == pub || "".equals(pub)) {
                logger.info((Object)"\u5408\u4f5c\u65b9\u516c\u94a5\u4e0d\u5b58\u5728");
                return false;
            }
            PublicKey yhPubKey = CryptoUtil.getRSAPublicKeyByFileSuffix(pub, "RSApublickey", "RSA");
            byte[] decodeBase64YhSignBytes = Base64.decodeBase64((byte[])Signature2.getBytes("UTF-8"));
            boolean verifySign = CryptoUtil.verifyDigitalSign(signString.getBytes("UTF-8"), decodeBase64YhSignBytes, yhPubKey, "SHA1WithRSA");
            if (!verifySign) {
                logger.info((Object)"\u62a5\u6587\u9a8c\u7b7e\u5931\u8d25");
                return false;
            }
            return true;
        }
        catch (Exception e) {
            logger.info((Object)"\u62a5\u6587\u9a8c\u7b7e\u5f02\u5e38!");
            e.printStackTrace();
            return false;
        }
    }

    public static boolean verifySign(String content, String sign) throws Exception {
        PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(UtilProperties.getPropertiesValue("app.properties", "sdjCer").trim());
        return PfxCerUtil.verify256(content, sign, publicKey);
    }
}

