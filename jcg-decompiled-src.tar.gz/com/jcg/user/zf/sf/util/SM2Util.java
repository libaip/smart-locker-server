/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_wx_pay_info
 *  org.bouncycastle.jcajce.spec.SM2ParameterSpec
 *  org.bouncycastle.jce.provider.BouncyCastleProvider
 *  org.bouncycastle.util.encoders.Hex
 */
package com.jcg.user.zf.sf.util;

import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.zf.sf.util.Base64;
import com.jcg.user.zf.sf.util.PfxCerUtil;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import org.bouncycastle.jcajce.spec.SM2ParameterSpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;

public class SM2Util {
    public static byte[] signSm3WithSm2(byte[] msg, byte[] userId, PrivateKey privateKey) {
        return SM2Util.signSm3WithSm2Asn1Rs(msg, userId, privateKey);
    }

    public static byte[] signSm3WithSm2Asn1Rs(byte[] msg, byte[] userId, PrivateKey privateKey) {
        try {
            SM2ParameterSpec parameterSpec = new SM2ParameterSpec(userId);
            Signature signer = Signature.getInstance("SM3withSM2", "BC");
            signer.setParameter((AlgorithmParameterSpec)parameterSpec);
            signer.initSign(privateKey, new SecureRandom());
            signer.update(msg, 0, msg.length);
            byte[] sig = signer.sign();
            return sig;
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean verifySm3WithSm2(byte[] msg, byte[] userId, byte[] rs, PublicKey publicKey) {
        return SM2Util.verifySm3WithSm2Asn1Rs(msg, userId, rs, publicKey);
    }

    public static boolean verifySm3WithSm2Asn1Rs(byte[] msg, byte[] userId, byte[] rs, PublicKey publicKey) {
        try {
            SM2ParameterSpec parameterSpec = new SM2ParameterSpec(userId);
            Signature verifier = Signature.getInstance("SM3withSM2", "BC");
            verifier.setParameter((AlgorithmParameterSpec)parameterSpec);
            verifier.initVerify(publicKey);
            verifier.update(msg, 0, msg.length);
            return verifier.verify(rs);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static Map<String, Object> getKey(String cerUrl, Tb_wx_pay_info info) {
        String cerPassword = info.getSub_merkey_v2();
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            Security.addProvider((Provider)new BouncyCastleProvider());
            KeyStore ks = KeyStore.getInstance("PKCS12", "BC");
            FileInputStream fis = new FileInputStream(cerUrl);
            char[] nPassword = null;
            nPassword = cerPassword == null || cerPassword.trim().equals("") ? null : cerPassword.toCharArray();
            ks.load(fis, nPassword);
            fis.close();
            Enumeration<String> enumas = ks.aliases();
            String keyAlias = null;
            if (enumas.hasMoreElements()) {
                keyAlias = enumas.nextElement();
            }
            PrivateKey prikey = (PrivateKey)ks.getKey(keyAlias, nPassword);
            Certificate cert = ks.getCertificate(keyAlias);
            PublicKey pubkey = cert.getPublicKey();
            map.put("publicKey", pubkey);
            map.put("privateKey", prikey);
            map.put("certificate", cert);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    public static Map<String, Object> getKey(String cerUrl) {
        String cerPassword = "123456";
        HashMap<String, Object> map = new HashMap<String, Object>();
        try {
            Security.addProvider((Provider)new BouncyCastleProvider());
            KeyStore ks = KeyStore.getInstance("PKCS12", "BC");
            FileInputStream fis = new FileInputStream(cerUrl);
            char[] nPassword = null;
            nPassword = cerPassword == null || cerPassword.trim().equals("") ? null : cerPassword.toCharArray();
            ks.load(fis, nPassword);
            fis.close();
            Enumeration<String> enumas = ks.aliases();
            String keyAlias = null;
            if (enumas.hasMoreElements()) {
                keyAlias = enumas.nextElement();
            }
            PrivateKey prikey = (PrivateKey)ks.getKey(keyAlias, nPassword);
            Certificate cert = ks.getCertificate(keyAlias);
            PublicKey pubkey = cert.getPublicKey();
            map.put("publicKey", pubkey);
            map.put("privateKey", prikey);
            map.put("certificate", cert);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    public static String getCertId(X509Certificate x509) throws Exception {
        String certId = x509.getSerialNumber().toString(16);
        return certId;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("--------------------");
        Map<String, Object> map = SM2Util.getKey("/Users/tim/Desktop/workspace/certificate/wx_cert/8610297105/payer99_sm2.pfx");
        PublicKey publicKey = (PublicKey)map.get("publicKey");
        PrivateKey privateKey = (PrivateKey)map.get("privateKey");
        System.out.println("public key = " + publicKey);
        System.out.println("private key = " + privateKey);
        byte[] msg = "message digest".getBytes();
        byte[] userId = "userId".getBytes();
        byte[] sig = SM2Util.signSm3WithSm2(msg, userId, privateKey);
        String sign = Hex.toHexString((byte[])sig);
        byte[] sig1 = Hex.decode((String)sign);
        System.out.println("sign:" + Hex.toHexString((byte[])sig));
        System.out.println("verify:" + SM2Util.verifySm3WithSm2(msg, userId, sig1, publicKey));
        String pubKey = "A0IABBtVrjlwZgZbedWWRF2+5wr2lFhWUzdjLb1l9IjArdj3ZBjP3XFD9A/oOvfzz7pcka23F6dexN2iDgqftMEy/rQ=";
        PublicKey publicKey1 = PfxCerUtil.getPublicKey(pubKey);
        System.out.println(publicKey1);
    }

    public static PublicKey getPublicKey(String certificate) {
        X509Certificate certificate2 = (X509Certificate)SM2Util.getCertificate(Base64.decode(certificate));
        PublicKey publicKey = certificate2.getPublicKey();
        return publicKey;
    }

    public static Certificate getCertificate(byte[] certByte) {
        try {
            Security.addProvider((Provider)new BouncyCastleProvider());
            CertificateFactory cf = CertificateFactory.getInstance("X.509", "BC");
            Certificate cert = cf.generateCertificate(new ByteArrayInputStream(certByte));
            return cert;
        }
        catch (NoSuchProviderException | CertificateException e) {
            e.printStackTrace();
            return null;
        }
    }

    static {
        if (Security.getProvider("BC") == null) {
            Security.addProvider((Provider)new BouncyCastleProvider());
        }
    }
}

