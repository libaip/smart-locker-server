/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.user.zf.sf.util;

public enum TransCode {
    TRANS_000000("000000", "\u6210\u529f"),
    TRANS_000001("000001", "\u6e20\u9053\u5546\u6237\u91cd\u5165\u9a7b\u5e76\u6210\u529f"),
    TRANS_000002("000002", "\u8865\u5355\u6210\u529f"),
    TRANS_000100("000100", "\u63d0\u4ea4\u6210\u529f"),
    TRANS_000200("000200", "\u65e0\u9700\u8d26\u52a1\u8c03\u6574"),
    TRANS_999999("999999", "\u5904\u7406\u5931\u8d25"),
    TRANS_100001("100001", "\u62a5\u6587\u9519\u8bef"),
    TRANS_100002("100002", "\u62a5\u6587\u683c\u5f0f\u9519\u8bef"),
    TRANS_100003("100003", "\u62a5\u6587\u7248\u672c\u53f7\u9519\u8bef"),
    TRANS_100004("100004", "\u62a5\u6587\u5fc5\u586b\u9879\u9519\u8bef"),
    TRANS_100005("100005", "\u62a5\u6587\u9a8c\u7b7e\u9519\u8bef"),
    TRANS_100006("100006", "\u62a5\u6587\u89e3\u5bc6\u9519\u8bef"),
    TRANS_100007("100007", "\u62a5\u6587\u52a0\u5bc6\u9519\u8bef"),
    TRANS_102001("102001", "\u5408\u4f5c\u65b9\u7f16\u7801\u4e0d\u5b58\u5728"),
    TRANS_102002("102002", "\u5546\u6237\u65b9\u7f16\u7801\u4e0d\u5b58\u5728"),
    TRANS_102003("102003", "\u5408\u4f5c\u65b9\u7f16\u7801\u72b6\u6001\u4e0d\u53ef\u7528"),
    TRANS_102004("102004", "\u5546\u6237\u65b9\u7f16\u7801\u72b6\u6001\u4e0d\u53ef\u7528"),
    TRANS_200001("200001", "\u901a\u7528\u672a\u77e5\u9519\u8bef"),
    TRANS_200002("200002", "\u901a\u7528\u72b6\u6001\u9519\u8bef"),
    TRANS_200003("200003", "\u901a\u7528\u8bb0\u5f55\u4e0d\u5b58\u5728"),
    TRANS_200004("200004", "\u901a\u7528\u53c2\u6570\u65e0\u6548"),
    TRANS_200005("200005", "\u901a\u7528\u6388\u6743\u4e0d\u53ef\u7528"),
    TRANS_202001("202001", "\u8ba2\u5355\u65e0\u6548"),
    TRANS_202002("202002", "\u8ba2\u5355\u91cd\u590d"),
    TRANS_202003("202003", "\u8ba2\u5355\u5df2\u8fc7\u671f"),
    TRANS_202004("202004", "\u64a4\u9500\u8ba2\u5355\u5df2\u8fc7\u671f"),
    TRANS_202005("202005", "\u62a5\u6587\u9519\u8bef"),
    TRANS_202006("202006", "\u67e5\u8be2\u8ba2\u5355\u5df2\u8fc7\u671f"),
    TRANS_202007("202007", "\u8ba2\u5355\u91d1\u989d\u8d85\u51fa\u8303\u56f4"),
    TRANS_202008("202008", "\u6d41\u6c34\u53f7\u751f\u6210\u7cfb\u7edf\u63a7\u5236\u4f4d\u4e0d\u5408\u6cd5"),
    TRANS_202009("202009", "\u8ba2\u5355\u53f7\u4e0d\u5339\u914d\u9519\u8bef"),
    TRANS_202010("202010", "\u8ba2\u5355\u91d1\u989d\u4e0d\u5339\u914d\u9519\u8bef"),
    TRANS_204001("204001", "\u5546\u6237\u65e0\u6548"),
    TRANS_204002("204002", "\u5546\u6237\u72b6\u6001\u4e0d\u53ef\u7528"),
    TRANS_206001("206001", "\u6e20\u9053\u5546\u6237\u65e0\u6548"),
    TRANS_206002("206002", "\u6e20\u9053\u72b6\u6001\u4e0d\u53ef\u7528"),
    TRANS_206003("206003", "\u6e20\u9053\u5546\u6237\u72b6\u6001\u4e0d\u53ef\u7528"),
    TRANS_208001("208001", "\u8d26\u6237\u4f59\u989d\u4e0d\u8db3"),
    TRANS_208002("208002", "\u8d26\u6237\u72b6\u6001\u4e0d\u53ef\u7528"),
    TRANS_210001("210001", "\u7528\u6237\u65e0\u6548"),
    TRANS_210002("210002", "\u7528\u6237\u72b6\u6001\u4e0d\u53ef\u7528"),
    TRANS_210003("210003", "\u7528\u6237\u6388\u6743\u4e0d\u53ef\u7528"),
    TRANS_212001("212001", "\u8def\u7531\u4e0d\u5b58\u5728"),
    TRANS_214001("214001", "\u94f6\u884c\u5361\u4ea7\u54c1\u4e0d\u652f\u6301"),
    TRANS_214002("214002", "\u94f6\u884c\u5361\u501f\u8d37\u7c7b\u578b\u4e0d\u652f\u6301"),
    TRANS_214003("214003", "\u94f6\u884c\u5361\u4f59\u989d\u4e0d\u8db3"),
    TRANS_214004("214004", "\u94f6\u884c\u5361\u72b6\u6001\u4e0d\u53ef\u7528"),
    TRANS_214005("214005", "\u94f6\u884c\u5361\u65e0\u6548"),
    TRANS_214006("214006", "\u94f6\u884c\u5361\u5df2\u89e3\u7ed1"),
    TRANS_216001("216001", "\u4e8c\u7ef4\u7801\u4e0d\u5b58\u5728"),
    TRANS_216002("216002", "\u4e8c\u7ef4\u7801\u5df2\u5931\u6548"),
    TRANS_216003("216003", "\u4e8c\u7ef4\u7801\u72b6\u6001\u9519\u8bef"),
    TRANS_216004("216004", "\u4e8c\u7ef4\u7801\u652f\u4ed8\u6b21\u6570\u8d85\u9650"),
    TRANS_300001("300001", "\u5546\u6237\u5f53\u65e5\u7d2f\u8ba1\u4ea4\u6613\u91d1\u989d\u9650\u5236"),
    TRANS_300002("300002", "\u5546\u6237\u7d2f\u8ba1\u4ea4\u6613\u91d1\u989d\u9650\u5236"),
    TRANS_300003("300003", "\u5546\u6237\u540c\u4e00\u7528\u6237\u5f53\u65e5\u7d2f\u8ba1\u4ea4\u6613\u91d1\u989d\u53d7\u9650"),
    TRANS_300004("300004", "\u5546\u6237\u540c\u4e00\u7528\u6237\u5f53\u65e5\u4ea4\u6613\u6b21\u6570\u53d7\u9650"),
    TRANS_300005("300005", "\u5546\u6237\u540c\u4e00\u7528\u6237\u591a\u65e5\u7d2f\u8ba1\u4ea4\u6613\u91d1\u989d\u53d7\u9650"),
    TRANS_300006("300006", "\u5546\u6237\u540c\u4e00\u7528\u6237\u591a\u65e5\u4ea4\u6613\u6b21\u6570\u53d7\u9650"),
    TRANS_302001("302001", "\u7528\u6237\u5f53\u65e5\u7d2f\u8ba1\u4ea4\u6613\u91d1\u989d\u53d7\u9650"),
    TRANS_302002("302002", "\u7528\u6237\u5f53\u65e5\u7d2f\u8ba1\u4ea4\u6613\u91d1\u989d\u53d7\u9650"),
    TRANS_302003("302003", "\u7528\u6237\u591a\u65e5\u7d2f\u8ba1\u4ea4\u6613\u91d1\u989d\u53d7\u9650"),
    TRANS_302004("302004", "\u7528\u6237\u591a\u65e5\u7d2f\u8ba1\u4ea4\u6613\u91d1\u989d\u53d7\u9650"),
    TRANS_900001("900001", "\u7cfb\u7edf\u7ef4\u62a4\u4e2d"),
    TRANS_900002("900002", "\u5176\u4ed6\u9519\u8bef"),
    TRANS_900003("900003", "\u8bf7\u6c42\u62d2\u7edd"),
    TRANS_900004("900004", "\u8bf7\u6c42\u8d85\u65f6"),
    TRANS_900005("900005", "\u8bf7\u6c42\u4e0d\u5b58\u5728"),
    TRANS_900006("900006", "\u8bf7\u6c42\u94f6\u884c\u5f02\u5e38"),
    TRANS_900007("900007", "\u521b\u5efa\u8bf7\u6c42\u8fde\u63a5\u5bf9\u8c61\u5931\u8d25\u5f02\u5e38");

    private String code;
    private String desc;

    private TransCode(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return this.desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}

