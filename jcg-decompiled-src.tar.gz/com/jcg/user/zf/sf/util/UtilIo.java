/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.user.zf.sf.util;

import java.nio.charset.Charset;

public class UtilIo {
    public static final Charset utf8 = Charset.forName("UTF-8");
    public static final Charset iso8859_1 = Charset.forName("ISO8859-1");
    public static final Charset gbk = Charset.forName("GBK");

    public static void close(AutoCloseable ... closeables) {
        for (AutoCloseable closeable : closeables) {
            if (closeable == null) continue;
            try {
                closeable.close();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

