/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.servlet.http.HttpServletRequest
 */
package com.jcg.user.zf.sf.util;

import com.jcg.user.zf.sf.util.UtilIo;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;

public class UtilString {
    public static final int md5Len = UtilString.md5("empty").length();
    public static final int uuidLen = UtilString.uuid().length();
    private static final Random random = new Random();
    private static final Set<String> chinaPhones = new HashSet<String>();
    public static final String[] removePrint = new String[]{"settleCardPic", "pic_01", "pic_02", "pic_03", "settleCardPic", "pic_04", "pic_05", "pic_06", "cardNo", "password", "passWord", "payPassword", "oldPayPassword", "bankAccountNo", "phoneNo", "username", "identityNo", "creditCardPic", "creditCardArmPic", "creditCard", "certId", "cvn2", "phone"};
    private static final Character[] randomChars;
    private static final Character[] randomNumbers;

    private static String fetchDigit(String text, int start) {
        if (text == null) {
            return "";
        }
        StringBuilder buf = new StringBuilder();
        boolean begin = false;
        int len = text.length();
        while (start < len) {
            char ch = text.charAt(start);
            if (ch >= '0' && ch <= '9') {
                begin = true;
                buf.append(ch);
            } else if (begin) break;
            ++start;
        }
        return buf.toString();
    }

    public static Integer fetchInt(String text, int start) {
        String value = UtilString.fetchDigit(text, start);
        return value.length() > 0 ? Integer.valueOf(value.toString()) : null;
    }

    public static Long fetchLong(String text, int start) {
        String value = UtilString.fetchDigit(text, start);
        return value.length() > 0 ? Long.valueOf(value.toString()) : null;
    }

    private static String digits(long val, int digits) {
        long hi = 1L << digits * 4;
        return Long.toHexString(hi | val & hi - 1L).substring(1);
    }

    public static String uuid() {
        UUID uuid = UUID.randomUUID();
        long mostSigBits = uuid.getMostSignificantBits();
        long leastSigBits = uuid.getLeastSignificantBits();
        return UtilString.digits(mostSigBits >> 32, 8) + UtilString.digits(mostSigBits >> 16, 4) + UtilString.digits(mostSigBits, 4) + UtilString.digits(leastSigBits >> 48, 4) + UtilString.digits(leastSigBits, 12);
    }

    public static String toHexString(byte[] bytes) {
        StringBuilder buf = new StringBuilder(bytes.length * 2);
        int len = bytes.length;
        for (int i = 0; i < len; ++i) {
            int value = bytes[i] & 0xFF;
            if (value < 16) {
                buf.append('0');
            }
            buf.append(Integer.toHexString(value));
        }
        return buf.toString();
    }

    public static String md5(String ... values) {
        return UtilString.md5(Arrays.asList(values));
    }

    public static String md5(Collection<String> values) {
        MessageDigest descDigest = UtilString.getMessageDigest("MD5");
        for (String value : values) {
            if (value == null) continue;
            descDigest.update(value.getBytes(UtilIo.utf8));
        }
        return UtilString.toHexString(descDigest.digest());
    }

    public static MessageDigest getMessageDigest(String algorithm) {
        try {
            return MessageDigest.getInstance(algorithm.toUpperCase());
        }
        catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("MD5 provider not exist!");
        }
    }

    public static boolean isChinaPhone(String phone) {
        return phone != null && phone.length() == 11 && phone.charAt(0) == '1' && chinaPhones.contains(phone.substring(0, 3));
    }

    public static boolean isEmail(String email) {
        String str = "^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
        Pattern p = Pattern.compile(str);
        Matcher m = p.matcher(email);
        return m.matches();
    }

    public static boolean isEmpty(Object value, boolean trim) {
        if (value == null) {
            return true;
        }
        String text = value instanceof String ? (String)value : value.toString();
        return (trim ? text.trim() : text).isEmpty();
    }

    public static boolean notEmpty(Object value, boolean trim) {
        return !UtilString.isEmpty(value, trim);
    }

    public static boolean isEmpty(Object value) {
        return value == null || (value instanceof String ? (String)value : value.toString()).isEmpty();
    }

    public static boolean notEmpty(Object value) {
        return !UtilString.isEmpty(value);
    }

    public static String trim(String value) {
        return value == null ? null : value.trim();
    }

    public static String toString(Object value) {
        return value == null ? null : value.toString();
    }

    public static String toString(Object value, Object defaultValue) {
        return value == null ? UtilString.toString(defaultValue) : value.toString();
    }

    public static String toString(Collection<?> collection, int maxLen) {
        if (collection == null) {
            return null;
        }
        StringBuilder buf = new StringBuilder(12 * maxLen);
        buf.append("[");
        Iterator<?> iterator = collection.iterator();
        for (int i = 0; iterator.hasNext() && i < maxLen; ++i) {
            buf.append(iterator.next()).append(", ");
        }
        if (buf.length() > 1) {
            buf.deleteCharAt(buf.length() - 1);
        }
        buf.append("]");
        return buf.toString();
    }

    public static String substring(String text, int beginIndex, int endIndex) {
        if (text == null) {
            return null;
        }
        if (beginIndex < 0) {
            beginIndex = 0;
        }
        if (beginIndex > text.length() - 1) {
            return "";
        }
        if (endIndex > text.length()) {
            endIndex = text.length();
        }
        return text.substring(beginIndex, endIndex);
    }

    public static String encodeURL(Object value) {
        if (value == null) {
            return "";
        }
        try {
            return URLEncoder.encode(value.toString(), "UTF-8");
        }
        catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
    }

    public static String decodeURL(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return URLDecoder.decode(value.toString(), "UTF-8");
        }
        catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
    }

    private static void addChars(List<Character> list, int start, int end) {
        for (int i = start; i <= end; ++i) {
            list.add(Character.valueOf((char)i));
        }
    }

    private static String randChars(Character[] chars, int len) {
        StringBuilder buf = new StringBuilder(len);
        for (int i = 0; i < len; ++i) {
            buf.append(chars[random.nextInt(chars.length)]);
        }
        return buf.toString();
    }

    public static String randCode(int len) {
        return UtilString.randChars(randomChars, len);
    }

    public static String randNumCode(int len) {
        return UtilString.randChars(randomNumbers, len);
    }

    public static String concat(Collection<?> collection, String split) {
        return UtilString.concat(collection, split, false);
    }

    public static String concat(Collection<?> collection, String split, boolean ignoreNullEl) {
        if (collection == null || collection.isEmpty()) {
            return "";
        }
        if (split == null) {
            split = "";
        }
        StringBuilder buf = new StringBuilder(collection.size() * (10 + split.length()));
        for (Object el : collection) {
            if (ignoreNullEl && el == null) continue;
            buf.append(el).append(split);
        }
        if (buf.length() > 0) {
            buf.setLength(buf.length() - split.length());
        }
        return buf.toString();
    }

    public static <T> String concat(T[] array, String split) {
        return UtilString.concat(array, split, false);
    }

    public static <T> String concat(T[] array, String split, boolean ignoreNullEl) {
        if (array == null || array.length == 0) {
            return "";
        }
        if (split == null) {
            split = "";
        }
        StringBuilder buf = new StringBuilder(array.length * (10 + split.length()));
        for (T el : array) {
            if (ignoreNullEl && el == null) continue;
            buf.append(el).append(split);
        }
        if (buf.length() > 0) {
            buf.setLength(buf.length() - split.length());
        }
        return buf.toString();
    }

    public static List<String> split(String text, char splitChar) {
        return UtilString.split(text, splitChar, true, text.length() / 16);
    }

    public static List<String> split(String text, char splitChar, boolean trim, Integer initialCapacity) {
        ArrayList<String> result = initialCapacity == null || initialCapacity < 10 ? new ArrayList<String>() : new ArrayList<String>(initialCapacity);
        int start = 0;
        int len = text.length();
        for (int i = 0; i < len; ++i) {
            if (splitChar != text.charAt(i)) continue;
            String tmp = start == i ? "" : text.substring(start, i);
            result.add(trim ? tmp.trim() : tmp);
            start = i + 1;
        }
        if (start <= len) {
            String tmp = text.substring(start);
            result.add(trim ? tmp.trim() : tmp);
        }
        return result;
    }

    public static boolean isNumber(String text) {
        if (text == null) {
            return false;
        }
        int len = text.length();
        for (int i = 0; i < len; ++i) {
            char ch = text.charAt(i);
            if (ch <= '9' && ch >= '0') continue;
            return false;
        }
        return true;
    }

    public static String format(int value, int len) {
        return UtilString.fillZero(Integer.toString(value), len);
    }

    public static String fillZero(String str, int maxLen) {
        if (str == null) {
            str = "";
        }
        if (str.length() >= maxLen) {
            return str;
        }
        StringBuilder buf = new StringBuilder();
        for (int i = str.length(); i < maxLen; ++i) {
            buf.append('0');
        }
        buf.append(str);
        return buf.toString();
    }

    public static String[] tokenizeToStringArray(String str, String delimiters, boolean trimTokens, boolean ignoreEmptyTokens) {
        if (str == null) {
            return null;
        }
        StringTokenizer st = new StringTokenizer(str, delimiters);
        ArrayList<String> tokens = new ArrayList<String>();
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            if (trimTokens) {
                token = token.trim();
            }
            if (ignoreEmptyTokens && token.length() <= 0) continue;
            tokens.add(token);
        }
        return tokens.toArray(new String[tokens.size()]);
    }

    public static String returnMsgStr(String code, String msg) {
        return "{\"code\":\"" + code + "\",\"msg\":\"" + msg + "\"}";
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String validate(Map<String, String> paras, HttpServletRequest request) {
        if (null == paras) return "{\"02\":\"\u65e0\u8bf7\u6c42\u53c2\u6570\"}";
        if (paras.size() <= 0) return "{\"02\":\"\u65e0\u8bf7\u6c42\u53c2\u6570\"}";
        String validate = String.valueOf(paras.get("validate"));
        if (!validate.equals("null") && !validate.equals("") && (validate.equals("false") || validate.equals("true"))) {
            if (!validate.equals("false")) return null;
            String encryptKey = request.getParameter("encryptData");
            if (null == encryptKey) return null;
            if (!"".equals(encryptKey)) return null;
            return null;
        }
        System.out.println("{\"02\":\"\u4e22\u5931validate\u53c2\u6570\u6216\u8005validate\u4e0d\u4e3atrue\u6216false\"}");
        return "{\"02\":\"\u4e22\u5931validate\u53c2\u6570\u6216\u8005validate\u4e0d\u4e3atrue\u6216false\"}";
    }

    public static String replaceBlank(String str) {
        String dest = "";
        if (str != null) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(str);
            dest = m.replaceAll("");
        }
        return dest;
    }

    static {
        chinaPhones.addAll(Arrays.asList("134,135,136,137,138,139,150,151,152,157,158,159,147,182,183,184,187,188,178".split(",")));
        chinaPhones.addAll(Arrays.asList("130,131,132,155,156,185,186,176,199,166,198".split(",")));
        chinaPhones.addAll(Arrays.asList("133,153,180,181,189,177,170,171,172,173,174,175,179".split(",")));
        ArrayList<Character> chars = new ArrayList<Character>();
        UtilString.addChars(chars, 97, 122);
        UtilString.addChars(chars, 65, 90);
        UtilString.addChars(chars, 48, 57);
        Collections.shuffle(chars, random);
        randomChars = chars.toArray(new Character[0]);
        chars = new ArrayList();
        UtilString.addChars(chars, 48, 57);
        Collections.shuffle(chars, random);
        randomNumbers = chars.toArray(new Character[0]);
    }
}

