/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.XcbConstantValue
 */
package com.jcg.user.zf.wx;

import com.jcg.common.model.XcbConstantValue;
import com.jcg.user.zf.wx.Base64Util;
import com.jcg.user.zf.wx.MD5Util;
import java.security.AlgorithmParameters;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AESUtil {
    private static final String ALGORITHM = "AES";
    private static final String ALGORITHM_MODE_PADDING = "AES/ECB/PKCS5Padding";
    private static final String ALGORITHM_MODE_WXPHONE = "AES/CBC/PKCS5Padding";

    public static String encryptData(String data, String meryKey) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM_MODE_PADDING);
        SecretKeySpec key = new SecretKeySpec(MD5Util.MD5Encode(meryKey, XcbConstantValue.ENCODING_UTF8).toLowerCase().getBytes(), ALGORITHM);
        cipher.init(1, key);
        return Base64Util.encode(cipher.doFinal(data.getBytes()));
    }

    public static String decryptData(String base64Data, String meryKey) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM_MODE_PADDING);
        SecretKeySpec key = new SecretKeySpec(MD5Util.MD5Encode(meryKey, XcbConstantValue.ENCODING_UTF8).toLowerCase().getBytes(), ALGORITHM);
        cipher.init(2, key);
        return new String(cipher.doFinal(Base64Util.decode(base64Data)));
    }

    public static byte[] decrypt(byte[] content, byte[] keyByte, byte[] ivByte) throws Exception {
        try {
            Cipher cipher = Cipher.getInstance(ALGORITHM_MODE_WXPHONE);
            SecretKeySpec sKeySpec = new SecretKeySpec(keyByte, ALGORITHM);
            cipher.init(2, (Key)sKeySpec, AESUtil.generateIV(ivByte));
            byte[] result = cipher.doFinal(content);
            return result;
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static AlgorithmParameters generateIV(byte[] iv) throws Exception {
        AlgorithmParameters params = AlgorithmParameters.getInstance(ALGORITHM);
        params.init(new IvParameterSpec(iv));
        return params;
    }
}

