/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  sun.misc.BASE64Decoder
 */
package com.jcg.user.zf.wx;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.Map;
import sun.misc.BASE64Decoder;

public class RSAUtil {
    private static String buildMessage(Map<String, String> map) {
        String appid = map.get("appId");
        String timeStamp = map.get("timeStamp");
        String nonceStr = map.get("nonceStr");
        String packageStr = map.get("package");
        return appid + "\n" + timeStamp + "\n" + nonceStr + "\n" + packageStr + "\n";
    }

    public static String getPaySign(Map<String, String> map, String sr_key) throws Exception {
        String message = RSAUtil.buildMessage(map);
        PrivateKey privateKey = RSAUtil.getPrivateKey(sr_key);
        String signature = RSAUtil.sign(message.getBytes("utf-8"), privateKey);
        return signature;
    }

    private static String sign(byte[] message, PrivateKey privateKey) throws Exception {
        Signature sign = Signature.getInstance("SHA256withRSA");
        sign.initSign(privateKey);
        sign.update(message);
        return Base64.getEncoder().encodeToString(sign.sign());
    }

    public static PrivateKey getPrivateKey(String key) throws Exception {
        byte[] keyBytes = new BASE64Decoder().decodeBuffer(key);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
        return privateKey;
    }
}

