/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.user.zf.wx;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class SerializationUtils {
    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static byte[] serialize(Object object) {
        byte[] bytes;
        block6: {
            if (object == null) {
                return null;
            }
            ObjectOutputStream oos = null;
            ByteArrayOutputStream baos = null;
            bytes = null;
            try {
                baos = new ByteArrayOutputStream();
                oos = new ObjectOutputStream(baos);
                oos.writeObject(object);
                bytes = baos.toByteArray();
                SerializationUtils.close(oos);
            }
            catch (Exception e) {
                e.printStackTrace();
                break block6;
            }
            finally {
                SerializationUtils.close(oos);
                SerializationUtils.close(baos);
            }
            SerializationUtils.close(baos);
        }
        return bytes;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object unserialize(byte[] bytes) {
        Object object;
        if (bytes == null) {
            return null;
        }
        ByteArrayInputStream bais = null;
        ObjectInputStream ois = null;
        try {
            bais = new ByteArrayInputStream(bytes);
            ois = new ObjectInputStream(bais);
            object = ois.readObject();
        }
        catch (Exception e) {
            try {
                e.printStackTrace();
            }
            catch (Throwable throwable) {
                SerializationUtils.close(bais);
                SerializationUtils.close(ois);
                throw throwable;
            }
            SerializationUtils.close(bais);
            SerializationUtils.close(ois);
            return null;
        }
        SerializationUtils.close(bais);
        SerializationUtils.close(ois);
        return object;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static byte[] serializeList(List<?> list) {
        byte[] bytes;
        block7: {
            if (list == null || list.size() == 0) {
                return null;
            }
            ObjectOutputStream oos = null;
            ByteArrayOutputStream baos = null;
            bytes = null;
            try {
                baos = new ByteArrayOutputStream();
                oos = new ObjectOutputStream(baos);
                for (Object obj : list) {
                    oos.writeObject(obj);
                }
                bytes = baos.toByteArray();
                SerializationUtils.close(oos);
            }
            catch (Exception e) {
                e.printStackTrace();
                break block7;
            }
            finally {
                SerializationUtils.close(oos);
                SerializationUtils.close(baos);
            }
            SerializationUtils.close(baos);
        }
        return bytes;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static List<?> unserializeList(byte[] bytes) {
        if (bytes == null) {
            return null;
        }
        ArrayList<Object> list = new ArrayList<Object>();
        ByteArrayInputStream bais = null;
        ObjectInputStream ois = null;
        try {
            Object obj;
            bais = new ByteArrayInputStream(bytes);
            ois = new ObjectInputStream(bais);
            while (bais.available() > 0 && (obj = ois.readObject()) != null) {
                list.add(obj);
            }
        }
        catch (Exception e) {
            try {
                e.printStackTrace();
            }
            catch (Throwable throwable) {
                SerializationUtils.close(bais);
                SerializationUtils.close(ois);
                throw throwable;
            }
            SerializationUtils.close(bais);
            SerializationUtils.close(ois);
        }
        SerializationUtils.close(bais);
        SerializationUtils.close(ois);
        return list;
    }

    public static void close(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

