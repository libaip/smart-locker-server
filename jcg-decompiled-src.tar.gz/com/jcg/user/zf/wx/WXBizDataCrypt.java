/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.sf.json.JSONObject
 *  org.apache.commons.codec.binary.Base64
 */
package com.jcg.user.zf.wx;

import com.jcg.user.zf.wx.AESUtil;
import java.util.HashMap;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Base64;

public class WXBizDataCrypt {
    private static WXBizDataCrypt instance = null;

    private WXBizDataCrypt() {
    }

    public static WXBizDataCrypt getInstance() {
        if (instance == null) {
            instance = new WXBizDataCrypt();
        }
        return instance;
    }

    public String decryptData(String encryptedData, String sessionKey, String iv, String encode) {
        byte[] aesKey = Base64.decodeBase64((String)sessionKey);
        byte[] aesIV = Base64.decodeBase64((String)iv);
        byte[] aesCipher = Base64.decodeBase64((String)encryptedData);
        HashMap<String, String> map = new HashMap<String, String>();
        try {
            byte[] resultByte = AESUtil.decrypt(aesCipher, aesKey, aesIV);
            if (null != resultByte && resultByte.length > 0) {
                String userInfo = new String(resultByte, encode);
                map.put("code", "0000");
                map.put("msg", "succeed");
                map.put("userInfo", userInfo);
            } else {
                map.put("status", "1000");
                map.put("msg", "false");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return JSONObject.fromObject(map).toString();
    }
}

