/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.wxpay.sdk.WXPayConstants$SignType
 *  com.github.wxpay.sdk.WXPayUtil
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_wx_info
 *  javax.servlet.http.HttpServletRequest
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.zf.wx;

import com.github.wxpay.sdk.WXPayConstants;
import com.github.wxpay.sdk.WXPayUtil;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.user.common.BaseService;
import com.jcg.user.common.PromptProperties;
import com.jcg.user.service.CompanyServiceImpl;
import com.jcg.user.service.SysParamServiceImpl;
import com.jcg.user.vo.LoginUser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WXzfCommon
extends BaseService {
    protected static Logger log = LoggerFactory.getLogger(WXzfCommon.class);
    @Autowired
    private CompanyServiceImpl companyService;
    @Autowired
    private SysParamServiceImpl sysParamService;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String sendGet(String url) {
        String result = "";
        BufferedReader in = null;
        try {
            String line;
            String urlNameString = url;
            URL realUrl = new URL(urlNameString);
            URLConnection connection = realUrl.openConnection();
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.connect();
            Map<String, List<String>> map = connection.getHeaderFields();
            for (String string : map.keySet()) {
            }
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
            while ((line = in.readLine()) != null) {
                result = result + line;
            }
        }
        catch (Exception e) {
            System.out.println("\u53d1\u9001GET\u8bf7\u6c42\u51fa\u73b0\u5f02\u5e38\uff01" + e);
            e.printStackTrace();
        }
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            }
            catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return result;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public String sendPost(String url, String param) {
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            String line;
            URL realUrl = new URL(url);
            URLConnection conn = realUrl.openConnection();
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            out = new PrintWriter(new OutputStreamWriter(conn.getOutputStream(), "utf-8"));
            out.print(param);
            out.flush();
            in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            while ((line = in.readLine()) != null) {
                result = result + line;
            }
        }
        catch (Exception e) {
            System.out.println("\u53d1\u9001 POST \u8bf7\u6c42\u51fa\u73b0\u5f02\u5e38\uff01" + e);
            e.printStackTrace();
        }
        finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    public static String getIpAdrress(HttpServletRequest request) {
        String Xip = request.getHeader("X-Real-IP");
        String XFor = request.getHeader("X-Forwarded-For");
        if (!XcbStringUtils.isNullOrBlank((Object)XFor) && !"unKnown".equalsIgnoreCase(XFor)) {
            int index = XFor.indexOf(",");
            if (index != -1) {
                return XFor.substring(0, index);
            }
            return XFor;
        }
        XFor = Xip;
        if (!XcbStringUtils.isNullOrBlank((Object)XFor) && !"unKnown".equalsIgnoreCase(XFor)) {
            return XFor;
        }
        if (XcbStringUtils.isNullOrBlank((Object)XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("Proxy-Client-IP");
        }
        if (XcbStringUtils.isNullOrBlank((Object)XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("WL-Proxy-Client-IP");
        }
        if (XcbStringUtils.isNullOrBlank((Object)XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("HTTP_CLIENT_IP");
        }
        if (XcbStringUtils.isNullOrBlank((Object)XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (XcbStringUtils.isNullOrBlank((Object)XFor) || "unknown".equalsIgnoreCase(XFor)) {
            XFor = request.getRemoteAddr();
        }
        return XFor;
    }

    public String getOpenId(Identifier identifier, LoginUser loginUser) throws Exception {
        String openId_str = "";
        try {
            StringBuffer sb = new StringBuffer();
            Tb_wx_info info = this.sysParamService.findWxInfoByCode(identifier, loginUser.getSr_way());
            String wx_appid = info.getSr_appid();
            String wx_secretKey = info.getSr_appsecret();
            sb.append(XcbConstantValue.wx_openId_url);
            sb.append(wx_appid).append("&secret=").append(wx_secretKey);
            sb.append("&js_code=").append(loginUser.getCode());
            sb.append("&grant_type=authorization_code");
            log.info("apiUrl:" + sb.toString());
            openId_str = WXzfCommon.sendGet(sb.toString());
        }
        catch (Exception e) {
            log.error(PromptProperties.getProperty("company.find.error", loginUser.getSw_company_id()));
            throw new Exception(e);
        }
        return openId_str;
    }

    public String getOpenid(String code, Tb_company company) throws Exception {
        String openId_str = "";
        try {
            StringBuffer sb = new StringBuffer();
            String wx_appid = company.getSr_wx_gzh_appid();
            String wx_secretKey = company.getSr_wx_gzh_appsecret();
            sb.append(XcbConstantValue.wx_gzh_openId_url);
            sb.append(wx_appid).append("&secret=").append(wx_secretKey);
            sb.append("&code=").append(code);
            sb.append("&grant_type=authorization_code");
            log.info("apiUrl:" + sb.toString());
            openId_str = WXzfCommon.sendGet(sb.toString());
        }
        catch (Exception e) {
            throw new Exception(e);
        }
        return openId_str;
    }

    public Tb_company getCompany(Identifier identifier, String sw_company_id, String sr_wx_mer_id) throws Exception {
        Tb_company company = new Tb_company();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)sr_wx_mer_id)) {
                Map<String, Object> dataMap = this.companyService.findCompanyByMerId(identifier, sr_wx_mer_id);
                company = (Tb_company)dataMap.get(XcbConstantValue.DATA);
            } else {
                Map<String, Object> dataMap = this.companyService.findCompanyPayIn(identifier, sw_company_id);
                company = (Tb_company)dataMap.get(XcbConstantValue.DATA);
            }
        }
        catch (Exception e) {
            log.error(PromptProperties.getProperty("company.find.error", sw_company_id));
            throw new Exception(e);
        }
        return company;
    }

    public String getReqStr(Identifier identifier, String sw_company_id, String openid, String cus_ip, String total_fee, String out_trade_no, String attach, String notify_url) throws Exception {
        HashMap<String, String> data = new HashMap<String, String>();
        Tb_company company = this.getCompany(identifier, sw_company_id, null);
        String nonce_str = WXPayUtil.generateNonceStr();
        String reqBody = null;
        data.put("appid", company.getSr_yh_wx_appid());
        data.put("mch_id", company.getSub_mchid());
        data.put("nonce_str", nonce_str);
        data.put("sign_type", XcbConstantValue.sign_type);
        data.put("body", company.getSr_body_name());
        data.put("out_trade_no", out_trade_no);
        data.put("fee_type", XcbConstantValue.fee_type);
        data.put("total_fee", String.valueOf(total_fee));
        data.put("spbill_create_ip", cus_ip);
        data.put("notify_url", notify_url);
        data.put("trade_type", XcbConstantValue.trade_type);
        data.put("openid", openid);
        data.put("attach", attach);
        try {
            String sign = WXPayUtil.generateSignature(data, (String)company.getSub_merkey_v3(), (WXPayConstants.SignType)WXPayConstants.SignType.MD5);
            data.put("sign", sign);
        }
        catch (Exception e) {
            log.error("sign error :" + XcbStringUtils.exceptionToString((Exception)e));
        }
        try {
            reqBody = WXPayUtil.mapToXml(data);
        }
        catch (Exception e) {
            log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return reqBody;
    }

    public Map<String, String> conPayParam(String prepayid, Identifier identifier, String sw_company_id) throws Exception {
        Tb_company company = this.getCompany(identifier, sw_company_id, null);
        log.info("\u6839\u636e\u5f53\u524d\u7684prepayid\u6784\u9020\u8fd4\u56de\u53c2\u6570= " + prepayid);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("appId", company.getSr_yh_wx_appid());
        map.put("timeStamp", XcbDateUtil.getCurrentTimestamp() + "");
        map.put("nonceStr", WXPayUtil.generateNonceStr());
        map.put("package", "prepay_id=" + prepayid);
        map.put("signType", "MD5");
        try {
            String sign = WXPayUtil.generateSignature(map, (String)company.getSub_merkey_v3(), (WXPayConstants.SignType)WXPayConstants.SignType.MD5);
            map.put("sign", sign);
        }
        catch (Exception e) {
            log.error(e.getMessage());
        }
        return map;
    }
}

