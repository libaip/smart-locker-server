/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.XcbStringUtils
 *  net.sf.json.JSONObject
 *  org.bouncycastle.jce.provider.BouncyCastleProvider
 *  org.bouncycastle.util.Arrays
 *  org.bouncycastle.util.encoders.Base64
 */
package com.jcg.user.zf.wx;

import com.jcg.common.model.XcbStringUtils;
import java.security.Key;
import java.security.Provider;
import java.security.Security;
import java.util.HashMap;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import net.sf.json.JSONObject;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.Arrays;
import org.bouncycastle.util.encoders.Base64;

public class WechatDecryptDataUtil {
    private static final String KEY_ALGORITHM = "AES";
    private static final String ALGORITHM_STR = "AES/CBC/PKCS7Padding";
    private static Key key;
    private static Cipher cipher;

    public static String decryptData(String encryptDataB64, String sessionKeyB64, String ivB64) {
        HashMap<String, String> map = new HashMap<String, String>();
        String result = new String(WechatDecryptDataUtil.decryptOfDiyIV(Base64.decode((String)encryptDataB64), Base64.decode((String)sessionKeyB64), Base64.decode((String)ivB64)));
        System.out.println("\u89e3\u5bc6\u7ed3\u679c:" + result);
        if (!XcbStringUtils.isNullOrBlank((Object)result)) {
            map.put("code", "0000");
            map.put("msg", "succeed");
            map.put("userInfo", result);
        } else {
            map.put("status", "1000");
            map.put("msg", "\u83b7\u53d6\u624b\u673a\u53f7\u7801\u5931\u8d25");
        }
        return JSONObject.fromObject(map).toString();
    }

    private static void init(byte[] keyBytes) {
        int base = 16;
        if (keyBytes.length % base != 0) {
            int groups = keyBytes.length / base + (keyBytes.length % base != 0 ? 1 : 0);
            byte[] temp = new byte[groups * base];
            Arrays.fill((byte[])temp, (byte)0);
            System.arraycopy(keyBytes, 0, temp, 0, keyBytes.length);
            keyBytes = temp;
        }
        Security.addProvider((Provider)new BouncyCastleProvider());
        key = new SecretKeySpec(keyBytes, KEY_ALGORITHM);
        try {
            cipher = Cipher.getInstance(ALGORITHM_STR, "BC");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static byte[] decryptOfDiyIV(byte[] encryptedData, byte[] keyBytes, byte[] ivs) {
        byte[] encryptedText = null;
        WechatDecryptDataUtil.init(keyBytes);
        try {
            cipher.init(2, key, new IvParameterSpec(ivs));
            encryptedText = cipher.doFinal(encryptedData);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return encryptedText;
    }
}

