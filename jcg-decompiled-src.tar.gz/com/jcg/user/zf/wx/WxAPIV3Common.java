/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.wxpay.sdk.WXPayUtil
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_operation_logs
 *  com.jcg.company.model.Tb_order_goods
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.wechat.pay.contrib.apache.httpclient.Credentials
 *  com.wechat.pay.contrib.apache.httpclient.Validator
 *  com.wechat.pay.contrib.apache.httpclient.WechatPayHttpClientBuilder
 *  com.wechat.pay.contrib.apache.httpclient.auth.AutoUpdateCertificatesVerifier
 *  com.wechat.pay.contrib.apache.httpclient.auth.PrivateKeySigner
 *  com.wechat.pay.contrib.apache.httpclient.auth.Signer
 *  com.wechat.pay.contrib.apache.httpclient.auth.Verifier
 *  com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Credentials
 *  com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Validator
 *  com.wechat.pay.contrib.apache.httpclient.util.PemUtil
 *  net.sf.json.JSONObject
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.client.utils.URIBuilder
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.util.EntityUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.zf.wx;

import com.github.wxpay.sdk.WXPayUtil;
import com.jcg.agent.model.Tb_device_package;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_operation_logs;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.common.BaseService;
import com.jcg.user.service.OperationLogServiceImpl;
import com.jcg.user.service.OrderServiceImpl;
import com.jcg.user.zf.wx.RSAUtil;
import com.wechat.pay.contrib.apache.httpclient.Credentials;
import com.wechat.pay.contrib.apache.httpclient.Validator;
import com.wechat.pay.contrib.apache.httpclient.WechatPayHttpClientBuilder;
import com.wechat.pay.contrib.apache.httpclient.auth.AutoUpdateCertificatesVerifier;
import com.wechat.pay.contrib.apache.httpclient.auth.PrivateKeySigner;
import com.wechat.pay.contrib.apache.httpclient.auth.Signer;
import com.wechat.pay.contrib.apache.httpclient.auth.Verifier;
import com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Credentials;
import com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Validator;
import com.wechat.pay.contrib.apache.httpclient.util.PemUtil;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.PrivateKey;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WxAPIV3Common
extends BaseService {
    private static CloseableHttpClient httpClient;
    private static Map<String, CloseableHttpClient> httpClinet_map;
    private Identifier identifier;
    @Autowired
    private OperationLogServiceImpl operationLogService;
    @Autowired
    private OrderServiceImpl orderService;

    private static void initCert(Tb_wx_pay_info info) throws Exception {
        httpClient = httpClinet_map.get(info.getSub_mchid());
        if (httpClient == null) {
            String privateKey = WxAPIV3Common.readLocalPrivateKey(info);
            PrivateKey merchantPrivateKey = PemUtil.loadPrivateKey((InputStream)new ByteArrayInputStream(privateKey.getBytes(XcbConstantValue.ENCODING_UTF8)));
            AutoUpdateCertificatesVerifier verifier = new AutoUpdateCertificatesVerifier((Credentials)new WechatPay2Credentials(info.getSub_mchid(), (Signer)new PrivateKeySigner(info.getSub_service_serialno(), merchantPrivateKey)), info.getSub_merkey_v3().getBytes(XcbConstantValue.ENCODING_UTF8));
            httpClient = WechatPayHttpClientBuilder.create().withMerchant(info.getSub_mchid(), info.getSub_service_serialno(), merchantPrivateKey).withValidator((Validator)new WechatPay2Validator((Verifier)verifier)).build();
            httpClinet_map.put(info.getSub_mchid(), httpClient);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Map<String, Object> createPayOrder(Tb_order order, Tb_device_package devicePackage, int totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String result = "";
        try {
            WxAPIV3Common.initCert(info);
        }
        catch (Exception e) {
            this.log.error("\u52a0\u8f7dhttpClient\u5f02\u5e38");
            e.printStackTrace();
        }
        String privateKey = WxAPIV3Common.readLocalPrivateKey(info);
        String url = XcbConstantValue.wx_apiv3_pay_url;
        URIBuilder uriBuilder = new URIBuilder(url);
        String sd_ordercash_id = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
        HashMap<String, Object> amountMap = new HashMap<String, Object>();
        amountMap.put("total", totalMoney);
        amountMap.put("currency", "CNY");
        JSONObject amount = JSONObject.fromObject(amountMap);
        String notify_url = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/payNotify";
        HashMap<String, String> payerMap = new HashMap<String, String>();
        payerMap.put("openid", sr_open_id);
        JSONObject payer = JSONObject.fromObject(payerMap);
        HashMap<String, Object> sceneInfoMap = new HashMap<String, Object>();
        HashMap<String, String> storeInfoMap = new HashMap<String, String>();
        storeInfoMap.put("id", XcbStringUtils.getObjtoString((Object)order.getSw_netpoint_id()));
        storeInfoMap.put("name", order.getSr_net_name());
        sceneInfoMap.put("payer_client_ip", cus_ip);
        sceneInfoMap.put("store_info", storeInfoMap);
        StringBuffer sb_attach = new StringBuffer();
        BigDecimal dc_order_money = BigDecimal.ZERO;
        BigDecimal dc_deposit_money = BigDecimal.ZERO;
        if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
            dc_order_money = devicePackage.getDc_once_price();
            dc_deposit_money = devicePackage.getDc_advance_price();
        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
            dc_order_money = devicePackage.getDc_once_price();
            dc_deposit_money = devicePackage.getDc_advance_price();
        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
            dc_deposit_money = devicePackage.getDc_advance_price();
        }
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSw_user_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_agent_id())).append(",").append(XcbStringUtils.getObjtoString((Object)devicePackage.getSd_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_device_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_box_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_order_way())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_charging_type())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_cj_function())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_iphone_num())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_password())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_WX)).append(",").append(XcbStringUtils.getObjtoString((Object)dc_order_money)).append(",").append(XcbStringUtils.getObjtoString((Object)dc_deposit_money)).append(",").append(XcbStringUtils.getObjtoString((Object)info.getSub_mchid()));
        System.out.println("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        JSONObject scene_info = JSONObject.fromObject(sceneInfoMap);
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        dataMap.put("amount", amount);
        dataMap.put("mchid", info.getSub_mchid());
        dataMap.put("description", info.getSr_body_name());
        dataMap.put("notify_url", notify_url);
        dataMap.put("payer", payer);
        dataMap.put("out_trade_no", sd_ordercash_id);
        dataMap.put("appid", info.getSub_appid());
        dataMap.put("scene_info", scene_info);
        dataMap.put("attach", sb_attach.toString());
        String reqdata = JSONObject.fromObject(dataMap).toString();
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
        CloseableHttpResponse response = null;
        try {
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, XcbConstantValue.ENCODING_UTF8);
            entity.setContentType("application/json");
            httpPost.setEntity((HttpEntity)entity);
            httpPost.setHeader("Accept", "application/json");
            response = httpClient.execute((HttpUriRequest)httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                Map<Object, Object> payMap = new HashMap();
                this.log.info("success,return body = " + result);
                JSONObject resultJson = JSONObject.fromObject((Object)result);
                String prepay_id = XcbStringUtils.getObjtoString((Object)resultJson.get("prepay_id"));
                payMap = this.conPayParam(privateKey, prepay_id, info);
                payMap.put("sw_order_id", order.getSd_order_id());
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.DATA, payMap);
            } else if (statusCode == 204) {
                result = "\u4e0b\u5355\u6210\u529f";
                this.log.info("success");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("failed,resp code = " + statusCode + ",return body = " + result);
                JSONObject jsonObj = JSONObject.fromObject((Object)result);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, jsonObj.getString("message"));
            }
        }
        catch (Exception e) {
            this.log.error("\u5fae\u4fe1\u652f\u4ed8V3 \u8bf7\u6c42url={}\u5f02\u5e38 ", (Object)uriBuilder.build());
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "createPayOrder", Integer.valueOf(0), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u5fae\u4fe1v3\u652f\u4ed8\u5931\u8d25" + result, "/pay/createPayOrder", cus_ip);
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(order.getSd_order_id());
            operationLogs.setSr_operate_table("tb_order");
            this.operationLogService.createOperaLog(this.identifier, operationLogs);
        }
        finally {
            if (null != response) {
                response.close();
            }
        }
        return ret;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Map<String, Object> createPayOrderGoods(Tb_order_goods order, int totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String result = "";
        try {
            WxAPIV3Common.initCert(info);
        }
        catch (Exception e) {
            this.log.error("\u52a0\u8f7dhttpClient\u5f02\u5e38");
            e.printStackTrace();
        }
        String privateKey = WxAPIV3Common.readLocalPrivateKey(info);
        String url = XcbConstantValue.wx_apiv3_pay_url;
        URIBuilder uriBuilder = new URIBuilder(url);
        HashMap<String, Object> amountMap = new HashMap<String, Object>();
        amountMap.put("total", totalMoney);
        amountMap.put("currency", "CNY");
        JSONObject amount = JSONObject.fromObject(amountMap);
        String notify_url = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/payGoodsNotify";
        HashMap<String, String> payerMap = new HashMap<String, String>();
        payerMap.put("openid", sr_open_id);
        JSONObject payer = JSONObject.fromObject(payerMap);
        StringBuffer sb_attach = new StringBuffer();
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)info.getSub_mchid()));
        System.out.println("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        dataMap.put("amount", amount);
        dataMap.put("mchid", info.getSub_mchid());
        dataMap.put("description", info.getSr_body_name());
        dataMap.put("notify_url", notify_url);
        dataMap.put("payer", payer);
        dataMap.put("out_trade_no", order.getSd_order_id());
        dataMap.put("appid", info.getSub_appid());
        dataMap.put("attach", sb_attach.toString());
        String reqdata = JSONObject.fromObject(dataMap).toString();
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
        CloseableHttpResponse response = null;
        try {
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, XcbConstantValue.ENCODING_UTF8);
            entity.setContentType("application/json");
            httpPost.setEntity((HttpEntity)entity);
            httpPost.setHeader("Accept", "application/json");
            response = httpClient.execute((HttpUriRequest)httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                Map<Object, Object> payMap = new HashMap();
                this.log.info("success,return body = " + result);
                JSONObject resultJson = JSONObject.fromObject((Object)result);
                String prepay_id = XcbStringUtils.getObjtoString((Object)resultJson.get("prepay_id"));
                payMap = this.conPayParam(privateKey, prepay_id, info);
                payMap.put("sd_order_id", order.getSd_order_id());
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.DATA, payMap);
            } else if (statusCode == 204) {
                result = "\u4e0b\u5355\u6210\u529f";
                this.log.info("success");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("failed,resp code = " + statusCode + ",return body = " + result);
                JSONObject jsonObj = JSONObject.fromObject((Object)result);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, jsonObj.getString("message"));
            }
        }
        catch (Exception e) {
            this.log.error("\u5fae\u4fe1\u652f\u4ed8V3 \u8bf7\u6c42url={}\u5f02\u5e38 ", (Object)uriBuilder.build());
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "createPayOrderGoods", Integer.valueOf(0), XcbConstantValue.OPERATION_FAIL, "CREATE", "\u5fae\u4fe1v3\u652f\u4ed8\u5931\u8d25" + result, "/pay/createPayOrderGoods", cus_ip);
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(order.getSd_order_id());
            operationLogs.setSr_operate_table("tb_order_goods");
            this.operationLogService.createOperaLog(this.identifier, operationLogs);
        }
        finally {
            if (null != response) {
                response.close();
            }
        }
        return ret;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Map<String, Object> finishOrder(Tb_order order, int totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String result = "";
        try {
            WxAPIV3Common.initCert(info);
        }
        catch (Exception e) {
            this.log.error("\u52a0\u8f7dhttpClient\u5f02\u5e38");
            e.printStackTrace();
        }
        String privateKey = WxAPIV3Common.readLocalPrivateKey(info);
        String url = XcbConstantValue.wx_apiv3_pay_url;
        URIBuilder uriBuilder = new URIBuilder(url);
        String sd_ordercash_id = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
        HashMap<String, Object> amountMap = new HashMap<String, Object>();
        amountMap.put("total", totalMoney);
        amountMap.put("currency", "CNY");
        JSONObject amount = JSONObject.fromObject(amountMap);
        String notify_url = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/finishNotify";
        HashMap<String, String> payerMap = new HashMap<String, String>();
        payerMap.put("openid", sr_open_id);
        JSONObject payer = JSONObject.fromObject(payerMap);
        HashMap<String, Object> sceneInfoMap = new HashMap<String, Object>();
        HashMap<String, String> storeInfoMap = new HashMap<String, String>();
        storeInfoMap.put("id", XcbStringUtils.getObjtoString((Object)order.getSw_netpoint_id()));
        storeInfoMap.put("name", order.getSr_net_name());
        sceneInfoMap.put("payer_client_ip", cus_ip);
        sceneInfoMap.put("store_info", storeInfoMap);
        StringBuffer sb_attach = new StringBuffer();
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_WX));
        System.out.println("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        JSONObject scene_info = JSONObject.fromObject(sceneInfoMap);
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        dataMap.put("amount", amount);
        dataMap.put("mchid", info.getSub_mchid());
        dataMap.put("description", info.getSr_body_name());
        dataMap.put("notify_url", notify_url);
        dataMap.put("payer", payer);
        dataMap.put("out_trade_no", sd_ordercash_id);
        dataMap.put("appid", info.getSub_appid());
        dataMap.put("scene_info", scene_info);
        dataMap.put("attach", sb_attach.toString());
        String reqdata = JSONObject.fromObject(dataMap).toString();
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
        CloseableHttpResponse response = null;
        try {
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, XcbConstantValue.ENCODING_UTF8);
            entity.setContentType("application/json");
            httpPost.setEntity((HttpEntity)entity);
            httpPost.setHeader("Accept", "application/json");
            response = httpClient.execute((HttpUriRequest)httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                Map<Object, Object> payMap = new HashMap();
                this.log.info("success,return body = " + result);
                JSONObject resultJson = JSONObject.fromObject((Object)result);
                String prepay_id = XcbStringUtils.getObjtoString((Object)resultJson.get("prepay_id"));
                payMap = this.conPayParam(privateKey, prepay_id, info);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.DATA, payMap);
            } else if (statusCode == 204) {
                result = "\u4e0b\u5355\u6210\u529f";
                this.log.info("success");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("failed,resp code = " + statusCode + ",return body = " + result);
                JSONObject jsonObj = JSONObject.fromObject((Object)result);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, jsonObj.getString("message"));
            }
        }
        catch (Exception e) {
            this.log.error("\u5fae\u4fe1\u652f\u4ed8V3 \u8bf7\u6c42url={}\u5f02\u5e38 ", (Object)uriBuilder.build());
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "createPayOrder", Integer.valueOf(0), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u5fae\u4fe1v3\u652f\u4ed8\u5931\u8d25" + result, "/pay/createPayOrder", cus_ip);
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(order.getSd_order_id());
            operationLogs.setSr_operate_table("tb_order");
            this.operationLogService.createOperaLog(this.identifier, operationLogs);
        }
        finally {
            if (null != response) {
                response.close();
            }
        }
        return ret;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Map<String, Object> temporaryOrder(Tb_order order, int totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String result = "";
        try {
            WxAPIV3Common.initCert(info);
        }
        catch (Exception e) {
            this.log.error("\u52a0\u8f7dhttpClient\u5f02\u5e38");
            e.printStackTrace();
        }
        String privateKey = WxAPIV3Common.readLocalPrivateKey(info);
        String url = XcbConstantValue.wx_apiv3_pay_url;
        URIBuilder uriBuilder = new URIBuilder(url);
        String sd_ordercash_id = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
        HashMap<String, Object> amountMap = new HashMap<String, Object>();
        amountMap.put("total", totalMoney);
        amountMap.put("currency", "CNY");
        JSONObject amount = JSONObject.fromObject(amountMap);
        String notify_url = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/temporaryNotify";
        HashMap<String, String> payerMap = new HashMap<String, String>();
        payerMap.put("openid", sr_open_id);
        JSONObject payer = JSONObject.fromObject(payerMap);
        HashMap<String, Object> sceneInfoMap = new HashMap<String, Object>();
        HashMap<String, String> storeInfoMap = new HashMap<String, String>();
        storeInfoMap.put("id", XcbStringUtils.getObjtoString((Object)order.getSw_netpoint_id()));
        storeInfoMap.put("name", order.getSr_net_name());
        sceneInfoMap.put("payer_client_ip", cus_ip);
        sceneInfoMap.put("store_info", storeInfoMap);
        StringBuffer sb_attach = new StringBuffer();
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_WX));
        System.out.println("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        JSONObject scene_info = JSONObject.fromObject(sceneInfoMap);
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        dataMap.put("amount", amount);
        dataMap.put("mchid", info.getSub_mchid());
        dataMap.put("description", info.getSr_body_name());
        dataMap.put("notify_url", notify_url);
        dataMap.put("payer", payer);
        dataMap.put("out_trade_no", sd_ordercash_id);
        dataMap.put("appid", info.getSub_appid());
        dataMap.put("scene_info", scene_info);
        dataMap.put("attach", sb_attach.toString());
        String reqdata = JSONObject.fromObject(dataMap).toString();
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
        CloseableHttpResponse response = null;
        try {
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, XcbConstantValue.ENCODING_UTF8);
            entity.setContentType("application/json");
            httpPost.setEntity((HttpEntity)entity);
            httpPost.setHeader("Accept", "application/json");
            response = httpClient.execute((HttpUriRequest)httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                Map<Object, Object> payMap = new HashMap();
                this.log.info("success,return body = " + result);
                JSONObject resultJson = JSONObject.fromObject((Object)result);
                String prepay_id = XcbStringUtils.getObjtoString((Object)resultJson.get("prepay_id"));
                payMap = this.conPayParam(privateKey, prepay_id, info);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.DATA, payMap);
            } else if (statusCode == 204) {
                result = "\u4e0b\u5355\u6210\u529f";
                this.log.info("success");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("failed,resp code = " + statusCode + ",return body = " + result);
                JSONObject jsonObj = JSONObject.fromObject((Object)result);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, jsonObj.getString("message"));
            }
        }
        catch (Exception e) {
            this.log.error("\u5fae\u4fe1\u652f\u4ed8V3 \u8bf7\u6c42url={}\u5f02\u5e38 ", (Object)uriBuilder.build());
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "createPayOrder", Integer.valueOf(0), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u5fae\u4fe1v3\u652f\u4ed8\u5931\u8d25" + result, "/pay/createPayOrder", cus_ip);
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(order.getSd_order_id());
            operationLogs.setSr_operate_table("tb_order");
            this.operationLogService.createOperaLog(this.identifier, operationLogs);
        }
        finally {
            if (null != response) {
                response.close();
            }
        }
        return ret;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Map<String, Object> xcrefund(String transaction_id, int total_fee, int refund_fee, String out_trade_no, String sd_cash_id, Tb_wx_pay_info info, String reason) throws Exception {
        Map<String, Object> ret = new HashMap<String, Object>();
        this.identifier = new Identifier(Integer.valueOf(0), "", "");
        String result = "";
        try {
            WxAPIV3Common.initCert(info);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        String url = XcbConstantValue.wx_apiv3_refund_url;
        URIBuilder uriBuilder = new URIBuilder(url);
        HashMap<String, Object> amountMap = new HashMap<String, Object>();
        amountMap.put("refund", refund_fee);
        amountMap.put("total", total_fee);
        amountMap.put("currency", "CNY");
        JSONObject amount = JSONObject.fromObject(amountMap);
        if (XcbStringUtils.isNullOrBlank((Object)reason)) {
            reason = "\u5546\u5bb6\u9000\u6b3e";
        }
        String notify_url = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/refundNotify";
        HashMap<String, String> dataMap = new HashMap<String, String>();
        dataMap.put("transaction_id", transaction_id);
        dataMap.put("out_trade_no", out_trade_no);
        dataMap.put("out_refund_no", sd_cash_id);
        dataMap.put("reason", reason);
        dataMap.put("notify_url", notify_url);
        dataMap.put("amount", (String)amount);
        String reqdata = JSONObject.fromObject(dataMap).toString();
        CloseableHttpResponse response = null;
        try {
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, XcbConstantValue.ENCODING_UTF8);
            entity.setContentType("application/json");
            httpPost.setEntity((HttpEntity)entity);
            httpPost.setHeader("Accept", "application/json");
            response = httpClient.execute((HttpUriRequest)httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                HashMap payMap = new HashMap();
                this.log.info("success,return body = " + result);
                JSONObject resultJson = JSONObject.fromObject((Object)result);
                this.log.info("\u5fae\u4fe1\u9000\u6b3e\u4e0b\u5355\uff1a\u4e1a\u52a1\u5f00\u59cb");
                String tkType = "";
                String sign_type = out_trade_no.substring(0, 2);
                String sr_refund_fee = CommonFunction.fenToyuan((String)XcbStringUtils.getObjtoString((Object)refund_fee));
                if (CommonFunction.zx_id.equals(sign_type)) {
                    tkType = "\u5bc4\u5b58\u67dc\u8ba2\u5355";
                    ret = this.orderService.autoTkNotify(this.identifier, out_trade_no, sr_refund_fee, sd_cash_id);
                }
                this.log.info("\u5fae\u4fe1" + tkType + "\u9000\u6b3e\u4e0b\u5355\uff1a\u4e1a\u52a1\u7ed3\u675f");
            } else if (statusCode == 204) {
                result = "\u9000\u6b3e\u4e0b\u5355\u6210\u529f";
                this.log.info("success");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("failed,resp code = " + statusCode + ",return body = " + result);
                JSONObject jsonObj = JSONObject.fromObject((Object)result);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, jsonObj.getString("message"));
            }
        }
        catch (Exception e) {
            this.log.error("\u5fae\u4fe1\u652f\u4ed8\u9000\u6b3eV3 \u8bf7\u6c42url={}\u5f02\u5e38 ", (Object)uriBuilder.build());
            Tb_operation_logs operationLogs = new Tb_operation_logs(XcbConstantValue.APPCAEGORY_ZF, "cancelPayScoreOrder", Integer.valueOf(0), XcbConstantValue.OPERATION_FAIL, "UPDATE", "\u5fae\u4fe1\u652f\u4ed8\u9000\u6b3e\u5931\u8d25:" + result, "", "");
            operationLogs.setSr_operate_from(XcbConstantValue.MOBILE);
            operationLogs.setSr_operate_primarykey(String.valueOf(out_trade_no));
            operationLogs.setSr_operate_table("tb_order");
            this.operationLogService.createOperaLog(this.identifier, operationLogs);
        }
        finally {
            if (null != response) {
                response.close();
            }
        }
        return ret;
    }

    public static String readLocalPrivateKey(Tb_wx_pay_info info) throws IOException {
        String keyPath = info.getSr_key_path() + info.getSub_mchid() + "/apiclient_key.pem";
        File file = new File(keyPath);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        return sb.toString();
    }

    public Map<String, String> conPayParam(String privateKey, String prepayid, Tb_wx_pay_info info) throws Exception {
        this.log.info("\u6839\u636e\u5f53\u524d\u7684prepayid\u6784\u9020\u8fd4\u56de\u53c2\u6570= " + prepayid);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("appId", info.getSub_appid());
        map.put("timeStamp", XcbDateUtil.getCurrentTimestamp() + "");
        map.put("nonceStr", WXPayUtil.generateNonceStr());
        map.put("package", "prepay_id=" + prepayid);
        map.put("signType", "RSA");
        try {
            String sign = RSAUtil.getPaySign(map, privateKey);
            this.log.info("paySign:" + sign);
            map.put("paySign", sign);
        }
        catch (Exception e) {
            this.log.error(e.getMessage());
        }
        return map;
    }

    static {
        httpClinet_map = new HashMap<String, CloseableHttpClient>();
    }
}

