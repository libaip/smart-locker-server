/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.company.model.Tb_order_goods
 *  com.jcg.company.model.Tb_wx_pay_info
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.zf.wx;

import com.jcg.agent.model.Tb_device_package;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.user.common.BaseService;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class WxSdjAPICommon
extends BaseService {
    public Map<String, Object> createPayOrder(Identifier identifier, Tb_order order, Tb_device_package devicePackage, BigDecimal totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) {
        identifier.setFunctionCode(XcbConstantValue.WX_SDJ_USER_ORDER_PAY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("devicePackage", devicePackage);
        param.put("totalMoney", totalMoney);
        param.put("sr_open_id", sr_open_id);
        param.put("info", info);
        param.put("cus_ip", cus_ip);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> createPayOrderGoods(Identifier identifier, Tb_order_goods order, BigDecimal totalMoney, String sr_open_id, Tb_wx_pay_info pay_info, String cus_ip) {
        identifier.setFunctionCode(XcbConstantValue.WX_SDJ_USER_ORDER_GOODS_PAY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("totalMoney", totalMoney);
        param.put("sr_open_id", sr_open_id);
        param.put("info", pay_info);
        param.put("cus_ip", cus_ip);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> temporaryOrder(Identifier identifier, Tb_order order, BigDecimal totalMoney, String sr_open_id, Tb_wx_pay_info pay_info, String cus_ip) {
        identifier.setFunctionCode(XcbConstantValue.WX_SDJ_USER_ORDER_TEMP_PAY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("totalMoney", totalMoney);
        param.put("sr_open_id", sr_open_id);
        param.put("info", pay_info);
        param.put("cus_ip", cus_ip);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> finishOrder(Identifier identifier, Tb_order order, BigDecimal totalMoney, String sr_open_id, Tb_wx_pay_info pay_info, String cus_ip) {
        identifier.setFunctionCode(XcbConstantValue.WX_SDJ_USER_ORDER_FINISH_PAY);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put("order", order);
        param.put("totalMoney", totalMoney);
        param.put("sr_open_id", sr_open_id);
        param.put("info", pay_info);
        param.put("cus_ip", cus_ip);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }

    public Map<String, Object> xcrefund(Identifier identifier, String transaction_id, String total, String payer_total, String out_trade_no, String sd_cash_id, Tb_wx_pay_info info) {
        identifier.setFunctionCode(XcbConstantValue.WX_SDJ_USER_REFUND);
        HashMap<String, String> param = new HashMap<String, String>();
        param.put("transaction_id", transaction_id);
        param.put("refund_fee", total);
        param.put("total_fee", payer_total);
        param.put("out_trade_no", out_trade_no);
        param.put("info", (String)info);
        param.put("sd_cash_id", sd_cash_id);
        Map ret = this.genericCaller.genericCall(identifier, param);
        return ret;
    }
}

