/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  com.alibaba.fastjson.TypeReference
 *  com.alibaba.fastjson.parser.Feature
 *  com.alipay.api.AlipayApiException
 *  com.alipay.api.AlipayRequest
 *  com.alipay.api.DefaultAlipayClient
 *  com.alipay.api.internal.util.AlipayEncrypt
 *  com.alipay.api.request.AlipaySystemOauthTokenRequest
 *  com.alipay.api.request.AlipayTradeCreateRequest
 *  com.alipay.api.request.AlipayTradeRefundRequest
 *  com.alipay.api.response.AlipaySystemOauthTokenResponse
 *  com.alipay.api.response.AlipayTradeCreateResponse
 *  com.alipay.api.response.AlipayTradeRefundResponse
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  javax.servlet.http.HttpServletRequest
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jcg.user.zf.zfb;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.fastjson.parser.Feature;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayRequest;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.internal.util.AlipayEncrypt;
import com.alipay.api.request.AlipaySystemOauthTokenRequest;
import com.alipay.api.request.AlipayTradeCreateRequest;
import com.alipay.api.request.AlipayTradeRefundRequest;
import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import com.alipay.api.response.AlipayTradeCreateResponse;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.jcg.agent.model.Tb_device_package;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.user.common.BaseService;
import com.jcg.user.common.PromptProperties;
import com.jcg.user.service.CompanyServiceImpl;
import com.jcg.user.service.OrderServiceImpl;
import com.jcg.user.vo.LoginUser;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ZFBzfCommon
extends BaseService {
    protected static Logger log = LoggerFactory.getLogger(ZFBzfCommon.class);
    @Autowired
    private CompanyServiceImpl companyService;
    @Autowired
    private OrderServiceImpl orderService;
    private static Map<String, Object> keyMap;
    private static Map<String, Map<String, Object>> cert_map;

    private static void initCert(Tb_company company) throws Exception {
        keyMap = cert_map.get(company.getSd_company_id());
        if (keyMap == null) {
            String publicKey = ZFBzfCommon.readLocalPubKey(company.getSr_zfb_public_path());
            String privateKey = ZFBzfCommon.readLocalPriKey(company.getSr_zfb_privatekey_path());
            keyMap = new HashMap<String, Object>();
            keyMap.put("publicKey", publicKey);
            keyMap.put("privateKey", privateKey);
            cert_map.put(company.getSd_company_id(), keyMap);
        }
    }

    public AlipaySystemOauthTokenResponse getAccessToken(Identifier identifier, LoginUser loginUser) throws Exception {
        AlipaySystemOauthTokenResponse response;
        block6: {
            response = new AlipaySystemOauthTokenResponse();
            try {
                Tb_company company = this.getCompany(identifier, loginUser.getSw_company_id());
                if (!loginUser.getSw_company_id().equals(company.getSd_company_id())) break block6;
                try {
                    ZFBzfCommon.initCert(company);
                }
                catch (Exception e) {
                    log.error("\u52a0\u8f7d\u652f\u4ed8\u5b9d\u8bc1\u4e66\u5f02\u5e38");
                    e.printStackTrace();
                }
                String publicKey = XcbStringUtils.getObjtoString((Object)keyMap.get("publicKey"));
                String privateKey = XcbStringUtils.getObjtoString((Object)keyMap.get("privateKey"));
                DefaultAlipayClient alipayClient = new DefaultAlipayClient(XcbConstantValue.zfb_api_url, company.getSr_yh_zfb_appid(), privateKey, "json", "GBK", publicKey, "RSA2");
                AlipaySystemOauthTokenRequest request = new AlipaySystemOauthTokenRequest();
                request.setGrantType("authorization_code");
                request.setCode(loginUser.getCode());
                response = (AlipaySystemOauthTokenResponse)alipayClient.execute((AlipayRequest)request);
                if (response.isSuccess()) {
                    System.out.println("\u8c03\u7528\u6210\u529f");
                } else {
                    System.out.println("\u8c03\u7528\u5931\u8d25");
                }
            }
            catch (Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
        }
        return response;
    }

    public Map<String, Object> createPayOrder(Tb_order order, Tb_device_package devicePackage, BigDecimal total_fee, String sr_open_id, Tb_company company) {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        try {
            ZFBzfCommon.initCert(company);
        }
        catch (Exception e) {
            log.error("\u52a0\u8f7d\u652f\u4ed8\u5b9d\u8bc1\u4e66\u5f02\u5e38");
            e.printStackTrace();
        }
        String publicKey = XcbStringUtils.getObjtoString((Object)keyMap.get("publicKey"));
        String privateKey = XcbStringUtils.getObjtoString((Object)keyMap.get("privateKey"));
        AlipayTradeCreateResponse response = null;
        String appid = company.getSr_yh_zfb_appid();
        String sd_ordercash_id = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
        String subject = company.getSr_body_name();
        BigDecimal dc_order_money = BigDecimal.ZERO;
        BigDecimal dc_deposit_money = BigDecimal.ZERO;
        if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
            dc_order_money = devicePackage.getDc_once_price();
            dc_deposit_money = devicePackage.getDc_advance_price();
        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
            dc_order_money = devicePackage.getDc_advance_price();
        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
            dc_deposit_money = devicePackage.getDc_advance_price();
        }
        StringBuffer sb_attach = new StringBuffer();
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSw_user_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_agent_id())).append(",").append(XcbStringUtils.getObjtoString((Object)devicePackage.getSd_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_device_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_box_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_order_way())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_charging_type())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_cj_function())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_iphone_num())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_password())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_ZFB)).append(",").append(XcbStringUtils.getObjtoString((Object)dc_order_money)).append(",").append(XcbStringUtils.getObjtoString((Object)dc_deposit_money));
        System.out.println("\u652f\u4ed8\u5b9d\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        log.info("\u652f\u4ed8\u5b9d\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        String sr_notify_url = XcbConstantValue.zfb_pay_notify_url.trim() + "_" + company.getSd_company_id().trim() + "/payNotify";
        DefaultAlipayClient alipayClient = new DefaultAlipayClient(XcbConstantValue.zfb_api_url, appid, privateKey, "json", "GBK", publicKey, "RSA2");
        AlipayTradeCreateRequest request = new AlipayTradeCreateRequest();
        request.setNotifyUrl(sr_notify_url);
        request.setBizContent("{\"out_trade_no\":\"" + sd_ordercash_id + "\",\"total_amount\":\"" + total_fee + "\",\"subject\":\"" + subject + "\",\"buyer_id\":\"" + sr_open_id + "\",\"body\":\"" + sb_attach + "\"    }");
        try {
            response = (AlipayTradeCreateResponse)alipayClient.execute((AlipayRequest)request);
            log.info("prepay from \u652f\u4ed8\u5b9d\u652f\u4ed8\u4e0b\u5355: \n " + response.getCode());
            String return_code = response.getCode();
            if (XcbConstantValue.zfb_rtn_code.equals(return_code)) {
                String trade_no = response.getTradeNo();
                dataMap.put("trade_no", trade_no);
                dataMap.put("sw_order_id", order.getSd_order_id());
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.DATA, dataMap);
            } else {
                log.error("\u652f\u4ed8\u5b9d -> \u5145\u503c\u652f\u4ed8 -> \u901a\u8baf\u51fa\u73b0\u5f02\u5e38\uff1a" + response.getMsg() + "\uff01");
                String msg = "\u652f\u4ed8\u901a\u8baf\u51fa\u73b0\u5f02\u5e38\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5\uff01";
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        }
        catch (AlipayApiException e) {
            e.printStackTrace();
        }
        return result_map;
    }

    public Map<String, Object> finishOrder(Tb_order order, BigDecimal total_fee, String sr_open_id, Tb_company company) {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        try {
            ZFBzfCommon.initCert(company);
        }
        catch (Exception e) {
            log.error("\u52a0\u8f7d\u652f\u4ed8\u5b9d\u8bc1\u4e66\u5f02\u5e38");
            e.printStackTrace();
        }
        String publicKey = XcbStringUtils.getObjtoString((Object)keyMap.get("publicKey"));
        String privateKey = XcbStringUtils.getObjtoString((Object)keyMap.get("privateKey"));
        AlipayTradeCreateResponse response = null;
        String appid = company.getSr_yh_zfb_appid();
        String sd_ordercash_id = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
        String subject = company.getSr_body_name();
        StringBuffer sb_attach = new StringBuffer();
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_ZFB));
        System.out.println("\u652f\u4ed8\u5b9d\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        log.info("\u652f\u4ed8\u5b9d\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        String sr_notify_url = XcbConstantValue.zfb_pay_notify_url.trim() + "_" + company.getSd_company_id().trim() + "/finishNotify";
        DefaultAlipayClient alipayClient = new DefaultAlipayClient(XcbConstantValue.zfb_api_url, appid, privateKey, "json", "GBK", publicKey, "RSA2");
        AlipayTradeCreateRequest request = new AlipayTradeCreateRequest();
        request.setNotifyUrl(sr_notify_url);
        request.setBizContent("{\"out_trade_no\":\"" + sd_ordercash_id + "\",\"total_amount\":\"" + total_fee + "\",\"subject\":\"" + subject + "\",\"buyer_id\":\"" + sr_open_id + "\",\"body\":\"" + sb_attach + "\"    }");
        try {
            response = (AlipayTradeCreateResponse)alipayClient.execute((AlipayRequest)request);
            log.info("prepay from \u652f\u4ed8\u5b9d\u652f\u4ed8\u4e0b\u5355: \n " + response.getCode());
            String return_code = response.getCode();
            if (XcbConstantValue.zfb_rtn_code.equals(return_code)) {
                String trade_no = response.getTradeNo();
                dataMap.put("trade_no", trade_no);
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.DATA, dataMap);
            } else {
                log.error("\u652f\u4ed8\u5b9d -> \u5145\u503c\u652f\u4ed8 -> \u901a\u8baf\u51fa\u73b0\u5f02\u5e38\uff1a" + response.getMsg() + "\uff01");
                String msg = "\u652f\u4ed8\u901a\u8baf\u51fa\u73b0\u5f02\u5e38\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5\uff01";
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        }
        catch (AlipayApiException e) {
            e.printStackTrace();
        }
        return result_map;
    }

    public Map<String, Object> temporaryOrder(Tb_order order, BigDecimal total_fee, String sr_open_id, Tb_company company) {
        HashMap<String, Object> result_map = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        try {
            ZFBzfCommon.initCert(company);
        }
        catch (Exception e) {
            log.error("\u52a0\u8f7d\u652f\u4ed8\u5b9d\u8bc1\u4e66\u5f02\u5e38");
            e.printStackTrace();
        }
        String publicKey = XcbStringUtils.getObjtoString((Object)keyMap.get("publicKey"));
        String privateKey = XcbStringUtils.getObjtoString((Object)keyMap.get("privateKey"));
        AlipayTradeCreateResponse response = null;
        String appid = company.getSr_yh_zfb_appid();
        String sd_ordercash_id = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
        String subject = company.getSr_body_name();
        StringBuffer sb_attach = new StringBuffer();
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_ZFB));
        System.out.println("\u652f\u4ed8\u5b9d\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        log.info("\u652f\u4ed8\u5b9d\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        String sr_notify_url = XcbConstantValue.zfb_pay_notify_url.trim() + "_" + company.getSd_company_id().trim() + "/temporaryNotify";
        DefaultAlipayClient alipayClient = new DefaultAlipayClient(XcbConstantValue.zfb_api_url, appid, privateKey, "json", "GBK", publicKey, "RSA2");
        AlipayTradeCreateRequest request = new AlipayTradeCreateRequest();
        request.setNotifyUrl(sr_notify_url);
        request.setBizContent("{\"out_trade_no\":\"" + sd_ordercash_id + "\",\"total_amount\":\"" + total_fee + "\",\"subject\":\"" + subject + "\",\"buyer_id\":\"" + sr_open_id + "\",\"body\":\"" + sb_attach + "\"    }");
        try {
            response = (AlipayTradeCreateResponse)alipayClient.execute((AlipayRequest)request);
            log.info("prepay from \u652f\u4ed8\u5b9d\u652f\u4ed8\u4e0b\u5355: \n " + response.getCode());
            String return_code = response.getCode();
            if (XcbConstantValue.zfb_rtn_code.equals(return_code)) {
                String trade_no = response.getTradeNo();
                dataMap.put("trade_no", trade_no);
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                result_map.put(XcbConstantValue.DATA, dataMap);
            } else {
                log.error("\u652f\u4ed8\u5b9d -> \u5145\u503c\u652f\u4ed8 -> \u901a\u8baf\u51fa\u73b0\u5f02\u5e38\uff1a" + response.getMsg() + "\uff01");
                String msg = "\u652f\u4ed8\u901a\u8baf\u51fa\u73b0\u5f02\u5e38\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5\uff01";
                result_map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                result_map.put(XcbConstantValue.MSG, msg);
            }
        }
        catch (AlipayApiException e) {
            e.printStackTrace();
        }
        return result_map;
    }

    public Map<String, Object> xcrefund(String trade_no, BigDecimal total_fee, BigDecimal refund_fee, String out_trade_no, String sd_cash_id, Tb_company company, String reason) throws Exception {
        Map<String, Object> ret = new HashMap<String, Object>();
        Identifier identifier = new Identifier(Integer.valueOf(0), "", "");
        String results = "";
        try {
            ZFBzfCommon.initCert(company);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        log.info("--------------------------------\u652f\u4ed8\u5b9d\u9000\u6b3e\u4e0b\u5355\u5f00\u59cb-----------------------------------");
        AlipayTradeRefundResponse response = null;
        String publicKey = XcbStringUtils.getObjtoString((Object)keyMap.get("publicKey"));
        String privateKey = XcbStringUtils.getObjtoString((Object)keyMap.get("privateKey"));
        DefaultAlipayClient alipayClient = new DefaultAlipayClient(XcbConstantValue.zfb_api_url, company.getSr_yh_zfb_appid(), privateKey, "json", "GBK", publicKey, "RSA2");
        AlipayTradeRefundRequest request = new AlipayTradeRefundRequest();
        try {
            request.setBizContent("{\"out_trade_no\":\"" + out_trade_no + "\",\"trade_no\":\"" + trade_no + "\",\"refund_amount\":" + refund_fee + ",\"refund_reason\":\"\u6b63\u5e38\u9000\u6b3e\",\"out_request_no\":\"" + sd_cash_id + "\"  }");
            response = (AlipayTradeRefundResponse)alipayClient.execute((AlipayRequest)request);
            if (response.isSuccess()) {
                log.info("--------------------------------\u652f\u4ed8\u5b9d\u9000\u6b3e\u8c03\u7528\u6210\u529f----------------------------------");
                if (XcbConstantValue.zfb_rtn_code.equals(response.getCode())) {
                    log.info("----------------------------\u9000\u6b3e\u6210\u529f----------------------------");
                    results = "\u9000\u6b3e\u6210\u529f";
                    log.info("\u652f\u4ed8\u5b9d\u9000\u6b3e\u4e0b\u5355\uff1a\u4e1a\u52a1\u5f00\u59cb");
                    String tkType = "";
                    String sign_type = out_trade_no.substring(0, 2);
                    if (CommonFunction.zx_id.equals(sign_type)) {
                        tkType = "\u667a\u80fd\u67dc\u8ba2\u5355";
                        ret = this.orderService.tkNotify(identifier, out_trade_no, XcbStringUtils.getObjtoString((Object)refund_fee), sd_cash_id);
                    }
                    log.info("\u652f\u4ed8\u5b9d" + tkType + "\u9000\u6b3e\u4e0b\u5355\uff1a\u4e1a\u52a1\u7ed3\u675f");
                } else {
                    results = response.getSubMsg();
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, results);
                    log.info("--------------------------------\u652f\u4ed8\u5b9d\u9000\u6b3e\u8c03\u7528\u5931\u8d25:" + results + "----------------------------------");
                }
            } else {
                results = response.getSubMsg();
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, results);
                log.info("--------------------------------\u652f\u4ed8\u5b9d\u9000\u6b3e\u8c03\u7528\u5931\u8d25----------------------------------");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        log.info("--------------------------------\u652f\u4ed8\u5b9d\u9000\u6b3e\u4e0b\u5355\u7ed3\u675f-----------------------------------");
        return ret;
    }

    public Tb_company getCompany(Identifier identifier, String sw_company_id) throws Exception {
        Tb_company company = new Tb_company();
        try {
            Map<String, Object> dataMap = this.companyService.findComanyParamCache(identifier, sw_company_id);
            company = (Tb_company)dataMap.get(XcbConstantValue.DATA);
        }
        catch (Exception e) {
            log.error(PromptProperties.getProperty("company.find.error", sw_company_id));
            throw new Exception(e);
        }
        return company;
    }

    public Map<String, String> convertRequestParamsToMap(HttpServletRequest request) {
        HashMap<String, String> retMap = new HashMap<String, String>();
        Set entrySet = request.getParameterMap().entrySet();
        for (Map.Entry entry : entrySet) {
            String name = (String)entry.getKey();
            String[] values = (String[])entry.getValue();
            int valLen = values.length;
            if (valLen == 1) {
                retMap.put(name, values[0]);
                continue;
            }
            if (valLen > 1) {
                StringBuilder sb = new StringBuilder();
                for (String val : values) {
                    sb.append(",").append(val);
                }
                retMap.put(name, sb.toString().substring(1));
                continue;
            }
            retMap.put(name, "");
        }
        return retMap;
    }

    public static String readLocalPubKey(String filePath) throws IOException {
        File file = new File(filePath);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        System.out.println("\u652f\u4ed8\u5b9d\u516c\u94a5\uff1a" + sb.toString());
        return sb.toString();
    }

    public static String readLocalPriKey(String filePath) throws IOException {
        File file = new File(filePath);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        System.out.println("\u652f\u4ed8\u5b9d\u79c1\u94a5\uff1a" + sb.toString());
        return sb.toString();
    }

    public String decryptPhoneNum(Identifier identifier, String response, String sw_company_id) throws Exception {
        Tb_company company = this.getCompany(identifier, sw_company_id);
        Map openapiResult = (Map)JSON.parseObject((String)response, (TypeReference)new TypeReference<Map<String, String>>(){}, (Feature[])new Feature[]{Feature.OrderedField});
        String charset = "UTF-8";
        String encryptType = "AES";
        String content = (String)openapiResult.get("response");
        boolean isDataEncrypted = !content.startsWith("{");
        String decryptKey = company.getSr_yh_zfb_aes_key();
        String plainData = null;
        if (isDataEncrypted) {
            try {
                System.out.println("AlipayEncrypt");
                plainData = AlipayEncrypt.decryptContent((String)content, (String)encryptType, (String)decryptKey, (String)charset);
                System.out.println("AlipayEncrypt Trance done");
            }
            catch (AlipayApiException e) {
                try {
                    throw new Exception("\u89e3\u5bc6\u5f02\u5e38");
                }
                catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        } else {
            plainData = content;
        }
        System.out.println(plainData);
        log.info("\u652f\u4ed8\u5b9d\u83b7\u53d6\u4f1a\u5458\u624b\u673a\u53f7\u7801\u89e3\u5bc6\u7ed3\u679c:" + plainData);
        return plainData;
    }

    static {
        cert_map = new HashMap<String, Map<String, Object>>();
    }
}

