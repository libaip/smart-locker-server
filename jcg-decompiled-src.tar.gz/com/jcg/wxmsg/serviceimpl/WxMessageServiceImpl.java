/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSONObject
 *  com.google.gson.JsonSyntaxException
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_advice_user
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_wx_info
 *  com.jcg.company.model.Tb_wx_template
 *  com.jcg.user.model.Tb_user
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.ClientProtocolException
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.util.EntityUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.wxmsg.serviceimpl;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonSyntaxException;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.BaseService;
import com.jcg.common.HttpClientUtil;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.idao.CompanyDao;
import com.jcg.company.idao.WxInfoDao;
import com.jcg.company.idao.WxTemplateDao;
import com.jcg.company.model.Tb_advice_user;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_wx_info;
import com.jcg.company.model.Tb_wx_template;
import com.jcg.user.idao.UserDao;
import com.jcg.user.model.Tb_user;
import com.jcg.wxmsg.util.MenuAppUtil;
import com.jcg.wxmsg.util.MenuUtil;
import com.jcg.wxmsg.vo.WxAppMessage;
import com.jcg.wxmsg.vo.WxMessage;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class WxMessageServiceImpl
extends BaseService
implements GenericCaller {
    private static final String QR_LIMIT_STR_SCENE = "QR_LIMIT_STR_SCENE";
    private static String create_ticket_path = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=";
    private static String show_qrcode_path = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=";
    private static String create_menu_url = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=";
    private static String send_message = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=";
    private static String send_app_message = "https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token=";
    public static String common_url = XcbConstantValue.user_host;
    @Autowired
    private UserDao userDao;
    @Autowired
    private CompanyDao companyDao;
    @Autowired
    private RedisUtil redis;
    @Autowired
    private WxInfoDao wxInfoDao;
    @Autowired
    private WxTemplateDao wxTemplateDao;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        Integer sw_user_id = null;
        String sw_company_id = "";
        if (param != null) {
            sw_user_id = XcbStringUtils.getObjtoint((Object)param.get("sw_user_id"));
            sw_company_id = XcbStringUtils.getObjtoString((Object)param.get("sw_company_id"));
        }
        try {
            String type;
            String money;
            Tb_order order;
            if (XcbConstantValue.WX_MESSAGE_SEND.equals(functionCode)) {
                order = (Tb_order)param.get("sd_order_id");
                money = XcbStringUtils.getObjtoString((Object)param.get("money"));
                type = XcbStringUtils.getObjtoString((Object)param.get("type"));
                ret = this.sendMessage(sw_user_id, order, money, type, null);
            }
            if (XcbConstantValue.WX_MESSAGE_APP_SEND.equals(functionCode)) {
                order = (Tb_order)param.get("sd_order_id");
                money = XcbStringUtils.getObjtoString((Object)param.get("money"));
                type = XcbStringUtils.getObjtoString((Object)param.get("type"));
                ret = this.sendAppMessage(sw_user_id, order, money, type);
            } else if (XcbConstantValue.WX_GZH_MENU_CREATE.equals(functionCode)) {
                String sr_way = XcbStringUtils.getObjtoString((Object)param.get("sr_way"));
                String sr_version = XcbStringUtils.getObjtoString((Object)param.get("sr_version"));
                ret = this.createMenu(sr_way, sr_version);
            }
        }
        catch (BusinessException e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)((Object)e)));
            throw e;
        }
        return ret;
    }

    public Map<String, Object> sendMessage(Integer sw_user_id, Tb_order order, String money, String type, Tb_advice_user advice) {
        Map<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_user user = this.userDao.findUserById(sw_user_id);
            Tb_wx_info info = this.wxInfoDao.findInfoByCode(user.getSr_way());
            Tb_wx_template tmp_info = this.wxTemplateDao.findWxTemplateByType(info.getSr_gzh_appid(), type);
            info.setTmp_info(tmp_info);
            String access_token = XcbStringUtils.getObjtoString((Object)this.redis.get("access_token_" + user.getSr_way()));
            if (XcbStringUtils.isNullOrBlank((Object)access_token)) {
                access_token = this.getAccessToken(info);
            }
            if (WxMessage.model_return.equals(type)) {
                ret = this.sendDepositMoney(user, order, money, access_token, info);
            } else if (WxMessage.model_asjf.equals(type)) {
                ret = this.sendAsjf(user, order, money, access_token, info);
            } else if (WxMessage.model_finish.equals(type)) {
                ret = this.sendFinish(user, order, money, access_token, info);
            } else if (WxMessage.model_refund.equals(type)) {
                ret = this.sendRefund(user, order, money, access_token, info);
            } else if (WxMessage.model_tx.equals(type)) {
                ret = this.sendTx(user, money, access_token, info);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    public Map<String, Object> sendAppMessage(Integer sw_user_id, Tb_order order, String money, String type) {
        Map<String, Object> ret = new HashMap<String, Object>();
        try {
            Tb_user user = this.userDao.findUserById(sw_user_id);
            Tb_wx_info info = this.wxInfoDao.findInfoByCode(user.getSr_way());
            Tb_wx_template tmp_info = this.wxTemplateDao.findWxTemplateByType(info.getSr_appid(), type);
            info.setTmp_info(tmp_info);
            String access_token = XcbStringUtils.getObjtoString((Object)this.redis.get("app_access_token" + user.getSr_way()));
            if (XcbStringUtils.isNullOrBlank((Object)access_token)) {
                access_token = this.getAppAccessToken(info);
            }
            if (WxAppMessage.model_return.equals(type)) {
                ret = this.sendAppDepositMoney(user, order, money, access_token, info);
            } else if (WxAppMessage.model_create.equals(type)) {
                ret = this.sendAppCreate(user, order, money, access_token, info);
            } else if (WxAppMessage.model_finish.equals(type)) {
                ret = this.sendAppFinish(user, order, money, access_token, info);
            } else if (WxAppMessage.model_refund.equals(type)) {
                ret = this.sendAppRefund(user, order, money, access_token, info);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private Map<String, Object> sendRefund(Tb_user user, Tb_order order, String money, String access_token, Tb_wx_info info) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            String url = send_message + access_token;
            Tb_wx_template tmp_info = info.getTmp_info();
            JSONObject map = new JSONObject();
            map.put("touser", (Object)user.getSr_open_id());
            map.put("template_id", (Object)tmp_info.getSr_msg_id());
            JSONObject character_string1 = new JSONObject();
            character_string1.put("value", (Object)order.getSd_order_id());
            character_string1.put("color", (Object)"#173177");
            JSONObject amount2 = new JSONObject();
            amount2.put("value", (Object)(money + "\u5143"));
            amount2.put("color", (Object)"#173177");
            JSONObject data = new JSONObject();
            data.put("character_string1", (Object)character_string1);
            data.put("amount2", (Object)amount2);
            map.put("data", (Object)data);
            String sendData = JSONObject.toJSONString((Object)map);
            String result = HttpClientUtil.getJsonData(sendData, url);
            System.out.println("-->" + result);
            this.log.info("\u6a21\u677f\u53d1\u9001\u7ed3\u679c\u901a\u77e5:\u7528\u6237ID:" + order.getSw_user_id() + ",\u7ed3\u679c:" + result);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private Map<String, Object> sendTx(Tb_user user, String money, String access_token, Tb_wx_info info) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            String url = send_message + access_token;
            Tb_wx_template tmp_info = info.getTmp_info();
            JSONObject map = new JSONObject();
            map.put("touser", (Object)user.getSr_open_id());
            map.put("template_id", (Object)tmp_info.getSr_msg_id());
            JSONObject amount1 = new JSONObject();
            amount1.put("value", (Object)(money + "\u5143"));
            amount1.put("color", (Object)"#173177");
            JSONObject time2 = new JSONObject();
            time2.put("value", (Object)XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
            time2.put("color", (Object)"#173177");
            JSONObject data = new JSONObject();
            data.put("amount1", (Object)amount1);
            data.put("time2", (Object)time2);
            map.put("data", (Object)data);
            String sendData = JSONObject.toJSONString((Object)map);
            String result = HttpClientUtil.getJsonData(sendData, url);
            System.out.println("-->" + result);
            this.log.info("\u6a21\u677f\u53d1\u9001\u7ed3\u679c\u901a\u77e5:\u7528\u6237ID:" + user.getSd_user_id() + ",\u7ed3\u679c:" + result);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private Map<String, Object> sendFinish(Tb_user user, Tb_order order, String money, String access_token, Tb_wx_info info) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            String url = send_message + access_token;
            Tb_wx_template tmp_info = info.getTmp_info();
            JSONObject map = new JSONObject();
            map.put("touser", (Object)user.getSr_open_id());
            map.put("template_id", (Object)tmp_info.getSr_msg_id());
            String sr_alias = order.getSr_alias_desc();
            if (!XcbStringUtils.isNullOrBlank((Object)sr_alias)) {
                if (sr_alias.contains("\u67dc")) {
                    sr_alias = sr_alias.replace("\u67dc", "-");
                }
                if (sr_alias.contains("\u533a")) {
                    sr_alias = sr_alias.replace("\u533a", "-");
                }
                if (sr_alias.contains("\u53f7")) {
                    sr_alias = sr_alias.replace("\u53f7", "");
                }
            }
            System.out.println("\u683c\u5b50\u7f16\u53f7:" + sr_alias);
            JSONObject thing1 = new JSONObject();
            thing1.put("value", (Object)order.getSr_net_name());
            thing1.put("color", (Object)"#173177");
            JSONObject character_string7 = new JSONObject();
            character_string7.put("value", (Object)sr_alias);
            character_string7.put("color", (Object)"#173177");
            JSONObject amount8 = new JSONObject();
            amount8.put("value", (Object)(order.getDc_actual_income() + "\u5143"));
            amount8.put("color", (Object)"#173177");
            JSONObject time2 = new JSONObject();
            time2.put("value", (Object)order.getSr_order_starttime());
            time2.put("color", (Object)"#173177");
            JSONObject time3 = new JSONObject();
            time3.put("value", (Object)order.getSr_order_endtime());
            time3.put("color", (Object)"#173177");
            JSONObject data = new JSONObject();
            data.put("character_string7", (Object)character_string7);
            data.put("thing1", (Object)thing1);
            data.put("amount8", (Object)amount8);
            data.put("time2", (Object)time2);
            data.put("time3", (Object)time3);
            map.put("data", (Object)data);
            String sendData = JSONObject.toJSONString((Object)map);
            String result = HttpClientUtil.getJsonData(sendData, url);
            System.out.println("-->" + result);
            this.log.info("\u6a21\u677f\u53d1\u9001\u7ed3\u679c\u901a\u77e5:\u7528\u6237ID:" + user.getSd_user_id() + ",\u7ed3\u679c:" + result);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private Map<String, Object> sendAsjf(Tb_user user, Tb_order order, String money, String access_token, Tb_wx_info info) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            String url = send_message + access_token;
            Tb_wx_template tmp_info = info.getTmp_info();
            JSONObject map = new JSONObject();
            map.put("touser", (Object)user.getSr_open_id());
            map.put("template_id", (Object)tmp_info.getSr_msg_id());
            JSONObject thing4 = new JSONObject();
            thing4.put("value", (Object)order.getSr_net_name());
            thing4.put("color", (Object)"#173177");
            JSONObject character_string5 = new JSONObject();
            String sr_alias = XcbStringUtils.getObjtoString((Object)order.getSr_alias_desc());
            if (!XcbStringUtils.isNullOrBlank((Object)sr_alias)) {
                if (sr_alias.contains("\u67dc")) {
                    sr_alias = sr_alias.replace("\u67dc", "-");
                }
                if (sr_alias.contains("\u533a")) {
                    sr_alias = sr_alias.replace("\u533a", "-");
                }
                if (sr_alias.contains("\u53f7")) {
                    sr_alias = sr_alias.replace("\u53f7", "");
                }
            }
            System.out.println("\u683c\u5b50\u7f16\u53f7:" + sr_alias);
            character_string5.put("value", (Object)sr_alias);
            character_string5.put("color", (Object)"#173177");
            JSONObject amount6 = new JSONObject();
            amount6.put("value", (Object)(money + "\u5143"));
            amount6.put("color", (Object)"#173177");
            JSONObject time3 = new JSONObject();
            time3.put("value", (Object)XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
            time3.put("color", (Object)"#173177");
            JSONObject data = new JSONObject();
            data.put("thing4", (Object)thing4);
            data.put("character_string5", (Object)character_string5);
            data.put("amount6", (Object)amount6);
            data.put("time3", (Object)time3);
            map.put("data", (Object)data);
            String sendData = JSONObject.toJSONString((Object)map);
            String result = HttpClientUtil.getJsonData(sendData, url);
            System.out.println("gzh \u5bc4\u5b58\u6210\u529f\u6d88\u606f-->" + result);
            this.log.info("\u6a21\u677f\u53d1\u9001\u7ed3\u679c\u901a\u77e5:\u7528\u6237ID:" + user.getSd_user_id() + ",\u7ed3\u679c:" + result);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private Map<String, Object> sendDepositMoney(Tb_user user, Tb_order order, String money, String access_token, Tb_wx_info info) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            String url = send_message + access_token;
            Tb_wx_template tmp_info = info.getTmp_info();
            JSONObject map = new JSONObject();
            map.put("touser", (Object)user.getSr_open_id());
            map.put("template_id", (Object)tmp_info.getSr_msg_id());
            JSONObject character_string11 = new JSONObject();
            character_string11.put("value", (Object)order.getSd_order_id());
            character_string11.put("color", (Object)"#173177");
            JSONObject amount7 = new JSONObject();
            amount7.put("value", (Object)(money + "\u5143"));
            amount7.put("color", (Object)"#173177");
            JSONObject character_string9 = new JSONObject();
            character_string9.put("value", (Object)order.getSw_ordercash_id());
            character_string9.put("color", (Object)"#173177");
            JSONObject thing8 = new JSONObject();
            thing8.put("value", (Object)"\u60a8\u53ef\u4ee5\u5728\u83dc\u5355\u680f\u9000\u6b3e&\u66f4\u591a\uff0c\u70b9\u51fb\u4f59\u989d\u63d0\u73b0");
            thing8.put("color", (Object)"#173177");
            JSONObject time5 = new JSONObject();
            time5.put("value", (Object)XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
            time5.put("color", (Object)"#173177");
            JSONObject data = new JSONObject();
            data.put("character_string11", (Object)character_string11);
            data.put("amount7", (Object)amount7);
            data.put("character_string9", (Object)character_string9);
            data.put("thing8", (Object)thing8);
            data.put("time5", (Object)time5);
            map.put("data", (Object)data);
            String sendData = JSONObject.toJSONString((Object)map);
            String result = HttpClientUtil.getJsonData(sendData, url);
            System.out.println("gzh \u9000\u62bc\u91d1\u6d88\u606f-->" + result);
            this.log.info("\u6a21\u677f\u53d1\u9001\u7ed3\u679c\u901a\u77e5:\u7528\u6237ID:" + user.getSd_user_id() + ",\u7ed3\u679c:" + result);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private Map<String, Object> sendUserAdvice(Tb_user user, String access_token, String sr_version, Tb_advice_user advice) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            String url = send_message + access_token;
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("touser", user.getSr_open_id());
            map.put("template_id", WxMessage.advice_user_msg);
            JSONObject first = new JSONObject();
            first.put("value", (Object)"\u60a8\u7684\u53cd\u9988\u4fe1\u606f\u5df2\u5f97\u5230\u56de\u590d");
            first.put("color", (Object)"#173177");
            JSONObject keyword1 = new JSONObject();
            keyword1.put("value", (Object)XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
            keyword1.put("color", (Object)"#173177");
            JSONObject keyword2 = new JSONObject();
            keyword2.put("value", (Object)advice.getSr_advice_title());
            keyword2.put("color", (Object)"#173177");
            JSONObject keyword3 = new JSONObject();
            keyword3.put("value", (Object)advice.getSr_advice_reply());
            keyword3.put("color", (Object)"#173177");
            JSONObject remark = new JSONObject();
            remark.put("value", (Object)"\u5982\u6709\u7591\u95ee\u8bf7\u8054\u7cfb\u5ba2\u670d");
            remark.put("color", (Object)"#173177");
            JSONObject data = new JSONObject();
            data.put("first", (Object)first);
            data.put("keyword1", (Object)keyword1);
            data.put("keyword2", (Object)keyword2);
            data.put("keyword3", (Object)keyword3);
            data.put("remark", (Object)remark);
            map.put("data", (String)data);
            String sendData = JSONObject.toJSONString(map);
            String result = HttpClientUtil.getJsonData(sendData, url);
            System.out.println("gzh \u7528\u6237\u53cd\u9988-->" + result);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    public String getAccessToken(Tb_company company) throws Exception {
        String access_token = "";
        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + company.getSr_wx_gzh_appid() + "&secret=" + company.getSr_wx_gzh_appsecret();
        JSONObject jsonObject = WxMessageServiceImpl.doGetJson(url);
        try {
            this.log.info("JSON:" + jsonObject);
            access_token = jsonObject.getString("access_token");
            int expires = jsonObject.getInteger("expires_in");
            this.redis.setForTimeMIN("access_token", access_token, 100L);
        }
        catch (Exception e) {
            System.out.println("\u9519\u8bef\u4fe1\u606f:" + jsonObject);
            this.log.info("\u9519\u8bef\u4fe1\u606f:" + jsonObject);
        }
        return access_token;
    }

    public String getAccessToken(Tb_wx_info info) throws Exception {
        String access_token = "";
        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + info.getSr_gzh_appid() + "&secret=" + info.getSr_gzh_appsecret();
        JSONObject jsonObject = WxMessageServiceImpl.doGetJson(url);
        try {
            this.log.info("JSON:" + jsonObject);
            access_token = jsonObject.getString("access_token");
            int expires = jsonObject.getInteger("expires_in");
            this.redis.setForTimeMIN("access_token_" + info.getSr_code(), access_token, 100L);
        }
        catch (Exception e) {
            System.out.println("\u9519\u8bef\u4fe1\u606f:" + jsonObject);
            this.log.info("\u9519\u8bef\u4fe1\u606f:" + jsonObject);
        }
        return access_token;
    }

    public String getAppAccessToken(Tb_wx_info info) throws Exception {
        String access_token = "";
        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + info.getSr_appid() + "&secret=" + info.getSr_appsecret();
        JSONObject jsonObject = WxMessageServiceImpl.doGetJson(url);
        try {
            this.log.info("JSON:" + jsonObject);
            access_token = jsonObject.getString("access_token");
            int expires = jsonObject.getInteger("expires_in");
            this.redis.setForTimeMIN("app_access_token_" + info.getSr_code(), access_token, 100L);
        }
        catch (Exception e) {
            System.out.println("\u9519\u8bef\u4fe1\u606f:" + jsonObject);
            this.log.info("\u9519\u8bef\u4fe1\u606f:" + jsonObject);
        }
        return access_token;
    }

    public String GenWxCode(Tb_company company, String sw_device_id) {
        String url = "";
        try {
            String accessToken = XcbStringUtils.getObjtoString((Object)this.redis.get("access_token"));
            if (XcbStringUtils.isNullOrBlank((Object)accessToken)) {
                accessToken = this.getAccessToken(company);
            }
            String sceneStr = sw_device_id;
            JSONObject json = this.createForeverTicket(accessToken, sceneStr);
            url = json.getString("url");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return url;
    }

    public String GenWxCode(Tb_wx_info info, String sw_device_id) {
        String url = "";
        try {
            String accessToken = XcbStringUtils.getObjtoString((Object)this.redis.get("access_token_" + info.getSr_code()));
            if (XcbStringUtils.isNullOrBlank((Object)accessToken)) {
                accessToken = this.getAccessToken(info);
            }
            String sceneStr = sw_device_id;
            JSONObject json = this.createForeverTicket(accessToken, sceneStr);
            url = json.getString("url");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return url;
    }

    public String GenOtherWxCode(String appid, String appsecret, String sw_device_id) {
        String url = "";
        try {
            String accessToken = XcbStringUtils.getObjtoString((Object)this.redis.get(appid + "_access_token"));
            if (XcbStringUtils.isNullOrBlank((Object)accessToken)) {
                accessToken = this.getOtherAccessToken(appid, appsecret);
            }
            String sceneStr = sw_device_id;
            JSONObject json = this.createForeverTicket(accessToken, sceneStr);
            url = json.getString("url");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return url;
    }

    public String getOtherAccessToken(String appid, String appsecret) throws Exception {
        String access_token = "";
        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + appid + "&secret=" + appsecret;
        JSONObject jsonObject = WxMessageServiceImpl.doGetJson(url);
        try {
            this.log.info("\u751f\u6210\u8bbe\u5907\u4e8c\u7ef4\u7801JSON:" + jsonObject);
            access_token = jsonObject.getString("access_token");
            int expires = jsonObject.getInteger("expires_in");
            this.redis.setForTimeMIN(appid + "_access_token", access_token, 100L);
        }
        catch (Exception e) {
            System.out.println("\u9519\u8bef\u4fe1\u606f:" + jsonObject);
            this.log.info("\u9519\u8bef\u4fe1\u606f:" + jsonObject);
        }
        return access_token;
    }

    public JSONObject createForeverTicket(String accessToken, String sceneStr) {
        JSONObject jsonObject = null;
        try {
            String url = create_ticket_path + accessToken;
            TreeMap<String, String> params = new TreeMap<String, String>();
            params.put("access_token", accessToken);
            HashMap<String, String> intMap = new HashMap<String, String>();
            intMap.put("scene_str", sceneStr);
            HashMap<String, HashMap<String, String>> mapMap = new HashMap<String, HashMap<String, String>>();
            mapMap.put("scene", intMap);
            JSONObject paramsMap = new JSONObject();
            paramsMap.put("action_name", (Object)QR_LIMIT_STR_SCENE);
            paramsMap.put("action_info", mapMap);
            String result = HttpClientUtil.sendPost(url, paramsMap);
            jsonObject = JSONObject.parseObject((String)result);
        }
        catch (JsonSyntaxException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    public JSONObject createQrCode(String ticket) {
        JSONObject jsonObject = null;
        try {
            String url = show_qrcode_path + ticket;
            jsonObject = WxMessageServiceImpl.doGetJson(url);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    public static String urlEncode(String source, String encode) {
        String result = source;
        try {
            result = URLEncoder.encode(source, encode);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public Map<String, Object> createMenu(String sr_way, String sr_version) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        Tb_wx_info info = this.wxInfoDao.findInfoByCode(sr_way);
        try {
            String accessToken = this.getAccessToken(info);
            String path = create_menu_url + accessToken;
            String jsonMenu = "";
            info.setSr_version(sr_version);
            jsonMenu = XcbConstantValue.WX_INFO_MODE_1.equals(info.getSr_type()) ? JSONObject.toJSONString((Object)MenuAppUtil.getMenu(info)) : JSONObject.toJSONString((Object)MenuUtil.getMenu(info));
            byte[] bytes = jsonMenu.getBytes("UTF-8");
            URL url = new URL(path);
            HttpURLConnection http = (HttpURLConnection)url.openConnection();
            http.setDoOutput(true);
            http.setDoInput(true);
            http.setRequestMethod("POST");
            http.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            http.connect();
            OutputStream os = http.getOutputStream();
            os.write(bytes);
            os.close();
            InputStream is = http.getInputStream();
            int size = is.available();
            byte[] bt = new byte[size];
            is.read(bt);
            String message = new String(bt, "UTF-8");
            JSONObject jsonMsg = JSONObject.parseObject((String)message);
            int status = Integer.parseInt(jsonMsg.getString("errcode"));
            String msg = jsonMsg.getString("errmsg");
            if (status == 0) {
                msg = "\u83dc\u5355\u66f4\u65b0\u6210\u529f";
                this.wxInfoDao.updateWxInfo(info);
            }
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, msg);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    public static JSONObject doGetJson(String url) throws ClientProtocolException, IOException {
        JSONObject jsonObject = null;
        DefaultHttpClient client = new DefaultHttpClient();
        HttpGet httpGet = new HttpGet(url);
        CloseableHttpResponse response = client.execute((HttpUriRequest)httpGet);
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            String result = EntityUtils.toString((HttpEntity)entity, (String)"UTF-8");
            jsonObject = JSONObject.parseObject((String)result);
        }
        return jsonObject;
    }

    private Map<String, Object> sendAppCreate(Tb_user user, Tb_order order, String money, String access_token, Tb_wx_info info) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            String url = send_app_message + access_token;
            Tb_wx_template tmp_info = info.getTmp_info();
            JSONObject map = new JSONObject();
            map.put("touser", (Object)user.getSr_app_open_id());
            map.put("template_id", (Object)tmp_info.getSr_msg_id());
            JSONObject thing1 = new JSONObject();
            thing1.put("value", (Object)order.getSr_net_name());
            thing1.put("color", (Object)"#173177");
            JSONObject thing2 = new JSONObject();
            String sr_alias = XcbStringUtils.getObjtoString((Object)order.getSr_alias_desc());
            thing2.put("value", (Object)sr_alias);
            thing2.put("color", (Object)"#173177");
            JSONObject amount3 = new JSONObject();
            amount3.put("value", (Object)(money + "\u5143"));
            amount3.put("color", (Object)"#173177");
            JSONObject time4 = new JSONObject();
            time4.put("value", (Object)XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
            time4.put("color", (Object)"#173177");
            JSONObject data = new JSONObject();
            data.put("thing1", (Object)thing1);
            data.put("thing2", (Object)thing2);
            data.put("amount3", (Object)amount3);
            data.put("time4", (Object)time4);
            map.put("data", (Object)data);
            String sendData = JSONObject.toJSONString((Object)map);
            String result = HttpClientUtil.getJsonData(sendData, url);
            System.out.println("-->" + result);
            this.log.info("\u6a21\u677f\u53d1\u9001\u7ed3\u679c\u901a\u77e5:\u7528\u6237ID:" + user.getSd_user_id() + ",\u7ed3\u679c:" + result);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private Map<String, Object> sendAppDepositMoney(Tb_user user, Tb_order order, String money, String access_token, Tb_wx_info info) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            String url = send_app_message + access_token;
            Tb_wx_template tmp_info = info.getTmp_info();
            JSONObject map = new JSONObject();
            map.put("touser", (Object)user.getSr_app_open_id());
            map.put("template_id", (Object)tmp_info.getSr_msg_id());
            JSONObject character_string1 = new JSONObject();
            character_string1.put("value", (Object)order.getSd_order_id());
            character_string1.put("color", (Object)"#173177");
            JSONObject amount2 = new JSONObject();
            amount2.put("value", (Object)(money + "\u5143"));
            amount2.put("color", (Object)"#173177");
            JSONObject thing3 = new JSONObject();
            thing3.put("value", (Object)"\u9000\u6b3e\u81f3\u4f59\u989d\uff0c\u70b9\u51fb\u4f59\u989d\u63d0\u73b0");
            thing3.put("color", (Object)"#173177");
            JSONObject data = new JSONObject();
            data.put("character_string1", (Object)character_string1);
            data.put("amount2", (Object)amount2);
            data.put("thing3", (Object)thing3);
            map.put("data", (Object)data);
            String sendData = JSONObject.toJSONString((Object)map);
            String result = HttpClientUtil.getJsonData(sendData, url);
            System.out.println("-->" + result);
            this.log.info("\u6a21\u677f\u53d1\u9001\u7ed3\u679c\u901a\u77e5:\u7528\u6237ID:" + user.getSd_user_id() + ",\u7ed3\u679c:" + result);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private Map<String, Object> sendAppFinish(Tb_user user, Tb_order order, String money, String access_token, Tb_wx_info info) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            String url = send_app_message + access_token;
            Tb_wx_template tmp_info = info.getTmp_info();
            JSONObject map = new JSONObject();
            map.put("touser", (Object)user.getSr_app_open_id());
            map.put("template_id", (Object)tmp_info.getSr_msg_id());
            JSONObject thing1 = new JSONObject();
            thing1.put("value", (Object)order.getSr_net_name());
            thing1.put("color", (Object)"#173177");
            JSONObject thing2 = new JSONObject();
            thing2.put("value", (Object)order.getSr_alias_desc());
            thing2.put("color", (Object)"#173177");
            JSONObject amount3 = new JSONObject();
            amount3.put("value", (Object)(order.getDc_actual_income() + "\u5143"));
            amount3.put("color", (Object)"#173177");
            JSONObject time4 = new JSONObject();
            time4.put("value", (Object)order.getSr_order_starttime());
            time4.put("color", (Object)"#173177");
            JSONObject time5 = new JSONObject();
            time5.put("value", (Object)order.getSr_order_endtime());
            time5.put("color", (Object)"#173177");
            JSONObject data = new JSONObject();
            data.put("thing1", (Object)thing1);
            data.put("thing2", (Object)thing2);
            data.put("amount3", (Object)amount3);
            data.put("time4", (Object)time4);
            data.put("time5", (Object)time5);
            map.put("data", (Object)data);
            String sendData = JSONObject.toJSONString((Object)map);
            String result = HttpClientUtil.getJsonData(sendData, url);
            System.out.println("-->" + result);
            this.log.info("\u6a21\u677f\u53d1\u9001\u7ed3\u679c\u901a\u77e5:\u7528\u6237ID:" + user.getSd_user_id() + ",\u7ed3\u679c:" + result);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private Map<String, Object> sendAppRefund(Tb_user user, Tb_order order, String money, String access_token, Tb_wx_info info) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            String url = send_app_message + access_token;
            Tb_wx_template tmp_info = info.getTmp_info();
            JSONObject map = new JSONObject();
            map.put("touser", (Object)user.getSr_app_open_id());
            map.put("template_id", (Object)tmp_info.getSr_msg_id());
            JSONObject character_string1 = new JSONObject();
            character_string1.put("value", (Object)order.getSd_order_id());
            character_string1.put("color", (Object)"#173177");
            JSONObject amount2 = new JSONObject();
            amount2.put("value", (Object)(money + "\u5143"));
            amount2.put("color", (Object)"#173177");
            JSONObject thing3 = new JSONObject();
            thing3.put("value", (Object)XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd HH:mm:ss"));
            thing3.put("color", (Object)"#173177");
            JSONObject data = new JSONObject();
            data.put("character_string1", (Object)character_string1);
            data.put("amount2", (Object)amount2);
            data.put("thing3", (Object)thing3);
            map.put("data", (Object)data);
            String sendData = JSONObject.toJSONString((Object)map);
            String result = HttpClientUtil.getJsonData(sendData, url);
            System.out.println("-->" + result);
            this.log.info("\u6a21\u677f\u53d1\u9001\u7ed3\u679c\u901a\u77e5:\u7528\u6237ID:" + order.getSw_user_id() + ",\u7ed3\u679c:" + result);
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            ret.put(XcbConstantValue.MSG, result);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }
}

