/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_wx_info
 */
package com.jcg.wxmsg.util;

import com.jcg.company.model.Tb_wx_info;
import com.jcg.wxmsg.vo.Button;
import com.jcg.wxmsg.vo.ComplexButton;
import com.jcg.wxmsg.vo.Menu;
import com.jcg.wxmsg.vo.ViewButton;

public class MenuUtil {
    public static Menu getMenu(Tb_wx_info info) {
        String index = info.getSr_user_host() + "?version=" + info.getSr_version() + "/#";
        String pickup = info.getSr_user_host() + "?version=" + info.getSr_version() + "/#/pickup";
        String mine = info.getSr_user_host() + "?version=" + info.getSr_version() + "/#/mine";
        String appl = info.getSr_user_host() + "?version=" + info.getSr_version() + "/#/appl";
        String joinus = info.getSr_user_host() + "?version=" + info.getSr_version() + "/#/contact";
        String help = info.getSr_user_host() + "?version=" + info.getSr_version() + "/#/help";
        ComplexButton cx_1 = new ComplexButton();
        cx_1.setUrl(index);
        cx_1.setName("\u5b58\u5305");
        cx_1.setType("view");
        ComplexButton cx_2 = new ComplexButton();
        cx_2.setUrl(pickup);
        cx_2.setName("\u53d6\u5305");
        cx_2.setType("view");
        ViewButton vb_1 = new ViewButton();
        vb_1.setUrl(mine);
        vb_1.setName("\u4e2a\u4eba\u4e2d\u5fc3");
        vb_1.setType("view");
        ViewButton vb_2 = new ViewButton();
        vb_2.setUrl(appl);
        vb_2.setName("\u4f59\u989d\u63d0\u73b0");
        vb_2.setType("view");
        ViewButton vb_3 = new ViewButton();
        vb_3.setUrl(help);
        vb_3.setName("\u4f7f\u7528\u5e2e\u52a9");
        vb_3.setType("view");
        ViewButton vb_4 = new ViewButton();
        vb_4.setName("\u4f4e\u4ef7\u7206\u54c1");
        vb_4.setType("view");
        vb_4.setUrl("https://cd-nt.lianlianlvyou.com/v4/index.html?i=wx58e8911f2b4f44fe&a=150308779&source=mall_spread&v=263&s=oRXy3wqwTLZbqBPYmQxseoTSDDWw&origin_a=150308779#/");
        ComplexButton cx_3 = new ComplexButton();
        cx_3.setName("\u9000\u6b3e&\u66f4\u591a");
        cx_3.setSub_button(new Button[]{vb_1, vb_2, vb_3, vb_4});
        Menu menu = new Menu();
        menu.setButton(new ComplexButton[]{cx_1, cx_2, cx_3});
        return menu;
    }
}

