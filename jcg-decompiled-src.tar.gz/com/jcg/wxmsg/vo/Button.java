/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.wxmsg.vo;

public class Button {
    private String name;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

