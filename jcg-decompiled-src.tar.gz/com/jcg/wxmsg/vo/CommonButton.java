/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.wxmsg.vo;

import com.jcg.wxmsg.vo.Button;

public class CommonButton
extends Button {
    private String type;
    private String key;

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getKey() {
        return this.key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}

