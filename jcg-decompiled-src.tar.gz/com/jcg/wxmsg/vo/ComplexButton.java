/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.wxmsg.vo;

import com.jcg.wxmsg.vo.Button;

public class ComplexButton {
    private String name;
    private String type;
    private String key;
    private String url;
    private Button[] sub_button;
    private String appid;
    private String pagepath;

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Button[] getSub_button() {
        return this.sub_button;
    }

    public void setSub_button(Button[] sub_button) {
        this.sub_button = sub_button;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getKey() {
        return this.key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAppid() {
        return this.appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getPagepath() {
        return this.pagepath;
    }

    public void setPagepath(String pagepath) {
        this.pagepath = pagepath;
    }
}

