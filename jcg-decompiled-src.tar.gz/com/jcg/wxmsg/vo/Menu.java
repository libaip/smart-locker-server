/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.wxmsg.vo;

import com.jcg.wxmsg.vo.ComplexButton;

public class Menu {
    private ComplexButton[] button;

    public ComplexButton[] getButton() {
        return this.button;
    }

    public void setButton(ComplexButton[] button) {
        this.button = button;
    }
}

