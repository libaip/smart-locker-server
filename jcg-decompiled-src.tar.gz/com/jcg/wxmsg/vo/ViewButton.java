/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.wxmsg.vo;

import com.jcg.wxmsg.vo.Button;

public class ViewButton
extends Button {
    private String type;
    private String url;
    private String appid;
    private String pagepath;

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAppid() {
        return this.appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getPagepath() {
        return this.pagepath;
    }

    public void setPagepath(String pagepath) {
        this.pagepath = pagepath;
    }
}

