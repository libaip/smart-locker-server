/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.wxmsg.vo;

public class WxAppMessage {
    public static String model_create = "create";
    public static String model_return = "return";
    public static String model_finish = "finish";
    public static String model_refund = "refund";
    public static String deposit_money_return_template_msg = "BFkar0NjQZK653DQ_2h_7hDI2OZtMmUhmiScA9fnejA";
    public static String create_order_success = "c7YeiVTR2djPXx6DHJ5yzBtAo3D6XQxy6caq5kIOsAc";
    public static String finish_order_success = "EMiAUchbcV9I1twXHGb6EruL58kBiIMb7yA_v2iZEVM";
    public static String refund_order_success = "ueijWsoARBIY8uDtvwtbdJfzLU2slayZgqFa3hLAwIE";
    public static String advice_user_msg = "jlXkkOgEEc0q-aEFuTDV5oliA2wVk-q81VQR-dbL0Yo";
    public static String user_tx_success = "BUK_OZg_K5srWiG_9GTaBQJ6eojuD-z3KVtIateUTFo";
}

