/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.wxmsg.vo;

public class WxMessage {
    public static String model_title = "\u7269\u54c1\u5bc4\u5b58\u6210\u529f\uff0c\u6b22\u8fce\u4f7f\u7528\u597d\u6613\u5b58\u5bc4\u5b58\u67dc";
    public static String model_title2 = "\u7269\u54c1\u5bc4\u5b58\u7ed3\u675f\uff0c\u53d6\u8d70\u7269\u54c1\u8bf7\u5173\u597d\u67dc\u95e8";
    public static String model_return = "return";
    public static String model_asjf = "asjf";
    public static String model_advice = "advice";
    public static String model_finish = "finish";
    public static String model_refund = "refund";
    public static String model_tx = "tx";
    public static String deposit_money_return_template_msg = "COPUHJlsOm2oLXDuu_wUTJLmpY4LjJs8BD80z1-SDGk";
    public static String create_order_success_asjf = "mBSlnz_7_qsVXOo2haSQvYQiVTls7L2_N4qhXkd07CA";
    public static String finish_order_success = "6k7od9Wlut2HIG7Jktbn1qs14enlRL7qdFAuUSQ5mNE";
    public static String refund_order_success = "z3g_hYFtVmqkgK9n5H1bKBzpilQ1hCCyJ1EtRYtt5gU";
    public static String advice_user_msg = "Mtihi8VgcZu-FQZsLwnRpdWCmFtA6rpho-Tvx4cl9z4";
    public static String user_tx_success = "A9_swjPNSHyZe3WBz5JveQg-zbt0Cj14RpQD4hLtjI4";
}

