/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.XcbConstantValue
 *  org.bouncycastle.util.encoders.Base64
 */
package com.jcg.zf.qb.util;

import com.jcg.common.model.XcbConstantValue;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.List;
import java.util.Map;
import org.bouncycastle.util.encoders.Base64;

public class QBUtils {
    public static String httpPost(String url, String data, Map<String, String> headers, Map<String, String> respHeaders) {
        return QBUtils.httpPost(url, data, headers, respHeaders, StandardCharsets.UTF_8, true);
    }

    public static String httpPost(String url, String data, Map<String, String> headers, Map<String, String> respHeaders, Charset charset, boolean logInfo) {
        if (logInfo) {
            QBUtils.logMsg(String.format("\u8bf7\u6c42\uff1a%s\r\n%s\n", url, data));
        }
        try {
            URL uri = new URL(url);
            HttpURLConnection connection = null;
            connection = (HttpURLConnection)uri.openConnection();
            connection.setRequestMethod("POST");
            if (headers != null && headers.size() > 0) {
                try {
                    for (String key : headers.keySet()) {
                        String val = headers.get(key);
                        if (key == null || key.trim().length() <= 0 || val == null) continue;
                        connection.setRequestProperty(key, val);
                        if (!logInfo) continue;
                        QBUtils.logMsg(String.format("%s : %s", key, val));
                    }
                    if (headers.size() > 1) {
                        QBUtils.logMsg(headers.toString());
                    }
                }
                catch (Exception iter) {
                    // empty catch block
                }
            }
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setUseCaches(false);
            connection.setInstanceFollowRedirects(true);
            connection.setReadTimeout(60000);
            connection.setConnectTimeout(10000);
            OutputStream out = connection.getOutputStream();
            out.write(data.getBytes(charset));
            out.flush();
            out.close();
            Map<String, List<String>> map = connection.getHeaderFields();
            for (String key : map.keySet()) {
                try {
                    respHeaders.put(key, map.get(key).get(0));
                }
                catch (Exception exception) {}
            }
            String res = QBUtils.readStream(connection.getInputStream());
            if (logInfo) {
                QBUtils.logMsg(String.format("\u54cd\u5e94\u7801\uff1a %s\uff0c \u54cd\u5e94\uff1a%s\uff0c %s\n\n", connection.getResponseCode(), res, connection.getResponseMessage()));
            }
            return res;
        }
        catch (Exception e) {
            QBUtils.logMsg(e);
            return null;
        }
    }

    public static void logMsg(Exception e) {
        e.printStackTrace();
    }

    public static void logMsg(String msg) {
        System.out.println(msg);
    }

    public static PrivateKey getPrivateKey(String priKey) {
        PrivateKey privateKey = null;
        try {
            PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decode((byte[])priKey.getBytes()));
            KeyFactory keyf = KeyFactory.getInstance("RSA");
            privateKey = keyf.generatePrivate(priPKCS8);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return privateKey;
    }

    public static PublicKey getPublicKey(String pubKey) {
        PublicKey publicKey = null;
        try {
            X509EncodedKeySpec PubKeySpec = new X509EncodedKeySpec(Base64.decode((byte[])pubKey.getBytes()));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            publicKey = keyFactory.generatePublic(PubKeySpec);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return publicKey;
    }

    public static String sign256(String data, String privateKey) {
        byte[] sigByte = QBUtils.sign256(data.getBytes(StandardCharsets.UTF_8), QBUtils.getPrivateKey(privateKey));
        String signVal = Base64.toBase64String((byte[])sigByte);
        return signVal;
    }

    public static byte[] sign256(byte[] data, PrivateKey privateKey) {
        byte[] signed = null;
        Signature signature = null;
        try {
            signature = Signature.getInstance(XcbConstantValue.SIGNATURE_ALGORITHM);
            signature.initSign(privateKey);
            signature.update(data);
            signed = signature.sign();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return signed;
    }

    public static boolean verify256(String data, String sign, String pubKey) {
        if (data == null || sign == null) {
            return false;
        }
        try {
            byte[] signBytes = Base64.decode((String)sign);
            byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);
            Signature signetcheck = Signature.getInstance(XcbConstantValue.SIGNATURE_ALGORITHM);
            signetcheck.initVerify(QBUtils.getPublicKey(pubKey));
            signetcheck.update(dataBytes);
            return signetcheck.verify(signBytes);
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static String readStream(InputStream stream) {
        String str = null;
        try {
            int read;
            byte[] buffer = new byte[64];
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            while ((read = stream.read(buffer)) > 0) {
                bo.write(buffer, 0, read);
            }
            str = bo.toString(String.valueOf(StandardCharsets.UTF_8));
        }
        catch (Exception exception) {
            // empty catch block
        }
        return str;
    }
}

