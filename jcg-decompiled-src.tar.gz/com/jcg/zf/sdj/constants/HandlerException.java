/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.zf.sdj.constants;

public class HandlerException
extends Exception {
    private static final long serialVersionUID = 1L;
    private String code;
    private String message;

    public HandlerException(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

