/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang.StringUtils
 *  org.bouncycastle.jce.provider.BouncyCastleProvider
 */
package com.jcg.zf.sdj.util;

import com.jcg.zf.sdj.util.UtilString;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.Security;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.lang.StringUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class AESEnDecryptionUtil {
    public static final String ALGORITHM_NAME = "SM4";
    public static final String ALGORITHM_NAME_ECB_PADDING = "SM4/ECB/PKCS5Padding";
    public static final String CHARSET_UTF8 = "UTF-8";
    private static final String KEY_ALGORITHM = "AES";
    private static final String DEFAULT_CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";
    public static final String DEFAULT_PASSWORD = "1234567890123456";

    private static String parseByte2HexStr(byte[] buf) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < buf.length; ++i) {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }

    private static byte[] parseHexStr2Byte(String hexStr) {
        if (hexStr.length() < 1) {
            return null;
        }
        if (hexStr.length() % 2 != 0) {
            return null;
        }
        byte[] result = new byte[hexStr.length() / 2];
        for (int i = 0; i < hexStr.length() / 2; ++i) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte)(high * 16 + low);
        }
        return result;
    }

    private static Key toKey(String password) throws UnsupportedEncodingException {
        return new SecretKeySpec(password.getBytes(CHARSET_UTF8), KEY_ALGORITHM);
    }

    public static String encryptEcbPadding(String content, String password) {
        if (UtilString.isEmpty(content)) {
            return "";
        }
        try {
            Key key = AESEnDecryptionUtil.toKey(password);
            byte[] byteContent = content.getBytes(CHARSET_UTF8);
            Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
            cipher.init(1, key);
            byte[] result = cipher.doFinal(byteContent);
            return AESEnDecryptionUtil.parseByte2HexStr(result);
        }
        catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String decryptEcbPadding(String cipherText, String key) {
        if (null == cipherText || StringUtils.isBlank((String)cipherText)) {
            return "";
        }
        try {
            int length = cipherText.length();
            if (length % 32 != 0) {
                return cipherText;
            }
            if (key.length() != 16) {
                throw new RuntimeException("err key length");
            }
            if (AESEnDecryptionUtil.isLowerCase(cipherText)) {
                Cipher cipher = AESEnDecryptionUtil.generateEcbCipher(ALGORITHM_NAME_ECB_PADDING, 2, key.getBytes(CHARSET_UTF8));
                byte[] contentHex = AESEnDecryptionUtil.parseHexStr2Byte(cipherText);
                byte[] doFinal = cipher.doFinal(contentHex);
                return new String(doFinal, CHARSET_UTF8);
            }
            return AESEnDecryptionUtil.decrypt(cipherText, key);
        }
        catch (BadPaddingException e) {
            return AESEnDecryptionUtil.decrypt(cipherText, key);
        }
        catch (Exception e) {
            e.printStackTrace();
            return cipherText;
        }
    }

    private static Cipher generateEcbCipher(String algorithmName, int mode, byte[] key) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException {
        Cipher cipher = Cipher.getInstance(algorithmName, "BC");
        SecretKeySpec sm4Key = new SecretKeySpec(key, ALGORITHM_NAME);
        cipher.init(mode, sm4Key);
        return cipher;
    }

    public static String decrypt(String content) {
        return AESEnDecryptionUtil.decrypt(content, DEFAULT_PASSWORD);
    }

    public static String decrypt(String content, String password) {
        if (UtilString.isEmpty(content)) {
            return "";
        }
        try {
            byte[] contentHex = AESEnDecryptionUtil.parseHexStr2Byte(content);
            if (null == contentHex) {
                return "";
            }
            Key key = AESEnDecryptionUtil.toKey(password);
            Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
            cipher.init(2, key);
            byte[] result = cipher.doFinal(contentHex);
            return new String(result, CHARSET_UTF8);
        }
        catch (Exception exception) {
            return "";
        }
    }

    private static boolean isLowerCase(String cipherText) {
        for (int i = 0; i < cipherText.length(); ++i) {
            char c = cipherText.charAt(i);
            if (!Character.isLowerCase(c)) continue;
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        String bankAccountIdentityNo = "B56DDB9367A2DBA0639562CFA3B7DEB5FC1DCD56596DFC48AF639BC147D705C1";
        String bankAccountName = "7CFAE80DD3583FB0BB8DCE2FB9935A95A7C084307CCAA439B4BBC6DBD9A2C71D";
        String bankAccountNo = "DA21E6208A2DD0C69323FF7064184079";
        System.out.println(AESEnDecryptionUtil.decryptEcbPadding(bankAccountIdentityNo, "pxuer1pmg4vq7uty"));
        System.out.println(AESEnDecryptionUtil.decryptEcbPadding(bankAccountName, "pxuer1pmg4vq7uty"));
        System.out.println(AESEnDecryptionUtil.decryptEcbPadding(bankAccountNo, "pxuer1pmg4vq7uty"));
    }

    static {
        if (Security.getProvider("BC") == null) {
            Security.addProvider((Provider)new BouncyCastleProvider());
        }
    }
}

