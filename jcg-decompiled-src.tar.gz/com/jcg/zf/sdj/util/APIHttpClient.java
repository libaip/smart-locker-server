/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.PostConstruct
 *  javax.annotation.PreDestroy
 *  org.apache.commons.logging.Log
 *  org.apache.commons.logging.LogFactory
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.config.RequestConfig
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClientBuilder
 *  org.apache.http.util.EntityUtils
 */
package com.jcg.zf.sdj.util;

import com.jcg.zf.sdj.util.UtilHttp;
import com.jcg.zf.sdj.util.UtilIo;
import com.jcg.zf.sdj.util.UtilString;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.TreeMap;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

public class APIHttpClient {
    private Log logger = LogFactory.getLog(this.getClass());
    private static final APIHttpClient instance = new APIHttpClient();
    private CloseableHttpClient httpClient;
    private Integer maxConnPerRoute = 20;
    private Integer maxConnTotal = 200;
    private Integer connectTimeout = 5000;
    private Integer socketTimeout = 60000;

    private APIHttpClient() {
        this.init();
    }

    public static APIHttpClient getInstance() {
        return instance;
    }

    @PostConstruct
    private void init() {
        HttpClientBuilder builder = HttpClientBuilder.create();
        builder.setMaxConnPerRoute(this.maxConnPerRoute.intValue()).setMaxConnTotal(this.maxConnTotal.intValue());
        builder.setDefaultRequestConfig(RequestConfig.custom().setConnectTimeout(this.connectTimeout.intValue()).setSocketTimeout(this.socketTimeout.intValue()).build());
        this.httpClient = builder.build();
    }

    @PreDestroy
    public void destroy() {
        UtilIo.close(new AutoCloseable[]{this.httpClient});
    }

    private String execute(HttpUriRequest request) {
        String html = null;
        int statusCode = 418;
        try (CloseableHttpResponse response = this.httpClient.execute(request);){
            statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                html = EntityUtils.toString((HttpEntity)response.getEntity());
            } else {
                HttpEntity entity = response.getEntity();
                if (null != entity) {
                    this.logger.info((Object)String.format("statusCode=%s;entity=%s", statusCode, EntityUtils.toString((HttpEntity)entity)));
                } else {
                    this.logger.info((Object)("statusCode=" + statusCode + ";entity is null"));
                }
                html = null;
            }
        }
        catch (Exception e) {
            this.logger.error((Object)e.getMessage(), (Throwable)e);
            html = UtilString.substring(html, 0, 1024);
        }
        return html;
    }

    public String get(String url, Object params) {
        Map map = params == null ? null : (params instanceof Map ? (Map)params : (Map)params);
        HttpGet request = map == null || map.isEmpty() ? new HttpGet(url) : new HttpGet(UtilHttp.toURI(url, map));
        return this.execute((HttpUriRequest)request);
    }

    public String get(String url, Object ... params) {
        TreeMap<String, Object> data = new TreeMap<String, Object>();
        int i = 0;
        int len = params.length;
        while (i < len) {
            data.put(UtilString.toString(params[i++]), params[i++]);
        }
        return this.get(url, (Object)data);
    }

    public String post(String params, String url) {
        HttpPost post = new HttpPost(url);
        post.addHeader("Content-type", "application/json");
        post.setHeader("Accept", "application/json");
        post.setEntity((HttpEntity)new StringEntity(params, Charset.forName("UTF-8")));
        return this.execute((HttpUriRequest)post);
    }

    public String post(String url, Object ... params) {
        TreeMap<String, Object> data = new TreeMap<String, Object>();
        int i = 0;
        int len = params.length;
        while (i < len) {
            data.put(UtilString.toString(params[i++]), params[i++]);
        }
        return this.post(url, data);
    }

    public String post(String uri, HttpEntity entity) {
        HttpPost post = new HttpPost(uri);
        post.setEntity(entity);
        return this.execute((HttpUriRequest)post);
    }
}

