/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.codec.binary.Base64
 *  org.apache.commons.io.FileUtils
 *  org.bouncycastle.jce.provider.BouncyCastleProvider
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jcg.zf.sdj.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Enumeration;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PfxCerUtil {
    private static final Logger logger = LoggerFactory.getLogger(PfxCerUtil.class);
    private static final String ENCODING = "UTF-8";
    private static final String SIGNATURE_ALGORITHM = "SHA256withRSA";

    public static byte[] sign256(String data, PrivateKey privateKey) throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, SignatureException, UnsupportedEncodingException {
        Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
        signature.initSign(privateKey);
        signature.update(data.getBytes(ENCODING));
        return signature.sign();
    }

    public static boolean verify256(String data, String sign, PublicKey publicKey) throws UnsupportedEncodingException {
        return PfxCerUtil.verify256(data, sign.getBytes(ENCODING), publicKey);
    }

    public static boolean verify256(String data, byte[] sign, PublicKey publicKey) throws UnsupportedEncodingException {
        if (data == null || sign == null || publicKey == null) {
            return false;
        }
        byte[] byteData = data.getBytes(ENCODING);
        try {
            Signature signetcheck = Signature.getInstance(SIGNATURE_ALGORITHM);
            signetcheck.initVerify(publicKey);
            signetcheck.update(byteData);
            return signetcheck.verify(PfxCerUtil.decodeBase64(sign));
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static String encodeBase64(byte[] bytes) {
        return new String(Base64.encodeBase64((byte[])bytes));
    }

    public static byte[] decodeBase64(byte[] bytes) {
        byte[] result = null;
        try {
            result = Base64.decodeBase64((byte[])bytes);
        }
        catch (Exception e) {
            return null;
        }
        return result;
    }

    public static PublicKey getEncryptCertPublicKey(String path) {
        if (!PfxCerUtil.isEmpty(path)) {
            X509Certificate encryptCert = PfxCerUtil.initCert(path);
            return encryptCert.getPublicKey();
        }
        logger.error("sdj-merchant-sdk.encryptCert.path is empty");
        return null;
    }

    public static PublicKey getEncryptCertPublicKeyByKeyStr(String keyStr) {
        try {
            X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(Base64.decodeBase64((String)keyStr));
            KeyFactory factory = PfxCerUtil.getKeyFactory();
            PublicKey pubKey = factory.generatePublic(x509EncodedKeySpec);
            return pubKey;
        }
        catch (Exception e) {
            logger.error("sdj-merchant-sdk.encryptCert.path is empty");
            return null;
        }
    }

    public static String getEncryptCertId(String path) {
        if (!PfxCerUtil.isEmpty(path)) {
            X509Certificate encryptCert = PfxCerUtil.initCert(path);
            return encryptCert.getSerialNumber().toString();
        }
        logger.error("sdj-merchant-sdk.encryptCert.path is empty");
        return null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static X509Certificate initCert(String path) {
        X509Certificate encryptCertTemp = null;
        CertificateFactory cf = null;
        FileInputStream in = null;
        try {
            Security.addProvider((Provider)new BouncyCastleProvider());
            cf = CertificateFactory.getInstance("X.509", "BC");
            in = new FileInputStream(path);
            encryptCertTemp = (X509Certificate)cf.generateCertificate(in);
            logger.info("\u9a8c\u7b7e\u8bc1\u4e66\uff1a" + path + " CertId=" + encryptCertTemp.getSerialNumber().toString(16));
        }
        catch (CertificateException e) {
            logger.error("InitCert Error", (Throwable)e);
        }
        catch (FileNotFoundException e) {
            logger.error("InitCert Error File Not Found", (Throwable)e);
        }
        catch (NoSuchProviderException e) {
            logger.error("LoadVerifyCert Error No BC Provider", (Throwable)e);
        }
        finally {
            if (null != in) {
                try {
                    in.close();
                }
                catch (IOException e) {
                    logger.error(e.toString());
                }
            }
        }
        return encryptCertTemp;
    }

    private static KeyFactory getKeyFactory() throws Exception {
        return PfxCerUtil.getKeyFactory("RSA");
    }

    private static KeyFactory getKeyFactory(String algorithm) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
        return keyFactory;
    }

    private static KeyStore getKeyStore(byte[] pfxData, String password) throws Exception {
        KeyStore keystore = KeyStore.getInstance("PKCS12");
        keystore.load(new ByteArrayInputStream(pfxData), password.toCharArray());
        return keystore;
    }

    public static PrivateKey getPrivateKeyByPfx(byte[] pfxData, String password) throws Exception {
        PrivateKey privateKey = null;
        KeyStore keystore = PfxCerUtil.getKeyStore(pfxData, password);
        Enumeration<String> enums = keystore.aliases();
        String keyAlias = "";
        while (enums.hasMoreElements()) {
            keyAlias = enums.nextElement();
            if (!keystore.isKeyEntry(keyAlias)) continue;
            privateKey = (PrivateKey)keystore.getKey(keyAlias, password.toCharArray());
        }
        return privateKey;
    }

    public static PrivateKey getPrivateKeyByPfx(String pfxPath, String password) throws Exception {
        File pfxFile = new File(pfxPath);
        return PfxCerUtil.getPrivateKeyByPfx(FileUtils.readFileToByteArray((File)pfxFile), password);
    }

    public static PrivateKey getPrivateKey(byte[] privateKeyByte) throws Exception {
        PrivateKey privateKey = null;
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyByte);
        KeyFactory keyFactory = PfxCerUtil.getKeyFactory();
        privateKey = keyFactory.generatePrivate(keySpec);
        return privateKey;
    }

    public static PrivateKey getPrivateKey(String privateKeyStr) throws Exception {
        byte[] privateKeyByte = Base64.decodeBase64((String)privateKeyStr);
        return PfxCerUtil.getPrivateKey(privateKeyByte);
    }

    public static PublicKey getPublicKey(byte[] publicKeyByte) throws Exception {
        PublicKey publicKey = null;
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicKeyByte);
        KeyFactory keyFactory = PfxCerUtil.getKeyFactory();
        publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

    public static PublicKey getPublicKey(String publicKeyStr) throws Exception {
        byte[] publicKeyByte = Base64.decodeBase64((String)publicKeyStr);
        return PfxCerUtil.getPublicKey(publicKeyByte);
    }

    public static X509Certificate getX509Certificate(byte[] pfxData, String password) throws Exception {
        X509Certificate x509Certificate = null;
        KeyStore keystore = PfxCerUtil.getKeyStore(pfxData, password);
        Enumeration<String> enums = keystore.aliases();
        String keyAlias = "";
        while (enums.hasMoreElements()) {
            keyAlias = enums.nextElement();
            if (!keystore.isKeyEntry(keyAlias)) continue;
            x509Certificate = (X509Certificate)keystore.getCertificate(keyAlias);
        }
        return x509Certificate;
    }

    public static X509Certificate getX509Certificate(String pfxPath, String password) throws Exception {
        File pfxFile = new File(pfxPath);
        return PfxCerUtil.getX509Certificate(FileUtils.readFileToByteArray((File)pfxFile), password);
    }

    public static String getCertId(String pfxPath, String password) throws Exception {
        X509Certificate x509 = PfxCerUtil.getX509Certificate(pfxPath, password);
        String certId = x509.getSerialNumber().toString(16);
        return certId;
    }

    public static byte[] generatorPkcx12(PrivateKey privateKey, X509Certificate x509Certificate, String password) throws Exception {
        Certificate[] chain = new Certificate[]{x509Certificate};
        KeyStore keystore = KeyStore.getInstance("PKCS12");
        keystore.load(null, password.toCharArray());
        keystore.setKeyEntry(x509Certificate.getSerialNumber().toString(), privateKey, password.toCharArray(), chain);
        ByteArrayOutputStream bytesos = new ByteArrayOutputStream();
        keystore.store(bytesos, password.toCharArray());
        byte[] bytes = bytesos.toByteArray();
        return bytes;
    }

    public static String generatorPFX(PrivateKey privateKey, X509Certificate x509Certificate, String password, File saveFile) throws Exception {
        if (!saveFile.exists()) {
            if (!saveFile.getParentFile().exists()) {
                saveFile.getParentFile().mkdirs();
            }
            saveFile.createNewFile();
        }
        byte[] pkcs12Byte = PfxCerUtil.generatorPkcx12(privateKey, x509Certificate, password);
        FileUtils.writeByteArrayToFile((File)saveFile, (byte[])pkcs12Byte);
        return saveFile.getPath();
    }

    public static void main(String[] args) throws Exception {
        String pfxPath = "C:\\Users\\49383\\Desktop\\\u6587\u4ef6\\\u56fd\u65b0\u6d4b\u8bd5\u8bc1\u4e66-1.pfx";
        String password = "1";
        PrivateKey privateKey = PfxCerUtil.getPrivateKeyByPfx(pfxPath, password);
        byte[] privateKeyByte = privateKey.getEncoded();
        String privateKeyStr = Base64.encodeBase64String((byte[])privateKeyByte);
        System.out.println("\u79c1\u94a5Base64\u5b57\u7b26\u4e32\uff1a" + privateKeyStr);
        PrivateKey privateKey2 = PfxCerUtil.getPrivateKey(privateKeyStr);
        System.out.println("\u79c1\u94a5Base64\u5b57\u7b26\u4e322\uff1a" + Base64.encodeBase64String((byte[])privateKey2.getEncoded()));
        X509Certificate certificate = PfxCerUtil.getX509Certificate(pfxPath, password);
        System.out.println("\u8bc1\u4e66\u4e3b\u9898\uff1a" + certificate.getSubjectDN().getName());
        String publicKeyStr = Base64.encodeBase64String((byte[])certificate.getPublicKey().getEncoded());
        System.out.println("\u516c\u94a5Base64\u5b57\u7b26\u4e32\uff1a" + publicKeyStr);
        System.out.println("\u516c\u94a5Base64\u5b57\u7b26\u4e322\uff1a" + Base64.encodeBase64String((byte[])PfxCerUtil.getPublicKey(publicKeyStr).getEncoded()));
        String savePath = PfxCerUtil.generatorPFX(privateKey, certificate, "1", new File("C:\\Users\\49383\\Desktop\\\u6587\u4ef6\\009\\009.pfx"));
        System.out.println(savePath);
    }

    public static boolean isEmpty(String s) {
        return null == s || "".equals(s.trim());
    }
}

