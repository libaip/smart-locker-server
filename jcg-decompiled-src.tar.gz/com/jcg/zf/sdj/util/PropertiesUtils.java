/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSONObject
 *  org.apache.commons.lang.StringUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jcg.zf.sdj.util;

import com.alibaba.fastjson.JSONObject;
import com.jcg.zf.sdj.util.APIHttpClient;
import com.jcg.zf.sdj.util.UtilProperties;
import java.util.HashMap;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertiesUtils {
    private static final Logger log = LoggerFactory.getLogger(PropertiesUtils.class);
    public static final String merchantNo = "sdj-merchant-api.config.merchantNo";
    public static final String merchantKey = "sdj-merchant-api.config.merchantKey";

    public static String getConfig(String key) {
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("key", key);
        String reqMsg = JSONObject.toJSONString(map);
        String gateway = UtilProperties.getPropertiesValue("app.properties", "sdjGateway");
        log.info("\u914d\u7f6e\u4e2d\u5fc3\u8bf7\u6c42\u8def\u5f84:{},\u8bf7\u6c42\u62a5\u6587:{}", (Object)(gateway + "/getPosConfig"), (Object)reqMsg);
        String respMsg = APIHttpClient.getInstance().post(reqMsg, gateway + "/getMerchantNoAndMerchantKey");
        log.info("\u914d\u7f6e\u4e2d\u5fc3\u54cd\u5e94\u62a5\u6587:{}", (Object)respMsg);
        if (StringUtils.isBlank((String)respMsg)) {
            log.info("\u914d\u7f6e\u4e2d\u5fc3\u54cd\u5e94\u62a5\u6587\uff1a{}, \u8fd4\u56de\u9519\u8bef\uff1anull", (Object)key);
            return "";
        }
        JSONObject resultJson = JSONObject.parseObject((String)respMsg);
        if (!"12000".equals(resultJson.getString("code"))) {
            log.info("\u914d\u7f6e\u4e2d\u5fc3\u54cd\u5e94\u62a5\u6587\uff1a{}, \u8fd4\u56de\u9519\u8bef\uff1a{}", (Object)key, (Object)resultJson.getString("code"));
            return "";
        }
        return resultJson.getString("value");
    }
}

