/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bouncycastle.jce.provider.BouncyCastleProvider
 */
package com.jcg.zf.sdj.util;

import com.jcg.zf.sdj.util.Base64;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Enumeration;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class RSAUtil {
    public static final String SIGN_ALGORITHMS = "SHA1WithRSA";

    public static String sign(String content, String input_charset, Key key) throws UnsupportedEncodingException, Exception {
        try {
            Security.addProvider((Provider)new BouncyCastleProvider());
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(1, key);
            byte[] output = cipher.doFinal(content.getBytes(input_charset));
            return Base64.encode(output);
        }
        catch (NoSuchAlgorithmException e) {
            throw new Exception("\u65e0\u6b64\u52a0\u5bc6\u7b97\u6cd5");
        }
        catch (NoSuchPaddingException e) {
            e.printStackTrace();
            return null;
        }
        catch (InvalidKeyException e) {
            throw new Exception("\u52a0\u5bc6\u516c\u94a5\u975e\u6cd5,\u8bf7\u68c0\u67e5");
        }
        catch (IllegalBlockSizeException e) {
            throw new Exception("\u660e\u6587\u957f\u5ea6\u975e\u6cd5");
        }
        catch (BadPaddingException e) {
            throw new Exception("\u660e\u6587\u6570\u636e\u5df2\u635f\u574f");
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String readFile(String filePath, String charSet) throws Exception {
        try (FileInputStream fileInputStream = new FileInputStream(filePath);){
            FileChannel fileChannel = fileInputStream.getChannel();
            ByteBuffer byteBuffer = ByteBuffer.allocate((int)fileChannel.size());
            fileChannel.read(byteBuffer);
            byteBuffer.flip();
            String string = new String(byteBuffer.array(), charSet);
            return string;
        }
    }

    public static String getKey(String string) throws Exception {
        String content = RSAUtil.readFile(string, "UTF8");
        return content.replaceAll("\\-{5}[\\w\\s]+\\-{5}[\\r\\n|\\n]", "");
    }

    public static String signByPrivate(String content, PrivateKey privateKey, String input_charset) throws Exception {
        if (privateKey == null) {
            throw new Exception("\u52a0\u5bc6\u79c1\u94a5\u4e3a\u7a7a, \u8bf7\u8bbe\u7f6e");
        }
        Signature signature = Signature.getInstance(SIGN_ALGORITHMS);
        signature.initSign(privateKey);
        signature.update(content.getBytes(input_charset));
        return Base64.encode(signature.sign());
    }

    public static String signByPrivate(String content, String privateKey, String input_charset) throws Exception {
        if (privateKey == null) {
            throw new Exception("\u52a0\u5bc6\u79c1\u94a5\u4e3a\u7a7a, \u8bf7\u8bbe\u7f6e");
        }
        PrivateKey privateKeyInfo = RSAUtil.getPrivateKey(privateKey);
        return RSAUtil.signByPrivate(content, privateKeyInfo, input_charset);
    }

    public static boolean verifyByKeyPath(String content, String sign, String publicKeyPath, String input_charset) {
        try {
            return RSAUtil.verify(content, sign, RSAUtil.getKey(publicKeyPath), input_charset);
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean verify(String content, String sign, String publicKey, String input_charset) {
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] encodedKey = Base64.decode(publicKey);
            PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));
            return RSAUtil.verify(content, sign, pubKey, input_charset);
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean verify(String content, String sign, PublicKey publicKey, String inputCharset) {
        try {
            Signature signature = Signature.getInstance(SIGN_ALGORITHMS);
            signature.initVerify(publicKey);
            signature.update(content.getBytes(inputCharset));
            boolean bverify = signature.verify(Base64.decode(sign));
            return bverify;
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static PrivateKey getPrivateKey(String key) throws Exception {
        byte[] keyBytes = RSAUtil.buildPKCS8Key(key);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
        return privateKey;
    }

    private static byte[] buildPKCS8Key(String privateKey) throws IOException {
        if (privateKey.contains("-----BEGIN PRIVATE KEY-----")) {
            return Base64.decode(privateKey.replaceAll("-----\\w+ PRIVATE KEY-----", ""));
        }
        if (privateKey.contains("-----BEGIN RSA PRIVATE KEY-----")) {
            byte[] innerKey = Base64.decode(privateKey.replaceAll("-----\\w+ RSA PRIVATE KEY-----", ""));
            byte[] result = new byte[innerKey.length + 26];
            System.arraycopy(Base64.decode("MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKY="), 0, result, 0, 26);
            System.arraycopy(BigInteger.valueOf(result.length - 4).toByteArray(), 0, result, 2, 2);
            System.arraycopy(BigInteger.valueOf(innerKey.length).toByteArray(), 0, result, 24, 2);
            System.arraycopy(innerKey, 0, result, 26, innerKey.length);
            return result;
        }
        return Base64.decode(privateKey);
    }

    public static String getPFXPrivateSerialNumber(String pfxPath, String password) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, UnrecoverableKeyException {
        FileInputStream fis = new FileInputStream(pfxPath);
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(fis, password.toCharArray());
        fis.close();
        Enumeration<String> enumas = ks.aliases();
        String keyAlias = null;
        X509Certificate x509Certificate = null;
        String serialNumber = null;
        if (enumas.hasMoreElements()) {
            keyAlias = enumas.nextElement();
            x509Certificate = (X509Certificate)ks.getCertificate(keyAlias);
            serialNumber = x509Certificate.getSerialNumber().toString(16);
        }
        return serialNumber;
    }

    public static KeyInfo getPFXPrivateKey(String pfxPath, String password) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, UnrecoverableKeyException {
        FileInputStream fis = new FileInputStream(pfxPath);
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(fis, password.toCharArray());
        fis.close();
        Enumeration<String> enumas = ks.aliases();
        String keyAlias = null;
        if (enumas.hasMoreElements()) {
            keyAlias = enumas.nextElement();
        }
        KeyInfo keyInfo = new KeyInfo();
        PrivateKey prikey = (PrivateKey)ks.getKey(keyAlias, password.toCharArray());
        Certificate cert = ks.getCertificate(keyAlias);
        PublicKey pubkey = cert.getPublicKey();
        keyInfo.privateKey = prikey;
        keyInfo.publicKey = pubkey;
        return keyInfo;
    }

    public static PublicKey getPublicKey(String key) throws Exception {
        if (key == null) {
            throw new Exception("\u52a0\u5bc6\u516c\u94a5\u4e3a\u7a7a, \u8bf7\u8bbe\u7f6e");
        }
        byte[] buffer = Base64.decode(key);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
        return keyFactory.generatePublic(keySpec);
    }

    public static class KeyInfo {
        PublicKey publicKey;
        PrivateKey privateKey;

        public PublicKey getPublicKey() {
            return this.publicKey;
        }

        public PrivateKey getPrivateKey() {
            return this.privateKey;
        }
    }
}

