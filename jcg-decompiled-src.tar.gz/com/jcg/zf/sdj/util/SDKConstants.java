/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.zf.sdj.util;

public class SDKConstants {
    public static final String SIGN_METHOD = "RSA";
    public static final String ENCODING = "UTF-8";
    public static final String VERSION = "3.0.4";
    public static final String EQUAL = "=";
}

