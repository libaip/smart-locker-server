/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 *  org.bouncycastle.jce.provider.BouncyCastleProvider
 */
package com.jcg.zf.sdj.util;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Security;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class SM4EnDecryptionUtil {
    public static final String ALGORITHM_NAME = "SM4";
    public static final String ALGORITHM_NAME_ECB_PADDING = "SM4/ECB/PKCS5Padding";
    public static final int DEFAULT_KEY_SIZE = 128;
    public static final String CHARSET_UTF8 = "UTF-8";
    public static final String ALGORITHM_NAME_AES_PADDING = "AES/ECB/PKCS5Padding";

    public static byte[] generateKey() throws NoSuchAlgorithmException, NoSuchProviderException {
        return SM4EnDecryptionUtil.generateKey(128);
    }

    public static byte[] generateKey(int keySize) throws NoSuchAlgorithmException, NoSuchProviderException {
        KeyGenerator kg = KeyGenerator.getInstance(ALGORITHM_NAME, "BC");
        kg.init(keySize, new SecureRandom());
        return kg.generateKey().getEncoded();
    }

    public static String encryptEcbPadding(String data, String key) {
        if (null == data || StringUtils.isBlank((CharSequence)data)) {
            return "";
        }
        try {
            if (key.length() != 16) {
                throw new RuntimeException("err key length");
            }
            Cipher cipher = SM4EnDecryptionUtil.generateEcbCipher(ALGORITHM_NAME_ECB_PADDING, 1, key.getBytes(CHARSET_UTF8));
            byte[] doFinal = cipher.doFinal(data.getBytes(CHARSET_UTF8));
            return SM4EnDecryptionUtil.parseByte2HexStr(doFinal).toLowerCase();
        }
        catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String decryptEcbPadding(String cipherText, String key) {
        if (null == cipherText || StringUtils.isBlank((CharSequence)cipherText)) {
            return "";
        }
        try {
            int length = cipherText.length();
            if (length % 32 != 0) {
                return cipherText;
            }
            if (key.length() != 16) {
                throw new RuntimeException("err key length");
            }
            Cipher cipher = SM4EnDecryptionUtil.generateEcbCipher(ALGORITHM_NAME_ECB_PADDING, 2, key.getBytes(CHARSET_UTF8));
            if (SM4EnDecryptionUtil.isLowerCase(cipherText)) {
                byte[] contentHex = SM4EnDecryptionUtil.parseHexStr2Byte(cipherText);
                byte[] doFinal = cipher.doFinal(contentHex);
                return new String(doFinal, CHARSET_UTF8);
            }
            return SM4EnDecryptionUtil.decrypt(cipherText, key);
        }
        catch (BadPaddingException e) {
            return SM4EnDecryptionUtil.decrypt(cipherText, key);
        }
        catch (Exception e) {
            e.printStackTrace();
            return cipherText;
        }
    }

    private static boolean isLowerCase(String cipherText) {
        for (int i = 0; i < cipherText.length(); ++i) {
            char c = cipherText.charAt(i);
            if (!Character.isLowerCase(c)) continue;
            return true;
        }
        return false;
    }

    public static String decrypt(String content, String password) {
        if (content == null || "".equals(content)) {
            return "";
        }
        try {
            int e = content.length();
            if (e % 32 != 0) {
                return content;
            }
            byte[] contentHex = SM4EnDecryptionUtil.parseHexStr2Byte(content);
            if (null == contentHex) {
                return "";
            }
            SecretKeySpec key = new SecretKeySpec(password.getBytes(CHARSET_UTF8), "AES");
            Cipher cipher = Cipher.getInstance(ALGORITHM_NAME_AES_PADDING);
            cipher.init(2, key);
            byte[] result = cipher.doFinal(contentHex);
            return new String(result, CHARSET_UTF8);
        }
        catch (Exception e) {
            e.printStackTrace();
            return content;
        }
    }

    private static Cipher generateEcbCipher(String algorithmName, int mode, byte[] key) throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException {
        Cipher cipher = Cipher.getInstance(algorithmName, "BC");
        SecretKeySpec sm4Key = new SecretKeySpec(key, ALGORITHM_NAME);
        cipher.init(mode, sm4Key);
        return cipher;
    }

    private static String parseByte2HexStr(byte[] buf) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < buf.length; ++i) {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }

    private static byte[] parseHexStr2Byte(String hexStr) {
        if (hexStr.length() < 1) {
            return null;
        }
        if (hexStr.length() % 2 != 0) {
            return null;
        }
        byte[] result = new byte[hexStr.length() / 2];
        for (int i = 0; i < hexStr.length() / 2; ++i) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte)(high * 16 + low);
        }
        return result;
    }

    public static void main(String[] args) throws Exception {
        String content = "0ff7919aa4874241d1b767a51ec5efa795ae752aa80e7def0942715304518337";
        String password = "3r85t4jgvwm9q5tw";
        System.err.println(SM4EnDecryptionUtil.decryptEcbPadding(content, password));
    }

    static {
        if (Security.getProvider("BC") == null) {
            Security.addProvider((Provider)new BouncyCastleProvider());
        }
    }
}

