/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.http.client.utils.URIBuilder
 */
package com.jcg.zf.sdj.util;

import com.jcg.zf.sdj.util.UtilString;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;
import org.apache.http.client.utils.URIBuilder;

public class UtilHttp {
    public static URI toURI(String url, Map<String, Object> params) throws IllegalArgumentException {
        try {
            URIBuilder builder = new URIBuilder(url);
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                builder.addParameter(entry.getKey(), UtilString.toString(entry.getValue(), ""));
            }
            return builder.build();
        }
        catch (URISyntaxException e) {
            throw new IllegalArgumentException(e);
        }
    }
}

