/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.StringUtils
 */
package com.jcg.zf.sdj.util;

import com.jcg.zf.sdj.util.PropertiesUtils;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.apache.commons.lang3.StringUtils;

public class UtilProperties {
    private static Properties properties = new Properties();
    private static String propName = "app.properties";

    public static String getPropertiesValue(String propFileName, String propertiesKey) {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        try {
            if (propFileName == null) {
                propFileName = propName;
            }
            InputStream config = cl.getResourceAsStream(propName);
            properties.load(config);
            config.close();
            String value = properties.getProperty(propertiesKey);
            if (StringUtils.isBlank((CharSequence)value)) {
                if (propertiesKey.equals("merchantNo")) {
                    value = PropertiesUtils.getConfig("sdj-merchant-api.config.merchantNo");
                } else if (propertiesKey.equals("merchantKey")) {
                    value = PropertiesUtils.getConfig("sdj-merchant-api.config.merchantKey");
                }
            }
            return value;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getPropertiesValue(String propertiesKey) {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        try {
            InputStream config = cl.getResourceAsStream(propName);
            properties.load(config);
            config.close();
            return properties.getProperty(propertiesKey);
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}

