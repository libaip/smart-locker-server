/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.thoughtworks.xstream.annotations.XStreamAlias
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package com.jcg.zf.wx;

import com.jcg.zf.wx.MD5;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Signature {
    private static final Logger L = LoggerFactory.getLogger(Signature.class);

    public static String getSign(String key, Object o) throws IllegalAccessException {
        Field[] fields;
        ArrayList<String> list = new ArrayList<String>();
        Class<?> cls = o.getClass();
        for (Field f : fields = cls.getDeclaredFields()) {
            f.setAccessible(true);
            if (f.get(o) == null || f.get(o) == "") continue;
            String name = f.getName();
            XStreamAlias anno = f.getAnnotation(XStreamAlias.class);
            if (anno != null) {
                name = anno.value();
            }
            list.add(name + "=" + f.get(o) + "&");
        }
        int size = list.size();
        String[] arrayToSort = list.toArray(new String[size]);
        Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; ++i) {
            sb.append(arrayToSort[i]);
        }
        String result = sb.toString();
        result = result + "key=" + key;
        System.out.println("\u7b7e\u540d\u6570\u636e\uff1a" + result);
        L.info("\u7b7e\u540d\u6570\u636e\uff1a" + result);
        result = MD5.MD5Encode(result).toUpperCase();
        return result;
    }

    public static String getSign(String key, Map<String, Object> map) {
        ArrayList<String> list = new ArrayList<String>();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (entry.getValue() == "") continue;
            list.add(entry.getKey() + "=" + entry.getValue() + "&");
        }
        int size = list.size();
        String[] arrayToSort = list.toArray(new String[size]);
        Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; ++i) {
            sb.append(arrayToSort[i]);
        }
        String result = sb.toString();
        result = result + "key=" + key;
        result = MD5.MD5Encode(result).toUpperCase();
        return result;
    }
}

