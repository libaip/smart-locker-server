/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.zf.wx;

import java.util.UUID;

public class UUidUtils {
    public static String getUUid() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public static void main(String[] args) {
        String id = UUidUtils.getUUid();
        System.out.println(id);
    }
}

