/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.thoughtworks.xstream.XStream
 *  com.thoughtworks.xstream.io.HierarchicalStreamDriver
 *  com.thoughtworks.xstream.io.naming.NameCoder
 *  com.thoughtworks.xstream.io.xml.DomDriver
 *  com.thoughtworks.xstream.io.xml.XmlFriendlyNameCoder
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.config.RequestConfig
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.conn.socket.LayeredConnectionSocketFactory
 *  org.apache.http.conn.ssl.SSLConnectionSocketFactory
 *  org.apache.http.conn.ssl.SSLContexts
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 *  org.apache.http.util.EntityUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.beans.factory.annotation.Qualifier
 *  org.springframework.stereotype.Component
 */
package com.jcg.zf.wx;

import com.jcg.company.model.Tb_wx_pay_info;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.HierarchicalStreamDriver;
import com.thoughtworks.xstream.io.naming.NameCoder;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.thoughtworks.xstream.io.xml.XmlFriendlyNameCoder;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.Map;
import javax.net.ssl.SSLContext;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class WXWithdrawTools {
    @Autowired
    @Qualifier(value="requestConfig")
    private RequestConfig requestConfig;
    private static CloseableHttpClient httpClient;
    private static Map<String, CloseableHttpClient> httpClinet_map;
    Logger log = LoggerFactory.getLogger(WXWithdrawTools.class);
    public static final String GET_PUBLIC_KEY_URL = "https://fraud.mch.weixin.qq.com/risk/getpublickey";
    public static final String WITHDRAW = "https://api.mch.weixin.qq.com/mmpaysptrans/pay_bank";
    public static final String QYPAY_LQ = "https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers";

    public String getXMLStringForObj(Object obj) {
        XStream xStreamForRequestPostData = new XStream((HierarchicalStreamDriver)new DomDriver("UTF-8", (NameCoder)new XmlFriendlyNameCoder("-_", "_")));
        xStreamForRequestPostData.alias("xml", obj.getClass());
        xStreamForRequestPostData.processAnnotations(obj.getClass());
        return xStreamForRequestPostData.toXML(obj);
    }

    public <T> T changeXMLToOj(String XmlDoc, Class c) {
        XStream xStream = new XStream();
        xStream.alias("xml", c);
        Object returnInfo = null;
        try {
            returnInfo = xStream.fromXML(XmlDoc);
        }
        catch (ClassCastException e) {
            e.printStackTrace();
            this.log.info(e.toString());
        }
        return (T)returnInfo;
    }

    public String postParamesForUrl(String XmlObj, String url, Tb_wx_pay_info info) throws IOException {
        try {
            WXWithdrawTools.initCert(info);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        HttpPost post = new HttpPost(url);
        post.setConfig(this.requestConfig);
        StringEntity postEntity = new StringEntity(XmlObj, "UTF-8");
        post.addHeader("Content-Type", "text/xml");
        post.setEntity((HttpEntity)postEntity);
        String result = null;
        try (CloseableHttpResponse response = httpClient.execute((HttpUriRequest)post);){
            if (response.getStatusLine().getStatusCode() == 200) {
                HttpEntity entity = response.getEntity();
                result = EntityUtils.toString((HttpEntity)entity, (String)"UTF-8");
                EntityUtils.consume((HttpEntity)entity);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            this.log.info("\u5931\u8d25--------------{}", (Object)e.toString());
        }
        this.log.info("===============================key=={}", result);
        return result;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static CloseableHttpClient initCert(Tb_wx_pay_info info) throws Exception {
        httpClient = httpClinet_map.get(info.getSub_mchid());
        if (httpClient == null) {
            String key = info.getSub_mchid();
            String path = info.getSr_key_path() + info.getSub_mchid() + "/apiclient_cert.p12";
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            try (FileInputStream instream = new FileInputStream(new File(path));){
                keyStore.load(instream, key.toCharArray());
            }
            SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(keyStore, key.toCharArray()).build();
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[]{"TLSv1"}, null, SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
            httpClient = HttpClients.custom().setSSLSocketFactory((LayeredConnectionSocketFactory)sslsf).build();
            httpClinet_map.put(info.getSub_mchid(), httpClient);
        }
        return httpClient;
    }

    static {
        httpClinet_map = new HashMap<String, CloseableHttpClient>();
    }
}

