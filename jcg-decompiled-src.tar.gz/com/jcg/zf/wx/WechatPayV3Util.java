/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.codec.binary.Base64
 *  org.springframework.util.StringUtils
 */
package com.jcg.zf.wx;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Random;
import org.apache.commons.codec.binary.Base64;
import org.springframework.util.StringUtils;

public class WechatPayV3Util {
    public static String getToken(String method, String canonicalUrl, String body, String merchantId, String certSerialNo, String keyPath) throws Exception {
        String signStr = "";
        String nonceStr = WechatPayV3Util.getRandomString(32);
        long timestamp = System.currentTimeMillis() / 1000L;
        if (StringUtils.isEmpty((Object)body)) {
            body = "";
        }
        String message = WechatPayV3Util.buildMessage(method, canonicalUrl, timestamp, nonceStr, body);
        String signature = WechatPayV3Util.sign(message.getBytes("utf-8"), keyPath);
        signStr = "mchid=\"" + merchantId + "\",timestamp=\"" + timestamp + "\",nonce_str=\"" + nonceStr + "\",serial_no=\"" + certSerialNo + "\",signature=\"" + signature + "\"";
        return signStr;
    }

    public static String buildMessage(String method, String canonicalUrl, long timestamp, String nonceStr, String body) {
        return method + "\n" + canonicalUrl + "\n" + timestamp + "\n" + nonceStr + "\n" + body + "\n";
    }

    public static String sign(byte[] message, String keyPath) throws Exception {
        Signature sign = Signature.getInstance("SHA256withRSA");
        sign.initSign(WechatPayV3Util.getPrivateKey(keyPath));
        sign.update(message);
        return Base64.encodeBase64String((byte[])sign.sign());
    }

    public static PrivateKey getPrivateKey(String filename) throws IOException {
        String content = new String(Files.readAllBytes(Paths.get(filename, new String[0])), "utf-8");
        try {
            String privateKey = content.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "").replaceAll("\\s+", "");
            KeyFactory kf = KeyFactory.getInstance("RSA");
            return kf.generatePrivate(new PKCS8EncodedKeySpec(Base64.decodeBase64((String)privateKey)));
        }
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("\u5f53\u524dJava\u73af\u5883\u4e0d\u652f\u6301RSA", e);
        }
        catch (InvalidKeySpecException e) {
            throw new RuntimeException("\u65e0\u6548\u7684\u5bc6\u94a5\u683c\u5f0f");
        }
    }

    public static String getRandomString(int length) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; ++i) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }
}

