/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.thoughtworks.xstream.annotations.XStreamAlias
 */
package com.jcg.zf.wx;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias(value="xml")
public class WithdrawInfo {
    private Integer amount;
    private String bank_code;
    private String desc;
    @XStreamAlias(value="enc_bank_no")
    private String encBankNo;
    @XStreamAlias(value="enc_true_name")
    private String encTrueName;
    @XStreamAlias(value="mch_id")
    private String mch_id;
    @XStreamAlias(value="nonce_str")
    private String nonce_str;
    @XStreamAlias(value="partner_trade_no")
    private String partner_trade_no;
    private String sign;
    private String sign_type;

    public String getBank_code() {
        return this.bank_code;
    }

    public void setBank_code(String bank_code) {
        this.bank_code = bank_code;
    }

    public String getMch_id() {
        return this.mch_id;
    }

    public void setMch_id(String mch_id) {
        this.mch_id = mch_id;
    }

    public String getPartner_trade_no() {
        return this.partner_trade_no;
    }

    public void setPartner_trade_no(String partner_trade_no) {
        this.partner_trade_no = partner_trade_no;
    }

    public String getNonce_str() {
        return this.nonce_str;
    }

    public void setNonce_str(String nonce_str) {
        this.nonce_str = nonce_str;
    }

    public String getSign() {
        return this.sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getEncBankNo() {
        return this.encBankNo;
    }

    public void setEncBankNo(String encBankNo) {
        this.encBankNo = encBankNo;
    }

    public String getEncTrueName() {
        return this.encTrueName;
    }

    public void setEncTrueName(String encTrueName) {
        this.encTrueName = encTrueName;
    }

    public Integer getAmount() {
        return this.amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public String getDesc() {
        return this.desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getSign_type() {
        return this.sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }
}

