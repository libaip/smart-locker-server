/*
 * Decompiled with CFR 0.152.
 */
package com.jcg.zf.wx;

public class WithdrawResult {
    private String return_code;
    private String return_msg;
    private String result_code;
    private String err_code;
    private String err_code_des;
    private String mch_id;
    private String pub_key;
    private String partner_trade_no;
    private String payment_no;
    private String cmms_amt;
    private String nonce_str;
    private int amount;

    public String getNonce_str() {
        return this.nonce_str;
    }

    public void setNonce_str(String nonce_str) {
        this.nonce_str = nonce_str;
    }

    public String toString() {
        return "WithdrawResult{return_code='" + this.return_code + '\'' + ", return_msg='" + this.return_msg + '\'' + ", result_code='" + this.result_code + '\'' + ", err_code='" + this.err_code + '\'' + ", err_code_des='" + this.err_code_des + '\'' + ", mch_id='" + this.mch_id + '\'' + ", pub_key='" + this.pub_key + '\'' + ", partner_trade_no='" + this.partner_trade_no + '\'' + ", payment_no='" + this.payment_no + '\'' + ", cmms_amt='" + this.cmms_amt + '\'' + ", amount=" + this.amount + '}';
    }

    public String getReturn_code() {
        return this.return_code;
    }

    public void setReturn_code(String return_code) {
        this.return_code = return_code;
    }

    public String getReturn_msg() {
        return this.return_msg;
    }

    public void setReturn_msg(String return_msg) {
        this.return_msg = return_msg;
    }

    public String getResult_code() {
        return this.result_code;
    }

    public void setResult_code(String result_code) {
        this.result_code = result_code;
    }

    public String getErr_code() {
        return this.err_code;
    }

    public void setErr_code(String err_code) {
        this.err_code = err_code;
    }

    public String getErr_code_des() {
        return this.err_code_des;
    }

    public void setErr_code_des(String err_code_des) {
        this.err_code_des = err_code_des;
    }

    public String getMch_id() {
        return this.mch_id;
    }

    public void setMch_id(String mch_id) {
        this.mch_id = mch_id;
    }

    public String getPub_key() {
        return this.pub_key;
    }

    public void setPub_key(String pub_key) {
        this.pub_key = pub_key;
    }

    public String getPartner_trade_no() {
        return this.partner_trade_no;
    }

    public void setPartner_trade_no(String partner_trade_no) {
        this.partner_trade_no = partner_trade_no;
    }

    public String getPayment_no() {
        return this.payment_no;
    }

    public void setPayment_no(String payment_no) {
        this.payment_no = payment_no;
    }

    public String getCmms_amt() {
        return this.cmms_amt;
    }

    public void setCmms_amt(String cmms_amt) {
        this.cmms_amt = cmms_amt;
    }

    public int getAmount() {
        return this.amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}

