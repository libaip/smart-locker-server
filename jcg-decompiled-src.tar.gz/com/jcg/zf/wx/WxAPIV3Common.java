/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.user.model.Tb_user
 *  com.wechat.pay.contrib.apache.httpclient.Credentials
 *  com.wechat.pay.contrib.apache.httpclient.Validator
 *  com.wechat.pay.contrib.apache.httpclient.WechatPayHttpClientBuilder
 *  com.wechat.pay.contrib.apache.httpclient.auth.AutoUpdateCertificatesVerifier
 *  com.wechat.pay.contrib.apache.httpclient.auth.PrivateKeySigner
 *  com.wechat.pay.contrib.apache.httpclient.auth.Signer
 *  com.wechat.pay.contrib.apache.httpclient.auth.Verifier
 *  com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Credentials
 *  com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Validator
 *  com.wechat.pay.contrib.apache.httpclient.util.PemUtil
 *  net.sf.json.JSONArray
 *  net.sf.json.JSONObject
 *  org.apache.commons.codec.binary.Base64
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.client.utils.URIBuilder
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 *  org.apache.http.util.EntityUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jcg.zf.wx;

import com.jcg.agent.model.Tb_agent;
import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.company.serviceimpl.CompanyServiceImpl;
import com.jcg.user.model.Tb_user;
import com.jcg.zf.wx.WechatPayV3Util;
import com.wechat.pay.contrib.apache.httpclient.Credentials;
import com.wechat.pay.contrib.apache.httpclient.Validator;
import com.wechat.pay.contrib.apache.httpclient.WechatPayHttpClientBuilder;
import com.wechat.pay.contrib.apache.httpclient.auth.AutoUpdateCertificatesVerifier;
import com.wechat.pay.contrib.apache.httpclient.auth.PrivateKeySigner;
import com.wechat.pay.contrib.apache.httpclient.auth.Signer;
import com.wechat.pay.contrib.apache.httpclient.auth.Verifier;
import com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Credentials;
import com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Validator;
import com.wechat.pay.contrib.apache.httpclient.util.PemUtil;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WxAPIV3Common
extends BaseService
implements GenericCaller {
    private static CloseableHttpClient httpClient;
    private static Map<String, CloseableHttpClient> httpClinet_map;
    @Autowired
    private CompanyServiceImpl companyService;

    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        return null;
    }

    private static void initCert(Tb_wx_pay_info info) throws Exception {
        httpClient = httpClinet_map.get(info.getSub_mchid());
        if (httpClient == null) {
            String privateKey = WxAPIV3Common.readLocalPrivateKey(info);
            PrivateKey merchantPrivateKey = PemUtil.loadPrivateKey((InputStream)new ByteArrayInputStream(privateKey.getBytes(XcbConstantValue.ENCODING_UTF8)));
            AutoUpdateCertificatesVerifier verifier = new AutoUpdateCertificatesVerifier((Credentials)new WechatPay2Credentials(info.getSub_mchid(), (Signer)new PrivateKeySigner(info.getSub_service_serialno(), merchantPrivateKey)), info.getSub_merkey_v3().getBytes(XcbConstantValue.ENCODING_UTF8));
            httpClient = WechatPayHttpClientBuilder.create().withMerchant(info.getSub_mchid(), info.getSub_service_serialno(), merchantPrivateKey).withValidator((Validator)new WechatPay2Validator((Verifier)verifier)).build();
            httpClinet_map.put(info.getSub_mchid(), httpClient);
        }
    }

    public static String readLocalPrivateKey(Tb_wx_pay_info info) throws IOException {
        String keyPath = info.getSr_key_path() + info.getSub_mchid() + "/apiclient_key.pem";
        File file = new File(keyPath);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        return sb.toString();
    }

    public Tb_company getCompany(String sw_company_id, String sr_wx_mer_id) throws Exception {
        Tb_company company = new Tb_company();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)sr_wx_mer_id)) {
                Map<String, Object> dataMap = this.companyService.findCompanyByMerId(sr_wx_mer_id);
                company = (Tb_company)dataMap.get(XcbConstantValue.DATA);
            } else {
                Map<String, Object> dataMap = this.companyService.findCompanyPayIn(sw_company_id);
                company = (Tb_company)dataMap.get(XcbConstantValue.DATA);
            }
        }
        catch (Exception e) {
            this.log.error(PromptProperties.getProperty("company.find.error", sw_company_id));
            throw new Exception(e);
        }
        return company;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Map<String, Object> xcrefund(Identifier identifier, String out_trade_no, String transaction_id, String sd_cash_id, int total_fee, int refund_fee, Tb_wx_pay_info info) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String result = "";
        try {
            WxAPIV3Common.initCert(info);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        String url = XcbConstantValue.wx_apiv3_refund_url;
        URIBuilder uriBuilder = new URIBuilder(url);
        HashMap<String, Object> amountMap = new HashMap<String, Object>();
        amountMap.put("refund", refund_fee);
        amountMap.put("total", total_fee);
        amountMap.put("currency", "CNY");
        JSONObject amount = JSONObject.fromObject(amountMap);
        String notify_url = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/refundNotify";
        HashMap<String, String> dataMap = new HashMap<String, String>();
        dataMap.put("transaction_id", transaction_id);
        dataMap.put("out_refund_no", sd_cash_id);
        dataMap.put("reason", info.getSr_refund_desc());
        dataMap.put("notify_url", notify_url);
        dataMap.put("amount", (String)amount);
        String reqdata = JSONObject.fromObject(dataMap).toString();
        CloseableHttpResponse response = null;
        try {
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, Charset.forName("UTF-8"));
            entity.setContentType("application/json;charset=utf-8");
            httpPost.addHeader("Content-type", "application/json; charset=utf-8");
            httpPost.setHeader("Accept", "application/json");
            httpPost.setEntity((HttpEntity)entity);
            response = httpClient.execute((HttpUriRequest)httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("success,return body = " + result);
                result = "\u9000\u6b3e\u6210\u529f";
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else if (statusCode == 204) {
                result = "\u9000\u6b3e\u6210\u529f";
                this.log.info("success");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("failed,resp code = " + statusCode + ",return body = " + result);
                JSONObject jsonObj = JSONObject.fromObject((Object)result);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, jsonObj.getString("message"));
            }
        }
        catch (Exception e) {
            this.log.error("\u5fae\u4fe1\u652f\u4ed8\u9000\u6b3eV3 \u5f02\u5e38\u539f\u56e0 : ", (Object)e.getMessage());
            this.log.error("\u5fae\u4fe1\u652f\u4ed8\u9000\u6b3eV3 \u8bf7\u6c42url={}\u5f02\u5e38 ", (Object)uriBuilder.build());
        }
        finally {
            if (null != response) {
                response.close();
            }
        }
        return ret;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Map<String, Object> wx_pay(Tb_wx_pay_info info, int zf_money_fen, Tb_agent agent, String cash_trade_no) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        CloseableHttpClient httpclient = HttpClients.createDefault();
        String result = "";
        String publicPath = info.getSr_key_path() + info.getSub_mchid() + "/public.pem";
        String keyPath = info.getSr_key_path() + info.getSub_mchid() + "/apiclient_key.pem";
        String url = XcbConstantValue.wx_apiv3_sjdk;
        URIBuilder uriBuilder = new URIBuilder(url);
        String out_batch_no = CommonFunction.getVoucherNum((String)CommonFunction.wx_tx);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u5546\u5bb6\u6253\u6b3e\u5230\u96f6\u94b1 \u5546\u5bb6\u6279\u6b21\u5355\u53f7:" + out_batch_no);
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        dataMap.put("appid", info.getSr_wx_gzh_appid());
        dataMap.put("out_batch_no", out_batch_no);
        dataMap.put("batch_name", info.getSr_batch_name());
        dataMap.put("batch_remark", info.getSr_batch_remark());
        dataMap.put("total_amount", zf_money_fen);
        dataMap.put("total_num", 1);
        X509Certificate cert = WxAPIV3Common.getCertificate(publicPath);
        String actname = WxAPIV3Common.rsaEncryptOAEP(agent.getSr_wx_actname(), cert);
        JSONArray jsonArr = new JSONArray();
        HashMap<String, Object> detailMap = new HashMap<String, Object>();
        detailMap.put("out_detail_no", cash_trade_no);
        detailMap.put("transfer_amount", zf_money_fen);
        detailMap.put("transfer_remark", info.getSr_payment_desc());
        detailMap.put("openid", agent.getSr_open_id());
        detailMap.put("user_name", actname);
        JSONObject detailJson = new JSONObject();
        detailJson = JSONObject.fromObject(detailMap);
        jsonArr.add((Object)detailJson);
        dataMap.put("transfer_detail_list", jsonArr);
        String reqdata = JSONObject.fromObject(dataMap).toString();
        String strToken = WechatPayV3Util.getToken("POST", "/v3/transfer/batches", reqdata, info.getSub_mchid(), info.getSub_service_serialno(), keyPath);
        CloseableHttpResponse response = null;
        try {
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, Charset.forName("UTF-8"));
            entity.setContentType("application/json;charset=utf-8");
            httpPost.addHeader("Content-type", "application/json; charset=utf-8");
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Wechatpay-Serial", info.getSr_v3_serialno());
            httpPost.setEntity((HttpEntity)entity);
            httpPost.addHeader("Authorization", "WECHATPAY2-SHA256-RSA2048 " + strToken);
            response = httpclient.execute((HttpUriRequest)httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result = EntityUtils.toString((HttpEntity)response.getEntity(), (String)"UTF-8");
                this.log.info("success,return body = " + result);
                ret.put(XcbConstantValue.DATA, result);
                result = "\u6253\u6b3e\u6210\u529f";
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else if (statusCode == 204) {
                result = "\u6253\u6b3e\u6210\u529f";
                this.log.info("success");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("failed,resp code = " + statusCode + ",return body = " + result);
                JSONObject jsonObj = JSONObject.fromObject((Object)result);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, jsonObj.getString("message"));
            }
        }
        catch (Exception e) {
            this.log.error("\u5fae\u4fe1\u652f\u4ed8\u6253\u6b3eV3 \u8bf7\u6c42url={}\u5f02\u5e38 ", (Object)uriBuilder.build());
        }
        finally {
            if (null != response) {
                response.close();
            }
        }
        return ret;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Map<String, Object> wx_pay_user(Tb_wx_pay_info info, int zf_money_fen, Tb_user user, String cash_trade_no) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        CloseableHttpClient httpclient = HttpClients.createDefault();
        String result = "";
        String publicPath = info.getSr_key_path() + info.getSub_mchid() + "/public.pem";
        String keyPath = info.getSr_key_path() + info.getSub_mchid() + "/apiclient_key.pem";
        String url = XcbConstantValue.wx_apiv3_sjdk;
        URIBuilder uriBuilder = new URIBuilder(url);
        String out_batch_no = CommonFunction.getVoucherNum((String)CommonFunction.wx_tx);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u5546\u5bb6\u6253\u6b3e\u5230\u96f6\u94b1 \u5546\u5bb6\u6279\u6b21\u5355\u53f7:" + out_batch_no);
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        dataMap.put("appid", info.getSub_appid());
        dataMap.put("out_batch_no", out_batch_no);
        dataMap.put("batch_name", info.getSr_batch_name());
        dataMap.put("batch_remark", info.getSr_batch_remark());
        dataMap.put("total_amount", zf_money_fen);
        dataMap.put("total_num", 1);
        JSONArray jsonArr = new JSONArray();
        HashMap<String, Object> detailMap = new HashMap<String, Object>();
        detailMap.put("out_detail_no", cash_trade_no);
        detailMap.put("transfer_amount", zf_money_fen);
        detailMap.put("transfer_remark", info.getSr_payment_desc());
        detailMap.put("openid", user.getSr_open_id());
        JSONObject detailJson = new JSONObject();
        detailJson = JSONObject.fromObject(detailMap);
        jsonArr.add((Object)detailJson);
        dataMap.put("transfer_detail_list", jsonArr);
        dataMap.put("transfer_scene_id", "1001");
        String reqdata = JSONObject.fromObject(dataMap).toString();
        String strToken = WechatPayV3Util.getToken("POST", "/v3/transfer/batches", reqdata, info.getSub_mchid(), info.getSub_service_serialno(), keyPath);
        CloseableHttpResponse response = null;
        try {
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, Charset.forName("UTF-8"));
            entity.setContentType("application/json;charset=utf-8");
            httpPost.addHeader("Content-type", "application/json; charset=utf-8");
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Wechatpay-Serial", info.getSr_v3_serialno());
            httpPost.setEntity((HttpEntity)entity);
            httpPost.addHeader("Authorization", "WECHATPAY2-SHA256-RSA2048 " + strToken);
            response = httpclient.execute((HttpUriRequest)httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("success,return body = " + result);
                ret.put(XcbConstantValue.DATA, result);
                result = "\u6253\u6b3e\u6210\u529f";
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else if (statusCode == 204) {
                result = "\u6253\u6b3e\u6210\u529f";
                this.log.info("success");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("failed,resp code = " + statusCode + ",return body = " + result);
                JSONObject jsonObj = JSONObject.fromObject((Object)result);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, jsonObj.getString("message"));
            }
        }
        catch (Exception e) {
            this.log.error("\u5fae\u4fe1\u652f\u4ed8\u6253\u6b3eV3 \u8bf7\u6c42url={}\u5f02\u5e38 ", (Object)uriBuilder.build());
        }
        finally {
            if (null != response) {
                response.close();
            }
        }
        return ret;
    }

    /*
     * Exception decompiling
     */
    public static X509Certificate getCertificate(String filename) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 4 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public static String rsaEncryptOAEP(String message, X509Certificate certificate) throws IllegalBlockSizeException, IOException {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
            cipher.init(1, certificate.getPublicKey());
            byte[] data = message.getBytes("utf-8");
            byte[] cipherdata = cipher.doFinal(data);
            return Base64.getEncoder().encodeToString(cipherdata);
        }
        catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new RuntimeException("\u5f53\u524dJava\u73af\u5883\u4e0d\u652f\u6301RSA v1.5/OAEP", e);
        }
        catch (InvalidKeyException e) {
            throw new IllegalArgumentException("\u65e0\u6548\u7684\u8bc1\u4e66", e);
        }
        catch (BadPaddingException | IllegalBlockSizeException e) {
            throw new IllegalBlockSizeException("\u52a0\u5bc6\u539f\u4e32\u7684\u957f\u5ea6\u4e0d\u80fd\u8d85\u8fc7214\u5b57\u8282");
        }
    }

    public static String buildMessage(String method, String canonicalUrl, long timestamp, String nonceStr, String body) {
        return method + "\n" + canonicalUrl + "\n" + timestamp + "\n" + nonceStr + "\n" + body + "\n";
    }

    public static String sign(byte[] message, String keyPath) throws Exception {
        Signature sign = Signature.getInstance("SHA256withRSA");
        sign.initSign(WxAPIV3Common.getPrivateKey(keyPath));
        sign.update(message);
        return org.apache.commons.codec.binary.Base64.encodeBase64String((byte[])sign.sign());
    }

    public static PrivateKey getPrivateKey(String filename) throws IOException {
        String content = new String(Files.readAllBytes(Paths.get(filename, new String[0])), "utf-8");
        try {
            String privateKey = content.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "").replaceAll("\\s+", "");
            KeyFactory kf = KeyFactory.getInstance("RSA");
            return kf.generatePrivate(new PKCS8EncodedKeySpec(org.apache.commons.codec.binary.Base64.decodeBase64((String)privateKey)));
        }
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("\u5f53\u524dJava\u73af\u5883\u4e0d\u652f\u6301RSA", e);
        }
        catch (InvalidKeySpecException e) {
            throw new RuntimeException("\u65e0\u6548\u7684\u5bc6\u94a5\u683c\u5f0f");
        }
    }

    public static String getRandomString(int length) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; ++i) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }

    static {
        httpClinet_map = new HashMap<String, CloseableHttpClient>();
    }
}

