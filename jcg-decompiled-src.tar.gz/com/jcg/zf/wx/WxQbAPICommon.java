/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_order_goods
 *  com.jcg.company.model.Tb_wx_pay_info
 *  net.sf.json.JSONObject
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jcg.zf.wx;

import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.model.Tb_device_package;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.BaseService;
import com.jcg.common.RedisUtil;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.zf.qb.util.QBUtils;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WxQbAPICommon
extends BaseService
implements GenericCaller {
    public static String DevPrivateKey = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCF/oTSk9A3xVmdY5mdubt7Y7s9GSpT4UkLYrNGZuXiiWByu4KZdz4p3iceUVM3hNKbSwGa5dGSqSXk9WDrHO26Rnwjhukzp1tCGcqzcTf0msvVPyglEuBDNtC+Ihp2X4OP7V5dCq1RamTdWD//9yYdYL6pxE1TcWCVdvnRfx229Mg6Ec/HjueJExSPhgV+DLkJSEzfIqqhqVqF6a/RDQHiWXfjD64q3DSmGhGXGLkGbSLwx30teDW2R2KjzSH/kCrxyFiflNrbbd8qdgfwgXqAUuQL+t3ld3a73RjjdXdklgsTxjVnDhpKOj2J8Y2FavPJwjy4dTKHEYYEpzMWyEGjAgMBAAECggEACYxPbqn1xmObtSlpwuF/SJWcvAfVClEdYWBRIg0nCHN9me9eqQzkMxuPcgudgHFIiKRZou4JdwfymVQa6eYP0pw/MFDmwTWFvToVRaAlupplN/beJ3Ym4ONBEKthc1nvCAyEEuE15H1OXq9xMA4uex1vuK0yTWXg2gW2W4VRWr4O2XnRwGiwqU/Pdxv7C7D5HDVFaRh+0cmOFt4gC6dzV8xkig/M2EmSh8fD0FUan7+VupCEOwfclTlDCmraCh/2U1615EwY7HiQl6BnkUpaxcHgrm6zUVfHe0vjW23CUmhka1piPx0Qv9Bv2sSU6spkZJFM4q3nWdraai01H78IMQKBgQD/Y1lWKFsYw3bF+XkZhdOLKoGYEoYyRG3MdMTz4Q9pAJunlNjn7VEbyDOtebg7lSXuKpufRKxNciQHiIpMCNxWpZX4e8ivu7rSYqdGvHuWtd3RF2Q/fHiVfhpzywOsExf5G16ArbCqdIR4kM7ff7jLMwJDmYiQQ+DztXXazBLwTwKBgQCGULVyl7kQ/fAGuWI1xcovAu9m8AdesaG+EHlSsvN0vjvgZahOu34BcK+0ePt2fRt9dF6Vrx94mOUtg/gmDdXmwMrrbpHig38GMRz4JcZMKH1FzzyC/69ZO9JJei25VDG33Q/Mwwz4uM+NUlrwtx/y7JyXN4yXT+V0wsUQGV0QbQKBgQDWZ6Xcu0yfYZoZYvPUBZIvx6O88/BNyz0S5QVkaZHyaVxEOKZRL99kH5OjFAkjnHeXl5XHBHRTIHw3Bt50Lwwsgh+B2QoG3uhdMA2XSS3IvS5YF/dFhU4G0zOJ+uo+UFlT/TI9fZRPxjpgrdG/uQ5/KXfBIOiRlSsJ71HeOm276QKBgCmfVytEszf9yWT8C+AoA+ifmzqmBVKl7z5r8nzbMbCqxvlZ51dGqNyfZAOkPiDQ0jUFW8487566msKJE9wPC4svkXJ12EV+hF2R2K1ZX2L4ZSG9/72EqH0ZmaflccftvF6C5cOJajqlYsQjkkToKsFn63q83xeAzdVqChFcGsfdAoGBALPxgq3ZlD83ZTFZwB/XTAss9E0U1wJdFDXjcQRNZO09+orRgcwLNoLHD2X3G0WDhxqNKTLsXNVAm3kuCdR4CK5RayTKrtb2ZKRhmQkHgeLXkB1w3Zjv/GMUv/UbkxFRCG8g5fgjtO1A0csc5UeZI9tRLHJUwEVTj49S8G0DaJSU";
    public static String DevPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhf6E0pPQN8VZnWOZnbm7e2O7PRkqU+FJC2KzRmbl4olgcruCmXc+Kd4nHlFTN4TSm0sBmuXRkqkl5PVg6xztukZ8I4bpM6dbQhnKs3E39JrL1T8oJRLgQzbQviIadl+Dj+1eXQqtUWpk3Vg///cmHWC+qcRNU3FglXb50X8dtvTIOhHPx47niRMUj4YFfgy5CUhM3yKqoalahemv0Q0B4ll34w+uKtw0phoRlxi5Bm0i8Md9LXg1tkdio80h/5Aq8chYn5Ta223fKnYH8IF6gFLkC/rd5Xd2u90Y43V3ZJYLE8Y1Zw4aSjo9ifGNhWrzycI8uHUyhxGGBKczFshBowIDAQAB";
    public static String QBPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnbDrCnkRIHHshcrAvku/A38t/flp8PKCOvmFuEVSh1a0phbpuXn+zDoLdtWfkod5t8+zjsy2Z5TriHfv4Icu+CXEKiTQRLmSvYh7MJ7rTUDsVy3Q469jRydwvKBAMe8xl/vSlMo/D9IOeQjdI9XO5OkgZqhhNNV4jt+C6sdGyl/NeryTy2uaX8IBc6xfcfssoFfkw2RpmX/SSu8br97iCOkx4NTN6bqGFLw+LF9nxVtvBP9Xmfg0NDTxQDczIz2Y6nF6nvXA+9QSQnRBwrFvxc/HYISX0zpJHcBcY3jidz01Nm5/6bCSscK8TVviRx9XEVi0Ar9Dzf4rsYuS341tyQIDAQAB";
    @Autowired
    private DeviceDao deviceDao;
    @Autowired
    private DeviceBoxDao deviceBoxDao;
    @Autowired
    private RedisUtil redis;

    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        if (param != null) {
            // empty if block
        }
        try {
            if (XcbConstantValue.WX_QB_USER_ORDER_PAY.equalsIgnoreCase(functionCode)) {
                Tb_order order = (Tb_order)param.get("order");
                Tb_device_package devicePackage = (Tb_device_package)param.get("devicePackage");
                Tb_wx_pay_info info = (Tb_wx_pay_info)param.get("info");
                int totalMoney = XcbStringUtils.getObjtoint((Object)param.get("totalMoney"));
                String sr_open_id = XcbStringUtils.getObjtoString((Object)param.get("sr_open_id"));
                String cus_ip = XcbStringUtils.getObjtoString((Object)param.get("cus_ip"));
                ret = this.createPayOrder(identifier, order, devicePackage, totalMoney, sr_open_id, info, cus_ip);
            } else if (XcbConstantValue.WX_QB_USER_ORDER_GOODS_PAY.equalsIgnoreCase(functionCode)) {
                Tb_order_goods order = (Tb_order_goods)param.get("order");
                Tb_wx_pay_info info = (Tb_wx_pay_info)param.get("info");
                int totalMoney = XcbStringUtils.getObjtoint((Object)param.get("totalMoney"));
                String sr_open_id = XcbStringUtils.getObjtoString((Object)param.get("sr_open_id"));
                String cus_ip = XcbStringUtils.getObjtoString((Object)param.get("cus_ip"));
                ret = this.createPayOrderGoods(identifier, order, totalMoney, sr_open_id, info, cus_ip);
            } else if (XcbConstantValue.WX_QB_USER_ORDER_TEMP_PAY.equalsIgnoreCase(functionCode)) {
                Tb_order order = (Tb_order)param.get("order");
                Tb_wx_pay_info info = (Tb_wx_pay_info)param.get("info");
                int totalMoney = XcbStringUtils.getObjtoint((Object)param.get("totalMoney"));
                String sr_open_id = XcbStringUtils.getObjtoString((Object)param.get("sr_open_id"));
                String cus_ip = XcbStringUtils.getObjtoString((Object)param.get("cus_ip"));
                ret = this.temporaryOrder(order, totalMoney, sr_open_id, info, cus_ip);
            } else if (XcbConstantValue.WX_QB_USER_ORDER_FINISH_PAY.equalsIgnoreCase(functionCode)) {
                Tb_order order = (Tb_order)param.get("order");
                Tb_wx_pay_info info = (Tb_wx_pay_info)param.get("info");
                int totalMoney = XcbStringUtils.getObjtoint((Object)param.get("totalMoney"));
                String sr_open_id = XcbStringUtils.getObjtoString((Object)param.get("sr_open_id"));
                String cus_ip = XcbStringUtils.getObjtoString((Object)param.get("cus_ip"));
                ret = this.finishOrder(order, totalMoney, sr_open_id, info, cus_ip);
            }
        }
        catch (BusinessException e) {
            throw e;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    public Map<String, Object> createPayOrder(Identifier identifier, Tb_order order, Tb_device_package devicePackage, int totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        Map<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, Object> dataMap = new HashMap<String, Object>();
        try {
            String url = XcbConstantValue.qb_preOrder;
            String out_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
            String payNotify = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/payNotify";
            payNotify = "http://estsyw6e.xiaomy.net/jcgweb-user/wechatPayNotify_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/payNotify";
            BigDecimal dc_order_money = BigDecimal.ZERO;
            BigDecimal dc_deposit_money = BigDecimal.ZERO;
            if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
                dc_order_money = devicePackage.getDc_once_price();
                dc_deposit_money = devicePackage.getDc_advance_price();
            } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
                dc_order_money = devicePackage.getDc_once_price();
                dc_deposit_money = devicePackage.getDc_advance_price();
            } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
                dc_deposit_money = devicePackage.getDc_advance_price();
            }
            StringBuffer sb_attach = new StringBuffer();
            sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSw_user_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_agent_id())).append(",").append(XcbStringUtils.getObjtoString((Object)devicePackage.getSd_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_device_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_box_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_order_way())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_charging_type())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_cj_function())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_iphone_num())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_password())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_WX)).append(",").append(XcbStringUtils.getObjtoString((Object)dc_order_money)).append(",").append(XcbStringUtils.getObjtoString((Object)dc_deposit_money)).append(",").append(XcbStringUtils.getObjtoString((Object)info.getSub_mchid()));
            System.out.println("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
            this.log.info("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
            this.redis.setForTimeMIN(out_trade_no, sb_attach.toString(), 1440L);
            dataMap.put("sn", info.getSub_merkey_v2());
            dataMap.put("merchantId", info.getSub_mchid());
            dataMap.put("terminalId", info.getSp_mchid());
            dataMap.put("tradeAmount", totalMoney);
            dataMap.put("payModeId", 10036);
            dataMap.put("outTransId", out_trade_no);
            dataMap.put("notifyUrl", payNotify);
            dataMap.put("appId", info.getSub_appid());
            dataMap.put("userOpenId", sr_open_id);
            dataMap.put("clientIp", cus_ip);
            ret = this.postAndVerify(dataMap, url, info, order.getSd_order_id());
        }
        catch (Exception e) {
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return ret;
    }

    private Map<String, Object> createPayOrderGoods(Identifier identifier, Tb_order_goods order, int totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        return ret;
    }

    public Map<String, Object> temporaryOrder(Tb_order order, int totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        return ret;
    }

    public Map<String, Object> finishOrder(Tb_order order, int totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        return ret;
    }

    private Map<String, Object> postAndVerify(Map<String, Object> dataMap, String url, Tb_wx_pay_info info, String sd_order_id) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        try {
            SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String json = JSONObject.fromObject(dataMap).toString();
            String signVal = QBUtils.sign256(json, DevPrivateKey);
            HashMap<String, String> headers = new HashMap<String, String>();
            HashMap<String, String> responseHeaders = new HashMap<String, String>();
            String timestamp = sdf2.format(new Date());
            headers.put("AccessId", info.getSr_userid());
            headers.put("Timestamp", timestamp);
            headers.put("SignType", XcbConstantValue.SIGNATURE_ALGORITHM);
            headers.put("SignValue", signVal);
            String respStr = QBUtils.httpPost(url, json, headers, responseHeaders);
            System.out.println("\u7ed3\u679c\uff1a" + respStr);
            System.out.println(responseHeaders.toString());
            String sigValRsp = responseHeaders.get("SignValue");
            if (sigValRsp != null && sigValRsp.length() > 0) {
                boolean verify = QBUtils.verify256(respStr, sigValRsp, QBPublicKey);
                System.out.println("\u9a8c\u7b7e\u7ed3\u679c\uff1a" + verify);
                if (verify) {
                    JSONObject obj = JSONObject.fromObject((Object)respStr);
                    String code = obj.getString("code");
                    String msg = obj.getString("msg");
                    if ("SUCCESS".equals(code)) {
                        String result = obj.getString("result");
                        JSONObject resultMap = JSONObject.fromObject((Object)result);
                        JSONObject payInfo = JSONObject.fromObject((Object)resultMap.getString("payInfo"));
                        String appId = payInfo.getString("appId");
                        String timeStamp = payInfo.getString("timeStamp");
                        String nonceStr = payInfo.getString("nonceStr");
                        String packageStr = payInfo.getString("package");
                        String signType = payInfo.getString("signType");
                        String paySign = payInfo.getString("paySign");
                        Map<String, String> payMap = this.conPayParam(appId, timeStamp, nonceStr, packageStr, signType, paySign);
                        payMap.put("sw_order_id", sd_order_id);
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                        ret.put(XcbConstantValue.DATA, payMap);
                    } else {
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                        ret.put(XcbConstantValue.MSG, "\u4e0b\u5355\u5f02\u5e38:" + msg);
                    }
                } else {
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    ret.put(XcbConstantValue.MSG, "\u7b7e\u540d\u5f02\u5e38");
                }
            } else {
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, "\u7b7e\u540d\u5f02\u5e38");
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return ret;
    }

    public Map<String, String> conPayParam(String appid, String timeStamp, String nonceStr, String packageStr, String signType, String paySign) throws Exception {
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("appId", appid);
        map.put("timeStamp", timeStamp);
        map.put("nonceStr", nonceStr);
        map.put("package", packageStr);
        map.put("signType", signType);
        map.put("paySign", paySign);
        return map;
    }
}

