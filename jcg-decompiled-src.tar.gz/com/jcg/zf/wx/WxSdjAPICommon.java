/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alibaba.fastjson.JSON
 *  com.alibaba.fastjson.JSONObject
 *  com.jcg.agent.model.Tb_agent
 *  com.jcg.agent.model.Tb_device
 *  com.jcg.agent.model.Tb_device_box
 *  com.jcg.agent.model.Tb_device_package
 *  com.jcg.agent.model.Tb_order
 *  com.jcg.common.model.BusinessException
 *  com.jcg.common.model.CommonFunction
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbDateUtil
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_order_goods
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.jcg.webapi.model.Tb_sdj_binding
 *  com.jcg.webapi.model.Tb_sdj_bindingResp
 *  com.jcg.webapi.model.Tb_sdj_binding_terminate
 *  com.jcg.webapi.model.Tb_sdj_identity
 *  com.jcg.webapi.model.Tb_sdj_identityResp
 *  com.jcg.webapi.model.Tb_sdj_order
 *  com.jcg.webapi.model.Tb_sdj_orderPreResp
 *  com.jcg.webapi.model.Tb_sdj_orderResp
 *  com.jcg.webapi.model.Tb_sdj_pay
 *  com.jcg.webapi.model.Tb_sdj_payResp
 *  com.jcg.webapi.model.Tb_sdj_refund
 *  com.jcg.webapi.model.Tb_sdj_refundResp
 *  net.sf.json.JSONObject
 *  org.bouncycastle.jce.provider.BouncyCastleProvider
 *  org.bouncycastle.util.encoders.Hex
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jcg.zf.wx;

import com.alibaba.fastjson.JSON;
import com.jcg.agent.idao.DeviceBoxDao;
import com.jcg.agent.idao.DeviceDao;
import com.jcg.agent.model.Tb_agent;
import com.jcg.agent.model.Tb_device;
import com.jcg.agent.model.Tb_device_box;
import com.jcg.agent.model.Tb_device_package;
import com.jcg.agent.model.Tb_order;
import com.jcg.common.BaseService;
import com.jcg.common.model.BusinessException;
import com.jcg.common.model.CommonFunction;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbDateUtil;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_order_goods;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.webapi.model.Tb_sdj_binding;
import com.jcg.webapi.model.Tb_sdj_bindingResp;
import com.jcg.webapi.model.Tb_sdj_binding_terminate;
import com.jcg.webapi.model.Tb_sdj_identity;
import com.jcg.webapi.model.Tb_sdj_identityResp;
import com.jcg.webapi.model.Tb_sdj_order;
import com.jcg.webapi.model.Tb_sdj_orderPreResp;
import com.jcg.webapi.model.Tb_sdj_orderResp;
import com.jcg.webapi.model.Tb_sdj_pay;
import com.jcg.webapi.model.Tb_sdj_payResp;
import com.jcg.webapi.model.Tb_sdj_refund;
import com.jcg.webapi.model.Tb_sdj_refundResp;
import com.jcg.zf.sdj.util.APIHttpClient;
import com.jcg.zf.sdj.util.PfxCerUtil;
import com.jcg.zf.sdj.util.SDKUtil;
import com.jcg.zf.sdj.util.SM2Util;
import com.jcg.zf.sdj.util.SM4EnDecryptionUtil;
import com.jcg.zf.sdj.util.TransCode;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Security;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import net.sf.json.JSONObject;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WxSdjAPICommon
extends BaseService
implements GenericCaller {
    private static Map<String, Map<String, Object>> certMap;
    private static Map<String, Object> cert;
    @Autowired
    private DeviceDao deviceDao;
    @Autowired
    private DeviceBoxDao deviceBoxDao;

    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        if (param != null) {
            // empty if block
        }
        try {
            if (XcbConstantValue.WX_SDJ_USER_ORDER_PAY.equalsIgnoreCase(functionCode)) {
                Tb_order order = (Tb_order)param.get("order");
                Tb_device_package devicePackage = (Tb_device_package)param.get("devicePackage");
                Tb_wx_pay_info info = (Tb_wx_pay_info)param.get("info");
                String totalMoney = XcbStringUtils.getObjtoString((Object)param.get("totalMoney"));
                String sr_open_id = XcbStringUtils.getObjtoString((Object)param.get("sr_open_id"));
                String cus_ip = XcbStringUtils.getObjtoString((Object)param.get("cus_ip"));
                ret = this.createPayOrder(identifier, order, devicePackage, totalMoney, sr_open_id, info, cus_ip);
            } else if (XcbConstantValue.WX_SDJ_USER_ORDER_GOODS_PAY.equalsIgnoreCase(functionCode)) {
                Tb_order_goods order = (Tb_order_goods)param.get("order");
                Tb_wx_pay_info info = (Tb_wx_pay_info)param.get("info");
                String totalMoney = XcbStringUtils.getObjtoString((Object)param.get("totalMoney"));
                String sr_open_id = XcbStringUtils.getObjtoString((Object)param.get("sr_open_id"));
                String cus_ip = XcbStringUtils.getObjtoString((Object)param.get("cus_ip"));
                ret = this.createPayOrderGoods(identifier, order, totalMoney, sr_open_id, info, cus_ip);
            } else if (XcbConstantValue.WX_SDJ_USER_ORDER_TEMP_PAY.equalsIgnoreCase(functionCode)) {
                Tb_order order = (Tb_order)param.get("order");
                Tb_wx_pay_info info = (Tb_wx_pay_info)param.get("info");
                String totalMoney = XcbStringUtils.getObjtoString((Object)param.get("totalMoney"));
                String sr_open_id = XcbStringUtils.getObjtoString((Object)param.get("sr_open_id"));
                String cus_ip = XcbStringUtils.getObjtoString((Object)param.get("cus_ip"));
                ret = this.temporaryOrder(order, totalMoney, sr_open_id, info, cus_ip);
            } else if (XcbConstantValue.WX_SDJ_USER_ORDER_FINISH_PAY.equalsIgnoreCase(functionCode)) {
                Tb_order order = (Tb_order)param.get("order");
                Tb_wx_pay_info info = (Tb_wx_pay_info)param.get("info");
                String totalMoney = XcbStringUtils.getObjtoString((Object)param.get("totalMoney"));
                String sr_open_id = XcbStringUtils.getObjtoString((Object)param.get("sr_open_id"));
                String cus_ip = XcbStringUtils.getObjtoString((Object)param.get("cus_ip"));
                ret = this.finishOrder(order, totalMoney, sr_open_id, info, cus_ip);
            } else if (XcbConstantValue.WX_SDJ_USER_REFUND.equalsIgnoreCase(functionCode)) {
                Tb_wx_pay_info info = (Tb_wx_pay_info)param.get("info");
                String sd_cash_id = XcbStringUtils.getObjtoString((Object)param.get("sd_cash_id"));
                String out_trade_no = XcbStringUtils.getObjtoString((Object)param.get("out_trade_no"));
                String transaction_id = XcbStringUtils.getObjtoString((Object)param.get("transaction_id"));
                String total_fee = XcbStringUtils.getObjtoString((Object)param.get("total_fee"));
                String refund_fee = XcbStringUtils.getObjtoString((Object)param.get("refund_fee"));
                ret = this.xcrefund(out_trade_no, transaction_id, sd_cash_id, total_fee, refund_fee, info);
            }
        }
        catch (BusinessException e) {
            throw e;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    public static Map<String, Object> initCert(Tb_wx_pay_info info) throws Exception {
        cert = certMap.get(info.getSub_mchid());
        if (cert == null) {
            String partnerSM2Pfx = info.getSr_key_path() + info.getSub_mchid() + "/payer99_sm2.pfx";
            cert = SM2Util.getKey(partnerSM2Pfx, info.getSub_merkey_v3());
            certMap.put(info.getSub_mchid(), cert);
        }
        return cert;
    }

    public static String getPublicKeyPath(Tb_wx_pay_info info) {
        String publicKeyPath = info.getSr_key_path() + info.getSub_mchid() + "/sdj_smclient.cer";
        return publicKeyPath;
    }

    private Map<String, Object> checkSdjVerifySign(Identifier identifier, Tb_wx_pay_info info, Object result, String respSign) {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        boolean isVerifySign = false;
        try {
            if (result instanceof Tb_sdj_orderResp) {
                result = (Tb_sdj_orderResp)result;
            }
            String signObject = SDKUtil.getSignData(result, info.getSub_merkey_v2());
            String publicKeyPath = WxSdjAPICommon.getPublicKeyPath(info);
            PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
            byte[] sig1 = Hex.decode((String)respSign);
            isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.exceptionToString((Exception)e));
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        ret.put("isVerifySign", isVerifySign);
        return ret;
    }

    public Map<String, Object> createPayOrder(Identifier identifier, Tb_order order, Tb_device_package devicePackage, String totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        Map<String, Object> map = WxSdjAPICommon.initCert(info);
        String certId = info.getSub_service_serialno();
        PrivateKey privateKey = (PrivateKey)map.get("privateKey");
        String url = XcbConstantValue.sdj_payee_preOrder;
        String out_trade_no = CommonFunction.getVoucherNum((String)CommonFunction.zx_id);
        String payNotify = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/payNotify";
        BigDecimal dc_order_money = BigDecimal.ZERO;
        BigDecimal dc_deposit_money = BigDecimal.ZERO;
        if (XcbConstantValue.DEVICE_CHARGING_TYPE_ACJF.equals(order.getSr_charging_type())) {
            dc_order_money = devicePackage.getDc_once_price();
            dc_deposit_money = devicePackage.getDc_advance_price();
        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_ASJF.equals(order.getSr_charging_type())) {
            dc_order_money = devicePackage.getDc_once_price();
            dc_deposit_money = devicePackage.getDc_advance_price();
        } else if (XcbConstantValue.DEVICE_CHARGING_TYPE_MF.equals(order.getSr_charging_type())) {
            dc_deposit_money = devicePackage.getDc_advance_price();
        }
        Tb_device device = this.deviceDao.findDeviceDetailById_agent(order.getSw_device_id());
        Tb_device_box deviceBox = this.deviceBoxDao.findDeviceBoxById_user(order.getSw_box_id());
        StringBuffer sb_attach = new StringBuffer();
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSw_user_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_agent_id())).append(",").append(XcbStringUtils.getObjtoString((Object)devicePackage.getSd_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_device_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSw_box_id())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_order_way())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_charging_type())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_cj_function())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_iphone_num())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSr_password())).append(",").append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_WX)).append(",").append(XcbStringUtils.getObjtoString((Object)dc_order_money)).append(",").append(XcbStringUtils.getObjtoString((Object)dc_deposit_money)).append(",").append(XcbStringUtils.getObjtoString((Object)info.getSub_mchid()));
        System.out.println("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        dataMap = new HashMap();
        Tb_sdj_order dto = new Tb_sdj_order();
        String timestamp = System.currentTimeMillis() + "";
        dto.setVersion(info.getSr_version());
        dto.setEncoding(XcbConstantValue.ENCODING_UTF8);
        dto.setSignMethod("SM");
        dto.setMerNo(info.getSub_mchid());
        dto.setTimestamp(timestamp);
        dto.setTxnProductType("WXB2C");
        dto.setTxnTransType("PURCHASE");
        dto.setTxnTransInput("300003");
        dto.setCertId(certId);
        dto.setTxnCurrencyCode("CNY");
        dto.setTxnPayeeOrderNo(out_trade_no);
        dto.setTxnPayeeOrderTime(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd'T'HH:mm:ss"));
        dto.setTxnAmt(totalMoney);
        dto.setMerAppId(info.getSub_appid());
        dto.setMerOpenId(sr_open_id);
        String notifyUrl = Base64.getUrlEncoder().withoutPadding().encodeToString(payNotify.getBytes("utf-8"));
        String successUrl = XcbConstantValue.user_host + "/#/success?id=" + order.getSd_order_id() + "&mid=" + device.getSi_mainboard_id() + "&boardno=" + deviceBox.getSi_board_number() + "&lockno=" + deviceBox.getSi_lock_number() + "&aliasno=" + deviceBox.getSr_alias_number() + "&alias=" + device.getSr_alias() + "&type=" + device.getSr_device_type();
        String txnReturnUrl = Base64.getUrlEncoder().withoutPadding().encodeToString(successUrl.getBytes("utf-8"));
        dto.setTxnNotifyUrl(notifyUrl);
        dto.setTxnReturnUrl(txnReturnUrl);
        dto.setTxnDescription(info.getSr_body_name());
        dto.setTxnSettleType("T1");
        dto.setTxnAttach(sb_attach.toString());
        dataMap.put("version", dto.getVersion());
        dataMap.put("encoding", dto.getEncoding());
        dataMap.put("signMethod", dto.getSignMethod());
        dataMap.put("merNo", dto.getMerNo());
        dataMap.put("timestamp", dto.getTimestamp());
        dataMap.put("txnProductType", dto.getTxnProductType());
        dataMap.put("txnTransType", dto.getTxnTransType());
        dataMap.put("txnTransInput", dto.getTxnTransInput());
        dataMap.put("txnSettleType", dto.getTxnSettleType());
        dataMap.put("txnCurrencyCode", dto.getTxnCurrencyCode());
        dataMap.put("txnAmt", dto.getTxnAmt());
        dataMap.put("txnPayeeOrderNo", dto.getTxnPayeeOrderNo());
        dataMap.put("txnPayeeOrderTime", dto.getTxnPayeeOrderTime());
        dataMap.put("txnDescription", dto.getTxnDescription());
        dataMap.put("txnAttach", dto.getTxnAttach());
        dataMap.put("txnNotifyUrl", notifyUrl);
        dataMap.put("txnReturnUrl", txnReturnUrl);
        dataMap.put("merAppId", dto.getMerAppId());
        dataMap.put("merOpenId", dto.getMerOpenId());
        dataMap.put("certId", certId);
        String signString = SDKUtil.getMerSign(dto, info);
        byte[] sign = SM2Util.signSm3WithSm2(signString.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), privateKey);
        String signData = Hex.toHexString((byte[])sign);
        dto.setSignature(signData);
        dataMap.put("signature", signData);
        String reqdata = com.alibaba.fastjson.JSONObject.toJSONString(dataMap);
        System.out.println("\u8bf7\u6c42\u6570\u636e\uff1a" + reqdata);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
        String respResult = APIHttpClient.getInstance().post(reqdata, url);
        this.log.info("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
        System.out.println("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
        if (!XcbStringUtils.isNullOrBlank((Object)respResult)) {
            com.alibaba.fastjson.JSONObject jsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
            Tb_sdj_orderPreResp resp = (Tb_sdj_orderPreResp)com.alibaba.fastjson.JSONObject.toJavaObject((JSON)jsonObj, Tb_sdj_orderPreResp.class);
            String respSign = jsonObj.getString("signature");
            String signObject = SDKUtil.getSignData(resp, info.getSub_merkey_v2());
            boolean isVerifySign = false;
            String publicKeyPath = WxSdjAPICommon.getPublicKeyPath(info);
            PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
            byte[] sig1 = Hex.decode((String)respSign);
            isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
            if (isVerifySign) {
                String transCode = resp.getTransCode();
                if ("000102".equals(transCode)) {
                    Map<Object, Object> payMap = new HashMap();
                    com.alibaba.fastjson.JSONObject respJsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
                    String txnPayData = respJsonObj.getString("txnPayData");
                    com.alibaba.fastjson.JSONObject txnPayDataJsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)txnPayData);
                    String appId = txnPayDataJsonObj.getString("appId");
                    String timeStamp = txnPayDataJsonObj.getString("timeStamp");
                    String nonceStr = txnPayDataJsonObj.getString("nonceStr");
                    String packageStr = txnPayDataJsonObj.getString("package");
                    String signType = txnPayDataJsonObj.getString("signType");
                    String paySign = txnPayDataJsonObj.getString("paySign");
                    payMap = this.conPayParam(appId, timeStamp, nonceStr, packageStr, signType, paySign);
                    payMap.put("sw_order_id", dto.getTxnPayeeOrderNo());
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.DATA, payMap);
                } else {
                    ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        } else {
            ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        return ret;
    }

    private Map<String, Object> createPayOrderGoods(Identifier identifier, Tb_order_goods order, String totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        Map<String, Object> map = WxSdjAPICommon.initCert(info);
        String certId = info.getSub_service_serialno();
        PrivateKey privateKey = (PrivateKey)map.get("privateKey");
        String url = XcbConstantValue.sdj_payee_preOrder;
        String payNotify = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/payGoodsNotify";
        StringBuffer sb_attach = new StringBuffer();
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)info.getSub_mchid()));
        System.out.println("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        dataMap = new HashMap();
        Tb_sdj_order dto = new Tb_sdj_order();
        String timestamp = System.currentTimeMillis() + "";
        dto.setVersion(info.getSr_version());
        dto.setEncoding(XcbConstantValue.ENCODING_UTF8);
        dto.setSignMethod("SM");
        dto.setMerNo(info.getSub_mchid());
        dto.setTimestamp(timestamp);
        dto.setTxnProductType("WXB2C");
        dto.setTxnTransType("PURCHASE");
        dto.setTxnTransInput("300003");
        dto.setCertId(certId);
        dto.setTxnCurrencyCode("CNY");
        dto.setTxnPayeeOrderNo(order.getSd_order_id());
        dto.setTxnPayeeOrderTime(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd'T'HH:mm:ss"));
        dto.setTxnAmt(totalMoney);
        dto.setMerAppId(info.getSub_appid());
        dto.setMerOpenId(sr_open_id);
        String notifyUrl = Base64.getUrlEncoder().withoutPadding().encodeToString(payNotify.getBytes("utf-8"));
        dto.setTxnNotifyUrl(notifyUrl);
        dto.setTxnDescription(info.getSr_body_name());
        dto.setTxnSettleType("T1");
        dto.setTxnAttach(sb_attach.toString());
        dataMap.put("version", dto.getVersion());
        dataMap.put("encoding", dto.getEncoding());
        dataMap.put("signMethod", dto.getSignMethod());
        dataMap.put("merNo", dto.getMerNo());
        dataMap.put("timestamp", dto.getTimestamp());
        dataMap.put("txnProductType", dto.getTxnProductType());
        dataMap.put("txnTransType", dto.getTxnTransType());
        dataMap.put("txnTransInput", dto.getTxnTransInput());
        dataMap.put("txnSettleType", dto.getTxnSettleType());
        dataMap.put("txnCurrencyCode", dto.getTxnCurrencyCode());
        dataMap.put("txnAmt", dto.getTxnAmt());
        dataMap.put("txnPayeeOrderNo", dto.getTxnPayeeOrderNo());
        dataMap.put("txnPayeeOrderTime", dto.getTxnPayeeOrderTime());
        dataMap.put("txnDescription", dto.getTxnDescription());
        dataMap.put("txnAttach", dto.getTxnAttach());
        dataMap.put("txnNotifyUrl", notifyUrl);
        dataMap.put("merAppId", dto.getMerAppId());
        dataMap.put("merOpenId", dto.getMerOpenId());
        dataMap.put("certId", certId);
        String signString = SDKUtil.getMerSign(dto, info);
        byte[] sign = SM2Util.signSm3WithSm2(signString.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), privateKey);
        String signData = Hex.toHexString((byte[])sign);
        dto.setSignature(signData);
        dataMap.put("signature", signData);
        String reqdata = com.alibaba.fastjson.JSONObject.toJSONString(dataMap);
        System.out.println("\u8bf7\u6c42\u6570\u636e\uff1a" + reqdata);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
        String respResult = APIHttpClient.getInstance().post(reqdata, url);
        this.log.info("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
        System.out.println("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
        if (!XcbStringUtils.isNullOrBlank((Object)respResult)) {
            com.alibaba.fastjson.JSONObject jsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
            Tb_sdj_orderPreResp resp = (Tb_sdj_orderPreResp)com.alibaba.fastjson.JSONObject.toJavaObject((JSON)jsonObj, Tb_sdj_orderPreResp.class);
            String respSign = jsonObj.getString("signature");
            String signObject = SDKUtil.getSignData(resp, info.getSub_merkey_v2());
            boolean isVerifySign = false;
            String publicKeyPath = WxSdjAPICommon.getPublicKeyPath(info);
            PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
            byte[] sig1 = Hex.decode((String)respSign);
            isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
            if (isVerifySign) {
                String transCode = resp.getTransCode();
                if ("000102".equals(transCode)) {
                    Map<Object, Object> payMap = new HashMap();
                    com.alibaba.fastjson.JSONObject respJsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
                    String txnPayData = respJsonObj.getString("txnPayData");
                    com.alibaba.fastjson.JSONObject txnPayDataJsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)txnPayData);
                    String appId = txnPayDataJsonObj.getString("appId");
                    String timeStamp = txnPayDataJsonObj.getString("timeStamp");
                    String nonceStr = txnPayDataJsonObj.getString("nonceStr");
                    String packageStr = txnPayDataJsonObj.getString("package");
                    String signType = txnPayDataJsonObj.getString("signType");
                    String paySign = txnPayDataJsonObj.getString("paySign");
                    payMap = this.conPayParam(appId, timeStamp, nonceStr, packageStr, signType, paySign);
                    payMap.put("sd_order_id", order.getSd_order_id());
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.DATA, payMap);
                } else {
                    ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        } else {
            ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        return ret;
    }

    public Map<String, Object> temporaryOrder(Tb_order order, String totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        Map<String, Object> map = WxSdjAPICommon.initCert(info);
        String certId = info.getSub_service_serialno();
        PrivateKey privateKey = (PrivateKey)map.get("privateKey");
        String url = XcbConstantValue.sdj_payee_preOrder;
        String payNotify = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/temporaryNotify";
        StringBuffer sb_attach = new StringBuffer();
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_WX));
        System.out.println("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        dataMap = new HashMap();
        Tb_sdj_order dto = new Tb_sdj_order();
        String timestamp = System.currentTimeMillis() + "";
        dto.setVersion(info.getSr_version());
        dto.setEncoding(XcbConstantValue.ENCODING_UTF8);
        dto.setSignMethod("SM");
        dto.setMerNo(info.getSub_mchid());
        dto.setTimestamp(timestamp);
        dto.setTxnProductType("WXB2C");
        dto.setTxnTransType("PURCHASE");
        dto.setTxnTransInput("300003");
        dto.setCertId(certId);
        dto.setTxnCurrencyCode("CNY");
        dto.setTxnPayeeOrderNo(order.getSd_order_id());
        dto.setTxnPayeeOrderTime(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd'T'HH:mm:ss"));
        dto.setTxnAmt(totalMoney);
        dto.setMerAppId(info.getSub_appid());
        dto.setMerOpenId(sr_open_id);
        String notifyUrl = Base64.getUrlEncoder().withoutPadding().encodeToString(payNotify.getBytes("utf-8"));
        dto.setTxnNotifyUrl(notifyUrl);
        dto.setTxnDescription(info.getSr_body_name());
        dto.setTxnSettleType("T1");
        dto.setTxnAttach(sb_attach.toString());
        dataMap.put("version", dto.getVersion());
        dataMap.put("encoding", dto.getEncoding());
        dataMap.put("signMethod", dto.getSignMethod());
        dataMap.put("merNo", dto.getMerNo());
        dataMap.put("timestamp", dto.getTimestamp());
        dataMap.put("txnProductType", dto.getTxnProductType());
        dataMap.put("txnTransType", dto.getTxnTransType());
        dataMap.put("txnTransInput", dto.getTxnTransInput());
        dataMap.put("txnSettleType", dto.getTxnSettleType());
        dataMap.put("txnCurrencyCode", dto.getTxnCurrencyCode());
        dataMap.put("txnAmt", dto.getTxnAmt());
        dataMap.put("txnPayeeOrderNo", dto.getTxnPayeeOrderNo());
        dataMap.put("txnPayeeOrderTime", dto.getTxnPayeeOrderTime());
        dataMap.put("txnDescription", dto.getTxnDescription());
        dataMap.put("txnAttach", dto.getTxnAttach());
        dataMap.put("txnNotifyUrl", notifyUrl);
        dataMap.put("merAppId", dto.getMerAppId());
        dataMap.put("merOpenId", dto.getMerOpenId());
        dataMap.put("certId", certId);
        String signString = SDKUtil.getMerSign(dto, info);
        byte[] sign = SM2Util.signSm3WithSm2(signString.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), privateKey);
        String signData = Hex.toHexString((byte[])sign);
        dto.setSignature(signData);
        dataMap.put("signature", signData);
        String reqdata = com.alibaba.fastjson.JSONObject.toJSONString(dataMap);
        System.out.println("\u8bf7\u6c42\u6570\u636e\uff1a" + reqdata);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
        String respResult = APIHttpClient.getInstance().post(reqdata, url);
        this.log.info("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
        System.out.println("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
        if (!XcbStringUtils.isNullOrBlank((Object)respResult)) {
            com.alibaba.fastjson.JSONObject jsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
            Tb_sdj_orderPreResp resp = (Tb_sdj_orderPreResp)com.alibaba.fastjson.JSONObject.toJavaObject((JSON)jsonObj, Tb_sdj_orderPreResp.class);
            String respSign = jsonObj.getString("signature");
            String signObject = SDKUtil.getSignData(resp, info.getSub_merkey_v2());
            boolean isVerifySign = false;
            String publicKeyPath = WxSdjAPICommon.getPublicKeyPath(info);
            PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
            byte[] sig1 = Hex.decode((String)respSign);
            isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
            if (isVerifySign) {
                String transCode = resp.getTransCode();
                if ("000102".equals(transCode)) {
                    Map<Object, Object> payMap = new HashMap();
                    com.alibaba.fastjson.JSONObject respJsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
                    String txnPayData = respJsonObj.getString("txnPayData");
                    com.alibaba.fastjson.JSONObject txnPayDataJsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)txnPayData);
                    String appId = txnPayDataJsonObj.getString("appId");
                    String timeStamp = txnPayDataJsonObj.getString("timeStamp");
                    String nonceStr = txnPayDataJsonObj.getString("nonceStr");
                    String packageStr = txnPayDataJsonObj.getString("package");
                    String signType = txnPayDataJsonObj.getString("signType");
                    String paySign = txnPayDataJsonObj.getString("paySign");
                    payMap = this.conPayParam(appId, timeStamp, nonceStr, packageStr, signType, paySign);
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.DATA, payMap);
                } else {
                    ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        } else {
            ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        return ret;
    }

    public Map<String, Object> finishOrder(Tb_order order, String totalMoney, String sr_open_id, Tb_wx_pay_info info, String cus_ip) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        Map<String, Object> map = WxSdjAPICommon.initCert(info);
        String certId = info.getSub_service_serialno();
        PrivateKey privateKey = (PrivateKey)map.get("privateKey");
        String url = XcbConstantValue.sdj_payee_preOrder;
        String payNotify = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/finishNotify";
        StringBuffer sb_attach = new StringBuffer();
        sb_attach.append(XcbStringUtils.getObjtoString((Object)order.getSd_order_id())).append(",").append(XcbStringUtils.getObjtoString((Object)XcbConstantValue.ORDER_CASH_TYPE_WX));
        System.out.println("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach.toString());
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u9644\u52a0\u53c2\u6570:" + sb_attach);
        dataMap = new HashMap();
        Tb_sdj_order dto = new Tb_sdj_order();
        String timestamp = System.currentTimeMillis() + "";
        dto.setVersion(info.getSr_version());
        dto.setEncoding(XcbConstantValue.ENCODING_UTF8);
        dto.setSignMethod("SM");
        dto.setMerNo(info.getSub_mchid());
        dto.setTimestamp(timestamp);
        dto.setTxnProductType("WXB2C");
        dto.setTxnTransType("PURCHASE");
        dto.setTxnTransInput("300003");
        dto.setCertId(certId);
        dto.setTxnCurrencyCode("CNY");
        dto.setTxnPayeeOrderNo(order.getSd_order_id());
        dto.setTxnPayeeOrderTime(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd'T'HH:mm:ss"));
        dto.setTxnAmt(totalMoney);
        dto.setMerAppId(info.getSub_appid());
        dto.setMerOpenId(sr_open_id);
        String notifyUrl = Base64.getUrlEncoder().withoutPadding().encodeToString(payNotify.getBytes("utf-8"));
        dto.setTxnNotifyUrl(notifyUrl);
        dto.setTxnDescription(info.getSr_body_name());
        dto.setTxnSettleType("T1");
        dto.setTxnAttach(sb_attach.toString());
        dataMap.put("version", dto.getVersion());
        dataMap.put("encoding", dto.getEncoding());
        dataMap.put("signMethod", dto.getSignMethod());
        dataMap.put("merNo", dto.getMerNo());
        dataMap.put("timestamp", dto.getTimestamp());
        dataMap.put("txnProductType", dto.getTxnProductType());
        dataMap.put("txnTransType", dto.getTxnTransType());
        dataMap.put("txnTransInput", dto.getTxnTransInput());
        dataMap.put("txnSettleType", dto.getTxnSettleType());
        dataMap.put("txnCurrencyCode", dto.getTxnCurrencyCode());
        dataMap.put("txnAmt", dto.getTxnAmt());
        dataMap.put("txnPayeeOrderNo", dto.getTxnPayeeOrderNo());
        dataMap.put("txnPayeeOrderTime", dto.getTxnPayeeOrderTime());
        dataMap.put("txnDescription", dto.getTxnDescription());
        dataMap.put("txnAttach", dto.getTxnAttach());
        dataMap.put("txnNotifyUrl", notifyUrl);
        dataMap.put("merAppId", dto.getMerAppId());
        dataMap.put("merOpenId", dto.getMerOpenId());
        dataMap.put("certId", certId);
        String signString = SDKUtil.getMerSign(dto, info);
        byte[] sign = SM2Util.signSm3WithSm2(signString.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), privateKey);
        String signData = Hex.toHexString((byte[])sign);
        dto.setSignature(signData);
        dataMap.put("signature", signData);
        String reqdata = com.alibaba.fastjson.JSONObject.toJSONString(dataMap);
        System.out.println("\u8bf7\u6c42\u6570\u636e\uff1a" + reqdata);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
        String respResult = APIHttpClient.getInstance().post(reqdata, url);
        this.log.info("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
        System.out.println("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
        if (!XcbStringUtils.isNullOrBlank((Object)respResult)) {
            com.alibaba.fastjson.JSONObject jsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
            Tb_sdj_orderPreResp resp = (Tb_sdj_orderPreResp)com.alibaba.fastjson.JSONObject.toJavaObject((JSON)jsonObj, Tb_sdj_orderPreResp.class);
            String respSign = jsonObj.getString("signature");
            String signObject = SDKUtil.getSignData(resp, info.getSub_merkey_v2());
            boolean isVerifySign = false;
            String publicKeyPath = WxSdjAPICommon.getPublicKeyPath(info);
            PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
            byte[] sig1 = Hex.decode((String)respSign);
            isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
            if (isVerifySign) {
                String transCode = resp.getTransCode();
                if ("000102".equals(transCode)) {
                    Map<Object, Object> payMap = new HashMap();
                    com.alibaba.fastjson.JSONObject respJsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
                    String txnPayData = respJsonObj.getString("txnPayData");
                    com.alibaba.fastjson.JSONObject txnPayDataJsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)txnPayData);
                    String appId = txnPayDataJsonObj.getString("appId");
                    String timeStamp = txnPayDataJsonObj.getString("timeStamp");
                    String nonceStr = txnPayDataJsonObj.getString("nonceStr");
                    String packageStr = txnPayDataJsonObj.getString("package");
                    String signType = txnPayDataJsonObj.getString("signType");
                    String paySign = txnPayDataJsonObj.getString("paySign");
                    payMap = this.conPayParam(appId, timeStamp, nonceStr, packageStr, signType, paySign);
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    ret.put(XcbConstantValue.DATA, payMap);
                } else {
                    ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        } else {
            ret.put(XcbConstantValue.MSG, "\u652f\u4ed8\u8bf7\u6c42\u5f02\u5e38");
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        return ret;
    }

    public Map<String, Object> identity_certificate(Identifier identifier, Tb_wx_pay_info info, Tb_agent agent) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        Tb_sdj_identity dto = new Tb_sdj_identity();
        try {
            Map<String, Object> map = WxSdjAPICommon.initCert(info);
            String certId = info.getSub_service_serialno();
            PrivateKey privateKey = (PrivateKey)map.get("privateKey");
            String url = XcbConstantValue.sdj_payee_identity;
            String timestamp = System.currentTimeMillis() + "";
            dto.setVersion(info.getSr_version());
            dto.setEncoding(XcbConstantValue.ENCODING_UTF8);
            dto.setSignMethod("SM");
            dto.setMerNo(info.getSub_mchid());
            dto.setTimestamp(timestamp);
            String orgOrder = CommonFunction.getVoucherNum((String)CommonFunction.identity_id);
            String orgOrderTime = XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd'T'HH:mm:ss");
            dto.setTxnProductType("DAIFU");
            dto.setTxnTransType("CERT_COM");
            dto.setTxnTransInput("01001");
            dto.setTxnPayeeOrderNo(orgOrder);
            dto.setTxnPayeeOrderTime(orgOrderTime);
            dto.setTxnDescription("\u4ee3\u4ed8\u7ed1\u5b9a\u8ba4\u8bc1");
            dto.setBankCode(agent.getSr_bank());
            dto.setBankAccountName(agent.getSr_account_name());
            dto.setBankAccountNo(agent.getSr_account());
            dto.setBankAccountIdentityNo(agent.getSr_accounter_id());
            dto.setBankAccountIdentityType("01");
            dto.setBankAccountCardType("DEBIT_CARD");
            dto.setBankAccountName(SM4EnDecryptionUtil.encryptEcbPadding(dto.getBankAccountName(), info.getSub_merkey_v2()));
            dto.setBankAccountNo(SM4EnDecryptionUtil.encryptEcbPadding(dto.getBankAccountNo(), info.getSub_merkey_v2()));
            dto.setBankAccountIdentityNo(SM4EnDecryptionUtil.encryptEcbPadding(dto.getBankAccountIdentityNo(), info.getSub_merkey_v2()));
            dto.setCertId(certId);
            dataMap.put("version", dto.getVersion());
            dataMap.put("encoding", dto.getEncoding());
            dataMap.put("signMethod", dto.getSignMethod());
            dataMap.put("merNo", dto.getMerNo());
            dataMap.put("timestamp", dto.getTimestamp());
            dataMap.put("txnProductType", dto.getTxnProductType());
            dataMap.put("txnTransType", dto.getTxnTransType());
            dataMap.put("txnTransInput", dto.getTxnTransInput());
            dataMap.put("txnPayeeOrderNo", dto.getTxnPayeeOrderNo());
            dataMap.put("txnPayeeOrderTime", dto.getTxnPayeeOrderTime());
            dataMap.put("bankCode", dto.getBankCode());
            dataMap.put("bankAccountCardType", dto.getBankAccountCardType());
            dataMap.put("bankAccountNo", dto.getBankAccountNo());
            dataMap.put("bankAccountName", dto.getBankAccountName());
            dataMap.put("bankAccountIdentityType", dto.getBankAccountIdentityType());
            dataMap.put("bankAccountIdentityNo", dto.getBankAccountIdentityNo());
            dataMap.put("txnDescription", dto.getTxnDescription());
            dataMap.put("certId", certId);
            String signString = SDKUtil.getMerSign(dto, info);
            byte[] sign = SM2Util.signSm3WithSm2(signString.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), privateKey);
            String signData = Hex.toHexString((byte[])sign);
            dto.setSignature(signData);
            dataMap.put("signature", signData);
            String reqdata = com.alibaba.fastjson.JSONObject.toJSONString(dataMap);
            System.out.println("\u8bf7\u6c42\u6570\u636e\uff1a" + reqdata);
            this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
            String respResult = APIHttpClient.getInstance().post(reqdata, url);
            this.log.info("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
            System.out.println("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
            if (!XcbStringUtils.isNullOrBlank((Object)respResult)) {
                com.alibaba.fastjson.JSONObject jsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
                Tb_sdj_identityResp resp = (Tb_sdj_identityResp)com.alibaba.fastjson.JSONObject.toJavaObject((JSON)jsonObj, Tb_sdj_identityResp.class);
                String respSign = jsonObj.getString("signature");
                String signObject = SDKUtil.getSignData(resp, info.getSub_merkey_v2());
                boolean isVerifySign = false;
                String publicKeyPath = WxSdjAPICommon.getPublicKeyPath(info);
                PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
                byte[] sig1 = Hex.decode((String)respSign);
                isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
                if (isVerifySign) {
                    String transCode = resp.getTransCode();
                    if (TransCode.TRANS_000000.getCode().equals(transCode)) {
                        HashMap<String, String> data = new HashMap<String, String>();
                        data.put("txnOrderNo", XcbStringUtils.getObjtoString((Object)resp.getTxnOrderNo()));
                        data.put("txnOrderTime", XcbStringUtils.getObjtoString((Object)resp.getTxnOrderTime()));
                        data.put("txnOrgOrder", XcbStringUtils.getObjtoString((Object)orgOrder));
                        data.put("txnOrgOrderTime", XcbStringUtils.getObjtoString((Object)orgOrderTime));
                        ret.put(XcbConstantValue.DATA, data);
                        ret.put(XcbConstantValue.MSG, "\u8ba4\u8bc1\u6210\u529f");
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    } else {
                        ret.put(XcbConstantValue.MSG, resp.getTransMsg());
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    }
                } else {
                    ret.put(XcbConstantValue.MSG, "\u4ee3\u4ed8\u7ed1\u5b9a\u8ba4\u8bc1\u8bf7\u6c42\u5f02\u5e38");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, "\u4ee3\u4ed8\u7ed1\u5b9a\u8ba4\u8bc1\u9a8c\u7b7e\u5931\u8d25");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.getObjtoString((Object)e));
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return ret;
    }

    public Map<String, Object> binding(Identifier identifier, Tb_wx_pay_info info, Tb_agent agent) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        Tb_sdj_binding dto = new Tb_sdj_binding();
        try {
            Map<String, Object> map = WxSdjAPICommon.initCert(info);
            String certId = info.getSub_service_serialno();
            PrivateKey privateKey = (PrivateKey)map.get("privateKey");
            String url = XcbConstantValue.sdj_payee_binding;
            String timestamp = System.currentTimeMillis() + "";
            dto.setVersion(info.getSr_version());
            dto.setEncoding(XcbConstantValue.ENCODING_UTF8);
            dto.setSignMethod("SM");
            dto.setMerNo(info.getSub_mchid());
            dto.setTimestamp(timestamp);
            dto.setTxnProductType("DAIFU");
            dto.setTxnTransType("BIND");
            dto.setTxnTransInput("650001");
            dto.setTxnPayerOrderNo(CommonFunction.getVoucherNum((String)CommonFunction.binding_id));
            dto.setTxnPayerOrderTime(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd'T'HH:mm:ss"));
            dto.setTxnDescription("\u7ed1\u5b9a\u5efa\u7acb");
            dto.setTxnOrigPayeeOrderNo(agent.getSr_txn_org_order());
            dto.setTxnOrigPayeeOrderTime(agent.getSr_txn_org_order_time());
            dto.setCertId(certId);
            dataMap.put("version", dto.getVersion());
            dataMap.put("encoding", dto.getEncoding());
            dataMap.put("signMethod", dto.getSignMethod());
            dataMap.put("merNo", dto.getMerNo());
            dataMap.put("timestamp", dto.getTimestamp());
            dataMap.put("txnProductType", dto.getTxnProductType());
            dataMap.put("txnTransType", dto.getTxnTransType());
            dataMap.put("txnTransInput", dto.getTxnTransInput());
            dataMap.put("txnPayerOrderNo", dto.getTxnPayerOrderNo());
            dataMap.put("txnPayerOrderTime", dto.getTxnPayerOrderTime());
            dataMap.put("txnOrigPayeeOrderNo", dto.getTxnOrigPayeeOrderNo());
            dataMap.put("txnOrigPayeeOrderTime", dto.getTxnOrigPayeeOrderTime());
            dataMap.put("bankCode", dto.getBankCode());
            dataMap.put("bankAccountCardType", dto.getBankAccountCardType());
            dataMap.put("bankAccountNo", dto.getBankAccountNo());
            dataMap.put("bankAccountName", dto.getBankAccountName());
            dataMap.put("bankAccountIdentityType", dto.getBankAccountIdentityType());
            dataMap.put("bankAccountIdentityNo", dto.getBankAccountIdentityNo());
            dataMap.put("txnDescription", dto.getTxnDescription());
            dataMap.put("certId", certId);
            String signString = SDKUtil.getMerSign(dto, info);
            byte[] sign = SM2Util.signSm3WithSm2(signString.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), privateKey);
            String signData = Hex.toHexString((byte[])sign);
            dto.setSignature(signData);
            dataMap.put("signature", signData);
            String reqdata = com.alibaba.fastjson.JSONObject.toJSONString(dataMap);
            System.out.println("\u8bf7\u6c42\u6570\u636e\uff1a" + reqdata);
            this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
            String respResult = APIHttpClient.getInstance().post(reqdata, url);
            this.log.info("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
            System.out.println("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
            if (!XcbStringUtils.isNullOrBlank((Object)respResult)) {
                com.alibaba.fastjson.JSONObject jsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
                Tb_sdj_bindingResp resp = (Tb_sdj_bindingResp)com.alibaba.fastjson.JSONObject.toJavaObject((JSON)jsonObj, Tb_sdj_bindingResp.class);
                String respSign = jsonObj.getString("signature");
                String signObject = SDKUtil.getSignData(resp, info.getSub_merkey_v2());
                boolean isVerifySign = false;
                String publicKeyPath = WxSdjAPICommon.getPublicKeyPath(info);
                PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
                byte[] sig1 = Hex.decode((String)respSign);
                isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
                if (isVerifySign) {
                    String transCode = resp.getTransCode();
                    if (TransCode.TRANS_000000.getCode().equals(transCode)) {
                        HashMap<String, String> data = new HashMap<String, String>();
                        String bindingNo = SM4EnDecryptionUtil.decryptEcbPadding(resp.getBindingNo(), info.getSub_merkey_v2());
                        data.put("bindingNo", bindingNo);
                        ret.put(XcbConstantValue.DATA, data);
                        ret.put(XcbConstantValue.MSG, "\u7ed1\u5b9a\u6210\u529f");
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    } else {
                        ret.put(XcbConstantValue.MSG, resp.getTransMsg());
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    }
                } else {
                    ret.put(XcbConstantValue.MSG, "\u7ed1\u5b9a\u5efa\u7acb\u8bf7\u6c42\u5f02\u5e38");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, "\u7ed1\u5b9a\u5efa\u7acb\u9a8c\u7b7e\u5931\u8d25");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.getObjtoString((Object)e));
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return ret;
    }

    public Map<String, Object> binding_cpy(Identifier identifier, Tb_wx_pay_info info, Tb_agent agent) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        Tb_sdj_binding dto = new Tb_sdj_binding();
        try {
            Map<String, Object> map = WxSdjAPICommon.initCert(info);
            String certId = info.getSub_service_serialno();
            PrivateKey privateKey = (PrivateKey)map.get("privateKey");
            String url = XcbConstantValue.sdj_payee_binding;
            String timestamp = System.currentTimeMillis() + "";
            dto.setVersion(info.getSr_version());
            dto.setEncoding(XcbConstantValue.ENCODING_UTF8);
            dto.setSignMethod("SM");
            dto.setMerNo(info.getSub_mchid());
            dto.setTimestamp(timestamp);
            dto.setTxnProductType("DAIFU");
            dto.setTxnTransType("BIND");
            dto.setTxnTransInput("650001");
            dto.setTxnPayerOrderNo(CommonFunction.getVoucherNum((String)CommonFunction.binding_id));
            dto.setTxnPayerOrderTime(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd'T'HH:mm:ss"));
            dto.setBankCode(agent.getSr_bank());
            dto.setBankAccountCardType("DEBIT_CARD");
            dto.setBankAccountIdentityType("14");
            dto.setBankAccountName(SM4EnDecryptionUtil.encryptEcbPadding(agent.getSr_account_name(), info.getSub_merkey_v2()));
            dto.setBankAccountNo(SM4EnDecryptionUtil.encryptEcbPadding(agent.getSr_account(), info.getSub_merkey_v2()));
            dto.setBankAccountType("OPEN");
            dto.setBankCnapsNo(agent.getSr_bank_cnapsno());
            dto.setTxnDescription("\u7ed1\u5b9a\u5efa\u7acb");
            dto.setCertId(certId);
            dataMap.put("version", dto.getVersion());
            dataMap.put("encoding", dto.getEncoding());
            dataMap.put("signMethod", dto.getSignMethod());
            dataMap.put("merNo", dto.getMerNo());
            dataMap.put("timestamp", dto.getTimestamp());
            dataMap.put("txnProductType", dto.getTxnProductType());
            dataMap.put("txnTransType", dto.getTxnTransType());
            dataMap.put("txnTransInput", dto.getTxnTransInput());
            dataMap.put("txnPayerOrderNo", dto.getTxnPayerOrderNo());
            dataMap.put("txnPayerOrderTime", dto.getTxnPayerOrderTime());
            dataMap.put("bankCode", dto.getBankCode());
            dataMap.put("bankAccountCardType", dto.getBankAccountCardType());
            dataMap.put("bankAccountNo", dto.getBankAccountNo());
            dataMap.put("bankAccountName", dto.getBankAccountName());
            dataMap.put("bankAccountIdentityType", dto.getBankAccountIdentityType());
            dataMap.put("bankAccountType", dto.getBankAccountType());
            dataMap.put("bankCnapsNo", dto.getBankCnapsNo());
            dataMap.put("txnDescription", dto.getTxnDescription());
            dataMap.put("certId", certId);
            String signString = SDKUtil.getMerSign(dto, info);
            byte[] sign = SM2Util.signSm3WithSm2(signString.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), privateKey);
            String signData = Hex.toHexString((byte[])sign);
            dto.setSignature(signData);
            dataMap.put("signature", signData);
            String reqdata = com.alibaba.fastjson.JSONObject.toJSONString(dataMap);
            System.out.println("\u8bf7\u6c42\u6570\u636e\uff1a" + reqdata);
            this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
            String respResult = APIHttpClient.getInstance().post(reqdata, url);
            this.log.info("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
            System.out.println("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
            if (!XcbStringUtils.isNullOrBlank((Object)respResult)) {
                com.alibaba.fastjson.JSONObject jsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
                Tb_sdj_bindingResp resp = (Tb_sdj_bindingResp)com.alibaba.fastjson.JSONObject.toJavaObject((JSON)jsonObj, Tb_sdj_bindingResp.class);
                String respSign = jsonObj.getString("signature");
                String signObject = SDKUtil.getSignData(resp, info.getSub_merkey_v2());
                boolean isVerifySign = false;
                String publicKeyPath = WxSdjAPICommon.getPublicKeyPath(info);
                PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
                byte[] sig1 = Hex.decode((String)respSign);
                isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
                if (isVerifySign) {
                    String transCode = resp.getTransCode();
                    if (TransCode.TRANS_000000.getCode().equals(transCode)) {
                        HashMap<String, String> data = new HashMap<String, String>();
                        String bindingNo = SM4EnDecryptionUtil.decryptEcbPadding(resp.getBindingNo(), info.getSub_merkey_v2());
                        data.put("bindingNo", bindingNo);
                        ret.put(XcbConstantValue.DATA, data);
                        ret.put(XcbConstantValue.MSG, "\u7ed1\u5b9a\u6210\u529f");
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    } else {
                        ret.put(XcbConstantValue.MSG, resp.getTransMsg());
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    }
                } else {
                    ret.put(XcbConstantValue.MSG, "\u7ed1\u5b9a\u5efa\u7acb\u8bf7\u6c42\u5f02\u5e38");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, "\u7ed1\u5b9a\u5efa\u7acb\u9a8c\u7b7e\u5931\u8d25");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.getObjtoString((Object)e));
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return ret;
    }

    public Map<String, Object> binding_terminate(Identifier identifier, Tb_wx_pay_info info, Tb_agent agent) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        Tb_sdj_binding_terminate dto = new Tb_sdj_binding_terminate();
        try {
            Map<String, Object> map = WxSdjAPICommon.initCert(info);
            String certId = info.getSub_service_serialno();
            PrivateKey privateKey = (PrivateKey)map.get("privateKey");
            String url = XcbConstantValue.sdj_payee_binding_terminate;
            String timestamp = System.currentTimeMillis() + "";
            dto.setVersion(info.getSr_version());
            dto.setEncoding(XcbConstantValue.ENCODING_UTF8);
            dto.setSignMethod("SM");
            dto.setMerNo(info.getSub_mchid());
            dto.setTimestamp(timestamp);
            dto.setTxnProductType("DAIFU");
            dto.setTxnTransType("BINDING_TE");
            dto.setTxnTransInput("650001");
            dto.setTxnPayerOrderNo(CommonFunction.getVoucherNum((String)CommonFunction.binding_id));
            dto.setTxnPayerOrderTime(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd'T'HH:mm:ss"));
            dto.setTxnDescription("\u7ed1\u5b9a\u89e3\u9664");
            dto.setBindingNo(agent.getSr_txn_bindno());
            dto.setCertId(certId);
            dataMap.put("version", dto.getVersion());
            dataMap.put("encoding", dto.getEncoding());
            dataMap.put("signMethod", dto.getSignMethod());
            dataMap.put("merNo", dto.getMerNo());
            dataMap.put("timestamp", dto.getTimestamp());
            dataMap.put("txnProductType", dto.getTxnProductType());
            dataMap.put("txnTransType", dto.getTxnTransType());
            dataMap.put("txnTransInput", dto.getTxnTransInput());
            dataMap.put("txnPayerOrderNo", dto.getTxnPayerOrderNo());
            dataMap.put("txnPayerOrderTime", dto.getTxnPayerOrderTime());
            dataMap.put("txnDescription", dto.getTxnDescription());
            dataMap.put("bindingNo", dto.getBindingNo());
            dataMap.put("certId", certId);
            String signString = SDKUtil.getMerSign(dto, info);
            byte[] sign = SM2Util.signSm3WithSm2(signString.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), privateKey);
            String signData = Hex.toHexString((byte[])sign);
            dto.setSignature(signData);
            dataMap.put("signature", signData);
            String reqdata = com.alibaba.fastjson.JSONObject.toJSONString(dataMap);
            System.out.println("\u8bf7\u6c42\u6570\u636e\uff1a" + reqdata);
            this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
            String respResult = APIHttpClient.getInstance().post(reqdata, url);
            this.log.info("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
            System.out.println("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
            if (!XcbStringUtils.isNullOrBlank((Object)respResult)) {
                com.alibaba.fastjson.JSONObject jsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
                Tb_sdj_bindingResp resp = (Tb_sdj_bindingResp)com.alibaba.fastjson.JSONObject.toJavaObject((JSON)jsonObj, Tb_sdj_bindingResp.class);
                String respSign = jsonObj.getString("signature");
                String signObject = SDKUtil.getSignData(resp, info.getSub_merkey_v2());
                ret.put(XcbConstantValue.MSG, "\u89e3\u7ed1\u6210\u529f");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
            } else {
                ret.put(XcbConstantValue.MSG, "\u89e3\u7ed1\u9a8c\u7b7e\u5931\u8d25");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.getObjtoString((Object)e));
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return ret;
    }

    public Map<String, Object> bindingPay(Tb_wx_pay_info info, Tb_agent agent, BigDecimal agent_once_money, String sd_cash_id) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        HashMap<String, String> dataMap = new HashMap<String, String>();
        Tb_sdj_pay dto = new Tb_sdj_pay();
        try {
            Map<String, Object> map = WxSdjAPICommon.initCert(info);
            String certId = info.getSub_service_serialno();
            PrivateKey privateKey = (PrivateKey)map.get("privateKey");
            String url = XcbConstantValue.sdj_payee_binding_pay;
            String payNotify = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "/bindPayNotify";
            String timestamp = System.currentTimeMillis() + "";
            dto.setVersion(info.getSr_version());
            dto.setEncoding(XcbConstantValue.ENCODING_UTF8);
            dto.setSignMethod("SM");
            dto.setMerNo(info.getSub_mchid());
            dto.setTimestamp(timestamp);
            dto.setTxnProductType("DAIFU");
            dto.setTxnTransType("PAYING");
            dto.setTxnTransInput("650001");
            dto.setTxnCurrencyCode("CNY");
            dto.setTxnAmt(XcbStringUtils.getObjtoString((Object)agent_once_money));
            dto.setTxnPayeeOrderNo(sd_cash_id);
            dto.setTxnPayeeOrderTime(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd'T'HH:mm:ss"));
            dto.setTxnDescription("\u4f63\u91d1\u6536\u5165");
            dto.setTxnSettleType("T1");
            dto.setTxnAttach("");
            dto.setBindingNo(agent.getSr_txn_bindno());
            dto.setCertId(certId);
            String notifyUrl = Base64.getUrlEncoder().withoutPadding().encodeToString(payNotify.getBytes("utf-8"));
            dto.setTxnNotifyUrl(notifyUrl);
            dataMap.put("version", dto.getVersion());
            dataMap.put("encoding", dto.getEncoding());
            dataMap.put("signMethod", dto.getSignMethod());
            dataMap.put("merNo", dto.getMerNo());
            dataMap.put("timestamp", dto.getTimestamp());
            dataMap.put("txnProductType", dto.getTxnProductType());
            dataMap.put("txnTransType", dto.getTxnTransType());
            dataMap.put("txnTransInput", dto.getTxnTransInput());
            dataMap.put("txnSettleType", dto.getTxnSettleType());
            dataMap.put("txnCurrencyCode", dto.getTxnCurrencyCode());
            dataMap.put("txnAmt", dto.getTxnAmt());
            dataMap.put("txnPayeeOrderNo", dto.getTxnPayeeOrderNo());
            dataMap.put("txnPayeeOrderTime", dto.getTxnPayeeOrderTime());
            dataMap.put("bindingNo", dto.getBindingNo());
            dataMap.put("txnDescription", dto.getTxnDescription());
            dataMap.put("txnAttach", dto.getTxnAttach());
            dataMap.put("txnNotifyUrl", notifyUrl);
            dataMap.put("certId", certId);
            String signString = SDKUtil.getMerSign(dto, info);
            byte[] sign = SM2Util.signSm3WithSm2(signString.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), privateKey);
            String signData = Hex.toHexString((byte[])sign);
            dto.setSignature(signData);
            dataMap.put("signature", signData);
            String reqdata = com.alibaba.fastjson.JSONObject.toJSONString(dataMap);
            System.out.println("\u8bf7\u6c42\u6570\u636e\uff1a" + reqdata);
            this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
            String respResult = APIHttpClient.getInstance().post(reqdata, url);
            this.log.info("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
            System.out.println("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
            if (!XcbStringUtils.isNullOrBlank((Object)respResult)) {
                com.alibaba.fastjson.JSONObject jsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
                Tb_sdj_payResp resp = (Tb_sdj_payResp)com.alibaba.fastjson.JSONObject.toJavaObject((JSON)jsonObj, Tb_sdj_payResp.class);
                String respSign = jsonObj.getString("signature");
                String signObject = SDKUtil.getSignData(resp, info.getSub_merkey_v2());
                boolean isVerifySign = false;
                String publicKeyPath = WxSdjAPICommon.getPublicKeyPath(info);
                PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
                byte[] sig1 = Hex.decode((String)respSign);
                isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
                if (isVerifySign) {
                    String transCode = resp.getTransCode();
                    if ("000102".equals(transCode)) {
                        HashMap data = new HashMap();
                        ret.put(XcbConstantValue.DATA, data);
                        ret.put(XcbConstantValue.MSG, "\u6253\u6b3e\u6210\u529f");
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                    } else {
                        ret.put(XcbConstantValue.MSG, resp.getTransMsg());
                        ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    }
                } else {
                    ret.put(XcbConstantValue.MSG, "\u6253\u6b3e\u8bf7\u6c42\u5f02\u5e38");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, "\u6253\u6b3e\u9a8c\u7b7e\u5931\u8d25");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        }
        catch (Exception e) {
            System.out.println(XcbStringUtils.getObjtoString((Object)e));
            this.log.error(XcbStringUtils.exceptionToString((Exception)e));
        }
        return ret;
    }

    public Map<String, Object> xcrefund(String out_trade_no, String transaction_id, String sd_cash_id, String total_fee, String refund_fee, Tb_wx_pay_info info) throws Exception {
        this.log.debug("\u76db\u8fea\u5609\u652f\u4ed8\u6d4b\u8bd5================");
        HashMap<String, Object> ret = new HashMap<String, Object>();
        Map<String, Object> map = WxSdjAPICommon.initCert(info);
        String certId = info.getSub_service_serialno();
        PrivateKey privateKey = (PrivateKey)map.get("privateKey");
        String timestamp = System.currentTimeMillis() + "";
        HashMap<String, String> dataMap = new HashMap<String, String>();
        Tb_sdj_refund dto = new Tb_sdj_refund();
        String url = XcbConstantValue.sdj_payee_trans_refund;
        dto.setVersion(info.getSr_version());
        dto.setEncoding(XcbConstantValue.ENCODING_UTF8);
        dto.setSignMethod("SM");
        dto.setMerNo(info.getSub_mchid());
        dto.setTimestamp(timestamp);
        dto.setTxnProductType("WXB2C");
        dto.setTxnTransType("REFUND");
        dto.setTxnTransInput("300003");
        dto.setTxnCurrencyCode("CNY");
        dto.setTxnAmt(refund_fee);
        dto.setTxnPayeeOrderNo(sd_cash_id);
        dto.setTxnOrigPayeeOrderNo(out_trade_no);
        dto.setTxnOrigPayeeAmt(total_fee);
        dto.setTxnPayeeOrderTime(XcbDateUtil.getCurrentDate((String)"yyyy-MM-dd'T'HH:mm:ss"));
        dto.setTxnDescription(info.getSr_refund_desc());
        String payNotify = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/refundPayNotify";
        dataMap.put("certId", certId);
        dto.setCertId(certId);
        String notifyUrl = Base64.getUrlEncoder().withoutPadding().encodeToString(payNotify.getBytes("utf-8"));
        dto.setTxnNotifyUrl(notifyUrl);
        dataMap.put("version", dto.getVersion());
        dataMap.put("encoding", dto.getEncoding());
        dataMap.put("signMethod", dto.getSignMethod());
        dataMap.put("merNo", dto.getMerNo());
        dataMap.put("timestamp", dto.getTimestamp());
        dataMap.put("txnProductType", dto.getTxnProductType());
        dataMap.put("txnTransType", dto.getTxnTransType());
        dataMap.put("txnTransInput", dto.getTxnTransInput());
        dataMap.put("txnCurrencyCode", dto.getTxnCurrencyCode());
        dataMap.put("txnAmt", dto.getTxnAmt());
        dataMap.put("txnPayeeOrderNo", dto.getTxnPayeeOrderNo());
        dataMap.put("txnPayeeOrderTime", dto.getTxnPayeeOrderTime());
        dataMap.put("txnOrigPayeeOrderNo", dto.getTxnOrigPayeeOrderNo());
        dataMap.put("txnOrigPayeeAmt", dto.getTxnOrigPayeeAmt());
        dataMap.put("txnDescription", dto.getTxnDescription());
        dataMap.put("txnNotifyUrl", notifyUrl);
        String signString = SDKUtil.getMerSign(dto, info);
        byte[] sign = SM2Util.signSm3WithSm2(signString.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), privateKey);
        String signData = Hex.toHexString((byte[])sign);
        dto.setSignature(signData);
        dataMap.put("signature", signData);
        String reqdata = JSONObject.fromObject(dataMap).toString();
        System.out.println("\u8bf7\u6c42\u6570\u636e\uff1a" + reqdata);
        this.log.info("\u5fae\u4fe1\u652f\u4ed8\u8bf7\u6c42\u53c2\u6570:" + reqdata);
        String respResult = APIHttpClient.getInstance().post(reqdata, url);
        this.log.info("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
        System.out.println("\u54cd\u5e94\u6570\u636e\uff1a" + respResult);
        if (!XcbStringUtils.isNullOrBlank((Object)respResult)) {
            com.alibaba.fastjson.JSONObject jsonObj = com.alibaba.fastjson.JSONObject.parseObject((String)respResult);
            Tb_sdj_refundResp resp = (Tb_sdj_refundResp)com.alibaba.fastjson.JSONObject.toJavaObject((JSON)jsonObj, Tb_sdj_refundResp.class);
            String respSign = jsonObj.getString("signature");
            String signObject = SDKUtil.getSignData(resp, info.getSub_merkey_v2());
            boolean isVerifySign = false;
            String publicKeyPath = WxSdjAPICommon.getPublicKeyPath(info);
            PublicKey publicKey = PfxCerUtil.getEncryptCertPublicKey(publicKeyPath.trim());
            byte[] sig1 = Hex.decode((String)respSign);
            isVerifySign = SM2Util.verifySm3WithSm2(signObject.getBytes(StandardCharsets.UTF_8), info.getSr_userid().getBytes(), sig1, publicKey);
            if (isVerifySign) {
                String transCode = resp.getTransCode();
                if (TransCode.TRANS_000000.getCode().equals(transCode)) {
                    HashMap data = new HashMap();
                    ret.put(XcbConstantValue.DATA, data);
                    ret.put(XcbConstantValue.MSG, "\u9000\u6b3e\u6210\u529f");
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                } else {
                    ret.put(XcbConstantValue.MSG, resp.getTransMsg());
                    ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                }
            } else {
                ret.put(XcbConstantValue.MSG, "\u9000\u6b3e\u8bf7\u6c42\u5f02\u5e38");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
            }
        } else {
            ret.put(XcbConstantValue.MSG, "\u9000\u6b3e\u9a8c\u7b7e\u5931\u8d25");
            ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
        }
        return ret;
    }

    public Map<String, String> conPayParam(String appid, String timeStamp, String nonceStr, String packageStr, String signType, String paySign) throws Exception {
        this.log.info("\u6839\u636e\u5f53\u524d\u7684prepayid\u6784\u9020\u8fd4\u56de\u53c2\u6570 " + packageStr);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("appId", appid);
        map.put("timeStamp", timeStamp);
        map.put("nonceStr", nonceStr);
        map.put("package", packageStr);
        map.put("signType", signType);
        map.put("paySign", paySign);
        return map;
    }

    static {
        Security.addProvider((Provider)new BouncyCastleProvider());
        certMap = new HashMap<String, Map<String, Object>>();
        cert = new HashMap<String, Object>();
    }
}

