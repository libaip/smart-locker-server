/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  com.jcg.company.model.Tb_wx_pay_info
 *  com.wechat.pay.contrib.apache.httpclient.Credentials
 *  com.wechat.pay.contrib.apache.httpclient.Validator
 *  com.wechat.pay.contrib.apache.httpclient.WechatPayHttpClientBuilder
 *  com.wechat.pay.contrib.apache.httpclient.auth.AutoUpdateCertificatesVerifier
 *  com.wechat.pay.contrib.apache.httpclient.auth.PrivateKeySigner
 *  com.wechat.pay.contrib.apache.httpclient.auth.Signer
 *  com.wechat.pay.contrib.apache.httpclient.auth.Verifier
 *  com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Credentials
 *  com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Validator
 *  com.wechat.pay.contrib.apache.httpclient.util.PemUtil
 *  net.sf.json.JSONObject
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.client.utils.URIBuilder
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.util.EntityUtils
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.stereotype.Service
 */
package com.jcg.zf.wx;

import com.jcg.common.BaseService;
import com.jcg.common.PromptProperties;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.company.model.Tb_wx_pay_info;
import com.jcg.company.serviceimpl.CompanyServiceImpl;
import com.wechat.pay.contrib.apache.httpclient.Credentials;
import com.wechat.pay.contrib.apache.httpclient.Validator;
import com.wechat.pay.contrib.apache.httpclient.WechatPayHttpClientBuilder;
import com.wechat.pay.contrib.apache.httpclient.auth.AutoUpdateCertificatesVerifier;
import com.wechat.pay.contrib.apache.httpclient.auth.PrivateKeySigner;
import com.wechat.pay.contrib.apache.httpclient.auth.Signer;
import com.wechat.pay.contrib.apache.httpclient.auth.Verifier;
import com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Credentials;
import com.wechat.pay.contrib.apache.httpclient.auth.WechatPay2Validator;
import com.wechat.pay.contrib.apache.httpclient.util.PemUtil;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.PrivateKey;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WxSpAPIV3Common
extends BaseService
implements GenericCaller {
    private static CloseableHttpClient httpClient;
    private static Map<String, CloseableHttpClient> httpClinet_map;
    @Autowired
    private CompanyServiceImpl companyService;

    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        return null;
    }

    private static void initCert(Tb_wx_pay_info info) throws Exception {
        httpClient = httpClinet_map.get(info.getSp_mchid());
        if (httpClient == null) {
            String privateKey = WxSpAPIV3Common.readLocalPrivateKey(info);
            PrivateKey merchantPrivateKey = PemUtil.loadPrivateKey((InputStream)new ByteArrayInputStream(privateKey.getBytes(XcbConstantValue.ENCODING_UTF8)));
            AutoUpdateCertificatesVerifier verifier = new AutoUpdateCertificatesVerifier((Credentials)new WechatPay2Credentials(info.getSp_mchid(), (Signer)new PrivateKeySigner(info.getSp_service_serialno(), merchantPrivateKey)), info.getSp_merkey_v3().getBytes(XcbConstantValue.ENCODING_UTF8));
            httpClient = WechatPayHttpClientBuilder.create().withMerchant(info.getSp_mchid(), info.getSp_service_serialno(), merchantPrivateKey).withValidator((Validator)new WechatPay2Validator((Verifier)verifier)).build();
            httpClinet_map.put(info.getSp_mchid(), httpClient);
        }
    }

    public static String readLocalPrivateKey(Tb_wx_pay_info info) throws IOException {
        String keyPath = info.getSr_key_path() + info.getSp_mchid() + "/apiclient_key.pem";
        File file = new File(keyPath);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        return sb.toString();
    }

    public Tb_company getCompany(String sw_company_id, String sr_wx_mer_id) throws Exception {
        Tb_company company = new Tb_company();
        try {
            if (!XcbStringUtils.isNullOrBlank((Object)sr_wx_mer_id)) {
                Map<String, Object> dataMap = this.companyService.findCompanyByMerId(sr_wx_mer_id);
                company = (Tb_company)dataMap.get(XcbConstantValue.DATA);
            } else {
                Map<String, Object> dataMap = this.companyService.findCompanyPayIn(sw_company_id);
                company = (Tb_company)dataMap.get(XcbConstantValue.DATA);
            }
        }
        catch (Exception e) {
            this.log.error(PromptProperties.getProperty("company.find.error", sw_company_id));
            throw new Exception(e);
        }
        return company;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Map<String, Object> xcrefund(Identifier identifier, String out_trade_no, String transaction_id, String sd_cash_id, int total_fee, int refund_fee, Tb_wx_pay_info info) throws Exception {
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String result = "";
        try {
            WxSpAPIV3Common.initCert(info);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        String url = XcbConstantValue.wx_apiv3_refund_url;
        URIBuilder uriBuilder = new URIBuilder(url);
        HashMap<String, Object> amountMap = new HashMap<String, Object>();
        amountMap.put("refund", refund_fee);
        amountMap.put("total", total_fee);
        amountMap.put("currency", "CNY");
        JSONObject amount = JSONObject.fromObject(amountMap);
        String notify_url = XcbConstantValue.wx_apiv3_pay_notify_url.trim() + "_" + info.getSub_mchid().trim() + "_" + info.getSr_way() + "/refundNotify";
        HashMap<String, String> dataMap = new HashMap<String, String>();
        dataMap.put("sub_mchid", info.getSub_mchid());
        dataMap.put("transaction_id", transaction_id);
        dataMap.put("out_refund_no", sd_cash_id);
        dataMap.put("reason", info.getSr_refund_desc());
        dataMap.put("notify_url", notify_url);
        dataMap.put("amount", (String)amount);
        String reqdata = JSONObject.fromObject(dataMap).toString();
        CloseableHttpResponse response = null;
        try {
            HttpPost httpPost = new HttpPost(uriBuilder.build());
            StringEntity entity = new StringEntity(reqdata, Charset.forName("UTF-8"));
            entity.setContentType("application/json;charset=utf-8");
            httpPost.addHeader("Content-type", "application/json; charset=utf-8");
            httpPost.setHeader("Accept", "application/json");
            httpPost.setEntity((HttpEntity)entity);
            response = httpClient.execute((HttpUriRequest)httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("success,return body = " + result);
                result = "\u9000\u6b3e\u6210\u529f";
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else if (statusCode == 204) {
                result = "\u9000\u6b3e\u6210\u529f";
                this.log.info("success");
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                ret.put(XcbConstantValue.MSG, result);
            } else {
                result = EntityUtils.toString((HttpEntity)response.getEntity());
                this.log.info("failed,resp code = " + statusCode + ",return body = " + result);
                JSONObject jsonObj = JSONObject.fromObject((Object)result);
                ret.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                ret.put(XcbConstantValue.MSG, jsonObj.getString("message"));
            }
        }
        catch (Exception e) {
            this.log.error("\u5fae\u4fe1\u652f\u4ed8\u9000\u6b3eV3 \u8bf7\u6c42url={}\u5f02\u5e38 ", (Object)uriBuilder.build());
        }
        finally {
            if (null != response) {
                response.close();
            }
        }
        return ret;
    }

    static {
        httpClinet_map = new HashMap<String, CloseableHttpClient>();
    }
}

