/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.zf.wxtoyhk;

import com.jcg.common.PromptProperties;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import com.jcg.zf.wx.CertHttpUtil;
import com.jcg.zf.wx.Signature;
import com.jcg.zf.wx.UUidUtils;
import com.jcg.zf.wx.WXWithdrawTools;
import com.jcg.zf.wxtoyhk.RSAPubKey;
import com.jcg.zf.wxtoyhk.ReturnRsaXml;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class RSAKeyWXUtils {
    Logger log = LoggerFactory.getLogger(RSAKeyWXUtils.class);
    private static String PUBLIC_KEY_FILE_NAME = "public.pem";
    @Autowired
    private WXWithdrawTools WXWithdrawTools;
    private static Map<String, Object> localPubKey_map = new HashMap<String, Object>();
    private static String localPubKey;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) throws Exception {
        this.log.debug("=========RSAKeyWXUtils========");
        this.log.debug(identifier.toString());
        HashMap<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        String mchId = "";
        String mchKey = "";
        String company_id = "";
        if (param != null) {
            mchId = (String)param.get("mchId");
            mchKey = (String)param.get("mchKey");
            company_id = (String)param.get("company_id");
        }
        if (XcbConstantValue.PRODUCT_WX_PUBKEY.equalsIgnoreCase(functionCode)) {
            this.getPubKeyForRemote(mchId, mchKey, company_id);
        }
        return ret;
    }

    public String getPubKeyForRemote(String mchId, String mchKey, String company_id) throws Exception {
        RSAPubKey rsaPubKey = new RSAPubKey();
        rsaPubKey.setMch_id(mchId);
        rsaPubKey.setNonce_str(UUidUtils.getUUid());
        String sign = Signature.getSign(mchKey, rsaPubKey);
        rsaPubKey.setSign(sign);
        String rasPubXml = this.WXWithdrawTools.getXMLStringForObj(rsaPubKey);
        Tb_company company = new Tb_company();
        this.log.info("get pub xml = === {}", (Object)rasPubXml);
        String result = CertHttpUtil.postData("https://fraud.mch.weixin.qq.com/risk/getpublickey", rasPubXml, company);
        if (null != result) {
            ReturnRsaXml returnRSA = (ReturnRsaXml)this.WXWithdrawTools.changeXMLToOj(result, ReturnRsaXml.class);
            this.log.info(" return code == {}", (Object)returnRSA.getReturn_code());
            if ("SUCCESS".equals(returnRSA.getReturn_code())) {
                this.savePubKeyToLocal(returnRSA.getPub_key(), mchId);
            } else if ("FALL".equals(returnRSA.getReturn_code())) {
                this.log.info(" weixin return fall ==={}", (Object)returnRSA.toString());
            }
        }
        return "";
    }

    private void savePubKeyToLocal(String pubKey, String mchId) {
        String rsaPubKeyPath = PromptProperties.getProperty("rsaPubKeyPath");
        rsaPubKeyPath = rsaPubKeyPath + mchId + "/";
        File file = new File(rsaPubKeyPath + PUBLIC_KEY_FILE_NAME);
        String absolutePath = file.getAbsolutePath();
        Path path = Paths.get(absolutePath, new String[0]);
        Charset charset = Charset.forName("UTF-8");
        try (BufferedWriter writer = Files.newBufferedWriter(path, charset, StandardOpenOption.APPEND);){
            writer.write(pubKey);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String readLocalPubKey(String mchId) throws IOException {
        localPubKey = (String)localPubKey_map.get(mchId);
        if (XcbStringUtils.isNullOrBlank((Object)localPubKey)) {
            String rsaPubKeyPath = PromptProperties.getProperty("rsaPubKeyPath");
            rsaPubKeyPath = rsaPubKeyPath + mchId + "/";
            File file = new File(rsaPubKeyPath + PUBLIC_KEY_FILE_NAME);
            String absolutePath = file.getAbsolutePath();
            List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
            StringBuilder sb = new StringBuilder();
            for (String line : lines) {
                if (line.charAt(0) == '-') continue;
                sb.append(line);
                sb.append('\r');
            }
            localPubKey = sb.toString();
            localPubKey_map.put(mchId, localPubKey);
        }
        return localPubKey;
    }
}

