/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.thoughtworks.xstream.annotations.XStreamAlias
 */
package com.jcg.zf.wxtoyhk;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class RSAPubKey {
    @XStreamAlias(value="mch_id")
    private String mch_id;
    @XStreamAlias(value="partner_trade_no")
    private String partner_trade_no;
    @XStreamAlias(value="nonce_str")
    private String nonce_str;
    private String sign;
    private String sign_type;

    public String getMch_id() {
        return this.mch_id;
    }

    public void setMch_id(String mch_id) {
        this.mch_id = mch_id;
    }

    public String getPartner_trade_no() {
        return this.partner_trade_no;
    }

    public void setPartner_trade_no(String partner_trade_no) {
        this.partner_trade_no = partner_trade_no;
    }

    public String getNonce_str() {
        return this.nonce_str;
    }

    public void setNonce_str(String nonce_str) {
        this.nonce_str = nonce_str;
    }

    public String getSign() {
        return this.sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getSign_type() {
        return this.sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }
}

