/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.codec.binary.Base64
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.stereotype.Component
 */
package com.jcg.zf.wxtoyhk;

import com.jcg.zf.wxtoyhk.RSAKeyWXUtils;
import java.io.ByteArrayOutputStream;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class RSAUtils {
    Logger log = LoggerFactory.getLogger(RSAUtils.class);
    private static String RSA = "RSA";
    private static final int KEYLENGTH = 2048;
    private static final int RESERVESIZE = 11;
    private static final String CIPHERALGORITHM = "RSA/ECB/OAEPWITHSHA-1ANDMGF1PADDING";

    public String encrypt(byte[] plainBytes, PublicKey publicKey) throws Exception {
        int keyByteSize = 256;
        int encryptBlockSize = keyByteSize - 11;
        int nBlock = plainBytes.length / encryptBlockSize;
        if (plainBytes.length % encryptBlockSize != 0) {
            ++nBlock;
        }
        ByteArrayOutputStream outbuf = null;
        try {
            Cipher cipher = Cipher.getInstance(CIPHERALGORITHM);
            cipher.init(1, publicKey);
            outbuf = new ByteArrayOutputStream(nBlock * keyByteSize);
            for (int offset = 0; offset < plainBytes.length; offset += encryptBlockSize) {
                int inputLen = plainBytes.length - offset;
                if (inputLen > encryptBlockSize) {
                    inputLen = encryptBlockSize;
                }
                byte[] encryptedBlock = cipher.doFinal(plainBytes, offset, inputLen);
                outbuf.write(encryptedBlock);
            }
            outbuf.flush();
            byte[] encryptedData = outbuf.toByteArray();
            String string = Base64.encodeBase64String((byte[])encryptedData);
            return string;
        }
        catch (Exception e) {
            throw new Exception("ENCRYPT ERROR:", e);
        }
        finally {
            try {
                if (outbuf != null) {
                    outbuf.close();
                }
            }
            catch (Exception e) {
                throw new Exception("CLOSE ByteArrayOutputStream ERROR:", e);
            }
        }
    }

    public PublicKey loadPublicKey(String publicKeyStr) throws Exception {
        this.log.info("string key========={}", (Object)publicKeyStr);
        try {
            byte[] buffer = this.decodeBase64(publicKeyStr);
            KeyFactory keyFactory = KeyFactory.getInstance(RSA);
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
            return keyFactory.generatePublic(keySpec);
        }
        catch (NoSuchAlgorithmException e) {
            throw new Exception("\u65e0\u6b64\u7b97\u6cd5");
        }
        catch (InvalidKeySpecException e) {
            throw new Exception("\u516c\u94a5\u975e\u6cd5");
        }
        catch (NullPointerException e) {
            throw new Exception("\u516c\u94a5\u6570\u636e\u4e3a\u7a7a");
        }
    }

    public byte[] decodeBase64(String input) throws Exception {
        return Base64.decodeBase64((String)input);
    }

    public String encodeBase64(byte[] input) throws Exception {
        return Base64.encodeBase64String((byte[])input);
    }

    public void printPublicKeyInfo(PublicKey publicKey) {
        RSAPublicKey rsaPublicKey = (RSAPublicKey)publicKey;
        this.log.info("----------RSAPublicKey----------");
        this.log.info("Modulus.length=" + rsaPublicKey.getModulus().bitLength());
        this.log.info("Modulus=" + rsaPublicKey.getModulus().toString());
        this.log.info("PublicExponent.length=" + rsaPublicKey.getPublicExponent().bitLength());
        this.log.info("PublicExponent=" + rsaPublicKey.getPublicExponent().toString());
    }

    public String encryptData(String data, String mchId) throws Exception {
        String pubKey = RSAKeyWXUtils.readLocalPubKey(mchId);
        this.log.debug("pubKey================={}", (Object)pubKey);
        PublicKey publicKey = this.loadPublicKey(pubKey);
        return this.encrypt(data.getBytes("UTF-8"), publicKey);
    }
}

