/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 *  org.springframework.transaction.annotation.Transactional
 */
package com.jcg.zf.zfb;

import com.jcg.common.PromptProperties;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

public class RSAKeyZFBUtils {
    Logger log = LoggerFactory.getLogger(RSAKeyZFBUtils.class);
    private static String PUBLIC_KEY_FILE_NAME = "rsa_public_key.pem";
    private static String PRIVATE_KEY_FILE_NAME = "rsa_private_key_pkcs8.pem";
    private static Map<String, Map<String, Object>> localKeyzfb_map = new HashMap<String, Map<String, Object>>();
    private static Map<String, Object> localKeyzfb;

    @Transactional
    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) throws Exception {
        this.log.debug("=========AdPlayServiceImpl========");
        this.log.debug(identifier.toString());
        Map<String, Object> ret = new HashMap<String, Object>();
        String functionCode = identifier.getFunctionCode();
        String mchId = "";
        if (param != null) {
            mchId = (String)param.get("mchId");
        }
        if (XcbConstantValue.GET_ZFB_PUBKEY.equalsIgnoreCase(functionCode)) {
            ret = RSAKeyZFBUtils.readLocalKey(mchId);
        }
        return ret;
    }

    public static Map<String, Object> readLocalKey(String mchId) throws IOException {
        localKeyzfb = localKeyzfb_map.get(mchId);
        if (localKeyzfb == null) {
            HashMap<String, Object> keyMap = new HashMap<String, Object>();
            String pubkey = RSAKeyZFBUtils.readLocalPubKey(mchId);
            String prikey = RSAKeyZFBUtils.readLocalPriKey(mchId);
            keyMap.put("pubkey", pubkey);
            keyMap.put("prikey", prikey);
            localKeyzfb = keyMap;
            localKeyzfb_map.put(mchId, localKeyzfb);
        }
        return localKeyzfb;
    }

    private static String readLocalPubKey(String mchId) throws IOException {
        String rsaPubKeyPath = PromptProperties.getProperty("rsaZfbKeyPath");
        rsaPubKeyPath = rsaPubKeyPath + mchId + "/";
        File file = new File(rsaPubKeyPath + PUBLIC_KEY_FILE_NAME);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        return sb.toString();
    }

    private static String readLocalPriKey(String mchId) throws IOException {
        String rsaPubKeyPath = PromptProperties.getProperty("rsaZfbKeyPath");
        rsaPubKeyPath = rsaPubKeyPath + mchId + "/";
        File file = new File(rsaPubKeyPath + PRIVATE_KEY_FILE_NAME);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        return sb.toString();
    }
}

