/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.alipay.api.AlipayRequest
 *  com.alipay.api.DefaultAlipayClient
 *  com.alipay.api.request.AlipayTradeRefundRequest
 *  com.alipay.api.response.AlipayTradeRefundResponse
 *  com.jcg.common.model.GenericCaller
 *  com.jcg.common.model.Identifier
 *  com.jcg.common.model.XcbConstantValue
 *  com.jcg.common.model.XcbStringUtils
 *  com.jcg.company.model.Tb_company
 *  org.springframework.stereotype.Service
 */
package com.jcg.zf.zfb;

import com.alipay.api.AlipayRequest;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.request.AlipayTradeRefundRequest;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.jcg.common.BaseService;
import com.jcg.common.model.GenericCaller;
import com.jcg.common.model.Identifier;
import com.jcg.common.model.XcbConstantValue;
import com.jcg.common.model.XcbStringUtils;
import com.jcg.company.model.Tb_company;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class ZFBzfCommon
extends BaseService
implements GenericCaller {
    private static Map<String, Object> keyMap;
    private static Map<String, Map<String, Object>> cert_map;

    public Map<String, Object> genericCall(Identifier identifier, Map<String, Object> param) {
        return null;
    }

    private static void initCert(Tb_company company) throws Exception {
        keyMap = cert_map.get(company.getSd_company_id());
        if (keyMap == null) {
            String publicKey = ZFBzfCommon.readLocalPubKey(company.getSr_zfb_public_path());
            String privateKey = ZFBzfCommon.readLocalPriKey(company.getSr_zfb_privatekey_path());
            keyMap = new HashMap<String, Object>();
            keyMap.put("publicKey", publicKey);
            keyMap.put("privateKey", privateKey);
            cert_map.put(company.getSd_company_id(), keyMap);
        }
    }

    public static String readLocalPubKey(String filePath) throws IOException {
        File file = new File(filePath);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        return sb.toString();
    }

    public static String readLocalPriKey(String filePath) throws IOException {
        File file = new File(filePath);
        String absolutePath = file.getAbsolutePath();
        List<String> lines = Files.readAllLines(Paths.get(absolutePath, new String[0]), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            if (line.charAt(0) == '-') continue;
            sb.append(line);
            sb.append('\r');
        }
        return sb.toString();
    }

    public Map<String, Object> xcrefund(Identifier identifier, String out_trade_no, String transaction_id, String sd_cash_id, BigDecimal total_fee, BigDecimal refund_fee, Tb_company company) {
        String result = "";
        HashMap<String, Object> map = new HashMap<String, Object>();
        this.log.info("--------------------------------\u652f\u4ed8\u5b9d\u9000\u6b3e\u4e0b\u5355\u5f00\u59cb-----------------------------------");
        try {
            ZFBzfCommon.initCert(company);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        String publicKey = XcbStringUtils.getObjtoString((Object)keyMap.get("publicKey"));
        String privateKey = XcbStringUtils.getObjtoString((Object)keyMap.get("privateKey"));
        AlipayTradeRefundResponse response = null;
        DefaultAlipayClient alipayClient = new DefaultAlipayClient(XcbConstantValue.zfb_api_url, company.getSr_yh_zfb_appid(), privateKey, "json", "GBK", publicKey, "RSA2");
        AlipayTradeRefundRequest request = new AlipayTradeRefundRequest();
        try {
            String sr_refund_fee = XcbStringUtils.getObjtoString((Object)refund_fee);
            request.setBizContent("{\"out_trade_no\":\"" + out_trade_no + "\",\"trade_no\":\"" + transaction_id + "\",\"refund_amount\":" + sr_refund_fee + ",\"refund_reason\":\"\u6b63\u5e38\u9000\u6b3e\",\"out_request_no\":\"" + sd_cash_id + "\"  }");
            response = (AlipayTradeRefundResponse)alipayClient.execute((AlipayRequest)request);
            if (response.isSuccess()) {
                this.log.info("--------------------------------\u652f\u4ed8\u5b9d\u9000\u6b3e\u8c03\u7528\u6210\u529f----------------------------------");
                if (XcbConstantValue.zfb_rtn_code.equals(response.getCode())) {
                    this.log.info("----------------------------\u9000\u6b3e\u6210\u529f----------------------------");
                    result = "\u9000\u6b3e\u6210\u529f";
                    map.put(XcbConstantValue.MSG, result);
                    map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_SUCCESS);
                } else {
                    result = response.getSubMsg();
                    map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                    map.put(XcbConstantValue.MSG, "\u9000\u6b3e\u5931\u8d25:" + result);
                    this.log.info("--------------------------------\u652f\u4ed8\u5b9d\u9000\u6b3e\u8c03\u7528\u5931\u8d25:----------------------------------");
                }
            } else {
                result = response.getSubMsg();
                map.put(XcbConstantValue.STATUS, XcbConstantValue.OPERA_FAIL);
                map.put(XcbConstantValue.MSG, "\u9000\u6b3e\u5931\u8d25:" + result);
                this.log.info("--------------------------------\u652f\u4ed8\u5b9d\u9000\u6b3e\u8c03\u7528\u5931\u8d25----------------------------------");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        this.log.info("--------------------------------\u652f\u4ed8\u5b9d\u9000\u6b3e\u4e0b\u5355\u7ed3\u675f-----------------------------------");
        this.initResultMap(map);
        return map;
    }

    static {
        cert_map = new HashMap<String, Map<String, Object>>();
    }
}

