// app.js - 小程序入口，全局登录状态管理
const auth = require('./utils/auth.js')

App({
  globalData: {
    userInfo: null,
    isLoggedIn: false,
    // 权限控制
    isAgent: false,
    // 功能开关
    enableDeposit: true,  // 收/退押金功能开关
    enableStats: true     // 业务统计功能开关
  },

  onLaunch(options) {
    // 检查登录状态
    const token = auth.getToken()
    if (token) {
      this.globalData.isLoggedIn = true
      this.globalData.isAgent = auth.isAgent()
      // 验证token有效性
      this.checkLoginStatus()
    } else {
      // 未登录，跳转到登录页
      wx.redirectTo({
        url: '/pages/login/login'
      })
    }
  },

  checkLoginStatus() {
    const API = require('./utils/api.js')
    API.request({
      url: '/merchant/info',
      method: 'GET'
    }).then(res => {
      if (res.code === 0 || res.code === 200) {
        this.globalData.userInfo = res.data
        this.globalData.isLoggedIn = true
        this.globalData.isAgent = auth.isAgent()
        // 根据用户类型设置功能开关
        if (res.data.enable_deposit !== undefined) {
          this.globalData.enableDeposit = !!res.data.enable_deposit
        }
      } else {
        this.handleLoginFailed()
      }
    }).catch(err => {
      if (err.statusCode === 401) {
        this.handleLoginFailed()
      }
    })
  },

  handleLoginFailed() {
    // token无效或过期，清除登录状态
    auth.clearAuth()
    this.globalData.isLoggedIn = false
    this.globalData.userInfo = null
    this.globalData.isAgent = false
    wx.redirectTo({
      url: '/pages/login/login'
    })
  },

  // 通用跳转登录页方法
  goToLogin() {
    auth.clearAuth()
    this.globalData.isLoggedIn = false
    this.globalData.userInfo = null
    this.globalData.isAgent = false
    wx.redirectTo({
      url: '/pages/login/login'
    })
  }
})
