const API = require('../../utils/api.js')
Page({
  data: { balance: null, isAgent: false },
  onLoad() { const auth = require('../../utils/auth.js'); this.setData({ isAgent: auth.isAgent() }); this.loadBalance() },
  onShow() { this.loadBalance() },
  onPullDownRefresh() { this.loadBalance().finally(() => wx.stopPullDownRefresh()) },
  loadBalance() {
    return API.getBalance().then(res => {
      if (res.data) { this.setData({ balance: res.data }) }
    }).catch(() => {})
  },
  fmtMoney(v) { if (!v && v !== 0) return '0.00'; return parseFloat(v).toFixed(2) }
})