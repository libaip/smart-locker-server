const API = require('../../utils/api.js')
Page({
  data: {
    stats: null, loading: false,
    startDate: '', endDate: '',
    isAgent: false
  },
  onLoad() {
    const auth = require('../../utils/auth.js');
    this.setData({ isAgent: auth.isAgent() });
    const now = new Date()
    const monthStart = now.getFullYear() + '-' + (now.getMonth()+1).toString().padStart(2,'0') + '-01'
    const today = now.getFullYear() + '-' + (now.getMonth()+1).toString().padStart(2,'0') + '-' + now.getDate().toString().padStart(2,'0')
    this.setData({ startDate: monthStart, endDate: today })
    this.loadStats()
  },
  onStartDateChange(e) { this.setData({ startDate: e.detail.value }) },
  onEndDateChange(e) { this.setData({ endDate: e.detail.value }) },
  onQuery() { this.loadStats() },
  loadStats() {
    this.setData({ loading: true })
    let params = {}
    if (this.data.startDate) params.start_date = this.data.startDate
    if (this.data.endDate) params.end_date = this.data.endDate
    API.getBusinessStats(params).then(res => {
      if (res.data) { this.setData({ stats: res.data }) }
      this.setData({ loading: false })
    }).catch(() => { this.setData({ loading: false }) })
  },
  fmtMoney(v) { if (!v && v !== 0) return '0.00'; return parseFloat(v).toFixed(2) }
})