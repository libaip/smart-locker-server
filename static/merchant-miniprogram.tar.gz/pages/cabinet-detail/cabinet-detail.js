// pages/cabinet-detail/cabinet-detail.js
const API = require('../../utils/api.js')

var STATUS_MAP = {
  0: { class: 'slot-free', text: '空闲', canOpen: true },
  1: { class: 'slot-free', text: '空闲', canOpen: true },
  2: { class: 'slot-using', text: '使用中', canOpen: true },
  3: { class: 'slot-fault', text: '故障', canOpen: false },
  4: { class: 'slot-locked', text: '锁定', canOpen: false }
}

function mapSlot(slot) {
  var s = STATUS_MAP[slot.status] || STATUS_MAP[0]
  return Object.assign({}, slot, { statusClass: s.class, statusText: s.text, canOpen: s.canOpen, cellClass: s.class })
}

Page({
  data: {
    cabinetId: null,
    locationId: null,
    cabinet: null,
    cabinets: [],
    slots: [],
    loading: true,
    selectedSlot: null, selectedSlotIndex: -1,
    showSlotModal: false,
    showStatusModal: false,
    statusTargetSlot: null,
    statusPickerIndex: 0,
    statusOptions: [
      { value: 0, label: '空闲' },
      { value: 2, label: '使用中' },
      { value: 3, label: '故障' },
      { value: 4, label: '锁定' }
    ],
    actionLoading: false,
    queryLoading: false,
    editSlotLabel: '',
    occupiedCount: 0,
    occupancyRate: 0
  },

  onLoad: function(options) {
    var cabinetId = options.cabinetId || options.cabinet_id || null
    var locationId = options.locationId || options.location_id || null
    this.setData({ cabinetId: cabinetId, locationId: locationId })
    if (cabinetId) {
      this.loadCabinetDetail(cabinetId)
    } else if (locationId) {
      this.loadCabinetsByLocation(locationId)
    }
  },

  onPullDownRefresh: function() {
    if (this.data.cabinetId) {
      this.loadCabinetDetail(this.data.cabinetId)
    } else if (this.data.locationId) {
      this.loadCabinetsByLocation(this.data.locationId)
    }
  },

  loadCabinetDetail: function(cabinetId) {
    var that = this
    this.setData({ loading: true })
    API.getSlots(cabinetId).then(function(slotsRes) {
      var slots = []
      var cabinetInfo = {}
      if (slotsRes.data && slotsRes.data.slots) {
        slots = slotsRes.data.slots
        cabinetInfo = slotsRes.data.cabinet || {}
      } else if (slotsRes.data && Array.isArray(slotsRes.data)) {
        slots = slotsRes.data
      }
      slots = slots.map(mapSlot)
      var occupiedCount = slots.filter(function(s) { return s.status === 2 }).length
      var occupancyRate = slots.length > 0 ? Math.round((occupiedCount / slots.length) * 100) : 0
      var online = cabinetInfo.is_online === 1 || cabinetInfo.is_online === true
      if (!online && cabinetInfo.last_heartbeat) {
        var lastHb = new Date(cabinetInfo.last_heartbeat + 'Z')
        online = (Date.now() - lastHb.getTime()) < 30000
      }
      var code = cabinetInfo.cabinet_code || cabinetInfo.code || cabinetInfo.serial_no || '--'
      var name = cabinetInfo.cabinet_code || cabinetInfo.name || code
      that.setData({
        cabinet: Object.assign({}, cabinetInfo, { id: cabinetId, code: code, name: name, online: online }),
        slots: slots,
        loading: false,
        occupiedCount: occupiedCount,
        occupancyRate: occupancyRate
      })
    }).catch(function(err) {
      console.error('loadCabinetDetail error', err)
      that.setData({ loading: false })
    })
  },

  loadCabinetsByLocation: function(locationId) {
    var that = this
    this.setData({ loading: true })
    API.getCabinets(locationId).then(function(res) {
      var cabinets = []
      if (res.data && Array.isArray(res.data)) { cabinets = res.data }
      else if (res.data && res.data.list) { cabinets = res.data.list }
      else if (res.data && res.data.cabinets) { cabinets = res.data.cabinets }
      cabinets = cabinets.map(function(cab) {
        return Object.assign({}, cab, {
          name: cab.cabinet_code || cab.name || cab.serial_no || '--',
          code: cab.cabinet_code || cab.code || '--'
        })
      })
      if (cabinets.length > 0 && !that.data.cabinetId) {
        that.setData({ cabinets: cabinets, cabinet: cabinets[0], cabinetId: cabinets[0].id })
        that.loadCabinetDetail(cabinets[0].id)
      } else {
        that.setData({ cabinets: cabinets, loading: false })
      }
    }).catch(function() { that.setData({ loading: false }) })
  },

  onCabinetChange: function(e) {
    var cabinet = this.data.cabinets[e.detail.value]
    if (cabinet) {
      this.setData({ cabinet: cabinet, cabinetId: cabinet.id, slots: [] })
      this.loadCabinetDetail(cabinet.id)
    }
  },

  onSlotTap: function(e) {
    var slot = e.currentTarget.dataset.slot
    var index = e.currentTarget.dataset.index
    this.setData({ selectedSlot: slot, selectedSlotIndex: index, showSlotModal: true, editSlotLabel: slot.slot_label || '' })
    this.updateSlotCellClass(index, true)
  },

  onCloseSlotModal: function() {
    this.setData({ selectedSlot: null, selectedSlotIndex: -1, showSlotModal: false })
    this.updateSlotCellClass(this.data.selectedSlotIndex, false)
  },

  onQuickOpen: function(e) {
    var slot = e.currentTarget.dataset.slot
    var index = e.currentTarget.dataset.index
    if (!slot.canOpen) {
      wx.showToast({ title: '该柜门无法开门', icon: 'none' })
      return
    }
    var that = this
    wx.showModal({
      title: '确认开门',
      content: '确定要远程开启柜门 ' + (slot.slot_number || slot.slot_no || slot.id) + ' 吗？',
      success: function(res) { if (res.confirm) that.doOpenSlot(slot) }
    })
  },

  onOpenSlot: function() {
    if (!this.data.selectedSlot || !this.data.cabinetId) return
    var that = this
    wx.showModal({
      title: '确认开门',
      content: '确定要远程开启此柜门吗？',
      success: function(res) { if (res.confirm) that.doOpenSlot(that.data.selectedSlot) }
    })
  },

  doOpenSlot: function(slot) {
    var that = this
    var slotId = slot.id || slot.slot_id
    this.setData({ actionLoading: true })
    API.openSlot(that.data.cabinetId, slotId).then(function() {
      that.setData({ actionLoading: false, showSlotModal: false })
      wx.showToast({ title: '开锁指令已发送', icon: 'success' })
      setTimeout(function() { that.loadCabinetDetail(that.data.cabinetId) }, 2000)
    }).catch(function(err) {
      that.setData({ actionLoading: false })
      wx.showToast({ title: (err && err.message) || '开锁失败', icon: 'none' })
    })
  },

  // 一键开门
  // 开门（底部栏：对选中柜门操作）
  onOpenSelected: function() {
    var selected = this.data.selectedSlot;
    if (!selected) { wx.showToast({ title: '请先点击选择柜门', icon: 'none' }); return; }
    if (!selected.canOpen) { wx.showToast({ title: '该柜门无法开门', icon: 'none' }); return; }
    var that = this;
    wx.showModal({
      title: '确认开门',
      content: '确定要远程开启柜门 ' + (selected.slot_number || selected.slot_no || selected.id) + ' 吗？',
      success: function(res) { if (res.confirm) that.doOpenSlot(selected) }
    })
  },

  onOpenAll: function() {
    var that = this
    var openable = this.data.slots.filter(function(s) { return s.canOpen })
    if (openable.length === 0) {
      wx.showToast({ title: '没有可开门的柜门', icon: 'none' })
      return
    }
    wx.showModal({
      title: '一键开门',
      content: '将开启 ' + openable.length + ' 个柜门（不含故障和锁定的门），确认？',
      success: function(res) {
        if (res.confirm) {
          that.setData({ actionLoading: true })
          API.openAllSlots(that.data.cabinetId).then(function(resp) {
            that.setData({ actionLoading: false })
            wx.showToast({ title: (resp.data && resp.data.message) || '开锁指令已发送', icon: 'success' })
            setTimeout(function() { that.loadCabinetDetail(that.data.cabinetId) }, 2000)
          }).catch(function(err) {
            that.setData({ actionLoading: false })
            wx.showToast({ title: (err && err.message) || '操作失败', icon: 'none' })
          })
        }
      }
    })
  },

  // 修改状态（底部栏：需先选择柜门）
  onModifyStatus: function() {
    var selected = this.data.selectedSlot;
    if (!selected) { wx.showToast({ title: '请先点击选择柜门', icon: 'none' }); return; }
    this.onChangeSlotStatus();
  },
  _onModifyStatus_old: function() {
    var that = this
    var slotNumbers = this.data.slots.map(function(s) { return s.slot_number || s.slot_no || s.id })
    if (slotNumbers.length === 0) {
      wx.showToast({ title: '暂无柜门数据', icon: 'none' })
      return
    }
    wx.showModal({
      title: '修改柜门状态',
      content: '请先点击柜门选择要修改的柜门',
      showCancel: false
    })
  },

  // 弹窗里点修改状态
  onChangeSlotStatus: function() {
    var slot = this.data.selectedSlot
    if (!slot) return
    // 找到当前状态对应的picker index
    var idx = 0
    for (var i = 0; i < this.data.statusOptions.length; i++) {
      if (this.data.statusOptions[i].value === slot.status) { idx = i; break }
    }
    this.setData({
      statusTargetSlot: slot,
      statusPickerIndex: idx,
      showSlotModal: false,
      showStatusModal: true
    })
  },

  onStatusPickerChange: function(e) {
    this.setData({ statusPickerIndex: e.detail.value })
  },

  onConfirmStatusChange: function() {
    var that = this
    var slot = this.data.statusTargetSlot
    var newStatus = this.data.statusOptions[this.data.statusPickerIndex].value
    if (!slot || !this.data.cabinetId) return
    if (newStatus === slot.status) {
      wx.showToast({ title: '状态未变化', icon: 'none' })
      return
    }
    this.setData({ actionLoading: true })
    API.updateSlotStatus(this.data.cabinetId, slot.id || slot.slot_id, newStatus).then(function() {
      that.setData({ actionLoading: false, showStatusModal: false })
      wx.showToast({ title: '状态已修改', icon: 'success' })
      setTimeout(function() { that.loadCabinetDetail(that.data.cabinetId) }, 1000)
    }).catch(function(err) {
      that.setData({ actionLoading: false })
      wx.showToast({ title: (err && err.message) || '修改失败', icon: 'none' })
    })
  },

  onCloseStatusModal: function() {
    this.setData({ showStatusModal: false, statusTargetSlot: null })
  },

  // 查询选中柜门状态
  onQueryStatus: function() {
    var selected = this.data.selectedSlot;
    if (!selected) { wx.showToast({ title: '请先点击选择柜门', icon: 'none' }); return; }
    this.setData({ statusTargetSlot: selected, showSlotModal: false, showStatusModal: false });
    this.onQuerySlotStatus();
  },

  // 弹窗里查询单个柜门
  onQuerySlotStatus: function() {
    if (!this.data.selectedSlot || !this.data.cabinetId) return
    var that = this
    var slotId = this.data.selectedSlot.id || this.data.selectedSlot.slot_id
    this.setData({ queryLoading: true })
    API.getSlotStatus(this.data.cabinetId, slotId).then(function(res) {
      that.setData({ queryLoading: false })
      if (res.data) {
        var mapped = mapSlot(res.data)
        that.setData({ selectedSlot: mapped })
        // 更新列表中对应slot
        var slots = that.data.slots
        for (var i = 0; i < slots.length; i++) {
          if (slots[i].id === mapped.id) { slots[i] = mapped; break }
        }
        that.setData({ slots: slots })
      }
      wx.showToast({ title: '状态已更新', icon: 'success' })
    }).catch(function() {
      that.setData({ queryLoading: false })
      wx.showToast({ title: '查询失败', icon: 'none' })
    })
  },

  updateSlotCellClass(idx, selected) {
    if (idx < 0 || idx >= this.data.slots.length) return
    const key = "slots[" + idx + "].cellClass"
    const slot = this.data.slots[idx]
    this.setData({ [key]: selected ? slot.statusClass + " slot-selected" : slot.statusClass })
  },

  onLabelInput: function(e) {
    this.setData({ editSlotLabel: e.detail.value })
  },
  onSaveLabel: function() {
    var that = this
    var slot = this.data.selectedSlot
    if (!slot || !this.data.cabinetId) return
    var label = this.data.editSlotLabel
    API.updateSlotLabel(this.data.cabinetId, slot.id || slot.slot_id, label).then(function() {
      wx.showToast({ title: '标签已保存', icon: 'success' })
      // 更新本地数据
      slot.slot_label = label
      that.setData({ selectedSlot: slot })
      var slots = that.data.slots
      for (var i = 0; i < slots.length; i++) {
        if (slots[i].id === (slot.id || slot.slot_id)) {
          slots[i].slot_label = label
          break
        }
      }
      that.setData({ slots: slots })
    }).catch(function(err) {
      wx.showToast({ title: (err && err.message) || '保存失败', icon: 'none' })
    })
  },
  onRefreshSlots: function() {
    if (this.data.cabinetId) this.loadCabinetDetail(this.data.cabinetId)
  }
})
