const API = require('../../utils/api.js')
Page({
  data: { devices: [], loading: true, isAgent: false },
  onLoad() { const auth = require('../../utils/auth.js'); this.setData({ isAgent: auth.isAgent() }); this.loadDevices() },
  onShow() { this.loadDevices() },
  onPullDownRefresh() { this.loadDevices().finally(() => wx.stopPullDownRefresh()) },
  loadDevices() {
    this.setData({ loading: true })
    return API.getLocations().then(res => {
      let locations = res.data || []
      let allDevices = []
      let promises = []
      locations.forEach(loc => {
        if (loc.cabinet_count > 0) {
          promises.push(API.getCabinets(loc.id).then(cabRes => {
            let cabinets = cabRes.data || []
            cabinets.forEach(c => {
              allDevices.push({
                id: c.id, cabinet_code: c.cabinet_code, name: c.name,
                location_name: loc.name, location_id: loc.id,
                isOnline: c.last_heartbeat && (Date.now() - new Date(c.last_heartbeat).getTime()) < 60000,
                last_heartbeat: c.last_heartbeat
              })
            })
          }).catch(() => {}))
        }
      })
      return Promise.all(promises).then(() => {
        // Load slot counts for each device
        let slotPromises = allDevices.map(d => {
          return API.getCabinetStatus(d.id).then(statRes => {
            if (statRes.data) {
              d.total_slots = statRes.data.total_slots || 0
              d.free_slots = statRes.data.free_slots || 0
              d.using_slots = statRes.data.using_slots || 0
              d.fault_slots = statRes.data.fault_slots || 0
              d.isOnline = statRes.data.online || false
            }
          }).catch(() => {})
        })
        return Promise.all(slotPromises).then(() => {
          this.setData({ devices: allDevices, loading: false })
        })
      })
    }).catch(() => { this.setData({ loading: false }) })
  },
  onDeviceTap(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: '/pages/cabinet-detail/cabinet-detail?cabinetId=' + id })
  }
})