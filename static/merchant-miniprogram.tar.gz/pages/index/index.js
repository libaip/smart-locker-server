// pages/index/index.js - 支付宝风格首页
const API = require('../../utils/api.js')
const auth = require('../../utils/auth.js')

Page({
  data: {
    userName: '用户',
    isAgent: false,
    hasChargeLocation: false,
    dashboard: {
      today_orders: 0, today_income: 0,
      yesterday_orders: 0, yesterday_income: 0,
      month_orders: 0, month_income: 0,
      online_devices: 0, total_devices: 0,
      occupied_slots: 0, location_count: 0
    },
    loading: true
  },

  onLoad() {
    const userInfo = auth.getUserInfo()
    const isAgent = auth.isAgent()
    this.setData({ isAgent })
    if (userInfo) {
      this.setData({ userName: userInfo.name || '用户' })
    }
  },

  onShow() {
    this.loadDashboard()
  },

  onPullDownRefresh() {
    this.loadDashboard().finally(() => { wx.stopPullDownRefresh() })
  },

  loadDashboard() {
    return API.getDashboard().then(res => {
      if (res.data) {
        this.setData({ 
          dashboard: res.data, 
          loading: false,
          hasChargeLocation: res.data.has_charge_location || false
        })
      }
    }).catch(() => { this.setData({ loading: false }) })
  },

  fmtMoney(amount) {
    if (!amount && amount !== 0) return '0.00'
    return parseFloat(amount).toFixed(2)
  },

  // 快捷入口
  onLocationsTap() { wx.switchTab({ url: '/pages/locations/locations' }) },
  onOrdersTap() { wx.navigateTo({ url: '/pages/orders/orders' }) },
  onDeviceStatusTap() { wx.navigateTo({ url: '/pages/device-status/device-status' }) },
  onBizStatsTap() { wx.navigateTo({ url: '/pages/biz-stats/biz-stats' }) },
  onBalanceTap() { wx.navigateTo({ url: '/pages/balance/balance' }) }
})