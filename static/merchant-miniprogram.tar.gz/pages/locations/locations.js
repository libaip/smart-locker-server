// pages/locations/locations.js - 网点管理
const API = require('../../utils/api.js')
const auth = require('../../utils/auth.js')

Page({
  data: {
    locations: [],
    loading: true,
    isAgent: false
  },

  onLoad() {
    const isAgent = auth.isAgent()
    this.setData({ isAgent })
  },

  onShow() {
    this.loadLocations()
  },

  onPullDownRefresh() {
    this.loadLocations()
  },

  // 加载网点列表
  loadLocations() {
    this.setData({ loading: true })
    
    API.getLocations()
      .then(res => {
        let locations = []
        
        if (res.data && Array.isArray(res.data)) {
          locations = res.data
        } else if (res.data && res.data.list) {
          locations = res.data.list
        } else if (res.data && res.data.locations) {
          locations = res.data.locations
        }
        
        this.setData({
          locations: locations,
          loading: false
        })
      })
      .catch(err => {
        this.setData({
          loading: false
        })
      })
  },

  // 点击网点，进入设备列表
  onLocationTap(e) {
    const locationId = e.currentTarget.dataset.id
    
    wx.navigateTo({
      url: '/pages/cabinet-detail/cabinet-detail?locationId=' + locationId
    })
  },

  // 获取状态文本
  getStatusText(status) {
    const statusMap = {
      normal: '正常',
      stopped: '停用',
      maintaining: '维护中',
      0: '正常',
      1: '停用',
      2: '维护中'
    }
    return statusMap[status] || '正常'
  },

  // 获取状态样式
  getStatusClass(status) {
    const classMap = {
      normal: 'status-normal',
      stopped: 'status-stopped',
      maintaining: 'status-maintaining',
      0: 'status-normal',
      1: 'status-stopped',
      2: 'status-maintaining'
    }
    return classMap[status] || 'status-normal'
  }
})
