// pages/mine/mine.js - 个人中心（支付宝风格）
const API = require('../../utils/api.js')
const auth = require('../../utils/auth.js')

Page({
  data: {
    merchant: { name: '', contact: '', phone: '' },
    isAgent: false,
    dashboard: {},
    showPasswordModal: false,
    passwordLoading: false,
    passwordForm: { oldPassword: '', newPassword: '', confirmPassword: '' }
  },

  onLoad() { this.setData({ isAgent: auth.isAgent() }) },

  onShow() {
    this.loadMerchantInfo()
    this.loadDashboard()
  },

  loadMerchantInfo() {
    API.getInfo().then(res => {
      if (res.data) {
        this.setData({ merchant: { name: res.data.name || res.data.merchant_name || '', contact: res.data.contact || res.data.contact_name || '--', phone: res.data.phone || res.data.mobile || '--' } })
        auth.setUserInfo(res.data)
      }
    }).catch(() => {})
  },

  loadDashboard() {
    API.getDashboard().then(res => {
      if (res.data) { this.setData({ dashboard: res.data }) }
    }).catch(() => {})
  },

  fmtMoney(amount) {
    if (!amount && amount !== 0) return '0.00'
    return parseFloat(amount).toFixed(2)
  },

  // 快捷入口
  onLocationsTap() { wx.switchTab({ url: '/pages/locations/locations' }) },
  onOrdersTap() { wx.navigateTo({ url: '/pages/orders/orders' }) },
  onDeviceManageTap() { wx.switchTab({ url: '/pages/locations/locations' }) },
  onDeviceStatusTap() { wx.navigateTo({ url: '/pages/device-status/device-status' }) },
  onBizStatsTap() { wx.navigateTo({ url: '/pages/biz-stats/biz-stats' }) },

  onBalanceTap() { wx.navigateTo({ url: '/pages/balance/balance' }) },

  // 修改密码
  onChangePassword() { this.setData({ showPasswordModal: true, passwordForm: { oldPassword: '', newPassword: '', confirmPassword: '' } }) },
  onClosePasswordModal() { this.setData({ showPasswordModal: false }) },
  onOldPasswordInput(e) { this.setData({ 'passwordForm.oldPassword': e.detail.value }) },
  onNewPasswordInput(e) { this.setData({ 'passwordForm.newPassword': e.detail.value }) },
  onConfirmPasswordInput(e) { this.setData({ 'passwordForm.confirmPassword': e.detail.value }) },

  onSubmitPassword() {
    const { oldPassword, newPassword, confirmPassword } = this.data.passwordForm
    if (!oldPassword) { wx.showToast({ title: '请输入原密码', icon: 'none' }); return }
    if (!newPassword || newPassword.length < 6) { wx.showToast({ title: '新密码至少6位', icon: 'none' }); return }
    if (newPassword !== confirmPassword) { wx.showToast({ title: '两次密码不一致', icon: 'none' }); return }
    this.setData({ passwordLoading: true })
    API.changePassword(oldPassword, newPassword).then(() => {
      this.setData({ passwordLoading: false })
      wx.showToast({ title: '密码修改成功', icon: 'success' })
      this.onClosePasswordModal()
    }).catch(() => { this.setData({ passwordLoading: false }) })
  },

  onAbout() { wx.showModal({ title: '关于', content: '智能寄存柜商家端 v2.0.0', showCancel: false }) },

  onLogout() {
    wx.showModal({
      title: '提示', content: '确定要退出登录吗？', confirmColor: '#FF3B30',
      success: (res) => {
        if (res.confirm) {
          API.logout().catch(() => {}).finally(() => {
            auth.clearAuth()
            wx.redirectTo({ url: '/pages/login/login' })
          })
        }
      }
    })
  },

  preventTouchMove() {}
})
