// utils/api.js
const auth = require('./auth.js')

const BASE_URL = 'https://locker.cqdyxl.com/api'

function request(options) {
  const { url, method = 'GET', data = {}, header = {}, showLoading = true, hideErrorToast = false } = options
  if (showLoading) { wx.showLoading({ title: '加载中...', mask: true }) }
  const cookie = auth.getCookie()
  const requestHeader = { 'Content-Type': 'application/json', ...header }
  if (cookie) { requestHeader['Cookie'] = cookie }
  const userInfo = auth.getUserInfo()
  if (userInfo && userInfo.token) { requestHeader['Authorization'] = 'Bearer ' + userInfo.token }
  return new Promise((resolve, reject) => {
    wx.request({
      url: BASE_URL + url, method, data: data, header: requestHeader, timeout: 15000,
      success: (res) => {
        if (showLoading) { wx.hideLoading() }
        if (res.header && res.header['Set-Cookie']) { auth.setCookie(res.header['Set-Cookie']) }
        if (res.header && res.header['set-cookie']) { auth.setCookie(res.header['set-cookie']) }
        if (res.data.code === 0 || res.data.code === 200) { resolve(res.data) }
        else if (res.statusCode === 401 || res.data.code === 401) { handleUnauthorized(); reject({ statusCode: 401, message: res.data.message || '登录已过期' }) }
        else { if (!hideErrorToast) { wx.showToast({ title: res.data.message || '请求失败', icon: 'none', duration: 2000 }) } reject({ statusCode: res.statusCode, code: res.data.code, message: res.data.message || '请求失败' }) }
      },
      fail: (err) => { if (showLoading) { wx.hideLoading() } if (!hideErrorToast) { wx.showToast({ title: '网络请求失败', icon: 'none', duration: 2000 }) } reject({ statusCode: -1, message: '网络请求失败' }) }
    })
  })
}

function handleUnauthorized() { auth.clearAuth(); const pages = getCurrentPages(); const current = pages[pages.length - 1]; if (current && !current.route.includes('login')) { wx.redirectTo({ url: '/pages/login/login' }) } }
function get(url, data, options = {}) { return request({ url, method: 'GET', data, ...options }) }
function post(url, data, options = {}) { return request({ url, method: 'POST', data, ...options }) }
function put(url, data, options = {}) { return request({ url, method: 'PUT', data, ...options }) }

const merchantApi = {
  login: (phone, password) => post('/admin/merchant/login', { phone, password }, { showLoading: false }),
  agentLogin: (phone, password) => post('/admin/agent/login', { phone, password }, { showLoading: false }),
  getInfo: () => get('/merchant/info'),
  getDashboard: () => get('/merchant/dashboard'),
  getLocations: () => get('/merchant/locations'),
  getCabinets: (locationId) => get('/merchant/cabinets', locationId ? { location_id: locationId } : {}),
  getSlots: (cabinetId) => get('/merchant/cabinets/' + cabinetId + '/slots'),
  getOrders: (params) => get('/merchant/orders', params),
  getOrderDetail: (orderId) => get('/merchant/orders/' + orderId),
  openSlot: (cabinetId, slotId) => post('/merchant/cabinets/' + cabinetId + '/open-slot', { slot_id: slotId }),
  openAllSlots: (cabinetId) => post('/merchant/cabinets/' + cabinetId + '/open-all', {}),
  getCabinetStatus: (cabinetId) => get('/merchant/cabinets/' + cabinetId + '/status'),
  getSlotStatus: (cabinetId, slotId) => get('/merchant/cabinets/' + cabinetId + '/slots/' + slotId + '/status'),
  updateSlotStatus: (cabinetId, slotId, status) => put('/merchant/cabinets/' + cabinetId + '/slots/' + slotId + '/status', { status: status }),
  updateSlotLabel: (cabinetId, slotId, slot_label) => put('/merchant/cabinets/' + cabinetId + '/slots/' + slotId + '/label', { slot_label: slot_label }),
  getBusinessStats: (params) => get('/merchant/stats/business', params),
  getAgentStats: (agentId) => get('/admin/agent/stats', { agent_id: agentId }),
  changePassword: (oldPwd, newPwd) => post('/merchant/password', { old_password: oldPwd, new_password: newPwd }),
  logout: () => post('/merchant/logout', {}),
  getDeposits: (params) => get('/merchant/deposits', params),
  refundDeposit: (paymentId) => post('/merchant/deposits/' + paymentId + '/refund', {}),
  getBalance: () => get('/merchant/balance')
}

module.exports = { request, get, post, put, BASE_URL, ...merchantApi }
