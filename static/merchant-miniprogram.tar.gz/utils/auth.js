// utils/auth.js
const COOKIE_KEY = 'merchant_cookie'
const USER_INFO_KEY = 'merchant_user_info'
const LOGIN_STATUS_KEY = 'merchant_logged_in'
const ROLE_KEY = 'merchant_role'

function getCookie() { return wx.getStorageSync(COOKIE_KEY) || '' }
function setCookie(cookie) { if (cookie) { wx.setStorageSync(COOKIE_KEY, cookie) } }
function getUserInfo() { const info = wx.getStorageSync(USER_INFO_KEY); return info ? JSON.parse(info) : null }
function setUserInfo(userInfo) { wx.setStorageSync(USER_INFO_KEY, JSON.stringify(userInfo)) }
function clearAuth() { wx.removeStorageSync(COOKIE_KEY); wx.removeStorageSync(USER_INFO_KEY); wx.removeStorageSync(LOGIN_STATUS_KEY); wx.removeStorageSync(ROLE_KEY) }
function setLoggedIn(status) { wx.setStorageSync(LOGIN_STATUS_KEY, status) }
function isLoggedIn() { return !!wx.getStorageSync(LOGIN_STATUS_KEY) }
function getRole() { return wx.getStorageSync(ROLE_KEY) || 'merchant' }
function setRole(role) { wx.setStorageSync(ROLE_KEY, role) }
function isAgent() { return getRole() === 'agent' }

module.exports = { getCookie, setCookie, getUserInfo, setUserInfo, clearAuth, setLoggedIn, isLoggedIn, getRole, setRole, isAgent }
