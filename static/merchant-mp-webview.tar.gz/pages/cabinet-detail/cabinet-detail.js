var app = getApp();

Page({
  data: {
    cabinet: {},
    slots: [],
    loading: true,
    errMsg: "",
    selectedId: 0
  },

  onLoad: function(e) {
    if (e.id) this.load(e.id);
  },

  load: function(id) {
    var self = this;
    var tk = wx.getStorageSync('auth_token') || '';
    var url = (app.globalData && app.globalData.baseUrl) || 'https://locker.cqdyxl.com';
    self.setData({ loading: true, errMsg: "" });

    wx.request({
      url: url + "/api/merchant/cabinets/" + id + "/slots",
      header: { 'Authorization': tk ? 'Bearer ' + tk : '' },
      success: function(r) {
        self.setData({ loading: false });
        if (r.statusCode != 200) {
          self.setData({ errMsg: "请求失败 " + r.statusCode });
          return;
        }
        var d = r.data;
        if (d.code == 200 || d.code == 0) {
          var body = d.data || {};
          self.setData({
            cabinet: body.cabinet || {},
            slots: body.slots || []
          });
        } else {
          self.setData({ errMsg: d.message || "数据错误" });
        }
      },
      fail: function() {
        self.setData({ loading: false, errMsg: "网络错误" });
      }
    });
  },

  refresh: function() {
    if (this.data.cabinet.id) this.load(this.data.cabinet.id);
  },

  goBack: function() {
    wx.navigateBack();
  },

  tapSlot: function(e) {
    var id = parseInt(e.currentTarget.dataset.id);
    var list = this.data.slots;
    for (var i = 0; i < list.length; i++) {
      if (list[i].id == id) {
        var s = list[i];
        this.setData({ cur: s, selectedId: id, showAct: (s.status == 2), showSet: false });
        return;
      }
    }
  },

  closeAct: function() {
    this.setData({ showAct: false });
  },

  openLock: function() {
    var self = this;
    var s = this.data.cur;
    if (!s) { wx.showToast({ title: '请先点击选择柜门', icon: 'none' }); return; }
    if (!this.data.cabinet.is_online) { wx.showModal({ title: '设备离线', content: '设备离线，无法发送开门指令', showCancel: false }); return; }
    var tk = wx.getStorageSync('auth_token') || '';
    var url = (app.globalData && app.globalData.baseUrl) || 'https://locker.cqdyxl.com';
    wx.showModal({
      title: '开门确认',
      content: '打开' + s.slot_number + '号柜门？',
      success: function(r) {
        if (!r.confirm) return;
        wx.request({
          url: url + "/api/merchant/cabinets/" + self.data.cabinet.id + "/open-slot",
          method: 'POST',
          data: { slot_id: s.id },
          header: { 'Authorization': tk ? 'Bearer ' + tk : '' },
          success: function(r) {
            if (r.data && (r.data.code == 200 || r.data.code == 0)) {
              wx.showToast({ title: s.slot_number + '号柜开门指令已发送', icon: 'none' });
            } else {
              wx.showToast({ title: (r.data && r.data.message) || '开门失败', icon: 'none' });
            }
          },
          fail: function() { wx.showToast({ title: '开门失败', icon: 'none' }); }
        });
      }
    });
  },

  queryStatus: function() {
    var self = this;
    var s = this.data.cur;
    if (!s) { wx.showToast({ title: '请先点击选择柜门', icon: 'none' }); return; }
    var tk = wx.getStorageSync('auth_token') || '';
    var url = (app.globalData && app.globalData.baseUrl) || 'https://locker.cqdyxl.com';
    wx.showLoading({ title: '查询中...' });
    wx.request({
      url: url + '/api/merchant/query-door-status',
      method: 'POST',
      data: { cabinet_id: self.data.cabinet.id, board_no: s.board_no || 1, lock_no: s.lock_no || s.slot_number },
      header: { 'Authorization': tk ? 'Bearer ' + tk : '' },
      success: function(r) {
        wx.hideLoading();
        if (r.data && (r.data.code == 200 || r.data.code == 0)) {
          var d = r.data.data || {};
          if (d.query_success) {
            wx.showModal({ title: s.slot_number + '号柜门', content: d.is_open ? '开门' : '关门', showCancel: false });
          } else {
            wx.showModal({ title: s.slot_number + '号柜门', content: '超时', showCancel: false });
          }
        } else {
          wx.showToast({ title: (r.data && r.data.message) || '查询失败', icon: 'none' });
        }
      },
      fail: function() { wx.hideLoading(); wx.showToast({ title: '查询失败', icon: 'none' }); }
    });
  },

  showSettings: function() {
    this.setData({ showSet: true, showAct: false });
  },

  closeSet: function() {
    this.setData({ showSet: false });
  },

  changeStatus: function(e) {
    var self = this;
    var ns = parseInt(e.currentTarget.dataset.status);
    var s = this.data.cur;
    if (!s) return;
    var names = {1:'空闲',3:'故障',4:'禁用'};
    var tk = wx.getStorageSync('auth_token') || '';
    var url = (app.globalData && app.globalData.baseUrl) || 'https://locker.cqdyxl.com';
    wx.showModal({
      title: '确认更改',
      content: '将' + s.slot_number + '号柜门改为"' + (names[ns] || '未知') + '"?',
      success: function(r) {
        if (!r.confirm) return;
        wx.request({
          url: url + "/api/merchant/cabinets/" + self.data.cabinet.id + "/slots/" + s.id + "/status",
          method: 'PUT',
          data: { status: ns },
          header: { 'Authorization': tk ? 'Bearer ' + tk : '' },
          success: function(r) {
            if (r.data && (r.data.code == 200 || r.data.code == 0)) {
              wx.showToast({ title: '状态已更新', icon: 'none' });
              self.closeSet();
              self.closeAct();
              self.refresh();
            } else {
              wx.showToast({ title: (r.data && r.data.message) || '更新失败', icon: 'none' });
            }
          },
          fail: function() { wx.showToast({ title: '更新失败', icon: 'none' }); }
        });
      }
    });
  },

  openAll: function() {
    var self = this;
    if (!this.data.cabinet.is_online) { wx.showModal({ title: '设备离线', content: '设备离线，无法发送开门指令', showCancel: false }); return; }
    var tk = wx.getStorageSync('auth_token') || '';
    var url = (app.globalData && app.globalData.baseUrl) || 'https://locker.cqdyxl.com';
    wx.showModal({
      title: '一键开门',
      content: '确认打开所有正常柜门？',
      success: function(r) {
        if (!r.confirm) return;
        wx.request({
          url: url + "/api/merchant/cabinets/" + self.data.cabinet.id + "/open-all",
          method: 'POST',
          header: { 'Authorization': tk ? 'Bearer ' + tk : '' },
          success: function(r) {
            if (r.data && (r.data.code == 200 || r.data.code == 0)) {
              wx.showToast({ title: r.data.message || '操作成功', icon: 'none' });
            } else {
              wx.showToast({ title: (r.data && r.data.message) || '操作失败', icon: 'none' });
            }
          },
          fail: function() { wx.showToast({ title: '操作失败', icon: 'none' }); }
        });
      }
    });
  },

  noop: function() {}
});
