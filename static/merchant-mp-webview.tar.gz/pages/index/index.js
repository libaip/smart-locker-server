const app = getApp();
Page({
  data: { webviewUrl: '' },
  onShow() {
    const token = wx.getStorageSync('token') || '';
    this.setData({ webviewUrl: 'https://locker.cqdyxl.com/h5/merchant/dashboard?token=' + encodeURIComponent(token) });
  }
})
