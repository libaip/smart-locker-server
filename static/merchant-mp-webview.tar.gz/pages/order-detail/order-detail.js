// pages/order-detail/order-detail.js - 订单详情逻辑
const API = require('../../utils/api.js')

Page({
  data: {
    orderId: null,
    order: null,
    loading: true,
    payments: [],
    doorRecords: []
  },

  onLoad(options) {
    const { orderId } = options
    if (orderId) {
      this.setData({ orderId: orderId })
      this.loadOrderDetail(orderId)
    }
  },

  // 加载订单详情
  loadOrderDetail(orderId) {
    this.setData({ loading: true })
    
    API.getOrderDetail(orderId)
      .then(res => {
        let order = null
        let payments = []
        
        if (res.data) {
          order = res.data.order || res.data
          payments = res.data.payments || res.data.payment_list || []
        }
        
        let doorRecords = res.data.door_records || []
        this.setData({
          order: order,
          payments: payments,
          doorRecords: doorRecords,
          loading: false
        })
      })
      .catch(err => {
        this.setData({ loading: false })
        console.error('加载订单详情失败:', err)
      })
  },

  // 获取状态文本
  getStatusText(status) {
    const statusMap = {
      1: '待支付',
      2: '进行中',
      3: '已结束',
      4: '已退款',
      5: '已取消',
      6: '已关闭'
    }
    return statusMap[status] || '未知'
  },

  // 获取状态样式
  getStatusClass(status) {
    const classMap = {
      1: 'status-tag-warning',
      2: 'status-tag-success',
      3: 'status-tag-gray',
      4: 'status-tag-gray',
      5: 'status-tag-danger',
      6: 'status-tag-danger'
    }
    return classMap[status] || 'status-tag-gray'
  },

  // 开门类型文本
  openTypeText: function(t) {
    var map = {
      store_open: '存包开门', end_storage: '结束开门', mid_offline: '中途开门',
      remote: '远程开门', local_reopen: '重开柜门', remote_reopen: '远程重开', local: '本地开门'
    };
    return map[t] || '开门';
  },

  // 格式化金额
  formatMoney(amount) {
    if (amount === null || amount === undefined || amount === '') return '0.00'
    return parseFloat(amount).toFixed(2)
  },

  // 格式化时间
  formatTime(time) {
    if (!time) return '--'
    const date = new Date(time)
    const year = date.getFullYear()
    const month = (date.getMonth() + 1).toString().padStart(2, '0')
    const day = date.getDate().toString().padStart(2, '0')
    const hour = date.getHours().toString().padStart(2, '0')
    const minute = date.getMinutes().toString().padStart(2, '0')
    const second = date.getSeconds().toString().padStart(2, '0')
    return `${year}-${month}-${day} ${hour}:${minute}:${second}`
  },

  // 获取支付状态文本
  getPaymentStatusText(status) {
    const statusMap = {
      pending: '待支付',
      paid: '已支付',
      refunded: '已退款',
      failed: '失败'
    }
    return statusMap[status] || statusMap[parseInt(status)] || '未知'
  },

  // 获取支付状态样式
  getPaymentStatusClass(status) {
    const classMap = {
      pending: 'status-tag-warning',
      paid: 'status-tag-success',
      refunded: 'status-tag-gray',
      failed: 'status-tag-danger'
    }
    return classMap[status] || classMap[parseInt(status)] || 'status-tag-gray'
  },

  // 获取支付类型文本
  getPaymentTypeText(type) {
    const typeMap = {
      deposit: '保证金',
      rent: '租金',
      penalty: '违约金',
      other: '其他'
    }
    return typeMap[type] || type || '其他'
  }
})
