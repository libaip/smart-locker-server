"""
智能寄存柜系统 - 全局配置
"""
import os

# ============================================
# 基础配置
# ============================================
SECRET_KEY = 'smart-locker-secret-key-2024'
DATABASE = 'locker.db'
DEBUG = False
HOST = '127.0.0.1'
PORT = 5001

# ============================================
# 微信支付配置
# ============================================
WX_MCH_ID = '1113658351'
WX_API_KEY = 'lichengju0904LICHENGJU0904libp98'
WX_API_V3_KEY = 'lichengjuLICHENGJU09040908libaip'
WX_CERT_SERIAL_NO = '39B1456463F2857B9B1F762C2D10D7B104E008FD'
WX_APP_ID = 'wxd85204d0ec930d46'
WX_APP_SECRET = '552e27fa9a260a6640bf6983bd3470f5'
WX_MP_APP_ID = 'wx57eaea52dcfff4e8'
WX_MP_APP_SECRET = '8b1233a6227fb2e5dc4d5c420979ac71'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WX_CERT_PATH = os.path.join(BASE_DIR, 'cert', 'apiclient_cert.pem')
WX_KEY_PATH = os.path.join(BASE_DIR, 'cert', 'apiclient_key.pem')
WX_PAY_NOTIFY_URL = 'https://locker.cqdyxl.com/api/pay/notify'
WX_REFUND_NOTIFY_URL = 'https://locker.cqdyxl.com/api/refund/notify'

# ============================================
# 主板品牌默认配置
# ============================================
BRAND_DEFAULTS = {
    'YBM': {'serial_port': 'ttyS4', 'baud_rate': 9600},
    'WT': {'serial_port': 'ttyS3', 'baud_rate': 115200},
    'QM': {'serial_port': 'ttyS2', 'baud_rate': 9600},
}

# ============================================
# APK版本信息
# ============================================
LATEST_VERSION_CODE = 149
LATEST_VERSION_NAME = "1.2.29"
AUTO_UPDATE_ENABLED = False
APK_DOWNLOAD_URL = "https://locker.cqdyxl.com/static/smart-locker.apk"

# ============================================
# 订单隐藏配置常量
# ============================================
ORDER_HIDE_SECRET = 'smart_locker_hide_2024'