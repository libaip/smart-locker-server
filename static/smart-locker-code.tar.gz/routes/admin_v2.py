import json
import os
"""
管理后台V2 API - 补全admin_v2前端所需的所有接口
包括：仪表盘统计、设备列表、订单管理、会员管理、提现管理等
"""
import logging
from datetime import datetime, timedelta
from flask import Blueprint, request, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db
import threading, uuid
from helpers import json_response, require_auth, logger, connected_devices
from config import WX_API_V3_KEY, WX_MCH_ID, WX_CERT_SERIAL_NO, WX_KEY_PATH, WX_CERT_PATH

bp = Blueprint('admin_v2', __name__)

_door_status_results = {}
_door_status_lock = threading.Lock()



@bp.route('/admin/dashboard', methods=['GET', 'POST'])
@require_auth
def admin_dashboard():
    """主控台统计数据"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT COUNT(*) as cnt, COALESCE(SUM(deposit_amount),0) as amt FROM orders')
        order_stat = c.fetchone()
        c.execute("SELECT COUNT(*) as cnt, COALESCE(SUM(refund_amount),0) as amt FROM orders WHERE refund_status='refunded'")
        refund_stat = c.fetchone()
        c.execute('SELECT COUNT(*) as cnt, COALESCE(SUM(balance),0) as bal, COALESCE(SUM(total_deposited),0) as dep, COALESCE(SUM(total_withdrawn),0) as wd FROM user_balances')
        member_stat = c.fetchone()
        c.execute('SELECT COUNT(*) FROM locations WHERE status=2')
        loc_count = c.fetchone()[0]
        c.execute('SELECT COUNT(*) FROM cabinets WHERE status=2')
        dev_count = c.fetchone()[0]
        online = len(connected_devices)
        c.execute('SELECT COALESCE(SUM(deposit_amount),0) FROM orders WHERE status=2')
        storage_income = c.fetchone()[0]
        c.execute("SELECT COALESCE(SUM(deposit_amount),0) FROM orders WHERE status NOT IN (0,5)")
        online_income = c.fetchone()[0]
        today = datetime.now().strftime('%Y-%m-%d')
        c.execute('SELECT COUNT(*) FROM orders WHERE date(store_time)=?', (today,))
        today_orders = c.fetchone()[0]
        c.execute('SELECT COALESCE(SUM(deposit_amount),0) FROM orders WHERE date(store_time)=?', (today,))
        today_amount = c.fetchone()[0]
        c.execute('SELECT COUNT(*) FROM user_balances')
        user_count = c.fetchone()[0]
        conn.close()
        return json_response(data={
            'onlineIncome': f'{online_income:.2f}',
            'storageIncome': f'{storage_income:.2f}',
            'withdrawn': f'{member_stat["wd"]:.2f}' if member_stat else '0.00',
            'totalIncome': f'{online_income:.2f}',
            'memberBalance': f'{member_stat["bal"]:.2f}' if member_stat else '0.00',
            'memberPending': '0.00',
            'memberWithdrawn': f'{member_stat["wd"]:.2f}' if member_stat else '0.00',
            'memberRecharge': f'{member_stat["dep"]:.2f}' if member_stat else '0.00',
            'orderCount': order_stat['cnt'] if order_stat else 0,
            'orderAmount': f'{order_stat["amt"]:.2f}' if order_stat else '0.00',
            'refundAmount': f'{refund_stat["amt"]:.2f}' if refund_stat else '0.00',
            'orderProfit': f'{(order_stat["amt"] - refund_stat["amt"]):.2f}' if order_stat and refund_stat else '0.00',
            'userCount': user_count,
            'locationCount': loc_count,
            'deviceCount': dev_count,
            'onlineCount': online,
            'todayOrders': today_orders,
            'todayAmount': f'{today_amount:.2f}'
        })
    except Exception as e:
        logger.error(f'[dashboard] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/daily-trend', methods=['GET', 'POST'])
@require_auth
def admin_daily_trend():
    """每日趋势数据"""
    try:
        days = int(request.args.get('days', 7))
        conn = get_db()
        c = conn.cursor()
        result = []
        for i in range(days):
            date = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
            c.execute('''
                SELECT COUNT(*) as cnt, COALESCE(SUM(deposit_amount),0) as amt 
                FROM orders WHERE date(store_time)=?
            ''', (date,))
            row = c.fetchone()
            result.insert(0, {'date': date, 'count': row['cnt'] if row else 0, 'amount': float(row['amt'] if row else 0)})
        conn.close()
        return json_response(data=result)
    except Exception as e:
        logger.error(f'[daily-trend] {e}')
        return json_response(data=[])


@bp.route('/admin/devices', methods=['GET', 'POST'])
@require_auth
def admin_devices():
    try:
        data = request.get_json() if request.method == 'POST' else {}
        keyword = (data or {}).get('keyword', '') or request.args.get('keyword', '')
        status = (data or {}).get('status', '') or request.args.get('status', '')
        page = int((data or {}).get('page', 1) or request.args.get('page', 1))
        page_size = 20
        conn = get_db()
        c = conn.cursor()
        where, params = '1=1', []
        if keyword:
            where += ' AND (device_id LIKE ? OR device_name LIKE ? OR cabinet_code LIKE ? OR mainboard_device_id LIKE ?)'
            params.extend([f'%{keyword}%', f'%{keyword}%', f'%{keyword}%', f'%{keyword}%'])
        if status == 'online':
            online_ids = list(connected_devices.keys())
            if online_ids:
                ph = ','.join(['?' for _ in online_ids])
                where += f' AND mainboard_device_id IN ({ph})'
                params.extend(online_ids)
            else:
                where += ' AND 1=0'
        elif status == 'offline':
            online_ids = list(connected_devices.keys())
            if online_ids:
                ph = ','.join(['?' for _ in online_ids])
                where += f' AND (mainboard_device_id NOT IN ({ph}) OR mainboard_device_id IS NULL OR mainboard_device_id="")'
                params.extend(online_ids)
        c.execute(f'SELECT COUNT(*) FROM cabinets WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT c.*, l.name as location_name 
            FROM cabinets c LEFT JOIN locations l ON c.location_id=l.id
            WHERE {where} ORDER BY c.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        devices = []
        import datetime as dt_mod
        now = dt_mod.datetime.now()
        for row in c.fetchall():
            d = dict(row)
            d['is_online'] = d.get('mainboard_device_id') in connected_devices
            if not d['is_online'] and d.get('last_heartbeat'):
                try:
                    hb = dt_mod.datetime.strptime(d['last_heartbeat'], '%Y-%m-%d %H:%M:%S')
                    d['is_online'] = (now - hb).total_seconds() < 60
                except:
                    pass
            d['app_version'] = d.get('app_version', '')
            d['app_version_code'] = d.get('app_version_code', 0) or 0
            devices.append(d)
        conn.close()
        return json_response(data={'list': devices, 'total': total})
    except Exception as e:
        logger.error(f'[admin_devices] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/cabinet/save', methods=['POST'])
@require_auth
def admin_cabinet_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        if data.get('id'):
            fields = ['name','cabinet_code','location_id','mainboard_device_id','mainboard_source',
                     'device_type','total_slots','business_status','status','charge_mode',
                     'deposit_amount','deposit_timeout','per_use_price','customer_phone','iot_company','iot_iccid',
                     'clean_balance_enabled','clean_balance_time','clean_balance_period','remark',
                     'usage_rules']
            sets, params = [], []
            for f in fields:
                if f in data:
                    v = data[f]
                    if isinstance(v, bool):
                        v = 1 if v else 0
                    sets.append(f'{f}=?')
                    params.append(v)
            params.append(data['id'])
            c.execute(f'UPDATE cabinets SET {",".join(sets)},updated_at=CURRENT_TIMESTAMP WHERE id=?', params)
        else:
            cabinet_code = data.get('cabinet_code') or f'CAB{datetime.now().strftime("%Y%m%d%H%M%S")}'
            c.execute('''INSERT INTO cabinets (cabinet_code,name,location_id,mainboard_device_id,mainboard_source,
                device_type,total_slots,business_status,status,charge_mode,deposit_amount,deposit_timeout,
                customer_phone,iot_company,iot_iccid,clean_balance_enabled,clean_balance_time,
                clean_balance_period,remark) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (cabinet_code, data.get('name',''), data.get('location_id'), data.get('mainboard_device_id'),
                 data.get('mainboard_source','WT'), data.get('device_type','screen'),
                 data.get('total_slots',12), data.get('business_status','open'),
                 data.get('status',1), data.get('charge_mode','deposit'),
                 data.get('deposit_amount',20), data.get('deposit_timeout',24), data.get('per_use_price',0),
                 data.get('customer_phone',''), data.get('iot_company',''),
                 data.get('iot_iccid',''), 1 if data.get('clean_balance_enabled') else 0,
                 data.get('clean_balance_time',''), data.get('clean_balance_period',1),
                 data.get('remark','')))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[cabinet_save] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/cabinet/delete', methods=['POST'])
@require_auth
def admin_cabinet_delete():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('DELETE FROM cabinets WHERE id=?', (data.get('id'),))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[cabinet_delete] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/force-update', methods=['POST'])
@require_auth
def admin_force_update():
    """推送设备更新"""
    try:
        # 从apk_version表读取最新版本
        conn_apk = get_db()
        c_apk = conn_apk.cursor()
        c_apk.execute("SELECT version_name, version_code, download_url FROM apk_version ORDER BY version_code DESC LIMIT 1")
        apk_row = c_apk.fetchone()
        conn_apk.close()
        if not apk_row:
            return json_response(message="未找到APK版本信息，请先上传APK", code=400)
        latest_url = apk_row["download_url"]
        latest_ver = apk_row["version_name"]
        latest_code = apk_row["version_code"]

        data = request.get_json()
        device_id = data.get('device_id')
        is_ws_online = device_id and device_id in connected_devices
        is_http_online = False
        if not is_ws_online:
            import datetime as dt_mod
            conn2 = get_db()
            c2 = conn2.cursor()
            c2.execute("SELECT last_heartbeat FROM cabinets WHERE mainboard_device_id=?", (device_id,))
            row2 = c2.fetchone()
            conn2.close()
            if row2 and row2['last_heartbeat']:
                try:
                    hb = dt_mod.datetime.strptime(row2['last_heartbeat'], '%Y-%m-%d %H:%M:%S')
                    is_http_online = (dt_mod.datetime.now() - hb).total_seconds() < 120
                except:
                    pass
        if is_ws_online:
            # WebSocket在线，直接推送force_update命令
            ws = connected_devices.get(device_id)
            if ws:
                import json as _json
                msg = _json.dumps({'type': 'force_update', 'download_url': latest_url, 'version_name': latest_ver, 'version_code': latest_code, 'force': True})
                ws.send(msg)
            return json_response(message='已推送更新指令')
        elif is_http_online:
            # HTTP轮询在线，通过pending-commands下发更新
            conn3 = get_db()
            c3 = conn3.cursor()
            c3.execute('SELECT id FROM cabinets WHERE mainboard_device_id=?', (device_id,))
            cab = c3.fetchone()
            if cab:
                import json as _json
                cmd = _json.dumps({'type': 'force_update', 'download_url': latest_url, 'version_name': latest_ver, 'version_code': latest_code, 'force': True})
                c3.execute('INSERT INTO pending_lock_cmds (cabinet_id, command, status) VALUES (?,?,?)', (cab['id'], cmd, 'pending'))
                conn3.commit()
            conn3.close()
            return json_response(message='已通过HTTP通道推送更新指令')
        return json_response(message='设备不在线', code=400)
    except Exception as e:
        logger.error(f'[force_update] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/reset-activation', methods=['POST'])
@require_auth
def admin_reset_activation():
    """重置设备激活状态"""
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('UPDATE cabinets SET activated=0 WHERE id=?', (data.get('cabinet_id'),))
        conn.commit()
        conn.close()
        return json_response(message='已重置激活状态')
    except Exception as e:
        logger.error(f'[reset_activation] {e}')
        return json_response(message=str(e), code=500)


# ============ Mainboards ============

@bp.route('/admin/slots', methods=['GET', 'POST'])
@require_auth
def admin_slots():
    """获取柜门列表"""
    try:
        data = request.get_json() if request.method == 'POST' else {}
        cabinet_id = data.get('cabinet_id') or request.args.get('cabinet_id')
        conn = get_db()
        c = conn.cursor()
        if cabinet_id:
            c.execute('SELECT * FROM cabinet_slots WHERE cabinet_id=? ORDER BY slot_number', (cabinet_id,))
        else:
            c.execute('SELECT * FROM cabinet_slots ORDER BY cabinet_id, slot_number')
        slots = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': slots})
    except Exception as e:
        logger.error(f'[slots] {e}')
        return json_response(data={'list': []})


@bp.route('/admin/slot/save', methods=['POST'])
@require_auth
def admin_slot_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('UPDATE cabinet_slots SET slot_size=?,status=?,slot_label=? WHERE id=?',
                  (data.get('slot_size'), data.get('status'), data.get('slot_label', ''), data['id']))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[slot_save] {e}')
        return json_response(message=str(e), code=500)




@bp.route('/admin/slots/batch-label', methods=['POST'])
@require_auth
def admin_slots_batch_label():
    """批量设置柜门标签：根据字母前缀+编号自动生成slot_label"""
    try:
        data = request.get_json()
        cabinet_id = data.get('cabinet_id')
        prefix = data.get('prefix', '').strip()
        start_num = data.get('start_num', 1)
        
        if not cabinet_id:
            return json_response(message='缺少柜体ID', code=400)
        if not prefix:
            return json_response(message='请输入字母前缀', code=400)
        
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT id, slot_number FROM cabinet_slots WHERE cabinet_id=? ORDER BY slot_number', (cabinet_id,))
        slots = c.fetchall()
        
        if not slots:
            conn.close()
            return json_response(message='该柜体没有柜门', code=400)
        
        updated = 0
        for i, slot in enumerate(slots):
            label = prefix + str(start_num + i)
            c.execute('UPDATE cabinet_slots SET slot_label=? WHERE id=?', (label, slot[0]))
            updated += 1
        
        conn.commit()
        conn.close()
        return json_response(message=f'已批量设置{updated}个柜门标签', data={'updated': updated})
    except Exception as e:
        logger.error(f'[batch_label] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/admin/slots/open-all', methods=['POST'])
@require_auth
def admin_slots_open_all():
    """全开柜门"""
    try:
        data = request.get_json()
        cabinet_id = data.get('cabinet_id')
        if not cabinet_id:
            return json_response(message='缺少柜体ID', code=400)
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT mainboard_device_id FROM cabinets WHERE id=?', (cabinet_id,))
        row = c.fetchone()
        conn.close()
        if not row or not row['mainboard_device_id']:
            return json_response(message='未找到设备', code=400)
        from helpers import send_open_all
        send_open_all(str(row['mainboard_device_id']))
        return json_response(message='已发送全开指令')
    except Exception as e:
        logger.error(f'[open_all] {e}')
        return json_response(message=str(e), code=500)


# ============ Locations ============

@bp.route('/admin/locations', methods=['GET', 'POST'])
@require_auth
def admin_locations():
    try:
        data = request.get_json() if request.method == 'POST' else {}
        keyword = (data or {}).get('keyword', '') or request.args.get('keyword', '')
        page = int((data or {}).get('page', 1) or request.args.get('page', 1))
        page_size = 20
        conn = get_db()
        c = conn.cursor()
        where, params = '1=1', []
        if keyword:
            where += ' AND (l.name LIKE ? OR l.address LIKE ?)'
            params.extend([f'%{keyword}%', f'%{keyword}%'])
        c.execute(f'SELECT COUNT(*) FROM locations l WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT l.*, m.name as merchant_name,
            (SELECT COUNT(*) FROM cabinets WHERE location_id=l.id) as cabinet_count,
            (SELECT COUNT(*) FROM cabinets WHERE location_id=l.id AND last_heartbeat>=datetime('now', '-30 seconds')) as online_count,
            (SELECT COUNT(*) FROM orders WHERE slot_id IN (SELECT id FROM cabinet_slots WHERE cabinet_id IN (SELECT id FROM cabinets WHERE location_id=l.id)) AND status=2) as active_orders
            FROM locations l LEFT JOIN merchants m ON l.merchant_id=m.id
            WHERE {where} ORDER BY l.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        locations = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': locations, 'total': total})
    except Exception as e:
        logger.error(f'[admin_locations] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/location/save', methods=['POST'])
@require_auth
def admin_location_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        if data.get('id'):
            fields = ['name','address','longitude','latitude','merchant_id','status',
                     'contact_name','contact_phone','open_time','close_time',
                     'allow_slot_select','slot_assign_mode','allow_mid_retrieve','retrieve_mode',
                     'allow_h5_to_mp','show_qr_follow','force_follow_mp','h5_url',
                     'show_slot_count','screen_show_title','screen_title',
                     'slot_full_alert','slot_full_text','end_alert_minutes',
                     'enable_clear_box','clear_box_time','clear_box_cycle',
                     'deposit_random','deposit_min','deposit_max',
                     'withdraw_enabled','show_refunding_status','refund_mode','withdraw_mode',
                     'auto_approve_day',
                     'auto_approve_time','auto_approve_rate','click_free_count',
                     'anti_test_minutes','anti_test_auto_refund','hide_ratio',
                     'whitelist_phones','duplicate_filter_enabled','duplicate_filter_days','duplicate_filter_limit',
                     'refund_approve_rate','refund_approve_start_min','refund_approve_end_min']
            sets, params = [], []
            for f in fields:
                if f in data:
                    v = data[f]
                    if isinstance(v, bool):
                        v = 1 if v else 0
                    sets.append(f'{f}=?')
                    params.append(v)
            params.append(data['id'])
            c.execute(f'UPDATE locations SET {",".join(sets)} WHERE id=?', params)
        else:
            c.execute('''INSERT INTO locations (name,address,longitude,latitude,merchant_id,status,
                contact_name,contact_phone) VALUES (?,?,?,?,?,?,?,?)''',
                (data.get('name'), data.get('address'), data.get('longitude'),
                 data.get('latitude'), data.get('merchant_id'), data.get('status',1),
                 data.get('contact_name',''), data.get('contact_phone','')))
        # 如果网点切换为自动审批，自动处理该网点pending的提现记录
        if data.get('id') and data.get('withdraw_mode') == 'auto_approve':
            try:
                c2 = conn.cursor()
                # 找到该网点下所有status=0(待审核)的余额提现记录
                c2.execute('''SELECT w.id, w.user_phone, w.amount FROM withdrawal_records w
                    JOIN orders o ON w.order_id = o.id
                    JOIN cabinets cb ON o.cabinet_id = cb.id
                    WHERE cb.location_id = ? AND w.status = 0 AND w.order_id IS NOT NULL''', (data['id'],))
                pending_records = c2.fetchall()
                # 也找余额提现(order_id IS NULL)属于该网点的
                c2.execute('''SELECT w.id, w.user_phone, w.amount FROM withdrawal_records w
                    WHERE w.order_id IS NULL AND w.status = 0 AND w.user_phone IN (
                        SELECT DISTINCT o.user_phone FROM orders o
                        JOIN cabinets cb ON o.cabinet_id = cb.id
                        WHERE cb.location_id = ?
                    )''', (data['id'],))
                pending_records += c2.fetchall()
                for wr in pending_records:
                    try:
                        refund_success = False
                        if wr['order_id']:
                            # 有关联订单，走原路退款
                            from helpers import do_real_refund
                            refund_success, refund_id, refund_msg = do_real_refund(order_id=wr['order_id'], amount=wr['amount'])
                        else:
                            # 余额提现，找最近订单原路退
                            c2.execute('SELECT id FROM orders WHERE user_phone=? AND status IN (2,4,5,6) AND deposit_amount > 0 ORDER BY id DESC LIMIT 1', (wr['user_phone'],))
                            recent = c2.fetchone()
                            if recent:
                                from helpers import do_real_refund
                                refund_success, refund_id, refund_msg = do_real_refund(order_id=recent['id'], amount=wr['amount'])
                        if refund_success:
                            c2.execute('UPDATE withdrawal_records SET status=2 WHERE id=?', (wr['id'],))
                            logger.info(f'[auto_approve_switch] 提现{wr["id"]}原路退款成功')
                        else:
                            c2.execute('UPDATE withdrawal_records SET status=1 WHERE id=?', (wr['id'],))
                            logger.info(f'[auto_approve_switch] 提现{wr["id"]}退款处理中')
                    except Exception as re:
                        logger.error(f'[auto_approve_switch] 提现{wr["id"]}自动退款失败: {re}')
                conn.commit()
            except Exception as ae:
                logger.error(f'[auto_approve_switch] 处理pending提现异常: {ae}')

        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[location_save] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/location/delete', methods=['POST'])
@require_auth
def admin_location_delete():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('DELETE FROM locations WHERE id=?', (data.get('id'),))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[location_delete] {e}')
        return json_response(message=str(e), code=500)


# ============ Orders ============

@bp.route('/admin/orders', methods=['GET', 'POST'])
@require_auth
def admin_orders():
    try:
        data = request.get_json() if request.method == 'POST' else request.args.to_dict()
        order_id = data.get('order_id', '') or data.get('order_no', '')
        phone = data.get('phone', '') or data.get('user_phone', '')
        status = data.get('status', '')
        page = int(data.get('page', 1))
        page_size = int(data.get('limit', 20))
        conn = get_db()
        c = conn.cursor()
        where, params = 'o.status NOT IN (5)', []
        if order_id:
            where += ' AND o.order_no LIKE ?'
            params.append(f'%{order_id}%')
        if phone:
            where += ' AND o.user_phone LIKE ?'
            params.append(f'%{phone}%')
        if status:
            where += ' AND o.status = ?'
            params.append(int(status))
        if data.get('logic_mark'):
            where += ' AND o.logic_mark = ?'
            params.append(data['logic_mark'])
        if data.get('refund_mark'):
            where += ' AND o.refund_mark = ?'
            params.append(data['refund_mark'])
        if data.get('location_id'):
            where += ' AND c.location_id = ?'
            params.append(data['location_id'])
        if data.get('device_id'):
            where += ' AND o.cabinet_id = ?'
            params.append(data['device_id'])
        # Date range filter, default 30 days
        start_date = data.get('start_date', '')
        end_date = data.get('end_date', '')
        if start_date and end_date:
            where += ' AND date(o.store_time)>=? AND date(o.store_time)<=?'
            params.extend([start_date, end_date])
        elif not start_date and not end_date:
            # Default: last 30 days
            where += ' AND o.store_time>=datetime(\'now\', \'-30 days\')'
        c.execute(f'SELECT COUNT(*) FROM orders o WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT o.*, c.cabinet_code, c.name as cabinet_name, cs.slot_number as compartment_number, ub.wechat_name
            FROM orders o LEFT JOIN cabinets c ON o.cabinet_id=c.id
            LEFT JOIN cabinet_slots cs ON o.slot_id=cs.id
            LEFT JOIN user_balances ub ON o.user_phone=ub.phone
            WHERE {where} ORDER BY o.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        orders = []
        for r in c.fetchall():
            d = dict(r)
            d['status_text'] = {2:'使用中',3:'已结算',4:'已退款',5:'已取消',6:'退款异常'}.get(d.get('status'), '未知')
            orders.append(d)
        conn.close()
        return json_response(data={'list': orders, 'total': total})
    except Exception as e:
        logger.error(f'[admin_orders] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/order/detail', methods=['GET', 'POST'])
@require_auth
def admin_order_detail():
    """订单详情(含开门记录)"""
    try:
        data = request.get_json() if request.method == 'POST' else request.args.to_dict()
        order_id = data.get('order_id')
        conn = get_db()
        c = conn.cursor()
        c.execute('''SELECT o.*, c.cabinet_code, c.name as cabinet_name,
            cs.slot_number as compartment_number, ub.wechat_name, cs.slot_label as compartment_label, l.name as location_name
            FROM orders o LEFT JOIN cabinets c ON o.cabinet_id=c.id
            LEFT JOIN cabinet_slots cs ON o.slot_id=cs.id
            LEFT JOIN user_balances ub ON o.user_phone=ub.phone
            LEFT JOIN locations l ON c.location_id=l.id
            WHERE o.id=?''', (order_id,))
        order = c.fetchone()
        if not order:
            conn.close()
            return json_response(message='订单不存在', code=404)
        order_dict = dict(order)
        # 查询该订单关联的开门记录
        order_no = order_dict.get("order_no", "")
        open_logs = []
        # 直接按order_no查door_records
        if order_no:
            c.execute("SELECT id, device_id, board_no, lock_no, order_id, open_type, create_time FROM door_records WHERE order_id=? ORDER BY create_time DESC", (str(order_no),))
            door_logs = [dict(r) for r in c.fetchall()]
            for log in door_logs:
                log["source"] = "door"
                log["created_at"] = log.get("create_time", "")
        else:
            door_logs = []
        # 查remote_open_logs(通过device_id+slot_id)
        slot_id = order_dict.get("slot_id") or 0
        if slot_id:
            dev_row = c.execute("SELECT c.mainboard_device_id FROM cabinet_slots cs JOIN cabinets c ON cs.cabinet_id=c.id WHERE cs.id=?", (slot_id,)).fetchone()
            if dev_row and dev_row["mainboard_device_id"]:
                device_id = dev_row["mainboard_device_id"]
                c.execute("SELECT id, action_type, operator, result, success, ip_address, created_at, device_id, slot_id FROM remote_open_logs WHERE device_id=? AND slot_id=? ORDER BY created_at DESC", (device_id, slot_id))
                remote_logs = [dict(r) for r in c.fetchall()]
                for log in remote_logs:
                    log["source"] = "remote"
                    log["open_type"] = log.get("action_type", "")
            else:
                remote_logs = []
        else:
            remote_logs = []
        # 合并并按时间倒序
        open_logs = door_logs + remote_logs
        open_logs.sort(key=lambda x: x.get("created_at", ""), reverse=True)
        return json_response(data=order_dict)
    except Exception as e:
        logger.error(f'[order_detail] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/order/refund', methods=['POST'])
@require_auth
def admin_order_refund():
    """订单退款 - 支持使用中(2)和已结算(4)的订单"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        conn = get_db()
        c = conn.cursor()
        # 支持status=2(使用中)和status=4(已结算)的订单退款
        c.execute('SELECT * FROM orders WHERE id=? AND status != 4', (order_id,))
        order = c.fetchone()
        if not order:
            conn.close()
            return json_response(message='订单不存在或状态不允许退款', code=400)
        order_dict = dict(order)
        amount = order_dict.get('deposit_amount', 0)
        transaction_id = order_dict.get('transaction_id', '')
        order_no = order_dict.get('order_no', '')
        payment_channel_id = order_dict.get('payment_channel_id')
        refund_no = 'RF' + datetime.now().strftime('%Y%m%d%H%M%S') + str(order_id)
        # 尝试调用微信退款API
        refund_result = None
        actual_refund = False
        if transaction_id and transaction_id != 'MOCK':
            try:
                from helpers import get_channel_wxpay, get_wxpay
                if payment_channel_id:
                    c.execute('SELECT * FROM payment_channels WHERE id=?', (payment_channel_id,))
                    ch = c.fetchone()
                    if ch:
                        wxpay_inst, _ = get_channel_wxpay(dict(ch))
                    else:
                        wxpay_inst = get_wxpay()
                else:
                    wxpay_inst = get_wxpay()
                total_fee = int(amount * 100)
                refund_result = wxpay_inst.refund(
                    out_trade_no=order_no,
                    total_fee=total_fee,
                    refund_fee=total_fee,
                    out_refund_no=refund_no,
                    refund_desc=''
                )
                if refund_result and refund_result.get('return_code') == 'SUCCESS' and refund_result.get('result_code') == 'SUCCESS':
                    actual_refund = True
                    logger.info(f'[order_refund] 微信退款成功 order={order_no} refund_no={refund_no}')
                else:
                    err_msg = refund_result.get('return_msg', '') or refund_result.get('err_code_des', '未知错误') if refund_result else '无返回'
                    logger.warning(f'[order_refund] 微信退款失败 order={order_no} err={err_msg}')
                    conn.close()
                    return json_response(message=f'微信退款失败: {err_msg}', code=400)
            except Exception as e:
                logger.warning(f'[order_refund] 微信退款异常 order={order_no} err={e}')
                conn.close()
                return json_response(message=f'微信退款异常: {str(e)}', code=400)
        # 微信退款成功或无transaction_id(MOCK)，才更新本地状态
        c.execute("UPDATE orders SET refund_mark='manual', refund_status='refunded', status=4, refund_amount=?, refund_time=CURRENT_TIMESTAMP WHERE id=?",
                  (amount, order_id))
        # 记录payments退款流水
        c.execute('INSERT INTO payments (order_id, type, amount, transaction_id, refund_transaction_id, status, created_at) VALUES (?, 2, ?, ?, ?, 1, ?)',
                  (order_id, amount, transaction_id, refund_no, datetime.now()))
        # 如果订单还在使用中(2)，释放柜格
        if order_dict.get('status') == 2 and order_dict.get('slot_id'):
            c.execute('UPDATE cabinet_slots SET status=1 WHERE id=?', (order_dict['slot_id'],))
        conn.commit()
        conn.close()
        return json_response(message='退款成功')
    except Exception as e:
        logger.error(f'[order_refund] {e}')
        return json_response(message=str(e), code=500)







@bp.route('/admin/order/close', methods=['POST'])
@require_auth
def admin_order_close():
    """结束订单 - 支持待支付(1)和使用中(2)的订单"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if not order_id:
            return json_response(message='缺少order_id', code=400)
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM orders WHERE id=? AND status IN (1,2)', (order_id,))
        order = c.fetchone()
        if not order:
            conn.close()
            return json_response(message='订单不存在或状态不允许结束', code=400)
        order_dict = dict(order)
        from datetime import datetime as dt_mod2
        now = dt_mod2.now().strftime('%Y-%m-%d %H:%M:%S')
        # 更新订单状态为已结算(4)
        c.execute('UPDATE orders SET status=4, pickup_time=?, updated_at=? WHERE id=?', (now, now, order_id))
        # 释放柜格
        if order_dict.get('slot_id'):
            c.execute('UPDATE cabinet_slots SET status=1 WHERE id=?', (order_dict['slot_id'],))
        conn.commit()
        conn.close()
        # 通知APK刷新柜格状态
        try:
            device_id = order_dict.get('device_id') or order_dict.get('cabinet_id')
            if device_id:
                # 尝试从cabinet获取mainboard_device_id
                conn2 = get_db()
                c2 = conn2.cursor()
                if order_dict.get('cabinet_id'):
                    c2.execute('SELECT mainboard_device_id FROM cabinets WHERE id=?', (order_dict['cabinet_id'],))
                    cab = c2.fetchone()
                    if cab:
                        device_id = cab['mainboard_device_id']
                conn2.close()
                from helpers import connected_devices
                import json as _json2
                ws = connected_devices.get(str(device_id))
                if ws:
                    ws.send(_json2.dumps({'type': 'slot_update', 'slot_id': order_dict.get('slot_id'), 'status': 1}))
                    logger.info(f'[order_close] 已通知设备{device_id}刷新柜格')
        except Exception as notify_err:
            logger.warning(f'[order_close] 通知APK失败: {notify_err}')
        return json_response(message='订单已结束')
    except Exception as e:
        logger.error(f'[order_close] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/admin/member/refund', methods=['POST'])
@require_auth
def admin_member_refund():
    """单个会员退款"""
    try:
        data = request.get_json()
        phone = data.get('phone')
        amount = data.get('amount', 0)
        if not phone or amount <= 0:
            return json_response(message='参数错误', code=400)
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM user_balances WHERE user_phone=?', (phone,))
        user = c.fetchone()
        if not user or (user['balance'] or 0) <= 0:
            conn.close()
            return json_response(message='用户余额不足', code=400)
        refund_amount = min(amount, user['balance'] or 0)
        c.execute('UPDATE user_balances SET balance=balance-? WHERE user_phone=?', (refund_amount, phone))
        c.execute("SELECT id, order_no, transaction_id, deposit_amount, payment_channel_id FROM orders WHERE user_phone=? AND status != 4 AND refund_status!='refunded' ORDER BY id DESC LIMIT 1", (phone,))
        order = c.fetchone()
        refund_no = 'RF_M' + datetime.now().strftime('%Y%m%d%H%M%S') + str(phone)[-4:]
        if order:
            # 先尝试微信退款，成功才更新本地状态
            wx_refund_ok = False
            wx_err_msg = ''
            try:
                from helpers import get_channel_wxpay, get_wxpay
                payment_channel_id = order['payment_channel_id'] if order else None
                if payment_channel_id:
                    c.execute('SELECT * FROM payment_channels WHERE id=?', (payment_channel_id,))
                    ch = c.fetchone()
                    wxpay_inst, _ = get_channel_wxpay(dict(ch)) if ch else (get_wxpay(), None)
                else:
                    wxpay_inst = get_wxpay()
                total_fee = int(refund_amount * 100)
                refund_result = wxpay_inst.refund(out_trade_no=order['order_no'], total_fee=total_fee, refund_fee=total_fee, out_refund_no=refund_no, refund_desc='')
                if refund_result and refund_result.get('return_code') == 'SUCCESS' and refund_result.get('result_code') == 'SUCCESS':
                    wx_refund_ok = True
                else:
                    wx_err_msg = refund_result.get('return_msg', '') or refund_result.get('err_code_des', '未知错误') if refund_result else '无返回'
                    logger.warning(f'[member_refund] 微信退款失败 err={wx_err_msg}')
            except Exception as e:
                wx_err_msg = str(e)
                logger.warning(f'[member_refund] 微信退款异常 err={e}')
            if not wx_refund_ok and order['transaction_id'] and order['transaction_id'] != 'MOCK':
                conn.close()
                return json_response(message=f'微信退款失败: {wx_err_msg}', code=400)
            c.execute("UPDATE orders SET refund_mark='manual', refund_status='refunded', status=4, refund_amount=?, refund_time=CURRENT_TIMESTAMP WHERE id=?",
                      (order['deposit_amount'], order['id']))
            c.execute('INSERT INTO payments (order_id, type, amount, transaction_id, refund_transaction_id, status, created_at) VALUES (?, 2, ?, ?, ?, 1, ?)',
                      (order['id'], refund_amount, order['transaction_id'], refund_no, datetime.now()))
        conn.commit()
        conn.close()
        return json_response(message=f'退款成功 ¥{refund_amount:.2f}')
    except Exception as e:
        logger.error(f'[member_refund] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/member/batch-refund', methods=['POST'])
@require_auth
def admin_member_batch_refund():
    """批量会员退款"""
    try:
        data = request.get_json()
        phones = data.get('phones', [])
        if not phones:
            return json_response(message='请选择会员', code=400)
        conn = get_db()
        c = conn.cursor()
        success_count = 0
        total_refund = 0
        for phone in phones:
            c.execute('SELECT * FROM user_balances WHERE user_phone=?', (phone,))
            user = c.fetchone()
            if not user or (user['balance'] or 0) <= 0:
                continue
            refund_amount = user['balance'] or 0
            c.execute('UPDATE user_balances SET balance=0 WHERE user_phone=?', (phone,))
            c.execute("SELECT id, order_no, transaction_id, deposit_amount, payment_channel_id FROM orders WHERE user_phone=? AND status != 4 AND refund_status!='refunded' ORDER BY id DESC LIMIT 1", (phone,))
            order = c.fetchone()
            refund_no = 'RF_B' + datetime.now().strftime('%Y%m%d%H%M%S') + str(phone)[-4:]
            if order:
                c.execute("UPDATE orders SET refund_mark='manual', refund_status='refunded', status=4, refund_amount=?, refund_time=CURRENT_TIMESTAMP WHERE id=?",
                          (order['deposit_amount'], order['id']))
                c.execute('INSERT INTO payments (order_id, type, amount, transaction_id, refund_transaction_id, status, created_at) VALUES (?, 2, ?, ?, ?, 1, ?)',
                          (order['id'], refund_amount, order['transaction_id'], refund_no, datetime.now()))
            success_count += 1
            total_refund += refund_amount
        conn.commit()
        conn.close()
        return json_response(message=f'批量退款完成: {success_count}人, 共¥{total_refund:.2f}')
    except Exception as e:
        logger.error(f'[batch_refund] {e}')
        return json_response(message=str(e), code=500)



@bp.route('/admin/order/open-lock', methods=['POST'])
@require_auth
def admin_order_open_lock():
    """远程开锁"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        conn = get_db()
        c = conn.cursor()
        c.execute('''SELECT o.*, c.mainboard_device_id, cs.slot_number, cs.board_no FROM orders o 
            JOIN cabinets c ON o.cabinet_id=c.id 
            LEFT JOIN cabinet_slots cs ON o.slot_id=cs.id
            WHERE o.id=?''', (order_id,))
        order = c.fetchone()
        conn.close()
        if not order or not order['mainboard_device_id']:
            return json_response(message='订单或设备不存在', code=404)
        order = dict(order)
        device_id = str(order['mainboard_device_id'])
        board_no = order.get('board_no') or 1
        lock_no = order.get('slot_number') or order.get('compartment_number') or 1
        from helpers import send_open_lock
        send_open_lock(device_id, board_no, lock_no, None, str(order_id))
        return json_response(message='开柜指令已发送')
    except Exception as e:
        logger.error(f'[open_lock] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/order/toggle-logic', methods=['POST'])
@require_auth
def admin_order_toggle_logic():
    """切换订单逻辑标记"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        logic_mark = data.get('logic_mark', 'N')
        conn = get_db()
        c = conn.cursor()
        c.execute('UPDATE orders SET logic_mark=? WHERE id=?', (logic_mark, order_id))
        conn.commit()
        conn.close()
        return json_response(message='已切换')
    except Exception as e:
        logger.error(f'[toggle_logic] {e}')
        return json_response(message=str(e), code=500)


# ============ Members ============

@bp.route('/admin/members', methods=['GET', 'POST'])
@require_auth
def admin_members():
    try:
        data = request.get_json() if request.method == 'POST' else {}
        phone = (data or {}).get('phone', '') or request.args.get('phone', '')
        page = int((data or {}).get('page', 1) or request.args.get('page', 1))
        page_size = 20
        conn = get_db()
        c = conn.cursor()
        where, params = '1=1', []
        if phone:
            where += ' AND phone LIKE ?'
            params.append(f'%{phone}%')
        c.execute(f'SELECT COUNT(*) FROM user_balances WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT ub.*, 
            (SELECT COUNT(*) FROM orders WHERE user_phone=ub.phone) as total_orders,
            (SELECT COALESCE(SUM(deposit_amount),0) FROM orders WHERE user_phone=ub.phone AND deposit_amount>0) as total_deposit
            FROM user_balances ub WHERE {where} ORDER BY ub.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        members = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': members, 'total': total})
    except Exception as e:
        logger.error(f'[admin_members] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/member/detail', methods=['GET', 'POST'])
@require_auth
def admin_member_detail():
    """会员详情"""
    try:
        data = request.get_json() if request.method == 'POST' else request.args.to_dict()
        user_id = data.get('user_id')
        phone = data.get('phone')
        conn = get_db()
        c = conn.cursor()
        if user_id:
            c.execute('SELECT * FROM user_balances WHERE id=?', (user_id,))
        elif phone:
            c.execute('SELECT * FROM user_balances WHERE phone=?', (phone,))
        else:
            conn.close()
            return json_response(message='缺少参数', code=400)
        member = c.fetchone()
        if member:
            c.execute('''SELECT order_no, store_time, status FROM orders 
                WHERE user_phone=? ORDER BY created_at DESC LIMIT 10''', (member['phone'],))
            recent_orders = [dict(r) for r in c.fetchall()]
            conn.close()
            result = dict(member)
            result['recent_orders'] = recent_orders
            result['total_orders'] = len(recent_orders)
            return json_response(data=result)
        conn.close()
        return json_response(message='会员不存在', code=404)
    except Exception as e:
        logger.error(f'[member_detail] {e}')
        return json_response(message=str(e), code=500)


# ============ Withdrawals ============

@bp.route('/admin/withdrawals', methods=['GET', 'POST'])
@require_auth
def admin_withdrawals():
    """提现列表"""
    try:
        data = request.get_json() if request.method == 'POST' else {}
        status = (data or {}).get('status', '') or request.args.get('status', '')
        page = int((data or {}).get('page', 1) or request.args.get('page', 1))
        page_size = 20
        conn = get_db()
        c = conn.cursor()
        where, params = '1=1', []
        if status:
            where += ' AND status=?'
            params.append(int(status))
        c.execute(f'SELECT COUNT(*) FROM withdrawal_records WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT wr.*, wr.user_phone as user_phone, ub.wechat_name, ub.wechat_name as user_name
            FROM withdrawal_records wr LEFT JOIN user_balances ub ON wr.user_phone=ub.phone
            WHERE {where} ORDER BY wr.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        withdrawals = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': withdrawals, 'total': total})
    except Exception as e:
        logger.error(f'[withdrawals] {e}')
        return json_response(data={'list': [], 'total': 0})


@bp.route('/admin/withdrawal/approve', methods=['POST'])
@require_auth
def admin_withdrawal_approve():
    """审批通过提现申请（status=0 -> 真退款 -> status=2或1）"""
    try:
        data = request.get_json()
        withdrawal_id = data.get('id')
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT w.*, o.payment_channel_id, o.order_no FROM withdrawal_records w LEFT JOIN orders o ON w.order_id = o.id WHERE w.id=?', (withdrawal_id,))
        wd = c.fetchone()
        if not wd:
            conn.close()
            return json_response(message='提现记录不存在', code=400)
        if wd['status'] != 0:
            conn.close()
            return json_response(message='该记录状态不允许审批', code=400)
        amount = wd['amount']
        phone = wd['user_phone']
        order_id = wd['order_id']
        # 扣除余额（如果是余额提现且还未扣）
        c.execute('SELECT balance FROM user_balances WHERE phone=?', (phone,))
        bal = c.fetchone()
        if bal and bal['balance'] >= amount:
            c.execute('UPDATE user_balances SET balance = balance - ?, total_withdrawn = total_withdrawn + ? WHERE phone = ?', (amount, amount, phone))
        # 真正退款/转账
        refund_success = False
        refund_id = ''
        if order_id:
            # 订单押金退款
            from helpers import do_real_refund
            refund_success, refund_id, refund_msg = do_real_refund(order_id=order_id, amount=amount)
        else:
            # 余额提现：找最近订单原路退回
            c.execute('SELECT id, deposit_amount, order_no FROM orders WHERE user_phone=? AND status IN (2,4,5,6) AND deposit_amount > 0 ORDER BY id DESC LIMIT 1', (phone,))
            recent_order = c.fetchone()
            if recent_order:
                from helpers import do_real_refund
                refund_success, refund_id, refund_msg = do_real_refund(order_id=recent_order['id'], amount=amount)
            else:
                refund_success, refund_id, refund_msg = False, '', 'No order to refund'
        if refund_success:
            c.execute('UPDATE withdrawal_records SET status=2, approver=?, approve_time=CURRENT_TIMESTAMP, refund_id=? WHERE id=?',
                       (session.get('admin_username', 'admin'), refund_id, withdrawal_id))
            if order_id:
                c.execute('UPDATE orders SET status=4, refund_id=?, refund_time=? WHERE id=?', (refund_id, datetime.now(), order_id))
        else:
            c.execute('UPDATE withdrawal_records SET status=1, approver=?, approve_time=CURRENT_TIMESTAMP WHERE id=?',
                       (session.get('admin_username', 'admin'), withdrawal_id))
            if order_id:
                c.execute('UPDATE orders SET status=3 WHERE id=?', (order_id,))
        conn.commit()
        conn.close()
        if refund_success:
            return json_response(message='审批通过，退款已完成')
        else:
            return json_response(message='审批通过，但退款失败，请手动确认退款')
    except Exception as e:
        logger.error('[withdrawal_approve] ' + str(e))
        return json_response(message=str(e), code=500)


@bp.route('/admin/withdrawal/reject', methods=['POST'])
@require_auth
def admin_withdrawal_reject():
    """拒绝提现"""
    try:
        data = request.get_json()
        withdrawal_id = data.get('id')
        reason = data.get('reason', '')
        conn = get_db()
        c = conn.cursor()
        # 查询提现记录状态
        c.execute('SELECT user_phone, amount, status FROM withdrawal_records WHERE id=?', (withdrawal_id,))
        wd = c.fetchone()
        if not wd:
            conn.close()
            return json_response(message='提现记录不存在', code=400)
        # 如果是已扣余额的(status=1审批通过/自动审批)，需要退还
        if wd['status'] == 1 and wd['user_phone']:
            c.execute('UPDATE user_balances SET balance=balance+?,total_withdrawn=total_withdrawn-? WHERE phone=?',
                      (wd['amount'], wd['amount'], wd['user_phone']))
        # status=0的没扣余额，不需要退; status=1的已扣余额需要退
        c.execute("SELECT order_id FROM withdrawal_records WHERE id=?", (withdrawal_id,))
        wd2 = c.fetchone()
        if wd2 and wd2['order_id']:
            c.execute("UPDATE orders SET status=3 WHERE id=? AND status!=4", (wd2['order_id'],))
        c.execute("UPDATE withdrawal_records SET status=3,approver=? WHERE id=?",
                  (session.get('admin_username', 'admin') + (':' + reason if reason else ''), withdrawal_id))
        conn.commit()
        conn.close()
        return json_response(message='已拒绝')
    except Exception as e:
        logger.error(f'[withdrawal_reject] {e}')
        return json_response(message=str(e), code=500)



@bp.route('/admin/withdrawal/confirm-refund', methods=['POST'])
@require_auth
def admin_withdrawal_confirm_refund():
    """确认退款完成（status=1 -> status=2）"""
    try:
        data = request.get_json()
        withdrawal_id = data.get('id')
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT id, status FROM withdrawal_records WHERE id=?', (withdrawal_id,))
        wd = c.fetchone()
        if not wd:
            conn.close()
            return json_response(message='提现记录不存在', code=400)
        if wd['status'] != 1:
            conn.close()
            return json_response(message='该记录状态不允许确认退款', code=400)
        # 确认退款完成：检查是否有关联订单需要更新
        c.execute('SELECT order_id FROM withdrawal_records WHERE id=?', (withdrawal_id,))
        wd2 = c.fetchone()
        if wd2 and wd2['order_id']:
            c.execute('UPDATE orders SET status=4, refund_time=? WHERE id=? AND status!=4', (datetime.now(), wd2['order_id']))
        c.execute("UPDATE withdrawal_records SET status=2, approve_time=CURRENT_TIMESTAMP WHERE id=?", (withdrawal_id,))
        conn.commit()
        conn.close()
        return json_response(message='已确认退款完成')
    except Exception as e:
        logger.error(f'[withdrawal_confirm_refund] {e}')
        return json_response(message=str(e), code=500)

# ============ Complaints ============

@bp.route('/admin/complaints', methods=['GET', 'POST'])
@require_auth
def admin_complaints():
    """投诉列表"""
    try:
        data = request.get_json() if request.method == 'POST' else {}
        complaint_type = (data or {}).get('type', 'complaint') or request.args.get('type', 'complaint')
        status = (data or {}).get('status', '') or request.args.get('status', '')
        page = int((data or {}).get('page', 1) or request.args.get('page', 1))
        page_size = 20
        conn = get_db()
        c = conn.cursor()
        where, params = '1=1', []
        where += ' AND complaint_type=?'
        params.append(complaint_type)
        if status:
            where += ' AND status=?'
            params.append(int(status))
        c.execute(f'SELECT COUNT(*) FROM complaints WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT c.*, o.order_no, o.user_phone
            FROM complaints c LEFT JOIN orders o ON c.order_id=o.id
            WHERE {where} ORDER BY c.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        complaints = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': complaints, 'total': total})
    except Exception as e:
        logger.error(f'[complaints] {e}')
        return json_response(data={'list': [], 'total': 0})


@bp.route('/admin/complaint/reply', methods=['POST'])
@require_auth
def admin_complaint_reply():
    """回复投诉"""
    try:
        data = request.get_json()
        complaint_id = data.get('id')
        reply = data.get('reply', '')
        conn = get_db()
        c = conn.cursor()
        c.execute('UPDATE complaints SET reply=?,status=1,reply_time=CURRENT_TIMESTAMP WHERE id=?',
                  (reply, complaint_id))
        conn.commit()
        conn.close()
        return json_response(message='回复成功')
    except Exception as e:
        logger.error(f'[complaint_reply] {e}')
        return json_response(message=str(e), code=500)


# ============ Agents ============

@bp.route('/admin/agents', methods=['GET', 'POST'])
@require_auth
def admin_agents():
    try:
        data = request.get_json() if request.method == 'POST' else {}
        keyword = (data or {}).get('keyword', '') or request.args.get('keyword', '')
        page = int((data or {}).get('page', 1) or request.args.get('page', 1))
        page_size = 20
        conn = get_db()
        c = conn.cursor()
        where, params = '1=1', []
        if keyword:
            where += ' AND (name LIKE ? OR contact_name LIKE ? OR contact_phone LIKE ?)'
            params.extend([f'%{keyword}%', f'%{keyword}%', f'%{keyword}%'])
        c.execute(f'SELECT COUNT(*) FROM agents WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT a.*, (SELECT COUNT(*) FROM merchants WHERE agent_id=a.id) as merchant_count
            FROM agents a WHERE {where} ORDER BY a.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        agents = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': agents, 'total': total})
    except Exception as e:
        logger.error(f'[admin_agents] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/agent/save', methods=['POST'])
@require_auth
def admin_agent_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        if data.get('id'):
            fields = ['name','contact_name','contact_phone','status','commission_rate']
            sets, params = [], []
            for f in fields:
                if f in data:
                    sets.append(f'{f}=?')
                    params.append(data[f])
            if data.get('password'):
                sets.append('password_hash=?')
                params.append(generate_password_hash(data['password']))
            params.append(data['id'])
            c.execute(f'UPDATE agents SET {",".join(sets)} WHERE id=?', params)
        else:
            if not data.get('name') or not data.get('contact_phone') or not data.get('password'):
                conn.close()
                return json_response(message='参数不完整', code=400)
            c.execute('INSERT INTO agents (name, contact_name, contact_phone, password_hash, commission_rate) VALUES (?,?,?,?,?)',
                      (data['name'], data.get('contact_name',''), data['contact_phone'], generate_password_hash(data['password']), data.get('commission_rate', 0)))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[agent_save] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/agent/delete', methods=['POST'])
@require_auth
def admin_agent_delete():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('DELETE FROM agents WHERE id=?', (data.get('id'),))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[agent_delete] {e}')
        return json_response(message=str(e), code=500)



@bp.route('/admin/agent/stats', methods=['GET'])
@require_auth
def admin_agent_stats():
    try:
        agent_id = request.args.get('agent_id', type=int)
        start_date = request.args.get('start_date', '')
        end_date = request.args.get('end_date', '')
        if not agent_id:
            return json_response(message='missing agent_id', code=400)
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT id, name, commission_rate FROM agents WHERE id=?', (agent_id,))
        agent = c.fetchone()
        if not agent:
            conn.close()
            return json_response(message='agent not found', code=404)
        agent_dict = dict(agent)
        rate = agent_dict.get('commission_rate', 0) or 0
        c.execute('SELECT id FROM merchants WHERE agent_id=?', (agent_id,))
        merchant_ids = [r[0] for r in c.fetchall()]
        empty_result = json_response(data={
            'agent': agent_dict,
            'total_deposit': 0, 'total_refund': 0, 'total_unreturned': 0,
            'platform_commission': 0, 'agent_income': 0,
            'order_count': 0, 'active_order_count': 0
        })
        if not merchant_ids:
            conn.close()
            return empty_result
        date_where = ''
        date_params = []
        if start_date:
            date_where += " AND o.created_at >= ?"
            date_params.append(start_date + ' 00:00:00')
        if end_date:
            date_where += " AND o.created_at <= ?"
            date_params.append(end_date + ' 23:59:59')
        m_ph = ','.join(['?'] * len(merchant_ids))
        c.execute('SELECT id FROM locations WHERE merchant_id IN (' + m_ph + ')', merchant_ids)
        location_ids = [r[0] for r in c.fetchall()]
        if not location_ids:
            conn.close()
            return empty_result
        l_ph = ','.join(['?'] * len(location_ids))
        c.execute('SELECT id FROM cabinets WHERE location_id IN (' + l_ph + ')', location_ids)
        cabinet_ids = [r[0] for r in c.fetchall()]
        if not cabinet_ids:
            conn.close()
            return empty_result
        c_ph = ','.join(['?'] * len(cabinet_ids))
        sql = 'SELECT COUNT(*) as order_count, COALESCE(SUM(deposit_amount),0) as total_deposit, COALESCE(SUM(refund_amount),0) as total_refund, COALESCE(SUM(deposit_amount - refund_amount),0) as total_unreturned FROM orders o WHERE o.cabinet_id IN (' + c_ph + ') ' + date_where
        c.execute(sql, cabinet_ids + date_params)
        row = c.fetchone()
        order_count = row[0]
        total_deposit = row[1] or 0
        total_refund = row[2] or 0
        total_unreturned = row[3] or 0
        sql2 = 'SELECT COUNT(*) FROM orders o WHERE o.cabinet_id IN (' + c_ph + ') AND o.status=2 ' + date_where
        c.execute(sql2, cabinet_ids + date_params)
        active_order_count = c.fetchone()[0]
        conn.close()
        platform_commission = round(total_unreturned * rate / 100, 2)
        agent_income = round(total_unreturned - platform_commission, 2)
        return json_response(data={
            'agent': agent_dict,
            'total_deposit': round(total_deposit, 2),
            'total_refund': round(total_refund, 2),
            'total_unreturned': round(total_unreturned, 2),
            'platform_commission': platform_commission,
            'agent_income': agent_income,
            'order_count': order_count,
            'active_order_count': active_order_count
        })
    except Exception as e:
        logger.error('[agent_stats] %s', e)
        return json_response(message=str(e), code=500)


# ============ Merchants ============

@bp.route('/admin/merchants', methods=['GET', 'POST'])
@require_auth
def admin_merchants():
    try:
        data = request.get_json() if request.method == 'POST' else {}
        keyword = (data or {}).get('keyword', '') or request.args.get('keyword', '')
        agent_id = (data or {}).get('agent_id', '') or request.args.get('agent_id', '')
        page = int((data or {}).get('page', 1) or request.args.get('page', 1))
        page_size = 20
        conn = get_db()
        c = conn.cursor()
        where, params = '1=1', []
        if keyword:
            where += ' AND (m.name LIKE ? OR m.contact_name LIKE ? OR m.contact_phone LIKE ?)'
            params.extend([f'%{keyword}%', f'%{keyword}%', f'%{keyword}%'])
        if agent_id:
            where += ' AND m.agent_id=?'
            params.append(agent_id)
        c.execute(f'SELECT COUNT(*) FROM merchants m WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT m.*, a.name as agent_name,
            (SELECT COUNT(*) FROM locations WHERE merchant_id=m.id) as location_count,
            (SELECT COUNT(*) FROM cabinets WHERE location_id IN (SELECT id FROM locations WHERE merchant_id=m.id)) as device_count,
            (SELECT COUNT(*) FROM orders WHERE cabinet_id IN (SELECT id FROM cabinets WHERE location_id IN (SELECT id FROM locations WHERE merchant_id=m.id))) as order_count,
            COALESCE((SELECT SUM(deposit_amount) FROM orders WHERE cabinet_id IN (SELECT id FROM cabinets WHERE location_id IN (SELECT id FROM locations WHERE merchant_id=m.id))),0) as total_revenue
            FROM merchants m LEFT JOIN agents a ON m.agent_id=a.id
            WHERE {where} ORDER BY m.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        merchants = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': merchants, 'total': total})
    except Exception as e:
        logger.error(f'[admin_merchants] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/merchant/save', methods=['POST'])
@require_auth
def admin_merchant_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        if data.get('id'):
            fields = ['name','contact_name','contact_phone','agent_id','status','permissions']
            sets, params = [], []
            for f in fields:
                if f in data:
                    sets.append(f'{f}=?')
                    params.append(data[f])
            if data.get('password'):
                sets.append('password_hash=?')
                params.append(generate_password_hash(data['password']))
            params.append(data['id'])
            c.execute(f'UPDATE merchants SET {",".join(sets)} WHERE id=?', params)
        else:
            if not data.get('name') or not data.get('contact_phone') or not data.get('password'):
                conn.close()
                return json_response(message='参数不完整', code=400)
            c.execute('INSERT INTO merchants (name, contact_name, contact_phone, password_hash, agent_id, permissions) VALUES (?,?,?,?,?,?)',
                      (data['name'], data.get('contact_name',''), data['contact_phone'], generate_password_hash(data['password']), data.get('agent_id'), data.get('permissions','[]')))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[merchant_save] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/merchant/delete', methods=['POST'])
@require_auth
def admin_merchant_delete():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('DELETE FROM merchants WHERE id=?', (data.get('id'),))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[merchant_delete] {e}')
        return json_response(message=str(e), code=500)


# ============ Employees ============

@bp.route('/admin/employees', methods=['GET', 'POST'])
@require_auth
def admin_employees():
    try:
        data = request.get_json() if request.method == 'POST' else {}
        keyword = (data or {}).get('keyword', '') or request.args.get('keyword', '')
        merchant_id = (data or {}).get('merchant_id', '') or request.args.get('merchant_id', '')
        page = int((data or {}).get('page', 1) or request.args.get('page', 1))
        page_size = 20
        conn = get_db()
        c = conn.cursor()
        where, params = '1=1', []
        if keyword:
            where += ' AND (e.name LIKE ? OR e.phone LIKE ?)'
            params.extend([f'%{keyword}%', f'%{keyword}%'])
        if merchant_id:
            where += ' AND e.merchant_id=?'
            params.append(merchant_id)
        c.execute(f'SELECT COUNT(*) FROM employees e WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT e.*, m.name as merchant_name
            FROM employees e LEFT JOIN merchants m ON e.merchant_id=m.id
            WHERE {where} ORDER BY e.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        employees = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': employees, 'total': total})
    except Exception as e:
        logger.error(f'[admin_employees] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/employee/save', methods=['POST'])
@require_auth
def admin_employee_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        if data.get('id'):
            fields = ['name','phone','role','merchant_id','status','permissions']
            sets, params = [], []
            for f in fields:
                if f in data:
                    sets.append(f'{f}=?')
                    params.append(data[f])
            if data.get('password'):
                sets.append('password_hash=?')
                params.append(generate_password_hash(data['password']))
            params.append(data['id'])
            c.execute(f'UPDATE employees SET {",".join(sets)} WHERE id=?', params)
        else:
            if not data.get('name') or not data.get('phone') or not data.get('password'):
                conn.close()
                return json_response(message='参数不完整', code=400)
            c.execute('INSERT INTO employees (merchant_id, name, phone, password_hash, role, permissions) VALUES (?,?,?,?,?,?)',
                      (data.get('merchant_id'), data['name'], data['phone'], generate_password_hash(data['password']), data.get('role','staff'), data.get('permissions','[]')))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[employee_save] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/employee/delete', methods=['POST'])
@require_auth
def admin_employee_delete():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('DELETE FROM employees WHERE id=?', (data.get('id'),))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[employee_delete] {e}')
        return json_response(message=str(e), code=500)


# ============ Users ============

@bp.route('/admin/users', methods=['GET', 'POST'])
@require_auth
def admin_users():
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT id, username, role, created_at FROM admin_users ORDER BY created_at DESC')
        users = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data=users)
    except Exception as e:
        logger.error(f'[admin_users] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/user/save', methods=['POST'])
@require_auth
def admin_user_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        if data.get('id'):
            fields = ['username','role']
            sets, params = [], []
            for f in fields:
                if f in data:
                    sets.append(f'{f}=?')
                    params.append(data[f])
            if data.get('password'):
                sets.append('password_hash=?')
                params.append(generate_password_hash(data['password']))
            params.append(data['id'])
            c.execute(f'UPDATE admin_users SET {",".join(sets)} WHERE id=?', params)
        else:
            if not data.get('username') or not data.get('password'):
                conn.close()
                return json_response(message='参数不完整', code=400)
            c.execute('SELECT id FROM admin_users WHERE username=?', (data['username'],))
            if c.fetchone():
                conn.close()
                return json_response(message='用户名已存在', code=400)
            c.execute('INSERT INTO admin_users (username, password_hash, role) VALUES (?,?,?)',
                      (data['username'], generate_password_hash(data['password']), data.get('role','admin')))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[user_save] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/user/delete', methods=['POST'])
@require_auth
def admin_user_delete():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('DELETE FROM admin_users WHERE id=? AND id!=?', (data.get('id'), session.get('admin_id', 0)))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[user_delete] {e}')
        return json_response(message=str(e), code=500)


# ============ APK ============

@bp.route('/admin/apk-version', methods=['GET', 'POST'])
@require_auth
def admin_apk_version():
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM apk_version ORDER BY version_code DESC LIMIT 1')
        row = c.fetchone()
        conn.close()
        if row:
            return json_response(data=dict(row))
        return json_response(data={})
    except Exception as e:
        logger.error(f'[apk_version] {e}')
        return json_response(data={})


@bp.route('/admin/apk-version/save', methods=['POST'])
@require_auth
def admin_apk_version_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('''INSERT INTO apk_version (version_name,version_code,download_url,update_desc) VALUES (?,?,?,?)''',
                  (data.get('version_name'), data.get('version_code'), data.get('download_url'), data.get('update_desc','')))
        conn.commit()
        conn.close()
        return json_response(message='发布成功')
    except Exception as e:
        logger.error(f'[apk_version_save] {e}')
        return json_response(message=str(e), code=500)


# ============ After-sales ============

@bp.route('/admin/after-sales', methods=['GET', 'POST'])
@require_auth
def admin_after_sales():
    """售后工单列表"""
    try:
        data = request.get_json() if request.method == 'POST' else {}
        status = (data or {}).get('status', '') or request.args.get('status', '')
        page = int((data or {}).get('page', 1) or request.args.get('page', 1))
        page_size = 20
        conn = get_db()
        c = conn.cursor()
        where, params = '1=1', []
        if status:
            where += ' AND status=?'
            params.append(status)
        c.execute(f'SELECT COUNT(*) FROM after_sales WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT a.*, c.cabinet_code, l.name as location_name
            FROM after_sales a LEFT JOIN cabinets c ON a.cabinet_id=c.id
            LEFT JOIN locations l ON c.location_id=l.id
            WHERE {where} ORDER BY a.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        records = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': records, 'total': total})
    except Exception as e:
        logger.error(f'[after_sales] {e}')
        return json_response(data={'list': [], 'total': 0})


@bp.route('/admin/after-sales/save', methods=['POST'])
@require_auth
def admin_after_sales_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        if data.get('id'):
            c.execute('UPDATE after_sales SET cabinet_id=?,type=?,description=? WHERE id=?',
                      (data.get('cabinet_id'), data.get('type'), data.get('description'), data['id']))
        else:
            ticket_no = f'AS{datetime.now().strftime("%Y%m%d%H%M%S")}'
            c.execute('''INSERT INTO after_sales (ticket_no,cabinet_id,type,description,status) VALUES (?,?,?,?,?)''',
                      (ticket_no, data.get('cabinet_id'), data.get('type'), data.get('description',''), 'pending'))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[after_sales_save] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/after-sales/handle', methods=['POST'])
@require_auth
def admin_after_sales_handle():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('UPDATE after_sales SET status=?,handler_note=?,handler=? WHERE id=?',
                  (data.get('status','processing'), data.get('handler_note',''), session.get('admin_username','admin'), data['id']))
        conn.commit()
        conn.close()
        return json_response(message='处理成功')
    except Exception as e:
        logger.error(f'[after_sales_handle] {e}')
        return json_response(message=str(e), code=500)


# ============ Stats ============

@bp.route('/admin/stats', methods=['GET', 'POST'])
@require_auth
def admin_stats():
    """统计数据"""
    try:
        data = request.get_json() if request.method == 'POST' else request.args.to_dict()
        location_id = data.get('location_id', '')
        start_date = data.get('start_date', '')
        end_date = data.get('end_date', '')
        conn = get_db()
        c = conn.cursor()
        # Summary - status=1 means in use
        where_parts = []
        params = []
        if location_id:
            where_parts.append('cabinet_id IN (SELECT id FROM cabinets WHERE location_id=?)')
            params.append(location_id)
        if start_date and end_date:
            where_parts.append('date(store_time)>=? AND date(store_time)<=?')
            params.extend([start_date, end_date])
        elif not start_date and not end_date:
            where_parts.append('store_time>=datetime(\'now\', \'-30 days\')')
        where_clause = (' WHERE ' + ' AND '.join(where_parts)) if where_parts else ''
        c.execute(f'''SELECT COUNT(*) as total, 
            SUM(CASE WHEN status=2 THEN 1 ELSE 0 END) as active_count,
            COALESCE(SUM(o.deposit_amount),0) as deposit_total,
            COALESCE(SUM(o.refund_amount),0) as refund_total
            FROM orders{where_clause}''', params)
        summary = dict(c.fetchone())
        summary['net_income'] = float(summary.get('deposit_total',0)) - float(summary.get('refund_total',0))
        # Location stats - join through cabinets since orders have no location_id
        c.execute('''SELECT l.name as location_name, m.name as merchant_name,
            COUNT(o.id) as order_count,
            SUM(CASE WHEN o.status=2 THEN 1 ELSE 0 END) as active_count,
            COALESCE(SUM(o.deposit_amount),0) as deposit_total,
            COALESCE(SUM(o.refund_amount),0) as refund_total
            FROM locations l LEFT JOIN merchants m ON l.merchant_id=m.id
            LEFT JOIN cabinets cab ON cab.location_id=l.id
            LEFT JOIN orders o ON o.cabinet_id=cab.id
            GROUP BY l.id''')
        locations = []
        for r in c.fetchall():
            d = dict(r)
            d['net_income'] = float(d.get('deposit_total',0) or 0) - float(d.get('refund_total',0) or 0)
            locations.append(d)
        # Trend
        trend = []
        for i in range(30):
            date = (datetime.now() - timedelta(days=29-i)).strftime('%Y-%m-%d')
            c.execute('''SELECT COUNT(*) as order_count,
                COALESCE(SUM(o.deposit_amount),0) as deposit_total,
                COALESCE(SUM(o.refund_amount),0) as refund_total
                FROM orders WHERE date(store_time)=?''', (date,))
            row = c.fetchone()
            trend.append({
                'date': date,
                'order_count': row['order_count'] if row else 0,
                'deposit_total': float(row['deposit_total'] if row else 0),
                'refund_total': float(row['refund_total'] if row else 0)
            })
        conn.close()
        return json_response(data={'summary': summary, 'locations': locations, 'trend': trend})
    except Exception as e:
        logger.error(f'[stats] {e}')
        return json_response(data={'summary': {}, 'locations': [], 'trend': []})



@bp.route('/admin/biz-stats', methods=['GET', 'POST'])
@require_auth
def admin_biz_stats():
    """业务统计数据"""
    try:
        data = request.get_json() if request.method == 'POST' else request.args.to_dict()
        province = data.get('province', '')
        agent_id = data.get('agent_id', '')
        location_id = data.get('location_id', '')
        start_date = data.get('start_date', '')
        end_date = data.get('end_date', '')
        
        conn = get_db()
        c = conn.cursor()
        
        # 构建基础查询条件
        where_parts = []
        params = []
        
        if location_id:
            where_parts.append('cab.id IN (SELECT id FROM cabinets WHERE location_id=?)')
            params.append(location_id)
        if agent_id:
            where_parts.append('l.agent_id=?')
            params.append(agent_id)
        if province:
            where_parts.append('l.province=?')
            params.append(province)
        if start_date and end_date:
            where_parts.append('date(o.store_time)>=? AND date(o.store_time)<=?')
            params.extend([start_date, end_date])
        elif not start_date and not end_date:
            where_parts.append("o.store_time>=datetime('now', '-30 days')")
        
        where_clause = (' WHERE ' + ' AND '.join(where_parts)) if where_parts else ''
        
        # 订单汇总统计
        c.execute(f'''SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN o.status=2 THEN 1 ELSE 0 END) as active_count,
            COALESCE(SUM(o.deposit_amount),0) as deposit_total,
            COALESCE(SUM(o.refund_amount),0) as refund_total
            FROM orders o
            LEFT JOIN cabinets cab ON o.cabinet_id=cab.id
            LEFT JOIN locations l ON cab.location_id=l.id
            {where_clause}''', params)
        row = c.fetchone()
        orderStats = {
            'total': row[0] if row else 0,
            'active_count': row[1] if row else 0,
            'deposit_total': float(row[2] if row and row[2] else 0),
            'refund_total': float(row[3] if row and row[3] else 0),
            'net_income': float(row[2] if row and row[2] else 0) - float(row[3] if row and row[3] else 0)
        }
        
        # 按网点聚合统计
        c.execute(f'''SELECT 
            l.id as location_id,
            l.name as location_name,
            COUNT(o.id) as order_count,
            SUM(CASE WHEN o.status=2 THEN 1 ELSE 0 END) as active_count,
            COALESCE(SUM(o.deposit_amount),0) as deposit_total,
            COALESCE(SUM(o.refund_amount),0) as refund_total
            FROM locations l
            LEFT JOIN cabinets cab ON cab.location_id=l.id
            LEFT JOIN orders o ON o.cabinet_id=cab.id
            {where_clause}
            GROUP BY l.id
            ORDER BY order_count DESC''', params)
        locations = []
        for r in c.fetchall():
            d = {'location_id': r[0], 'location_name': r[1], 'order_count': r[2], 'active_count': r[3]}
            d['deposit_total'] = float(r[4] if r[4] else 0)
            d['refund_total'] = float(r[5] if r[5] else 0)
            d['net_income'] = d['deposit_total'] - d['refund_total']
            locations.append(d)
        
        # 按省份聚合
        c.execute(f'''SELECT 
            COALESCE(l.province, '未知') as province,
            COUNT(o.id) as order_count,
            COALESCE(SUM(o.deposit_amount),0) as deposit_total
            FROM orders o
            LEFT JOIN cabinets cab ON o.cabinet_id=cab.id
            LEFT JOIN locations l ON cab.location_id=l.id
            {where_clause}
            GROUP BY l.province
            ORDER BY order_count DESC''', params)
        provinces = []
        for r in c.fetchall():
            provinces.append({
                'province': r[0],
                'order_count': r[1],
                'deposit_total': float(r[2] if r[2] else 0)
            })
        
        # 按天聚合趋势
        daily = []
        days = 30
        for i in range(days):
            date = (datetime.now() - timedelta(days=days-1-i)).strftime('%Y-%m-%d')
            c.execute(f'''SELECT COUNT(*) as cnt, COALESCE(SUM(o.deposit_amount),0) as dep, COALESCE(SUM(o.refund_amount),0) as ref
                FROM orders o
                LEFT JOIN cabinets cab ON o.cabinet_id=cab.id
                LEFT JOIN locations l ON cab.location_id=l.id
                WHERE date(o.store_time)=?
                {(' AND ' + ' AND '.join(where_parts)) if where_parts else ''}''', [date] + params)
            row = c.fetchone()
            daily.append({
                'date': date,
                'order_count': row[0] if row else 0,
                'deposit_total': float(row[1] if row and row[1] else 0),
                'refund_total': float(row[2] if row and row[2] else 0)
            })
        
        conn.close()
        return json_response(data={
            'orderStats': orderStats,
            'locations': locations,
            'provinces': provinces,
            'daily': daily
        })
    except Exception as e:
        logger.error(f'[biz_stats] {e}')
        return json_response(message=str(e), code=500)


# ============ Channels ============

@bp.route('/admin/channels', methods=['GET', 'POST'])
@require_auth
def admin_channels():
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM payment_channels ORDER BY created_at DESC')
        channels = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data=channels)
    except Exception as e:
        logger.error(f'[channels] {e}')
        return json_response(data=[])


@bp.route('/admin/channel/save', methods=['POST'])
@require_auth
def admin_channel_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        if data.get('id'):
            fields = ['name','channel_type','app_id','mch_id','api_key','status']
            sets, params = [], []
            for f in fields:
                if f in data:
                    sets.append(f'{f}=?')
                    params.append(data[f])
            params.append(data['id'])
            c.execute(f'UPDATE payment_channels SET {",".join(sets)} WHERE id=?', params)
        else:
            c.execute('''INSERT INTO payment_channels (name,channel_type,app_id,mch_id,api_key,status) VALUES (?,?,?,?,?,?)''',
                      (data.get('name'), data.get('channel_type'), data.get('app_id'),
                       data.get('mch_id'), data.get('api_key'), data.get('status',1)))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[channel_save] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/channel/delete', methods=['POST'])
@require_auth
def admin_channel_delete():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('DELETE FROM payment_channels WHERE id=?', (data.get('id'),))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[channel_delete] {e}')
        return json_response(message=str(e), code=500)


# ============ Password ============

@bp.route('/admin/change-password', methods=['POST'])
@require_auth
def admin_change_password():
    try:
        data = request.get_json()
        old_pwd = data.get('old_password', '')
        new_pwd = data.get('new_password', '')
        if not all([old_pwd, new_pwd]):
            return json_response(message='旧密码和新密码不能为空', code=400)
        if len(new_pwd) < 6:
            return json_response(message='新密码长度不能少于6位', code=400)
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT password_hash FROM admin_users WHERE id=?', (session['admin_id'],))
        admin = c.fetchone()
        if not admin or not check_password_hash(admin['password_hash'], old_pwd):
            conn.close()
            return json_response(message='旧密码错误', code=400)
        c.execute('UPDATE admin_users SET password_hash=? WHERE id=?',
                  (generate_password_hash(new_pwd), session['admin_id']))
        conn.commit()
        conn.close()
        return json_response(message='密码修改成功')
    except Exception as e:
        logger.error(f'[change_pwd] {e}')
        return json_response(message=str(e), code=500)
# -*- coding: utf-8 -*-
"""
11个功能页面的API端点
追加到 routes/admin_v2.py 末尾
"""
import os
import sqlite3
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'locker.db')
# Fix: actual DB is in app root, not parent of routes/

# ============ 建表 ============

def _ensure_tables():
    db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'locker.db')
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS companies(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        credit_code TEXT,
        contact_person TEXT,
        contact_phone TEXT,
        address TEXT,
        status INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT (datetime('now'))
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS blacklist(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone TEXT NOT NULL,
        reason TEXT,
        cabinet_id INTEGER,
        operator TEXT,
        status INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT (datetime('now'))
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS after_sales(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_no TEXT UNIQUE,
        cabinet_id INTEGER,
        location_id INTEGER,
        device_id TEXT,
        fault_type TEXT,
        description TEXT,
        status TEXT DEFAULT 'pending',
        handler TEXT,
        handler_note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS alarms(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL,
        cabinet_id INTEGER,
        device_id TEXT,
        content TEXT,
        level INTEGER DEFAULT 1,
        status INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT (datetime('now')),
        resolved_at DATETIME,
        resolver TEXT
    )""")
    conn.commit()
    conn.close()

_ensure_tables()

# ============ 1. 结算管理 ============

@bp.route('/settlement/list', methods=['GET', 'POST'])
@require_auth
def settlement_list():
    try:
        page = int(request.args.get('page', 1))
        size = int(request.args.get('size', 20))
        _d2=request.get_json(silent=True) or {}; location_id = _d2.get('location_id') or request.args.get('location_id', '')
        date_start = request.args.get('date_start', '')
        date_end = request.args.get('date_end', '')
        offset = (page - 1) * size
        conn = get_db()
        c = conn.cursor()
        sql = """SELECT o.id, o.order_no, o.user_phone, o.cabinet_id, o.deposit_amount,
                o.refund_amount, o.refund_mark, o.refund_status, o.status, o.store_time, o.retrieve_time, o.cabinet_name,
                c.location_id, l.name as location_name, m.name as merchant_name
                FROM orders o LEFT JOIN cabinets c ON o.cabinet_id=c.id
                LEFT JOIN locations l ON c.location_id=l.id
                LEFT JOIN merchants m ON l.merchant_id=m.id
                WHERE 1=1"""
        params = []
        if location_id:
            sql += " AND c.location_id=?"
            params.append(location_id)
        if date_start:
            sql += " AND o.store_time>=?"
            params.append(date_start)
        if date_end:
            sql += " AND o.store_time<=?"
            params.append(date_end)
        sql += " ORDER BY o.id DESC LIMIT ? OFFSET ?"
        params += [size, offset]
        c.execute(sql, params)
        rows = [dict(r) for r in c.fetchall()]
        count_sql = "SELECT COUNT(*) FROM orders o LEFT JOIN cabinets c ON o.cabinet_id=c.id WHERE 1=1"
        count_params = []
        if location_id:
            count_sql += " AND c.location_id=?"
            count_params.append(location_id)
        if date_start:
            count_sql += " AND o.store_time>=?"
            count_params.append(date_start)
        if date_end:
            count_sql += " AND o.store_time<=?"
            count_params.append(date_end)
        c.execute(count_sql, count_params)
        total = c.fetchone()[0]
        conn.close()
        return json_response(data={'list': rows, 'total': total, 'page': page, 'size': size})
    except Exception as e:
        logger.error(f'[settlement_list] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/settlement/stats', methods=['GET', 'POST'])
@require_auth
def settlement_stats():
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT COUNT(*) as total_orders, COALESCE(SUM(deposit_amount),0) as total_deposit FROM orders")
        row = c.fetchone()
        c.execute("SELECT COUNT(*) as active_orders FROM orders WHERE status=2")
        active = c.fetchone()[0]
        c.execute("SELECT COUNT(*) as completed FROM orders WHERE status=2")
        completed = c.fetchone()[0]
        c.execute("SELECT COUNT(*) as refunded FROM orders WHERE status=3")
        refunded = c.fetchone()[0]
        conn.close()
        return json_response(data={
            'total_orders': row['total_orders'],
            'total_deposit': row['total_deposit'],
            'active_orders': active,
            'completed': completed,
            'refunded': refunded
        })
    except Exception as e:
        logger.error(f'[settlement_stats] {e}')
        return json_response(message=str(e), code=500)

# ============ 2. 提现管理 ============

@bp.route('/withdrawals/list', methods=['GET', 'POST'])
@require_auth
def withdrawals_list():
    try:
        page = int(request.args.get('page', 1))
        size = int(request.args.get('size', 20))
        status = request.args.get('status', '')
        offset = (page - 1) * size
        conn = get_db()
        c = conn.cursor()
        sql = """SELECT wr.*, o.order_no, o.deposit_amount as order_amount, c.cabinet_code
                FROM withdrawal_records wr 
                LEFT JOIN orders o ON wr.order_id=o.id
                LEFT JOIN cabinets c ON o.cabinet_id=c.id
                WHERE 1=1"""
        params = []
        if status != '':
            sql += " AND status=?"
            params.append(int(status))
        sql += " ORDER BY id DESC LIMIT ? OFFSET ?"
        params += [size, offset]
        c.execute(sql, params)
        rows = [dict(r) for r in c.fetchall()]
        count_sql = "SELECT COUNT(*) FROM withdrawal_records WHERE 1=1"
        count_params = []
        if status != '':
            count_sql += " AND status=?"
            count_params.append(int(status))
        c.execute(count_sql, count_params)
        total = c.fetchone()[0]
        conn.close()
        return json_response(data={'list': rows, 'total': total, 'page': page, 'size': size})
    except Exception as e:
        logger.error(f'[withdrawals_list] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/withdrawals/approve', methods=['POST'])
@require_auth
def withdrawals_approve():
    try:
        data = request.get_json()
        wid = data.get('id')
        action = data.get('action')  # approve/reject
        if not wid or not action:
            return json_response(message='参数缺失', code=400)
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT * FROM withdrawal_records WHERE id=?", (wid,))
        record = c.fetchone()
        if not record:
            conn.close()
            return json_response(message='记录不存在', code=404)
        if record['status'] != 0:
            conn.close()
            return json_response(message='该记录已处理', code=400)
        new_status = 1 if action == 'approve' else 2
        c.execute("UPDATE withdrawal_records SET status=?, approve_time=datetime('now'), approver=? WHERE id=?",
                  (new_status, session.get('admin_user', 'admin'), wid))
        conn.commit()
        conn.close()
        return json_response(message='处理成功')
    except Exception as e:
        logger.error(f'[withdrawals_approve] {e}')
        return json_response(message=str(e), code=500)

# ============ 3. 平台流水 ============

@bp.route('/platform-flow/list', methods=['GET', 'POST'])
@require_auth
def platform_flow_list():
    try:
        page = int(request.args.get('page', 1))
        size = int(request.args.get('size', 20))
        flow_type = request.args.get('type', '')
        offset = (page - 1) * size
        conn = get_db()
        c = conn.cursor()
        sql = """SELECT p.id, p.order_id, p.type, p.amount, p.transaction_id, p.status, p.created_at,
                p.refund_transaction_id, o.order_no, o.user_phone
                FROM payments p LEFT JOIN orders o ON p.order_id=o.id WHERE 1=1"""
        params = []
        if flow_type:
            sql += " AND p.type=?"
            params.append(int(flow_type))
        sql += " ORDER BY p.id DESC LIMIT ? OFFSET ?"
        params += [size, offset]
        c.execute(sql, params)
        rows = [dict(r) for r in c.fetchall()]
        count_sql = "SELECT COUNT(*) FROM payments p WHERE 1=1"
        count_params = []
        if flow_type:
            count_sql += " AND p.type=?"
            count_params.append(int(flow_type))
        c.execute(count_sql, count_params)
        total = c.fetchone()[0]
        c.execute("SELECT COALESCE(SUM(CASE WHEN type=1 THEN amount END),0) as total_deposit, COALESCE(SUM(CASE WHEN type=2 THEN amount END),0) as total_refund FROM payments WHERE status=2")
        summary = c.fetchone()
        conn.close()
        return json_response(data={
            'list': rows, 'total': total, 'page': page, 'size': size,
            'total_deposit': summary['total_deposit'],
            'total_refund': summary['total_refund']
        })
    except Exception as e:
        logger.error(f'[platform_flow_list] {e}')
        return json_response(message=str(e), code=500)

# ============ 4. 资金流水 ============

@bp.route('/fund-flow/list', methods=['GET', 'POST'])
@require_auth
def fund_flow_list():
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute("""SELECT ub.phone, ub.balance, ub.total_deposited, ub.total_withdrawn, ub.first_use_time,
                (SELECT COUNT(*) FROM orders WHERE user_phone=ub.phone) as order_count
                FROM user_balances ub ORDER BY ub.id DESC""")
        rows = [dict(r) for r in c.fetchall()]
        c.execute("SELECT COUNT(*) as total_users, COALESCE(SUM(balance),0) as total_balance FROM user_balances")
        summary = c.fetchone()
        conn.close()
        return json_response(data={'list': rows, 'total_users': summary['total_users'], 'total_balance': summary['total_balance']})
    except Exception as e:
        logger.error(f'[fund_flow_list] {e}')
        return json_response(message=str(e), code=500)

# ============ 5. 综合查询 ============

@bp.route('/query-all/list', methods=['GET', 'POST'])
@require_auth
def query_all_list():
    try:
        keyword = request.args.get('keyword', '')
        query_type = request.args.get('type', 'order')
        conn = get_db()
        c = conn.cursor()
        results = []
        if not keyword:
            return json_response(data={'list': [], 'total': 0})
        if query_type == 'order':
            c.execute("""SELECT o.*, c.cabinet_code, c.name as cabinet_name, l.name as location_name
                    FROM orders o LEFT JOIN cabinets c ON o.cabinet_id=c.id
                    LEFT JOIN locations l ON c.location_id=l.id
                    WHERE o.order_no LIKE ? OR o.user_phone LIKE ? ORDER BY o.id DESC LIMIT 50""",
                    (f'%{keyword}%', f'%{keyword}%'))
            results = [dict(r) for r in c.fetchall()]
        elif query_type == 'phone':
            c.execute("""SELECT ub.*, (SELECT COUNT(*) FROM orders WHERE user_phone=ub.phone) as order_count
                    FROM user_balances ub WHERE ub.phone LIKE ? LIMIT 50""", (f'%{keyword}%',))
            results = [dict(r) for r in c.fetchall()]
        elif query_type == 'cabinet':
            c.execute("""SELECT c.*, l.name as location_name
                    FROM cabinets c LEFT JOIN locations l ON c.location_id=l.id
                    WHERE c.cabinet_code LIKE ? OR c.name LIKE ? OR c.mainboard_device_id LIKE ? LIMIT 50""",
                    (f'%{keyword}%', f'%{keyword}%', f'%{keyword}%'))
            results = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': results, 'total': len(results)})
    except Exception as e:
        logger.error(f'[query_all_list] {e}')
        return json_response(message=str(e), code=500)

# ============ 6. 公司管理 ============

@bp.route('/companies/list', methods=['GET', 'POST'])
@require_auth
def companies_list():
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT * FROM companies ORDER BY id DESC")
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': rows, 'total': len(rows)})
    except Exception as e:
        logger.error(f'[companies_list] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/companies/save', methods=['POST'])
@require_auth
def companies_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        cid = data.get('id')
        if cid:
            c.execute("UPDATE companies SET name=?, credit_code=?, contact_person=?, contact_phone=?, address=?, status=? WHERE id=?",
                      (data.get('name',''), data.get('credit_code',''), data.get('contact_person',''),
                       data.get('contact_phone',''), data.get('address',''), data.get('status',1), cid))
        else:
            c.execute("INSERT INTO companies(name, credit_code, contact_person, contact_phone, address, status) VALUES(?,?,?,?,?,?)",
                      (data.get('name',''), data.get('credit_code',''), data.get('contact_person',''),
                       data.get('contact_phone',''), data.get('address',''), data.get('status',1)))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[companies_save] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/companies/delete', methods=['POST'])
@require_auth
def companies_delete():
    try:
        data = request.get_json()
        cid = data.get('id')
        conn = get_db()
        c = conn.cursor()
        c.execute("DELETE FROM companies WHERE id=?", (cid,))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[companies_delete] {e}')
        return json_response(message=str(e), code=500)

# ============ 7. 黑名单管理 ============

@bp.route('/blacklist/list', methods=['GET', 'POST'])
@require_auth
def blacklist_list():
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute("""SELECT b.*, c.cabinet_code, c.name as cabinet_name
                FROM blacklist b LEFT JOIN cabinets c ON b.cabinet_id=c.id
                ORDER BY b.id DESC""")
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': rows, 'total': len(rows)})
    except Exception as e:
        logger.error(f'[blacklist_list] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/blacklist/save', methods=['POST'])
@require_auth
def blacklist_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        bid = data.get('id')
        if bid:
            c.execute("UPDATE blacklist SET phone=?, reason=?, cabinet_id=?, status=? WHERE id=?",
                      (data.get('phone',''), data.get('reason',''), data.get('cabinet_id'), data.get('status',1), bid))
        else:
            c.execute("INSERT INTO blacklist(phone, reason, cabinet_id, operator, status) VALUES(?,?,?,?,?)",
                      (data.get('phone',''), data.get('reason',''), data.get('cabinet_id'),
                       session.get('admin_user','admin'), data.get('status',1)))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[blacklist_save] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/blacklist/delete', methods=['POST'])
@require_auth
def blacklist_delete():
    try:
        data = request.get_json()
        bid = data.get('id')
        conn = get_db()
        c = conn.cursor()
        c.execute("DELETE FROM blacklist WHERE id=?", (bid,))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[blacklist_delete] {e}')
        return json_response(message=str(e), code=500)

# ============ 8. 报警记录 ============

@bp.route('/alarms/list', methods=['GET', 'POST'])
@require_auth
def alarms_list():
    try:
        page = int(request.args.get('page', 1))
        size = int(request.args.get('size', 20))
        status = request.args.get('status', '')
        offset = (page - 1) * size
        conn = get_db()
        c = conn.cursor()
        sql = """SELECT a.*, c.cabinet_code, c.name as cabinet_name
                FROM alarms a LEFT JOIN cabinets c ON a.cabinet_id=c.id WHERE 1=1"""
        params = []
        if status != '':
            sql += " AND a.status=?"
            params.append(int(status))
        sql += " ORDER BY a.id DESC LIMIT ? OFFSET ?"
        params += [size, offset]
        c.execute(sql, params)
        rows = [dict(r) for r in c.fetchall()]
        count_sql = "SELECT COUNT(*) FROM alarms a WHERE 1=1"
        count_params = []
        if status != '':
            count_sql += " AND a.status=?"
            count_params.append(int(status))
        c.execute(count_sql, count_params)
        total = c.fetchone()[0]
        conn.close()
        return json_response(data={'list': rows, 'total': total, 'page': page, 'size': size})
    except Exception as e:
        logger.error(f'[alarms_list] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/alarms/resolve', methods=['POST'])
@require_auth
def alarms_resolve():
    try:
        data = request.get_json()
        aid = data.get('id')
        conn = get_db()
        c = conn.cursor()
        c.execute("UPDATE alarms SET status=1, resolved_at=datetime('now'), resolver=? WHERE id=?",
                  (session.get('admin_user','admin'), aid))
        conn.commit()
        conn.close()
        return json_response(message='处理成功')
    except Exception as e:
        logger.error(f'[alarms_resolve] {e}')
        return json_response(message=str(e), code=500)

# ============ 9. 位置报警 ============

@bp.route('/location-alarms/list', methods=['GET', 'POST'])
@require_auth
def location_alarms_list():
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute("""SELECT c.id, c.cabinet_code, c.name, c.location_id, l.name as location_name,
                c.last_heartbeat, c.status, c.mainboard_device_id,
                (SELECT COUNT(*) FROM alarms WHERE cabinet_id=c.id AND status=0) as alarm_count,
                (SELECT COUNT(*) FROM orders WHERE cabinet_id=c.id AND status=1) as active_orders
                FROM cabinets c LEFT JOIN locations l ON c.location_id=l.id
                WHERE c.location_id IS NOT NULL ORDER BY c.id""")
        rows = [dict(r) for r in c.fetchall()]
        import datetime as dt_mod
        for row in rows:
            if row.get('last_heartbeat'):
                try:
                    hb = dt_mod.datetime.strptime(row['last_heartbeat'], '%Y-%m-%d %H:%M:%S')
                    diff = (dt_mod.datetime.utcnow() - hb).total_seconds()
                    row['offline'] = diff > 300
                    row['heartbeat_age_min'] = int(diff / 60)
                except:
                    row['offline'] = True
                    row['heartbeat_age_min'] = 999
            else:
                row['offline'] = True
                row['heartbeat_age_min'] = 0
        conn.close()
        return json_response(data={'list': rows, 'total': len(rows)})
    except Exception as e:
        logger.error(f'[location_alarms_list] {e}')
        return json_response(message=str(e), code=500)

# ============ 10. 角色管理 ============

@bp.route('/roles/list', methods=['GET', 'POST'])
@require_auth
def roles_list():
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT id, username, role, created_at FROM admin_users ORDER BY id")
        rows = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': rows, 'total': len(rows)})
    except Exception as e:
        logger.error(f'[roles_list] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/roles/save', methods=['POST'])
@require_auth
def roles_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        uid = data.get('id')
        username = data.get('username','')
        role = data.get('role','viewer')
        password = data.get('password','')
        if uid:
            if password:
                c.execute("UPDATE admin_users SET username=?, role=?, password_hash=? WHERE id=?",
                          (username, role, generate_password_hash(password), uid))
            else:
                c.execute("UPDATE admin_users SET username=?, role=? WHERE id=?", (username, role, uid))
        else:
            if not password:
                return json_response(message='新用户必须设置密码', code=400)
            c.execute("INSERT INTO admin_users(username, password_hash, role) VALUES(?,?,?)",
                      (username, generate_password_hash(password), role))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[roles_save] {e}')
        return json_response(message=str(e), code=500)

# ============ 11. 数据重置 ============

@bp.route('/data-reset/stats', methods=['GET', 'POST'])
@require_auth
def data_reset_stats():
    try:
        conn = get_db()
        c = conn.cursor()
        stats = {}
        for table in ['orders','payments','withdrawal_records','complaints','device_logs','storage_records','door_records','pending_lock_cmds']:
            c.execute(f"SELECT COUNT(*) FROM {table}")
            stats[table] = c.fetchone()[0]
        conn.close()
        return json_response(data=stats)
    except Exception as e:
        logger.error(f'[data_reset_stats] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/data-reset/exec', methods=['POST'])
@require_auth
def data_reset_exec():
    try:
        data = request.get_json()
        tables = data.get('tables', [])
        if not tables:
            return json_response(message='请选择要清理的表', code=400)
        conn = get_db()
        c = conn.cursor()
        allowed = ['orders','payments','withdrawal_records','complaints','device_logs','storage_records','door_records','pending_lock_cmds']
        for t in tables:
            if t in allowed:
                c.execute(f"DELETE FROM {t}")
        conn.commit()
        conn.close()
        return json_response(message='清理完成')
    except Exception as e:
        logger.error(f'[data_reset_exec] {e}')
        return json_response(message=str(e), code=500)

# ==================== P0-3: 系统设置管理 ====================

@bp.route('/settings', methods=['GET', 'POST'])
def get_settings():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        rows = c.execute("SELECT setting_key as key, setting_value as value, description FROM system_settings").fetchall()
        settings = {row['key']: {'value': row['value'], 'desc': row['description']} for row in rows}
        conn.close()
        return jsonify({'code': 200, 'data': settings})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

@bp.route('/settings/save', methods=['POST'])
def save_settings():
    try:
        data = request.get_json() or {}
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        for key, value in data.items():
            existing = c.execute("SELECT id FROM system_settings WHERE setting_key=?", (key,)).fetchone()
            if existing:
                c.execute("UPDATE system_settings SET setting_value=? WHERE setting_key=?", (str(value), key))
            else:
                c.execute("INSERT INTO system_settings (setting_key, setting_value, description) VALUES (?, ?, '')", (key, str(value)))
        conn.commit()
        conn.close()
        return jsonify({'code': 200, 'message': '保存成功'})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

@bp.route('/settings/order-visibility', methods=['GET', 'POST'])
def get_order_visibility():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        hide_rate = c.execute("SELECT setting_value FROM system_settings WHERE setting_key='order_hide_rate'").fetchone()
        whitelist = c.execute("SELECT setting_value FROM system_settings WHERE setting_key='order_hide_whitelist'").fetchone()
        conn.close()
        return jsonify({'code': 200, 'data': {
            'order_hide_rate': int(hide_rate['value']) if hide_rate else 0,
            'order_hide_whitelist': whitelist['value'] if whitelist else ''
        }})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

@bp.route('/settings/order-visibility/save', methods=['POST'])
def save_order_visibility():
    try:
        data = request.get_json() or {}
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        for key in ['order_hide_rate', 'order_hide_whitelist']:
            val = data.get(key, '')
            existing = c.execute("SELECT id FROM system_settings WHERE setting_key=?", (key,)).fetchone()
            if existing:
                c.execute("UPDATE system_settings SET setting_value=? WHERE setting_key=?", (str(val), key))
            else:
                c.execute("INSERT INTO system_settings (setting_key, setting_value, description) VALUES (?, ?, '')", (key, str(val)))
        conn.commit()
        conn.close()
        return jsonify({'code': 200, 'message': '保存成功'})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

@bp.route('/settings/duplicate-filter', methods=['GET', 'POST'])
def get_duplicate_filter():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        enabled = c.execute("SELECT setting_value FROM system_settings WHERE setting_key='duplicate_filter_enabled'").fetchone()
        days = c.execute("SELECT setting_value FROM system_settings WHERE setting_key='duplicate_days'").fetchone()
        limit = c.execute("SELECT setting_value FROM system_settings WHERE setting_key='duplicate_limit'").fetchone()
        conn.close()
        return jsonify({'code': 200, 'data': {
            'duplicate_filter_enabled': int(enabled['value']) if enabled and enabled['value'] not in ('false','0') else 0,
            'duplicate_days': int(days['value']) if days else 7,
            'duplicate_limit': int(limit['value']) if limit else 5
        }})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

@bp.route('/settings/duplicate-filter/save', methods=['POST'])
def save_duplicate_filter():
    try:
        data = request.get_json() or {}
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        for key in ['duplicate_filter_enabled', 'duplicate_days', 'duplicate_limit']:
            val = data.get(key, '')
            existing = c.execute("SELECT id FROM system_settings WHERE setting_key=?", (key,)).fetchone()
            if existing:
                c.execute("UPDATE system_settings SET setting_value=? WHERE setting_key=?", (str(val), key))
            else:
                c.execute("INSERT INTO system_settings (setting_key, setting_value, description) VALUES (?, ?, '')", (key, str(val)))
        conn.commit()
        conn.close()
        return jsonify({'code': 200, 'message': '保存成功'})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})


# ==================== P0-4: 柜组管理 ====================

@bp.route('/admin/cabinet-groups', methods=['GET', 'POST'])
def cabinet_groups_list():
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        keyword = request.args.get('keyword', '')
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        where = "WHERE 1=1"
        params = []
        if keyword:
            where += " AND (group_code LIKE ? OR name LIKE ?)"
            params += [f'%{keyword}%', f'%{keyword}%']
        total = c.execute(f"SELECT COUNT(*) FROM cabinet_groups {where}", params).fetchone()[0]
        rows = c.execute(f"SELECT * FROM cabinet_groups {where} ORDER BY id DESC LIMIT ? OFFSET ?", params + [limit, (page-1)*limit]).fetchall()
        groups = []
        for r in rows:
            g = dict(r)
            cabinet_count = c.execute("SELECT COUNT(*) FROM cabinets WHERE group_id=?", (g['id'],)).fetchone()[0]
            g['cabinet_count'] = cabinet_count
            groups.append(g)
        conn.close()
        return jsonify({'code': 200, 'data': {'list': groups, 'total': total}})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

@bp.route('/admin/cabinet-groups/save', methods=['POST'])
def cabinet_groups_save():
    try:
        data = request.get_json() or {}
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        if data.get('id'):
            c.execute("UPDATE cabinet_groups SET group_code=?, name=?, location_id=? WHERE id=?",
                      (data.get('group_code',''), data.get('name',''), data.get('location_id'), data['id']))
        else:
            c.execute("INSERT INTO cabinet_groups (location_id, group_code, name, status, created_at) VALUES (?, ?, ?, 1, datetime('now','localtime'))",
                      (data.get('location_id'), data.get('group_code',''), data.get('name','')))
        conn.commit()
        conn.close()
        return jsonify({'code': 200, 'message': '保存成功'})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

@bp.route('/admin/cabinet-groups/delete', methods=['POST'])
def cabinet_groups_delete():
    try:
        data = request.get_json() or {}
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("DELETE FROM cabinet_groups WHERE id=?", (data['id'],))
        conn.commit()
        conn.close()
        return jsonify({'code': 200, 'message': '删除成功'})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

@bp.route('/admin/cabinet-groups/cabinets', methods=['GET', 'POST'])
def cabinet_groups_cabinets():
    try:
        group_id = request.args.get('group_id')
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        rows = c.execute("SELECT * FROM cabinets WHERE group_id=?", (group_id,)).fetchall()
        conn.close()
        return jsonify({'code': 200, 'data': [dict(r) for r in rows]})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

@bp.route('/admin/cabinet-groups/by-code', methods=['GET', 'POST'])
def cabinet_groups_by_code():
    try:
        code = request.args.get('code')
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        row = c.execute("SELECT * FROM cabinet_groups WHERE group_code=?", (code,)).fetchone()
        if not row:
            return jsonify({'code': 404, 'message': '柜组不存在'})
        g = dict(row)
        cabinets = c.execute("SELECT * FROM cabinets WHERE group_id=?", (g['id'],)).fetchall()
        g['cabinets'] = [dict(c2) for c2 in cabinets]
        conn.close()
        return jsonify({'code': 200, 'data': g})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

# ==================== P1: 代理商/员工登录 ====================

@bp.route('/admin/agent/login', methods=['POST'])
def agent_login():
    try:
        data = request.get_json() or {}
        phone = data.get('phone', '')
        password = data.get('password', '')
        if not phone or not password:
            return jsonify({'code': 400, 'message': '请输入手机号和密码'})
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        row = c.execute("SELECT * FROM agents WHERE contact_phone=? AND status=1", (phone,)).fetchone()
        if not row:
            conn.close()
            return jsonify({'code': 401, 'message': '账号不存在或已停用'})
        if not check_password_hash(row['password_hash'], password):
            conn.close()
            return jsonify({'code': 401, 'message': '密码错误'})
        import secrets
        token = secrets.token_hex(16)
        c.execute("UPDATE agents SET auth_token=? WHERE id=?", (token, row['id']))
        conn.commit()
        result = dict(row)
        result.pop('password_hash', None)
        conn.close()
        session['agent_id'] = row['id']
        session['agent_name'] = row['name']
        session['is_agent'] = True
        all_perms = ["dashboard","locations","devices","orders","statistics","withdrawal","alerts","merchant_manage","full_data"]
        return jsonify({'code': 200, 'data': {'token': token, 'role': 'agent', 'agent_id': row['id'], 'name': row['name'], 'commission_rate': result.get('commission_rate', 0)}})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})


@bp.route('/admin/merchant/login', methods=['POST'])
def merchant_login():
    try:
        data = request.get_json() or {}
        phone = data.get('phone', '')
        password = data.get('password', '')
        if not phone or not password:
            return jsonify({'code': 400, 'message': '请输入手机号和密码'})
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        row = c.execute("SELECT * FROM merchants WHERE contact_phone=? AND status=1", (phone,)).fetchone()
        if not row:
            conn.close()
            return jsonify({'code': 401, 'message': '账号不存在或已停用'})
        if not check_password_hash(row['password_hash'], password):
            conn.close()
            return jsonify({'code': 401, 'message': '密码错误'})
        import secrets
        token = secrets.token_hex(16)
        c.execute("UPDATE merchants SET auth_token=? WHERE id=?", (token, row['id']))
        conn.commit()
        result = dict(row)
        result.pop('password_hash', None)
        conn.close()
        return jsonify({'code': 200, 'data': {'token': token, 'role': 'merchant', 'merchant_id': row['id'], 'name': row['name'], 'agent_id': result.get('agent_id'), 'permissions': result.get("permissions", "[]")}})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})


@bp.route('/admin/employee/login', methods=['POST'])
def employee_login():
    try:
        data = request.get_json() or {}
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        row = c.execute("SELECT * FROM employees WHERE phone=? AND status=1", (data.get('phone',''),)).fetchone()
        if not row:
            return jsonify({'code': 401, 'message': '账号不存在或已停用'})
        if data.get('password') != row.get('password',''):
            return jsonify({'code': 401, 'message': '密码错误'})
        import secrets
        token = secrets.token_hex(16)
        c.execute("UPDATE employees SET auth_token=? WHERE id=?", (token, row['id']))
        conn.commit()
        conn.close()
        return jsonify({'code': 200, 'data': {'token': token, 'employee_id': row['id'], 'name': row['name'], 'permissions': row['permissions'] if 'permissions' in row.keys() else '[]'}})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})


# ==================== P1: 批量自动提现 ====================

@bp.route('/admin/withdrawal/batch-auto', methods=['POST'])
def withdrawal_batch_auto():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        # 查找符合自动审批条件的待审核提现
        rows = c.execute("""
            SELECT w.* FROM withdrawal_records w
            JOIN locations l ON w.order_id IN (SELECT id FROM orders WHERE cabinet_id IN (SELECT id FROM cabinets WHERE location_id=l.id))
            WHERE w.status=0 AND l.auto_approve_rate>=80
        """).fetchall()
        approved = 0
        for r in rows:
            c.execute("UPDATE withdrawal_records SET status=1, approve_time=datetime('now','localtime'), approver='系统自动' WHERE id=?", (r['id'],))
            approved += 1
        conn.commit()
        conn.close()
        return jsonify({'code': 200, 'message': f'自动审批{approved}条提现', 'data': {'approved': approved}})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})


# ==================== P1: 离线订单管理 ====================

@bp.route('/admin/offline-orders', methods=['GET', 'POST'])
def offline_orders_list():
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        keyword = request.args.get('keyword', '')
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        where = "WHERE 1=1"
        params = []
        if keyword:
            where += " AND (order_no LIKE ? OR user_phone LIKE ?)"
            params += [f'%{keyword}%', f'%{keyword}%']
        total = c.execute(f"SELECT COUNT(*) FROM orders {where} AND status=6", params).fetchone()[0]
        rows = c.execute(f"SELECT * FROM orders {where} AND status=6 ORDER BY id DESC LIMIT ? OFFSET ?", params + [limit, (page-1)*limit]).fetchall()
        conn.close()
        return jsonify({'code': 200, 'data': {'list': [dict(r) for r in rows], 'total': total}})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})


# ==================== P1: 远程开门日志 ====================

@bp.route('/admin/remote-open-logs', methods=['GET', 'POST'])
def remote_open_logs_list():
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        total = c.execute("SELECT COUNT(*) FROM remote_open_logs").fetchone()[0]
        rows = c.execute("SELECT * FROM remote_open_logs ORDER BY id DESC LIMIT ? OFFSET ?", (limit, (page-1)*limit)).fetchall()
        conn.close()
        return jsonify({'code': 200, 'data': {'list': [dict(r) for r in rows], 'total': total}})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})


# ==================== P1: 设备日志查看 ====================

@bp.route('/admin/device-logs', methods=['GET', 'POST'])
def device_logs_list():
    try:
        cabinet_id = request.args.get('cabinet_id', '')
        device_id = request.args.get('device_id', '')
        log_type = request.args.get('log_type', '')
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))
        
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        where = " WHERE d.create_time >= datetime('now', '-3 days')"
        params = []
        
        if cabinet_id:
            where += " AND d.cabinet_id=?"
            params.append(cabinet_id)
        if device_id:
            where += " AND d.device_id LIKE ?"
            params.append('%' + device_id + '%')
        if log_type:
            where += " AND d.log_type=?"
            params.append(log_type)
        
        sql = "SELECT d.id, d.device_id, d.log_type, d.content, d.create_time, cab.id as cabinet_id, cab.cabinet_code, COALESCE(loc.name, '') as location_name FROM device_logs d LEFT JOIN cabinets cab ON d.device_id = cab.mainboard_device_id OR d.device_id = CAST(cab.id AS TEXT) LEFT JOIN locations loc ON cab.location_id = loc.id" + where + " ORDER BY d.id DESC LIMIT ? OFFSET ?"
        
        total_sql = "SELECT COUNT(*) FROM device_logs d LEFT JOIN cabinets cab ON d.device_id = cab.mainboard_device_id OR d.device_id = CAST(cab.id AS TEXT) " + where
        total = c.execute(total_sql, params).fetchone()[0]
        rows = c.execute(sql, params + [limit, (page-1)*limit]).fetchall()
        
        logs = []
        for r in rows:
            logs.append({'id': r[0], 'device_id': r[1], 'log_type': r[2], 'content': r[3], 'created_at': r[4], 'cabinet_id': r[5], 'cabinet_code': r[6] or '', 'location_name': r[7] or ''})
        
        conn.close()
        return jsonify({'code': 200, 'data': {'list': logs, 'total': total}})
    except Exception as e:
        logger.error('[device_logs] ' + str(e))
        return jsonify({'code': 500, 'message': str(e)})


# ==================== P1: 开门记录 ====================

# ==================== P1: 开门记录 ====================

@bp.route('/admin/door-records', methods=['GET', 'POST'])
def door_records_list():
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        cabinet_id = request.args.get('cabinet_id', '')
        order_id = request.args.get('order_id', '')
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        where = "WHERE 1=1"
        params = []
        if cabinet_id:
            where += " AND cabinet_id=?"
            params.append(cabinet_id)
        if order_id:
            # order_id可能是数字id，先查order_no
            try:
                oid = int(order_id)
                row = c.execute('SELECT order_no FROM orders WHERE id=?', (oid,)).fetchone()
                if row:
                    where += " AND order_id=?"
                    params.append(str(row['order_no']))
                else:
                    where += " AND order_id=?"
                    params.append(str(order_id))
            except ValueError:
                where += " AND order_id=?"
                params.append(str(order_id))
        total = c.execute(f"SELECT COUNT(*) FROM door_records {where}", params).fetchone()[0]
        rows = c.execute(f"SELECT * FROM door_records {where} ORDER BY id DESC LIMIT ? OFFSET ?", params + [limit, (page-1)*limit]).fetchall()
        conn.close()
        return jsonify({'code': 200, 'data': {'list': [dict(r) for r in rows], 'total': total}})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})



# ==================== 告警管理 ====================

@bp.route('/admin/alerts', methods=['GET', 'POST'])
def alerts_list():
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 20))
        alert_type = request.args.get('alert_type', '')
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        # Ensure table exists
        c.execute("""CREATE TABLE IF NOT EXISTS device_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id TEXT,
            alert_type TEXT,
            detail TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        where = "WHERE 1=1"
        params = []
        if alert_type:
            where += " AND alert_type=?"
            params.append(alert_type)
        total = c.execute(f"SELECT COUNT(*) FROM device_alerts {where}", params).fetchone()[0]
        rows = c.execute(f"SELECT * FROM device_alerts {where} ORDER BY id DESC LIMIT ? OFFSET ?", params + [limit, (page-1)*limit]).fetchall()
        conn.close()
        return jsonify({'code': 200, 'data': {'list': [dict(r) for r in rows], 'total': total}})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})

# ==================== P1: 待执行命令监控 ====================

@bp.route('/admin/pending-cmds', methods=['GET', 'POST'])
def pending_cmds_list():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        rows = c.execute("SELECT * FROM pending_lock_cmds ORDER BY id DESC LIMIT 100").fetchall()
        conn.close()
        return jsonify({'code': 200, 'data': {'list': [dict(r) for r in rows], 'total': len(rows)}})
    except Exception as e:
        return jsonify({'code': 500, 'message': str(e)})


@bp.route('/admin/cancel-cmd', methods=['POST'])
def admin_cancel_cmd():
    data = request.get_json() or {}
    cmd_id = data.get('id')
    if not cmd_id:
        return jsonify({'code': 1, 'message': '缺少命令ID'})
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    try:
        db.execute('UPDATE pending_lock_cmds SET delivered=2 WHERE id=? AND delivered=0', (cmd_id,))
        db.commit()
        return jsonify({'code': 0, 'message': '命令已取消'})
    except Exception as e:
        return jsonify({'code': 1, 'message': str(e)})
    finally:
        db.close()

# ==================== 柜组管理 ====================

@bp.route('/admin/cabinet-groups', methods=['GET', 'POST'])
@require_auth
def admin_cabinet_groups():
    try:
        location_id = request.args.get('location_id', '')
        page = int(request.args.get('page', 1))
        page_size = int(request.args.get('limit', 20))
        conn = get_db()
        c = conn.cursor()
        where, params = '1=1', []
        if location_id:
            where += ' AND cg.location_id=?'
            params.append(location_id)
        c.execute(f'SELECT COUNT(*) FROM cabinet_groups cg WHERE {where}', params)
        total = c.fetchone()[0]
        c.execute(f'''SELECT cg.*, l.name as location_name,
            (SELECT COUNT(*) FROM cabinets WHERE group_id=cg.id) as cabinet_count,
            COALESCE((SELECT SUM(CASE WHEN cs.status=1 THEN 1 ELSE 0 END) FROM cabinet_slots cs JOIN cabinets cab ON cs.cabinet_id=cab.id WHERE cab.group_id=cg.id),0) as available_slots,
            COALESCE((SELECT SUM(CASE WHEN cs.status=2 THEN 1 ELSE 0 END) FROM cabinet_slots cs JOIN cabinets cab ON cs.cabinet_id=cab.id WHERE cab.group_id=cg.id),0) as occupied_slots
            FROM cabinet_groups cg LEFT JOIN locations l ON cg.location_id=l.id
            WHERE {where} ORDER BY cg.created_at DESC LIMIT ? OFFSET ?''',
                  params + [page_size, (page-1)*page_size])
        groups = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data={'list': groups, 'total': total})
    except Exception as e:
        logger.error(f'[cabinet_groups] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/cabinet-group/save', methods=['POST'])
@require_auth
def admin_cabinet_group_save():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        if data.get('id'):
            sets, params = [], []
            for f in ['name', 'screen_url', 'status', 'location_id']:
                if f in data:
                    sets.append(f'{f}=?')
                    params.append(data[f])
            params.append(data['id'])
            c.execute(f'UPDATE cabinet_groups SET {",".join(sets)} WHERE id=?', params)
        else:
            group_code = data.get('group_code', '')
            if not group_code:
                import time
                group_code = 'G' + str(int(time.time() * 100))[-6:]
            c.execute('SELECT id FROM cabinet_groups WHERE group_code=?', (group_code,))
            if c.fetchone():
                conn.close()
                return json_response(message='柜组编号已存在', code=400)
            c.execute('INSERT INTO cabinet_groups (location_id, group_code, name, screen_url) VALUES (?,?,?,?)',
                      (data.get('location_id'), group_code, data.get('name', group_code), data.get('screen_url', '')))
        conn.commit()
        conn.close()
        return json_response(message='保存成功')
    except Exception as e:
        logger.error(f'[cabinet_group_save] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/cabinet-group/delete', methods=['POST'])
@require_auth
def admin_cabinet_group_delete():
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT COUNT(*) FROM cabinets WHERE group_id=?', (data.get('id'),))
        if c.fetchone()[0] > 0:
            conn.close()
            return json_response(message='该柜组下存在柜体，请先删除柜体', code=400)
        c.execute('DELETE FROM cabinet_groups WHERE id=?', (data.get('id'),))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[cabinet_group_delete] {e}')
        return json_response(message=str(e), code=500)


# ==================== 设备详情 ====================

@bp.route('/admin/device/detail', methods=['GET', 'POST'])
@require_auth
def admin_device_detail():
    try:
        _d=request.get_json(silent=True) or {}; device_id = _d.get('id') or request.args.get('id', '')
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM cabinets WHERE id=?', (device_id,))
        cabinet = c.fetchone()
        if not cabinet:
            conn.close()
            return json_response(message='设备不存在', code=404)
        result = dict(cabinet)
        c.execute('SELECT * FROM cabinet_slots WHERE cabinet_id=? ORDER BY slot_number', (device_id,))
        result['slots'] = [dict(r) for r in c.fetchall()]
        c.execute('''SELECT o.*, cs.slot_number as compartment_number, ub.wechat_name FROM orders o
            LEFT JOIN cabinet_slots cs ON o.slot_id=cs.id
            WHERE o.cabinet_id=? AND o.status=2 ORDER BY o.store_time DESC''', (device_id,))
        result['active_orders'] = [dict(r) for r in c.fetchall()]
        conn.close()
        return json_response(data=result)
    except Exception as e:
        logger.error(f'[device_detail] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/device/slot-open', methods=['POST'])
@require_auth
def admin_device_slot_open():
    try:
        data = request.get_json()
        slot_id = data.get('slot_id')
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT cs.*, c.mainboard_device_id, c.id as cabinet_id FROM cabinet_slots cs JOIN cabinets c ON cs.cabinet_id=c.id WHERE cs.id=?', (slot_id,))
        slot = c.fetchone()
        if not slot:
            conn.close()
            return json_response(message='柜格不存在', code=404)
        device_id = slot['mainboard_device_id']
        board_no = slot['board_no'] if 'board_no' in slot.keys() else 1
        lock_no = slot['lock_no'] if 'lock_no' in slot.keys() and slot['lock_no'] else (slot['slot_number'] if 'slot_number' in slot.keys() else 0)
        protocol = slot['protocol'] if 'protocol' in slot.keys() else 'YBM'
        c.execute("INSERT INTO remote_open_logs (device_id, slot_id, action_type, operator, success, created_at) VALUES (?,?,?,?,?,CURRENT_TIMESTAMP)",
                  (device_id, slot_id, 'admin_open', 'admin', 1))
        conn.commit()
        conn.close()
        from helpers import send_open_lock
        send_open_lock(device_id, board_no, lock_no, protocol)
        logger.info(f'[slot_open] sent via send_open_lock: device={device_id}, board={board_no}, lock={lock_no}')
        return json_response(message='开门指令已发送')
    except Exception as e:
        logger.error(f'[slot_open] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/device/batch-open', methods=['POST'])
@require_auth
def admin_device_batch_open():
    try:
        data = request.get_json()
        cabinet_id = data.get('cabinet_id')
        slot_ids = data.get('slot_ids', [])
        if not cabinet_id:
            return json_response(message='缺少设备ID', code=400)
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM cabinets WHERE id=?', (cabinet_id,))
        cabinet = c.fetchone()
        if not cabinet:
            conn.close()
            return json_response(message='设备不存在', code=404)
        import json as _json
        opened = 0
        if slot_ids:
            for sid in slot_ids:
                c.execute('SELECT * FROM cabinet_slots WHERE id=? AND cabinet_id=?', (sid, cabinet_id))
                slot = c.fetchone()
                if slot:
                    cmd = _json.dumps({'type': 'open_lock', 'device_id': cabinet['mainboard_device_id'], 'slot_number': slot['slot_number']})
                    c.execute('INSERT INTO pending_lock_cmds (cabinet_id, slot_id, command, status) VALUES (?,?,?,?)',
                              (cabinet_id, sid, cmd, 'pending'))
                    c.execute("INSERT INTO remote_open_logs (device_id, slot_id, action_type, operator, success, created_at) VALUES (?,?,?,?,?,CURRENT_TIMESTAMP)",
                              (cabinet['mainboard_device_id'], sid, 'admin_batch_open', 'admin', 1))
                    opened += 1
        else:
            c.execute('SELECT * FROM cabinet_slots WHERE cabinet_id=?', (cabinet_id,))
            for slot in c.fetchall():
                cmd = _json.dumps({'type': 'open_lock', 'device_id': cabinet['mainboard_device_id'], 'slot_number': slot['slot_number']})
                c.execute('INSERT INTO pending_lock_cmds (cabinet_id, slot_id, command, status) VALUES (?,?,?,?)',
                          (cabinet_id, slot['id'], cmd, 'pending'))
                opened += 1
        conn.commit()
        conn.close()
        return json_response(message=f'已发送{opened}个开门指令')
    except Exception as e:
        logger.error(f'[batch_open] {e}')
        return json_response(message=str(e), code=500)


# ==================== 网点二维码 ====================


@bp.route('/admin/device/qrcode', methods=['GET','POST'])
@require_auth
def admin_device_qrcode():
    try:
        _jd=request.get_json(silent=True) or {}; device_id = _jd.get('id') or request.args.get('id', '')
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM cabinets WHERE id=?', (device_id,))
        cabinet = c.fetchone()
        if not cabinet:
            conn.close()
            return json_response(message='设备不存在', code=404)
        result = dict(cabinet)
        # Build QR URL for this device
        group_id = cabinet['group_id'] if 'group_id' in cabinet.keys() else None
        group_code = ''
        if group_id:
            c.execute('SELECT group_code FROM cabinet_groups WHERE id=?', (group_id,))
            g = c.fetchone()
            if g:
                group_code = g['group_code']
        qr_url = 'https://locker.cqdyxl.com/store?group_code=' + group_code + '&cabinet_id=' + str(device_id) if group_code else 'https://locker.cqdyxl.com/store?cabinet_id=' + str(device_id)
        result['qr_url'] = qr_url
        conn.close()
        # Generate QR code image as base64
        try:
            import qrcode
            from io import BytesIO
            import base64
            qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=10, border=2)
            qr.add_data(qr_url)
            qr.make(fit=True)
            img = qr.make_image(fill_color='black', back_color='white')
            buf = BytesIO()
            img.save(buf, format='PNG')
            result['qrcode_img'] = 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode('utf-8')
        except Exception as qe:
            logger.error(f'[device_qrcode] generate image failed: {qe}')
            result['qrcode_img'] = None
        return json_response(data=result)
    except Exception as e:
        logger.error(f'[device_qrcode] {e}')
        return json_response(message=str(e), code=500)

@bp.route('/admin/location/qrcode', methods=['GET','POST'])
@require_auth
def admin_location_qrcode():
    try:
        _jd2=request.get_json(silent=True) or {}; location_id = _jd2.get('location_id') or request.args.get('location_id', '')
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM locations WHERE id=?', (location_id,))
        location = c.fetchone()
        if not location:
            conn.close()
            return json_response(message='网点不存在', code=404)
        c.execute('SELECT cg.*, (SELECT COUNT(*) FROM cabinets WHERE group_id=cg.id) as cabinet_count FROM cabinet_groups cg WHERE cg.location_id=? ORDER BY cg.created_at', (location_id,))
        groups = [dict(r) for r in c.fetchall()]
        base_url = 'http://locker.cqdyxl.com/store'
        for g in groups:
            g['qr_url'] = base_url + g['group_code']
        conn.close()
        return json_response(data={'location': dict(location), 'groups': groups})
    except Exception as e:
        logger.error(f'[location_qrcode] {e}')
        return json_response(message=str(e), code=500)




@bp.route('/admin/slot/add', methods=['POST'])
@require_auth
def admin_slot_add():
    """批量添加柜门：根据主板号+柜门数自动生成连续柜门号"""
    try:
        data = request.get_json()
        cabinet_id = data.get('cabinet_id')
        slot_size = data.get('slot_size', 'medium')
        board_no = data.get('board_no', 1)
        slot_count = int(data.get('slot_count', 1))
        if not cabinet_id:
            return json_response(message='缺少设备ID', code=400)
        if not slot_count or slot_count < 1:
            return json_response(message='柜门数至少为1', code=400)
        conn = get_db()
        cur = conn.cursor()
        # 查当前该cabinet已有最大slot_number
        cur.execute('SELECT MAX(slot_number) as max_num FROM cabinet_slots WHERE cabinet_id=?', (cabinet_id,))
        row = cur.fetchone()
        max_num = row['max_num'] if row and row['max_num'] else 0
        # 从max_num+1开始连续生成slot_count个柜门
        added = 0
        for i in range(slot_count):
            slot_number = max_num + 1 + i
            lock_no = i + 1  # lock_no从1开始，对应主板上的物理锁号
            cur.execute('SELECT id FROM cabinet_slots WHERE cabinet_id=? AND slot_number=?', (cabinet_id, slot_number))
            if cur.fetchone():
                continue  # 跳过已存在的
            cur.execute('INSERT INTO cabinet_slots(cabinet_id,slot_number,slot_size,board_no,lock_no,status) VALUES(?,?,?,?,?,1)',
                        (cabinet_id, slot_number, slot_size, board_no, lock_no))
            added += 1
        conn.commit()
        conn.close()
        return json_response(data={'added': added}, message=f'成功添加{added}个柜门(编号{max_num+1}-{max_num+slot_count})')
    except Exception as e:
        return json_response(message=str(e), code=500)

@bp.route('/admin/slot/delete', methods=['POST'])
@require_auth
def admin_slot_delete():
    try:
        data=request.get_json(); slot_id=data.get('id')
        if not slot_id: return json_response(message='缺少柜门ID',code=400)
        conn=get_db(); cur=conn.cursor()
        cur.execute('DELETE FROM cabinet_slots WHERE id=?',(slot_id,))
        conn.commit(); conn.close()
        return json_response(message='删除成功')
    except Exception as e: return json_response(message=str(e),code=500)



@bp.route('/admin/order/open-door', methods=['POST'])
@require_auth
def admin_order_open_door():
    """已结束订单开门：根据订单找到对应slot，调用开门逻辑"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if not order_id:
            return json_response(message='缺少订单ID', code=400)
        conn = get_db()
        c = conn.cursor()
        # 查订单获取slot_id
        c.execute('SELECT slot_id, cabinet_id FROM orders WHERE id=?', (order_id,))
        order = c.fetchone()
        if not order:
            conn.close()
            return json_response(message='订单不存在', code=404)
        slot_id = order['slot_id']
        cabinet_id = order['cabinet_id']
        if not slot_id:
            conn.close()
            return json_response(message='订单无关联柜门', code=400)
        # 查slot信息
        c.execute('SELECT * FROM cabinet_slots WHERE id=?', (slot_id,))
        slot = c.fetchone()
        if not slot:
            conn.close()
            return json_response(message='柜门不存在', code=404)
        # 查设备信息
        c.execute('SELECT mainboard_device_id FROM cabinets WHERE id=?', (cabinet_id,))
        cabinet = c.fetchone()
        if not cabinet or not cabinet['mainboard_device_id']:
            conn.close()
            return json_response(message='设备未配置', code=400)
        device_id = cabinet['mainboard_device_id']
        board_no = slot['board_no']
        lock_no = slot['lock_no']
        conn.close()
        # 调用开门逻辑
        from helpers import send_open_lock
        result = send_open_lock(device_id, board_no, lock_no)
        if result:
            return json_response(message='开门指令已发送', data={'success': True})
        else:
            return json_response(message='开门指令发送失败，设备可能离线', code=500)
    except Exception as e:
        return json_response(message=str(e), code=500)
@bp.route('/admin/slots/batch-delete', methods=['POST'])
@require_auth
def admin_slots_batch_delete():
    try:
        data = request.get_json()
        ids = data.get('ids', [])
        if not ids or not isinstance(ids, list):
            return json_response(message='请选择要删除的柜门', code=400)
        conn = get_db()
        c = conn.cursor()
        placeholders = ','.join(['?'] * len(ids))
        # 先把关联订单的slot_id置空，避免外键约束
        c.execute(f'UPDATE orders SET slot_id=NULL WHERE slot_id IN ({placeholders})', ids)
        c.execute(f'DELETE FROM cabinet_slots WHERE id IN ({placeholders})', ids)
        deleted = c.rowcount
        conn.commit()
        conn.close()
        return json_response(data={'deleted': deleted}, message=f'成功删除{deleted}个柜门')
    except Exception as e:
        return json_response(message=str(e), code=500)

# ==================== 补充V1缺失功能 ====================

@bp.route('/admin/device/clear-all', methods=['POST'])
@require_auth
def admin_device_clear_all():
    """清柜: 结束所有活跃订单+开所有门"""
    try:
        data = request.get_json()
        cabinet_id = data.get('cabinet_id')
        if not cabinet_id:
            return json_response(message='缺少设备ID', code=400)
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM cabinets WHERE id=?', (cabinet_id,))
        cabinet = c.fetchone()
        if not cabinet:
            conn.close()
            return json_response(message='设备不存在', code=404)
        import json as _json
        from datetime import datetime
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        # End all active orders
        c.execute('SELECT id, slot_id FROM orders WHERE cabinet_id=? AND status=2', (cabinet_id,))
        active = c.fetchall()
        ended = 0
        for o in active:
            c.execute('UPDATE orders SET status=4, pickup_time=?, updated_at=? WHERE id=?', (now, now, o['id']))
            c.execute('UPDATE cabinet_slots SET status=1 WHERE id=?', (o['slot_id'],))
            ended += 1
        # Open all slots
        c.execute('SELECT * FROM cabinet_slots WHERE cabinet_id=?', (cabinet_id,))
        slots = c.fetchall()
        opened = 0
        for s in slots:
            cmd = _json.dumps({'type': 'open_lock', 'device_id': cabinet['mainboard_device_id'], 'slot_number': s['slot_number'], 'slot_label': s['slot_label'] if 'slot_label' in s.keys() else ''})
            c.execute('INSERT INTO pending_lock_cmds (cabinet_id, slot_id, command, status) VALUES (?,?,?,?)',
                      (cabinet_id, s['id'], cmd, 'pending'))
            opened += 1
        conn.commit()
        conn.close()
        return json_response(message=f'已结束{ended}个订单，发送{opened}个开门指令')
    except Exception as e:
        logger.error(f'[clear_all] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/slot/update-status', methods=['POST'])
@require_auth
def admin_slot_update_status():
    """手动更新格口状态"""
    try:
        data = request.get_json()
        slot_id = data.get('slot_id')
        status = data.get('status')  # 1=空闲 2=占用 3=故障
        if not slot_id or status not in [1, 2, 3]:
            return json_response(message='参数错误', code=400)
        conn = get_db()
        c = conn.cursor()
        c.execute('UPDATE cabinet_slots SET status=? WHERE id=?', (status, slot_id))
        if c.rowcount == 0:
            conn.close()
            return json_response(message='格口不存在', code=404)
        conn.commit()
        conn.close()
        return json_response(message='状态已更新')
    except Exception as e:
        logger.error(f'[slot_update_status] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/logout', methods=['POST'])
@require_auth
def admin_logout():
    """管理员登出"""
    return json_response(message='已登出')


@bp.route("/admin/transactions", methods=["GET"])
@require_auth
def admin_transactions():
    """结算流水列表"""
    try:
        db = get_db()
        page = int(request.args.get("page", 1))
        per_page = int(request.args.get("per_page", 20))
        offset = (page - 1) * per_page
        
        where = "1=1"
        params = []
        cabinet_id = request.args.get("cabinet_id")
        if cabinet_id:
            where += " AND o.cabinet_id = ?"
            params.append(cabinet_id)
        status = request.args.get("status")
        if status:
            where += " AND o.status = ?"
            params.append(status)
        start_date = request.args.get("start_date")
        if start_date:
            where += " AND o.created_at >= ?"
            params.append(start_date)
        end_date = request.args.get("end_date")
        if end_date:
            where += " AND o.created_at <= ?"
            params.append(end_date + " 23:59:59")
        
        total = db.execute(f"SELECT COUNT(*) FROM orders o WHERE {where}", params).fetchone()[0]
        rows = db.execute(
            f"SELECT o.id, o.order_no, o.cabinet_id, o.slot_id, o.compartment_number, "
            f"o.deposit_amount, o.status, o.access_code, o.created_at, o.retrieve_time, "
            f"c.cabinet_code "
            f"FROM orders o LEFT JOIN cabinets c ON o.cabinet_id = c.id "
            f"WHERE {where} ORDER BY o.created_at DESC LIMIT ? OFFSET ?",
            params + [per_page, offset]
        ).fetchall()
        
        items = []
        for r in rows:
            items.append({
                "id": r["id"], "order_no": r["order_no"],
                "cabinet_id": r["cabinet_id"], "cabinet_code": r["cabinet_code"],
                "slot_id": r["slot_id"], "compartment_number": r["compartment_number"],
                "deposit_amount": r["deposit_amount"], "status": r["status"],
                "retrieve_code": r["access_code"], "created_at": r["created_at"],
                "retrieve_time": r["retrieve_time"]
            })
        
        return json_response(data={
            "items": items, "total": total,
            "page": page, "per_page": per_page,
            "total_pages": (total + per_page - 1) // per_page
        })
    except Exception as e:
        logger.error(f"[transactions] {e}")
        return json_response(message=str(e), code=500)


@bp.route("/admin/device/status", methods=["GET"])
@require_auth
def admin_device_status():
    """设备在线状态"""
    try:
        db = get_db()
        devices = db.execute(
            "SELECT c.mainboard_device_id as device_id, c.cabinet_code as device_name, c.id as cabinet_id, c.last_heartbeat, "
            "c.cabinet_code "
            "FROM cabinets c WHERE c.mainboard_device_id IS NOT NULL "
            "ORDER BY c.last_heartbeat DESC"
        ).fetchall()
        
        items = []
        for d in devices:
            is_online = False
            if d["last_heartbeat"]:
                from datetime import datetime, timedelta
                try:
                    last = datetime.strptime(str(d["last_heartbeat"]), "%Y-%m-%d %H:%M:%S")
                    is_online = (datetime.now() - last) < timedelta(minutes=3)
                except:
                    pass
            items.append({
                "device_id": d["device_id"], "device_name": d["device_name"],
                "cabinet_id": d["cabinet_id"], "cabinet_code": d["cabinet_code"],
                "is_online": is_online
            })
        
        online_count = sum(1 for i in items if i["is_online"])
        return json_response(data={
            "devices": items,
            "total": len(items),
            "online": online_count,
            "offline": len(items) - online_count
        })
    except Exception as e:
        logger.error(f"[device_status] {e}")
        return json_response(message=str(e), code=500)

# ========== 主板管理 API ==========

@bp.route('/admin/mainboards', methods=['GET', 'POST'])
@require_auth
def admin_mainboards_list():
    """获取指定柜体的主板列表"""
    try:
        cabinet_id = request.args.get('cabinet_id')
        if not cabinet_id:
            return json_response(message='缺少cabinet_id', code=400)
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM mainboards WHERE cabinet_id=? ORDER BY board_index', (cabinet_id,))
        rows = c.fetchall()
        result = []
        for r in rows:
            result.append({
                'id': r['id'],
                'cabinet_id': r['cabinet_id'],
                'board_index': r['board_index'],
                'slot_count': r['slot_count'],
                'name': r['name'],
                'serial_port': r['serial_port'],
                'baud_rate': r['baud_rate'],
                'protocol': r['protocol'] or 'YBM'
            })
        conn.close()
        return json_response(data=result)
    except Exception as e:
        logger.error(f'[mainboards_list] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/mainboards/save', methods=['POST'])
@require_auth
def admin_mainboards_save():
    """新增或编辑主板"""
    try:
        data = request.get_json()
        mid = data.get('id')
        cabinet_id = data.get('cabinet_id')
        board_index = data.get('board_index')
        slot_count = data.get('slot_count', 24)
        name = data.get('name', '')
        serial_port = data.get('serial_port', 'ttyS4')
        baud_rate = data.get('baud_rate', 9600)
        protocol = data.get('protocol', 'YBM')
        
        if protocol not in ('YBM', 'WT'):
            return json_response(message='协议仅支持YBM和WT', code=400)
        if not cabinet_id or board_index is None:
            return json_response(message='缺少必要参数', code=400)
        
        conn = get_db()
        c = conn.cursor()
        
        if mid:
            # 更新
            c.execute('UPDATE mainboards SET board_index=?, slot_count=?, name=?, serial_port=?, baud_rate=?, protocol=? WHERE id=?',
                      (board_index, slot_count, name, serial_port, baud_rate, protocol, mid))
            # 同步更新该主板下slot的board_no
            c.execute('UPDATE cabinet_slots SET board_no=? WHERE mainboard_id=?', (board_index, mid))
            conn.commit()
            conn.close()
            return json_response(message='更新成功')
        else:
            # 新增
            c.execute('INSERT INTO mainboards (cabinet_id, board_index, slot_count, name, serial_port, baud_rate, protocol) VALUES (?,?,?,?,?,?,?)',
                      (cabinet_id, board_index, slot_count, name, serial_port, baud_rate, protocol))
            new_id = c.lastrowid
            conn.commit()
            conn.close()
            return json_response(data={'id': new_id}, message='新增成功')
    except Exception as e:
        logger.error(f'[mainboards_save] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/mainboards/delete', methods=['POST'])
@require_auth
def admin_mainboards_delete():
    """删除主板（需先移走或删除关联slot）"""
    try:
        data = request.get_json()
        mid = data.get('id')
        if not mid:
            return json_response(message='缺少id', code=400)
        conn = get_db()
        c = conn.cursor()
        # 检查是否有slot关联
        c.execute('SELECT COUNT(*) as cnt FROM cabinet_slots WHERE mainboard_id=?', (mid,))
        cnt = c.fetchone()['cnt']
        if cnt > 0:
            conn.close()
            return json_response(message=f'该主板下还有{cnt}个柜格，请先移除', code=400)
        c.execute('DELETE FROM mainboards WHERE id=?', (mid,))
        conn.commit()
        conn.close()
        return json_response(message='删除成功')
    except Exception as e:
        logger.error(f'[mainboards_delete] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/admin/mainboards/generate-slots', methods=['POST'])
@require_auth
def admin_mainboards_generate_slots():
    """根据主板配置自动生成slot（先清空该柜体旧slot再重建）"""
    try:
        data = request.get_json()
        cabinet_id = data.get('cabinet_id')
        if not cabinet_id:
            return json_response(message='缺少cabinet_id', code=400)
        
        conn = get_db()
        c = conn.cursor()
        
        # 获取该柜体所有主板
        c.execute('SELECT * FROM mainboards WHERE cabinet_id=? ORDER BY board_index', (cabinet_id,))
        boards = c.fetchall()
        if not boards:
            conn.close()
            return json_response(message='该柜体没有主板配置', code=400)
        
        # 检查是否有在用订单
        c.execute('SELECT COUNT(*) as cnt FROM orders WHERE cabinet_id=? AND status=1', (cabinet_id,))
        active_orders = c.fetchone()['cnt']
        if active_orders > 0:
            conn.close()
            return json_response(message=f'该柜体有{active_orders}个在用订单，请先处理', code=400)
        
        # 清空旧slot
        c.execute('DELETE FROM cabinet_slots WHERE cabinet_id=?', (cabinet_id,))
        
        # 按主板生成slot
        slot_number = 1
        for board in boards:
            for lock_no in range(1, board['slot_count'] + 1):
                c.execute(
                    'INSERT INTO cabinet_slots (cabinet_id, slot_number, board_no, lock_no, mainboard_id, status) VALUES (?,?,?,?,?,1)',
                    (cabinet_id, slot_number, board['board_index'], lock_no, board['id'])
                )
                slot_number += 1
        
        conn.commit()
        conn.close()
        return json_response(message=f'已生成{slot_number - 1}个柜格')
    except Exception as e:
        logger.error(f'[mainboards_generate_slots] {e}')
        return json_response(message=str(e), code=500)

# ============ 微信投诉通知API (骨架) ============
# 注意：此API需要用户在微信支付后台配置投诉通知URL才能实际接收投诉
# 微信支付投诉通知URL格式: https://your-domain.com/api/admin_v2/wechat-complaint/notify
# 需要配置微信支付API证书和密钥才能解密投诉通知

@bp.route('/wechat-complaint/notify', methods=['POST'])
def wechat_complaint_notify():
    """微信支付投诉通知接收 - 自动解密+回复"""
    import hashlib, base64
    try:
        data = request.get_json() or {}
        logger.info('[wechat_complaint_notify] 收到通知: %s', json.dumps(data, ensure_ascii=False)[:500])
        
        # 解密通知内容 (AEAD_AES_256_GCM)
        resource = data.get('resource', {})
        ciphertext_b64 = resource.get('ciphertext', '')
        nonce = resource.get('nonce', '')
        associated_data = resource.get('associated_data', '')
        api_v3_key = WX_API_V3_KEY.encode('utf-8')
        
        if not ciphertext_b64:
            logger.warning('[wechat_complaint_notify] 无ciphertext, 跳过解密')
            return jsonify({'code': 'SUCCESS', 'message': 'ok'})
        
        # AES-256-GCM解密
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        ciphertext = base64.b64decode(ciphertext_b64)
        aesgcm = AESGCM(api_v3_key)
        plaintext = aesgcm.decrypt(nonce.encode('utf-8'), ciphertext, associated_data.encode('utf-8'))
        complaint_data = json.loads(plaintext.decode('utf-8'))
        logger.info('[wechat_complaint_notify] 解密内容: %s', json.dumps(complaint_data, ensure_ascii=False)[:1000])
        
        # 提取投诉信息
        complaint_id = complaint_data.get('complaint_id', '')
        complaint_time = complaint_data.get('complaint_time', '')
        complaint_detail = complaint_data.get('complaint_detail', '')
        complaint_order_info = complaint_data.get('complaint_order_info', [])
        payer_phone = complaint_data.get('payer_phone', '')
        complaint_state = complaint_data.get('complaint_state', '')
        
        # 提取订单号
        order_no = ''
        if complaint_order_info:
            order_no = complaint_order_info[0].get('transaction_id', '') or complaint_order_info[0].get('out_trade_no', '')
        
        # 存入complaints表
        conn = get_db()
        c = conn.cursor()
        # 检查是否已存在
        existing = c.execute('SELECT id FROM complaints WHERE wx_complaint_id=?', (complaint_id,)).fetchone()
        if not existing:
            c.execute(
                'INSERT INTO complaints (user_phone, type, content, order_no, wx_complaint_id, complaint_type, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
                (payer_phone, 'wechat', complaint_detail or complaint_time or '微信投诉', order_no, complaint_id, 'wechat', 0)
            )
            conn.commit()
            logger.info('[wechat_complaint_notify] 已保存投诉: complaint_id=%s', complaint_id)
        else:
            logger.info('[wechat_complaint_notify] 投诉已存在: complaint_id=%s', complaint_id)
        conn.close()
        
        # 自动回复
        if complaint_id and complaint_state != 'USER_CREATE_COMPLAINT_REPLY':
            _auto_reply_complaint(complaint_id)
        
        return jsonify({'code': 'SUCCESS', 'message': 'ok'})
    except Exception as e:
        logger.error('[wechat_complaint_notify] 错误: %s', e, exc_info=True)
        return jsonify({'code': 'FAIL', 'message': str(e)})


def _auto_reply_complaint(complaint_id):
    """自动回复微信投诉"""
    import time, requests, base64
    try:
        # 获取access_token用于回复 (通过商户API)
        # 微信投诉回复API: POST https://api.mch.weixin.qq.com/v3/merchant-service/complaints-v2/{complaint_id}/response
        mch_id = WX_MCH_ID
        cert_serial = WX_CERT_SERIAL_NO
        private_key_path = WX_KEY_PATH
        
        with open(private_key_path, 'r') as f:
            private_key = f.read()
        
        reply_content = '已帮您在余额提现，请核对账单'
        
        # 构造签名
        timestamp = str(int(time.time()))
        nonce_str = os.urandom(16).hex()
        
        # POST body - 按微信投诉回复API V2规范
        # 文档: POST /v3/merchant-service/complaints-v2/{complaint_id}/response
        body = json.dumps({
            'complainted_mchid': mch_id,
            'response_content': reply_content,
            'response_images': []
        }, ensure_ascii=False)
        
        # 签名串构造

        url_path = '/v3/merchant-service/complaints-v2/' + complaint_id + '/response'
        sign_str = 'POST\n' + url_path + '\n' + timestamp + '\n' + nonce_str + '\n' + body + '\n'
        
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
        private_key_obj = serialization.load_pem_private_key(private_key.encode(), password=None)
        signature = private_key_obj.sign(
            sign_str.encode('utf-8'),
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        sign_b64 = base64.b64encode(signature).decode('utf-8')
        
        # 构造Authorization头
        authorization = 'WECHATPAY2-SHA256-RSA2048 mchid="' + mch_id + '",nonce_str="' + nonce_str + '",timestamp="' + timestamp + '",serial_no="' + cert_serial + '",signature="' + sign_b64 + '"'
        
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': authorization
        }
        
        resp = requests.post(
            'https://api.mch.weixin.qq.com' + url_path,
            data=body.encode('utf-8'),
            headers=headers,
            cert=(WX_CERT_PATH, WX_KEY_PATH),
            timeout=10
        )
        logger.info('[auto_reply] complaint_id=%s status=%s resp=%s', complaint_id, resp.status_code, resp.text[:500])
        
        # 更新complaints表状态
        conn = get_db()
        c = conn.cursor()
        c.execute('UPDATE complaints SET reply=?, status=1, reply_time=CURRENT_TIMESTAMP WHERE wx_complaint_id=?',
                  (reply_content, complaint_id))
        conn.commit()
        conn.close()
        
    except Exception as e:
        logger.error('[auto_reply] 投诉自动回复失败: %s', e, exc_info=True)



@bp.route('/admin/device/door-status', methods=['POST'])
@require_auth
def admin_query_door_status():
    import json as _j
    from helpers import connected_devices as _cd
    data = request.get_json()
    device_id = data.get('device_id', '')
    board_no = data.get('board_no', 1)
    lock_no = data.get('lock_no', 1)
    protocol = data.get('protocol', 'YBM')
    if not device_id:
        return json_response(message='device_id required', code=400)
    request_id = str(uuid.uuid4())
    with _door_status_lock:
        _door_status_results[request_id] = {'result': None, 'event': threading.Event()}
    if device_id in _cd:
        try:
            cmd = {'type': 'query_door_status', 'request_id': request_id, 'board_no': board_no, 'lock_no': lock_no, 'protocol': protocol}
            _cd[device_id].send(_j.dumps(cmd))
            logger.info('[door_status] sent: device=%s req=%s', device_id, request_id)
        except Exception as e:
            with _door_status_lock: _door_status_results.pop(request_id, None)
            return json_response(message='send failed: ' + str(e), code=500)
    else:
        with _door_status_lock: _door_status_results.pop(request_id, None)
        return json_response(message='device offline', code=400)
    with _door_status_lock:
        evt = _door_status_results.get(request_id, {}).get('event')
    if evt:
        ok = evt.wait(timeout=10)
        with _door_status_lock:
            result = _door_status_results.pop(request_id, {}).get('result')
        if result:
            return json_response(data=result)
        return json_response(message='query timeout', code=504)
    return json_response(message='query failed', code=500)
