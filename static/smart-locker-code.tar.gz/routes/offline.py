"""
离线取包API - Blueprint
支持断网时APK本地验证，网络恢复后同步到服务器
"""
import logging
from datetime import datetime
from flask import Blueprint, request
from database import get_db
from helpers import json_response, logger, pending_lock_commands

bp = Blueprint('offline', __name__)


@bp.route('/lock-result', methods=['POST'])
def report_lock_result():
    """HTTP开锁结果上报"""
    try:
        data = request.get_json()
        device_id = data.get('device_id')
        order_id = data.get('order_id')
        success = data.get('success', False)
        logger.info(f'[HTTP上报] 开锁结果: device_id={device_id}, order_id={order_id}, success={success}')
        if order_id and success:
            conn = get_db()
            cursor = conn.cursor()
            try:
                oid = int(order_id)
            except (ValueError, TypeError):
                oid = None
            if oid:
                cursor.execute('SELECT o.slot_id FROM orders o WHERE o.id = ?', (oid,))
            else:
                cursor.execute('SELECT o.slot_id FROM orders o WHERE o.order_no = ?', (str(order_id),))
            order = cursor.fetchone()
            if order and order['slot_id']:
                cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ?', (order['slot_id'],))
                conn.commit()
            conn.close()
        return json_response({'message': '结果已记录'})
    except Exception as e:
        logger.error(f'[lock_result] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/pending-commands/<device_id>', methods=['GET'])
def get_pending_commands(device_id):
    """获取待处理的离线指令"""
    try:
        import sqlite3 as _sqlite3
        _db = _sqlite3.connect('/home/ubuntu/smart-locker/locker.db', timeout=30)
        _db.row_factory = _sqlite3.Row
        _cur = _db.cursor()
        _cur.execute('SELECT * FROM pending_lock_cmds WHERE device_id=? AND delivered=0 ORDER BY id', (device_id,))
        pending_rows = _cur.fetchall()
        valid_commands = []
        for row in pending_rows:
            valid_commands.append({
                'order_id': str(row['order_id']) if row['order_id'] else '',
                'board_no': row['board_no'],
                'lock_no': row['lock_no'],
                'action': 'open',
                'protocol': row['protocol'],
                'timestamp': row['created_at']
            })
        # Add update info before closing db
        update_info = None
        try:
            _cur2 = _db.cursor()
            _cur2.execute('SELECT * FROM apk_version ORDER BY id DESC LIMIT 1')
            apk_row = _cur2.fetchone()
            if apk_row:
                update_info = {
                    'has_update': True,
                    'version_name': apk_row['version_name'],
                    'version_code': apk_row['version_code'],
                    'download_url': apk_row['download_url'],
                    'update_desc': apk_row['update_desc'] or '',
                    'force': True
                }
        except:
            pass
        _db.close()
        now = datetime.now()
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT o.id as order_id, o.order_no, o.user_phone, o.access_code, o.deposit_amount, o.compartment_number, o.slot_size, o.cabinet_id, o.store_time FROM orders o JOIN cabinets c ON o.cabinet_id = c.id WHERE c.mainboard_device_id = ? AND o.status = 2 ORDER BY o.id DESC', (device_id,))
        orders = [dict(row) for row in cursor.fetchall()]
        conn.close()

        return json_response({'commands': valid_commands, 'orders': orders,
                              'server_time': now.strftime('%Y-%m-%d %H:%M:%S'),
                              'update': update_info})
    except Exception as e:
        logger.error(f'[pending_commands] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/active-orders/by-device/<device_id>', methods=['GET'])
def get_active_orders_by_device(device_id):
    """获取设备的活动订单"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT o.id as order_id, o.order_no, o.user_phone, o.access_code, o.deposit_amount, o.compartment_number, o.slot_size, o.cabinet_id, o.store_time FROM orders o JOIN cabinets c ON o.cabinet_id = c.id WHERE c.mainboard_device_id = ? AND o.status = 2 ORDER BY o.id DESC', (device_id,))
        orders = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return json_response({'orders': orders, 'count': len(orders), 'device_id': device_id,
                              'server_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
    except Exception as e:
        logger.error(f'[active_orders] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/offline-retrieve', methods=['POST'])
def offline_retrieve():
    """离线取包同步（单条）"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        order_no = data.get('order_no')
        user_phone = data.get('user_phone')
        retrieve_time = data.get('retrieve_time')
        if not order_id and not order_no:
            return json_response(message='缺少订单信息', code=400)
        conn = get_db()
        cursor = conn.cursor()
        if order_id:
            cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
        else:
            cursor.execute('SELECT * FROM orders WHERE order_no = ?', (order_no,))
        order = cursor.fetchone()
        if not order:
            conn.close()
            return json_response(message='订单不存在', code=404)
        if order['status'] != 2:
            conn.close()
            return json_response(message=f'订单已处理（当前状态: {order["status"]}）', code=400)
        if user_phone and order['user_phone'] != user_phone:
            conn.close()
            return json_response(message='手机号不匹配', code=403)
        actual_time = retrieve_time or datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute('UPDATE orders SET status = 3, retrieve_time = ? WHERE id = ? AND status = 2', (actual_time, order['id']))
        if order['slot_id']:
            cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ?', (order['slot_id'],))
        conn.commit()
        conn.close()
        return json_response({'message': '取包记录已同步', 'order_id': order['id'], 'order_no': order['order_no'],
                              'status': 3, 'retrieve_time': actual_time})
    except Exception as e:
        logger.error(f'[offline_retrieve] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/offline-retrieve/batch', methods=['POST'])
def offline_retrieve_batch():
    """离线取包批量同步"""
    try:
        data = request.get_json()
        records = data.get('records', [])
        device_id = data.get('device_id')
        if not records:
            return json_response(message='无记录需要同步', code=400)
        conn = get_db()
        cursor = conn.cursor()
        results = []
        for rec in records:
            oid = rec.get('order_id')
            ono = rec.get('order_no')
            try:
                if oid:
                    cursor.execute('SELECT * FROM orders WHERE id = ?', (oid,))
                else:
                    cursor.execute('SELECT * FROM orders WHERE order_no = ?', (ono,))
                order = cursor.fetchone()
                if not order:
                    results.append({'order_id': oid, 'order_no': ono, 'status': 'not_found'})
                    continue
                if order['status'] != 2:
                    results.append({'order_id': order['id'], 'order_no': order['order_no'], 'status': 'already_processed'})
                    continue
                actual_time = rec.get('retrieve_time') or datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                cursor.execute('UPDATE orders SET status = 3, retrieve_time = ? WHERE id = ? AND status = 2', (actual_time, order['id']))
                if order['slot_id']:
                    cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ?', (order['slot_id'],))
                results.append({'order_id': order['id'], 'order_no': order['order_no'], 'status': 'ok'})
            except Exception as e:
                results.append({'order_id': oid, 'order_no': ono, 'status': 'error', 'message': str(e)})
        conn.commit()
        conn.close()
        success_count = sum(1 for r in results if r['status'] == 'ok')
        return json_response({'total': len(records), 'success': success_count, 'results': results})
    except Exception as e:
        logger.error(f'[offline_batch] {e}')
        return json_response(message=str(e), code=500)