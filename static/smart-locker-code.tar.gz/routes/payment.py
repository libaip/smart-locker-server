"""
支付相关API - Blueprint
包含：支付渠道管理、支付/退款回调
"""
import logging
import json
import random
import string
from datetime import datetime
from flask import Blueprint, request
from database import get_db
from helpers import (json_response, require_auth, get_setting, is_mock_mode, logger,
                     get_wxpay, get_channel_wxpay, update_channel_stats, send_open_lock)
from wxpay import WxPay, ThirdPartyPay

bp = Blueprint('payment', __name__)


# ============================================
# 支付渠道管理
# ============================================

@bp.route('/payment-channels', methods=['GET'])
def list_payment_channels():
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM payment_channels ORDER BY id')
        channels = [dict(ch) for ch in cursor.fetchall()]
        conn.close()
        return json_response(channels)
    except Exception as e:
        logger.error(f'[list_channels] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/payment-channels', methods=['POST'])
@require_auth
def create_payment_channel():
    try:
        data = request.get_json()
        name = data.get('name')
        channel_type = data.get('channel_type', 'wechat')
        mch_id = data.get('mch_id')
        api_key = data.get('api_key')
        app_id = data.get('app_id')
        app_secret = data.get('app_secret')
        cert_name = data.get('cert_name')
        extra_config = data.get('extra_config')
        weight = data.get('weight', 1)
        daily_limit = data.get('daily_limit', 0)
        is_active = data.get('is_active', 1)
        if not name:
            return json_response(message='渠道名称不能为空', code=400)
        if channel_type == 'wechat' and not mch_id:
            return json_response(message='微信渠道商户号不能为空', code=400)
        if channel_type == 'third_party' and not mch_id:
            return json_response(message='第三方平台AppID不能为空', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO payment_channels (name, channel_type, mch_id, api_key, app_id, app_secret, cert_name, extra_config, is_active, weight, daily_limit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                       (name, channel_type, mch_id, api_key, app_id, app_secret, cert_name,
                        json.dumps(extra_config) if isinstance(extra_config, dict) else extra_config,
                        is_active, weight, daily_limit))
        conn.commit()
        channel_id = cursor.lastrowid
        conn.close()
        return json_response({'id': channel_id, 'message': '渠道创建成功'})
    except Exception as e:
        logger.error(f'[create_channel] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/payment-channels/<int:channel_id>', methods=['PUT'])
@require_auth
def update_payment_channel(channel_id):
    try:
        data = request.get_json()
        conn = get_db()
        cursor = conn.cursor()
        updates, params = [], []
        for field in ['name', 'channel_type', 'mch_id', 'api_key', 'app_id', 'app_secret', 'cert_name', 'is_active', 'weight', 'daily_limit']:
            if field in data:
                updates.append(f'{field} = ?')
                params.append(data[field])
        if 'extra_config' in data:
            updates.append("extra_config = ?")
            ec = data['extra_config']
            params.append(json.dumps(ec) if isinstance(ec, dict) else ec)
        if not updates:
            conn.close()
            return json_response(message='无更新内容', code=400)
        params.append(channel_id)
        cursor.execute(f"UPDATE payment_channels SET {', '.join(updates)} WHERE id = ?", params)
        conn.commit()
        conn.close()
        return json_response({'message': '渠道更新成功'})
    except Exception as e:
        logger.error(f'[update_channel] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/payment-channels/<int:channel_id>', methods=['DELETE'])
@require_auth
def delete_payment_channel(channel_id):
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM orders WHERE payment_channel_id = ?', (channel_id,))
        if cursor.fetchone()[0] > 0:
            conn.close()
            return json_response(message=f'该渠道下有订单，无法删除，请禁用', code=400)
        cursor.execute('DELETE FROM payment_channels WHERE id = ?', (channel_id,))
        conn.commit()
        conn.close()
        return json_response({'message': '渠道删除成功'})
    except Exception as e:
        logger.error(f'[delete_channel] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/payment-channels/<int:channel_id>/toggle', methods=['POST'])
@require_auth
def toggle_payment_channel(channel_id):
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT is_active FROM payment_channels WHERE id = ?', (channel_id,))
        channel = cursor.fetchone()
        if not channel:
            conn.close()
            return json_response(message='渠道不存在', code=404)
        new_status = 0 if channel['is_active'] else 1
        cursor.execute('UPDATE payment_channels SET is_active = ? WHERE id = ?', (new_status, channel_id))
        conn.commit()
        conn.close()
        return json_response({'is_active': new_status, 'message': '渠道状态已更新'})
    except Exception as e:
        logger.error(f'[toggle_channel] {e}')
        return json_response(message=str(e), code=500)


@bp.route('/payment-channels/<int:channel_id>/reset-stats', methods=['POST'])
@require_auth
def reset_channel_stats(channel_id):
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('UPDATE payment_channels SET total_amount = 0, total_count = 0 WHERE id = ?', (channel_id,))
        conn.commit()
        conn.close()
        return json_response({'message': '统计已重置'})
    except Exception as e:
        logger.error(f'[reset_channel_stats] {e}')
        return json_response(message=str(e), code=500)


# ============================================
# 支付回调
# ============================================

@bp.route('/pay/notify', methods=['POST', 'GET'])
def pay_notify():
    """微信支付结果回调"""
    try:
        logger.info('[支付回调] 收到通知')
        xml_data = request.get_data(as_text=True)
        mock_mode = is_mock_mode()
        if mock_mode:
            return WxPay.build_pay_notify_response('SUCCESS', 'OK')

        temp_result = WxPay.xml_to_dict(xml_data)
        out_trade_no = temp_result.get('out_trade_no', '')
        notify_wxpay = get_wxpay()

        if out_trade_no:
            try:
                conn = get_db()
                cursor = conn.cursor()
                cursor.execute('SELECT payment_channel_id FROM orders WHERE order_no = ?', (out_trade_no,))
                order_row = cursor.fetchone()
                if order_row and order_row['payment_channel_id']:
                    cursor.execute('SELECT * FROM payment_channels WHERE id = ?', (order_row['payment_channel_id'],))
                    ch = cursor.fetchone()
                    if ch:
                        wxpay_inst, ch_type = get_channel_wxpay(dict(ch))
                        if wxpay_inst and ch_type == 'wechat':
                            notify_wxpay = wxpay_inst
                conn.close()
            except Exception as e:
                logger.error(f'[支付回调] 渠道查询异常: {e}')

        result = notify_wxpay.parse_pay_notify(xml_data)
        if result.get('return_code') != 'SUCCESS':
            return notify_wxpay.build_pay_notify_response('FAIL', result.get('return_msg')), 400

        out_trade_no = result.get('out_trade_no')
        transaction_id = result.get('transaction_id')
        trade_state = result.get('trade_state', result.get('result_code'))

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM orders WHERE order_no = ?', (out_trade_no,))
        order = cursor.fetchone()
        if not order:
            conn.close()
            return notify_wxpay.build_pay_notify_response('FAIL', '订单不存在'), 400
        if order['status'] in [2, 3, 4]:
            conn.close()
            return notify_wxpay.build_pay_notify_response('SUCCESS', 'OK'), 200

        if trade_state == 'SUCCESS' or result.get('result_code') == 'SUCCESS':
            cursor.execute('UPDATE orders SET status = 2, transaction_id = ?, pay_time = ? WHERE id = ?',
                           (transaction_id, datetime.now(), order['id']))
            if order['slot_id']:
                cursor.execute('UPDATE cabinet_slots SET status = 2 WHERE id = ?', (order['slot_id'],))
            cursor.execute('INSERT INTO payments (order_id, type, amount, transaction_id, status) VALUES (?, 1, ?, ?, 1)',
                           (order['id'], order['deposit_amount'], transaction_id))
            # 更新用户余额
            try:
                cursor.execute('SELECT id FROM user_balances WHERE phone = ?', (order['user_phone'],))
                ub = cursor.fetchone()
                if ub:
                    cursor.execute('UPDATE user_balances SET balance = balance + ?, total_deposited = total_deposited + ? WHERE phone = ?',
                                   (order['deposit_amount'], order['deposit_amount'], order['user_phone']))
                else:
                    cursor.execute('INSERT INTO user_balances (phone, balance, total_deposited, first_use_time) VALUES (?, ?, ?, ?)',
                                   (order['user_phone'], order['deposit_amount'], order['deposit_amount'], datetime.now()))
            except Exception as e:
                logger.error(f'[支付回调更新余额失败] {e}')
            # 记录开锁信息（在commit之前读取，避免DB锁）
            _open_lock_info = None
            try:
                cursor.execute('SELECT mainboard_device_id, mainboard_source FROM cabinets WHERE id = ?', (order['cabinet_id'],))
                cab_info = cursor.fetchone()
                if cab_info and cab_info['mainboard_device_id']:
                    _open_lock_info = {
                        'device_id': str(cab_info['mainboard_device_id']),
                        'board_no': 1,
                        'lock_no': order['compartment_number'] or 1,
                        'protocol': cab_info['mainboard_source'] or 'QM',
                        'order_id': order['order_no']
                    }
            except Exception as e:
                logger.error(f'[支付回调读取开锁信息失败] {e}')
            _channel_id = order['payment_channel_id']
            _deposit_amount = order['deposit_amount']
        else:
            cursor.execute('UPDATE orders SET status = 5 WHERE id = ?', (order['id'],))
            if order['slot_id']:
                cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ?', (order['slot_id'],))
        # 先在DB提交前发送开门指令（WebSocket立即发出，独立DB连接不冲突）
        if trade_state == 'SUCCESS' or result.get('result_code') == 'SUCCESS':
            if _open_lock_info:
                try:
                    send_open_lock(_open_lock_info['device_id'], _open_lock_info['board_no'],
                                   _open_lock_info['lock_no'], _open_lock_info['protocol'],
                                   _open_lock_info['order_id'])
                except Exception as e:
                    logger.error(f'[支付回调开锁失败] {e}')
            if _channel_id:
                try:
                    update_channel_stats(_channel_id, _deposit_amount)
                except Exception as e:
                    logger.error(f'[支付回调更新渠道统计失败] {e}')
        conn.commit()
        conn.close()
        return notify_wxpay.build_pay_notify_response('SUCCESS', 'OK'), 200
    except Exception as e:
        logger.error(f'[pay_notify] {e}')
        return 'fail', 500


@bp.route('/refund/notify', methods=['POST', 'GET'])
def refund_notify():
    """微信退款回调"""
    try:
        logger.info('[退款回调] 收到通知')
        xml_data = request.get_data(as_text=True)
        mock_mode = is_mock_mode()
        if mock_mode:
            return WxPay.build_pay_notify_response('SUCCESS', 'OK')
        wxpay = get_wxpay()
        result, success = wxpay.parse_refund_notify(xml_data)
        if not success:
            return wxpay.build_pay_notify_response('FAIL', '解析失败'), 400
        return wxpay.build_pay_notify_response('SUCCESS', 'OK'), 200
    except Exception as e:
        logger.error(f'[refund_notify] {e}')
        return 'fail', 500


@bp.route('/pay/notify/third-party', methods=['POST', 'GET'])
def third_party_pay_notify():
    """第三方支付回调"""
    try:
        logger.info('[第三方支付回调] 收到通知')
        if request.method == 'GET':
            params = dict(request.args)
        else:
            params = dict(request.form) if request.form else (request.get_json(silent=True) or {})

        out_trade_no = params.get('trade_order_id', params.get('out_trade_no', ''))
        if not out_trade_no:
            return 'fail', 400

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM orders WHERE order_no = ?', (out_trade_no,))
        order = cursor.fetchone()
        if not order or order['status'] in [2, 3, 4]:
            conn.close()
            return 'fail' if not order else 'success'

        # 验签
        if order['payment_channel_id']:
            cursor.execute('SELECT * FROM payment_channels WHERE id = ?', (order['payment_channel_id'],))
            channel = cursor.fetchone()
            if channel:
                tpp = ThirdPartyPay(appid=channel['mch_id'], appsecret=channel['api_key'], notify_url='')
                if not tpp.verify_notify(params):
                    conn.close()
                    return 'fail', 400

        if params.get('status') == 'OD' or params.get('return_code') == 'SUCCESS':
            transaction_id = params.get('transaction_id', params.get('order_id', ''))
            cursor.execute('UPDATE orders SET status = 2, transaction_id = ?, pay_time = ? WHERE id = ?',
                           (transaction_id, datetime.now(), order['id']))
            if order['slot_id']:
                cursor.execute('UPDATE cabinet_slots SET status = 2 WHERE id = ?', (order['slot_id'],))
            cursor.execute('INSERT INTO payments (order_id, type, amount, transaction_id, status) VALUES (?, 1, ?, ?, 1)',
                           (order['id'], order['deposit_amount'], transaction_id))
            if order['payment_channel_id']:
                update_channel_stats(order['payment_channel_id'], order['deposit_amount'])
            conn.commit()
            conn.close()
            return 'success'
        conn.close()
        return 'fail'
    except Exception as e:
        logger.error(f'[third_party_notify] {e}')
        return 'fail', 500