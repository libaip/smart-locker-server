"""
用户端API - Blueprint
包含：存包、取包、押金流程、短信验证、H5存包
"""
import logging
import random
import string
import json
import qrcode
import io
import base64
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, send_from_directory, redirect, send_file
from database import get_db
from helpers import (json_response, get_setting, is_mock_mode, is_wechat_browser,
                     is_mobile_browser, send_open_lock, get_payment_params,
                     generate_order_no, generate_access_code, generate_sms_code,
                     logger)
from models import BRAND_DEFAULTS

bp = Blueprint('user', __name__)


# ============================================
# 存包流程
# ============================================



@bp.route('/cabinet/<int:cabinet_id>/available-sizes', methods=['GET'])
def cabinet_available_sizes(cabinet_id):
    """获取柜体可用的格子尺寸列表"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT slot_size, COUNT(*) as total, SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) as available "
            "FROM cabinet_slots WHERE cabinet_id = ? GROUP BY slot_size ORDER BY slot_size",
            (cabinet_id,))
        sizes = []
        for row in cursor.fetchall():
            sizes.append({'size': row['slot_size'], 'total': row['total'], 'available': row['available'] or 0})
        conn.close()
        return json_response({'sizes': sizes})
    except Exception as e:
        logger.error(f'[cabinet_available_sizes] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/deposit/pay-order', methods=['POST'])
def deposit_pay_order():
    """对已存在的订单发起支付（柜门已在store/init时分配）"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if not order_id:
            return json_response(message='order_id不能为空', code=400)

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT o.*, c.mainboard_device_id FROM orders o JOIN cabinets c ON o.cabinet_id = c.id WHERE o.id = ?', (order_id,))
        order = cursor.fetchone()
        conn.close()

        if not order:
            return json_response(message='订单不存在', code=404)
        if order['status'] != 1:
            return json_response(message='订单状态异常，无法支付', code=400)

        from helpers import select_payment_channel
        payment_channel = select_payment_channel()
        payment_channel_id = payment_channel['id'] if payment_channel else None

        openid = data.get('openid')
        pay_params = get_payment_params(order_id, order['order_no'], order['deposit_amount'],
                                         order['user_phone'], openid,
                                         payment_channel=payment_channel,
                                         payment_channel_id=payment_channel_id)

        return json_response({
            'order_id': order['id'], 'order_no': order['order_no'],
            'access_code': order['access_code'], 'cabinet_id': order['cabinet_id'],
            'compartment_number': order['compartment_number'],
            'deposit_amount': order['deposit_amount'], 'pay_params': pay_params
        })
    except Exception as e:
        logger.error(f'[deposit_pay_order] 错误: {e}')
        return json_response(message=str(e), code=500)

@bp.route('/store/init', methods=['POST'])
def store_init():
    """存包初始化 - 分配柜格并创建订单（状态=待支付）"""
    try:
        data = request.get_json()
        cabinet_id = data.get('cabinet_id')
        slot_size = data.get('slot_size', 'M')
        user_phone = data.get('phone')
        sms_code = data.get('sms_code')
        access_code = data.get('access_code')

        if not all([cabinet_id, user_phone]):
            return json_response(message='参数不完整', code=400)

        # 检查设备是否在线
        from helpers import connected_devices
        conn0 = get_db()
        cur0 = conn0.cursor()
        cur0.execute('SELECT mainboard_device_id FROM cabinets WHERE id=?', (cabinet_id,))
        cab0 = cur0.fetchone()
        conn0.close()
        device_online = False
        if cab0 and cab0['mainboard_device_id']:
            device_online = cab0['mainboard_device_id'] in connected_devices
        # 如果没有绑定设备ID，允许仅从数据库分配（柜门分配不依赖设备在线）
        # 如果绑定了设备ID但设备不在线，仍然允许分配，支付成功后再开柜

        sms_enabled = get_setting('sms_enabled', 'false').lower() == 'true'
        if sms_enabled and not sms_code:
            return json_response(message='请输入短信验证码', code=400)

        if sms_enabled:
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM sms_codes WHERE phone = ? AND code = ? AND expires_at > ? ORDER BY id DESC LIMIT 1',
                           (user_phone, sms_code, datetime.now()))
            sms_record = cursor.fetchone()
            if not sms_record:
                conn.close()
                return json_response(message='短信验证码错误', code=400)
            cursor.execute('DELETE FROM sms_codes WHERE id = ?', (sms_record['id'],))
            conn.commit()
            conn.close()

        conn = get_db()
        cursor = conn.cursor()

        cursor.execute('SELECT cs.*, MAX(o.store_time) as last_used_at FROM cabinet_slots cs JOIN cabinets c ON cs.cabinet_id = c.id LEFT JOIN orders o ON o.slot_id = cs.id WHERE c.id = ? AND cs.status = 1 AND cs.slot_size = ? GROUP BY cs.id ORDER BY CASE WHEN last_used_at IS NULL THEN 0 ELSE 1 END, last_used_at ASC, cs.slot_number ASC LIMIT 1',
                       (cabinet_id, slot_size))
        slot = cursor.fetchone()
        if not slot:
            cursor.execute('SELECT cs.*, MAX(o.store_time) as last_used_at FROM cabinet_slots cs JOIN cabinets c ON cs.cabinet_id = c.id LEFT JOIN orders o ON o.slot_id = cs.id WHERE c.id = ? AND cs.status = 1 GROUP BY cs.id ORDER BY CASE WHEN last_used_at IS NULL THEN 0 ELSE 1 END, last_used_at ASC, cs.slot_number ASC LIMIT 1',
                           (cabinet_id,))
            slot = cursor.fetchone()
        if not slot:
            conn.close()
            return json_response(message='暂无可用柜格', code=400)

        if not access_code:
            access_code = generate_access_code()
        elif len(access_code) != 4 or not access_code.isdigit():
            conn.close()
            return json_response(message='取件码必须为4位数字', code=400)

        order_no = generate_order_no()
        cursor.execute('SELECT deposit_amount FROM cabinets WHERE id = ?', (cabinet_id,))
        cab_row = cursor.fetchone()
        deposit_amount = cab_row['deposit_amount'] if cab_row and cab_row['deposit_amount'] else float(get_setting('deposit_amount', '20'))
        compartment_display = slot['slot_label'] if 'slot_label' in slot.keys() and slot['slot_label'] else (slot['display_number'] if slot['display_number'] else slot['slot_number'])

        cursor.execute('INSERT INTO orders (order_no, user_phone, slot_id, cabinet_id, compartment_number, access_code, deposit_amount, status, store_time, logical_mark) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)',
                       (order_no, user_phone, slot['id'], cabinet_id, compartment_display, access_code, deposit_amount, datetime.now(), 'N'))
        order_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return json_response({'order_id': order_id, 'order_no': order_no, 'access_code': access_code,
                              'slot_id': slot['id'], 'cabinet_id': cabinet_id, 'compartment_number': compartment_display, 'compartment_label': slot['slot_label'] if 'slot_label' in slot.keys() and slot['slot_label'] else '',
                              'slot_size': slot['slot_size'], 'deposit_amount': deposit_amount})
    except Exception as e:
        logger.error(f'[store_init] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/store', methods=['POST'])
def store_legacy():
    """存包API - 简化版兼容"""
    try:
        data = request.get_json()
        cabinet_id = data.get('cabinet_id')
        compartment_size = data.get('size', 'M')
        user_phone = data.get('phone')
        access_code = data.get('access_code', generate_access_code())
        if not all([cabinet_id, user_phone]):
            return json_response(message='参数不完整', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT cs.* FROM cabinet_slots cs JOIN cabinets c ON cs.cabinet_id = c.id WHERE c.id = ? AND cs.status = 1 AND cs.slot_size = ? LIMIT 1',
                       (cabinet_id, compartment_size))
        slot = cursor.fetchone()
        if not slot:
            cursor.execute('SELECT cs.* FROM cabinet_slots cs JOIN cabinets c ON cs.cabinet_id = c.id WHERE c.id = ? AND cs.status = 1 LIMIT 1', (cabinet_id,))
            slot = cursor.fetchone()
        if not slot:
            conn.close()
            return json_response(message='暂无可用柜格', code=400)
        cursor.execute('UPDATE cabinet_slots SET status = 2 WHERE id = ?', (slot['id'],))
        cursor.execute('INSERT INTO storage_records (cabinet_id, compartment_number, user_phone, access_code, status, store_time) VALUES (?, ?, ?, ?, 2, ?)',
                       (cabinet_id, slot['slot_number'], user_phone, access_code, datetime.now()))
        conn.commit()
        conn.close()
        return json_response({'cabinet_id': cabinet_id, 'compartment_number': slot['slot_number'], 'access_code': access_code, 'slot_size': slot['slot_size']})
    except Exception as e:
        logger.error(f'[store_legacy] 错误: {e}')
        return json_response(message=str(e), code=500)


# ============================================
# 取包流程
# ============================================

@bp.route('/retrieve', methods=['POST'])
def retrieve():
    """取包API - 支持两种模式：
    1. 原始模式: cabinet_id + compartment_number + access_code
    2. APK模式: phone + access_code + device_id (PickUpActivity调用)
    """
    try:
        data = request.get_json()
        access_code = data.get('access_code', '')
        phone = data.get('phone', '')
        device_id = data.get('device_id', '')
        cabinet_id = data.get('cabinet_id')
        compartment_number = data.get('compartment_number')

        conn = get_db()
        cursor = conn.cursor()

        # APK模式: phone + access_code + device_id
        if phone and access_code and device_id:
            cursor.execute(
                'SELECT o.*, c.mainboard_device_id FROM orders o '
                'JOIN cabinets c ON o.cabinet_id = c.id '
                'WHERE o.user_phone = ? AND o.access_code = ? AND c.mainboard_device_id = ? AND o.status = 2 '
                'ORDER BY o.id DESC LIMIT 1',
                (phone, access_code, device_id))
            order = cursor.fetchone()
            if not order:
                conn.close()
                return json_response(message='取件码错误或柜格已空', code=400)
            cursor.execute('UPDATE orders SET status = 3, retrieve_time = ? WHERE id = ?',
                           (datetime.now(), order['id']))
            if order['slot_id']:
                cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ?', (order['slot_id'],))
            conn.commit()
            conn.close()
            return json_response({'message': '取包成功', 'order_no': order['order_no'],
                                   'order_id': order['id'], 'code': 0})

        # 原始模式: cabinet_id + compartment_number + access_code
        if cabinet_id and compartment_number and access_code:
            cursor.execute(
                'SELECT * FROM storage_records WHERE cabinet_id = ? AND compartment_number = ? AND access_code = ? AND status = 2 ORDER BY id DESC LIMIT 1',
                (cabinet_id, compartment_number, access_code))
            record = cursor.fetchone()
            if not record:
                conn.close()
                return json_response(message='取件码错误或柜格已空', code=400)
            cursor.execute('UPDATE storage_records SET status = 1, retrieve_time = ? WHERE id = ?',
                           (datetime.now(), record['id']))
            cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE cabinet_id = ? AND slot_number = ?',
                           (cabinet_id, compartment_number))
            conn.commit()
            conn.close()
            return json_response(message='取包成功')

        conn.close()
        return json_response(message='参数不完整', code=400)
    except Exception as e:
        logger.error(f'[retrieve] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/retrieve/verify', methods=['POST'])
def retrieve_verify():
    """取包验证 - 验证手机号和取件码"""
    try:
        data = request.get_json()
        cabinet_id = data.get('cabinet_id')
        phone = data.get('phone')
        access_code = data.get('access_code')
        if not all([cabinet_id, phone, access_code]):
            return json_response(message='参数不完整', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT o.*, COALESCE(cs.slot_size, o.slot_size) as slot_size, cs.board_no, cs.lock_no FROM orders o JOIN cabinet_slots cs ON o.slot_id = cs.id WHERE o.cabinet_id = ? AND o.user_phone = ? AND o.access_code = ? AND o.status = 2 ORDER BY o.id DESC LIMIT 1',
                       (cabinet_id, phone, access_code))
        order = cursor.fetchone()
        conn.close()
        if not order:
            return json_response(message='验证失败，请检查手机号和取件码', code=400)
        return json_response({'order_id': order['id'], 'order_no': order['order_no'], 'slot_id': order['slot_id'],
                              'compartment_number': order['compartment_number'], 'slot_size': order['slot_size'],
                              'board_no': order['board_no'], 'lock_no': order['lock_no'],
                              'deposit_amount': order['deposit_amount'], 'store_time': order['store_time']})
    except Exception as e:
        logger.error(f'[retrieve_verify] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/retrieve/confirm', methods=['POST'])
def retrieve_confirm():
    """取包确认 - 继续存或结束"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        action = data.get('action')
        if not all([order_id, action]):
            return json_response(message='参数不完整', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
        order = cursor.fetchone()
        if not order:
            conn.close()
            return json_response(message='订单不存在', code=404)
        if action == 'continue':
            conn.close()
            return json_response({'action': 'continue', 'message': '请继续使用，已为您保留柜格'})
        deposit_amount = order['deposit_amount']
        transaction_id = order['transaction_id']
        cursor.execute('UPDATE orders SET status = 3, retrieve_time = ? WHERE id = ?', (datetime.now(), order_id))
        cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ?', (order['slot_id'],))
        refund_success = False
        refund_id = None
        mock_mode = is_mock_mode()
        if mock_mode:
            refund_id = 'MOCK_R' + datetime.now().strftime('%Y%m%d%H%M%S') + ''.join(random.choices(string.digits, k=4))
            refund_success = True
        elif transaction_id:
            refund_success = True
            refund_id = 'MOCK_R' + datetime.now().strftime('%Y%m%d%H%M%S') + ''.join(random.choices(string.digits, k=4))
        cursor.execute('INSERT INTO payments (order_id, type, amount, refund_transaction_id, status) VALUES (?, 2, ?, ?, ?)',
                       (order_id, deposit_amount, refund_id, 1 if refund_success else 0))
        if not refund_success:
            cursor.execute('UPDATE orders SET status = 6 WHERE id = ?', (order_id,))
        conn.commit()
        conn.close()
        if refund_success:
            return json_response({'action': 'end', 'refund_amount': deposit_amount, 'refund_id': refund_id, 'message': f'取包成功，押金¥{deposit_amount}已退还'})
        return json_response({'action': 'end', 'refund_amount': 0, 'message': '取包成功，但押金退款失败'}, message='取包成功，退款异常', code=200)
    except Exception as e:
        logger.error(f'[retrieve_confirm] 错误: {e}')
        return json_response(message=str(e), code=500)


# ============================================
# 押金存包流程
# ============================================

@bp.route('/deposit/create-order', methods=['POST'])
def create_deposit_order():
    """创建存包订单并获取微信支付参数"""
    try:
        data = request.get_json()
        cabinet_id = data.get('cabinet_id')
        slot_size = data.get('slot_size', 'M')
        user_phone = data.get('phone')
        sms_code = data.get('sms_code')
        access_code = data.get('access_code')
        if not all([cabinet_id, user_phone]):
            return json_response(message='参数不完整', code=400)
        sms_enabled = get_setting('sms_enabled', 'false').lower() == 'true'
        if sms_enabled and not sms_code:
            return json_response(message='请输入短信验证码', code=400)
        if sms_enabled:
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM sms_codes WHERE phone = ? AND code = ? AND expires_at > ? ORDER BY id DESC LIMIT 1',
                           (user_phone, sms_code, datetime.now()))
            sms_record = cursor.fetchone()
            if not sms_record:
                conn.close()
                return json_response(message='短信验证码错误', code=400)
            cursor.execute('DELETE FROM sms_codes WHERE id = ?', (sms_record['id'],))
            conn.commit()
            conn.close()
        conn = get_db()
        cursor = conn.cursor()
        # 清理同一手机号+同一柜子的未支付订单（用户可能放弃支付又重新扫码）
        cursor.execute('SELECT id, slot_id FROM orders WHERE user_phone = ? AND cabinet_id = ? AND status = 1', (user_phone, cabinet_id))
        stale_orders = cursor.fetchall()
        for stale in stale_orders:
            # 释放被占的柜门
            if stale['slot_id']:
                cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ? AND status = 2', (stale['slot_id'],))
            # 删除未支付订单
            cursor.execute('DELETE FROM orders WHERE id = ? AND status = 1', (stale['id'],))
        if stale_orders:
            conn.commit()
            logger.info(f'[create_deposit_order] 清理了 {len(stale_orders)} 个未支付订单, phone={user_phone}, cabinet_id={cabinet_id}')
        cursor.execute('SELECT cs.*, MAX(o.store_time) as last_used_at FROM cabinet_slots cs JOIN cabinets c ON cs.cabinet_id = c.id LEFT JOIN orders o ON o.slot_id = cs.id WHERE c.id = ? AND cs.status = 1 AND cs.slot_size = ? GROUP BY cs.id ORDER BY CASE WHEN last_used_at IS NULL THEN 0 ELSE 1 END, last_used_at ASC, cs.slot_number ASC LIMIT 1',
                       (cabinet_id, slot_size))
        slot = cursor.fetchone()
        if not slot:
            cursor.execute('SELECT cs.*, MAX(o.store_time) as last_used_at FROM cabinet_slots cs JOIN cabinets c ON cs.cabinet_id = c.id LEFT JOIN orders o ON o.slot_id = cs.id WHERE c.id = ? AND cs.status = 1 GROUP BY cs.id ORDER BY CASE WHEN last_used_at IS NULL THEN 0 ELSE 1 END, last_used_at ASC, cs.slot_number ASC LIMIT 1', (cabinet_id,))
            slot = cursor.fetchone()
        if not slot:
            conn.close()
            return json_response(message='暂无可用柜格', code=400)
        if not access_code:
            access_code = generate_access_code()
        elif len(access_code) != 4 or not access_code.isdigit():
            conn.close()
            return json_response(message='取件码必须为4位数字', code=400)
        order_no = generate_order_no()
        cursor.execute('SELECT deposit_amount FROM cabinets WHERE id = ?', (cabinet_id,))
        cab_row = cursor.fetchone()
        deposit_amount = cab_row['deposit_amount'] if cab_row and cab_row['deposit_amount'] else float(get_setting('deposit_amount', '20'))
        # 选择支付渠道
        from helpers import select_payment_channel
        payment_channel = select_payment_channel()
        payment_channel_id = payment_channel['id'] if payment_channel else None
        compartment_display = slot['slot_label'] if 'slot_label' in slot.keys() and slot['slot_label'] else (slot['display_number'] if slot['display_number'] else slot['slot_number'])
        # Mark slot as occupied immediately to prevent double allocation
        cursor.execute('UPDATE cabinet_slots SET status = 2 WHERE id = ?', (slot['id'],))
        cursor.execute('INSERT INTO orders (order_no, user_phone, slot_id, cabinet_id, compartment_number, access_code, deposit_amount, status, store_time, payment_channel_id) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)',
                       (order_no, user_phone, slot['id'], cabinet_id, compartment_display, access_code, deposit_amount, datetime.now(), payment_channel_id))
        order_id = cursor.lastrowid
        conn.commit()
        conn.close()
        openid = data.get('openid')
        pay_params = get_payment_params(order_id, order_no, deposit_amount, user_phone, openid, payment_channel=payment_channel, payment_channel_id=payment_channel_id)
        return json_response({'order_id': order_id, 'order_no': order_no, 'access_code': access_code,
                              'slot_id': slot['id'], 'cabinet_id': cabinet_id, 'compartment_number': compartment_display, 'compartment_label': slot['slot_label'] if 'slot_label' in slot.keys() and slot['slot_label'] else '',
                              'slot_size': slot['slot_size'], 'deposit_amount': deposit_amount, 'pay_params': pay_params})
    except Exception as e:
        logger.error(f'[create_deposit_order] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/store/pay', methods=['POST'])
def store_pay():
    """存包支付保证金"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if not order_id:
            return json_response(message='订单ID不能为空', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
        order = cursor.fetchone()
        if not order or order['status'] != 1:
            conn.close()
            return json_response(message='订单不存在或状态异常', code=404 if not order else 400)
        mock_mode = is_mock_mode()
        if mock_mode:
            transaction_id = 'MOCK' + datetime.now().strftime('%Y%m%d%H%M%S') + ''.join(random.choices(string.digits, k=6))
            cursor.execute('INSERT INTO payments (order_id, type, amount, transaction_id, status) VALUES (?, 1, ?, ?, 1)',
                           (order_id, order['deposit_amount'], transaction_id))
            cursor.execute('UPDATE orders SET status = 2, transaction_id = ?, pay_time = ? WHERE id = ?',
                           (transaction_id, datetime.now(), order_id))
            if order['slot_id']:
                cursor.execute('UPDATE cabinet_slots SET status = 2 WHERE id = ?', (order['slot_id'],))
            conn.commit()
            try:
                cursor2 = get_db().cursor()
                cursor2.execute('SELECT mainboard_device_id, mainboard_source FROM cabinets WHERE id = ?', (order['cabinet_id'],))
                cab_info = cursor2.fetchone()
                cursor2.connection.close()
                if cab_info and cab_info['mainboard_device_id']:
                    send_open_lock(str(cab_info['mainboard_device_id']), 1, order['compartment_number'] or 1, cab_info['mainboard_source'] or 'QM', order['order_no'])
            except Exception as e:
                logger.error(f'[Mock支付开锁失败] {e}')
            conn.close()
            return json_response({'order_id': order_id, 'order_no': order['order_no'], 'transaction_id': transaction_id, 'mode': 'mock', 'message': '支付成功，请取物存放'})
        else:
            from helpers import get_wxpay
            wxpay = get_wxpay()
            result = wxpay.order_query(out_trade_no=order['order_no'])
            if result.get('trade_state') == 'SUCCESS' or result.get('result_code') == 'SUCCESS':
                transaction_id = result.get('transaction_id')
                cursor.execute('INSERT INTO payments (order_id, type, amount, transaction_id, status) VALUES (?, 1, ?, ?, 1)',
                               (order_id, order['deposit_amount'], transaction_id))
                cursor.execute('UPDATE orders SET status = 2, transaction_id = ?, pay_time = ? WHERE id = ?',
                               (transaction_id, datetime.now(), order_id))
                if order['slot_id']:
                    cursor.execute('UPDATE cabinet_slots SET status = 2 WHERE id = ?', (order['slot_id'],))
                conn.commit()
                try:
                    cursor2 = get_db().cursor()
                    cursor2.execute('SELECT mainboard_device_id, mainboard_source FROM cabinets WHERE id = ?', (order['cabinet_id'],))
                    cab_info = cursor2.fetchone()
                    cursor2.connection.close()
                    if cab_info and cab_info['mainboard_device_id']:
                        send_open_lock(str(cab_info['mainboard_device_id']), 1, order['compartment_number'] or 1, cab_info['mainboard_source'] or 'QM', order['order_no'])
                except Exception as e:
                    logger.error(f'[WechatPay开锁失败] {e}')
                conn.close()
                return json_response({'order_id': order_id, 'order_no': order['order_no'], 'transaction_id': transaction_id, 'mode': 'wechat', 'message': '支付成功，请取物存放'})
            else:
                conn.close()
                return json_response(message='支付尚未完成', code=400)
    except Exception as e:
        logger.error(f'[store_pay] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/store/confirm', methods=['POST'])
def store_confirm():
    """存包确认"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if not order_id:
            return json_response(message='订单ID不能为空', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('UPDATE orders SET status = 2 WHERE id = ? AND status = 2', (order_id,))
        conn.commit()
        conn.close()
        return json_response(message='存包确认成功')
    except Exception as e:
        logger.error(f'[store_confirm] 错误: {e}')
        return json_response(message=str(e), code=500)


# ============================================
# H5存包
# ============================================

@bp.route('/h5/store', methods=['POST'])
def h5_store():
    """H5存包API"""
    try:
        data = request.get_json()
        phone = data.get('phone', '').strip()
        pwd = data.get('pwd', '').strip()
        device = data.get('device', '')
        if not phone or len(phone) < 11:
            return json_response(message='请输入正确的手机号', code=400)
        if not pwd or len(pwd) < 4:
            return json_response(message='请输入至少4位密码', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT id, mainboard_device_id, mainboard_source, deposit_amount, group_id, cabinet_code, name FROM cabinets WHERE mainboard_device_id = ?', (device,))
        cabinet = cursor.fetchone()
        if not cabinet:
            cursor.execute('SELECT id, mainboard_device_id, mainboard_source, deposit_amount, group_id, cabinet_code, name FROM cabinets WHERE cabinet_code = ?', (device,))
            cabinet = cursor.fetchone()
        if not cabinet:
            try:
                cursor.execute('SELECT id, mainboard_device_id, mainboard_source, deposit_amount, group_id, cabinet_code, name FROM cabinets WHERE id = ?', (int(device),))
                cabinet = cursor.fetchone()
            except (ValueError, TypeError):
                pass
        if not cabinet:
            conn.close()
            return json_response(message='设备不存在', code=404)
        # 检查设备是否在线
        from helpers import connected_devices
        dev_id = cabinet['mainboard_device_id'] or ''
        if not dev_id or dev_id not in connected_devices:
            conn.close()
            return json_response(message='设备未在线，暂时无法使用', code=503)
        cabinet_id = cabinet['id']
        cursor.execute('SELECT cs.*, MAX(o.store_time) as last_used_at FROM cabinet_slots cs LEFT JOIN orders o ON o.slot_id = cs.id WHERE cs.cabinet_id = ? AND cs.status = 1 GROUP BY cs.id ORDER BY CASE WHEN MAX(o.store_time) IS NULL THEN 0 ELSE 1 END, MAX(o.store_time) ASC, cs.slot_number ASC LIMIT 1', (cabinet_id,))
        slot = cursor.fetchone()
        if not slot:
            conn.close()
            return json_response(message='暂无可用柜格', code=303)
        cursor.execute('UPDATE cabinet_slots SET status = 2 WHERE id = ?', (slot['id'],))
        order_no = 'ORD' + datetime.now().strftime('%Y%m%d%H%M%S') + ''.join(random.choices(string.digits, k=4))
        deposit = cabinet['deposit_amount'] or 0
        cursor.execute('INSERT INTO orders (order_no, user_phone, slot_id, cabinet_id, compartment_number, access_code, deposit_amount, status, store_time, group_id, cabinet_code, cabinet_name, slot_size) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?)',
                       (order_no, phone, slot['id'], cabinet_id, slot['slot_number'], pwd, deposit, datetime.now(), cabinet['group_id'], cabinet['cabinet_code'], cabinet['name'], slot['slot_size']))
        order_id = cursor.lastrowid
        conn.commit()
        result = {'order_id': order_id, 'order_no': order_no, 'slot_number': str(slot['slot_number']), 'pwd': pwd, 'deposit': str(deposit), 'cabinet_id': cabinet_id, 'cabinet_device_id': cabinet['mainboard_device_id'], 'board_no': 1}
        openid = request.args.get('openid', '') or data.get('openid', '')
        try:
            pay_params = get_payment_params(order_id, order_no, deposit, phone, openid)
            result['pay_params'] = pay_params
            if pay_params.get('mode') == 'error':
                cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ?', (slot['id'],))
                cursor.execute('DELETE FROM orders WHERE id = ?', (order_id,))
                conn.commit()
                logger.info(f'[h5_store] pay failed, released slot, deleted order {order_id}')
        except Exception as e:
            cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ?', (slot['id'],))
            cursor.execute('DELETE FROM orders WHERE id = ?', (order_id,))
            conn.commit()
            logger.error(f'[h5_store get_payment_params] {e}, released slot')
        conn.close()
        return json_response(data=result)
    except Exception as e:
        logger.error(f'[h5_store] 错误: {e}')
        return json_response(message=str(e), code=500)


# ============================================
# 押金取物/续存/结束
# ============================================

@bp.route('/deposit/retrieve', methods=['POST'])
def deposit_retrieve():
    """取物验证"""
    try:
        data = request.get_json()
        cabinet_code = data.get('cabinet_code')
        group_code = data.get('group_code')
        phone = data.get('phone')
        access_code = data.get('access_code')
        if not all([phone, access_code]):
            return json_response(message='参数不完整', code=400)
        if len(access_code) != 4 or not access_code.isdigit():
            return json_response(message='取物码必须为4位数字', code=400)
        if not phone or len(phone) != 11 or not phone.startswith('1'):
            return json_response(message='请输入正确的手机号', code=400)
        conn = get_db()
        cursor = conn.cursor()
        if group_code:
            cursor.execute('SELECT id FROM cabinet_groups WHERE group_code = ?', (group_code,))
            group = cursor.fetchone()
            if not group:
                conn.close()
                return json_response(message='柜组不存在', code=404)
            cursor.execute('SELECT o.*, cs.slot_number, COALESCE(cs.slot_size, o.slot_size) as slot_size, c.cabinet_code, c.name as cabinet_name, cs.board_no, cs.lock_no, c.mainboard_device_id FROM orders o JOIN cabinet_slots cs ON o.slot_id = cs.id JOIN cabinets c ON o.cabinet_id = c.id WHERE c.group_id = ? AND o.user_phone = ? AND o.access_code = ? AND o.status = 2 ORDER BY o.id DESC LIMIT 1',
                           (group['id'], phone, access_code))
        else:
            if not cabinet_code:
                conn.close()
                return json_response(message='柜体或柜组编号不能为空', code=400)
            cursor.execute('SELECT id FROM cabinets WHERE cabinet_code = ?', (cabinet_code,))
            cabinet = cursor.fetchone()
            if not cabinet:
                conn.close()
                return json_response(message='柜体不存在', code=404)
            cursor.execute('SELECT o.*, cs.slot_number, COALESCE(cs.slot_size, o.slot_size) as slot_size, cs.board_no, cs.lock_no, c.mainboard_device_id FROM orders o JOIN cabinet_slots cs ON o.slot_id = cs.id JOIN cabinets c ON o.cabinet_id = c.id WHERE o.cabinet_id = ? AND o.user_phone = ? AND o.access_code = ? AND o.status = 2 ORDER BY o.id DESC LIMIT 1',
                           (cabinet['id'], phone, access_code))
        order = cursor.fetchone()
        if not order:
            conn.close()
            return json_response(message='手机号或取物码错误', code=400)
        order_dict = dict(order)
        conn.close()
        # ??????
        try:
            device_id = order_dict.get('mainboard_device_id')
            board_no = order_dict.get('board_no') or ''
            lock_no = order_dict.get('lock_no') or ''
            if device_id and board_no and lock_no:
                send_open_lock(device_id, board_no, lock_no, order_id=str(order_dict['id']))
                logger.info(f'[????] ???????: device={device_id}, board={board_no}, lock={lock_no}, order_id=' + str(order_dict['id']))
            else:
                logger.warning(f'[????] ??????, device={device_id}, board={board_no}, lock={lock_no}')
        except Exception as open_err:
            logger.error(f'[????] ????: ' + str(open_err))
        logger.info(f"[????] ??: order_id={order_dict['id']}")
        return json_response({'order_id': order_dict['id'], 'order_no': order_dict['order_no'],
                              'cabinet_id': order_dict['cabinet_id'], 'cabinet_code': order_dict.get('cabinet_code', cabinet_code),
                              'slot_id': order['slot_id'], 'compartment_number': order['slot_number'],
                              'slot_size': order['slot_size'], 'deposit_amount': order['deposit_amount'],
                              'store_time': order['store_time'], 'group_code': group_code})
    except Exception as e:
        logger.error(f'[deposit_retrieve] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/deposit/continue-storage', methods=['POST'])
def deposit_continue_storage():
    """继续存放"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if not order_id:
            return json_response(message='订单ID不能为空', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
        order = cursor.fetchone()
        if not order or order['status'] != 2:
            conn.close()
            return json_response(message='订单不存在或状态异常', code=404 if not order else 400)
        cursor.execute('INSERT INTO storage_records (cabinet_id, compartment_number, user_phone, access_code, status, store_time, retrieve_time) VALUES (?, ?, ?, ?, 2, ?, ?)',
                       (order['cabinet_id'], order['compartment_number'], order['user_phone'], order['access_code'], order['store_time'], datetime.now()))
        if order['slot_id']:
            cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ?', (order['slot_id'],))
        conn.commit()
        conn.close()
        return json_response({'message': '继续存放成功', 'order_id': order_id, 'deposit_amount': order['deposit_amount']})
    except Exception as e:
        logger.error(f'[continue_storage] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/deposit/end-storage', methods=['POST'])
def deposit_end_storage():
    """结束取物"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if not order_id:
            return json_response(message='订单ID不能为空', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT o.*, cs.slot_number, cs.board_no, cs.lock_no, c.cabinet_code, c.mainboard_device_id FROM orders o JOIN cabinet_slots cs ON o.slot_id = cs.id JOIN cabinets c ON o.cabinet_id = c.id WHERE o.id = ?', (order_id,))
        order = cursor.fetchone()
        if not order or order['status'] != 2:
            conn.close()
            return json_response(message='订单不存在或状态异常', code=404 if not order else 400)
        refund_amount = order['deposit_amount']
        compartment_number = order['slot_number'] or order['compartment_number']
        cursor.execute('INSERT INTO storage_records (cabinet_id, compartment_number, user_phone, access_code, status, store_time, retrieve_time) VALUES (?, ?, ?, ?, 1, ?, ?)',
                       (order['cabinet_id'], order['compartment_number'], order['user_phone'], order['access_code'], order['store_time'], datetime.now()))
        # 根据网点退款模式处理
        cursor.execute('SELECT l.withdraw_mode, l.show_refunding_status FROM cabinets c JOIN locations l ON c.location_id = l.id WHERE c.id = ?', (order['cabinet_id'],))
        loc_row = cursor.fetchone()
        withdraw_mode = loc_row['withdraw_mode'] if loc_row else 'auto_approve'
        if order['slot_id']:
            cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ?', (order['slot_id'],))
        # 工业屏结束订单：始终立即退款，不受审批模式影响
        from helpers import do_real_refund
        refund_success, refund_id, refund_msg = do_real_refund(order_id=order_id, amount=refund_amount)
        if refund_success:
            new_status = 4
            cursor.execute('UPDATE orders SET status = ?, refund_id = ?, refund_time = ? WHERE id = ?', (new_status, refund_id, datetime.now(), order_id))
            if refund_amount > 0:
                cursor.execute('INSERT INTO payments (order_id, type, amount, refund_transaction_id, status) VALUES (?, 2, ?, ?, 1)', (order_id, refund_amount, refund_id))
            cursor.execute('INSERT INTO withdrawal_records (order_id, user_phone, amount, status, approver, auto_approve_time) VALUES (?, ?, ?, 2, "system", ?)',
                           (order_id, order['user_phone'], refund_amount, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        else:
            new_status = 6
            cursor.execute('UPDATE orders SET status = ? WHERE id = ?', (new_status, order_id))
            if refund_amount > 0:
                cursor.execute('INSERT INTO payments (order_id, type, amount, refund_transaction_id, status) VALUES (?, 2, ?, ?, 0)', (order_id, refund_amount, ''))
            cursor.execute('INSERT INTO withdrawal_records (order_id, user_phone, amount, status, auto_approve_time) VALUES (?, ?, ?, 1, ?)',
                           (order_id, order['user_phone'], refund_amount, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        conn.commit()
        conn.close()
        # Send open_lock via WebSocket
        try:
            from helpers import pending_lock_commands
            device_id = order['mainboard_device_id']
            open_cmd = {'type': 'open_lock', 'board_no': order['board_no'] or '', 'boardNo': order['board_no'] or '', 'lock_no': order['lock_no'] or '', 'lockNo': order['lock_no'] or '', 'order_id': str(order_id), 'orderId': str(order_id), 'reason': 'end_storage'}
            if device_id not in pending_lock_commands:
                pending_lock_commands[device_id] = []
            pending_lock_commands[device_id].append(open_cmd)
            logger.info(f'[end_storage] open_lock queued: device={device_id}, board={order["board_no"]}, lock={order["lock_no"]}')
        except Exception as we:
            logger.error(f'[end_storage] WebSocket发送失败: {we}')
        if new_status == 4:
            return json_response({'message': '取物完成，保证金已退还', 'order_id': order_id, 'refund_amount': refund_amount, 'refund_id': refund_id, 'compartment_number': compartment_number})
        else:
            return json_response({'message': '取物完成，退款异常，请联系客服', 'order_id': order_id, 'refund_amount': 0, 'compartment_number': compartment_number})
    except Exception as e:
        logger.error(f'[end_storage] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/deposit/open-slot', methods=['POST'])
def deposit_open_slot():
    """开锁指令"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if not order_id:
            return json_response(message='订单ID不能为空', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
        order = cursor.fetchone()
        if not order:
            conn.close()
            return json_response(message='订单不存在', code=404)
        cursor.execute('SELECT cs.*, c.cabinet_code FROM cabinet_slots cs JOIN cabinets c ON cs.cabinet_id = c.id WHERE cs.id = ?', (order['slot_id'],))
        slot = cursor.fetchone()
        conn.close()
        if not slot:
            return json_response(message='柜格不存在', code=404)
        return json_response({'message': '开锁指令已发送', 'cabinet_code': slot['cabinet_code'], 'slot_number': slot['slot_number']})
    except Exception as e:
        logger.error(f'[deposit_open_slot] 错误: {e}')
        return json_response(message=str(e), code=500)



@bp.route('/deposit/mid-retrieve', methods=['POST'])
def deposit_mid_retrieve():
    """中途取物开锁"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if not order_id:
            return json_response(message='订单ID不能为空', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT o.*, cs.slot_number, COALESCE(cs.slot_size, o.slot_size) as slot_size, cs.board_no, cs.lock_no, c.cabinet_code, c.mainboard_device_id FROM orders o JOIN cabinet_slots cs ON o.slot_id = cs.id JOIN cabinets c ON o.cabinet_id = c.id WHERE o.id = ?', (order_id,))
        order = cursor.fetchone()
        if not order:
            conn.close()
            return json_response(message='订单不存在', code=404)
        if order['status'] != 2:
            conn.close()
            return json_response(message='订单状态不允许中途取物', code=400)
        # Record mid-retrieve
        cursor.execute('INSERT INTO storage_records (cabinet_id, compartment_number, user_phone, access_code, status, store_time, retrieve_time) VALUES (?, ?, ?, ?, 2, ?, ?)',
                       (order['cabinet_id'], order['compartment_number'], order['user_phone'], order['access_code'], order['store_time'], datetime.now()))
        conn.commit()
        conn.close()
        # Send open_lock via WebSocket
        try:
            from helpers import pending_lock_commands
            device_id = order['mainboard_device_id']
            open_cmd = {'type': 'open_lock', 'board_no': order['board_no'] or '', 'boardNo': order['board_no'] or '', 'lock_no': order['lock_no'] or '', 'lockNo': order['lock_no'] or '', 'order_id': str(order_id), 'orderId': str(order_id), 'reason': 'mid_retrieve'}
            if device_id not in pending_lock_commands:
                pending_lock_commands[device_id] = []
            pending_lock_commands[device_id].append(open_cmd)
            logger.info(f'[中途取物] open_lock queued: device={device_id}, board={order["board_no"]}, lock={order["lock_no"]}')
        except Exception as we:
            logger.error(f'[中途取物] WebSocket发送失败: {we}')
        logger.info(f'[中途取物] order_id={order_id}, compartment={order["slot_number"]}')
        return json_response({'message': '柜门已打开', 'order_id': order_id, 'compartment_number': order['slot_number'], 'cabinet_code': order['cabinet_code']})
    except Exception as e:
        logger.error(f'[mid_retrieve] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/order/<int:order_id>', methods=['GET'])
def get_user_order_detail(order_id):
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT o.*, c.cabinet_code, c.name, c.location_id, l.name as location_name, l.withdraw_enabled, cs.slot_number, cs.slot_size as slot_size_name FROM orders o LEFT JOIN cabinets c ON o.cabinet_id = c.id LEFT JOIN locations l ON c.location_id = l.id LEFT JOIN cabinet_slots cs ON o.slot_id = cs.id WHERE o.id = ?', (order_id,))
        order = cursor.fetchone()
        if not order:
            conn.close()
            return json_response(message='订单不存在', code=404)
        cursor.execute('SELECT status FROM withdrawal_records WHERE order_id = ? ORDER BY id DESC LIMIT 1', (order_id,))
        wr = cursor.fetchone()
        conn.close()
        d = dict(order)
        status_map = {1: 'storing', 2: 'storing', 3: 'retrieved', 4: 'retrieved', 5: 'timeout', 6: 'retrieved'}
        status_str = status_map.get(d.get('status', 1), 'storing')
        wd_status = None
        if wr:
            wd_map = {0: 'pending', 1: 'pending', 2: 'approved', 3: 'failed'}
            wd_status = wd_map.get(wr['status'])
        result = {'order_id': d['id'], 'order_no': d.get('order_no', ''), 'cabinet_name': d.get('cabinet_name') or d.get('cabinet_code', '寄存柜'), 'cabinet_id': d.get('cabinet_id'), 'location': d.get('location_name', ''), 'slot_id': d.get('slot_id'), 'slot_no': d.get('slot_number') or d.get('slot_id'), 'slot_size': d.get('slot_size_name') or d.get('slot_size', 0), 'deposit_time': d.get('store_time', ''), 'retrieve_time': d.get('retrieve_time', ''), 'end_time': d.get('retrieve_time', ''), 'status': status_str, 'phone': d.get('user_phone', ''), 'access_code': d.get('access_code', ''), 'deposit': d.get('deposit_amount', 10) or 10, 'fee': 0, 'refund_amount': d.get('refund_amount', 0) or 0, 'withdraw_enabled': bool(d.get('withdraw_enabled', 0)), 'withdraw_status': wd_status}
        return json_response(data=result)
    except Exception as e:
        logger.error('[order_detail] error: ' + str(e))
        return json_response(message=str(e), code=500)

@bp.route('/order/reopen', methods=['POST'])
def order_reopen():
    """重新开锁 - 不管订单状态都能开"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if not order_id:
            return json_response(message='订单ID不能为空', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT o.*, cs.slot_number, COALESCE(cs.slot_size, o.slot_size) as slot_size, cs.board_no, cs.lock_no, c.cabinet_code, c.mainboard_device_id FROM orders o JOIN cabinet_slots cs ON o.slot_id = cs.id JOIN cabinets c ON o.cabinet_id = c.id WHERE o.id = ?', (order_id,))
        order = cursor.fetchone()
        if not order:
            conn.close()
            return json_response(message='订单不存在', code=404)
        compartment = order['slot_number']
        conn.close()
        # Send open_lock via WebSocket
        try:
            from helpers import pending_lock_commands
            device_id = order['mainboard_device_id']
            open_cmd = {'type': 'open_lock', 'board_no': order['board_no'] or '', 'boardNo': order['board_no'] or '', 'lock_no': order['lock_no'] or '', 'lockNo': order['lock_no'] or '', 'order_id': str(order_id), 'orderId': str(order_id), 'reason': 'reopen'}
            if device_id not in pending_lock_commands:
                pending_lock_commands[device_id] = []
            pending_lock_commands[device_id].append(open_cmd)
            logger.info(f'[重新开锁] open_lock queued: device={device_id}, board={order["board_no"]}, lock={order["lock_no"]}')
        except Exception as we:
            logger.error(f'[重新开锁] WebSocket发送失败: {we}')
        logger.info(f'[重新开锁] order_id={order_id}, compartment={compartment}')
        return json_response({'message': '开门指令已发送', 'order_id': order_id, 'compartment_number': compartment, 'cabinet_code': order['cabinet_code']})
    except Exception as e:
        logger.error(f'[order_reopen] 错误: {e}')
        return json_response(message=str(e), code=500)

# ============================================
# 短信验证码
# ============================================

@bp.route('/sms/send', methods=['POST'])
def sms_send():
    """发送短信验证码"""
    try:
        data = request.get_json()
        phone = data.get('phone')
        if not phone:
            return json_response(message='手机号不能为空', code=400)
        if get_setting('sms_enabled', 'false').lower() != 'true':
            return json_response(message='短信验证未开启')
        code = generate_sms_code()
        expires_at = datetime.now() + timedelta(minutes=5)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM sms_codes WHERE phone = ?', (phone,))
        cursor.execute('INSERT INTO sms_codes (phone, code, expires_at) VALUES (?, ?, ?)', (phone, code, expires_at))
        conn.commit()
        conn.close()
        logger.info(f'[短信模拟] 发送给 {phone} 的验证码: {code}')
        return json_response(message='验证码已发送', data={'expires_in': 300})
    except Exception as e:
        logger.error(f'[sms_send] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/sms/verify', methods=['POST'])
def sms_verify():
    """验证短信验证码"""
    try:
        data = request.get_json()
        phone = data.get('phone')
        code = data.get('code')
        if not all([phone, code]):
            return json_response(message='参数不完整', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM sms_codes WHERE phone = ? AND code = ? AND expires_at > ? ORDER BY id DESC LIMIT 1', (phone, code, datetime.now()))
        record = cursor.fetchone()
        if not record:
            conn.close()
            return json_response(message='验证码错误或已过期', code=400)
        cursor.execute('DELETE FROM sms_codes WHERE id = ?', (record['id'],))
        conn.commit()
        conn.close()
        return json_response(message='验证成功')
    except Exception as e:
        logger.error(f'[sms_verify] 错误: {e}')
        return json_response(message=str(e), code=500)


# ============================================
# 通用接口
# ============================================

@bp.route('/cabinet/<int:cabinet_id>/status', methods=['GET'])
def cabinet_status(cabinet_id):
    """柜体状态"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM cabinets WHERE id = ?', (cabinet_id,))
        cabinet = cursor.fetchone()
        if not cabinet:
            conn.close()
            return json_response(message='柜体不存在', code=404)
        cursor.execute('SELECT * FROM cabinet_slots WHERE cabinet_id = ?', (cabinet_id,))
        slots = cursor.fetchall()
        conn.close()
        return json_response({
            'cabinet_id': cabinet_id, 'deposit_amount': cabinet['deposit_amount'] or 20,
            'total': len(slots), 'available': len([s for s in slots if s['status'] == 1]),
            'occupied': len([s for s in slots if s['status'] == 2]),
            'fault': len([s for s in slots if s['status'] == 3]),
            'locked': len([s for s in slots if s['status'] == 4]),
            'slots': [{'id': s['id'], 'number': s['display_number'] if s['display_number'] else s['slot_number'], 'size': s['slot_size'], 'status': s['status']} for s in slots]
        })
    except Exception as e:
        logger.error(f'[cabinet_status] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/qrcode', methods=['GET'])
def generate_qrcode():
    """生成二维码"""
    try:
        url = request.args.get('url', '')
        if not url:
            return json_response(message='缺少url参数', code=400)
        qr = qrcode.QRCode(version=1, box_size=10, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)
        img_b64 = base64.b64encode(buffer.getvalue()).decode()
        return json_response({'qrcode': f"data:image/png;base64,{img_b64}", 'url': url})
    except Exception as e:
        logger.error(f'[qrcode] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/cabinet/<int:cabinet_id>/qrcode', methods=['GET'])
def cabinet_qrcode(cabinet_id):
    """生成柜体二维码"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT cabinet_code FROM cabinets WHERE id = ?', (cabinet_id,))
        cabinet = cursor.fetchone()
        conn.close()
        if not cabinet:
            return json_response(message='柜体不存在', code=404)
        qr_data = f"locker://open?code={cabinet['cabinet_code']}"
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(qr_data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        buffer.seek(0)
        img_b64 = base64.b64encode(buffer.getvalue()).decode()
        return json_response({'qrcode': f"data:image/png;base64,{img_b64}", 'cabinet_code': cabinet['cabinet_code']})
    except Exception as e:
        logger.error(f'[cabinet_qrcode] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/order/<int:order_id>/pay-status', methods=['GET'])
def get_pay_status(order_id):
    """查询订单支付状态"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
        order = cursor.fetchone()
        conn.close()
        if not order:
            return json_response(message='订单不存在', code=404)
        status_map = {1: '待支付', 2: '使用中', 3: '已结算', 4: '已退款', 5: '已取消', 6: '退款异常'}
        # 主动查询微信支付状态兜底（如果本地状态是待支付，去微信确认）
        if order['status'] == 1 and order['payment_channel_id']:
            try:
                ch_row2 = None
                conn2 = get_db()
                cur2 = conn2.cursor()
                cur2.execute('SELECT * FROM payment_channels WHERE id = ?', (order['payment_channel_id'],))
                ch_row2 = cur2.fetchone()
                conn2.close()
                if ch_row2:
                    from helpers import get_channel_wxpay as _gchw
                    wxpay_inst2, ch_type2 = _gchw(dict(ch_row2))
                    if wxpay_inst2 and ch_type2 == 'wechat':
                        qr = wxpay_inst2.order_query(out_trade_no=order['order_no'])
                        if qr.get('trade_state') == 'SUCCESS':
                            # 微信已支付但回调丢失，手动更新
                            cur3 = conn.cursor() if False else None
                            conn3 = get_db()
                            cur3 = conn3.cursor()
                            txn_id = qr.get('transaction_id', '')
                            cur3.execute('UPDATE orders SET status = 2, transaction_id = ?, pay_time = ? WHERE id = ?',
                                         (txn_id, datetime.now(), order['id']))
                            if order['slot_id']:
                                cur3.execute('UPDATE cabinet_slots SET status = 2 WHERE id = ?', (order['slot_id'],))
                            try:
                                cur3.execute('SELECT id FROM user_balances WHERE phone = ?', (order['user_phone'],))
                                ub = cur3.fetchone()
                                if ub:
                                    cur3.execute('UPDATE user_balances SET balance = balance + ?, total_deposited = total_deposited + ? WHERE phone = ?',
                                                 (order['deposit_amount'], order['deposit_amount'], order['user_phone']))
                                else:
                                    cur3.execute('INSERT INTO user_balances (phone, balance, total_deposited, first_use_time) VALUES (?, ?, ?, ?)',
                                                 (order['user_phone'], order['deposit_amount'], order['deposit_amount'], datetime.now()))
                            except: pass
                            cur3.execute('INSERT INTO payments (order_id, type, amount, transaction_id, status) VALUES (?, 1, ?, ?, 1)',
                                         (order['id'], order['deposit_amount'], txn_id))
                            conn3.commit()
                            conn3.close()
                            order = {'id': order['id'], 'order_no': order['order_no'], 'status': 2,
                                     'transaction_id': txn_id, 'pay_time': datetime.now(),
                                     'refund_id': order['refund_id'], 'refund_time': order['refund_time']}
                            logger.info(f'[pay-status] 主动查询发现订单{order["id"]}已支付，已更新')
            except Exception as e2:
                logger.error(f'[pay-status] 主动查询微信失败: {e2}')
        return json_response({'order_id': order['id'], 'order_no': order['order_no'], 'status': order['status'],
                              'status_text': status_map.get(order['status'], '未知'), 'transaction_id': order['transaction_id'],
                              'pay_time': order['pay_time'], 'refund_id': order['refund_id'], 'refund_time': order['refund_time']})
    except Exception as e:
        logger.error(f'[get_pay_status] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/cabinet/screen-info', methods=['GET'])
def cabinet_screen_info():
    """柜体屏幕显示信息"""
    try:
        cabinet_code = request.args.get('cabinet_code')
        group_code = request.args.get('group_code')
        if not cabinet_code and not group_code:
            return json_response(message='柜组编号不能为空', code=400)
        conn = get_db()
        cursor = conn.cursor()
        if group_code:
            cursor.execute('SELECT cg.*, l.name as location_name, l.address as location_address, m.name as merchant_name FROM cabinet_groups cg LEFT JOIN locations l ON cg.location_id = l.id LEFT JOIN merchants m ON l.merchant_id = m.id WHERE cg.group_code = ?', (group_code,))
            group = cursor.fetchone()
            if not group:
                conn.close()
                return json_response(message='柜组不存在', code=404)
            cursor.execute('SELECT COUNT(cs.id) as total_slots, SUM(CASE WHEN cs.status = 1 THEN 1 ELSE 0 END) as available_slots, SUM(CASE WHEN cs.status = 2 THEN 1 ELSE 0 END) as occupied_slots FROM cabinets c JOIN cabinet_slots cs ON c.id = cs.cabinet_id WHERE c.group_id = ?', (group['id'],))
            slot_stats = cursor.fetchone()
            system_name = get_setting('system_name', '智能寄存柜')
            conn.close()
            return json_response({'group_id': group['id'], 'group_code': group['group_code'], 'group_name': group['name'],
                                  'location_name': group['location_name'] or '未知网点', 'location_address': group['location_address'],
                                  'system_name': system_name, 'total_slots': slot_stats['total_slots'] or 0,
                                  'available_slots': slot_stats['available_slots'] or 0, 'occupied_slots': slot_stats['occupied_slots'] or 0,
                                  'deposit_amount': float(get_setting('deposit_amount', '20'))})
        cursor.execute('SELECT c.id as cabinet_id, c.cabinet_code, c.name as cabinet_name, c.total_slots, l.name as location_name, l.address as location_address FROM cabinets c LEFT JOIN locations l ON c.location_id = l.id WHERE c.cabinet_code = ?', (cabinet_code,))
        cabinet = cursor.fetchone()
        if not cabinet:
            conn.close()
            return json_response(message='柜体不存在', code=404)
        cursor.execute('SELECT COUNT(*) as available FROM cabinet_slots WHERE cabinet_id = ? AND status = 1', (cabinet['cabinet_id'],))
        available_count = cursor.fetchone()['available']
        conn.close()
        return json_response({'cabinet_id': cabinet['cabinet_id'], 'cabinet_code': cabinet['cabinet_code'], 'cabinet_name': cabinet['cabinet_name'],
                              'location_name': cabinet['location_name'], 'location_address': cabinet['location_address'],
                              'total_slots': cabinet['total_slots'], 'available_slots': available_count,
                              'deposit_amount': float(get_setting('deposit_amount', '20'))})
    except Exception as e:
        logger.error(f'[cabinet_screen_info] 错误: {e}')
        return json_response(message=str(e), code=500)


# ============================================
# 投诉
# ============================================

@bp.route('/complaints', methods=['POST'])
def create_complaint():
    """用户提交投诉"""
    try:
        data = request.get_json()
        user_phone = data.get('phone')
        complaint_type = data.get('type', 'self')
        content = data.get('content')
        order_no = data.get('order_no')
        wx_complaint_id = data.get('wx_complaint_id')
        if not all([user_phone, content]):
            return json_response(message='参数不完整', code=400)
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO complaints (user_phone, type, content, order_no, wx_complaint_id, complaint_type) VALUES (?, ?, ?, ?, ?, ?)',
                       (user_phone, complaint_type, content, order_no, wx_complaint_id, complaint_type))
        complaint_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return json_response({'complaint_id': complaint_id, 'message': '投诉已提交，我们会尽快处理'})
    except Exception as e:
        logger.error(f'[create_complaint] 错误: {e}')
        return json_response(message=str(e), code=500)
# ============================================
# 设备串口配置（APK查询用）
# ============================================

@bp.route('/cabinet/serial-config', methods=['GET'])
def cabinet_serial_config():
    """APK查询串口配置：根据mainboard_device_id返回对应的串口和波特率"""
    try:
        device_id = request.args.get('device_id')
        if not device_id:
            return json_response(message='device_id不能为空', code=400)

        conn = get_db()
        cursor = conn.cursor()
        # 找到该设备对应的柜体，再查该柜体的主板配置
        cursor.execute('''
            SELECT m.serial_port, m.baud_rate, c.cabinet_code, c.mainboard_source
            FROM cabinets c
            JOIN mainboards m ON c.id = m.cabinet_id
            WHERE c.mainboard_device_id = ?
            ORDER BY m.board_index ASC
            LIMIT 1
        ''', (device_id,))
        row = cursor.fetchone()
        conn.close()

        if not row:
            # 设备存在但无主板配置时回默认值
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute('SELECT cabinet_code, mainboard_source FROM cabinets WHERE mainboard_device_id = ?', (device_id,))
            cab = cursor.fetchone()
            conn.close()
            if cab:
                brand = cab['mainboard_source'] or 'QM'
                from config import BRAND_DEFAULTS
                defaults = BRAND_DEFAULTS.get(brand, {'serial_port': 'ttyS2', 'baud_rate': 9600})
                return json_response({
                    'device_id': device_id,
                    'cabinet_code': cab['cabinet_code'],
                    'serial_port': defaults['serial_port'],
                    'baud_rate': defaults['baud_rate'],
                    'source': 'brand_default'
                })
            return json_response(message='设备未注册', code=404)

        return json_response({
            'device_id': device_id,
            'cabinet_code': row['cabinet_code'],
            'serial_port': row['serial_port'],
            'baud_rate': row['baud_rate'],
            'source': 'manual'
        })
    except Exception as e:
        logger.error(f'[cabinet_serial_config] 错误: {e}')
        return json_response(message=str(e), code=500)
# ============================================
# 微信小程序登录 - jscode2session
# ============================================

@bp.route('/wx/login', methods=['POST'])
def wx_login():
    """微信小程序登录 - 用code换openid"""
    try:
        data = request.get_json()
        code = data.get('code')
        if not code:
            return json_response(message='code不能为空', code=400)
        import requests
        import config
        appid = config.WX_MP_APP_ID
        secret = config.WX_MP_APP_SECRET
        url = f'https://api.weixin.qq.com/sns/jscode2session?appid={appid}&secret={secret}&js_code={code}&grant_type=authorization_code'
        resp = requests.get(url, timeout=10)
        result = resp.json()
        if 'openid' in result:
            return json_response({'openid': result['openid'], 'session_key': result.get('session_key', '')})
        else:
            logger.error(f'[wx_login] 微信接口返回异常: {result}')
            return json_response(message='登录失败，请稍后重试', code=400)
    except Exception as e:
        logger.error(f'[wx_login] 错误: {e}')
        return json_response(message=str(e), code=500)

@bp.route('/wx/login-phone', methods=['POST'])
def wx_login_phone():
    """一步到位：code换session_key + 解密手机号"""
    try:
        data = request.get_json()
        code = data.get('code')
        encrypted_data = data.get('encrypted_data')
        iv = data.get('iv')
        if not code or not encrypted_data or not iv:
            return json_response(message='参数不完整', code=400)
        import requests as _req
        import config
        appid = config.WX_MP_APP_ID
        secret = config.WX_MP_APP_SECRET
        url = f'https://api.weixin.qq.com/sns/jscode2session?appid={appid}&secret={secret}&js_code={code}&grant_type=authorization_code'
        resp = _req.get(url, timeout=10)
        result = resp.json()
        if 'openid' not in result:
            logger.error(f'[wx_login_phone] 微信接口异常: {result}')
            return json_response(message='微信登录失败', code=400)
        openid = result['openid']
        session_key = result.get('session_key', '')
        if not session_key:
            return json_response(message='session_key获取失败', code=400)
        import base64
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.backends import default_backend
        try:
            session_key_bytes = base64.b64decode(session_key)
            encrypted_bytes = base64.b64decode(encrypted_data)
            iv_bytes = base64.b64decode(iv)
            cipher = Cipher(algorithms.AES(session_key_bytes), modes.CBC(iv_bytes), backend=default_backend())
            decryptor = cipher.decryptor()
            decrypted = decryptor.update(encrypted_bytes) + decryptor.finalize()
            pad_len = decrypted[-1]
            if pad_len > 0 and pad_len <= 16:
                decrypted = decrypted[:-pad_len]
            import json as _json
            phone_info = _json.loads(decrypted.decode('utf-8'))
            phone_number = phone_info.get('phoneNumber', '')
            if phone_number:
                logger.info(f'[wx_login_phone] 成功: {phone_number[:3]}****{phone_number[-4:]}')
                return json_response({'openid': openid, 'phone': phone_number, 'session_key': session_key})
            else:
                logger.error(f'[wx_login_phone] 解密无手机号: {phone_info}')
                return json_response(message='解密手机号失败', code=400)
        except Exception as de:
            logger.error(f'[wx_login_phone] 解密异常: {de}')
            return json_response(message='手机号解密失败', code=400)
    except Exception as e:
        logger.error(f'[wx_login_phone] 错误: {e}')
        return json_response(message=str(e), code=500)


@bp.route('/wx/phone', methods=['POST'])
def wx_decrypt_phone():
    """微信小程序手机号解密"""
    try:
        data = request.get_json()
        encrypted_data = data.get('encrypted_data')
        iv = data.get('iv')
        if not encrypted_data or not iv:
            return json_response(message='参数不完整', code=400)
        
        # 从请求头或参数获取session_key（前端先wx.login拿到后缓存的）
        session_key = data.get('session_key')
        if not session_key:
            return json_response(message='session_key缺失，请重新登录', code=400)
        
        import base64
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.backends import default_backend
        
        try:
            session_key_bytes = base64.b64decode(session_key)
            encrypted_bytes = base64.b64decode(encrypted_data)
            iv_bytes = base64.b64decode(iv)
            
            cipher = Cipher(algorithms.AES(session_key_bytes), modes.CBC(iv_bytes), backend=default_backend())
            decryptor = cipher.decryptor()
            decrypted = decryptor.update(encrypted_bytes) + decryptor.finalize()
            
            # 去除PKCS7填充
            pad_len = decrypted[-1]
            if pad_len > 0 and pad_len <= 16:
                decrypted = decrypted[:-pad_len]
            
            import json as _json
            phone_info = _json.loads(decrypted.decode('utf-8'))
            phone_number = phone_info.get('phoneNumber', '')
            
            if phone_number:
                logger.info(f'[wx_decrypt_phone] 获取手机号成功: {phone_number[:3]}****{phone_number[-4:]}')
                return json_response({'phone': phone_number})
            else:
                logger.error(f'[wx_decrypt_phone] 解密结果无手机号: {phone_info}')
                return json_response(message='获取手机号失败', code=400)
        except Exception as de:
            logger.error(f'[wx_decrypt_phone] 解密错误: {de}')
            return json_response(message='手机号解密失败', code=400)
    except Exception as e:
        logger.error(f'[wx_decrypt_phone] 错误: {e}')
        return json_response(message=str(e), code=500)


# ============================================
# 用户订单和余额API - H5个人中心用
# ============================================

@bp.route('/user/orders', methods=['GET'])
def get_user_orders():
    """获取用户订单列表"""
    try:
        phone = request.args.get('phone')
        if not phone:
            return json_response(message='手机号不能为空', code=400)
        
        conn = get_db()
        cur = conn.cursor()
        cur.execute('''
            SELECT id, order_no, user_phone, cabinet_id, compartment_number, slot_size,
                   deposit_amount, status, store_time, retrieve_time, created_at
            FROM orders
            WHERE user_phone = ?
            ORDER BY created_at DESC
            LIMIT 50
        ''', (phone,))
        orders = [dict(row) for row in cur.fetchall()]
        conn.close()
        
        return json_response(data=orders)
    except Exception as e:
        logger.error(f'[user/orders] 错误: {e}')
        return json_response(message=str(e), code=500)

@bp.route('/user/withdrawal-rules', methods=['GET'])
def get_withdrawal_rules():
    """获取提现规则"""
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT withdraw_enabled, withdraw_mode, click_free_count, auto_approve_time, auto_approve_day FROM locations WHERE withdraw_enabled = 1 LIMIT 1")
        row = cur.fetchone()
        conn.close()
        rules = {
            'withdraw_enabled': row['withdraw_enabled'] if row else 1,
            'withdraw_mode': row['withdraw_mode'] if row else 'manual_approve',
            'daily_limit': row['click_free_count'] if row else 3,
            'withdraw_time': '00:00-23:59',
            'arrival_time': '0-3个工作日内',
        }
        return json_response(data=rules)
    except Exception as e:
        return json_response(data={
            'withdraw_enabled': 1, 'daily_limit': 3,
            'withdraw_time': '00:00-23:59', 'arrival_time': '0-3个工作日内',
            'withdraw_mode': 'manual_approve'
        })

@bp.route('/user/balance', methods=['GET'])
def get_user_balance():
    """获取用户钱包余额"""
    try:
        phone = request.args.get('phone')
        if not phone:
            return json_response(message='手机号不能为空', code=400)
        
        conn = get_db()
        cur = conn.cursor()
        # 获取用户余额信息
        cur.execute("""
            SELECT phone, balance, total_deposited, total_withdrawn, first_use_time, created_at
            FROM user_balances
            WHERE phone = ?
        """, (phone,))
        row = cur.fetchone()
        
        # 检查是否有待处理的提现申请（status=0待审核 或 status=1退款中）
        has_pending_withdrawal = False
        cur.execute('SELECT COUNT(*) as cnt FROM withdrawal_records WHERE user_phone = ? AND status IN (0, 1)', (phone,))
        wd_row = cur.fetchone()
        if wd_row and wd_row['cnt'] > 0:
            has_pending_withdrawal = True
        
        conn.close()
        
        if row:
            result = dict(row)
            result['has_pending_withdrawal'] = has_pending_withdrawal
            return json_response(data=result)
        else:
            # 用户余额记录不存在，返回默认值
            return json_response(data={
                'phone': phone,
                'balance': 0,
                'total_deposited': 0,
                'total_withdrawn': 0,
                'has_pending_withdrawal': has_pending_withdrawal
            })
    except Exception as e:
        logger.error(f'[user/balance] 错误: {e}')
        return json_response(message=str(e), code=500)


# ============================================
# 未付款订单超时清理
# ============================================

@bp.route('/cleanup/expired-orders', methods=['POST'])
def cleanup_expired_orders():
    """清理超过5分钟仍未付款的订单，释放柜格"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        # 查找status=1且创建时间超过5分钟的订单
        cursor.execute('''
            SELECT o.id, o.slot_id, o.order_no FROM orders o
            WHERE o.status = 1 AND o.store_time < datetime('now', '-1 minute')
        ''')
        expired = cursor.fetchall()
        released = 0
        for order in expired:
            if order['slot_id']:
                cursor.execute('UPDATE cabinet_slots SET status = 1 WHERE id = ? AND status = 2', (order['slot_id'],))
                if cursor.rowcount > 0:
                    released += 1
            cursor.execute('UPDATE orders SET status = 5 WHERE id = ?', (order['id'],))
            logger.info(f'[超时清理] 订单{order["order_no"]}超时未支付，已释放柜格')
        conn.commit()
        conn.close()
        return json_response({'cleaned': len(expired), 'released_slots': released})
    except Exception as e:
        logger.error(f'[cleanup_expired] {e}')
        return json_response(message=str(e), code=500)


# ============================================
# 用户余额提现
# ============================================

@bp.route('/user/withdraw', methods=['POST'])
def user_withdraw():
    """用户从余额申请提现"""
    try:
        data = request.get_json()
        phone = data.get('phone', '').strip()
        amount = data.get('amount', 0)
        
        if not phone:
            return json_response(message='手机号不能为空', code=400)
        if not amount or float(amount) <= 0:
            return json_response(message='请输入有效金额', code=400)
        
        amount = float(amount)
        conn = get_db()
        cursor = conn.cursor()
        
        # 检查用户余额
        cursor.execute('SELECT balance, total_deposited, total_withdrawn FROM user_balances WHERE phone = ?', (phone,))
        row = cursor.fetchone()
        if not row:
            conn.close()
            return json_response(message='用户不存在', code=404)
        
        balance = row['balance']
        if balance <= 0:
            conn.close()
            return json_response(message='余额不足，无法提现', code=400)
        if amount > balance:
            conn.close()
        
        # 检查用户最近使用的网点是否允许提现
        cursor.execute("""
            SELECT l.withdraw_enabled, l.withdraw_mode, l.click_free_count 
            FROM orders o 
            JOIN cabinets c ON o.cabinet_id = c.id 
            JOIN locations l ON c.location_id = l.id 
            WHERE o.user_phone = ? 
            ORDER BY o.created_at DESC 
            LIMIT 1
        """, (phone,))
        loc_row = cursor.fetchone()
        if loc_row and not loc_row['withdraw_enabled']:
            conn.close()
            return json_response(message='该网点暂不支持提现', code=400)
        
        withdraw_mode = loc_row['withdraw_mode'] if loc_row else 'manual_approve'
        click_free = loc_row['click_free_count'] if loc_row else 0
        c2 = get_db(); c2.row_factory = get_db().row_factory if hasattr(get_db(), 'row_factory') else None
        cur2 = c2.cursor(); cur2.execute("SELECT COUNT(*) FROM withdrawal_records WHERE user_phone=? AND order_id IS NULL AND status=2", (phone,)); wd_cnt = cur2.fetchone()[0]; c2.close()
        if wd_cnt >= click_free:
            withdraw_mode = 'auto_approve'
        
        if withdraw_mode == 'auto_approve':
            # 自动审批模式：扣除余额 + 原路退回（通过最近支付订单走微信退款API）
            # 查找用户最近支付成功的订单，用于原路退回
            cursor.execute('SELECT id, deposit_amount, order_no FROM orders WHERE user_phone=? AND status IN (2,4,5,6) AND deposit_amount > 0 ORDER BY id DESC LIMIT 1', (phone,))
            refund_order = cursor.fetchone()
            if not refund_order:
                conn.close()
                return json_response(message='没有可退款的订单，无法提现', code=400)
            if amount > refund_order['deposit_amount']:
                conn.close()
                return json_response(message='提现金额不能超过最近订单支付金额(%.2f元)' % refund_order['deposit_amount'], code=400)
            cursor.execute('UPDATE user_balances SET balance = balance - ?, total_withdrawn = total_withdrawn + ? WHERE phone = ?', 
                           (amount, amount, phone))
            from helpers import do_real_refund
            refund_success, refund_id, refund_msg = do_real_refund(order_id=refund_order['id'], amount=amount)
            if refund_success:
                cursor.execute('INSERT INTO withdrawal_records (order_id, user_phone, amount, status, auto_approve_time, click_count) VALUES (?, ?, ?, 2, datetime("now"), 1)',
                               (refund_order['id'], phone, amount))
                withdrawal_id = cursor.lastrowid
                conn.commit()
                conn.close()
                return json_response(data={
                    'withdrawal_id': withdrawal_id,
                    'status': 'refunded',
                    'message': '提现成功，退款已原路退回'
                })
            else:
                # 退款失败，回滚余额
                cursor.execute('UPDATE user_balances SET balance = balance + ?, total_withdrawn = total_withdrawn - ? WHERE phone = ?', 
                               (amount, amount, phone))
                cursor.execute('INSERT INTO withdrawal_records (order_id, user_phone, amount, status, auto_approve_time, click_count) VALUES (?, ?, ?, 1, datetime("now"), 1)',
                               (refund_order['id'], phone, amount))
                withdrawal_id = cursor.lastrowid
                conn.commit()
                conn.close()
                return json_response(data={
                    'withdrawal_id': withdrawal_id,
                    'status': 'pending_refund',
                    'message': '提现申请已通过，退款处理中'
                })
        else:
            # 手动审批模式：仅创建待审批记录，不扣余额（审批通过后再扣）
            cursor.execute('INSERT INTO withdrawal_records (order_id, user_phone, amount, status, click_count) VALUES (NULL, ?, ?, 0, 1)',
                           (phone, amount))
            withdrawal_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return json_response(data={
                'withdrawal_id': withdrawal_id,
                'status': 'pending',
                'message': '提现申请已提交，等待审核'
            })
    except Exception as e:
        logger.error(f'[user/withdraw] {e}')
        return json_response(message=str(e), code=500)

