# 智能寄存柜商家端小程序

## 项目介绍

这是一个面向智能寄存柜商家的微信小程序，用于管理柜体、网点、订单等业务。

## 功能特性

- **登录注册**：商家账号登录
- **首页仪表盘**：实时查看今日订单、使用中柜格、今日收入、在线设备等数据
- **网点管理**：查看和管理所有网点的柜体设备
- **柜体详情**：查看柜格状态，支持远程开锁
- **订单管理**：查看所有订单，支持状态筛选
- **订单详情**：查看订单详细信息、支付记录
- **个人中心**：修改密码、查看开锁日志、退出登录

## 技术栈

- 微信小程序原生框架
- JavaScript (ES6+)
- WXML + WXSS
- 微信小程序 API

## 项目结构

```
smart-locker-merchant/
├── app.js              # 小程序入口
├── app.json            # 全局配置
├── app.wxss            # 全局样式
├── project.config.json # 项目配置
├── sitemap.json        # 站点地图
├── utils/
│   ├── api.js          # API 封装
│   └── auth.js         # 登录状态管理
├── images/             # 图片资源
├── pages/
│   ├── login/          # 登录页
│   ├── index/          # 首页/仪表盘
│   ├── locations/      # 网点管理
│   ├── cabinet-detail/ # 柜体详情
│   ├── orders/         # 订单列表
│   ├── order-detail/   # 订单详情
│   └── mine/           # 个人中心
└── components/         # 公共组件
```

## API 配置

API 基础地址配置在 `utils/api.js` 中：

```javascript
const BASE_URL = 'http://106.55.7.10/api'
```

如需修改后端地址，请直接修改此变量。

## 接口列表

| 接口 | 方法 | 说明 |
|------|------|------|
| /api/merchant/login | POST | 商家登录 |
| /api/merchant/logout | POST | 登出 |
| /api/merchant/info | GET | 获取商家信息 |
| /api/merchant/dashboard | GET | 获取仪表盘数据 |
| /api/merchant/locations | GET | 获取网点列表 |
| /api/merchant/cabinets | GET | 获取柜体列表 |
| /api/merchant/cabinets/{id}/slots | GET | 获取柜格详情 |
| /api/merchant/orders | GET | 获取订单列表 |
| /api/merchant/orders/{id} | GET | 获取订单详情 |
| /api/merchant/cabinets/{id}/open-slot | POST | 远程开锁 |
| /api/merchant/open-logs | GET | 获取开锁日志 |
| /api/merchant/password | PUT | 修改密码 |

## 快速开始

1. 克隆项目代码
2. 使用微信开发者工具导入项目
3. 修改 `utils/api.js` 中的 `BASE_URL` 为实际后端地址
4. 添加 TabBar 图标（可选）
5. 编译运行

## 注意事项

1. 请确保后端 API 已正常运行
2. 小程序需要配置合法域名（在微信公众平台设置）
3. 开发者工具中需要开启"不校验合法域名"进行开发测试
4. Token 存储在 `wx.setStorageSync('merchant_token', token)`

## 版本信息

- 版本号：v1.0.0
- 更新日期：2024年
