// app.js - 小程序入口，全局登录状态管理
const auth = require('./utils/auth.js')

App({
  globalData: {
    userInfo: null,
    isLoggedIn: false
  },

  onLaunch(options) {
    // 检查登录状态
    const token = auth.getToken()
    if (token) {
      this.globalData.isLoggedIn = true
      // 验证token有效性，可以在这里调用获取用户信息接口
      this.checkLoginStatus()
    } else {
      // 未登录，跳转到登录页
      wx.redirectTo({
        url: '/pages/login/login'
      })
    }
  },

  checkLoginStatus() {
    const API = require('./utils/api.js')
    API.request({
      url: '/merchant/info',
      method: 'GET'
    }).then(res => {
      if (res.code === 0 || res.code === 200) {
        this.globalData.userInfo = res.data
        this.globalData.isLoggedIn = true
      } else {
        this.handleLoginFailed()
      }
    }).catch(err => {
      if (err.statusCode === 401) {
        this.handleLoginFailed()
      }
    })
  },

  handleLoginFailed() {
    // token无效或过期，清除登录状态
    auth.clearAuth()
    this.globalData.isLoggedIn = false
    this.globalData.userInfo = null
    wx.redirectTo({
      url: '/pages/login/login'
    })
  },

  // 通用跳转登录页方法
  goToLogin() {
    auth.clearAuth()
    this.globalData.isLoggedIn = false
    this.globalData.userInfo = null
    wx.redirectTo({
      url: '/pages/login/login'
    })
  }
})
