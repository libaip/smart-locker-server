/**
 * components 文件夹说明
 * 
 * 此文件夹用于存放可复用组件
 * 
 * 如果需要创建自定义组件，请在此目录下创建组件文件夹
 * 每个组件应包含：
 * - component-name.wxml    (组件模板)
 * - component-name.wxss     (组件样式)
 * - component-name.js       (组件逻辑)
 * - component-name.json     (组件配置)
 * 
 * 示例组件结构：
 * components/
 *   ├── loading/
 *   │   ├── loading.wxml
 *   │   ├── loading.wxss
 *   │   ├── loading.js
 *   │   └── loading.json
 *   └── empty-state/
 *       ├── empty-state.wxml
 *       ├── empty-state.wxss
 *       ├── empty-state.js
 *       └── empty-state.json
 * 
 * 组件使用方式：
 * 1. 在页面的 .json 文件中引入：
 *    {
 *      "usingComponents": {
 *        "loading": "/components/loading/loading"
 *      }
 *    }
 * 
 * 2. 在页面的 .wxml 文件中使用：
 *    <loading show="{{loading}}" />
 */
