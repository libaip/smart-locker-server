// pages/cabinet-detail/cabinet-detail.js - 柜体详情逻辑
const API = require('../../utils/api.js')

Page({
  data: {
    cabinetId: null,
    locationId: null,
    locationName: '',
    cabinet: null,
    cabinets: [],
    slots: [],
    loading: true,
    selectedSlot: null,
    showConfirmModal: false,
    actionLoading: false
  },

  onLoad(options) {
    const { cabinetId, locationId, locationName } = options
    
    this.setData({
      cabinetId: cabinetId || null,
      locationId: locationId || null,
      locationName: decodeURIComponent(locationName || '')
    })
    
    if (cabinetId) {
      // 加载单个柜体
      this.loadCabinetDetail(cabinetId)
    } else if (locationId) {
      // 加载网点下所有柜体
      this.loadCabinetsByLocation(locationId)
    }
  },

  onPullDownRefresh() {
    if (this.data.cabinetId) {
      this.loadCabinetDetail(this.data.cabinetId)
    } else if (this.data.locationId) {
      this.loadCabinetsByLocation(this.data.locationId)
    }
  },

  // 加载单个柜体详情
  loadCabinetDetail(cabinetId) {
    this.setData({ loading: true })
    
    Promise.all([
      API.getSlots(cabinetId)
    ]).then(([slotsRes]) => {
      let slots = []
      
      if (slotsRes.data && Array.isArray(slotsRes.data)) {
        slots = slotsRes.data
      } else if (slotsRes.data && slotsRes.data.slots) {
        slots = slotsRes.data.slots
      }
      
      this.setData({
        cabinet: slotsRes.data?.cabinet || slotsRes.data?.info || { id: cabinetId },
        slots: slots,
        loading: false
      })
    }).catch(err => {
      this.setData({ loading: false })
      console.error('加载柜体详情失败:', err)
    })
  },

  // 加载网点下所有柜体
  loadCabinetsByLocation(locationId) {
    this.setData({ loading: true })
    
    API.getCabinets(locationId)
      .then(res => {
        let cabinets = []
        
        if (res.data && Array.isArray(res.data)) {
          cabinets = res.data
        } else if (res.data && res.data.list) {
          cabinets = res.data.list
        } else if (res.data && res.data.cabinets) {
          cabinets = res.data.cabinets
        }
        
        // 默认显示第一个柜体的柜格
        if (cabinets.length > 0 && !this.data.cabinetId) {
          this.setData({
            cabinets: cabinets,
            cabinet: cabinets[0],
            cabinetId: cabinets[0].id
          })
          this.loadCabinetDetail(cabinets[0].id)
        } else {
          this.setData({
            cabinets: cabinets,
            loading: false
          })
        }
      })
      .catch(err => {
        this.setData({ loading: false })
        console.error('加载柜体列表失败:', err)
      })
  },

  // 切换柜体
  onCabinetChange(e) {
    const index = e.detail.value
    const cabinet = this.data.cabinets[index]
    
    if (cabinet) {
      this.setData({
        cabinet: cabinet,
        cabinetId: cabinet.id,
        slots: []
      })
      this.loadCabinetDetail(cabinet.id)
    }
  },

  // 点击柜格
  onSlotTap(e) {
    const slot = e.currentTarget.dataset.slot
    const status = slot.status
    
    // 只有使用中或故障状态才能查看详情
    if (status === 'using' || status === 'fault' || status === 1 || status === 3) {
      this.setData({
        selectedSlot: slot,
        showConfirmModal: true
      })
    } else {
      // 空闲柜格只显示信息
      wx.showModal({
        title: '柜格信息',
        content: `柜格号：${slot.slot_no || slot.slot_number || slot.id}\n状态：空闲\n`,
        showCancel: false
      })
    }
  },

  // 关闭确认弹窗
  onCancelConfirm() {
    this.setData({
      selectedSlot: null,
      showConfirmModal: false
    })
  },

  // 确认远程开锁
  onConfirmOpen() {
    if (!this.data.selectedSlot || !this.data.cabinetId) {
      return
    }
    
    const slotId = this.data.selectedSlot.id || this.data.selectedSlot.slot_id
    
    this.setData({
      actionLoading: true
    })
    
    API.openSlot(this.data.cabinetId, slotId)
      .then(res => {
        this.setData({
          actionLoading: false,
          showConfirmModal: false,
          selectedSlot: null
        })
        
        wx.showToast({
          title: '开锁成功',
          icon: 'success',
          duration: 2000
        })
        
        // 刷新柜格状态
        this.loadCabinetDetail(this.data.cabinetId)
      })
      .catch(err => {
        this.setData({ actionLoading: false })
        console.error('远程开锁失败:', err)
      })
  },

  // 获取柜格状态样式
  getSlotStatusClass(status) {
    const statusMap = {
      'free': 'slot-free',
      'idle': 'slot-free',
      'using': 'slot-using',
      'fault': 'slot-fault',
      'locked': 'slot-locked',
      0: 'slot-free',
      1: 'slot-using',
      2: 'slot-fault',
      3: 'slot-locked'
    }
    return statusMap[status] || 'slot-free'
  },

  // 获取柜格状态文本
  getSlotStatusText(status) {
    const statusMap = {
      'free': '空闲',
      'idle': '空闲',
      'using': '使用中',
      'fault': '故障',
      'locked': '锁定',
      0: '空闲',
      1: '使用中',
      2: '故障',
      3: '锁定'
    }
    return statusMap[status] || '空闲'
  },

  // 判断柜格是否可点击
  isSlotClickable(status) {
    return status === 'using' || status === 'fault' || status === 1 || status === 3
  }
})
