// pages/index/index.js - 首页/仪表盘逻辑
const API = require('../../utils/api.js')
const auth = require('../../utils/auth.js')

Page({
  data: {
    merchantName: '商家用户',
    dashboard: {
      today_orders: 0,
      occupied_slots: 0,
      today_income: 0,
      online_cabinets: 0,
      total_cabinets: 0
    },
    recentOrders: [],
    loading: true
  },

  onLoad() {
    // 获取用户信息
    const userInfo = auth.getUserInfo()
    if (userInfo) {
      this.setData({
        merchantName: userInfo.name || userInfo.merchant_name || '商家用户'
      })
    }
  },

  onShow() {
    this.loadDashboard()
    this.loadRecentOrders()
  },

  onPullDownRefresh() {
    Promise.all([
      this.loadDashboard(),
      this.loadRecentOrders()
    ]).finally(() => {
      wx.stopPullDownRefresh()
    })
  },

  // 加载仪表盘数据
  loadDashboard() {
    API.getDashboard()
      .then(res => {
        if (res.data) {
          this.setData({
            dashboard: {
              today_orders: res.data.today_orders || 0,
              occupied_slots: res.data.occupied_slots || 0,
              today_income: res.data.today_income || 0,
              online_cabinets: res.data.online_cabinets || 0,
              total_cabinets: res.data.total_cabinets || 0
            },
            loading: false
          })
        }
      })
      .catch(err => {
        this.setData({ loading: false })
        console.error('加载仪表盘数据失败:', err)
      })
  },

  // 加载最近订单
  loadRecentOrders() {
    API.getOrders({ page: 1, limit: 5 })
      .then(res => {
        if (res.data && res.data.list) {
          this.setData({
            recentOrders: res.data.list
          })
        } else if (res.data && Array.isArray(res.data)) {
          this.setData({
            recentOrders: res.data.slice(0, 5)
          })
        }
      })
      .catch(err => {
        console.error('加载最近订单失败:', err)
      })
  },

  // 跳转到网点页面
  onLocationsTap() {
    wx.switchTab({
      url: '/pages/locations/locations'
    })
  },

  // 跳转到订单页面
  onOrdersTap() {
    wx.switchTab({
      url: '/pages/orders/orders'
    })
  },

  // 扫码查柜（预留功能）
  onScanCabinet() {
    wx.scanCode({
      success: (res) => {
        console.log('扫码结果:', res)
        // 解析扫码结果，提取柜体ID
        try {
          const result = res.result || res.scanType
          if (result) {
            // 假设扫码结果是柜体ID
            wx.navigateTo({
              url: `/pages/cabinet-detail/cabinet-detail?cabinetId=${result}`
            })
          }
        } catch (e) {
          wx.showToast({
            title: '无效的二维码',
            icon: 'none'
          })
        }
      },
      fail: () => {
        wx.showToast({
          title: '扫码取消',
          icon: 'none'
        })
      }
    })
  },

  // 远程开锁（预留功能）
  onRemoteOpen() {
    wx.showToast({
      title: '请先选择柜体',
      icon: 'none'
    })
  },

  // 跳转到订单详情
  onOrderTap(e) {
    const orderId = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/order-detail/order-detail?orderId=${orderId}`
    })
  },

  // 格式化金额
  formatMoney(amount) {
    if (!amount && amount !== 0) return '0.00'
    return parseFloat(amount).toFixed(2)
  },

  // 获取状态文本
  getStatusText(status) {
    const statusMap = {
      1: '使用中',
      2: '已取物',
      3: '已结算',
      4: '已超时'
    }
    return statusMap[status] || '未知'
  },

  // 获取状态样式
  getStatusClass(status) {
    const classMap = {
      1: 'status-tag-warning',
      2: 'status-tag-success',
      3: 'status-tag-gray',
      4: 'status-tag-danger'
    }
    return classMap[status] || 'status-tag-gray'
  },

  // 格式化时间
  formatTime(time) {
    if (!time) return '--'
    const date = new Date(time)
    const month = (date.getMonth() + 1).toString().padStart(2, '0')
    const day = date.getDate().toString().padStart(2, '0')
    const hour = date.getHours().toString().padStart(2, '0')
    const minute = date.getMinutes().toString().padStart(2, '0')
    return `${month}-${day} ${hour}:${minute}`
  }
})
