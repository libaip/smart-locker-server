// pages/locations/locations.js - 网点管理逻辑
const API = require('../../utils/api.js')

Page({
  data: {
    locations: [],
    loading: true,
    refreshing: false
  },

  onLoad() {
    this.loadLocations()
  },

  onShow() {
    // 每次显示页面时刷新数据
    // this.loadLocations()
  },

  onPullDownRefresh() {
    this.loadLocations()
  },

  // 加载网点列表
  loadLocations() {
    this.setData({ loading: true, refreshing: true })
    
    API.getLocations()
      .then(res => {
        let locations = []
        
        if (res.data && Array.isArray(res.data)) {
          locations = res.data
        } else if (res.data && res.data.list) {
          locations = res.data.list
        } else if (res.data && res.data.locations) {
          locations = res.data.locations
        }
        
        this.setData({
          locations: locations,
          loading: false,
          refreshing: false
        })
      })
      .catch(err => {
        this.setData({
          loading: false,
          refreshing: false
        })
        console.error('加载网点列表失败:', err)
      })
  },

  // 点击网点，查看柜体列表
  onLocationTap(e) {
    const locationId = e.currentTarget.dataset.id
    const location = e.currentTarget.dataset.location
    
    if (location && location.cabinets && location.cabinets.length > 0) {
      // 如果已经加载了柜体数据，直接跳转
      wx.navigateTo({
        url: `/pages/cabinet-detail/cabinet-detail?locationId=${locationId}&locationName=${encodeURIComponent(location.name || '')}`
      })
    } else {
      // 跳转到柜体页面
      wx.navigateTo({
        url: `/pages/cabinet-detail/cabinet-detail?locationId=${locationId}&locationName=${encodeURIComponent(location.name || '')}`
      })
    }
  },

  // 获取状态文本
  getStatusText(status) {
    const statusMap = {
      normal: '正常',
      stopped: '停用',
      maintaining: '维护中',
      0: '正常',
      1: '停用',
      2: '维护中'
    }
    return statusMap[status] || '正常'
  },

  // 获取状态样式
  getStatusClass(status) {
    const classMap = {
      normal: 'status-normal',
      stopped: 'status-stopped',
      maintaining: 'status-maintaining',
      0: 'status-normal',
      1: 'status-stopped',
      2: 'status-maintaining'
    }
    return classMap[status] || 'status-normal'
  }
})
