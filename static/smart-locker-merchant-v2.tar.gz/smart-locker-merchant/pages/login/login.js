// pages/login/login.js - 登录页逻辑
const API = require('../../utils/api.js')
const auth = require('../../utils/auth.js')

Page({
  data: {
    phone: '',
    password: '',
    phoneError: '',
    passwordError: '',
    loading: false
  },

  onLoad() {
    // 如果已登录，直接跳转
    if (auth.isLoggedIn()) {
      wx.switchTab({
        url: '/pages/index/index'
      })
    }
  },

  // 手机号输入
  onPhoneInput(e) {
    const phone = e.detail.value
    this.setData({
      phone: phone,
      phoneError: ''
    })
  },

  // 密码输入
  onPasswordInput(e) {
    const password = e.detail.value
    this.setData({
      password: password,
      passwordError: ''
    })
  },

  // 验证手机号
  validatePhone() {
    const phone = this.data.phone.trim()
    if (!phone) {
      this.setData({ phoneError: '请输入手机号' })
      return false
    }
    if (!/^1[3-9]\d{9}$/.test(phone)) {
      this.setData({ phoneError: '手机号格式不正确' })
      return false
    }
    return true
  },

  // 验证密码
  validatePassword() {
    const password = this.data.password
    if (!password) {
      this.setData({ passwordError: '请输入密码' })
      return false
    }
    return true
  },

  // 登录按钮点击
  onLoginTap() {
    // 验证表单
    const phoneValid = this.validatePhone()
    const passwordValid = this.validatePassword()
    
    if (!phoneValid || !passwordValid) {
      return
    }

    this.setData({ loading: true })

    API.login(this.data.phone.trim(), this.data.password)
      .then(res => {
        this.setData({ loading: false })
        
        // 登录成功，保存状态和用户信息
        auth.setLoggedIn(true)
        if (res.data) {
          auth.setUserInfo(res.data)
        }
        
        wx.showToast({
          title: '登录成功',
          icon: 'success',
          duration: 1500
        })

        // 跳转到首页
        setTimeout(() => {
          wx.switchTab({
            url: '/pages/index/index'
          })
        }, 1500)
      })
      .catch(err => {
        this.setData({ loading: false })
        console.error('登录失败:', err)
        if (err.message) {
          wx.showToast({
            title: err.message,
            icon: 'none',
            duration: 2000
          })
        }
      })
  },

  // 忘记密码（预留）
  onForgetPassword() {
    wx.showToast({
      title: '请联系管理员重置密码',
      icon: 'none'
    })
  }
})
