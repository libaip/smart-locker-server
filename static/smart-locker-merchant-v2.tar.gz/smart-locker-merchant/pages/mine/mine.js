// pages/mine/mine.js - 个人中心逻辑
const API = require('../../utils/api.js')
const auth = require('../../utils/auth.js')

Page({
  data: {
    merchant: {
      name: '',
      contact: '',
      phone: ''
    },
    showPasswordModal: false,
    showLogsModal: false,
    logs: [],
    logsLoading: false,
    // 修改密码表单
    passwordForm: {
      oldPassword: '',
      newPassword: '',
      confirmPassword: ''
    },
    passwordLoading: false
  },

  onLoad() {
    this.loadMerchantInfo()
  },

  onShow() {
    this.loadMerchantInfo()
  },

  // 加载商家信息
  loadMerchantInfo() {
    API.getInfo()
      .then(res => {
        if (res.data) {
          this.setData({
            merchant: {
              name: res.data.name || res.data.merchant_name || '商家用户',
              contact: res.data.contact || res.data.contact_name || '--',
              phone: res.data.phone || res.data.mobile || '--'
            }
          })
          // 保存到本地
          auth.setUserInfo(res.data)
        }
      })
      .catch(err => {
        console.error('加载商家信息失败:', err)
      })
  },

  // 跳转到修改密码页面（使用弹窗）
  onChangePassword() {
    this.setData({
      showPasswordModal: true,
      passwordForm: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      }
    })
  },

  // 关闭修改密码弹窗
  onClosePasswordModal() {
    this.setData({
      showPasswordModal: false
    })
  },

  // 旧密码输入
  onOldPasswordInput(e) {
    this.setData({
      'passwordForm.oldPassword': e.detail.value
    })
  },

  // 新密码输入
  onNewPasswordInput(e) {
    this.setData({
      'passwordForm.newPassword': e.detail.value
    })
  },

  // 确认密码输入
  onConfirmPasswordInput(e) {
    this.setData({
      'passwordForm.confirmPassword': e.detail.value
    })
  },

  // 提交修改密码
  onSubmitPassword() {
    const { oldPassword, newPassword, confirmPassword } = this.data.passwordForm

    // 验证
    if (!oldPassword) {
      wx.showToast({ title: '请输入原密码', icon: 'none' })
      return
    }
    if (!newPassword) {
      wx.showToast({ title: '请输入新密码', icon: 'none' })
      return
    }
    if (newPassword.length < 6) {
      wx.showToast({ title: '新密码至少6位', icon: 'none' })
      return
    }
    if (newPassword !== confirmPassword) {
      wx.showToast({ title: '两次密码不一致', icon: 'none' })
      return
    }

    this.setData({ passwordLoading: true })

    API.changePassword(oldPassword, newPassword)
      .then(res => {
        this.setData({ passwordLoading: false })
        wx.showToast({
          title: '密码修改成功',
          icon: 'success'
        })
        this.onClosePasswordModal()
      })
      .catch(err => {
        this.setData({ passwordLoading: false })
        console.error('修改密码失败:', err)
      })
  },

  // 查看开锁日志
  onViewOpenLogs() {
    this.setData({
      showLogsModal: true,
      logs: [],
      logsLoading: true
    })
    this.loadOpenLogs()
  },

  // 关闭日志弹窗
  onCloseLogsModal() {
    this.setData({
      showLogsModal: false
    })
  },

  // 加载开锁日志
  loadOpenLogs() {
    this.setData({ logsLoading: true })
    
    API.getOpenLogs({ page: 1, limit: 50 })
      .then(res => {
        let logs = []
        if (res.data && Array.isArray(res.data)) {
          logs = res.data
        } else if (res.data && res.data.list) {
          logs = res.data.list
        } else if (res.data && res.data.logs) {
          logs = res.data.logs
        }
        
        this.setData({
          logs: logs,
          logsLoading: false
        })
      })
      .catch(err => {
        this.setData({ logsLoading: false })
        console.error('加载开锁日志失败:', err)
      })
  },

  // 关于
  onAbout() {
    wx.showModal({
      title: '关于',
      content: '智能寄存柜商家端 v1.0.0\n\n为您提供便捷的柜体管理服务',
      showCancel: false
    })
  },

  // 退出登录
  onLogout() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      confirmColor: '#FF3B30',
      success: (res) => {
        if (res.confirm) {
          API.logout()
            .catch(() => {})
            .finally(() => {
              auth.clearAuth()
              const app = getApp()
              app.globalData.isLoggedIn = false
              app.globalData.userInfo = null
              
              wx.redirectTo({
                url: '/pages/login/login'
              })
            })
        }
      }
    })
  },

  // 格式化时间
  formatTime(time) {
    if (!time) return '--'
    const date = new Date(time)
    const month = (date.getMonth() + 1).toString().padStart(2, '0')
    const day = date.getDate().toString().padStart(2, '0')
    const hour = date.getHours().toString().padStart(2, '0')
    const minute = date.getMinutes().toString().padStart(2, '0')
    const second = date.getSeconds().toString().padStart(2, '0')
    return `${month}-${day} ${hour}:${minute}:${second}`
  }
})
