// pages/orders/orders.js - 订单列表逻辑
const API = require('../../utils/api.js')

Page({
  data: {
    orders: [],
    loading: true,
    refreshing: false,
    currentTab: 0,
    tabs: [
      { name: '全部', status: '' },
      { name: '使用中', status: 1 },
      { name: '已取物', status: 2 },
      { name: '已结算', status: 3 }
    ],
    page: 1,
    limit: 20,
    hasMore: true,
    loadingMore: false
  },

  onLoad() {
    this.loadOrders()
  },

  onShow() {
    // this.loadOrders()
  },

  onPullDownRefresh() {
    this.setData({
      page: 1,
      hasMore: true
    })
    this.loadOrders().finally(() => {
      wx.stopPullDownRefresh()
    })
  },

  onReachBottom() {
    if (this.data.hasMore && !this.data.loadingMore) {
      this.loadMoreOrders()
    }
  },

  // 切换Tab
  onTabChange(e) {
    const index = e.currentTarget.dataset.index
    this.setData({
      currentTab: index,
      orders: [],
      page: 1,
      hasMore: true
    })
    this.loadOrders()
  },

  // 加载订单列表
  loadOrders() {
    const currentTab = this.data.tabs[this.data.currentTab]
    const status = currentTab.status
    
    this.setData({ loading: true })
    
    const params = {
      page: 1,
      limit: this.data.limit
    }
    
    if (status !== '') {
      params.status = status
    }
    
    return API.getOrders(params)
      .then(res => {
        let orders = []
        
        if (res.data && Array.isArray(res.data)) {
          orders = res.data
        } else if (res.data && res.data.list) {
          orders = res.data.list
        } else if (res.data && res.data.orders) {
          orders = res.data.orders
        }
        
        this.setData({
          orders: orders,
          loading: false,
          refreshing: false,
          page: 1,
          hasMore: orders.length >= this.data.limit
        })
      })
      .catch(err => {
        this.setData({
          loading: false,
          refreshing: false
        })
        console.error('加载订单列表失败:', err)
      })
  },

  // 加载更多订单
  loadMoreOrders() {
    if (!this.data.hasMore || this.data.loadingMore) {
      return
    }
    
    this.setData({ loadingMore: true })
    
    const currentTab = this.data.tabs[this.data.currentTab]
    const status = currentTab.status
    
    const params = {
      page: this.data.page + 1,
      limit: this.data.limit
    }
    
    if (status !== '') {
      params.status = status
    }
    
    API.getOrders(params)
      .then(res => {
        let newOrders = []
        
        if (res.data && Array.isArray(res.data)) {
          newOrders = res.data
        } else if (res.data && res.data.list) {
          newOrders = res.data.list
        } else if (res.data && res.data.orders) {
          newOrders = res.data.orders
        }
        
        this.setData({
          orders: [...this.data.orders, ...newOrders],
          loadingMore: false,
          page: this.data.page + 1,
          hasMore: newOrders.length >= this.data.limit
        })
      })
      .catch(err => {
        this.setData({ loadingMore: false })
        console.error('加载更多订单失败:', err)
      })
  },

  // 点击订单
  onOrderTap(e) {
    const orderId = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/order-detail/order-detail?orderId=${orderId}`
    })
  },

  // 获取状态文本
  getStatusText(status) {
    const statusMap = {
      1: '使用中',
      2: '已取物',
      3: '已结算',
      4: '已超时'
    }
    return statusMap[status] || '未知'
  },

  // 获取状态样式
  getStatusClass(status) {
    const classMap = {
      1: 'status-tag-warning',
      2: 'status-tag-success',
      3: 'status-tag-gray',
      4: 'status-tag-danger'
    }
    return classMap[status] || 'status-tag-gray'
  },

  // 格式化金额
  formatMoney(amount) {
    if (!amount && amount !== 0) return '0.00'
    return parseFloat(amount).toFixed(2)
  },

  // 格式化时间
  formatTime(time) {
    if (!time) return '--'
    const date = new Date(time)
    const month = (date.getMonth() + 1).toString().padStart(2, '0')
    const day = date.getDate().toString().padStart(2, '0')
    const hour = date.getHours().toString().padStart(2, '0')
    const minute = date.getMinutes().toString().padStart(2, '0')
    return `${month}-${day} ${hour}:${minute}`
  },

  // 格式化手机号（脱敏）
  formatPhone(phone) {
    if (!phone) return '****'
    if (phone.length === 11) {
      return phone.substring(0, 3) + '****' + phone.substring(7)
    }
    return phone
  }
})
