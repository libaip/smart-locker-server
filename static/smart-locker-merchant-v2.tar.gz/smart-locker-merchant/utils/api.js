// utils/api.js - 封装wx.request，统一请求处理
const auth = require('./auth.js')

// API基础地址
const BASE_URL = 'http://106.55.7.10/api'

/**
 * 统一请求方法
 * @param {object} options - 请求配置
 */
function request(options) {
  const {
    url,
    method = 'GET',
    data = {},
    header = {},
    showLoading = true,
    hideErrorToast = false
  } = options

  // 显示loading
  if (showLoading) {
    wx.showLoading({
      title: '加载中...',
      mask: true
    })
  }

  // 获取session cookie
  const cookie = auth.getCookie()
  
  // 合并请求头
  const requestHeader = {
    'Content-Type': 'application/json',
    ...header
  }
  
  if (cookie) {
    requestHeader['Cookie'] = cookie
  }

  return new Promise((resolve, reject) => {
    wx.request({
      url: BASE_URL + url,
      method: method,
      data: data,
      header: requestHeader,
      timeout: 15000,
      success: (res) => {
        if (showLoading) {
          wx.hideLoading()
        }

        // 保存服务器返回的Set-Cookie
        if (res.header && res.header['Set-Cookie']) {
          auth.setCookie(res.header['Set-Cookie'])
        }
        // 某些版本用小写
        if (res.header && res.header['set-cookie']) {
          auth.setCookie(res.header['set-cookie'])
        }

        // 处理业务错误
        if (res.data.code === 0 || res.data.code === 200) {
          resolve(res.data)
        } else if (res.statusCode === 401 || res.data.code === 401) {
          // 未授权
          handleUnauthorized()
          reject({
            statusCode: 401,
            message: res.data.message || '登录已过期，请重新登录'
          })
        } else {
          // 其他业务错误
          if (!hideErrorToast) {
            wx.showToast({
              title: res.data.message || '请求失败',
              icon: 'none',
              duration: 2000
            })
          }
          reject({
            statusCode: res.statusCode,
            code: res.data.code,
            message: res.data.message || '请求失败'
          })
        }
      },
      fail: (err) => {
        if (showLoading) {
          wx.hideLoading()
        }
        
        console.error('请求失败:', err)
        
        if (!hideErrorToast) {
          wx.showToast({
            title: '网络请求失败，请检查网络',
            icon: 'none',
            duration: 2000
          })
        }
        
        reject({
          statusCode: -1,
          message: '网络请求失败'
        })
      }
    })
  })
}

/**
 * 处理未授权情况
 */
function handleUnauthorized() {
  auth.clearAuth()
  
  // 获取当前页面栈
  const pages = getCurrentPages()
  const currentPage = pages[pages.length - 1]
  const currentRoute = currentPage ? currentPage.route : ''
  
  // 如果不是登录页，则跳转到登录页
  if (!currentRoute.includes('login')) {
    wx.redirectTo({
      url: '/pages/login/login'
    })
  }
}

/**
 * GET请求
 */
function get(url, data, options = {}) {
  return request({
    url,
    method: 'GET',
    data,
    ...options
  })
}

/**
 * POST请求
 */
function post(url, data, options = {}) {
  return request({
    url,
    method: 'POST',
    data,
    ...options
  })
}

/**
 * PUT请求
 */
function put(url, data, options = {}) {
  return request({
    url,
    method: 'PUT',
    data,
    ...options
  })
}

/**
 * DELETE请求
 */
function del(url, data, options = {}) {
  return request({
    url,
    method: 'DELETE',
    data,
    ...options
  })
}

// 商家相关API
const merchantApi = {
  // 登录
  login: (phone, password) => post('/merchant/login', { phone, password }, { showLoading: false }),
  
  // 登出
  logout: () => post('/merchant/logout', {}),
  
  // 获取商家信息
  getInfo: () => get('/merchant/info'),
  
  // 获取仪表盘数据
  getDashboard: () => get('/merchant/dashboard'),
  
  // 获取网点列表
  getLocations: () => get('/merchant/locations'),
  
  // 获取柜体列表
  getCabinets: (locationId) => get('/merchant/cabinets', locationId ? { location_id: locationId } : {}),
  
  // 获取柜格详情
  getSlots: (cabinetId) => get(`/merchant/cabinets/${cabinetId}/slots`),
  
  // 获取订单列表
  getOrders: (params) => get('/merchant/orders', params),
  
  // 获取订单详情
  getOrderDetail: (orderId) => get(`/merchant/orders/${orderId}`),
  
  // 远程开锁
  openSlot: (cabinetId, slotId) => post(`/merchant/cabinets/${cabinetId}/open-slot`, { slot_id: slotId }),
  
  // 获取开锁日志
  getOpenLogs: (params) => get('/merchant/open-logs', params),
  
  // 修改密码
  changePassword: (oldPassword, newPassword) => put('/merchant/password', { old_password: oldPassword, new_password: newPassword })
}

module.exports = {
  request,
  get,
  post,
  put,
  del,
  BASE_URL,
  ...merchantApi
}
