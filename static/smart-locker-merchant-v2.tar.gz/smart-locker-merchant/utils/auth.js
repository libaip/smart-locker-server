// utils/auth.js - 登录状态管理，cookie/session存取

const COOKIE_KEY = 'merchant_cookie'
const USER_INFO_KEY = 'merchant_user_info'
const LOGIN_STATUS_KEY = 'merchant_logged_in'

/**
 * 获取存储的cookie
 */
function getCookie() {
  return wx.getStorageSync(COOKIE_KEY) || ''
}

/**
 * 设置cookie
 * @param {string} cookie - cookie值
 */
function setCookie(cookie) {
  if (cookie) {
    wx.setStorageSync(COOKIE_KEY, cookie)
  }
}

/**
 * 获取用户信息
 */
function getUserInfo() {
  const info = wx.getStorageSync(USER_INFO_KEY)
  return info ? JSON.parse(info) : null
}

/**
 * 设置用户信息
 * @param {object} userInfo - 用户信息对象
 */
function setUserInfo(userInfo) {
  wx.setStorageSync(USER_INFO_KEY, JSON.stringify(userInfo))
}

/**
 * 清除认证信息（退出登录）
 */
function clearAuth() {
  wx.removeStorageSync(COOKIE_KEY)
  wx.removeStorageSync(USER_INFO_KEY)
  wx.removeStorageSync(LOGIN_STATUS_KEY)
}

/**
 * 设置登录状态
 */
function setLoggedIn(status) {
  wx.setStorageSync(LOGIN_STATUS_KEY, status)
}

/**
 * 检查是否已登录
 */
function isLoggedIn() {
  return !!wx.getStorageSync(LOGIN_STATUS_KEY)
}

module.exports = {
  getCookie,
  setCookie,
  getUserInfo,
  setUserInfo,
  clearAuth,
  setLoggedIn,
  isLoggedIn
}
