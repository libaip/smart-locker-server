// pages/index/index.js
const API = require('../../utils/api.js')
const auth = require('../../utils/auth.js')

Page({
  data: {
    userName: '用户',
    isAgent: false,
    dashboard: { today_orders: 0, occupied_slots: 0, today_income: 0, online_cabinets: 0, total_cabinets: 0 },
    agentStats: { total_deposit: '0.00', total_refund: '0.00', total_unreturned: '0.00', platform_commission: '0.00', agent_income: '0.00', commission_rate: 0, order_count: 0, active_order_count: 0 },
    recentOrders: [],
    loading: true
  },

  onLoad() {
    const userInfo = auth.getUserInfo()
    const isAgent = auth.isAgent()
    this.setData({ isAgent })
    if (userInfo) {
      this.setData({ userName: userInfo.name || '用户' })
    }
  },

  onShow() {
    if (this.data.isAgent) { this.loadAgentStats() }
    else { this.loadDashboard(); this.loadRecentOrders() }
  },

  onPullDownRefresh() {
    if (this.data.isAgent) { this.loadAgentStats().finally(() => wx.stopPullDownRefresh()) }
    else { Promise.all([this.loadDashboard(), this.loadRecentOrders()]).finally(() => wx.stopPullDownRefresh()) }
  },

  loadAgentStats() {
    const userInfo = auth.getUserInfo()
    const agentId = userInfo ? userInfo.agent_id : null
    if (!agentId) { return Promise.resolve() }
    return API.getAgentStats(agentId).then(res => {
      if (res.data) {
        const d = res.data
        this.setData({
          agentStats: {
            total_deposit: (d.total_deposit || 0).toFixed(2),
            total_refund: (d.total_refund || 0).toFixed(2),
            total_unreturned: (d.total_unreturned || 0).toFixed(2),
            platform_commission: (d.platform_commission || 0).toFixed(2),
            agent_income: (d.agent_income || 0).toFixed(2),
            commission_rate: (d.agent && d.agent.commission_rate) || 0,
            order_count: d.order_count || 0,
            active_order_count: d.active_order_count || 0
          },
          loading: false
        })
      }
    }).catch(err => { this.setData({ loading: false }); console.error('加载代理商统计失败:', err) })
  },

  loadDashboard() {
    API.getDashboard().then(res => {
      if (res.data) {
        this.setData({
          dashboard: {
            today_orders: res.data.today_orders || 0, occupied_slots: res.data.occupied_slots || 0,
            today_income: res.data.today_income || 0, online_cabinets: res.data.online_cabinets || 0, total_cabinets: res.data.total_cabinets || 0
          }, loading: false
        })
      }
    }).catch(err => { this.setData({ loading: false }) })
  },

  loadRecentOrders() {
    API.getOrders({ page: 1, limit: 5 }).then(res => {
      if (res.data && res.data.list) { this.setData({ recentOrders: res.data.list }) }
      else if (res.data && Array.isArray(res.data)) { this.setData({ recentOrders: res.data.slice(0, 5) }) }
    }).catch(err => { console.error('加载最近订单失败:', err) })
  },

  onLocationsTap() { wx.switchTab({ url: '/pages/locations/locations' }) },
  onOrdersTap() { wx.switchTab({ url: '/pages/orders/orders' }) },
  onScanCabinet() {
    wx.scanCode({
      success: (res) => {
        try {
          if (res.result) { wx.navigateTo({ url: '/pages/cabinet-detail/cabinet-detail?cabinetId=' + res.result }) }
        } catch (e) { wx.showToast({ title: '无效的二维码', icon: 'none' }) }
      }, fail: () => { wx.showToast({ title: '扫码取消', icon: 'none' }) }
    })
  },
  onRemoteOpen() { wx.showToast({ title: '请先选择柜体', icon: 'none' }) },
  onOrderTap(e) { wx.navigateTo({ url: '/pages/order-detail/order-detail?orderId=' + e.currentTarget.dataset.id }) },
  formatMoney(amount) { if (!amount && amount !== 0) return '0.00'; return parseFloat(amount).toFixed(2) },
  getStatusText(status) { return { 1: '使用中', 2: '已取物', 3: '已结算', 4: '已超时' }[status] || '未知' },
  getStatusClass(status) { return { 1: 'status-tag-warning', 2: 'status-tag-success', 3: 'status-tag-gray', 4: 'status-tag-danger' }[status] || 'status-tag-gray' },
  formatTime(time) {
    if (!time) return '--'
    const d = new Date(time)
    return (d.getMonth() + 1).toString().padStart(2, '0') + '-' + d.getDate().toString().padStart(2, '0') + ' ' + d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0')
  }
})
