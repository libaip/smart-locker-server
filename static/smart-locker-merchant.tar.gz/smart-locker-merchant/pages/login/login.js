// pages/login/login.js
const API = require('../../utils/api.js')
const auth = require('../../utils/auth.js')

Page({
  data: { phone: '', password: '', phoneError: '', passwordError: '', loading: false, role: 'merchant' },

  onLoad() {
    const savedRole = auth.getRole()
    if (savedRole) { this.setData({ role: savedRole }) }
    if (auth.isLoggedIn()) { wx.switchTab({ url: '/pages/index/index' }) }
  },

  onRoleChange(e) { this.setData({ role: e.currentTarget.dataset.role }) },
  onPhoneInput(e) { this.setData({ phone: e.detail.value, phoneError: '' }) },
  onPasswordInput(e) { this.setData({ password: e.detail.value, passwordError: '' }) },

  validatePhone() {
    const phone = this.data.phone.trim()
    if (!phone) { this.setData({ phoneError: '请输入手机号' }); return false }
    if (!/^1[3-9]\d{9}$/.test(phone)) { this.setData({ phoneError: '手机号格式不正确' }); return false }
    return true
  },

  validatePassword() {
    if (!this.data.password) { this.setData({ passwordError: '请输入密码' }); return false }
    return true
  },

  onLoginTap() {
    if (!this.validatePhone() || !this.validatePassword()) { return }
    this.setData({ loading: true })
    const isAgent = this.data.role === 'agent'
    const loginFn = isAgent ? API.agentLogin : API.login
    loginFn(this.data.phone.trim(), this.data.password)
      .then(res => {
        this.setData({ loading: false })
        auth.setLoggedIn(true)
        auth.setRole(this.data.role)
        if (res.data) {
          res.data.role = this.data.role
          auth.setUserInfo(res.data)
        }
        wx.showToast({ title: '登录成功', icon: 'success', duration: 1500 })
        setTimeout(() => { wx.switchTab({ url: '/pages/index/index' }) }, 1500)
      })
      .catch(err => {
        this.setData({ loading: false })
        if (err.message) { wx.showToast({ title: err.message, icon: 'none', duration: 2000 }) }
      })
  },

  onForgetPassword() { wx.showToast({ title: '请联系管理员重置密码', icon: 'none' }) },

  goPrivacy() { wx.navigateTo({ url: '/pages/privacy/privacy' }) },
  goAgreement() { wx.navigateTo({ url: '/pages/agreement/agreement' }) }
})
