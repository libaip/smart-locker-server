# 智能寄存柜屏幕端 APK

## 项目概述

本项目是一个完整的Android寄存柜屏幕端应用，参考 `com.lczk` APK的架构开发，确保与YBM协议主板的硬件兼容性。

## 核心特性

- ✅ **YBM协议支持** - 完整实现YBM锁控板协议
- ✅ **多种串口类型** - BaseSerial/NormalSerial/VioSerial
- ✅ **WebSocket通信** - STOMP协议，支持断线重连
- ✅ **后台服务** - 开机自启，保持长连接
- ✅ **全屏界面** - 专业寄存柜屏幕UI
- ✅ **本地存储** - SQLite数据库，SharedPreferences
- ✅ **WT板预留** - 预留WT协议接口

## 项目结构

```
smart-locker-apk/
├── app/
│   ├── src/main/
│   │   ├── java/com/smartlocker/screen/
│   │   │   ├── MainActivity.java          # 主界面（全屏）
│   │   │   ├── SettingsActivity.java      # 设置界面
│   │   │   ├── OpenLockActivity.java      # 开锁管理
│   │   │   ├── OrderActivity.java         # 订单/存取界面
│   │   │   ├── AdminActivity.java         # 管理员界面
│   │   │   ├── SmartLockerApp.java       # Application类
│   │   │   ├── SerialPortManager.java     # 串口管理
│   │   │   ├── YBMProtocol.java          # YBM协议
│   │   │   ├── LockerWebSocket.java      # WebSocket客户端
│   │   │   ├── db/
│   │   │   │   └── DBHelper.java          # SQLite数据库
│   │   │   ├── service/
│   │   │   │   ├── LockerService.java     # 后台服务
│   │   │   │   └── AutoInstallService.java # 自动安装
│   │   │   ├── receiver/
│   │   │   │   ├── BootReceiver.java      # 开机广播
│   │   │   │   └── NetworkReceiver.java   # 网络状态
│   │   │   └── utils/
│   │   │       └── PreferencesHelper.java # 配置管理
│   │   ├── res/                           # 资源文件
│   │   ├── AndroidManifest.xml
│   │   └── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
└── gradle/
```

## API接口

### 设备端接口
| 接口 | 方法 | 说明 |
|------|------|------|
| /api/device/register | POST | 设备注册 |
| /api/device/heartbeat | POST | 心跳上报 |
| /api/deposit/create-order | POST | 创建订单(存包) |
| /api/retrieve/verify | POST | 取件验证 |
| /api/retrieve/confirm | POST | 取件确认 |
| /api/admin/open-lock | POST | 远程开锁 |

### WebSocket接口
- 订阅: `/topic/lock-command` - 开锁指令
- 订阅: `/topic/device-status` - 设备状态
- 订阅: `/topic/message` - 通用消息

## 串口配置

| 参数 | 值 |
|------|-----|
| 默认路径 | `/dev/ttyS1` |
| 可用路径 | `/dev/ttyS1~S4`, `/dev/ttyUSB0~3` |
| 波特率 | 9600, 19200, 115200 |
| 数据位 | 8 |
| 停止位 | 1 |
| 校验 | 无 |

## YBM协议

### 命令码
| 命令 | 码值 | 说明 |
|------|------|------|
| CMD_OPEN_LOCK_B | 0x80 | 开锁(有响应) |
| CMD_OPEN_LOCK_A | 0x9D | 开锁(无响应) |
| CMD_OPEN_ALL | 0xA5 | 全部开锁 |
| CMD_SET_BOARD_NO | 0xDF | 设置板号 |
| CMD_READ_MCU_ID | 0xDD | 读取MCU ID |
| CMD_READ_STATUS | 0xD1 | 读取锁状态 |
| CMD_HEARTBEAT | 0x10 | 心跳检测 |

### 帧格式
```
[CMD] [BOARD] [DATA1] [DATA2] [XOR]
```

## 编译说明

### 环境要求
- Android Studio Arctic Fox 或更高
- JDK 8+
- Android SDK 34

### 编译步骤
```bash
# 同步Gradle
./gradlew clean

# Debug编译
./gradlew assembleDebug

# Release编译
./gradlew assembleRelease
```

### 签名配置
在 `app/build.gradle` 中配置签名信息：
```groovy
android {
    signingConfigs {
        release {
            storeFile file('keystore.jks')
            storePassword 'password'
            keyAlias 'alias'
            keyPassword 'password'
        }
    }
}
```

## 配置说明

### 首次配置
1. 在设置界面配置服务器地址: `https://cqdyxl.com`
2. 设置设备ID（与后台管理系统对应）
3. 选择串口路径和波特率
4. 设置主板编号（起始号和数量）
5. 保存后重启服务

### 管理员功能
- 默认密码: `123456`
- 进入方式: 设置界面点击5次屏幕

## 与参考APK对比

| 功能 | 参考APK (com.lczk) | 本APK |
|------|-------------------|-------|
| 包名 | com.lczk | com.smartlocker.screen |
| 版本 | 1.0.3 | 1.0.3 |
| 协议 | YBM | YBM + WT预留 |
| 串口 | stty + JNI | stty (保留JNI接口) |
| 数据库 | SQLite | SQLite |
| WebSocket | STOMP | STOMP |
| 开机自启 | ✅ | ✅ |
| 心跳机制 | ✅ | ✅ |
| 全开功能 | ✅ | ✅ |

## 注意事项

1. **Root权限**: BaseSerial模式需要root权限来执行stty配置
2. **硬件兼容**: 确保主板使用YBM协议，串口连接正确
3. **网络要求**: 设备需要稳定的网络连接
4. **版本号**: 保持与参考APK版本一致(1.0.3)便于兼容

## 许可证

本项目仅供学习参考，使用请遵循相关法律法规。
