# Add project specific ProGuard rules here.

# 保留Gson序列化
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# 保留实体类
-keep class com.smartlocker.screen.model.** { *; }
-keep class * implements java.io.Serializable { *; }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# STOMP
-keep class ua.naivejava.** { *; }
-dontwarn ua.naivejava.**

# ZXing
-keep class com.google.zxing.** { *; }
-dontwarn com.google.zxing.**

# AndroidX
-keep class androidx.** { *; }
-dontwarn androidx.**

# 保留枚举
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# 保留Parcelable
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# 保留R字段
-keepclassmembers class **.R$* {
    public static <fields>;
}

# 去除日志（Release）
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

# 保留JNI方法
-keepclasseswithmembernames class * {
    native <methods>;
}

# 保留Service
-keep class com.smartlocker.screen.service.** { *; }
-keep class com.smartlocker.screen.receiver.** { *; }
