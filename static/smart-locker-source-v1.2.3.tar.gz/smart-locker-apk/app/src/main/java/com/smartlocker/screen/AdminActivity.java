package com.smartlocker.screen;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.*;
import android.widget.*;import android.graphics.Typeface;;
import com.smartlocker.screen.utils.PreferencesHelper;

/**
 * 管理员界面
 * 需要输入管理员密码才能进入
 */
public class AdminActivity extends Activity {
    private static final String TAG = "AdminActivity";
    
    private PreferencesHelper mPrefs;
    private Handler mHandler;
    
    private LinearLayout mLoginLayout;
    private LinearLayout mMenuLayout;
    private EditText mEtPassword;
    private TextView mTvError;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        mPrefs = new PreferencesHelper(this);
        mHandler = new Handler(Looper.getMainLooper());
        
        checkPassword();
    }
    
    private void checkPassword() {
        // 显示登录界面
        showLoginUI();
    }
    
    private void showLoginUI() {
        mLoginLayout = new LinearLayout(this);
        mLoginLayout.setOrientation(LinearLayout.VERTICAL);
        mLoginLayout.setBackgroundColor(Color.parseColor("#263238"));
        mLoginLayout.setGravity(Gravity.CENTER);
        mLoginLayout.setPadding(50, 50, 50, 50);
        
        // 标题
        TextView title = new TextView(this);
        title.setText("🔐 管理员登录");
        title.setTextSize(28);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        mLoginLayout.addView(title);
        
        // 密码输入
        mEtPassword = new EditText(this);
        mEtPassword.setHint("请输入管理员密码");
        mEtPassword.setTextSize(20);
        mEtPassword.setTextColor(Color.WHITE);
        mEtPassword.setBackgroundColor(Color.parseColor("#37474F"));
        mEtPassword.setPadding(20, 15, 20, 15);
        mEtPassword.setGravity(Gravity.CENTER);
        mEtPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        mLoginLayout.addView(mEtPassword, new LinearLayout.LayoutParams(400, LinearLayout.LayoutParams.WRAP_CONTENT));
        
        ((LinearLayout.LayoutParams)mEtPassword.getLayoutParams()).topMargin = 30;
        
        // 错误提示
        mTvError = new TextView(this);
        mTvError.setTextColor(Color.parseColor("#EF5350"));
        mTvError.setTextSize(14);
        mTvError.setGravity(Gravity.CENTER);
        mLoginLayout.addView(mTvError);
        
        // 登录按钮
        Button btnLogin = new Button(this);
        btnLogin.setText("登录");
        btnLogin.setTextSize(20);
        btnLogin.setTextColor(Color.WHITE);
        btnLogin.setBackgroundColor(Color.parseColor("#4CAF50"));
        btnLogin.setPadding(40, 15, 40, 15);
        btnLogin.setOnClickListener(v -> verifyPassword());
        mLoginLayout.addView(btnLogin, new LinearLayout.LayoutParams(300, LinearLayout.LayoutParams.WRAP_CONTENT));
        
        ((LinearLayout.LayoutParams)btnLogin.getLayoutParams()).topMargin = 20;
        
        // 返回按钮
        Button btnBack = new Button(this);
        btnBack.setText("返回主界面");
        btnBack.setTextSize(16);
        btnBack.setTextColor(Color.parseColor("#90A4AE"));
        btnBack.setBackgroundColor(Color.TRANSPARENT);
        btnBack.setOnClickListener(v -> finish());
        mLoginLayout.addView(btnBack);
        
        setContentView(mLoginLayout);
    }
    
    private void verifyPassword() {
        String input = mEtPassword.getText().toString();
        String correct = mPrefs.getAdminPassword();
        
        if (input.equals(correct)) {
            showMenuUI();
        } else {
            mTvError.setText("密码错误");
            mEtPassword.setText("");
        }
    }
    
    private void showMenuUI() {
        mMenuLayout = new LinearLayout(this);
        mMenuLayout.setOrientation(LinearLayout.VERTICAL);
        mMenuLayout.setBackgroundColor(Color.parseColor("#263238"));
        mMenuLayout.setPadding(30, 30, 30, 30);
        
        // 标题
        LinearLayout titleBar = new LinearLayout(this);
        titleBar.setOrientation(LinearLayout.HORIZONTAL);
        titleBar.setGravity(Gravity.CENTER_VERTICAL);
        
        TextView title = new TextView(this);
        title.setText("⚙️ 管理员功能");
        title.setTextSize(24);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titleBar.addView(title);
        
        titleBar.addView(new View(this), new LinearLayout.LayoutParams(0, 0, 1f));
        
        Button btnBack = new Button(this);
        btnBack.setText("退出");
        btnBack.setTextColor(Color.WHITE);
        btnBack.setBackgroundColor(Color.parseColor("#455A64"));
        btnBack.setOnClickListener(v -> finish());
        titleBar.addView(btnBack);
        
        mMenuLayout.addView(titleBar);
        
        // 菜单按钮
        addMenuButton("🔓 开锁管理", () -> {
            Intent intent = new Intent(this, OpenLockActivity.class);
            startActivity(intent);
        });
        
        addMenuButton("⚙️ 系统设置", () -> {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        });
        
        addMenuButton("📊 设备状态", () -> showDeviceStatus());
        
        addMenuButton("🔄 重启服务", () -> restartService());
        
        addMenuButton("📱 关于", () -> showAbout());
        
        setContentView(mMenuLayout);
    }
    
    private void addMenuButton(String text, Runnable action) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(18);
        btn.setTextColor(Color.WHITE);
        btn.setBackgroundColor(Color.parseColor("#37474F"));
        btn.setPadding(30, 20, 30, 20);
        btn.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        btn.setOnClickListener(v -> action.run());
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        params.topMargin = 10;
        btn.setLayoutParams(params);
        
        mMenuLayout.addView(btn);
    }
    
    private void showDeviceStatus() {
        StringBuilder status = new StringBuilder();
        status.append("设备ID: ").append(mPrefs.getDeviceId()).append("\n\n");
        status.append("服务器: ").append(mPrefs.getServerUrl()).append("\n\n");
        status.append("串口: ").append(mPrefs.getSerialPort()).append("\n");
        status.append("波特率: ").append(mPrefs.getBaudRate()).append("\n\n");
        status.append("协议: ").append(mPrefs.getProtocolType()).append("\n");
        status.append("主板: ").append(mPrefs.getBoardNo()).append("~")
              .append(mPrefs.getBoardNo() + mPrefs.getBoardCount() - 1).append("\n\n");
        status.append("服务状态: ").append(
            com.smartlocker.screen.service.LockerService.isConnected() ? "已连接" : "未连接");
        
        new AlertDialog.Builder(this)
            .setTitle("📊 设备状态")
            .setMessage(status.toString())
            .setPositiveButton("确定", null)
            .show();
    }
    
    private void restartService() {
        new AlertDialog.Builder(this)
            .setTitle("重启服务")
            .setMessage("确定要重启后台服务吗？")
            .setPositiveButton("确定", (d, w) -> {
                Intent intent = new Intent(this, com.smartlocker.screen.service.LockerService.class);
                stopService(intent);
                
                mHandler.postDelayed(() -> {
                    startService(intent);
                    Toast.makeText(this, "服务已重启", Toast.LENGTH_SHORT).show();
                }, 500);
            })
            .setNegativeButton("取消", null)
            .show();
    }
    
    private void showAbout() {
        String info = "智能寄存柜屏幕端\n\n" +
                      "版本: " + SmartLockerApp.getInstance().getVersionName() + "\n" +
                      "构建: " + SmartLockerApp.getInstance().getVersionCode() + "\n\n" +
                      "基于YBM协议开发\n" +
                      "支持多主板级联";
        
        new AlertDialog.Builder(this)
            .setTitle("关于")
            .setMessage(info)
            .setPositiveButton("确定", null)
            .show();
    }
}
