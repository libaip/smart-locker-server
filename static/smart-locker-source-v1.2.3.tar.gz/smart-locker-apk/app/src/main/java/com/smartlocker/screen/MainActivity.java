package com.smartlocker.screen;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.common.BitMatrix;

import org.json.JSONObject;

import java.io.File;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.security.KeyStore;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import java.util.HashMap;
import java.util.Map;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import okhttp3.*;
import okhttp3.WebSocket;
import okhttp3.Response;



public class MainActivity extends Activity {

    private static final String TAG = "MainActivity";
    private static final String SERVER_URL = "http://locker.cqdyxl.com";
    private OkHttpClient mOkClient;
    private static final String PREFS_NAME = "locker_prefs";
    private static final int CURRENT_VERSION_CODE = 123;

    private SharedPreferences mPrefs;
    private String mCurrentQrData = "";
    private Handler mRefreshHandler = new Handler(Looper.getMainLooper());
    private static final int REFRESH_INTERVAL = 30000; // 30秒自动刷新
    private TextView tvRefreshTime;
    private Runnable mRefreshRunnable = new Runnable() {
        @Override
        public void run() {
            refreshSlotStatus();
            updateRefreshTime();
            mRefreshHandler.postDelayed(this, REFRESH_INTERVAL);
        }
    };

    private TextView tvStoreName, tvBusinessHours, tvCustomerPhone, tvAvailableCount, tvDeviceId, tvPickupBtn, tvVersion;
    private TextClock tcClock;
    private ImageView ivQrCode;
    private SerialPortManager mSerialPort;
    private WebSocket mMainWs;
    private android.app.ProgressDialog mProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        mPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        OkHttpClient.Builder okBuilder1 = new OkHttpClient.Builder();
        mOkClient = okBuilder1
                .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                .build();

        if (mPrefs.getBoolean("is_bound", false) && !mPrefs.getString("mainboard_id", "").isEmpty()) {
            showMainScreen();
        } else {
            showSetupScreen();
        }
    }

    private void showSetupScreen() {
        setContentView(R.layout.activity_setup);

        EditText etMainboardId = findViewById(R.id.etMainboardId);
        Button btnBind = findViewById(R.id.btnBind);
        ProgressBar pbSetup = findViewById(R.id.pbSetup);
        TextView tvSetupError = findViewById(R.id.tvSetupError);

        String lastMid = mPrefs.getString("mainboard_id", "");
        if (!lastMid.isEmpty()) {
            etMainboardId.setText(lastMid);
        }

        btnBind.setOnClickListener(v -> {
            String mainboardId = etMainboardId.getText().toString().trim();
            if (mainboardId.isEmpty()) {
                Toast.makeText(this, "请输入主板编号", Toast.LENGTH_SHORT).show();
                return;
            }
            btnBind.setEnabled(false);
            pbSetup.setVisibility(TextView.VISIBLE);
            tvSetupError.setVisibility(TextView.GONE);

            new Thread(() -> {
                try {
                    Request req = new Request.Builder().url(SERVER_URL + "/api/cabinets/by-mainboard/" + mainboardId).get().build();
                    Response resp = mOkClient.newCall(req).execute();
                    int code = resp.code();
                    String body = resp.body() != null ? resp.body().string() : "";
                    resp.close();
                    JSONObject json = new JSONObject(body);

                    if (code == 200 && json.has("data")) {
                        JSONObject data = json.getJSONObject("data");
                        SharedPreferences.Editor editor = mPrefs.edit();
                        editor.putString("mainboard_id", mainboardId);
                        editor.putBoolean("is_bound", true);
                        editor.putString("store_name", data.optString("location_name", data.optString("group_name", "智能寄存柜")));
                        editor.putString("business_hours", data.optString("business_hours", ""));
                        editor.putString("customer_phone", data.optString("customer_phone", ""));
                        editor.putString("cabinet_id", String.valueOf(data.optInt("id", 0)));
                        editor.putString("cabinet_code", data.optString("cabinet_code", ""));
                        editor.putString("charge_mode", data.optString("charge_mode", "deposit"));
                        editor.putString("deposit_amount", String.valueOf(data.optDouble("deposit_amount", 20)));
                        editor.putString("mainboard_source", data.optString("mainboard_source", "YBM"));
                        if (data.has("slots") && data.getJSONArray("slots").length() > 0) {
                            JSONObject firstSlot = data.getJSONArray("slots").getJSONObject(0);
                            editor.putString("serial_port", firstSlot.optString("serial_port", "ttyS1"));
                            editor.putInt("baud_rate", firstSlot.optInt("baud_rate", 9600));
                            editor.putString("board_type", firstSlot.optString("sr_mid_way", "YBM"));
                        } else {
                            editor.putString("serial_port", "ttyS1");
                            editor.putInt("baud_rate", 9600);
                            editor.putString("board_type", "YBM");
                        }
                        editor.apply();
                        runOnUiThread(() -> showMainScreen());
                    } else {
                        String msg = json.optString("message", "绑定失败，请检查主板编号");
                        runOnUiThread(() -> {
                            tvSetupError.setText(msg);
                            tvSetupError.setVisibility(TextView.VISIBLE);
                            btnBind.setEnabled(true);
                            pbSetup.setVisibility(TextView.GONE);
                        });
                    }
                } catch (Exception e) {
                    Log.e(TAG, "绑定失败", e);
                    runOnUiThread(() -> {
                        StringBuilder errMsg = new StringBuilder();
                        errMsg.append("v1.2.3 ").append(SERVER_URL).append(" ");
                        Throwable cause = e;
                        while (cause != null) {
                            errMsg.append(cause.getClass().getSimpleName()).append(": ").append(cause.getMessage()).append(" >> ");
                            cause = cause.getCause();
                        }
                        tvSetupError.setText(errMsg.toString());
                        Toast.makeText(MainActivity.this, "错误: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        tvSetupError.setVisibility(TextView.VISIBLE);
                        btnBind.setEnabled(true);
                        pbSetup.setVisibility(TextView.GONE);
                    });
                }
            }).start();
        });
    }

    private void showMainScreen() {
        setContentView(R.layout.activity_main);


        tvStoreName = findViewById(R.id.tvStoreName);
        tvBusinessHours = findViewById(R.id.tvBusinessHours);
        tvCustomerPhone = findViewById(R.id.tvCustomerPhone);
        tcClock = findViewById(R.id.tcClock);
        tvAvailableCount = findViewById(R.id.tvAvailableCount);
        tvPickupBtn = findViewById(R.id.tvPickupBtn);
        tvDeviceId = findViewById(R.id.tvDeviceId);
        tvVersion = findViewById(R.id.tvVersion);
        ivQrCode = findViewById(R.id.ivQrCode);

        // 刷新按钮
        TextView tvRefreshBtn = findViewById(R.id.tvRefreshBtn);
        tvRefreshTime = findViewById(R.id.tvRefreshTime);
        tvRefreshBtn.setOnClickListener(v -> {
            refreshSlotStatus();
            updateRefreshTime();
            Toast.makeText(this, "已刷新", Toast.LENGTH_SHORT).show();
        });
        // 启动自动刷新
        mRefreshHandler.postDelayed(mRefreshRunnable, REFRESH_INTERVAL);
        updateRefreshTime();

        tvPickupBtn.setOnClickListener(v -> showPickupDialog());

        tvStoreName.setText(mPrefs.getString("store_name", "智能寄存柜"));
        tvBusinessHours.setText(mPrefs.getString("business_hours", "8:00~22:00"));
        tvCustomerPhone.setText(mPrefs.getString("customer_phone", ""));
        tvDeviceId.setText(mPrefs.getString("mainboard_id", ""));
        tvVersion.setText("v1.2.1");

        generateQrCode();
        refreshSlotStatus();
        initSerialPort();
        initWebSocket();
        checkUpdate();
    }

    private void generateQrCode() {
        String mainboardId = mPrefs.getString("mainboard_id", "");
        final String content = "http://locker.cqdyxl.com/locker?device=" + mainboardId;
        if (content.equals(mCurrentQrData)) return;
        mCurrentQrData = content;

        new Thread(() -> {
            try {
                int size = 800;
                QRCodeWriter writer = new QRCodeWriter();
                Map hints = new HashMap<>();
                hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
                hints.put(EncodeHintType.MARGIN, 2);
                BitMatrix bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size, hints);
                int width = bitMatrix.getWidth();
                int height = bitMatrix.getHeight();
                int[] pixels = new int[width * height];
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        pixels[y * width + x] = bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF;
                    }
                }
                Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
                runOnUiThread(() -> ivQrCode.setImageBitmap(bitmap));
            } catch (Exception e) {
                Log.e(TAG, "生成二维码失败", e);
            }
        }).start();
    }

    private void updateRefreshTime() {
        if (tvRefreshTime != null) {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault());
            tvRefreshTime.setText(sdf.format(new java.util.Date()) + " \u66f4\u65b0");
        }
    }

    private void refreshSlotStatus() {
        String mainboardId = mPrefs.getString("mainboard_id", "");
        if (mainboardId.isEmpty()) return;
        new Thread(() -> {
            try {
                Request req = new Request.Builder().url(SERVER_URL + "/api/cabinets/by-mainboard/" + mainboardId).get().build();
                Response resp = mOkClient.newCall(req).execute();
                String body = resp.body() != null ? resp.body().string() : "";
                resp.close();
                JSONObject json = new JSONObject(body);
                if (json.has("data")) {
                    JSONObject data = json.getJSONObject("data");
                    int available = data.optInt("available_slots", 0);
                    runOnUiThread(() -> tvAvailableCount.setText(String.valueOf(available)));
                }
            } catch (Exception e) {
                Log.e(TAG, "刷新状态失败", e);
            }
        }).start();
    }

    private void showPickupDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("密码取包");
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);
        final EditText etPhone = new EditText(this);
        etPhone.setHint("手机号");
        etPhone.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        layout.addView(etPhone);
        final EditText etCode = new EditText(this);
        etCode.setHint("4位密码");
        etCode.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etCode.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(4)});
        layout.addView(etCode);
        builder.setView(layout);
        builder.setPositiveButton("取包", (dialog, which) -> {
            String phone = etPhone.getText().toString().trim();
            String code = etCode.getText().toString().trim();
            if (phone.isEmpty() || code.isEmpty()) {
                Toast.makeText(this, "请输入手机号和密码", Toast.LENGTH_SHORT).show();
                return;
            }
            new Thread(() -> {
                try {
                    JSONObject postData = new JSONObject();
                    postData.put("device", mPrefs.getString("mainboard_id", ""));
                    postData.put("phone", phone);
                    postData.put("password", code);
                    URL url = new URL(SERVER_URL + "/api/h5/retrieve");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);
                    java.io.OutputStream os = conn.getOutputStream();
                    os.write(postData.toString().getBytes("UTF-8"));
                    os.close();
                    int respCode = conn.getResponseCode();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(
                        respCode == 200 ? conn.getInputStream() : conn.getErrorStream()));
                    StringBuilder sb = new StringBuilder();
                    String rl;
                    while ((rl = reader.readLine()) != null) sb.append(rl);
                    reader.close();
                    JSONObject json = new JSONObject(sb.toString());
                    String msg = json.optString("message", "");
                    if (respCode == 200) {
                        runOnUiThread(() -> Toast.makeText(this, "取包成功，柜门已开", Toast.LENGTH_LONG).show());
                        refreshSlotStatus();
                    } else {
                        runOnUiThread(() -> Toast.makeText(this, msg.isEmpty() ? "取包失败" : msg, Toast.LENGTH_LONG).show());
                    }
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(this, "网络错误", Toast.LENGTH_SHORT).show());
                }
            }).start();
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }

    private void checkUpdate() {
        new Thread(() -> {
            try {
                Request req = new Request.Builder().url(SERVER_URL + "/api/app/version").get().build();
                Response resp = mOkClient.newCall(req).execute();
                if (resp.code() == 200) {
                    String respBody = resp.body() != null ? resp.body().string() : "";
                    resp.close();
                    JSONObject json = new JSONObject(respBody);
                    JSONObject data = json.optJSONObject("data");
                    if (data == null) data = json;
                    int newVersion = data.optInt("version_code", 1);
                    String downloadUrl = data.optString("download_url", "");
                    String versionName = data.optString("version_name", "");
                    String updateLog = data.optString("update_log", data.optString("update_desc", ""));
                    if (newVersion > CURRENT_VERSION_CODE && !downloadUrl.isEmpty()) {
                        Log.i(TAG, "发现新版本: " + versionName + " (" + newVersion + ")");
                        runOnUiThread(() -> showUpdateDialog(versionName, updateLog, downloadUrl, false));
                    } else {
                        Log.i(TAG, "当前已是最新版本");
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "检查更新失败", e);
            }
        }).start();
    }

    private void showUpdateDialog(String versionName, String desc, String downloadUrl, boolean force) {
        String msg = "发现新版本: " + versionName;
        if (desc != null && !desc.isEmpty()) msg += "\n\n" + desc;
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
            .setTitle("版本更新")
            .setMessage(msg)
            .setCancelable(!force);
        if (force) {
            builder.setPositiveButton("立即更新", (d, w) -> downloadAndInstall(downloadUrl));
        } else {
            builder.setPositiveButton("立即更新", (d, w) -> downloadAndInstall(downloadUrl))
                   .setNegativeButton("稍后再说", null);
        }
        builder.show();
    }

    private void downloadAndInstall(String downloadUrl) {
        new Thread(() -> {
            try {
                // Show progress dialog
                runOnUiThread(() -> {
                    if (mProgressDialog == null) {
                        mProgressDialog = new android.app.ProgressDialog(this);
                        mProgressDialog.setTitle("正在下载更新");
                        mProgressDialog.setProgressStyle(android.app.ProgressDialog.STYLE_HORIZONTAL);
                        mProgressDialog.setMax(100);
                        mProgressDialog.setCancelable(false);
                    }
                    mProgressDialog.setProgress(0);
                    mProgressDialog.setMessage("下载中...");
                    mProgressDialog.show();
                });

                URL url = new URL(downloadUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(120000);
                int fileSize = conn.getContentLength();

                File apkFile = new File(getCacheDir(), "smart-locker-update.apk");
                java.io.InputStream is = conn.getInputStream();
                java.io.FileOutputStream fos = new java.io.FileOutputStream(apkFile);
                byte[] buffer = new byte[8192];
                int len, totalRead = 0;
                while ((len = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len);
                    totalRead += len;
                    if (fileSize > 0) {
                        int progress = (int) (totalRead * 100L / fileSize);
                        runOnUiThread(() -> {
                            if (mProgressDialog != null && mProgressDialog.isShowing())
                                mProgressDialog.setProgress(progress);
                        });
                    }
                }
                fos.close();
                is.close();

                runOnUiThread(() -> {
                    if (mProgressDialog != null && mProgressDialog.isShowing()) {
                        mProgressDialog.setMessage("下载完成，正在安装...");
                        mProgressDialog.setProgress(100);
                    }
                });

                Log.i(TAG, "下载完成，开始安装");

                // Try PackageInstaller for silent install (system app)
                try {
                    PackageInstaller installer = getPackageManager().getPackageInstaller();
                    PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(
                        PackageInstaller.SessionParams.MODE_FULL_INSTALL);
                    int sessionId = installer.createSession(params);
                    PackageInstaller.Session session = installer.openSession(sessionId);

                    java.io.OutputStream out = session.openWrite("package", 0, apkFile.length());
                    java.io.FileInputStream fis = new java.io.FileInputStream(apkFile);
                    byte[] buf = new byte[65536];
                    int size;
                    while ((size = fis.read(buf)) != -1) {
                        out.write(buf, 0, size);
                    }
                    session.fsync(out);
                    out.close();
                    fis.close();

                    Intent resultIntent = new Intent(this, InstallResultReceiver.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this,
                        sessionId, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    session.commit(pendingIntent.getIntentSender());
                    session.close();

                    runOnUiThread(() -> Toast.makeText(this, "正在安装更新...", Toast.LENGTH_SHORT).show());
                } catch (Exception installErr) {
                    // Fallback: open APK with system installer
                    Log.w(TAG, "PackageInstaller failed, trying intent installer: " + installErr.getMessage());
                    runOnUiThread(() -> {
                        try {
                            if (mProgressDialog != null && mProgressDialog.isShowing())
                                mProgressDialog.dismiss();
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            if (android.os.Build.VERSION.SDK_INT >= 24) {
                                intent.setDataAndType(androidx.core.content.FileProvider.getUriForFile(this,
                                    getPackageName() + ".fileprovider", apkFile),
                                    "application/vnd.android.package-archive");
                                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            } else {
                                intent.setDataAndType(android.net.Uri.fromFile(apkFile),
                                    "application/vnd.android.package-archive");
                            }
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        } catch (Exception e2) {
                            Toast.makeText(this, "安装失败: " + e2.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            } catch (Exception e) {
                Log.e(TAG, "下载更新失败", e);
                runOnUiThread(() -> {
                    if (mProgressDialog != null && mProgressDialog.isShowing())
                        mProgressDialog.dismiss();
                    Toast.makeText(this, "更新失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void initSerialPort() {
        try {
            String serialPort = mPrefs.getString("serial_port", "ttyS1");
            int baudRate = mPrefs.getInt("baud_rate", 9600);
            mSerialPort = new SerialPortManager(SerialPortManager.SerialType.BaseSerial);
            boolean opened = mSerialPort.open("/dev/" + serialPort, baudRate);
            if (!opened) {
                Log.e(TAG, "串口打开失败");
            }
        } catch (Exception e) {
            Log.e(TAG, "串口初始化失败", e);
        }
    }

    private WebSocket mMainWsHeartbeat;

    private void initWebSocket() {
        try {
            String deviceId = mPrefs.getString("mainboard_id", "");
            if (deviceId.isEmpty()) {
                Log.w(TAG, "No mainboard_id, skip WebSocket");
                return;
            }

            String wsUrl = "ws://locker.cqdyxl.com/ws/?device_id=" + deviceId;
            Log.i(TAG, "WS connecting: " + wsUrl);

                    OkHttpClient.Builder wsBuilder = new OkHttpClient.Builder();
                    OkHttpClient client = wsBuilder
                    .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(0, java.util.concurrent.TimeUnit.MINUTES)
                    .pingInterval(20, java.util.concurrent.TimeUnit.SECONDS)
                    .build();

            Request request = new Request.Builder().url(wsUrl).build();

            mMainWs = client.newWebSocket(request, new WebSocketListener() {
                @Override
                public void onOpen(WebSocket ws, Response response) {
                    Log.i(TAG, "WS Connected");
                    try {
                        JSONObject reg = new JSONObject();
                        reg.put("type", "register");
                        reg.put("device_id", deviceId);
                        reg.put("version", "1.2.3");
                        reg.put("deviceType", "LOCKER_SCREEN");
                        ws.send(reg.toString());
                        Log.i(TAG, "WS Registered: " + deviceId);

                        // Start heartbeat
                        startMainWsHeartbeat(ws, deviceId);
                    } catch (Exception e) {
                        Log.e(TAG, "WS Register err: " + e.getMessage());
                    }
                }

                @Override
                public void onMessage(WebSocket ws, String text) {
                    try {
                        JSONObject json = new JSONObject(text);
                        String type = json.optString("type", "");

                        if ("open_lock".equals(type)) {
                            int boardNo = json.optInt("board_no", json.optInt("boardNo", 1));
                            int lockNo = json.optInt("lock_no", json.optInt("lockNo", 1));
                            String protocol = json.optString("protocol", "YBM");
                            String orderId = json.optString("order_id", json.optString("orderId", ""));
                            Log.i(TAG, "WS open_lock: board=" + boardNo + " lock=" + lockNo + " proto=" + protocol);
                            openLockViaSerial(boardNo, lockNo, protocol);
                        } else if ("force_update".equals(type)) {
                            String downloadUrl = json.optString("download_url", "");
                            String versionName = json.optString("version_name", "");
                            int newVersion = json.optInt("version_code", 0);
                            boolean force = json.optBoolean("force", false);
                            String desc = json.optString("update_desc", "");
                            Log.i(TAG, "WS force_update: version=" + versionName);
                            if (newVersion > CURRENT_VERSION_CODE && !downloadUrl.isEmpty()) {
                                runOnUiThread(() -> showUpdateDialog(versionName, desc, downloadUrl, force));
                            }
                        } else if ("heartbeat_ack".equals(type)) {
                            Log.d(TAG, "WS heartbeat_ack");
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "WS onMessage err: " + e.getMessage());
                    }
                }

                @Override
                public void onFailure(WebSocket ws, Throwable t, Response resp) {
                    Log.e(TAG, "WS onFailure: " + t.getMessage());
                    // Reconnect after delay
                    new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> initWebSocket(), 5000);
                }

                @Override
                public void onClosed(WebSocket ws, int code, String reason) {
                    Log.w(TAG, "WS onClosed: " + code + " " + reason);
                    new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> initWebSocket(), 5000);
                }
            });

        } catch (Exception e) {
            Log.e(TAG, "WS init failed: " + e.getMessage());
        }
    }

    private void startMainWsHeartbeat(WebSocket ws, String deviceId) {
        final Thread t = new Thread(() -> {
            while (!Thread.interrupted()) {
                try {
                    Thread.sleep(25000);
                    JSONObject hb = new JSONObject();
                    hb.put("type", "heartbeat");
                    hb.put("device_id", deviceId);
                    hb.put("timestamp", System.currentTimeMillis());
                    hb.put("status", "online");
                    ws.send(hb.toString());
                } catch (Exception e) {
                    break;
                }
            }
        });
        t.setDaemon(true);
        t.start();
        mMainWsHeartbeat = null; // thread reference not needed, daemon auto-exits
    }

    private void openLockViaSerial(int boardNo, int lockNo, String protocol) {
        new Thread(() -> {
            try {
                // Always re-init serial to pick up latest config from prefs
                if (mSerialPort != null) { mSerialPort.close(); mSerialPort = null; }
                initSerialPort();
                
                // YBM protocol: [addr] [0x4F] [lock_no] [XOR checksum]
                int addr = 0x01;
                int cmd = 0x4F;
                int xor = addr ^ cmd ^ lockNo;
                byte[] command = new byte[]{(byte)addr, (byte)cmd, (byte)lockNo, (byte)xor};
                String hexStr = String.format("%02X %02X %02X %02X", addr, cmd, lockNo, xor);
                Log.i(TAG, "Serial YBM cmd: " + hexStr);

                if (mSerialPort != null && mSerialPort.isOpened()) {
                    mSerialPort.write(command);
                    Log.i(TAG, "Serial sent OK");
                } else {
                    Log.e(TAG, "Serial still not available after re-init");
                }
            } catch (Exception e) {
                Log.e(TAG, "openLockViaSerial err: " + e.getMessage());
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mMainWs != null) { mMainWs.close(1000, "exit"); mMainWs = null; }
        mRefreshHandler.removeCallbacks(mRefreshRunnable);
        if (mSerialPort != null) mSerialPort.close();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mPrefs.getBoolean("is_bound", false)) refreshSlotStatus();
    }

    public static class InstallResultReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
                String msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                if (status == PackageInstaller.STATUS_SUCCESS) {
                    Log.i("Update", "自动安装成功");
                } else {
                    Log.e("Update", "自动安装失败: " + status + " " + msg);
                }
            }
        }
    }



}
