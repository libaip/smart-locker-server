package com.smartlocker.screen;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.*;
import android.widget.*;
import java.util.List;
import android.content.ContentValues;import android.graphics.Typeface;;
import com.smartlocker.screen.db.DBHelper;
import com.smartlocker.screen.utils.PreferencesHelper;

/**
 * 开锁界面 - 管理员开锁或取件
 */
public class OpenLockActivity extends Activity {
    private static final String TAG = "OpenLockActivity";
    
    private PreferencesHelper mPrefs;
    private DBHelper mDB;
    private Handler mHandler;
    
    private TextView mTvTitle;
    private Spinner mSpBoard;
    private Spinner mSpLock;
    private Button mBtnOpen;
    private TextView mTvStatus;
    private ListView mLvRecords;
    
    private int[] mBoardList;
    private int mSelectedBoard = 1;
    private int mSelectedLock = 1;
    
    private ConnectionReceiver mConnectionReceiver;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        mPrefs = new PreferencesHelper(this);
        mDB = DBHelper.getInstance(this);
        mHandler = new Handler(Looper.getMainLooper());
        
        buildUI();
        initData();
        registerReceiver();
    }
    
    private void buildUI() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#263238"));
        layout.setPadding(30, 30, 30, 30);
        
        // 标题栏
        LinearLayout titleBar = new LinearLayout(this);
        titleBar.setOrientation(LinearLayout.HORIZONTAL);
        titleBar.setGravity(Gravity.CENTER_VERTICAL);
        
        mTvTitle = new TextView(this);
        mTvTitle.setText("🔓 开锁管理");
        mTvTitle.setTextSize(24);
        mTvTitle.setTextColor(Color.WHITE);
        mTvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        titleBar.addView(mTvTitle);
        
        titleBar.addView(new View(this), new LinearLayout.LayoutParams(0, 0, 1f));
        
        Button btnBack = new Button(this);
        btnBack.setText("返回");
        btnBack.setTextColor(Color.WHITE);
        btnBack.setBackgroundColor(Color.parseColor("#455A64"));
        btnBack.setOnClickListener(v -> finish());
        titleBar.addView(btnBack);
        
        layout.addView(titleBar);
        
        // 主板选择
        LinearLayout boardRow = new LinearLayout(this);
        boardRow.setPadding(0, 30, 0, 10);
        
        TextView boardLabel = new TextView(this);
        boardLabel.setText("主板: ");
        boardLabel.setTextSize(18);
        boardLabel.setTextColor(Color.WHITE);
        boardRow.addView(boardLabel);
        
        mSpBoard = new Spinner(this);
        mSpBoard.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mSelectedBoard = mBoardList[position];
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        boardRow.addView(mSpBoard, new LinearLayout.LayoutParams(200, LinearLayout.LayoutParams.WRAP_CONTENT));
        
        layout.addView(boardRow);
        
        // 锁号选择
        LinearLayout lockRow = new LinearLayout(this);
        lockRow.setPadding(0, 10, 0, 10);
        
        TextView lockLabel = new TextView(this);
        lockLabel.setText("锁号: ");
        lockLabel.setTextSize(18);
        lockLabel.setTextColor(Color.WHITE);
        lockRow.addView(lockLabel);
        
        mSpLock = new Spinner(this);
        lockRow.addView(mSpLock, new LinearLayout.LayoutParams(200, LinearLayout.LayoutParams.WRAP_CONTENT));
        
        layout.addView(lockRow);
        
        // 开锁按钮
        mBtnOpen = new Button(this);
        mBtnOpen.setText("🔓 开 锁");
        mBtnOpen.setTextSize(24);
        mBtnOpen.setTextColor(Color.WHITE);
        mBtnOpen.setBackgroundColor(Color.parseColor("#4CAF50"));
        mBtnOpen.setPadding(30, 20, 30, 20);
        mBtnOpen.setOnClickListener(v -> performOpenLock());
        layout.addView(mBtnOpen);
        
        // 全开按钮
        Button btnOpenAll = new Button(this);
        btnOpenAll.setText("🔓 全 开");
        btnOpenAll.setTextSize(20);
        btnOpenAll.setTextColor(Color.WHITE);
        btnOpenAll.setBackgroundColor(Color.parseColor("#FF9800"));
        btnOpenAll.setPadding(30, 15, 30, 15);
        btnOpenAll.setOnClickListener(v -> performOpenAll());
        layout.addView(btnOpenAll);
        
        // 状态显示
        mTvStatus = new TextView(this);
        mTvStatus.setTextColor(Color.parseColor("#90CAF9"));
        mTvStatus.setTextSize(14);
        mTvStatus.setPadding(0, 20, 0, 10);
        layout.addView(mTvStatus);
        
        // 分隔线
        View divider = new View(this);
        divider.setBackgroundColor(Color.parseColor("#37474F"));
        layout.addView(divider, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 2));
        
        // 开锁记录
        TextView recordTitle = new TextView(this);
        recordTitle.setText("📋 最近开锁记录");
        recordTitle.setTextSize(16);
        recordTitle.setTextColor(Color.parseColor("#B0BEC5"));
        recordTitle.setPadding(0, 10, 0, 10);
        layout.addView(recordTitle);
        
        mLvRecords = new ListView(this);
        mLvRecords.setBackgroundColor(Color.parseColor("#37474F"));
        layout.addView(mLvRecords, new LinearLayout.LayoutParams(0, 0, 1f));
        
        setContentView(layout);
    }
    
    private void initData() {
        // 初始化主板列表
        mBoardList = mPrefs.getBoardNoList();
        String[] boardNames = new String[mBoardList.length];
        for (int i = 0; i < mBoardList.length; i++) {
            boardNames[i] = "主板 " + mBoardList[i];
        }
        
        ArrayAdapter<String> boardAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_dropdown_item, boardNames);
        mSpBoard.setAdapter(boardAdapter);
        
        // 初始化锁号列表（假设每板12个锁）
        updateLockSpinner(12);
        
        // 更新连接状态
        updateConnectionStatus();
        
        // 加载开锁记录
        loadRecords();
    }
    
    private void updateLockSpinner(int lockCount) {
        String[] lockNames = new String[lockCount];
        for (int i = 1; i <= lockCount; i++) {
            lockNames[i - 1] = "锁 " + i;
        }
        
        ArrayAdapter<String> lockAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_dropdown_item, lockNames);
        mSpLock.setAdapter(lockAdapter);
    }
    
    private void updateConnectionStatus() {
        boolean connected = com.smartlocker.screen.service.LockerService.isConnected();
        if (connected) {
            mTvStatus.setText("状态: 已连接服务器 ✅");
        } else {
            mTvStatus.setText("状态: 未连接 ⚠️");
        }
    }
    
    private void loadRecords() {
        java.util.List<android.content.ContentValues> records = mDB.getRecentRecords(20);
        String[] items = new String[records.size()];
        
        for (int i = 0; i < records.size(); i++) {
            ContentValues record = records.get(i);
            String time = record.getAsString(DBHelper.COL_OPEN_TIME);
            int board = record.getAsInteger(DBHelper.COL_BOARD_NO);
            int lock = record.getAsInteger(DBHelper.COL_LOCK_NO);
            int result = record.getAsInteger(DBHelper.COL_RESULT);
            
            items[i] = String.format("%s | 板%d-锁%d | %s", 
                time != null ? time : "",
                board, lock,
                result == 1 ? "✅成功" : "❌失败");
        }
        
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_list_item_1, items);
        mLvRecords.setAdapter(adapter);
    }
    
    private void performOpenLock() {
        if (!com.smartlocker.screen.service.LockerService.isServiceRunning()) {
            showToast("服务未运行");
            return;
        }
        
        mBtnOpen.setEnabled(false);
        mBtnOpen.setText("开锁中...");
        
        com.smartlocker.screen.service.LockerService.triggerManualOpen(mSelectedBoard, mSelectedLock);
        
        mHandler.postDelayed(() -> {
            mBtnOpen.setEnabled(true);
            mBtnOpen.setText("🔓 开 锁");
            showToast("开锁指令已发送");
            loadRecords();
        }, 1000);
    }
    
    private void performOpenAll() {
        if (!com.smartlocker.screen.service.LockerService.isServiceRunning()) {
            showToast("服务未运行");
            return;
        }
        
        new AlertDialog.Builder(this)
            .setTitle("确认全开")
            .setMessage("确定要打开所有柜门吗？")
            .setPositiveButton("确定", (d, w) -> {
                com.smartlocker.screen.service.LockerService.triggerOpenAll();
                showToast("全开指令已发送");
                loadRecords();
            })
            .setNegativeButton("取消", null)
            .show();
    }
    
    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
    
    private void registerReceiver() {
        mConnectionReceiver = new ConnectionReceiver();
        IntentFilter filter = new IntentFilter("com.smartlocker.CONNECTION_CHANGED");
        registerReceiver(mConnectionReceiver, filter);
    }
    
    private class ConnectionReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean connected = intent.getBooleanExtra("connected", false);
            mHandler.post(() -> updateConnectionStatus());
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        updateConnectionStatus();
        loadRecords();
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mConnectionReceiver != null) {
            unregisterReceiver(mConnectionReceiver);
        }
    }
}
