package com.smartlocker.screen;
import java.io.IOException;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.*;
import android.widget.*;import android.graphics.Typeface;;
import com.smartlocker.screen.db.DBHelper;
import com.smartlocker.screen.utils.PreferencesHelper;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;
import okhttp3.*;

/**
 * 订单界面 - 寄存和取件流程
 */
public class OrderActivity extends Activity {
    private static final String TAG = "OrderActivity";
    
    private String mMode;  // "deposit" 或 "retrieve"
    
    private LinearLayout mLayout;
    private TextView mTvTitle;
    private TextView mTvInstructions;
    private EditText mEtInput;
    private Button mBtnConfirm;
    private TextView mTvResult;
    
    private PreferencesHelper mPrefs;
    private DBHelper mDB;
    private Handler mHandler;
    private OkHttpClient mHttpClient;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        mPrefs = new PreferencesHelper(this);
        mDB = DBHelper.getInstance(this);
        mHandler = new Handler(Looper.getMainLooper());
        mHttpClient = new OkHttpClient();
        
        Intent intent = getIntent();
        mMode = intent.getStringExtra("mode");
        if (mMode == null) mMode = "deposit";
        
        buildUI();
    }
    
    private void buildUI() {
        mLayout = new LinearLayout(this);
        mLayout.setOrientation(LinearLayout.VERTICAL);
        mLayout.setBackgroundColor(Color.parseColor("#E3F2FD"));
        mLayout.setPadding(40, 40, 40, 40);
        mLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        
        // 标题栏
        LinearLayout titleBar = new LinearLayout(this);
        titleBar.setOrientation(LinearLayout.HORIZONTAL);
        titleBar.setGravity(Gravity.CENTER_VERTICAL);
        titleBar.setBackgroundColor(Color.parseColor("#1976D2"));
        titleBar.setPadding(20, 15, 20, 15);
        
        mTvTitle = new TextView(this);
        mTvTitle.setTextSize(24);
        mTvTitle.setTextColor(Color.WHITE);
        mTvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        titleBar.addView(mTvTitle);
        
        titleBar.addView(new View(this), new LinearLayout.LayoutParams(0, 0, 1f));
        
        Button btnBack = new Button(this);
        btnBack.setText("返回");
        btnBack.setTextColor(Color.WHITE);
        btnBack.setBackgroundColor(Color.TRANSPARENT);
        btnBack.setOnClickListener(v -> finish());
        titleBar.addView(btnBack);
        
        mLayout.addView(titleBar);
        
        // 内容区域
        LinearLayout contentLayout = new LinearLayout(this);
        contentLayout.setOrientation(LinearLayout.VERTICAL);
        contentLayout.setGravity(Gravity.CENTER);
        contentLayout.setPadding(40, 60, 40, 40);
        
        // 说明文字
        mTvInstructions = new TextView(this);
        mTvInstructions.setTextSize(20);
        mTvInstructions.setTextColor(Color.parseColor("#1565C0"));
        mTvInstructions.setGravity(Gravity.CENTER);
        mTvInstructions.setLineSpacing(5, 1.2f);
        contentLayout.addView(mTvInstructions);
        
        // 输入框
        mEtInput = new EditText(this);
        mEtInput.setHint("请输入手机号或取件码");
        mEtInput.setTextSize(24);
        mEtInput.setGravity(Gravity.CENTER);
        mEtInput.setBackgroundColor(Color.WHITE);
        mEtInput.setPadding(20, 20, 20, 20);
        mEtInput.setInputType(InputType.TYPE_CLASS_PHONE);
        contentLayout.addView(mEtInput, new LinearLayout.LayoutParams(
            500, LinearLayout.LayoutParams.WRAP_CONTENT));
        
        ((LinearLayout.LayoutParams)mEtInput.getLayoutParams()).topMargin = 30;
        
        // 确认按钮
        mBtnConfirm = new Button(this);
        mBtnConfirm.setText("确认");
        mBtnConfirm.setTextSize(22);
        mBtnConfirm.setTextColor(Color.WHITE);
        mBtnConfirm.setBackgroundColor(Color.parseColor("#4CAF50"));
        mBtnConfirm.setPadding(40, 20, 40, 20);
        mBtnConfirm.setOnClickListener(v -> onConfirm());
        contentLayout.addView(mBtnConfirm, new LinearLayout.LayoutParams(
            300, LinearLayout.LayoutParams.WRAP_CONTENT));
        
        ((LinearLayout.LayoutParams)mBtnConfirm.getLayoutParams()).topMargin = 30;
        
        // 结果显示
        mTvResult = new TextView(this);
        mTvResult.setTextSize(18);
        mTvResult.setTextColor(Color.parseColor("#333333"));
        mTvResult.setGravity(Gravity.CENTER);
        mTvResult.setVisibility(View.GONE);
        contentLayout.addView(mTvResult);
        
        mLayout.addView(contentLayout);
        
        setContentView(mLayout);
        
        // 根据模式设置UI
        if ("deposit".equals(mMode)) {
            mTvTitle.setText("📦 我要寄存");
            mTvInstructions.setText("请输入您的手机号码\n我们将为您分配一个空闲柜门");
            mEtInput.setHint("请输入手机号");
        } else {
            mTvTitle.setText("🔑 密码取包");
            mTvInstructions.setText("请输入取件码\n验证码通过短信发送");
            mEtInput.setHint("请输入取件码");
            mEtInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        }
    }
    
    private void onConfirm() {
        String input = mEtInput.getText().toString().trim();
        
        if (input.isEmpty()) {
            showError("请输入内容");
            return;
        }
        
        if ("deposit".equals(mMode)) {
            processDeposit(input);
        } else {
            processRetrieve(input);
        }
    }
    
    /**
     * 处理寄存
     */
    private void processDeposit(String phone) {
        mBtnConfirm.setEnabled(false);
        mBtnConfirm.setText("处理中...");
        
        String url = mPrefs.getServerUrl() + "/api/deposit/create-order";
        
        JSONObject body = new JSONObject();
        try {
            body.put("deviceId", mPrefs.getDeviceId());
            body.put("phone", phone);
        } catch (Exception e) {}
        
        RequestBody requestBody = RequestBody.create(
            MediaType.parse("application/json"), body.toString());
        
        Request request = new Request.Builder()
            .url(url)
            .post(requestBody)
            .build();
        
        mHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mHandler.post(() -> {
                    mBtnConfirm.setEnabled(true);
                    mBtnConfirm.setText("确认");
                    showError("网络请求失败: " + e.getMessage());
                });
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    String respBody = response.body().string();
                    JSONObject json = new JSONObject(respBody);
                    
                    int code = json.optInt("code", -1);
                    if (code == 0) {
                        // 成功
                        JSONObject data = json.optJSONObject("data");
                        String orderId = data.optString("orderId");
                        int boardNo = data.optInt("boardNo");
                        int lockNo = data.optInt("lockNo");
                        String pwd = data.optString("password");
                        
                        mHandler.post(() -> showDepositSuccess(orderId, boardNo, lockNo, pwd));
                    } else {
                        String msg = json.optString("msg", "下单失败");
                        mHandler.post(() -> {
                            mBtnConfirm.setEnabled(true);
                            mBtnConfirm.setText("确认");
                            showError(msg);
                        });
                    }
                } catch (Exception e) {
                    mHandler.post(() -> {
                        mBtnConfirm.setEnabled(true);
                        mBtnConfirm.setText("确认");
                        showError("解析响应失败");
                    });
                }
            }
        });
    }
    
    /**
     * 处理取件
     */
    private void processRetrieve(String code) {
        mBtnConfirm.setEnabled(false);
        mBtnConfirm.setText("验证中...");
        
        String url = mPrefs.getServerUrl() + "/api/retrieve/verify";
        
        JSONObject body = new JSONObject();
        try {
            body.put("deviceId", mPrefs.getDeviceId());
            body.put("code", code);
        } catch (Exception e) {}
        
        RequestBody requestBody = RequestBody.create(
            MediaType.parse("application/json"), body.toString());
        
        Request request = new Request.Builder()
            .url(url)
            .post(requestBody)
            .build();
        
        mHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mHandler.post(() -> {
                    mBtnConfirm.setEnabled(true);
                    mBtnConfirm.setText("确认");
                    showError("网络请求失败");
                });
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    String respBody = response.body().string();
                    JSONObject json = new JSONObject(respBody);
                    
                    int code = json.optInt("code", -1);
                    if (code == 0) {
                        JSONObject data = json.optJSONObject("data");
                        String orderId = data.optString("orderId");
                        int boardNo = data.optInt("boardNo");
                        int lockNo = data.optInt("lockNo");
                        
                        mHandler.post(() -> confirmRetrieve(orderId, boardNo, lockNo));
                    } else {
                        String msg = json.optString("msg", "验证失败");
                        mHandler.post(() -> {
                            mBtnConfirm.setEnabled(true);
                            mBtnConfirm.setText("确认");
                            showError(msg);
                        });
                    }
                } catch (Exception e) {
                    mHandler.post(() -> {
                        mBtnConfirm.setEnabled(true);
                        mBtnConfirm.setText("确认");
                        showError("验证失败");
                    });
                }
            }
        });
    }
    
    /**
     * 确认取件并开锁
     */
    private void confirmRetrieve(String orderId, int boardNo, int lockNo) {
        // 调用开锁
        com.smartlocker.screen.service.LockerService.triggerManualOpen(boardNo, lockNo);
        
        // 显示成功
        mTvResult.setVisibility(View.VISIBLE);
        mTvResult.setText("✅ 柜门已打开\n请取出您的物品\n记得关好柜门哦！");
        mTvResult.setTextColor(Color.parseColor("#4CAF50"));
        
        // 记录
        mDB.recordOpenLock(orderId, boardNo, lockNo, 0, true);
        
        mHandler.postDelayed(this::finish, 3000);
    }
    
    /**
     * 显示寄存成功
     */
    private void showDepositSuccess(String orderId, int boardNo, int lockNo, String password) {
        mBtnConfirm.setEnabled(true);
        mBtnConfirm.setText("确认");
        
        mTvResult.setVisibility(View.VISIBLE);
        mTvResult.setText("✅ 寄存成功！\n\n" +
                "📦 柜门: " + boardNo + "-" + lockNo + "\n\n" +
                "🔑 取件码: " + password + "\n\n" +
                "⚠️ 请牢记取件码！");
        mTvResult.setTextColor(Color.parseColor("#4CAF50"));
        
        // 保存订单
        // TODO: 保存到本地数据库
    }
    
    private void showError(String msg) {
        mTvResult.setVisibility(View.VISIBLE);
        mTvResult.setText("❌ " + msg);
        mTvResult.setTextColor(Color.parseColor("#F44336"));
    }
}
