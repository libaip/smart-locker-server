package com.smartlocker.screen;

import android.util.Log;

/**
 * QM锁控板协议实现
 * 
 * 帧格式: [0x5A] [功能码] [板地址H] [板地址L] [锁号H] [锁号L] [XOR_CHECKSUM]
 * XOR校验 = 前6字节依次异或
 * 
 * 支持功能:
 * - 0x23 开锁
 * - 0x22 查询锁状态
 */
public class QMProtocol {
    private static final String TAG = "QM";

    // 帧头
    public static final int FRAME_HEAD = 0x5A;

    // 功能码
    public static final int FUNC_OPEN_LOCK = 0x23;        // 开锁
    public static final int FUNC_OPEN_LOCK_RESP = 0xA3;   // 开锁响应
    public static final int FUNC_READ_STATUS = 0x22;      // 查询锁状态
    public static final int FUNC_READ_STATUS_RESP = 0x9E; // 状态查询响应

    // 开锁结果
    public static final int RESULT_SUCCESS = 1;
    public static final int RESULT_TIMEOUT = -1;
    public static final int RESULT_FAIL = -2;
    public static final int RESULT_CHECKSUM_ERROR = -3;
    public static final int RESULT_FORMAT_ERROR = -4;

    private SerialPortManager mSerialPort;

    // 回调
    private OnQMCallback mCallback;

    public interface OnQMCallback {
        void onOpenLockResult(int boardNo, int lockNo, boolean success, int errorCode);
        void onLockStatusReceived(int boardNo, int[] lockStatus);
        void onError(String message);
    }

    public void setCallback(OnQMCallback callback) {
        mCallback = callback;
    }

    public QMProtocol(SerialPortManager serialPort) {
        mSerialPort = serialPort;
    }

    // ==================== XOR校验 ====================

    /**
     * XOR校验 - 前6字节依次异或
     */
    public static byte xorChecksum(byte[] data, int length) {
        byte result = 0;
        for (int i = 0; i < length; i++) {
            result ^= data[i];
        }
        return result;
    }

    // ==================== 命令构建 ====================

    /**
     * 开锁命令
     * 发送: [0x5A] [0x23] [板地址H] [板地址L] [锁号H] [锁号L] [XOR]
     */
    public byte[] buildOpenLockCommand(int boardNo, int lockNo) {
        byte[] cmd = new byte[7];
        cmd[0] = (byte) FRAME_HEAD;
        cmd[1] = (byte) FUNC_OPEN_LOCK;
        cmd[2] = (byte) ((boardNo >> 8) & 0xFF);  // 板地址高字节
        cmd[3] = (byte) (boardNo & 0xFF);           // 板地址低字节
        cmd[4] = (byte) ((lockNo >> 8) & 0xFF);    // 锁号高字节
        cmd[5] = (byte) (lockNo & 0xFF);            // 锁号低字节
        cmd[6] = xorChecksum(cmd, 6);

        Log.d(TAG, "构建QM开锁: board=" + boardNo + ", lock=" + lockNo
                + ", frame=" + SerialPortManager.bytesToHex(cmd));
        return cmd;
    }

    /**
     * 查询锁状态命令
     * 发送: [0x5A] [0x22] [板地址H] [板地址L] [锁号H] [锁号L] [XOR]
     */
    public byte[] buildReadStatusCommand(int boardNo, int lockNo) {
        byte[] cmd = new byte[7];
        cmd[0] = (byte) FRAME_HEAD;
        cmd[1] = (byte) FUNC_READ_STATUS;
        cmd[2] = (byte) ((boardNo >> 8) & 0xFF);
        cmd[3] = (byte) (boardNo & 0xFF);
        cmd[4] = (byte) ((lockNo >> 8) & 0xFF);
        cmd[5] = (byte) (lockNo & 0xFF);
        cmd[6] = xorChecksum(cmd, 6);

        Log.d(TAG, "构建QM状态查询: board=" + boardNo + ", lock=" + lockNo);
        return cmd;
    }

    // ==================== 命令发送 ====================

    /**
     * 发送开锁指令
     */
    public boolean sendOpenLock(int boardNo, int lockNo) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            Log.e(TAG, "串口未打开");
            if (mCallback != null) mCallback.onError("串口未打开");
            return false;
        }

        byte[] cmd = buildOpenLockCommand(boardNo, lockNo);
        mSerialPort.write(cmd);
        Log.i(TAG, "发送QM开锁: board=" + boardNo + ", lock=" + lockNo);
        return true;
    }

    /**
     * 发送查询锁状态指令
     */
    public boolean sendReadStatus(int boardNo, int lockNo) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            return false;
        }

        byte[] cmd = buildReadStatusCommand(boardNo, lockNo);
        mSerialPort.write(cmd);
        Log.i(TAG, "发送QM状态查询: board=" + boardNo + ", lock=" + lockNo);
        return true;
    }

    // ==================== 响应解析 ====================

    /**
     * 解析开锁响应
     * 响应: [0x5A] [0xA3] [状态码] [XOR]
     * 状态码 0x00 = 成功, 其他 = 错误码
     */
    public int parseOpenLockResponse(byte[] response) {
        if (response == null || response.length < 4) {
            Log.w(TAG, "QM开锁响应太短: " + (response != null ? response.length : 0));
            return RESULT_FAIL;
        }

        // 帧头检查
        if ((response[0] & 0xFF) != FRAME_HEAD) {
            Log.w(TAG, "QM帧头错误: " + String.format("%02X", response[0]));
            return RESULT_FORMAT_ERROR;
        }

        // 功能码检查
        if ((response[1] & 0xFF) != FUNC_OPEN_LOCK_RESP) {
            Log.w(TAG, "QM功能码不匹配: " + String.format("%02X", response[1]));
            return RESULT_FORMAT_ERROR;
        }

        // XOR校验
        byte expectedXor = xorChecksum(response, 3);
        if (expectedXor != response[3]) {
            Log.w(TAG, "QM XOR校验失败: expected=" + String.format("%02X", expectedXor)
                    + ", actual=" + String.format("%02X", response[3]));
            return RESULT_CHECKSUM_ERROR;
        }

        int statusCode = response[2] & 0xFF;
        if (statusCode == 0x00) {
            Log.i(TAG, "QM开锁成功");
            return RESULT_SUCCESS;
        } else {
            Log.w(TAG, "QM开锁失败, 错误码: " + String.format("%02X", statusCode));
            return RESULT_FAIL;
        }
    }

    /**
     * 解析锁状态响应
     * 响应: [0x5A] [0x9E] [板地址H] [板地址L] [状态字节...] [XOR]
     * 响应长度 >= 9字节
     * XOR校验: 所有字节(除最后一个)异或 == 最后一个字节
     */
    public int[] parseLockStatusResponse(byte[] response) {
        if (response == null || response.length < 9) {
            Log.w(TAG, "QM状态响应太短: " + (response != null ? response.length : 0));
            return null;
        }

        // 帧头检查
        if ((response[0] & 0xFF) != FRAME_HEAD) {
            return null;
        }

        // 功能码检查
        if ((response[1] & 0xFF) != FUNC_READ_STATUS_RESP) {
            return null;
        }

        // XOR校验
        byte expectedXor = 0;
        for (int i = 0; i < response.length - 1; i++) {
            expectedXor ^= response[i];
        }
        if (expectedXor != response[response.length - 1]) {
            Log.w(TAG, "QM状态XOR校验失败");
            return null;
        }

        // 板地址
        int boardAddr = ((response[2] & 0xFF) << 8) | (response[3] & 0xFF);

        // 状态字节 (从index 4开始, 到倒数第2个)
        int statusByteCount = response.length - 5;  // 去掉头2+板地址2+校验1
        int[] status = new int[statusByteCount * 8];

        for (int i = 0; i < statusByteCount; i++) {
            int byteVal = response[4 + i] & 0xFF;
            for (int bit = 0; bit < 8; bit++) {
                status[i * 8 + bit] = (byteVal >> bit) & 1;
            }
        }

        if (mCallback != null) {
            mCallback.onLockStatusReceived(boardAddr, status);
        }

        Log.d(TAG, "QM锁状态解析完成, board=" + boardAddr + ", 锁数=" + status.length);
        return status;
    }

    /**
     * 处理接收数据
     */
    public void handleReceivedData(byte[] data, int length) {
        if (data == null || length < 4) return;

        Log.d(TAG, "QM收到数据: " + SerialPortManager.bytesToHex(data));

        // 检查帧头
        if ((data[0] & 0xFF) != FRAME_HEAD) {
            Log.w(TAG, "QM帧头不匹配");
            return;
        }

        int funcCode = data[1] & 0xFF;

        switch (funcCode) {
            case FUNC_OPEN_LOCK_RESP:
                int result = parseOpenLockResponse(data);
                if (mCallback != null) {
                    int errorCode = (result == RESULT_FAIL && data.length >= 3) ? (data[2] & 0xFF) : 0;
                    mCallback.onOpenLockResult(0, 0, result == RESULT_SUCCESS, errorCode);
                }
                break;

            case FUNC_READ_STATUS_RESP:
                parseLockStatusResponse(data);
                break;

            default:
                Log.w(TAG, "QM未知功能码: " + String.format("%02X", funcCode));
                break;
        }
    }
}
