package com.smartlocker.screen;

import android.util.Log;
import java.io.*;

/**
 * 串口管理器 - 支持多种串口类型
 * 
 * 串口类型:
 * - BaseSerial: 基础串口，使用stty配置（需要root）
 * - NormalSerial: 普通串口，直接读写
 * - VioSerial: 暴力串口，用于WT板特殊处理
 * 
 * 支持自动检测可用串口: /dev/ttyS1~S4, /dev/ttyUSB0~3
 */
public class SerialPortManager {
    private static final String TAG = "SerialPort";
    
    // 串口类型枚举
    public enum SerialType {
        BaseSerial,    // 基础串口
        NormalSerial,  // 普通串口
        VioSerial      // 暴力串口（用于WT板）
    }
    
    // 可用的串口路径列表
    public static final String[] AVAILABLE_PORTS = {
            "/dev/ttyS1", "/dev/ttyS2", "/dev/ttyS3", "/dev/ttyS4",
            "/dev/ttyUSB0", "/dev/ttyUSB1", "/dev/ttyUSB2", "/dev/ttyUSB3"
    };
    
    // 可用的波特率列表
    public static final int[] AVAILABLE_BAUD_RATES = {
            1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400
    };
    
    private FileInputStream mInputStream;
    private FileOutputStream mOutputStream;
    private RandomAccessFile mFileStream;
    private boolean mOpened = false;
    private Thread mReadThread;
    private OnDataReceivedListener mListener;
    
    private String mPortPath;
    private int mBaudRate;
    private SerialType mSerialType;
    
    // JNI库（可选）
    private boolean mHasJni = false;
    
    public interface OnDataReceivedListener {
        void onDataReceived(byte[] data, int length);
    }
    
    public void setDataReceivedListener(OnDataReceivedListener listener) {
        mListener = listener;
    }
    
    public SerialPortManager() {
        this(SerialType.BaseSerial);
    }
    
    public SerialPortManager(SerialType type) {
        mSerialType = type;
    }
    
    /**
     * 打开串口
     * @param path 设备路径
     * @param baudRate 波特率
     * @return 是否成功
     */
    public boolean open(String path, int baudRate) {
        return open(path, baudRate, mSerialType);
    }
    
    /**
     * 打开串口（指定类型）
     */
    public boolean open(String path, int baudRate, SerialType type) {
        if (mOpened) {
            close();
        }
        
        mPortPath = path;
        mBaudRate = baudRate;
        mSerialType = type;
        
        try {
            File device = new File(path);
            if (!device.exists()) {
                Log.e(TAG, "串口设备不存在: " + path);
                return false;
            }
            
            boolean success = false;
            switch (type) {
                case BaseSerial:
                    success = openBaseSerial(path, baudRate);
                    break;
                case NormalSerial:
                    success = openNormalSerial(path, baudRate);
                    break;
                case VioSerial:
                    success = openVioSerial(path, baudRate);
                    break;
            }
            
            if (success) {
                mOpened = true;
                startReadThread();
                Log.i(TAG, "串口打开成功: " + path + " @ " + baudRate + " [" + type + "]");
                return true;
            }
            
            return false;
        } catch (Exception e) {
            Log.e(TAG, "串口打开失败: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * BaseSerial - 基础串口，使用stty配置（需要root）
     */
    private boolean openBaseSerial(String path, int baudRate) {
        try {
            // 尝试使用su设置权限和串口参数
            Process su = Runtime.getRuntime().exec("su");
            OutputStream os = su.getOutputStream();
            
            // 设置权限
            os.write(("chmod 777 " + path + "\n").getBytes());
            
            // stty配置: 8位数据位, 1位停止位, 无校验
            String sttyCmd = String.format(
                "stty -F %s %d cs8 -cstopb -parenb -ignbrk -brkint -icrnl -imaxbel -opost -isig -icanon -iexten %s\n",
                path, baudRate,
                mBaudRate >= 115200 ? "-hup" : ""
            );
            os.write(sttyCmd.getBytes());
            os.write("exit\n".getBytes());
            os.flush();
            su.waitFor();
            
            if (su.exitValue() == 0) {
                Log.i(TAG, "stty配置成功");
            }
            
            // 直接打开设备文件
            mFileStream = new RandomAccessFile(path, "rw");
            mOpened = true;
            return true;
            
        } catch (Exception e) {
            Log.e(TAG, "BaseSerial失败: " + e.getMessage());
            return openNormalSerial(path, baudRate);
        }
    }
    
    /**
     * NormalSerial - 普通串口，直接读写
     */
    private boolean openNormalSerial(String path, int baudRate) {
        try {
            Process process = Runtime.getRuntime().exec("chmod 666 " + path);
            process.waitFor();
            
            mInputStream = new FileInputStream(path);
            mOutputStream = new FileOutputStream(path);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "NormalSerial失败: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * VioSerial - 暴力串口，用于WT板特殊处理
     */
    private boolean openVioSerial(String path, int baudRate) {
        try {
            // WT板需要特殊的初始化序列
            Process process = Runtime.getRuntime().exec("chmod 666 " + path);
            process.waitFor();
            
            mFileStream = new RandomAccessFile(path, "rw");
            
            // 发送初始化序列
            byte[] initSeq = new byte[]{
                    0x7E, 0x01, (byte)0xF0, 0x0D, 0x0A
            };
            mFileStream.write(initSeq);
            
            return true;
        } catch (Exception e) {
            Log.e(TAG, "VioSerial失败: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 发送数据
     */
    public void write(byte[] data) {
        if (!mOpened) {
            Log.w(TAG, "串口未打开");
            return;
        }
        
        try {
            if (mFileStream != null) {
                mFileStream.write(data);
                mFileStream.getFD().sync();
            } else if (mOutputStream != null) {
                mOutputStream.write(data);
                mOutputStream.flush();
            }
            Log.d(TAG, "发送: " + bytesToHex(data));
        } catch (IOException e) {
            Log.e(TAG, "发送失败: " + e.getMessage());
        }
    }
    
    /**
     * 发送数据并等待响应
     * @param data 发送的数据
     * @param timeoutMs 超时时间(毫秒)
     * @return 响应数据，null表示超时
     */
    public byte[] writeWithResponse(byte[] data, int timeoutMs) {
        write(data);
        
        final byte[][] responseHolder = new byte[1][];
        final Object lock = new Object();
        
        OnDataReceivedListener originalListener = mListener;
        setDataReceivedListener(new OnDataReceivedListener() {
            @Override
            public void onDataReceived(byte[] data, int length) {
                responseHolder[0] = new byte[length];
                System.arraycopy(data, 0, responseHolder[0], 0, length);
                synchronized (lock) {
                    lock.notifyAll();
                }
            }
        });
        
        synchronized (lock) {
            try {
                lock.wait(timeoutMs);
            } catch (InterruptedException e) {
                // ignore
            }
        }
        
        setDataReceivedListener(originalListener);
        return responseHolder[0];
    }
    
    /**
     * 关闭串口
     */
    public void close() {
        mOpened = false;
        
        if (mReadThread != null) {
            mReadThread.interrupt();
            mReadThread = null;
        }
        
        try {
            if (mInputStream != null) {
                mInputStream.close();
                mInputStream = null;
            }
            if (mOutputStream != null) {
                mOutputStream.close();
                mOutputStream = null;
            }
            if (mFileStream != null) {
                mFileStream.close();
                mFileStream = null;
            }
        } catch (IOException e) {
            Log.e(TAG, "关闭串口失败: " + e.getMessage());
        }
        
        Log.i(TAG, "串口已关闭: " + mPortPath);
    }
    
    /**
     * 启动数据读取线程
     */
    private void startReadThread() {
        if (mReadThread != null) {
            mReadThread.interrupt();
        }
        
        mReadThread = new Thread(() -> {
            byte[] buffer = new byte[256];
            
            while (mOpened && !Thread.currentThread().isInterrupted()) {
                try {
                    int size = -1;
                    
                    if (mFileStream != null) {
                        // RandomAccessFile方式
                        int available = mFileStream.read(buffer);
                        if (available > 0) {
                            size = available;
                        }
                    } else if (mInputStream != null) {
                        // FileInputStream方式
                        size = mInputStream.read(buffer);
                    }
                    
                    if (size > 0 && mListener != null) {
                        byte[] data = new byte[size];
                        System.arraycopy(buffer, 0, data, 0, size);
                        mListener.onDataReceived(data, size);
                    }
                    
                    // 短暂休眠避免CPU占用过高
                    Thread.sleep(10);
                    
                } catch (InterruptedException e) {
                    break;
                } catch (IOException e) {
                    if (mOpened) {
                        Log.e(TAG, "读取失败: " + e.getMessage());
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ie) {
                            break;
                        }
                    }
                }
            }
        });
        
        mReadThread.setName("SerialRead-" + mPortPath);
        mReadThread.setDaemon(true);
        mReadThread.start();
    }
    
    /**
     * 自动检测可用串口
     * @return 第一个可用的串口路径，null表示未找到
     */
    public static String autoDetectPort() {
        for (String port : AVAILABLE_PORTS) {
            File device = new File(port);
            if (device.exists() && device.canRead() && device.canWrite()) {
                Log.i(TAG, "检测到可用串口: " + port);
                return port;
            }
        }
        return null;
    }
    
    /**
     * 检测指定串口是否可用
     */
    public static boolean isPortAvailable(String port) {
        File device = new File(port);
        return device.exists() && device.canRead() && device.canWrite();
    }
    
    /**
     * 字节数组转十六进制字符串
     */
    public static String bytesToHex(byte[] bytes) {
        if (bytes == null) return "";
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X ", b));
        }
        return sb.toString().trim();
    }
    
    /**
     * 十六进制字符串转字节数组
     */
    public static byte[] hexToBytes(String hex) {
        hex = hex.replaceAll("\\s+", "");
        if (hex.length() % 2 != 0) {
            hex = "0" + hex;
        }
        byte[] data = new byte[hex.length() / 2];
        for (int i = 0; i < data.length; i++) {
            data[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
        }
        return data;
    }
    
    /**
     * CRC-8校验（参考APK中的CRC校验）
     */
    public static byte crc8(byte[] data) {
        byte crc = 0;
        for (byte b : data) {
            crc ^= b;
            for (int i = 0; i < 8; i++) {
                if ((crc & 0x80) != 0) {
                    crc = (byte) ((crc << 1) ^ 0x07);
                } else {
                    crc = (byte) (crc << 1);
                }
            }
        }
        return crc;
    }
    
    /**
     * XOR校验和
     */
    public static byte xorChecksum(byte... data) {
        byte result = 0;
        for (byte b : data) {
            result ^= b;
        }
        return result;
    }
    
    public boolean isOpened() {
        return mOpened;
    }
    
    public String getPortPath() {
        return mPortPath;
    }
    
    public int getBaudRate() {
        return mBaudRate;
    }
    
    public SerialType getSerialType() {
        return mSerialType;
    }
}
