package com.smartlocker.screen;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.*;
import android.widget.*;
import android.content.ContentValues;import android.graphics.Color;import android.graphics.Typeface;;
import com.smartlocker.screen.db.DBHelper;
import com.smartlocker.screen.service.LockerService;
import com.smartlocker.screen.utils.PreferencesHelper;

/**
 * 设置界面 - 设备配置
 * 
 * 功能:
 * - 服务器地址配置
 * - 设备ID配置
 * - 串口配置
 * - 波特率选择
 * - 主板配置
 * - 协议选择
 * - 管理员密码
 */
public class SettingsActivity extends Activity {
    private static final String TAG = "SettingsActivity";
    
    // 组件
    private ScrollView mScrollView;
    private LinearLayout mContentLayout;
    
    // 输入框
    private EditText mEtServerUrl;
    private EditText mEtWebSocketUrl;
    private EditText mEtDeviceId;
    private EditText mEtDeviceName;
    private EditText mEtStoreName;
    private EditText mEtStoreAddress;
    private EditText mEtCustomerPhone;
    private Spinner mSpSerialPort;
    private Spinner mSpBaudRate;
    private Spinner mSpSerialType;
    private Spinner mSpProtocolType;
    private EditText mEtBoardStart;
    private EditText mEtBoardCount;
    private EditText mEtAdminPassword;
    
    // 状态显示
    private TextView mTvSerialStatus;
    private TextView mTvConnectionStatus;
    private TextView mTvVersion;
    
    private PreferencesHelper mPrefs;
    private DBHelper mDB;
    
    // 串口选项
    private static final String[] SERIAL_PORTS = {
            "/dev/ttyS1", "/dev/ttyS2", "/dev/ttyS3", "/dev/ttyS4",
            "/dev/ttyUSB0", "/dev/ttyUSB1", "/dev/ttyUSB2", "/dev/ttyUSB3",
            "/dev/ttyACM0", "/dev/ttyACM1"
    };
    
    // 波特率选项
    private static final String[] BAUD_RATES = {
            "1200", "2400", "4800", "9600", "19200", "38400", "57600", "115200", "230400"
    };
    
    // 串口类型选项
    private static final String[] SERIAL_TYPES = {
            "BaseSerial (基础串口)", "NormalSerial (普通串口)", "VioSerial (WT板暴力串口)"
    };
    
    // 协议类型选项
    private static final String[] PROTOCOL_TYPES = {
            "YBM (亚博明)",
            "WT (威特-Modbus RTU)",
            "QM (启明)"
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        mPrefs = new PreferencesHelper(this);
        mDB = DBHelper.getInstance(this);
        
        buildUI();
        loadSettings();
    }
    
    /**
     * 构建设置界面
     */
    private void buildUI() {
        // 主布局
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(Color.parseColor("#263238"));
        
        // 标题栏
        LinearLayout titleBar = new LinearLayout(this);
        titleBar.setOrientation(LinearLayout.HORIZONTAL);
        titleBar.setGravity(Gravity.CENTER_VERTICAL);
        titleBar.setBackgroundColor(Color.parseColor("#37474F"));
        titleBar.setPadding(20, 15, 20, 15);
        
        TextView title = new TextView(this);
        title.setText("⚙️ 系统设置");
        title.setTextSize(22);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titleBar.addView(title);
        
        titleBar.addView(new View(this), new LinearLayout.LayoutParams(0, 0, 1f));
        
        // 返回按钮
        Button btnBack = new Button(this);
        btnBack.setText("返回");
        btnBack.setTextColor(Color.WHITE);
        btnBack.setBackgroundColor(Color.parseColor("#1976D2"));
        btnBack.setOnClickListener(v -> finish());
        titleBar.addView(btnBack);
        
        mainLayout.addView(titleBar);
        
        // 内容区域
        mScrollView = new ScrollView(this);
        mContentLayout = new LinearLayout(this);
        mContentLayout.setOrientation(LinearLayout.VERTICAL);
        mContentLayout.setPadding(20, 20, 20, 20);
        
        // 服务器配置
        addSectionTitle("📡 服务器配置");
        addEditRow("服务器地址:", mEtServerUrl = new EditText(this), mPrefs.getServerUrl());
        addEditRow("WebSocket地址:", mEtWebSocketUrl = new EditText(this), mPrefs.getWebSocketUrl());
        
        // 设备配置
        addSectionTitle("📱 设备配置");
        addEditRow("设备ID:", mEtDeviceId = new EditText(this), mPrefs.getDeviceId());
        addEditRow("设备名称:", mEtDeviceName = new EditText(this), mPrefs.getDeviceName());
        addEditRow("网点名称:", mEtStoreName = new EditText(this), mPrefs.getStoreName());
        addEditRow("网点地址:", mEtStoreAddress = new EditText(this), "");
        addEditRow("客服电话:", mEtCustomerPhone = new EditText(this), "");

        // 主板品牌选择（自动联动串口类型+波特率）
        addSpinnerRow("主板品牌:", mSpProtocolType = new Spinner(this), PROTOCOL_TYPES);

        // 主板品牌变化时自动联动串口类型和波特率
        mSpProtocolType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String serialType;
                int targetBaud;
                switch (position) {
                    case 0: // YBM (亚博旻) → NormalSerial, 9600
                        serialType = "NormalSerial";
                        targetBaud = 9600;
                        break;
                    case 1: // WT (威特) → VioSerial, 115200
                        serialType = "VioSerial";
                        targetBaud = 115200;
                        break;
                    case 2: // QM (启明) → NormalSerial, 9600
                        serialType = "NormalSerial";
                        targetBaud = 9600;
                        break;
                    default:
                        serialType = "NormalSerial";
                        targetBaud = 9600;
                        break;
                }
                // 自动设置串口类型
                for (int i = 0; i < SERIAL_TYPES.length; i++) {
                    if (SERIAL_TYPES[i].contains(serialType)) {
                        mSpSerialType.setSelection(i);
                        break;
                    }
                }
                // 自动设置波特率
                for (int i = 0; i < BAUD_RATES.length; i++) {
                    if (BAUD_RATES[i].equals(String.valueOf(targetBaud))) {
                        mSpBaudRate.setSelection(i);
                        break;
                    }
                }
                String currentPort = mSpSerialPort.getSelectedItem().toString();
                mTvSerialStatus.setText("品牌联动: " + PROTOCOL_TYPES[position] + " -> " + serialType + " @ " + targetBaud);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        
        // 串口配置
        addSectionTitle("🔌 串口配置");
        addSpinnerRow("串口路径:", mSpSerialPort = new Spinner(this), SERIAL_PORTS);
        addSpinnerRow("波特率:", mSpBaudRate = new Spinner(this), BAUD_RATES);
        
        // Serial port selection auto-matches baud rate
        mSpSerialPort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String port = SERIAL_PORTS[position];
                int targetBaud = getDefaultBaudRate(port);
                for (int i = 0; i < BAUD_RATES.length; i++) {
                    if (BAUD_RATES[i].equals(String.valueOf(targetBaud))) {
                        mSpBaudRate.setSelection(i);
                        break;
                    }
                }
                if (port.contains("ttyS")) {
                    mSpSerialType.setSelection(1);
                } else if (port.contains("ttyACM")) {
                    mSpSerialType.setSelection(0);
                } else if (port.contains("ttyUSB")) {
                    mSpSerialType.setSelection(1);
                }
                mTvSerialStatus.setText("Auto: " + port + " -> " + targetBaud);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        addSpinnerRow("串口类型:", mSpSerialType = new Spinner(this), SERIAL_TYPES);

        // 串口类型选择时自动匹配波特率
        mSpSerialType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int targetBaud;
                switch (position) {
                    case 0: // BaseSerial (基础串口/ttyACM) -> 115200
                        targetBaud = 115200;
                        break;
                    case 2: // VioSerial (WT暴力串口) -> 115200
                        targetBaud = 115200;
                        break;
                    default: // NormalSerial (普通串口) -> 9600
                        targetBaud = 9600;
                        break;
                }
                for (int i = 0; i < BAUD_RATES.length; i++) {
                    if (BAUD_RATES[i].equals(String.valueOf(targetBaud))) {
                        mSpBaudRate.setSelection(i);
                        break;
                    }
                }
                String currentPort = mSpSerialPort.getSelectedItem().toString();
                mTvSerialStatus.setText("Auto: " + currentPort + " @ " + targetBaud + " [" + SERIAL_TYPES[position] + "]");
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        
        // 测试按钮
        LinearLayout testRow = new LinearLayout(this);
        testRow.setOrientation(LinearLayout.HORIZONTAL);
        
        Button btnScan = new Button(this);
        btnScan.setText("🔍 自动扫描");
        btnScan.setOnClickListener(v -> scanSerialPort());
        testRow.addView(btnScan);
        
        Button btnTestSerial = new Button(this);
        btnTestSerial.setText("🧪 测试串口");
        btnTestSerial.setOnClickListener(v -> testSerialPort());
        testRow.addView(btnTestSerial);
        
        mContentLayout.addView(testRow);
        
        mTvSerialStatus = new TextView(this);
        mTvSerialStatus.setTextColor(Color.parseColor("#90CAF9"));
        mTvSerialStatus.setTextSize(12);
        mContentLayout.addView(mTvSerialStatus);
        
        // 主板配置
        addSectionTitle("🔧 主板配置");
        addEditRow("起始板号:", mEtBoardStart = new EditText(this), String.valueOf(mPrefs.getBoardNo()));
        addEditRow("主板数量:", mEtBoardCount = new EditText(this), String.valueOf(mPrefs.getBoardCount()));
        
        // 测试按钮
        LinearLayout boardRow = new LinearLayout(this);
        boardRow.setOrientation(LinearLayout.HORIZONTAL);
        
        Button btnReadMcu = new Button(this);
        btnReadMcu.setText("📋 读取MCU ID");
        btnReadMcu.setOnClickListener(v -> readMcuId());
        boardRow.addView(btnReadMcu);
        
        Button btnOpenAll = new Button(this);
        btnOpenAll.setText("🔓 全开测试");
        btnOpenAll.setOnClickListener(v -> testOpenAll());
        boardRow.addView(btnOpenAll);
        
        mContentLayout.addView(boardRow);
        
        // 管理员配置
        addSectionTitle("🔑 管理员配置");
        addEditRow("管理员密码:", mEtAdminPassword = new EditText(this), mPrefs.getAdminPassword());
        mEtAdminPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        
        // 保存按钮
        Button btnSave = new Button(this);
        btnSave.setText("💾 保存设置");
        btnSave.setTextSize(18);
        btnSave.setTextColor(Color.WHITE);
        btnSave.setBackgroundColor(Color.parseColor("#4CAF50"));
        btnSave.setPadding(20, 15, 20, 15);
        btnSave.setOnClickListener(v -> saveSettings());
        mContentLayout.addView(btnSave, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));
        
        // 状态栏
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setPadding(0, 20, 0, 0);
        
        mTvConnectionStatus = new TextView(this);
        mTvConnectionStatus.setTextColor(Color.parseColor("#90CAF9"));
        mTvConnectionStatus.setText("连接状态: --");
        statusRow.addView(mTvConnectionStatus);
        
        statusRow.addView(new View(this), new LinearLayout.LayoutParams(0, 0, 1f));
        
        mTvVersion = new TextView(this);
        mTvVersion.setTextColor(Color.parseColor("#78909C"));
        mTvVersion.setText("版本: " + SmartLockerApp.getInstance().getVersionName());
        statusRow.addView(mTvVersion);
        
        mContentLayout.addView(statusRow);
        
        mScrollView.addView(mContentLayout);
        mainLayout.addView(mScrollView, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT));
        
        setContentView(mainLayout);
    }
    
    /**
     * 添加分组标题
     */

    private int getDefaultBaudRate(String port) {
        if (port.contains("ttyACM")) {
            return 115200;
        }
        return 9600;
    }

    private void addSectionTitle(String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(16);
        tv.setTextColor(Color.parseColor("#4CAF50"));
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, 20, 0, 10);
        mContentLayout.addView(tv);
    }
    
    /**
     * 添加编辑行
     */
    private void addEditRow(String label, EditText editText, String defaultValue) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, 5, 0, 5);
        
        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextSize(14);
        labelView.setTextColor(Color.parseColor("#B0BEC5"));
        labelView.setMinWidth(100);
        row.addView(labelView);
        
        editText.setText(defaultValue);
        editText.setTextSize(14);
        editText.setTextColor(Color.WHITE);
        editText.setBackgroundColor(Color.parseColor("#37474F"));
        editText.setPadding(10, 8, 10, 8);
        
        row.addView(editText, new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        
        mContentLayout.addView(row);
    }
    
    /**
     * 添加选择行
     */
    private void addSpinnerRow(String label, Spinner spinner, String[] items) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, 5, 0, 5);
        
        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextSize(14);
        labelView.setTextColor(Color.parseColor("#B0BEC5"));
        labelView.setMinWidth(100);
        row.addView(labelView);
        
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_dropdown_item, items);
        spinner.setAdapter(adapter);
        
        row.addView(spinner, new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        
        mContentLayout.addView(row);
    }
    
    /**
     * 加载设置
     */
    private void loadSettings() {
        mEtServerUrl.setText(mPrefs.getServerUrl());
        mEtWebSocketUrl.setText(mPrefs.getWebSocketUrl());
        mEtDeviceId.setText(mPrefs.getDeviceId());
        mEtDeviceName.setText(mPrefs.getDeviceName());
        mEtStoreName.setText(mPrefs.getStoreName());
        
        // 串口
        String currentPort = mPrefs.getSerialPort();
        for (int i = 0; i < SERIAL_PORTS.length; i++) {
            if (SERIAL_PORTS[i].equals(currentPort)) {
                mSpSerialPort.setSelection(i);
                break;
            }
        }
        
        // 波特率
        int currentBaud = mPrefs.getBaudRate();
        for (int i = 0; i < BAUD_RATES.length; i++) {
            if (BAUD_RATES[i].equals(String.valueOf(currentBaud))) {
                mSpBaudRate.setSelection(i);
                break;
            }
        }
        
        // 串口类型
        String serialType = mPrefs.getSerialType();
        if ("NormalSerial".equals(serialType)) {
            mSpSerialType.setSelection(1);
        } else if ("VioSerial".equals(serialType)) {
            mSpSerialType.setSelection(2);
        } else {
            mSpSerialType.setSelection(0);
        }
        
        // 协议类型
        String protocol = mPrefs.getProtocolType();
        for (int i = 0; i < PROTOCOL_TYPES.length; i++) {
            if (PROTOCOL_TYPES[i].contains(protocol)) {
                mSpProtocolType.setSelection(i);
                break;
            }
        }
        
        mEtBoardStart.setText(String.valueOf(mPrefs.getBoardNo()));
        mEtBoardCount.setText(String.valueOf(mPrefs.getBoardCount()));
        mEtAdminPassword.setText(mPrefs.getAdminPassword());
        
        // 加载网点信息
        ContentValues storeInfo = mDB.getStoreInfo();
        if (storeInfo != null) {
            if (storeInfo.containsKey(DBHelper.COL_STORE_ADDRESS)) {
                mEtStoreAddress.setText(storeInfo.getAsString(DBHelper.COL_STORE_ADDRESS));
            }
            if (storeInfo.containsKey(DBHelper.COL_CUSTOMER_PHONE)) {
                mEtCustomerPhone.setText(storeInfo.getAsString(DBHelper.COL_CUSTOMER_PHONE));
            }
        }
        
        // 串口状态
        mTvSerialStatus.setText("当前: " + mPrefs.getSerialPort() + " @ " + mPrefs.getBaudRate() + " [" + mPrefs.getSerialType() + "]");
    }
    
    /**
     * 保存设置
     */
    private void saveSettings() {
        try {
            // 服务器配置
            mPrefs.setServerUrl(mEtServerUrl.getText().toString().trim());
            mPrefs.setWebSocketUrl(mEtWebSocketUrl.getText().toString().trim());
            
            // 设备配置
            String deviceId = mEtDeviceId.getText().toString().trim();
            if (deviceId.isEmpty()) {
                Toast.makeText(this, "设备ID不能为空", Toast.LENGTH_SHORT).show();
                return;
            }
            mPrefs.setDeviceId(deviceId);
            mPrefs.setDeviceName(mEtDeviceName.getText().toString().trim());
            mPrefs.setStoreName(mEtStoreName.getText().toString().trim());
            
            // 串口配置
            mPrefs.setSerialPort(SERIAL_PORTS[mSpSerialPort.getSelectedItemPosition()]);
            mPrefs.setBaudRate(Integer.parseInt(BAUD_RATES[mSpBaudRate.getSelectedItemPosition()]));
            
            String serialType;
            switch (mSpSerialType.getSelectedItemPosition()) {
                case 1: serialType = "NormalSerial"; break;
                case 2: serialType = "VioSerial"; break;
                default: serialType = "BaseSerial"; break;
            }
            mPrefs.setSerialType(serialType);
            
            // 主板配置
            String protocolStr = PROTOCOL_TYPES[mSpProtocolType.getSelectedItemPosition()];
            if (protocolStr.contains("YBM")) {
                mPrefs.setProtocolType("YBM");
            } else if (protocolStr.contains("WT")) {
                mPrefs.setProtocolType("WT");
            } else {
                mPrefs.setProtocolType("QM");
            }
            
            int boardStart = Integer.parseInt(mEtBoardStart.getText().toString().trim());
            int boardCount = Integer.parseInt(mEtBoardCount.getText().toString().trim());
            mPrefs.setBoardNoList(boardStart, boardCount);
            
            // 管理员配置
            mPrefs.setAdminPassword(mEtAdminPassword.getText().toString().trim());
            
            // 保存网点信息
            mDB.saveStoreInfo(
                mPrefs.getStoreName(),
                mEtStoreAddress.getText().toString().trim(),
                "",  // 营业时间
                mEtCustomerPhone.getText().toString().trim(),
                0, 0 // 柜门数量待更新
            );
            
            // 重启服务以应用新配置
            restartService();
            
            Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
            Log.i(TAG, "设置已保存");
            
        } catch (Exception e) {
            Log.e(TAG, "保存设置失败: " + e.getMessage());
            Toast.makeText(this, "保存失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    
    /**
     * 自动扫描串口
     */
    private void scanSerialPort() {
        String detectedPort = SerialPortManager.autoDetectPort();
        if (detectedPort != null) {
            mTvSerialStatus.setText("✅ 检测到串口: " + detectedPort);
            
            // 自动选择
            for (int i = 0; i < SERIAL_PORTS.length; i++) {
                if (SERIAL_PORTS[i].equals(detectedPort)) {
                    mSpSerialPort.setSelection(i);
                    break;
                }
            }
        } else {
            mTvSerialStatus.setText("❌ 未检测到可用串口");
        }
    }
    
    /**
     * 测试串口
     */
    private void testSerialPort() {
        String port = SERIAL_PORTS[mSpSerialPort.getSelectedItemPosition()];
        int baud = Integer.parseInt(BAUD_RATES[mSpBaudRate.getSelectedItemPosition()]);
        
        SerialPortManager.SerialType type;
        switch (mSpSerialType.getSelectedItemPosition()) {
            case 1: type = SerialPortManager.SerialType.NormalSerial; break;
            case 2: type = SerialPortManager.SerialType.VioSerial; break;
            default: type = SerialPortManager.SerialType.BaseSerial; break;
        }
        
        SerialPortManager serial = new SerialPortManager(type);
        boolean success = serial.open(port, baud);
        
        if (success) {
            mTvSerialStatus.setText("✅ 串口打开成功: " + port + " @ " + baud);
            serial.close();
        } else {
            mTvSerialStatus.setText("❌ 串口打开失败: " + port);
        }
    }
    
    /**
     * 读取MCU ID
     */
    private void readMcuId() {
        String port = mPrefs.getSerialPort();
        int baud = mPrefs.getBaudRate();
        int boardNo = mPrefs.getBoardNo();
        
        SerialPortManager serial = new SerialPortManager();
        if (!serial.open(port, baud)) {
            Toast.makeText(this, "串口打开失败", Toast.LENGTH_SHORT).show();
            return;
        }
        
        YBMProtocol protocol = new YBMProtocol(serial);
        serial.setDataReceivedListener((data, length) -> {
            String mcuId = protocol.parseMcuIdResponse(data);
            runOnUiThread(() -> {
                if (mcuId != null) {
                    Toast.makeText(this, "MCU ID: " + mcuId, Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "读取失败，请检查连接", Toast.LENGTH_SHORT).show();
                }
                serial.close();
            });
        });
        
        protocol.sendReadMcuId(boardNo);
        
        // 5秒超时
        new Thread(() -> {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {}
            serial.close();
        }).start();
    }
    
    /**
     * 测试全开
     */
    private void testOpenAll() {
        String port = mPrefs.getSerialPort();
        int baud = mPrefs.getBaudRate();
        
        SerialPortManager serial = new SerialPortManager();
        if (!serial.open(port, baud)) {
            Toast.makeText(this, "串口打开失败", Toast.LENGTH_SHORT).show();
            return;
        }
        
        YBMProtocol protocol = new YBMProtocol(serial);
        boolean sent = protocol.sendOpenAll();
        
        if (sent) {
            Toast.makeText(this, "全开指令已发送", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "发送失败", Toast.LENGTH_SHORT).show();
        }
        
        new Thread(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {}
            serial.close();
        }).start();
    }
    
    /**
     * 重启后台服务
     */
    private void restartService() {
        Intent intent = new Intent(this, LockerService.class);
        stopService(intent);
        
        new Thread(() -> {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {}
            
            runOnUiThread(() -> startService(intent));
        }).start();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        // 更新连接状态
        mTvConnectionStatus.setText("连接状态: " + (LockerService.isConnected() ? "已连接" : "未连接"));
    }
}
