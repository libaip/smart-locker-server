package com.smartlocker.screen;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.util.Log;

import com.smartlocker.screen.db.DBHelper;
import com.smartlocker.screen.utils.PreferencesHelper;

/**
 * 应用全局配置
 */
public class SmartLockerApp extends Application {
    private static final String TAG = "SmartLockerApp";
    private static SmartLockerApp instance;
    
    // 服务通知渠道
    public static final String CHANNEL_ID = "locker_service_channel";
    
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        
        Log.i(TAG, "应用启动, 版本: " + getVersionName());
        
        // 初始化数据库
        DBHelper.getInstance(this);
        
        // 创建服务通知渠道
        createNotificationChannel();
    }
    
    public static SmartLockerApp getInstance() {
        return instance;
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "寄存柜服务",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("保持后台连接，接收开锁指令");
            channel.setShowBadge(false);
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
    
    /**
     * 启动前台服务通知
     */
    public void startServiceNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification notification = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("智能寄存柜运行中")
                    .setContentText("设备ID: " + PreferencesHelper.getDeviceId(this))
                    .setSmallIcon(R.drawable.ic_notification)
                    .setPriority(Notification.PRIORITY_LOW)
                    .build();
            
            NotificationManager nm = getSystemService(NotificationManager.class); if (nm != null) nm.notify(1, notification);
        }
    }
    
    public String getVersionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "1.0.0";
        }
    }
    
    public int getVersionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 1;
        }
    }

    public static android.content.Context getContext() {
        return instance != null ? instance.getApplicationContext() : null;
    }
}
