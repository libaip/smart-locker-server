package com.smartlocker.screen;

import android.content.Context;
import android.util.Log;

import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;

public class SslUtils {
    private static final String TAG = "SslUtils";

    public static void configureSsl(OkHttpClient.Builder builder, Context context) {
        try {
            X509TrustManager systemTm = getSystemTrustManager();
            X509TrustManager isrgTm = getIsrgTrustManager(context);
            X509TrustManager compositeTm = new CompositeTrustManager(systemTm, isrgTm);

            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{compositeTm}, null);

            builder.sslSocketFactory(sslContext.getSocketFactory(), compositeTm);
            Log.i(TAG, "SSL configured with composite trust manager (system + ISRG)");
        } catch (Exception e) {
            Log.e(TAG, "Failed to configure SSL, using default", e);
        }
    }

    private static X509TrustManager getSystemTrustManager() throws Exception {
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init((KeyStore) null);
        for (TrustManager tm : tmf.getTrustManagers()) {
            if (tm instanceof X509TrustManager) {
                return (X509TrustManager) tm;
            }
        }
        throw new IllegalStateException("No X509TrustManager found");
    }

    private static X509TrustManager getIsrgTrustManager(Context context) throws Exception {
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        ks.load(null, null);

        int[] rawIds = {R.raw.isrgrootx1, R.raw.isrgrootx2};
        String[] names = {"isrg-root-x1", "isrg-root-x2"};
        for (int i = 0; i < rawIds.length; i++) {
            try (InputStream is = context.getResources().openRawResource(rawIds[i])) {
                X509Certificate cert = (X509Certificate) cf.generateCertificate(is);
                ks.setCertificateEntry(names[i], cert);
                Log.i(TAG, "Loaded " + names[i] + ": " + cert.getSubjectDN());
            } catch (Exception e) {
                Log.w(TAG, "Failed to load " + names[i], e);
            }
        }

        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(ks);
        for (TrustManager tm : tmf.getTrustManagers()) {
            if (tm instanceof X509TrustManager) {
                return (X509TrustManager) tm;
            }
        }
        throw new IllegalStateException("No ISRG X509TrustManager found");
    }

    private static class CompositeTrustManager implements X509TrustManager {
        private final X509TrustManager primary;
        private final X509TrustManager fallback;

        CompositeTrustManager(X509TrustManager primary, X509TrustManager fallback) {
            this.primary = primary;
            this.fallback = fallback;
        }

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {
            try {
                primary.checkClientTrusted(chain, authType);
            } catch (java.security.cert.CertificateException e) {
                fallback.checkClientTrusted(chain, authType);
            }
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {
            try {
                primary.checkServerTrusted(chain, authType);
            } catch (java.security.cert.CertificateException e) {
                Log.w(TAG, "System trust failed (" + e.getMessage() + "), trying ISRG fallback");
                fallback.checkServerTrusted(chain, authType);
            }
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            X509Certificate[] p = primary.getAcceptedIssuers();
            X509Certificate[] f = fallback.getAcceptedIssuers();
            X509Certificate[] combined = new X509Certificate[p.length + f.length];
            System.arraycopy(p, 0, combined, 0, p.length);
            System.arraycopy(f, 0, combined, p.length, f.length);
            return combined;
        }
    }
}
