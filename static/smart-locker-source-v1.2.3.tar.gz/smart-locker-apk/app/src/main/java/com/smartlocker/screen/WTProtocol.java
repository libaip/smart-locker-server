package com.smartlocker.screen;

import android.util.Log;

/**
 * WT锁控板协议实现 - Modbus RTU
 * 
 * 帧格式: [板地址] [功能码] [数据...] [CRC_L] [CRC_H]
 * CRC16多项式: 0xA001, 低字节在前
 * 
 * 支持功能:
 * - 0x02 读输入状态（查询锁状态）
 * - 0x05 写单个线圈（开锁）
 */
public class WTProtocol {
    private static final String TAG = "WT";

    // Modbus功能码
    public static final int FUNC_READ_INPUT_STATUS = 0x02;   // 读输入状态
    public static final int FUNC_WRITE_SINGLE_COIL = 0x05;   // 写单个线圈

    // 开锁结果
    public static final int RESULT_SUCCESS = 1;
    public static final int RESULT_TIMEOUT = -1;
    public static final int RESULT_FAIL = -2;
    public static final int RESULT_CRC_ERROR = -3;
    public static final int RESULT_FORMAT_ERROR = -4;

    private SerialPortManager mSerialPort;

    // 回调
    private OnWTCallback mCallback;

    public interface OnWTCallback {
        void onOpenLockResult(int boardAddr, int lockNo, boolean success);
        void onLockStatusReceived(int boardAddr, int[] lockStatus);
        void onError(String message);
    }

    public void setCallback(OnWTCallback callback) {
        mCallback = callback;
    }

    public WTProtocol(SerialPortManager serialPort) {
        mSerialPort = serialPort;
    }

    // ==================== CRC16 Modbus ====================

    /**
     * CRC16 Modbus校验（多项式0xA001）
     * 返回低字节在前的2字节数组
     */
    public static byte[] crc16Modbus(byte[] data, int length) {
        int crc = 0xFFFF;
        for (int i = 0; i < length; i++) {
            crc ^= (data[i] & 0xFF);
            for (int j = 0; j < 8; j++) {
                if ((crc & 1) != 0) {
                    crc = (crc >> 1) ^ 0xA001;
                } else {
                    crc >>= 1;
                }
            }
        }
        return new byte[]{(byte) (crc & 0xFF), (byte) ((crc >> 8) & 0xFF)};
    }

    /**
     * 验证CRC
     */
    public static boolean verifyCRC(byte[] data, int length) {
        if (data == null || length < 3) return false;
        byte[] expected = crc16Modbus(data, length - 2);
        return expected[0] == data[length - 2] && expected[1] == data[length - 1];
    }

    // ==================== 命令构建 ====================

    /**
     * 开锁命令 - 功能码0x05 写单个线圈
     * 发送: [板地址] [0x05] [0x00] [锁号] [0xFF] [0x00] [CRC_L] [CRC_H]
     * 锁号范围: 1~16
     */
    public byte[] buildOpenLockCommand(int boardAddr, int lockNo) {
        byte[] cmd = new byte[6];
        cmd[0] = (byte) boardAddr;
        cmd[1] = (byte) FUNC_WRITE_SINGLE_COIL;
        cmd[2] = 0x00;
        cmd[3] = (byte) lockNo;
        cmd[4] = (byte) 0xFF;
        cmd[5] = 0x00;

        byte[] crc = crc16Modbus(cmd, cmd.length);
        byte[] frame = new byte[8];
        System.arraycopy(cmd, 0, frame, 0, 6);
        System.arraycopy(crc, 0, frame, 6, 2);

        Log.d(TAG, "构建WT开锁: board=" + boardAddr + ", lock=" + lockNo
                + ", frame=" + SerialPortManager.bytesToHex(frame));
        return frame;
    }

    /**
     * 查询锁状态 - 功能码0x02 读输入状态
     * 发送: [板地址] [0x02] [0x00] [0x01] [0x00] [0x10] [CRC_L] [CRC_H]
     * 起始地址0x0001, 读取数量0x0010(16个)
     */
    public byte[] buildReadStatusCommand(int boardAddr) {
        byte[] cmd = new byte[6];
        cmd[0] = (byte) boardAddr;
        cmd[1] = (byte) FUNC_READ_INPUT_STATUS;
        cmd[2] = 0x00;
        cmd[3] = 0x01;
        cmd[4] = 0x00;
        cmd[5] = 0x10;

        byte[] crc = crc16Modbus(cmd, cmd.length);
        byte[] frame = new byte[8];
        System.arraycopy(cmd, 0, frame, 0, 6);
        System.arraycopy(crc, 0, frame, 6, 2);

        Log.d(TAG, "构建WT状态查询: board=" + boardAddr);
        return frame;
    }

    // ==================== 命令发送 ====================

    /**
     * 发送开锁指令
     */
    public boolean sendOpenLock(int boardAddr, int lockNo) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            Log.e(TAG, "串口未打开");
            if (mCallback != null) mCallback.onError("串口未打开");
            return false;
        }

        if (lockNo < 1 || lockNo > 16) {
            Log.e(TAG, "WT锁号范围1~16, 当前: " + lockNo);
            if (mCallback != null) mCallback.onError("锁号超出范围(1~16)");
            return false;
        }

        byte[] cmd = buildOpenLockCommand(boardAddr, lockNo);
        mSerialPort.write(cmd);
        Log.i(TAG, "发送WT开锁: board=" + boardAddr + ", lock=" + lockNo);
        return true;
    }

    /**
     * 发送查询锁状态指令
     */
    public boolean sendReadStatus(int boardAddr) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            return false;
        }

        byte[] cmd = buildReadStatusCommand(boardAddr);
        mSerialPort.write(cmd);
        Log.i(TAG, "发送WT状态查询: board=" + boardAddr);
        return true;
    }

    // ==================== 响应解析 ====================

    /**
     * 解析开锁响应 (0x05)
     * 响应: [板地址] [0x05] [0x00] [锁号] [0xFF] [0x00] [CRC_L] [CRC_H]
     * 正常响应会回显发送数据
     */
    public int parseOpenLockResponse(byte[] response) {
        if (response == null || response.length < 6) {
            Log.w(TAG, "WT开锁响应太短: " + (response != null ? response.length : 0));
            return RESULT_FAIL;
        }

        int funcCode = response[1] & 0xFF;

        // 异常响应: 功能码最高位为1
        if ((funcCode & 0x80) != 0) {
            int errorCode = response[2] & 0xFF;
            Log.e(TAG, "WT开锁异常响应, 错误码: " + String.format("%02X", errorCode));
            return RESULT_FAIL;
        }

        if (funcCode != FUNC_WRITE_SINGLE_COIL) {
            Log.w(TAG, "WT功能码不匹配: " + String.format("%02X", funcCode));
            return RESULT_FORMAT_ERROR;
        }

        // CRC校验
        if (!verifyCRC(response, response.length)) {
            Log.w(TAG, "WT开锁CRC校验失败");
            return RESULT_CRC_ERROR;
        }

        Log.i(TAG, "WT开锁成功");
        return RESULT_SUCCESS;
    }

    /**
     * 解析锁状态响应 (0x02)
     * 响应: [板地址] [0x02] [0x02] [状态字节1] [状态字节2] [CRC_L] [CRC_H]
     * byte[3] = 锁1~8状态位, byte[4] = 锁9~16状态位
     * 0=打开, 1=关闭（取反逻辑）
     */
    public int[] parseLockStatusResponse(byte[] response) {
        if (response == null || response.length < 5) {
            Log.w(TAG, "WT状态响应太短");
            return null;
        }

        int funcCode = response[1] & 0xFF;
        if (funcCode != FUNC_READ_INPUT_STATUS) {
            Log.w(TAG, "WT状态功能码不匹配");
            return null;
        }

        // CRC校验
        if (!verifyCRC(response, response.length)) {
            Log.w(TAG, "WT状态CRC校验失败");
            return null;
        }

        int byteCount = response[2] & 0xFF;
        int[] status = new int[byteCount * 8];

        for (int i = 0; i < byteCount && (3 + i) < response.length - 2; i++) {
            int byteVal = response[3 + i] & 0xFF;
            for (int bit = 0; bit < 8; bit++) {
                // WT: 0=打开, 1=关闭 → 取反
                status[i * 8 + bit] = ((byteVal >> bit) & 1) == 0 ? 1 : 0;  // 1=开, 0=关
            }
        }

        int boardAddr = response[0] & 0xFF;
        if (mCallback != null) {
            mCallback.onLockStatusReceived(boardAddr, status);
        }

        Log.d(TAG, "WT锁状态解析完成, board=" + boardAddr + ", 锁数=" + status.length);
        return status;
    }

    /**
     * 获取单个锁状态
     * @param byte1 锁1~8状态字节
     * @param byte2 锁9~16状态字节
     * @param lockNo 锁号1~16
     * @return true=打开, false=关闭
     */
    public static boolean isLockOpen(int byte1, int byte2, int lockNo) {
        int value, bit;
        if (lockNo >= 1 && lockNo <= 8) {
            value = byte1;
            bit = lockNo - 1;
        } else if (lockNo >= 9 && lockNo <= 16) {
            value = byte2;
            bit = lockNo - 9;
        } else {
            return false;
        }
        // WT: 0=打开, 1=关闭
        return ((value >> bit) & 1) == 0;
    }

    /**
     * 处理接收数据
     */
    public void handleReceivedData(byte[] data, int length) {
        if (data == null || length < 3) return;

        Log.d(TAG, "WT收到数据: " + SerialPortManager.bytesToHex(data));

        int funcCode = data[1] & 0xFF;

        switch (funcCode) {
            case FUNC_WRITE_SINGLE_COIL:
                int result = parseOpenLockResponse(data);
                if (mCallback != null) {
                    int boardAddr = data[0] & 0xFF;
                    int lockNo = data[3] & 0xFF;
                    mCallback.onOpenLockResult(boardAddr, lockNo, result == RESULT_SUCCESS);
                }
                break;

            case FUNC_READ_INPUT_STATUS:
                parseLockStatusResponse(data);
                break;

            default:
                Log.w(TAG, "WT未知功能码: " + String.format("%02X", funcCode));
                break;
        }
    }
}
