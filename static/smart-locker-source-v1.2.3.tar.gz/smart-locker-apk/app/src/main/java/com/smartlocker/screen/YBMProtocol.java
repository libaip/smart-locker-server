package com.smartlocker.screen;

import android.util.Log;

/**
 * YBM锁控板协议实现 - 完整版
 * 
 * 帧格式: [HEAD] [CMD] [DATA1] [DATA2] [DATA3] [CHECKSUM]
 * HEAD = 0x7E (可选)
 * CHECKSUM = XOR校验 = CMD ⊕ DATA1 ⊕ DATA2 ⊕ DATA3
 * 
 * 兼容参考APK的协议格式
 */
public class YBMProtocol {
    private static final String TAG = "YBM";
    
    // 协议版本
    public static final int PROTOCOL_YBM = 1;
    public static final int PROTOCOL_WT = 2;
    
    // 命令码 - 开锁
    public static final int CMD_OPEN_LOCK_A = 0x9D;      // 开锁方式A (超时10s, 无响应)
    public static final int CMD_OPEN_LOCK_B = 0x80;       // 开锁方式B (超时800ms, 有响应)
    public static final int CMD_OPEN_ALL = 0xA5;          // 全部开锁
    
    // 命令码 - 设置
    public static final int CMD_SET = 0x9B;               // 设置指令
    public static final int CMD_SET_BOARD_NO = 0xDF;      // 板号设置
    public static final int CMD_SET_LOCK_COUNT = 0xD0;    // 设置锁数量
    
    // 命令码 - 查询
    public static final int CMD_READ_MCU_ID = 0xDD;      // 读取MCU ID
    public static final int CMD_READ_STATUS = 0xD1;       // 读取锁状态
    public static final int CMD_READ_VERSION = 0xDC;     // 读取版本号
    
    // 命令码 - 控制
    public static final int CMD_RESET = 0x01;             // 复位
    public static final int CMD_ENTER_SETUP = 0x02;       // 进入设置模式
    
    // 命令码 - 心跳
    public static final int CMD_HEARTBEAT = 0x10;         // 心跳检测
    
    // 开锁结果码
    public static final int RESULT_SUCCESS = 1;
    public static final int RESULT_SENT = 0;              // 命令已发送(方式A)
    public static final int RESULT_TIMEOUT = -1;
    public static final int RESULT_FAIL = -2;
    public static final int RESULT_CHECKSUM_ERROR = 2;
    public static final int RESULT_FORMAT_ERROR = 3;
    
    // 状态码
    public static final int STATUS_SUCCESS = 0x11;        // 成功
    public static final int STATUS_LOCK_OPEN = 0x22;       // 锁已开
    public static final int STATUS_LOCK_CLOSED = 0x33;     // 锁关闭
    public static final int STATUS_BUSY = 0x44;            // 忙
    public static final int STATUS_ERROR = 0x55;           // 错误
    
    private SerialPortManager mSerialPort;
    private int[] mBoardArr = {1};  // 主板编号数组，支持多主板
    private int mProtocolType = PROTOCOL_YBM;
    
    // 回调监听
    private OnLockCallback mLockCallback;
    
    public interface OnLockCallback {
        void onOpenLockResult(int boardNo, int lockNo, boolean success);
        void onMcuIdReceived(int boardNo, String mcuId);
        void onLockStatusReceived(int boardNo, int[] lockStatus);
        void onError(String message);
    }
    
    public void setLockCallback(OnLockCallback callback) {
        mLockCallback = callback;
    }
    
    public YBMProtocol(SerialPortManager serialPort) {
        mSerialPort = serialPort;
    }
    
    public YBMProtocol(SerialPortManager serialPort, int protocolType) {
        mSerialPort = serialPort;
        mProtocolType = protocolType;
    }
    
    // ==================== 命令构建 ====================
    
    /**
     * 开锁 - 方式B (有响应反馈, 推荐使用)
     * 发送: [0x80] [板号] [锁号] [0x33] [XOR]
     */
    public byte[] buildOpenLockCommand(int boardNo, int lockNo) {
        byte cmd = (byte) CMD_OPEN_LOCK_B;
        byte bBoard = (byte) (boardNo - 1);
        byte bLock = (byte) lockNo;
        byte param = 0x33;
        byte checksum = xorChecksum(cmd, bBoard, bLock, param);
        
        Log.d(TAG, "构建开锁命令: board=" + boardNo + ", lock=" + lockNo);
        return new byte[]{cmd, bBoard, bLock, param, checksum};
    }
    
    /**
     * 开锁 - 方式A (无详细响应，超时10秒)
     * 发送: [0x9D] [板号] [锁号] [0x10] [XOR]
     */
    public byte[] buildOpenLockCommandA(int boardNo, int lockNo) {
        byte cmd = (byte) CMD_OPEN_LOCK_A;
        byte bBoard = (byte) (boardNo - 1);
        byte bLock = (byte) lockNo;
        byte param = 0x10;
        byte checksum = xorChecksum(cmd, bBoard, bLock, param);
        
        Log.d(TAG, "构建开锁命令A: board=" + boardNo + ", lock=" + lockNo);
        return new byte[]{cmd, bBoard, bLock, param, checksum};
    }
    
    /**
     * 全部开锁 - 打开所有柜门
     * 发送: [0xA5] [板号] [0xFF] [0xFF] [XOR]
     */
    public byte[] buildOpenAllCommand() {
        return buildOpenAllCommand(mBoardArr[0]);
    }
    
    public byte[] buildOpenAllCommand(int boardNo) {
        byte cmd = (byte) CMD_OPEN_ALL;
        byte bBoard = (byte) (boardNo - 1);
        byte param1 = (byte) 0xFF;
        byte param2 = (byte) 0xFF;
        byte checksum = xorChecksum(cmd, bBoard, param1, param2);
        
        Log.i(TAG, "构建全开命令: board=" + boardNo);
        return new byte[]{cmd, bBoard, param1, param2, checksum};
    }
    
    /**
     * 读取MCU ID
     * 发送: [0xDD] [板号] [0x11] [0x11] [XOR]
     */
    public byte[] buildReadMcuIdCommand(int boardNo) {
        byte cmd = (byte) CMD_READ_MCU_ID;
        byte bBoard = (byte) (boardNo - 1);
        byte param1 = 0x11;
        byte param2 = 0x11;
        byte checksum = xorChecksum(cmd, bBoard, param1, param2);
        
        Log.d(TAG, "构建读MCU ID命令: board=" + boardNo);
        return new byte[]{cmd, bBoard, param1, param2, checksum};
    }
    
    /**
     * 设置板号
     * 发送: [0xDF] [板号] [0x01] [设置参数] [XOR]
     */
    public byte[] buildSetBoardNoCommand(int boardNo, int setParam) {
        byte cmd = (byte) CMD_SET_BOARD_NO;
        byte bBoard = (byte) (boardNo - 1);
        byte param1 = 0x01;
        byte param2 = (byte) (setParam - 1);
        byte checksum = xorChecksum(cmd, bBoard, param1, param2);
        
        Log.i(TAG, "构建设置板号命令: board=" + boardNo + ", param=" + setParam);
        return new byte[]{cmd, bBoard, param1, param2, checksum};
    }
    
    /**
     * 读取锁状态
     * 发送: [0xD1] [板号] [0x00] [0x00] [XOR]
     * 响应: [0xD1] [板号] [状态字节1] [状态字节2] [XOR]
     */
    public byte[] buildReadStatusCommand(int boardNo) {
        byte cmd = (byte) CMD_READ_STATUS;
        byte bBoard = (byte) (boardNo - 1);
        byte param1 = 0x00;
        byte param2 = 0x00;
        byte checksum = xorChecksum(cmd, bBoard, param1, param2);
        
        return new byte[]{cmd, bBoard, param1, param2, checksum};
    }
    
    /**
     * 心跳检测
     * 发送: [0x10] [板号] [0x55] [0x55] [XOR]
     */
    public byte[] buildHeartbeatCommand(int boardNo) {
        byte cmd = (byte) CMD_HEARTBEAT;
        byte bBoard = (byte) (boardNo - 1);
        byte param1 = 0x55;
        byte param2 = 0x55;
        byte checksum = xorChecksum(cmd, bBoard, param1, param2);
        
        return new byte[]{cmd, bBoard, param1, param2, checksum};
    }
    
    /**
     * 复位指令
     */
    public byte[] buildResetCommand(int boardNo) {
        byte cmd = (byte) CMD_RESET;
        byte bBoard = (byte) (boardNo - 1);
        byte param1 = 0x00;
        byte param2 = 0x00;
        byte checksum = xorChecksum(cmd, bBoard, param1, param2);
        
        return new byte[]{cmd, bBoard, param1, param2, checksum};
    }
    
    // ==================== 命令发送 ====================
    
    /**
     * 发送开锁指令 (方式B)
     */
    public boolean sendOpenLock(int boardNo, int lockNo) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            Log.e(TAG, "串口未打开");
            if (mLockCallback != null) {
                mLockCallback.onError("串口未打开");
            }
            return false;
        }
        
        if (mProtocolType == PROTOCOL_WT) {
            return sendOpenLockWT(boardNo, lockNo);
        }
        
        byte[] cmd = buildOpenLockCommand(boardNo, lockNo);
        mSerialPort.write(cmd);
        Log.i(TAG, "发送开锁: board=" + boardNo + ", lock=" + lockNo);
        return true;
    }
    
    /**
     * 发送开锁指令 (方式A)
     */
    public boolean sendOpenLockA(int boardNo, int lockNo) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            Log.e(TAG, "串口未打开");
            return false;
        }
        
        byte[] cmd = buildOpenLockCommandA(boardNo, lockNo);
        mSerialPort.write(cmd);
        Log.i(TAG, "发送开锁A: board=" + boardNo + ", lock=" + lockNo);
        return true;
    }
    
    /**
     * 发送全部开锁指令
     */
    public boolean sendOpenAll() {
        return sendOpenAll(mBoardArr[0]);
    }
    
    public boolean sendOpenAll(int boardNo) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            Log.e(TAG, "串口未打开");
            return false;
        }
        
        byte[] cmd = buildOpenAllCommand(boardNo);
        mSerialPort.write(cmd);
        Log.i(TAG, "发送全开: board=" + boardNo);
        return true;
    }
    
    /**
     * 发送读取MCU ID指令
     */
    public boolean sendReadMcuId(int boardNo) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            Log.e(TAG, "串口未打开");
            return false;
        }
        
        byte[] cmd = buildReadMcuIdCommand(boardNo);
        mSerialPort.write(cmd);
        Log.i(TAG, "发送读MCU ID: board=" + boardNo);
        return true;
    }
    
    /**
     * 发送设置板号指令
     */
    public boolean sendSetBoardNo(int boardNo, int setParam) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            return false;
        }
        
        byte[] cmd = buildSetBoardNoCommand(boardNo, setParam);
        mSerialPort.write(cmd);
        return true;
    }
    
    /**
     * 设置指令
     * 发送: [0x9B] [板号] [参数1] [0x10] [XOR]
     */
    public byte[] buildSetCommand(int boardNo, int param1) {
        byte cmd = (byte) CMD_SET;
        byte bBoard = (byte) (boardNo - 1);
        byte bParam1 = (byte) param1;
        byte param2 = 0x10;
        byte checksum = xorChecksum(cmd, bBoard, bParam1, param2);
        
        Log.d(TAG, "构建设置命令: board=" + boardNo + ", param=" + param1);
        return new byte[]{cmd, bBoard, bParam1, param2, checksum};
    }
    
    /**
     * 发送设置指令
     */
    public boolean sendSetCommand(int boardNo, int param1) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            Log.e(TAG, "串口未打开");
            return false;
        }
        byte[] cmd = buildSetCommand(boardNo, param1);
        mSerialPort.write(cmd);
        Log.i(TAG, "发送设置: board=" + boardNo + ", param=" + param1);
        return true;
    }
    
    /**
     * 发送心跳检测
     */
    public boolean sendHeartbeat(int boardNo) {
        if (mSerialPort == null || !mSerialPort.isOpened()) {
            return false;
        }
        
        byte[] cmd = buildHeartbeatCommand(boardNo);
        mSerialPort.write(cmd);
        return true;
    }
    
    /**
     * 发送全部心跳（多主板）
     */
    public void sendHeartbeatAll() {
        for (int boardNo : mBoardArr) {
            sendHeartbeat(boardNo);
        }
    }
    
    // ==================== 响应解析 ====================
    
    /**
     * 解析开锁响应 (0x80方式B)
     * 响应格式: [0x80] [DATA1] [STATUS] [XOR]
     * STATUS == 0x11 → 成功
     */
    public int parseOpenLockResponse(byte[] response) {
        if (response == null || response.length < 4) {
            Log.w(TAG, "响应数据太短: " + (response != null ? response.length : 0));
            return RESULT_FAIL;
        }
        
        int cmd = response[0] & 0xFF;
        if (cmd != CMD_OPEN_LOCK_B) {
            Log.w(TAG, "响应命令码不匹配: " + String.format("%02X", cmd));
            return RESULT_FORMAT_ERROR;
        }
        
        int boardNo = response[1] & 0xFF;
        int status = response[2] & 0xFF;
        
        // XOR校验
        byte expectedChecksum = xorChecksum(response[0], response[1], response[2]);
        if (expectedChecksum != response[3]) {
            Log.w(TAG, "XOR校验失败: expected=" + String.format("%02X", expectedChecksum) 
                    + ", actual=" + String.format("%02X", response[3]));
            return RESULT_CHECKSUM_ERROR;
        }
        
        Log.d(TAG, "开锁响应: board=" + boardNo + ", status=" + String.format("%02X", status));
        
        if (status == STATUS_SUCCESS || status == STATUS_LOCK_OPEN) {
            Log.i(TAG, "开锁成功! board=" + boardNo);
            return RESULT_SUCCESS;
        } else {
            Log.w(TAG, "开锁失败, status=" + String.format("%02X", status));
            return RESULT_FAIL;
        }
    }
    
    /**
     * 解析MCU ID响应
     * 响应格式: [0xDD] [板号] [ID字节...] [XOR]
     */
    public String parseMcuIdResponse(byte[] response) {
        if (response == null || response.length < 6) {
            Log.w(TAG, "MCU ID响应太短: " + (response != null ? response.length : 0));
            return null;
        }
        
        // 验证命令码
        if ((response[0] & 0xFF) != CMD_READ_MCU_ID) {
            Log.w(TAG, "MCU ID命令码不匹配");
            return null;
        }
        
        int boardNo = response[1] & 0xFF;
        
        // 提取ID（通常在中间字节）
        StringBuilder idBuilder = new StringBuilder();
        for (int i = 2; i < response.length - 1; i++) {
            idBuilder.append(String.format("%02X", response[i]));
        }
        
        String mcuId = idBuilder.toString();
        Log.i(TAG, "MCU ID: " + mcuId + " (board=" + boardNo + ")");
        
        if (mLockCallback != null) {
            mLockCallback.onMcuIdReceived(boardNo, mcuId);
        }
        
        return mcuId;
    }
    
    /**
     * 解析锁状态响应
     * 响应格式: [0xD1] [板号] [状态字节1] [状态字节2] ... [XOR]
     * 每个位表示一个锁的状态: 0=关闭, 1=打开
     */
    public int[] parseLockStatusResponse(byte[] response) {
        if (response == null || response.length < 4) {
            return null;
        }
        
        if ((response[0] & 0xFF) != CMD_READ_STATUS) {
            return null;
        }
        
        int boardNo = response[1] & 0xFF;
        int statusBytes = response.length - 3;  // 减去头、校验
        
        int[] status = new int[statusBytes * 8];  // 每个字节8位
        
        int index = 0;
        for (int i = 2; i < response.length - 1; i++) {
            for (int bit = 0; bit < 8; bit++) {
                status[index++] = (response[i] >> bit) & 0x01;
            }
        }
        
        if (mLockCallback != null) {
            mLockCallback.onLockStatusReceived(boardNo, status);
        }
        
        return status;
    }
    
    /**
     * 处理接收到的数据（由SerialPortManager调用）
     */
    public void handleReceivedData(byte[] data, int length) {
        if (data == null || length == 0) return;
        
        Log.d(TAG, "收到数据: " + SerialPortManager.bytesToHex(data));
        
        int cmd = data[0] & 0xFF;
        
        switch (cmd) {
            case CMD_OPEN_LOCK_B:
                int result = parseOpenLockResponse(data);
                if (mLockCallback != null) {
                    // 根据响应获取板号和锁号（需要上层配合传递上下文）
                    mLockCallback.onOpenLockResult(0, 0, result == RESULT_SUCCESS);
                }
                break;
                
            case CMD_READ_MCU_ID:
                parseMcuIdResponse(data);
                break;
                
            case CMD_READ_STATUS:
                parseLockStatusResponse(data);
                break;
                
            default:
                Log.w(TAG, "未知命令: " + String.format("%02X", cmd));
                break;
        }
    }
    
    // ==================== WT/QM板协议支持 ====================
    
    private WTProtocol mWTProtocol;
    private QMProtocol mQMProtocol;
    
    /**
     * 设置WT协议实例（用于混合协议场景）
     */
    public void setWTProtocol(WTProtocol wtProtocol) {
        this.mWTProtocol = wtProtocol;
    }
    
    /**
     * 设置QM协议实例
     */
    public void setQMProtocol(QMProtocol qmProtocol) {
        this.mQMProtocol = qmProtocol;
    }
    
    /**
     * WT板开锁 - Modbus RTU功能码0x05
     * 发送: [板地址] [0x05] [0x00] [锁号] [0xFF] [0x00] [CRC_L] [CRC_H]
     */
    private boolean sendOpenLockWT(int boardNo, int lockNo) {
        if (mWTProtocol == null) {
            mWTProtocol = new WTProtocol(mSerialPort);
        }
        return mWTProtocol.sendOpenLock(boardNo, lockNo);
    }
    
    /**
     * QM板开锁
     * 发送: [0x5A] [0x23] [板地址H] [板地址L] [锁号H] [锁号L] [XOR]
     */
    private boolean sendOpenLockQM(int boardNo, int lockNo) {
        if (mQMProtocol == null) {
            mQMProtocol = new QMProtocol(mSerialPort);
        }
        return mQMProtocol.sendOpenLock(boardNo, lockNo);
    }
    
    /**
     * 统一开锁入口 - 根据协议类型自动路由
     */
    public boolean sendOpenLockByProtocol(int protocolType, int boardNo, int lockNo) {
        switch (protocolType) {
            case PROTOCOL_YBM:
                return sendOpenLock(boardNo, lockNo);
            case PROTOCOL_WT:
                return sendOpenLockWT(boardNo, lockNo);
            case PROTOCOL_QM:
                return sendOpenLockQM(boardNo, lockNo);
            default:
                Log.e(TAG, "未知协议类型: " + protocolType);
                return false;
        }
    }
    
    // 协议类型扩展
    public static final int PROTOCOL_QM = 3;
    
    // ==================== 工具方法 ====================
    
    private byte xorChecksum(byte... data) {
        byte result = 0;
        for (byte b : data) {
            result ^= b;
        }
        return result;
    }
    
    /**
     * 设置主板编号数组（支持多主板）
     */
    public void setBoardArr(int[] boards) {
        this.mBoardArr = boards;
    }
    
    /**
     * 获取主板编号数组
     */
    public int[] getBoardArr() {
        return mBoardArr;
    }
    
    /**
     * 设置协议类型
     */
    public void setProtocolType(int type) {
        this.mProtocolType = type;
    }
    
    /**
     * 获取协议类型
     */
    public int getProtocolType() {
        return mProtocolType;
    }
    
    /**
     * 检查是否为YBM协议
     */
    public boolean isYBMProtocol() {
        return mProtocolType == PROTOCOL_YBM;
    }
    
    /**
     * 检查是否为WT协议
     */
    public boolean isWTProtocol() {
        return mProtocolType == PROTOCOL_WT;
    }
}
