package com.smartlocker.screen.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * SQLite数据库助手
 * 兼容参考APK的USER表结构
 */
public class DBHelper extends SQLiteOpenHelper {
    private static final String TAG = "DBHelper";
    private static DBHelper instance;
    
    // 数据库配置
    private static final String DB_NAME = "locker.db";
    private static final int DB_VERSION = 4;
    
    // USER表 - 存储设备配置
    public static final String TABLE_USER = "user";
    public static final String COL_ID = "_id";
    public static final String COL_SR_ALIASNO = "sr_aliasno";       // 设备别名编号
    public static final String COL_SR_USERNAME = "sr_username";     // 用户名
    public static final String COL_SR_PASSWORD = "sr_password";      // 密码
    public static final String COL_SR_BOARDNO = "sr_boardno";        // 主板编号
    public static final String COL_SR_LOCKNO = "sr_lockno";         // 锁编号
    public static final String COL_SR_LASTTIME = "sr_lasttime";      // 最后操作时间
    public static final String COL_SR_BAUDRATE = "sr_baudrate";      // 波特率
    public static final String COL_SR_SERIAL_PORT = "sr_serial_port"; // 串口路径
    public static final String COL_SR_DEVICE_STATUS = "sr_device_status"; // 设备状态
    public static final String COL_SR_IPHONE_NUM = "sr_iphone_num"; // 手机号
    public static final String COL_SR_IS_SHOW_DOOR = "sr_is_show_door"; // 是否显示柜门
    public static final String COL_SR_MAINTAIN_PHONE = "sr_maintain_phone"; // 维护电话
    public static final String COL_SR_ORDER_ENDTIME = "sr_order_endtime"; // 订单结束时间
    public static final String COL_SR_ORDER_STATUS = "sr_order_status"; // 订单状态
    public static final String COL_SR_QR_CODE = "sr_qr_code";        // 二维码
    
    // SETTINGS表 - 存储设置参数
    public static final String TABLE_SETTINGS = "settings";
    public static final String COL_SI_KEY = "si_key";
    public static final String COL_SI_VALUE = "si_value";
    
    // 预设设置键
    public static final String KEY_BOARD_NUMBER = "si_board_number";      // 主板编号
    public static final String KEY_LOCK_NUMBER = "si_lock_number";        // 锁编号
    public static final String KEY_MAINBOARD_ID = "si_mainboard_id";      // 主板ID
    public static final String KEY_TIME_SLOT = "si_time_slot";            // 时间段
    
    // LOCK_RECORDS表 - 开锁记录
    public static final String TABLE_LOCK_RECORDS = "lock_records";
    public static final String COL_RECORD_ID = "_id";
    public static final String COL_ORDER_ID = "order_id";
    public static final String COL_BOARD_NO = "board_no";
    public static final String COL_LOCK_NO = "lock_no";
    public static final String COL_OPEN_TIME = "open_time";
    public static final String COL_OPEN_TYPE = "open_type";  // 0=取件, 1=管理员, 2=远程
    public static final String COL_RESULT = "result";
    
    // STORE_INFO表 - 网点信息
    public static final String TABLE_STORE_INFO = "store_info";
    public static final String COL_STORE_NAME = "store_name";
    public static final String COL_STORE_ADDRESS = "store_address";
    public static final String COL_BUSINESS_HOURS = "business_hours";
    public static final String COL_CUSTOMER_PHONE = "customer_phone";
    public static final String COL_AVAILABLE_BOXES = "available_boxes";
    public static final String COL_TOTAL_BOXES = "total_boxes";
    
    private DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    
    public static synchronized DBHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DBHelper(context.getApplicationContext());
        }
        return instance;
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        // USER表
        String sqlUser = "CREATE TABLE " + TABLE_USER + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_SR_ALIASNO + " TEXT, "
                + COL_SR_USERNAME + " TEXT, "
                + COL_SR_PASSWORD + " TEXT, "
                + COL_SR_BOARDNO + " INTEGER DEFAULT 1, "
                + COL_SR_LOCKNO + " INTEGER DEFAULT 1, "
                + COL_SR_LASTTIME + " TEXT, "
                + COL_SR_BAUDRATE + " INTEGER DEFAULT 9600, "
                + COL_SR_SERIAL_PORT + " TEXT DEFAULT '/dev/ttyS1', "
                + COL_SR_DEVICE_STATUS + " INTEGER DEFAULT 0, "
                + COL_SR_IPHONE_NUM + " TEXT, "
                + COL_SR_IS_SHOW_DOOR + " INTEGER DEFAULT 1, "
                + COL_SR_MAINTAIN_PHONE + " TEXT, "
                + COL_SR_ORDER_ENDTIME + " TEXT, "
                + COL_SR_ORDER_STATUS + " INTEGER DEFAULT 0, "
                + COL_SR_QR_CODE + " TEXT"
                + ")";
        
        // SETTINGS表
        String sqlSettings = "CREATE TABLE " + TABLE_SETTINGS + " ("
                + COL_SI_KEY + " TEXT PRIMARY KEY, "
                + COL_SI_VALUE + " TEXT"
                + ")";
        
        // LOCK_RECORDS表
        String sqlRecords = "CREATE TABLE " + TABLE_LOCK_RECORDS + " ("
                + COL_RECORD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ORDER_ID + " TEXT, "
                + COL_BOARD_NO + " INTEGER, "
                + COL_LOCK_NO + " INTEGER, "
                + COL_OPEN_TIME + " TEXT, "
                + COL_OPEN_TYPE + " INTEGER, "
                + COL_RESULT + " INTEGER"
                + ")";
        
        // STORE_INFO表
        String sqlStore = "CREATE TABLE " + TABLE_STORE_INFO + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_STORE_NAME + " TEXT, "
                + COL_STORE_ADDRESS + " TEXT, "
                + COL_BUSINESS_HOURS + " TEXT, "
                + COL_CUSTOMER_PHONE + " TEXT, "
                + COL_AVAILABLE_BOXES + " INTEGER DEFAULT 0, "
                + COL_TOTAL_BOXES + " INTEGER DEFAULT 0"
                + ")";
        
        db.execSQL(sqlUser);
        db.execSQL(sqlSettings);
        db.execSQL(sqlRecords);
        db.execSQL(sqlStore);
        
        Log.i(TAG, "数据库表创建完成");
        
        // 初始化默认设置
        initDefaultSettings(db);
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(TAG, "数据库升级: " + oldVersion + " -> " + newVersion);
        
        if (oldVersion < 2) {
            // v1到v2的升级
            db.execSQL("ALTER TABLE " + TABLE_USER + " ADD COLUMN " + COL_SR_QR_CODE + " TEXT");
        }
        
        if (oldVersion < 3) {
            // v2到v3的升级
            db.execSQL("ALTER TABLE " + TABLE_USER + " ADD COLUMN " + COL_SR_MAINTAIN_PHONE + " TEXT");
        }
        
        if (oldVersion < 4) {
            // v3到v4: 新增离线缓存表
            db.execSQL("CREATE TABLE IF NOT EXISTS cached_orders (" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "order_id INTEGER, " +
                    "order_no TEXT, " +
                    "user_phone TEXT, " +
                    "access_code TEXT, " +
                    "deposit_amount REAL, " +
                    "compartment_number INTEGER, " +
                    "slot_size TEXT, " +
                    "cabinet_id INTEGER, " +
                    "store_time TEXT, " +
                    "cached_at TEXT, " +
                    "expires_at TEXT)");
            
            db.execSQL("CREATE TABLE IF NOT EXISTS offline_retrieve_records (" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "order_id INTEGER, " +
                    "order_no TEXT, " +
                    "user_phone TEXT, " +
                    "retrieve_time TEXT, " +
                    "synced INTEGER DEFAULT 0, " +
                    "created_at TEXT)");
            
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_cached_order_phone ON cached_orders(user_phone)");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_cached_order_code ON cached_orders(access_code)");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_offline_sync ON offline_retrieve_records(synced)");
        }
    }
    
    private void initDefaultSettings(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put(COL_SI_KEY, KEY_BOARD_NUMBER);
        values.put(COL_SI_VALUE, "1");
        db.insert(TABLE_SETTINGS, null, values);
        
        values.clear();
        values.put(COL_SI_KEY, KEY_LOCK_NUMBER);
        values.put(COL_SI_VALUE, "12");
        db.insert(TABLE_SETTINGS, null, values);
        
        values.clear();
        values.put(COL_SI_KEY, KEY_TIME_SLOT);
        values.put(COL_SI_VALUE, "0");
        db.insert(TABLE_SETTINGS, null, values);
    }
    
    // ==================== USER表操作 ====================
    
    /**
     * 插入或更新用户记录
     */
    public long insertOrUpdateUser(ContentValues values) {
        SQLiteDatabase db = getWritableDatabase();
        long id = db.insertWithOnConflict(TABLE_USER, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        Log.d(TAG, "插入/更新用户: id=" + id);
        return id;
    }
    
    /**
     * 获取所有用户记录
     */
    public List<ContentValues> getAllUsers() {
        List<ContentValues> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, null, null, null, null, null, COL_ID + " DESC");
        
        while (cursor.moveToNext()) {
            ContentValues values = new ContentValues();
            for (String col : cursor.getColumnNames()) {
                int idx = cursor.getColumnIndex(col);
                switch (cursor.getType(idx)) {
                    case Cursor.FIELD_TYPE_INTEGER:
                        values.put(col, cursor.getInt(idx));
                        break;
                    case Cursor.FIELD_TYPE_STRING:
                        values.put(col, cursor.getString(idx));
                        break;
                    case Cursor.FIELD_TYPE_FLOAT:
                        values.put(col, cursor.getFloat(idx));
                        break;
                }
            }
            list.add(values);
        }
        cursor.close();
        return list;
    }
    
    /**
     * 根据设备状态获取用户
     */
    public List<ContentValues> getUsersByStatus(int status) {
        List<ContentValues> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, null, 
                COL_SR_DEVICE_STATUS + "=?", new String[]{String.valueOf(status)},
                null, null, null);
        
        while (cursor.moveToNext()) {
            ContentValues values = new ContentValues();
            for (String col : cursor.getColumnNames()) {
                int idx = cursor.getColumnIndex(col);
                if (cursor.getType(idx) == Cursor.FIELD_TYPE_STRING) {
                    values.put(col, cursor.getString(idx));
                } else if (cursor.getType(idx) == Cursor.FIELD_TYPE_INTEGER) {
                    values.put(col, cursor.getInt(idx));
                }
            }
            list.add(values);
        }
        cursor.close();
        return list;
    }
    
    /**
     * 删除用户
     */
    public int deleteUser(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_USER, COL_ID + "=?", new String[]{String.valueOf(id)});
    }
    
    /**
     * 更新设备状态
     */
    public int updateDeviceStatus(long id, int status) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_SR_DEVICE_STATUS, status);
        return db.update(TABLE_USER, values, COL_ID + "=?", new String[]{String.valueOf(id)});
    }
    
    // ==================== SETTINGS表操作 ====================
    
    /**
     * 获取设置值
     */
    public String getSetting(String key) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_SETTINGS, new String[]{COL_SI_VALUE},
                COL_SI_KEY + "=?", new String[]{key}, null, null, null);
        
        String value = null;
        if (cursor.moveToFirst()) {
            value = cursor.getString(0);
        }
        cursor.close();
        return value;
    }
    
    /**
     * 获取设置值（整型）
     */
    public int getSettingInt(String key, int defaultValue) {
        String value = getSetting(key);
        return value != null ? Integer.parseInt(value) : defaultValue;
    }
    
    /**
     * 保存设置
     */
    public void setSetting(String key, String value) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_SI_KEY, key);
        values.put(COL_SI_VALUE, value);
        db.insertWithOnConflict(TABLE_SETTINGS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }
    
    /**
     * 保存设置（整型）
     */
    public void setSetting(String key, int value) {
        setSetting(key, String.valueOf(value));
    }
    
    // ==================== LOCK_RECORDS表操作 ====================
    
    /**
     * 记录开锁
     */
    public long recordOpenLock(String orderId, int boardNo, int lockNo, int openType, boolean success) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ORDER_ID, orderId);
        values.put(COL_BOARD_NO, boardNo);
        values.put(COL_LOCK_NO, lockNo);
        values.put(COL_OPEN_TIME, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
        values.put(COL_OPEN_TYPE, openType);
        values.put(COL_RESULT, success ? 1 : 0);
        long id = db.insert(TABLE_LOCK_RECORDS, null, values);
        Log.i(TAG, "记录开锁: orderId=" + orderId + ", board=" + boardNo + ", lock=" + lockNo + ", result=" + success);
        return id;
    }
    
    /**
     * 获取最近开锁记录
     */
    public List<ContentValues> getRecentRecords(int limit) {
        List<ContentValues> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_LOCK_RECORDS, null, null, null, null, null,
                COL_OPEN_TIME + " DESC", String.valueOf(limit));
        
        while (cursor.moveToNext()) {
            ContentValues values = new ContentValues();
            for (String col : cursor.getColumnNames()) {
                int idx = cursor.getColumnIndex(col);
                if (cursor.getType(idx) == Cursor.FIELD_TYPE_STRING) {
                    values.put(col, cursor.getString(idx));
                } else if (cursor.getType(idx) == Cursor.FIELD_TYPE_INTEGER) {
                    values.put(col, cursor.getInt(idx));
                }
            }
            list.add(values);
        }
        cursor.close();
        return list;
    }
    
    /**
     * 清空旧记录（保留最近N条）
     */
    public void cleanOldRecords(int keepCount) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = "DELETE FROM " + TABLE_LOCK_RECORDS + " WHERE " + COL_RECORD_ID 
                + " NOT IN (SELECT " + COL_RECORD_ID + " FROM " + TABLE_LOCK_RECORDS 
                + " ORDER BY " + COL_OPEN_TIME + " DESC LIMIT " + keepCount + ")";
        db.execSQL(sql);
        Log.i(TAG, "清理旧记录完成");
    }
    
    // ==================== STORE_INFO表操作 ====================
    
    /**
     * 保存网点信息
     */
    public void saveStoreInfo(String name, String address, String hours, String phone, int available, int total) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_STORE_NAME, name);
        values.put(COL_STORE_ADDRESS, address);
        values.put(COL_BUSINESS_HOURS, hours);
        values.put(COL_CUSTOMER_PHONE, phone);
        values.put(COL_AVAILABLE_BOXES, available);
        values.put(COL_TOTAL_BOXES, total);
        db.insertWithOnConflict(TABLE_STORE_INFO, null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }
    
    /**
     * 获取网点信息
     */
    public ContentValues getStoreInfo() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_STORE_INFO, null, null, null, null, null, null);
        
        ContentValues values = null;
        if (cursor.moveToFirst()) {
            values = new ContentValues();
            for (String col : cursor.getColumnNames()) {
                int idx = cursor.getColumnIndex(col);
                if (cursor.getType(idx) == Cursor.FIELD_TYPE_STRING) {
                    values.put(col, cursor.getString(idx));
                } else if (cursor.getType(idx) == Cursor.FIELD_TYPE_INTEGER) {
                    values.put(col, cursor.getInt(idx));
                }
            }
        }
        cursor.close();
        return values;
    }
    
    /**
     * 更新可用柜门数量
     */
    public void updateAvailableBoxes(int available) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_AVAILABLE_BOXES, available);
        db.update(TABLE_STORE_INFO, values, null, null);
    }
    // ==================== CACHED_ORDERS表操作（离线订单缓存） ====================

    /**
     * 刷新活跃订单缓存（先清空再批量插入）
     */
    public void refreshCachedOrders(List<ContentValues> orders) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.beginTransaction();
            // 清空旧缓存
            db.delete("cached_orders", null, null);
            // 批量插入
            String now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
            // 缓存2小时后过期
            String expiresAt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    .format(new Date(System.currentTimeMillis() + 2 * 60 * 60 * 1000));
            for (ContentValues order : orders) {
                ContentValues values = new ContentValues();
                values.put("order_id", order.getAsInteger("order_id"));
                values.put("order_no", order.getAsString("order_no"));
                values.put("user_phone", order.getAsString("user_phone"));
                values.put("access_code", order.getAsString("access_code"));
                if (order.containsKey("deposit_amount"))
                    values.put("deposit_amount", order.getAsDouble("deposit_amount"));
                if (order.containsKey("compartment_number"))
                    values.put("compartment_number", order.getAsInteger("compartment_number"));
                if (order.containsKey("slot_size"))
                    values.put("slot_size", order.getAsString("slot_size"));
                if (order.containsKey("cabinet_id"))
                    values.put("cabinet_id", order.getAsInteger("cabinet_id"));
                if (order.containsKey("store_time"))
                    values.put("store_time", order.getAsString("store_time"));
                values.put("cached_at", now);
                values.put("expires_at", expiresAt);
                db.insert("cached_orders", null, values);
            }
            db.setTransactionSuccessful();
            Log.i(TAG, "刷新订单缓存: " + orders.size() + "条");
        } finally {
            db.endTransaction();
        }
    }

    /**
     * 离线验证取包 - 通过手机号+密码匹配
     * @return 匹配的订单，null表示未找到或已过期
     */
    public ContentValues findCachedOrder(String phone, String accessCode) {
        SQLiteDatabase db = getReadableDatabase();
        String now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        
        Cursor cursor = db.query("cached_orders", null,
                "user_phone = ? AND access_code = ? AND expires_at > ?",
                new String[]{phone, accessCode, now},
                null, null, "_id DESC LIMIT 1");
        
        ContentValues result = null;
        if (cursor.moveToFirst()) {
            result = new ContentValues();
            for (String col : cursor.getColumnNames()) {
                int idx = cursor.getColumnIndex(col);
                if (cursor.getType(idx) == Cursor.FIELD_TYPE_STRING) {
                    result.put(col, cursor.getString(idx));
                } else if (cursor.getType(idx) == Cursor.FIELD_TYPE_INTEGER) {
                    result.put(col, cursor.getInt(idx));
                } else if (cursor.getType(idx) == Cursor.FIELD_TYPE_FLOAT) {
                    result.put(col, cursor.getFloat(idx));
                }
            }
        }
        cursor.close();
        
        if (result != null) {
            Log.i(TAG, "离线验证成功: phone=" + phone + ", orderId=" + result.getAsInteger("order_id"));
        } else {
            Log.w(TAG, "离线验证失败: phone=" + phone + ", code=" + accessCode);
        }
        
        return result;
    }

    /**
     * 获取所有未过期的缓存订单
     */
    public List<ContentValues> getValidCachedOrders() {
        List<ContentValues> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        
        Cursor cursor = db.query("cached_orders", null,
                "expires_at > ?", new String[]{now},
                null, null, "_id DESC");
        
        while (cursor.moveToNext()) {
            ContentValues values = new ContentValues();
            for (String col : cursor.getColumnNames()) {
                int idx = cursor.getColumnIndex(col);
                if (cursor.getType(idx) == Cursor.FIELD_TYPE_STRING) {
                    values.put(col, cursor.getString(idx));
                } else if (cursor.getType(idx) == Cursor.FIELD_TYPE_INTEGER) {
                    values.put(col, cursor.getInt(idx));
                } else if (cursor.getType(idx) == Cursor.FIELD_TYPE_FLOAT) {
                    values.put(col, cursor.getFloat(idx));
                }
            }
            list.add(values);
        }
        cursor.close();
        return list;
    }

    /**
     * 清理过期缓存
     */
    public void cleanExpiredCache() {
        SQLiteDatabase db = getWritableDatabase();
        String now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        int deleted = db.delete("cached_orders", "expires_at <= ?", new String[]{now});
        if (deleted > 0) {
            Log.i(TAG, "清理过期订单缓存: " + deleted + "条");
        }
    }

    // ==================== OFFLINE_RETRIEVE_RECORDS表操作（离线取包记录） ====================

    /**
     * 记录离线取包操作
     */
    public long recordOfflineRetrieve(int orderId, String orderNo, String phone) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("order_id", orderId);
        values.put("order_no", orderNo);
        values.put("user_phone", phone);
        values.put("retrieve_time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
        values.put("synced", 0);
        values.put("created_at", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
        long id = db.insert("offline_retrieve_records", null, values);
        Log.i(TAG, "记录离线取包: orderId=" + orderId + ", phone=" + phone);
        return id;
    }

    /**
     * 获取未同步的离线取包记录
     */
    public List<ContentValues> getUnsyncedRetrieves() {
        List<ContentValues> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("offline_retrieve_records", null,
                "synced = 0", null, null, null, "_id ASC");
        
        while (cursor.moveToNext()) {
            ContentValues values = new ContentValues();
            for (String col : cursor.getColumnNames()) {
                int idx = cursor.getColumnIndex(col);
                if (cursor.getType(idx) == Cursor.FIELD_TYPE_STRING) {
                    values.put(col, cursor.getString(idx));
                } else if (cursor.getType(idx) == Cursor.FIELD_TYPE_INTEGER) {
                    values.put(col, cursor.getInt(idx));
                }
            }
            list.add(values);
        }
        cursor.close();
        return list;
    }

    /**
     * 标记离线取包记录为已同步
     */
    public void markRetrievesSynced(List<Integer> recordIds) {
        if (recordIds.isEmpty()) return;
        SQLiteDatabase db = getWritableDatabase();
        for (int id : recordIds) {
            ContentValues values = new ContentValues();
            values.put("synced", 1);
            db.update("offline_retrieve_records", values, "_id = ?", new String[]{String.valueOf(id)});
        }
        Log.i(TAG, "标记离线取包记录已同步: " + recordIds.size() + "条");
    }

    /**
     * 清理已同步的旧记录（保留最近7天）
     */
    public void cleanOldSyncedRecords() {
        SQLiteDatabase db = getWritableDatabase();
        String cutoff = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                .format(new Date(System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000));
        int deleted = db.delete("offline_retrieve_records", "synced = 1 AND created_at < ?", new String[]{cutoff});
        if (deleted > 0) {
            Log.i(TAG, "清理已同步旧记录: " + deleted + "条");
        }
    }
}
