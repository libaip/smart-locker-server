package com.smartlocker.screen.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.smartlocker.screen.service.LockerService;

/**
 * 开机广播接收器
 * 实现开机自启动
 */
public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "BootReceiver";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) 
                || "android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            
            Log.i(TAG, "收到开机广播");
            
            // 延迟启动服务，等待系统就绪
            Intent serviceIntent = new Intent(context, LockerService.class);
            
            // 使用 PendingIntent 确保服务能启动
            try {
                context.startService(serviceIntent);
                Log.i(TAG, "LockerService 已启动");
            } catch (Exception e) {
                Log.e(TAG, "启动服务失败: " + e.getMessage());
            }
        }
    }
}
