package com.smartlocker.screen.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.smartlocker.screen.service.LockerService;

/**
 * 网络状态变化接收器
 * 断网自动重连
 */
public class NetworkReceiver extends BroadcastReceiver {
    private static final String TAG = "NetworkReceiver";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        
        if ("android.net.conn.CONNECTIVITY_CHANGE".equals(action)) {
            Log.i(TAG, "网络状态变化");
            
            // 网络恢复时，重启服务确保连接
            if (LockerService.isServiceRunning() && !LockerService.isConnected()) {
                Log.i(TAG, "尝试重连...");
                // 服务会自动重连，这里只是记录日志
            }
        }
    }
}
