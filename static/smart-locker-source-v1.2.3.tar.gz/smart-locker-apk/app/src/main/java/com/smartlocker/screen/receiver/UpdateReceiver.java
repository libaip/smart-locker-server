package com.smartlocker.screen.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * APK更新后自动重启接收器
 * 监听 PACKAGE_REPLACED 广播，应用被更新后自动启动
 */
public class UpdateReceiver extends BroadcastReceiver {
    private static final String TAG = "UpdateReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        
        String action = intent.getAction();
        Log.i(TAG, "收到广播: " + action);
        
        if (Intent.ACTION_PACKAGE_REPLACED.equals(action)) {
            String pkgName = intent.getDataString();
            Log.i(TAG, "包名: " + pkgName);
            
            // 只处理自己的包更新
            if (pkgName != null && pkgName.contains("com.smartlocker.screen")) {
                Log.i(TAG, "检测到自身更新，启动应用");
                Intent launchIntent = new Intent(context, com.smartlocker.screen.MainActivity.class);
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.startActivity(launchIntent);
            }
        }
    }
}
