package com.smartlocker.screen.service;

import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * 自动安装服务
 * 用于静默安装APK更新
 */
public class AutoInstallService extends Service {
    private static final String TAG = "AutoInstallService";
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String apkUrl = intent.getStringExtra("apk_url");
            if (apkUrl != null) {
                downloadAndInstall(apkUrl);
            }
        }
        return START_NOT_STICKY;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    private void downloadAndInstall(String urlStr) {
        new Thread(() -> {
            try {
                Log.i(TAG, "开始下载: " + urlStr);
                
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // SSL fix for old Android - bundle Let's Encrypt root cert
                if (conn instanceof javax.net.ssl.HttpsURLConnection) {
                    try {
                        javax.net.ssl.HttpsURLConnection httpsConn = (javax.net.ssl.HttpsURLConnection) conn;
                        java.io.InputStream certIs = getResources().openRawResource(com.smartlocker.screen.R.raw.isrgrootx1);
                        java.security.cert.X509Certificate isrgRoot = (java.security.cert.X509Certificate) java.security.cert.CertificateFactory.getInstance("X.509").generateCertificate(certIs);
                        certIs.close();
                        java.security.KeyStore ks = java.security.KeyStore.getInstance(java.security.KeyStore.getDefaultType());
                        ks.load(null, null);
                        ks.setCertificateEntry("isrg-root-x1", isrgRoot);
                        javax.net.ssl.TrustManagerFactory tmf = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.TrustManagerFactory.getDefaultAlgorithm());
                        tmf.init(ks);
                        javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("TLS");
                        sc.init(null, tmf.getTrustManagers(), null);
                        httpsConn.setSSLSocketFactory(sc.getSocketFactory());
                    } catch (Exception sslEx) {
                        Log.w(TAG, "Custom SSL for download failed", sslEx);
                    }
                }
                conn.connect();
                
                int length = conn.getContentLength();
                InputStream is = conn.getInputStream();
                
                File apkFile = new File(getExternalFilesDir(null), "update.apk");
                FileOutputStream fos = new FileOutputStream(apkFile);
                
                byte[] buffer = new byte[4096];
                int len;
                int downloaded = 0;
                
                while ((len = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len);
                    downloaded += len;
                    
                    // 可以在此更新下载进度
                    int progress = (int) ((downloaded / (float) length) * 100);
                    Log.d(TAG, "下载进度: " + progress + "%");
                }
                
                fos.close();
                is.close();
                conn.disconnect();
                
                Log.i(TAG, "下载完成");
                
                // 安装APK
                installApk(apkFile);
                
            } catch (Exception e) {
                Log.e(TAG, "下载失败: " + e.getMessage());
            } finally {
                stopSelf();
            }
        }).start();
    }
    
    private void installApk(File apkFile) {
        try {
            // 安装前先设置自动重启闹钟
            scheduleRestart();
            
            Intent intent = new Intent(Intent.ACTION_VIEW);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                // Android 7.0+ 需要FileProvider
                android.content.ComponentName comp = new android.content.ComponentName(
                    "com.smartlocker.screen", 
                    "com.smartlocker.screen.service.AutoInstallFileProvider");
                android.net.Uri apkUri = androidx.core.content.FileProvider.getUriForFile(
                    this, "com.smartlocker.screen.fileprovider", apkFile);
                intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                intent.setDataAndType(Uri.fromFile(apkFile), 
                        "application/vnd.android.package-archive");
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "安装失败: " + e.getMessage());
        }
    }
    
    /**
     * 设置安装后自动重启的闹钟
     */
    private void scheduleRestart() {
        try {
            android.app.AlarmManager alarmManager = (android.app.AlarmManager) 
                getSystemService(android.content.Context.ALARM_SERVICE);
            Intent restartIntent = new Intent(this, com.smartlocker.screen.MainActivity.class);
            restartIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            restartIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            android.app.PendingIntent pendingIntent = android.app.PendingIntent.getActivity(
                this, 0, restartIntent, android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
            
            // 30秒后启动
            long triggerTime = System.currentTimeMillis() + 30000;
            alarmManager.setExactAndAllowWhileIdle(
                android.app.AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);
            Log.i(TAG, "已设置30秒后自动重启");
        } catch (Exception e) {
            Log.e(TAG, "设置自动重启失败: " + e.getMessage());
        }
    }
}
