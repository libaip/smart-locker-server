package com.smartlocker.screen.service;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import com.smartlocker.screen.*;
import com.smartlocker.screen.db.DBHelper;
import com.smartlocker.screen.utils.PreferencesHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

/**
 * 后台服务 - 保持设备连接 + 离线取包支持
 * 
 * 功能:
 * - WebSocket连接管理
 * - HTTP轮询（每10秒，作为WebSocket的补充/替代）
 * - 串口通信管理
 * - 心跳机制
 * - 开锁指令处理
 * - 活跃订单缓存（每30秒拉取）
 * - 离线取包验证（本地手机号+密码匹配）
 * - 联网后同步取包记录
 * - 状态上报
 */
public class LockerService extends Service {
    private static final String TAG = "LockerService";
    
    // 心跳间隔
    private static final long HEARTBEAT_INTERVAL = 30000;  // 30秒
    
    // HTTP轮询间隔
    private static final long POLL_INTERVAL = 10;  // 10秒
    // 订单缓存间隔
    private static final long CACHE_INTERVAL = 30;  // 30秒
    
    // 单例
    private static LockerService instance;
    private static boolean isConnected = false;
    
    private PreferencesHelper mPrefs;
    private DBHelper mDB;
    private Handler mHandler;
    
    private SerialPortManager mSerialPort;
    private YBMProtocol mYBMProtocol;
    private WTProtocol mWTProtocol;
    private QMProtocol mQMProtocol;
    private LockerWebSocket mWebSocket;
    
    // 当前协议类型: 1=YBM, 2=WT, 3=QM
    private int mCurrentProtocol = YBMProtocol.PROTOCOL_YBM;
    
    private ScheduledExecutorService mScheduledExecutor;
    private ExecutorService mCommandExecutor;
    
    // HTTP客户端
    private OkHttpClient mHttpClient;
    
    // 当前处理的开锁请求
    private volatile String mCurrentOrderId = null;
    private volatile int mCurrentBoardNo = 0;
    private volatile int mCurrentLockNo = 0;
    
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        
        Log.i(TAG, "服务创建");
        
        mPrefs = new PreferencesHelper(this);
        mDB = DBHelper.getInstance(this);
        mHandler = new Handler(Looper.getMainLooper());
        
        mScheduledExecutor = Executors.newScheduledThreadPool(3);
        mCommandExecutor = Executors.newSingleThreadExecutor();
        
        mHttpClient = new OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.SECONDS)
                .writeTimeout(5, TimeUnit.SECONDS)
                .build();
        
        initComponents();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "服务启动");
        
        // 启动前台通知
        startForeground(1, createNotification());
        
        // 启动组件
        startSerial();
        startWebSocket();
        startHttpPolling();
        startOrderCache();
        startHeartbeat();
        startOfflineSync();
        
        return START_STICKY;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "服务销毁");
        
        stopAll();
        instance = null;
    }
    
    // ==================== 组件初始化 ====================
    
    private void initComponents() {
        // 初始化串口协议
        String serialType = mPrefs.getSerialType();
        SerialPortManager.SerialType type;
        if ("NormalSerial".equals(serialType)) {
            type = SerialPortManager.SerialType.NormalSerial;
        } else if ("VioSerial".equals(serialType)) {
            type = SerialPortManager.SerialType.VioSerial;
        } else {
            type = SerialPortManager.SerialType.BaseSerial;
        }
        
        mSerialPort = new SerialPortManager(type);
        
        String protocolType = mPrefs.getProtocolType();
        if ("WT".equals(protocolType)) {
            mCurrentProtocol = YBMProtocol.PROTOCOL_WT;
            mYBMProtocol = new YBMProtocol(mSerialPort, YBMProtocol.PROTOCOL_WT);
            mWTProtocol = new WTProtocol(mSerialPort);
            mYBMProtocol.setWTProtocol(mWTProtocol);
        } else if ("QM".equals(protocolType)) {
            mCurrentProtocol = YBMProtocol.PROTOCOL_QM;
            mYBMProtocol = new YBMProtocol(mSerialPort, YBMProtocol.PROTOCOL_YBM);
            mQMProtocol = new QMProtocol(mSerialPort);
            mYBMProtocol.setQMProtocol(mQMProtocol);
        } else {
            mCurrentProtocol = YBMProtocol.PROTOCOL_YBM;
            mYBMProtocol = new YBMProtocol(mSerialPort, YBMProtocol.PROTOCOL_YBM);
        }
        
        // 设置主板数组
        mYBMProtocol.setBoardArr(mPrefs.getBoardNoList());
        
        // 设置回调
        mYBMProtocol.setLockCallback(new YBMProtocol.OnLockCallback() {
            @Override
            public void onOpenLockResult(int boardNo, int lockNo, boolean success) {
                handleLockResult(boardNo, lockNo, success);
            }
            
            @Override
            public void onMcuIdReceived(int boardNo, String mcuId) {
                Log.i(TAG, "MCU ID: " + mcuId + " (board=" + boardNo + ")");
            }
            
            @Override
            public void onLockStatusReceived(int boardNo, int[] lockStatus) {
                Log.i(TAG, "锁状态: board=" + boardNo + ", count=" + lockStatus.length);
            }
            
            @Override
            public void onError(String message) {
                Log.e(TAG, "协议错误: " + message);
            }
        });
        
        // 初始化WebSocket
        mWebSocket = new LockerWebSocket(mPrefs, this);
        mWebSocket.setListener(new LockerWebSocket.OnWSListener() {
            @Override
            public void onConnected() {
                isConnected = true;
                Log.i(TAG, "WebSocket已连接");
                notifyMainActivity(true);
            }
            
            @Override
            public void onDisconnected() {
                isConnected = false;
                Log.i(TAG, "WebSocket已断开");
                notifyMainActivity(false);
            }
            
            @Override
            public void onLockCommand(int boardNo, int lockNo, String orderId, String protocol) {
                handleLockCommand(boardNo, lockNo, orderId, protocol);
            }
            
            @Override
            public void onOpenAllCommand(String orderId) {
                handleOpenAllCommand(orderId);
            }
            
            @Override
            public void onMessageReceived(String topic, String message) {
                handleServerMessage(topic, message);
            }
            
            @Override
            public void onError(String error) {
                Log.e(TAG, "WebSocket错误: " + error);
            }
        });
    }
    
    // ==================== 串口管理 ====================
    
    private boolean startSerial() {
        String port = mPrefs.getSerialPort();
        int baud = mPrefs.getBaudRate();
        
        boolean success = mSerialPort.open(port, baud);
        
        if (success) {
            mSerialPort.setDataReceivedListener((data, length) -> {
                switch (mCurrentProtocol) {
                    case YBMProtocol.PROTOCOL_WT:
                        if (mWTProtocol != null) mWTProtocol.handleReceivedData(data, length);
                        break;
                    case YBMProtocol.PROTOCOL_QM:
                        if (mQMProtocol != null) mQMProtocol.handleReceivedData(data, length);
                        break;
                    default:
                        mYBMProtocol.handleReceivedData(data, length);
                        break;
                }
            });
            Log.i(TAG, "串口启动成功: " + port + " @ " + baud + ", 协议=" + mCurrentProtocol);
        } else {
            Log.e(TAG, "串口启动失败: " + port);
        }
        
        return success;
    }
    
    private void stopSerial() {
        if (mSerialPort != null) {
            mSerialPort.close();
        }
    }
    
    private void restartSerial() {
        stopSerial();
        mHandler.postDelayed(this::startSerial, 1000);
    }
    
    // ==================== WebSocket管理 ====================
    
    private void startWebSocket() {
        if (mWebSocket != null) {
            mWebSocket.connect();
        }
    }
    
    private void stopWebSocket() {
        if (mWebSocket != null) {
            mWebSocket.disconnect();
        }
    }
    
    // ==================== HTTP轮询（离线指令兜底） ====================
    
    private void startHttpPolling() {
        mScheduledExecutor.scheduleAtFixedRate(() -> {
            try {
                pollPendingCommands();
            } catch (Exception e) {
                Log.e(TAG, "HTTP轮询异常: " + e.getMessage());
            }
        }, POLL_INTERVAL, POLL_INTERVAL, TimeUnit.SECONDS);
    }
    
    private void pollPendingCommands() {
        String deviceId = mPrefs.getDeviceId();
        if (deviceId == null || deviceId.isEmpty()) return;
        
        String url = mPrefs.getServerUrl() + "/api/pending-commands/" + deviceId;
        
        Request request = new Request.Builder()
                .url(url)
                .get()
                .build();
        
        try (Response response = mHttpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                Log.w(TAG, "轮询失败: " + response.code());
                return;
            }
            
            String body = response.body().string();
            JSONObject json = new JSONObject(body);
            JSONObject data = json.optJSONObject("data");
            if (data == null) data = json;
            
            // 处理积压的开锁指令
            JSONArray commands = data.optJSONArray("commands");
            if (commands != null && commands.length() > 0) {
                Log.i(TAG, "轮询获取到" + commands.length() + "条待执行指令");
                for (int i = 0; i < commands.length(); i++) {
                    JSONObject cmd = commands.getJSONObject(i);
                    int boardNo = cmd.optInt("board_no", 1);
                    int lockNo = cmd.optInt("lock_no", 1);
                    String orderId = cmd.optString("order_id", "");
                    String protocol = cmd.optString("protocol", "YBM");
                    handleLockCommand(boardNo, lockNo, orderId, protocol);
                }
            }
            
            // 更新活跃订单缓存
            JSONArray orders = data.optJSONArray("orders");
            if (orders != null) {
                updateOrderCache(orders);
            }
            
        } catch (Exception e) {
            Log.d(TAG, "轮询请求失败: " + e.getMessage());
        }
    }
    
    // ==================== 订单缓存（支持离线取包） ====================
    
    private void startOrderCache() {
        // 首次立即拉取
        mScheduledExecutor.schedule(() -> {
            try {
                fetchActiveOrders();
            } catch (Exception e) {
                Log.e(TAG, "订单缓存异常: " + e.getMessage());
            }
        }, 5, TimeUnit.SECONDS);
        
        // 之后每30秒拉取一次
        mScheduledExecutor.scheduleAtFixedRate(() -> {
            try {
                fetchActiveOrders();
            } catch (Exception e) {
                Log.d(TAG, "订单缓存请求失败: " + e.getMessage());
            }
        }, CACHE_INTERVAL, CACHE_INTERVAL, TimeUnit.SECONDS);
        
        // 每5分钟清理过期缓存
        mScheduledExecutor.scheduleAtFixedRate(() -> {
            try {
                mDB.cleanExpiredCache();
                mDB.cleanOldSyncedRecords();
            } catch (Exception e) {
                Log.e(TAG, "清理缓存异常: " + e.getMessage());
            }
        }, 5, 5, TimeUnit.MINUTES);
    }
    
    private void fetchActiveOrders() {
        String deviceId = mPrefs.getDeviceId();
        if (deviceId == null || deviceId.isEmpty()) return;
        
        String url = mPrefs.getServerUrl() + "/api/active-orders/by-device/" + deviceId;
        
        Request request = new Request.Builder()
                .url(url)
                .get()
                .build();
        
        try (Response response = mHttpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) return;
            
            String body = response.body().string();
            JSONObject json = new JSONObject(body);
            JSONObject data = json.optJSONObject("data");
            if (data == null) data = json;
            
            JSONArray orders = data.optJSONArray("orders");
            if (orders != null) {
                updateOrderCache(orders);
            }
            
        } catch (Exception e) {
            Log.d(TAG, "获取活跃订单失败: " + e.getMessage());
        }
    }
    
    private void updateOrderCache(JSONArray orders) {
        try {
            List<android.content.ContentValues> orderList = new ArrayList<>();
            for (int i = 0; i < orders.length(); i++) {
                JSONObject o = orders.getJSONObject(i);
                android.content.ContentValues values = new android.content.ContentValues();
                values.put("order_id", o.optInt("order_id"));
                values.put("order_no", o.optString("order_no", ""));
                values.put("user_phone", o.optString("user_phone", ""));
                values.put("access_code", o.optString("access_code", ""));
                values.put("deposit_amount", o.optDouble("deposit_amount", 0));
                values.put("compartment_number", o.optInt("compartment_number", 0));
                values.put("slot_size", o.optString("slot_size", ""));
                values.put("cabinet_id", o.optInt("cabinet_id", 0));
                values.put("store_time", o.optString("store_time", ""));
                orderList.add(values);
            }
            mDB.refreshCachedOrders(orderList);
            Log.d(TAG, "订单缓存更新: " + orderList.size() + "条活跃订单");
        } catch (Exception e) {
            Log.e(TAG, "更新订单缓存失败: " + e.getMessage());
        }
    }
    
    // ==================== 离线取包验证 ====================
    
    /**
     * 离线取包验证 - 在屏幕端输入手机号+密码
     * 1. 先查本地缓存
     * 2. 匹配成功→开锁+记录到offline_retrieve_records
     * 3. 联网后自动同步到服务器
     */
    public boolean offlineRetrieve(String phone, String accessCode) {
        // 查本地缓存
        android.content.ContentValues order = mDB.findCachedOrder(phone, accessCode);
        
        if (order == null) {
            Log.w(TAG, "离线取包验证失败: phone=" + phone);
            return false;
        }
        
        int orderId = order.getAsInteger("order_id");
        String orderNo = order.getAsString("order_no");
        int compartmentNumber = order.containsKey("compartment_number") ? 
                order.getAsInteger("compartment_number") : 0;
        
        Log.i(TAG, "离线取包验证成功: orderId=" + orderId + ", compartment=" + compartmentNumber);
        
        // 开锁
        int boardNo = 1;  // 默认主板1
        int lockNo = compartmentNumber > 0 ? compartmentNumber : 1;
        handleLockCommand(boardNo, lockNo, String.valueOf(orderId), mPrefs.getProtocolType());
        
        // 记录到离线取包表
        mDB.recordOfflineRetrieve(orderId, orderNo, phone);
        
        // 尝试立即同步
        syncOfflineRetrieves();
        
        return true;
    }
    
    // ==================== 离线取包同步 ====================
    
    private void startOfflineSync() {
        // 每30秒检查是否有未同步的记录
        mScheduledExecutor.scheduleAtFixedRate(() -> {
            try {
                syncOfflineRetrieves();
            } catch (Exception e) {
                Log.e(TAG, "离线同步异常: " + e.getMessage());
            }
        }, 30, 30, TimeUnit.SECONDS);
    }
    
    private void syncOfflineRetrieves() {
        List<android.content.ContentValues> unsynced = mDB.getUnsyncedRetrieves();
        if (unsynced.isEmpty()) return;
        
        String deviceId = mPrefs.getDeviceId();
        JSONArray records = new JSONArray();
        List<Integer> recordIds = new ArrayList<>();
        
        for (android.content.ContentValues rec : unsynced) {
            try {
                JSONObject r = new JSONObject();
                r.put("order_id", rec.getAsInteger("order_id"));
                r.put("order_no", rec.getAsString("order_no"));
                r.put("user_phone", rec.getAsString("user_phone"));
                r.put("retrieve_time", rec.getAsString("retrieve_time"));
                records.put(r);
                recordIds.add(rec.getAsInteger("_id"));
            } catch (Exception e) {
                Log.e(TAG, "构建同步记录失败: " + e.getMessage());
            }
        }
        
        try {
            JSONObject requestBody = new JSONObject();
            requestBody.put("device_id", deviceId);
            requestBody.put("records", records);
            
            String url = mPrefs.getServerUrl() + "/api/offline-retrieve/batch";
            RequestBody body = RequestBody.create(
                    requestBody.toString(),
                    MediaType.parse("application/json"));
            
            Request request = new Request.Builder()
                    .url(url)
                    .post(body)
                    .build();
            
            try (Response response = mHttpClient.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    mDB.markRetrievesSynced(recordIds);
                    Log.i(TAG, "离线取包同步成功: " + recordIds.size() + "条");
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "离线同步请求失败: " + e.getMessage());
        }
    }
    
    // ==================== 心跳机制 ====================
    
    private void startHeartbeat() {
        // 定期发送串口心跳
        mScheduledExecutor.scheduleAtFixedRate(() -> {
            if (mSerialPort != null && mSerialPort.isOpened()) {
                mYBMProtocol.sendHeartbeatAll();
            }
        }, HEARTBEAT_INTERVAL, HEARTBEAT_INTERVAL, TimeUnit.MILLISECONDS);
        
        // 定期发送服务器心跳
        mScheduledExecutor.scheduleAtFixedRate(() -> {
            if (mWebSocket != null && mWebSocket.isConnected()) {
                mWebSocket.sendHeartbeat();
            }
            mPrefs.setLastHeartbeat(System.currentTimeMillis());
        }, HEARTBEAT_INTERVAL, HEARTBEAT_INTERVAL, TimeUnit.MILLISECONDS);
    }
    
    // ==================== 开锁处理 ====================
    
    private void handleLockCommand(int boardNo, int lockNo, String orderId, String protocol) {
        Log.i(TAG, "收到开锁指令: board=" + boardNo + ", lock=" + lockNo + ", orderId=" + orderId);
        
        mCurrentOrderId = orderId;
        mCurrentBoardNo = boardNo;
        mCurrentLockNo = lockNo;
        
        mCommandExecutor.execute(() -> {
            try {
                String targetProtocol = mPrefs.getProtocolType();
                String effectiveProtocol = (protocol != null && !protocol.isEmpty()) ? protocol : targetProtocol;
                
                boolean sent = false;
                
                if ("WT".equalsIgnoreCase(effectiveProtocol) && mWTProtocol != null) {
                    sent = mWTProtocol.sendOpenLock(boardNo, lockNo);
                } else if ("QM".equalsIgnoreCase(effectiveProtocol) && mQMProtocol != null) {
                    sent = mQMProtocol.sendOpenLock(boardNo, lockNo);
                } else {
                    sent = mYBMProtocol.sendOpenLock(boardNo, lockNo);
                }
                
                if (!sent) {
                    handleLockResult(boardNo, lockNo, false);
                    return;
                }
                
                Thread.sleep(1000);
                handleLockResult(boardNo, lockNo, true);
                
            } catch (Exception e) {
                Log.e(TAG, "处理开锁失败: " + e.getMessage());
                handleLockResult(boardNo, lockNo, false);
            }
        });
    }
    
    private void handleOpenAllCommand(String orderId) {
        Log.i(TAG, "收到全开指令: orderId=" + orderId);
        
        mCommandExecutor.execute(() -> {
            try {
                int[] boards = mPrefs.getBoardNoList();
                for (int boardNo : boards) {
                    boolean sent = mYBMProtocol.sendOpenAll(boardNo);
                    if (sent) {
                        Thread.sleep(500);
                    }
                }
                
                mDB.recordOpenLock(orderId, 0, 0, 2, true);
                
                if (mWebSocket != null && mWebSocket.isConnected()) {
                    mWebSocket.sendLockResult(orderId, 0, 0, true);
                }
                
            } catch (Exception e) {
                Log.e(TAG, "处理全开失败: " + e.getMessage());
            }
        });
    }
    
    private void handleLockResult(int boardNo, int lockNo, boolean success) {
        String orderId = mCurrentOrderId;
        
        Log.i(TAG, "开锁结果: board=" + boardNo + ", lock=" + lockNo + ", success=" + success);
        
        int openType = orderId != null && !orderId.isEmpty() ? 0 : 1;
        mDB.recordOpenLock(orderId, boardNo, lockNo, openType, success);
        
        mCurrentOrderId = null;
        mCurrentBoardNo = 0;
        mCurrentLockNo = 0;
        
        // WebSocket上报
        if (mWebSocket != null && mWebSocket.isConnected() && orderId != null) {
            mWebSocket.sendLockResult(orderId, boardNo, lockNo, success);
        }
        
        // HTTP上报（兜底，确保服务器收到）
        if (orderId != null && !orderId.isEmpty()) {
            reportLockResultHttp(orderId, boardNo, lockNo, success);
        }
    }
    
    /**
     * 通过HTTP上报开锁结果（WebSocket断线时的兜底）
     */
    private void reportLockResultHttp(String orderId, int boardNo, int lockNo, boolean success) {
        try {
            JSONObject body = new JSONObject();
            body.put("device_id", mPrefs.getDeviceId());
            body.put("order_id", orderId);
            body.put("board_no", boardNo);
            body.put("lock_no", lockNo);
            body.put("success", success);
            
            String url = mPrefs.getServerUrl() + "/api/lock-result";
            RequestBody requestBody = RequestBody.create(
                    body.toString(),
                    MediaType.parse("application/json"));
            
            Request request = new Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build();
            
            mHttpClient.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.w(TAG, "HTTP上报开锁结果失败: " + e.getMessage());
                }
                
                @Override
                public void onResponse(Call call, Response response) {
                    Log.d(TAG, "HTTP上报开锁结果: " + response.code());
                    response.close();
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "构建HTTP上报失败: " + e.getMessage());
        }
    }
    
    private void handleServerMessage(String topic, String message) {
        try {
            JSONObject json = new JSONObject(message);
            String type = json.optString("type", "");
            
            switch (type) {
                case "update_config":
                    if (json.has("serial_port")) {
                        mPrefs.setSerialPort(json.getString("serial_port"));
                    }
                    if (json.has("baud_rate")) {
                        mPrefs.setBaudRate(json.getInt("baud_rate"));
                    }
                    restartSerial();
                    break;
                    
                case "query_status":
                    reportDeviceStatus();
                    break;
                    
                default:
                    Log.d(TAG, "收到消息: " + topic + " -> " + message);
            }
        } catch (Exception e) {
            Log.e(TAG, "处理消息失败: " + e.getMessage());
        }
    }
    
    // ==================== 状态上报 ====================
    
    private void reportDeviceStatus() {
        if (mWebSocket == null || !mWebSocket.isConnected()) {
            return;
        }
        
        try {
            JSONObject status = new JSONObject();
            status.put("deviceId", mPrefs.getDeviceId());
            status.put("serialPort", mPrefs.getSerialPort());
            status.put("baudRate", mPrefs.getBaudRate());
            status.put("protocol", mPrefs.getProtocolType());
            status.put("boardCount", mPrefs.getBoardCount());
            status.put("online", true);
            status.put("timestamp", System.currentTimeMillis());
            
            Log.d(TAG, "上报状态: " + status.toString());
        } catch (Exception e) {
            Log.e(TAG, "上报状态失败: " + e.getMessage());
        }
    }
    
    // ==================== 通知主界面 ====================
    
    private void notifyMainActivity(boolean connected) {
        Intent intent = new Intent("com.smartlocker.CONNECTION_CHANGED");
        intent.putExtra("connected", connected);
        sendBroadcast(intent);
    }
    
    // ==================== 服务控制 ====================
    
    private void stopAll() {
        stopSerial();
        stopWebSocket();
        
        if (mScheduledExecutor != null) {
            mScheduledExecutor.shutdown();
        }
        if (mCommandExecutor != null) {
            mCommandExecutor.shutdown();
        }
        
        isConnected = false;
    }
    
    private android.app.Notification createNotification() {
        android.app.Notification.Builder builder;
        
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            builder = new android.app.Notification.Builder(this, SmartLockerApp.CHANNEL_ID);
        } else {
            builder = new android.app.Notification.Builder(this);
        }
        
        return builder
                .setContentTitle("智能寄存柜运行中")
                .setContentText("设备: " + mPrefs.getDeviceId())
                .setSmallIcon(R.drawable.ic_notification)
                .setPriority(android.app.Notification.PRIORITY_LOW)
                .setOngoing(true)
                .build();
    }
    
    // ==================== 公共接口 ====================
    
    public static boolean isServiceRunning() {
        return instance != null;
    }
    
    public static boolean isConnected() {
        return isConnected;
    }
    
    public static void triggerManualOpen(int boardNo, int lockNo) {
        if (instance != null) {
            instance.handleLockCommand(boardNo, lockNo, "manual_" + System.currentTimeMillis(), "YBM");
        }
    }
    
    public static void triggerOpenAll() {
        if (instance != null) {
            instance.handleOpenAllCommand("openall_" + System.currentTimeMillis());
        }
    }
    
    /**
     * 离线取包 - 公共入口
     * 在MainActivity的取包对话框中调用
     */
    public static boolean staticOfflineRetrieve(String phone, String accessCode) {
        if (instance != null) {
            return instance.offlineRetrieve(phone, accessCode);
        }
        return false;
    }
    
    
    /**
     * 获取缓存订单数量（供UI显示）
     */
    public static int getCachedOrderCount() {
        if (instance != null) {
            return instance.mDB.getValidCachedOrders().size();
        }
        return 0;
    }
    
    /**
     * 获取未同步记录数量（供UI显示）
     */
    public static int getUnsyncedCount() {
        if (instance != null) {
            return instance.mDB.getUnsyncedRetrieves().size();
        }
        return 0;
    }
}
