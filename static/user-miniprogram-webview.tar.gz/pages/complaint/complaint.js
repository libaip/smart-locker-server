// pages/complaint/complaint.js - 投诉建议页面
const API = require('../../utils/api.js')

Page({
  data: {
    complaintTypes: [
      { id: 'self', name: '使用问题', checked: true },
      { id: 'device', name: '设备故障', checked: false },
      { id: 'fee', name: '费用问题', checked: false },
      { id: 'other', name: '其他', checked: false }
    ],
    selectedType: 'self',
    content: '',
    orderNo: '',
    userPhone: '',
    isSubmitting: false,
    maxContentLength: 200
  },

  onLoad(options) {
    // 如果从订单详情页进入，自动填充订单号
    if (options.orderNo) {
      this.setData({ orderNo: options.orderNo })
    }
    
    // 获取用户手机号（从本地存储读取）
    const userPhone = wx.getStorageSync('userPhone') || ''
    this.setData({ userPhone })
  },

  // 选择投诉类型
  onTypeChange(e) {
    const index = parseInt(e.currentTarget.dataset.index)
    const types = this.data.complaintTypes.map((item, i) => {
      item.checked = i === index
      return item
    })
    this.setData({
      complaintTypes: types,
      selectedType: types[index].id
    })
  },

  // 投诉内容输入
  onContentInput(e) {
    const content = e.detail.value
    if (content.length <= this.data.maxContentLength) {
      this.setData({ content })
    }
  },

  // 订单号输入
  onOrderNoInput(e) {
    this.setData({ orderNo: e.detail.value })
  },

  // 手机号输入
  onPhoneInput(e) {
    this.setData({ userPhone: e.detail.value })
  },

  // 提交投诉
  onSubmit() {
    const { content, userPhone, selectedType, orderNo } = this.data
    
    // 验证投诉内容
    if (!content || content.trim().length < 5) {
      wx.showToast({
        title: '请输入至少5个字的投诉内容',
        icon: 'none'
      })
      return
    }
    
    // 验证手机号
    if (!userPhone || !/^1[3-9]\d{9}$/.test(userPhone)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      })
      return
    }
    
    if (this.data.isSubmitting) return
    
    this.setData({ isSubmitting: true })
    
    // 保存手机号到本地
    wx.setStorageSync('userPhone', userPhone)
    
    API.submitComplaint({
      type: selectedType,
      content: content.trim(),
      orderNo: orderNo.trim(),
      userPhone: userPhone
    }).then(res => {
      this.setData({ isSubmitting: false })
      wx.showToast({
        title: '提交成功',
        icon: 'success'
      })
      setTimeout(() => {
        wx.navigateBack()
      }, 1500)
    }).catch(err => {
      this.setData({ isSubmitting: false })
      console.error('提交投诉失败:', err)
    })
  }
})
