// pages/mine/mine.js - 个人中心
var API = require('../../utils/api.js')
Page({
  data: {
    phoneNumber: '未登录',
    openid: '',
    showOpenid: false
  },
  onLoad: function() {
    this.loadUserInfo()
  },
  onShow: function() {
    this.loadUserInfo()
  },
  loadUserInfo: function() {
    var phone = wx.getStorageSync('userPhone') || ''
    var openid = wx.getStorageSync('openid') || ''
    var masked = '未登录'
    if (phone && phone.length === 11) {
      masked = phone.substring(0, 3) + '****' + phone.substring(7)
    }
    this.setData({ phoneNumber: masked, openid: openid })
    // 每次都刷新session_key，确保getPhoneNumber能解密
    this.doWxLogin()
  },
  doWxLogin: function() {
    var that = this
    wx.login({
      success: function(res) {
        if (res.code) {
          API.wxLogin(res.code).then(function(resp) {
            if (resp && resp.data && resp.data.openid) {
              wx.setStorageSync('openid', resp.data.openid)
              that.setData({ openid: resp.data.openid })
            }
            if (resp && resp.data && resp.data.session_key) {
              wx.setStorageSync('sessionKey', resp.data.session_key)
            }
          }).catch(function() {})
        }
      }
    })
  },
  onMyOrders: function() {
    wx.navigateTo({ url: '/pages/orders/orders' })
  },
  onMyBalance: function() {
    var phone = wx.getStorageSync('userPhone')
    if (!phone) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      return
    }
    API.getBalance(phone).then(function(resp) {
      var d = resp.data || {}
      var bal = d.balance != null ? parseFloat(d.balance).toFixed(2) : '0.00'
      var ref = (d.refunding_amount || 0).toFixed(2)
      wx.showModal({
        title: '我的余额',
        content: '余额：¥' + bal + '\n退款中：¥' + ref,
        confirmText: '提现',
        cancelText: '关闭',
        success: function(r) {
          if (r.confirm) {
            var amount = parseFloat(d.balance)
            if (!amount || amount <= 0) {
              wx.showToast({ title: '余额不足', icon: 'none' })
              return
            }
            wx.showModal({
              title: '确认提现',
              content: '提现金额：¥' + amount.toFixed(2),
              success: function(r2) {
                if (r2.confirm) {
                  API.applyWithdrawal(phone, amount).then(function() {
                    wx.showToast({ title: '提现申请已提交', icon: 'success' })
                  }).catch(function(e) {
                    wx.showToast({ title: e.message || '提现失败', icon: 'none' })
                  })
                }
              }
            })
          }
        }
      })
    }).catch(function() {
      wx.showToast({ title: '查询失败', icon: 'none' })
    })
  },
  onHelp: function() {
    wx.showModal({
      title: '使用帮助',
      content: '1. 扫描柜体二维码存包\n2. 输入手机号和4位取件码\n3. 支付押金后柜门自动打开\n4. 取包时输入手机号+取件码\n5. 柜门打开后取走物品\n6. 押金自动原路退还',
      showCancel: false,
      confirmText: '知道了'
    })
  },
  onClearCache: function() {
    wx.showModal({
      title: '确认清理',
      content: '将清除本地缓存数据，不影响订单记录',
      success: function(res) {
        if (res.confirm) {
          var openid = wx.getStorageSync('openid')
          var phone = wx.getStorageSync('userPhone')
          wx.clearStorageSync()
          if (openid) wx.setStorageSync('openid', openid)
          if (phone) wx.setStorageSync('userPhone', phone)
          wx.showToast({ title: '缓存已清理', icon: 'success' })
        }
      }
    })
  },
  onCallComplaint: function() {
    wx.makePhoneCall({
      phoneNumber: '400-000-0000',
      fail: function() {
        wx.showToast({ title: '拨号失败', icon: 'none' })
      }
    })
  },
  // 微信授权手机号登录
  onGetPhoneNumber: function(e) {
    var that = this
    if (e.detail.errMsg && e.detail.errMsg.indexOf('fail') !== -1) {
      wx.showToast({ title: '需要授权手机号才能登录', icon: 'none' })
      return
    }
    var encryptedData = e.detail.encryptedData || ''
    var iv = e.detail.iv || ''
    if (!encryptedData || !iv) {
      wx.showToast({ title: '授权失败，请重试', icon: 'none' })
      return
    }
    wx.showLoading({ title: '登录中...' })
    // wx.login拿code，然后code+encryptedData+iv一起发后端
    // 后端一步到位：code→session_key→解密手机号
    wx.login({
      success: function(loginRes) {
        if (!loginRes.code) {
          wx.hideLoading()
          wx.showToast({ title: '登录失败', icon: 'none' })
          return
        }
        API.loginPhone(loginRes.code, encryptedData, iv).then(function(resp) {
          wx.hideLoading()
          var openid = (resp && resp.data && resp.data.openid) || ''
          var phone = (resp && resp.data && resp.data.phone) || ''
          var sessionKey = (resp && resp.data && resp.data.session_key) || ''
          if (openid) {
            wx.setStorageSync('openid', openid)
            that.setData({ openid: openid })
          }
          if (sessionKey) wx.setStorageSync('sessionKey', sessionKey)
          if (phone) {
            wx.setStorageSync('userPhone', phone)
            var masked = phone.substring(0, 3) + '****' + phone.substring(7)
            that.setData({ phoneNumber: masked })
            wx.showToast({ title: '登录成功', icon: 'success' })
          } else {
            wx.showToast({ title: '获取手机号失败', icon: 'none' })
          }
        }).catch(function(err) {
          wx.hideLoading()
          console.error('loginPhone failed', err)
          wx.showToast({ title: '登录失败，请重试', icon: 'none' })
        })
      },
      fail: function() {
        wx.hideLoading()
        wx.showToast({ title: '微信登录失败', icon: 'none' })
      }
    })
  },

  onComplaint: function() {
    wx.navigateTo({ url: '/pages/complaint/complaint' })
  }
})
