// pages/orders/orders.js - 订单页面逻辑
const API = require('../../utils/api.js')
const util = require('../../utils/util.js')

Page({
  data: {
    phone: '',
    canSearch: false,
    hasSearched: false,
    loading: false,
    orders: []
  },

  // 手机号输入
  onPhoneInput(e) {
    const phone = e.detail.value
    this.setData({
      phone: phone,
      canSearch: util.validatePhone(phone)
    })
  },

  // 查询订单
  onSearch() {
    const { phone } = this.data
    
    if (!util.validatePhone(phone)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      })
      return
    }
    
    this.setData({ loading: true, hasSearched: true })
    
    API.getOrders(phone)
      .then(res => {
        this.setData({ loading: false })
        
        if (res.data && Array.isArray(res.data)) {
          const orders = res.data.map(item => this.formatOrder(item))
          this.setData({ orders })
        } else if (res.data && res.data.list) {
          const orders = res.data.list.map(item => this.formatOrder(item))
          this.setData({ orders })
        } else {
          this.setData({ orders: [] })
        }
      })
      .catch(err => {
        this.setData({ loading: false })
        console.error('查询订单失败:', err)
        this.setData({ orders: [] })
      })
  },

  // 格式化订单数据
  formatOrder(item) {
    const statusMap = {
      'storing': { text: '在存', class: 'storing' },
      'retrieved': { text: '已取', class: 'retrieved' },
      'timeout': { text: '已超时', class: 'timeout' }
    }
    
    const status = item.status || 'storing'
    const statusInfo = statusMap[status] || statusMap.storing
    
    return {
      order_id: item.order_id || item.id,
      cabinet_name: item.cabinet_name || item.location || '寄存柜',
      slot_no: item.slot_no || item.slot_id,
      slot_size: item.slot_size,
      slot_size_name: util.getSlotSizeName(item.slot_size),
      deposit_time: item.deposit_time ? util.formatDateShort(item.deposit_time) : '',
      retrieve_time: item.retrieve_time ? util.formatDateShort(item.retrieve_time) : '',
      status: status,
      status_text: statusInfo.text,
      status_class: statusInfo.class,
      phone: item.phone,
      access_code: item.access_code
    }
  },

  // 快速取物
  onGoRetrieve(e) {
    const { phone, code } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/retrieve/retrieve?phone=${phone}&code=${code}`
    })
  },

  // 查看订单详情
  onViewDetail(e) {
    const { orderId } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/order-detail/order-detail?orderId=${orderId}`
    })
  },

  // 投诉订单
  onComplaint(e) {
    const { orderId, orderNo } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/complaint/complaint?orderNo=${orderNo || orderId}`
    })
  }
})
