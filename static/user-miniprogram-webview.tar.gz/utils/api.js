// utils/api.js - 用户端小程序API封装

const BASE_URL = 'https://locker.cqdyxl.com/api'

function request(options) {
  var url = options.url
  var method = options.method || 'GET'
  var data = options.data || {}
  var header = options.header || {}
  return new Promise(function(resolve, reject) {
    wx.request({
      url: BASE_URL + url,
      method: method,
      data: data,
      header: Object.assign({ 'Content-Type': 'application/json' }, header),
      timeout: 15000,
      success: function(res) {
        if (res.data && (res.data.code === 0 || res.data.code === 200)) {
          resolve(res.data)
        } else {
          reject({ code: res.data ? res.data.code : -1, message: res.data ? res.data.message : '请求失败' })
        }
      },
      fail: function(err) {
        reject({ code: -1, message: '网络请求失败' })
      }
    })
  })
}

function get(url, data) { return request({ url: url, method: 'GET', data: data }) }
function post(url, data) { return request({ url: url, method: 'POST', data: data }) }

// 微信登录
function wxLogin(code) { return post('/wx/login', { code: code }) }

// 解密手机号
function decryptPhone(encryptedData, iv, sessionKey) { return post('/wx/phone', { encrypted_data: encryptedData, iv: iv, session_key: sessionKey }) }

// 一步登录+解密手机号：code+encryptedData+iv一起发后端
function loginPhone(code, encryptedData, iv) { return post('/wx/login-phone', { code: code, encrypted_data: encryptedData, iv: iv }) }

// 获取用户余额
function getBalance(phone) { return get('/user/balance', { phone: phone }) }

// 申请提现
function applyWithdrawal(phone, amount) { return post('/user/withdraw', { phone: phone, amount: amount }) }

// 获取订单列表
function getOrders(phone) { return get('/user/orders', { phone: phone }) }

// 获取订单详情
function getOrderDetail(orderId) { return get('/order/' + orderId) }

// 创建存包订单
function createOrder(params) {
  return post('/deposit/create-order', {
    cabinet_id: params.cabinetId,
    slot_size: params.slotSize || 'M',
    phone: params.phone,
    access_code: params.accessCode,
    sms_code: params.smsCode || '',
    openid: params.openid || ''
  })
}

// 取物验证
function retrieveVerify(phone, accessCode, cabinetId) {
  return post('/deposit/retrieve', { phone: phone, access_code: accessCode, cabinet_id: cabinetId || undefined })
}

// 继续寄存
function continueStorage(orderId) { return post('/deposit/continue-storage', { order_id: orderId }) }

// 结束取物
function endStorage(orderId) { return post('/deposit/end-storage', { order_id: orderId }) }

// 获取柜体信息(通过二维码参数)
function getCabinetInfo(cabinetId) { return get('/cabinets/' + cabinetId) }

// 获取柜体信息(通过主板ID)
function getCabinetByMainboard(deviceId) { return get('/cabinets/by-mainboard/' + deviceId) }

// 获取柜格列表
function getSlots(cabinetId) { return get('/cabinets/' + cabinetId + '/slots') }

// 获取柜体信息(通过group_code)
function getCabinetByGroupCode(groupCode) { return get('/cabinets/by-group/' + groupCode) }

// 远程开锁
function openDoor(cabinetId, slotId) { return post('/cabinets/' + cabinetId + '/slots/' + slotId + '/open') }

// 支付处理
function handlePay(orderId) { return post('/order/' + orderId + '/pay') }

// 查询支付状态
function getPayStatus(orderId) { return get('/order/' + orderId + '/pay-status') }

// 提交投诉
function submitComplaint(params) {
  return post('/complaints', {
    type: params.type || 'self',
    content: params.content,
    order_no: params.orderNo || '',
    user_phone: params.userPhone
  })
}

// 获取投诉记录
function getComplaintList(phone) { return get('/complaints', { user_phone: phone }) }

module.exports = {
  BASE_URL: BASE_URL,
  request: request, get: get, post: post,
  wxLogin: wxLogin,
  decryptPhone: decryptPhone,
  loginPhone: loginPhone,
  getBalance: getBalance, applyWithdrawal: applyWithdrawal,
  getOrders: getOrders, getOrderDetail: getOrderDetail,
  createOrder: createOrder,
  retrieveVerify: retrieveVerify,
  continueStorage: continueStorage, endStorage: endStorage,
  getCabinetInfo: getCabinetInfo,
  getCabinetByMainboard: getCabinetByMainboard,
  getCabinetByGroupCode: getCabinetByGroupCode,
  getSlots: getSlots,
  openDoor: openDoor,
  handlePay: handlePay, getPayStatus: getPayStatus,
  submitComplaint: submitComplaint,
  getComplaintList: getComplaintList
}
